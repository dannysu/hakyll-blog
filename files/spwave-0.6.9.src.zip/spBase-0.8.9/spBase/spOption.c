/*
 *	spOption.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>
#include <sp/spOption.h>

struct _spOptions {
    char *progname;	/* program name */
    int section;	/* section number */
    int num_option;	/* number of option */
    spOption *options;	/* option list */
    spBool option_allocated;
    int num_file;	/* number of file */
    char **labels;	/* file label */
    char **files;	/* file name */
    spBool *changes;
    int argc;
    int filec;
    int file_index;
    spBool ignore_unknown;
};

static spOptions sp_options = NULL;
static char *sp_setup_file = NULL;
static spBool *sp_help_flag;
static char sp_help_message[SP_MAX_LINE] = "";
static int sp_option_desc_offset = 32;

spBool spEqType(spOptionType type1, spOptionType type2)
{
    enum {SP_DUMMY1, SP_DUMMY2} dummy;
    
    if (!(0xff & type2)) {
	if ((0xff00 & type2) & (0xff00 & type1)) {
	    return SP_TRUE;
	}
    } else {
	if ((0xff & type1) == SP_TYPE_ENUM) {
	    if (sizeof(dummy) == sizeof(char)) {
		return ((0xff & type2) == SP_TYPE_CHAR ? SP_TRUE : SP_FALSE);
	    } else if (sizeof(dummy) == sizeof(short)) {
		return ((0xff & type2) == SP_TYPE_SHORT ? SP_TRUE : SP_FALSE);
	    } else if (sizeof(dummy) == sizeof(long)) {
		return ((0xff & type2) == SP_TYPE_LONG ? SP_TRUE : SP_FALSE);
	    } else {
		return ((0xff & type2) == SP_TYPE_INT ? SP_TRUE : SP_FALSE);
	    }
	} else if ((0xff & type1) == (0xff & type2)) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

void spIgnoreUnknownOption(spOptions options, spBool flag)
{
    if (options == NULL) return;
    
    options->ignore_unknown = flag;
    return;
}

int spGetNumOption(spOptions options)
{
    if (options == NULL) return -1;
    
    return options->num_option;
}

spOption *spGetOptionList(spOptions options)
{
    if (options == NULL) return NULL;
    
    return options->options;
}

/*
 *	cut option value
 */
char *xspCutOptionValue(char *value, int index)
{
    int i;
    char *p;
    char *string = NULL;
    char buf[SP_MAX_LINE];

    if (strnone(value)) return NULL;

    spStrCopy(buf, SP_MAX_LINE, value);
    
    p = buf;
    for (i = 0;; i++) {
	if (index < 0) {
	    if (*p == '@') {
		string = p + 1;
		break;
	    }
	} else {
	    if (i == index) {
		if (*p == '@') {
		    string = p + 1;
		} else {
		    string = p;
		}
		break;
	    }
	}
	if ((p = strchr(p, '|')) == NULL) {
	    break;
	}
	p++;
    }

    if (index < 0 && string == NULL) {
	string = buf;
    }
    
    if (string != NULL) {
	if ((p = strchr(string, '|')) != NULL) {
	    *p = NUL;
	}

	return strclone(string);
    } else {
	return NULL;
    }
}

/*
 *	convert option value
 */
static int convertOptionValue(spOption *option, char *value, int init_flag)
{
    int incr = SP_UNKNOWN;
    char *string;

    if (option == NULL) return SP_UNKNOWN;

    spDebug(40, "convertOptionValue", "in\n");
    
    if (value == NULL || *value == NUL) {
	if (option->value != NULL) {
	    if (spEqType(option->type, SP_TYPE_STRING)) {
		if (!init_flag) {
		    if (*(char **)option->value != NULL)
			xfree(*(char **)option->value);
		}
		*(char **)option->value = NULL;
	    } else if (spEqType(option->type,  SP_TYPE_STRING_A)) {
		strcpy((char *)option->value, "");
	    }
	}
    } else {
	if ((string = xspCutOptionValue(value, -1)) != NULL) {
	    if (option->value == NULL) {
		if (spEqType(option->type, SP_TYPE_BOOL)) {
		    incr = 0;
		} else {
		    incr = 1;
		}
	    } else if (string != NULL) {
		if (spEqType(option->type, SP_TYPE_INT)) {
		    *(int *)option->value = atoi(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_SHORT)) {
		    *(short *)option->value = (short)atoi(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_LONG)) {
		    *(long *)option->value = atol(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_FLOAT)) {
		    *(float *)option->value = (float)atof(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_DOUBLE)) {
		    *(double *)option->value = atof(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_CHAR)) {
		    *(char *)option->value = string[0];
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_STRING)) {
		    if (!init_flag) {
			if (*(char **)option->value != NULL) {
			    xfree(*(char **)option->value);
			}
		    }
		    *(char **)option->value = strclone(string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_STRING_A)) {
		    strcpy((char *)option->value, string);
		    incr = 1;
		} else if (spEqType(option->type, SP_TYPE_BOOL)) {
		    *(spBool *)option->value = spStrToBool(string);
		    incr = 0;
		} else {
		    spWarning("Unknown option data type.\n");
		    incr = SP_UNKNOWN;
		}
	    } else {
		incr = SP_UNKNOWN;
	    }
	    xfree(string);
	}
    }

    spDebug(40, "convertOptionValue", "done\n");
    
    return incr;
}

int spConvertOptionValue(spOption *option, char *value)
{
    return convertOptionValue(option, value, 0);
}

/*
 *	initialize option
 */
static void initOptions(spOptions options)
{
    int j;

    for (j = 0; j < options->num_option; j++) {
	convertOptionValue(&options->options[j], options->options[j].def_value, 1);
    }

    spDebug(40, "initOptions", "done\n");
    
    return;
}

/*
 *      get option number of being equal to flag
 */
static int flagEq(spOptions options, char *flag)
{
    int i;

    spDebug(40, "flagEq", "flag = %s\n", flag);
    
    for (i = 0;; i++) {
        if (i >= options->num_option) {
	    return SP_UNKNOWN;
        }
        if (streq(options->options[i].flag, flag) ||
	    streq(options->options[i].subflag, flag)) {
            break;
        } else if (options->options[i].type == SP_TYPE_BOOL && flag[0] == '+') {
	    if ((options->options[i].flag != NULL 
		 && streq(options->options[i].flag + 1, flag + 1)) ||
		(options->options[i].subflag != NULL 
		 && streq(options->options[i].subflag + 1, flag + 1))) {
		break;
	    }
        }
    }

    return i;
}

/*
 *	set change flag
 */
static void setChanges(int argc, char **argv, spOptions options)
{
    int i;
    int oc;

    if (options->changes == NULL) {
	options->changes = xalloc(MAX(options->num_option, 1), spBool);
    }
    
    for (i = 1; i < argc; i++) {
	if ((oc = flagEq(options, argv[i])) != SP_UNKNOWN) {
	    options->changes[oc] = SP_TRUE;
	}
    }

    return;
}

static spOptions allocOptions(int num_option, spOption *option_list, spBool copy_flag)
{
    spOptions options;
    
    options = xalloc(1, struct _spOptions);
    options->progname = NULL;
    options->section = 1;
    options->num_option = num_option;
    if (copy_flag == SP_TRUE) {
	int i;
	
	options->options = xalloc(num_option, spOption);
	for (i = 0; i < num_option; i++) {
	    memcpy(&options->options[i], &option_list[i], sizeof(spOption));
	}
	options->option_allocated = SP_TRUE;
    } else {
	options->options = option_list;
	options->option_allocated = SP_FALSE;
    }
    options->num_file = 0;
    options->labels = NULL;
    options->files = NULL;
    options->changes = NULL;
    options->argc = 1;
    options->filec = 0;
    options->file_index = 0;
    options->ignore_unknown = SP_FALSE;

    return options;
}

spOptions spAllocOptions(int num_option, spOption *option_list)
{
    return allocOptions(num_option, option_list, SP_FALSE);
}

spOptions spCopyOptions(int num_option, spOption *option_list)
{
    return allocOptions(num_option, option_list, SP_TRUE);
}

void _spFreeOptions(spOptions options)
{
    if (options != NULL) {
	if (options->option_allocated == SP_TRUE) {
	    xfree(options->options);
	}
	if (options->progname != NULL) {
	    xfree(options->progname);
	}
	if (options->files != NULL) {
	    xfree(options->files);
	}
	if (options->changes != NULL) {
	    xfree(options->changes);
	}
	xfree(options);
    }

    return;
}

/*
 *	get options struct
 */
spOptions _spGetOptions(int argc, char **argv, int num_option, spOption *option_list,
			int num_file, char **labels)
{
    int i;
    spOptions options;

    options = spAllocOptions(num_option, option_list);
    options->progname = xspGetBaseName(argv[0]);
    if (num_file == 1 && labels != NULL && strnone(labels[0])) {
	options->num_file = 0;
    } else {
	options->num_file = num_file;
    }
    options->labels = labels;
    if (argc > 0) {
	options->files = xalloc(argc, char *);
	for (i = 0; i < argc; i++) {
	    options->files[i] = NULL;
	}
    }

    initOptions(options);
    setChanges(argc, argv, options);
    
    if (sp_options == NULL) {
	sp_options = options;
    }

    if (!strnone(sp_setup_file)) {
	if (spIsExist(sp_setup_file) == SP_TRUE) {
	    spReadSetup(sp_setup_file, options);
	} else {
	    char *basename;

	    if ((basename = spGetBaseName(sp_setup_file)) != NULL) {
		char buf[SP_MAX_PATHNAME];
		
		sprintf(buf, "%s%c%s", spGetDefaultDir(), SP_DIR_SEPARATOR, basename);
		spReadSetup(buf, options);
	    }
	}
    }

    return options;
}

/*
 *	set section number 
 */
void spSetSection(spOptions options, int section)
{
    if (options != NULL) {
	options->section = section;
    }
    
    return;
}

void spSetSetup(char *filename)
{
    if (sp_setup_file != NULL) {
	xfree(sp_setup_file);
	sp_setup_file = NULL;
    }

    if (!strnone(filename)) {
	spDebug(10, "spSetSetup", "filename = %s\n", filename);
#if 0
	sp_setup_file = strclone(filename);
#else
	{
	    char *basename;

	    if (spIsExactName(filename) == SP_FALSE
		&& (basename = spGetBaseName(filename)) != NULL) {
		char *appdir;

		appdir = spGetApplicationDir(NULL);
	    
		sp_setup_file = xalloc(strlen(appdir) + strlen(basename) + 2, char);
		sprintf(sp_setup_file, "%s%c%s", appdir, SP_DIR_SEPARATOR, basename);
	    } else {
		sp_setup_file = strclone(filename);
	    }
	}
#endif
    }
    
    return;
}

void spWriteGlobalSetup(void)
{
    spWriteSetup(sp_setup_file, sp_options);
    return;
}

typedef struct _spExitCallbackList *spExitCallbackList;
struct _spExitCallbackList {
    int num_callback_buffer;
    int num_callback;
    spExitCallbackFunc *callbacks;
    void  **call_data_list;
};

static spExitCallbackList sp_exit_callback_list = NULL;

spBool spAddExitCallback(spExitCallbackFunc callback, void *data)
{
    int index;
    
    if (callback == NULL) return SP_FALSE;
    
    if (sp_exit_callback_list == NULL) {
	sp_exit_callback_list = xalloc(1, struct _spExitCallbackList);
	sp_exit_callback_list->num_callback_buffer = 0;
	sp_exit_callback_list->num_callback = 0;
	sp_exit_callback_list->callbacks = NULL;
	sp_exit_callback_list->call_data_list = NULL;
    }

    if (sp_exit_callback_list == NULL) return SP_FALSE;

#if 0
    for (index = 0; index < sp_exit_callback_list->num_callback; index++) {
	if (sp_exit_callback_list->callbacks[index] == NULL) {
	    break;
	}
    }
#else
    index = sp_exit_callback_list->num_callback;
#endif
    
    spDebug(10, "spAddExitCallback", "index = %d, num_callback = %d\n",
	    index, sp_exit_callback_list->num_callback);

    if (index >= sp_exit_callback_list->num_callback) {
	if (sp_exit_callback_list->num_callback + 1 >= sp_exit_callback_list->num_callback_buffer) {
	    sp_exit_callback_list->num_callback_buffer += SP_MAX_EXIT_CALLBACK;
	    sp_exit_callback_list->callbacks = xrealloc(sp_exit_callback_list->callbacks,
							sp_exit_callback_list->num_callback_buffer, spExitCallbackFunc);
	    sp_exit_callback_list->call_data_list = xrealloc(sp_exit_callback_list->call_data_list,
							     sp_exit_callback_list->num_callback_buffer, void *);
	}
	index = sp_exit_callback_list->num_callback;
	sp_exit_callback_list->num_callback++;
    }

    sp_exit_callback_list->callbacks[index] = callback;
    sp_exit_callback_list->call_data_list[index] = data;

    spDebug(10, "spAddExitCallback", "done: index = %d, num_callback = %d\n",
	    index, sp_exit_callback_list->num_callback);
    
    return SP_TRUE;
}

static spBool emitExitCallback(void)
{
    int i;
    spExitCallbackFunc callback;

    if (sp_exit_callback_list != NULL) {
	for (i = sp_exit_callback_list->num_callback - 1; i >= 0; i--) {
	    if ((callback = sp_exit_callback_list->callbacks[i]) != NULL) {
		callback(sp_exit_callback_list->call_data_list[i]);
	    }
	}
	if (sp_exit_callback_list->num_callback_buffer > 0) {
	    xfree(sp_exit_callback_list->callbacks);
	    xfree(sp_exit_callback_list->call_data_list);
	}
	xfree(sp_exit_callback_list);
	sp_exit_callback_list = NULL;
    }
    
    return SP_TRUE;
}

spBool spRemoveExitCallback(spExitCallbackFunc callback, void *data)
{
    int i;
    
    if (callback == NULL || sp_exit_callback_list == NULL) return SP_FALSE;
    
    for (i = 0; i < sp_exit_callback_list->num_callback; i++) {
	if (sp_exit_callback_list->callbacks[i] == callback
	    && sp_exit_callback_list->call_data_list[i] == data) {
	    sp_exit_callback_list->callbacks[i] = NULL;
	    sp_exit_callback_list->call_data_list[i] = NULL;
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

static spExitFunc sp_exit_func = NULL;

spBool spSetExitFunc(spExitFunc func)
{
    sp_exit_func = func;
    return SP_TRUE;
}

/*
 *	exit program
 */
void spExit(int status)
{
    emitExitCallback();

    if (status == 0) {
	spWriteGlobalSetup();
    }

    if (sp_exit_func != NULL) {
	sp_exit_func(status);
    } else {
	exit(status);
    }
}

/*
 *	set option value
 */
static int setOptionValue(spOption *option, char *flag, char *value)
{
    int incr;

    if (spEqType(option->type, SP_TYPE_BOOL)) {
	if (option->value != NULL) {
	    if (*(spBool *)option->value != SP_TRUE) {
		if (flag != NULL && flag[0] == '+') {
		    *(spBool *)option->value = SP_FALSE;
		} else {
		    *(spBool *)option->value = SP_TRUE;
		}
	    } else {
		if (flag != NULL && flag[0] == '+') {
		    *(spBool *)option->value = SP_TRUE;
		} else {
		    *(spBool *)option->value = SP_FALSE;
		}
	    }
	}
	incr = 0;
    } else {
	incr = spConvertOptionValue(option, value);
    }

    spDebug(40, "setOptionValue", "done\n");
    
    return incr;
}

/*
 *	get arg file
 */
static int getArgFile(spOptions options, char *filename, int *fc)
{
    int i;
    int stdin_flag = 0;
    int incr = 1;

    spDebug(40, "getArgFile", "in\n");
    
    if (streq(filename, "-")) {
	stdin_flag = 1;
    }
    
    if (!stdin_flag && strveq(filename, "-")) {
	if (options->ignore_unknown == SP_TRUE) {
	    return 0;
	} else {
	    spPrintError("Unknown option %s", filename);
	}
    }
    if (fc == NULL) {
	i = 0;
    } else {
	i = *fc;
	*fc += incr;
    }

    if (options->files != NULL) {
	if (options->files[i] != NULL)
	    xfree(options->files[i]);
	
	if (stdin_flag) {
	    options->files[i] = strclone(filename);
	} else {
	    options->files[i] = xspGetExactName(filename);
	}
	
	spDebug(10, "getArgFile", "options->files[%d] = %s\n", i,
		options->files[i]);
    }
    
    return incr;
}

/*
 *	get option value
 */
char *spGetOptionValue(int argc, char **argv, spOptions options)
{
    int i;
    int oc;
    int incr;

    if (argc <= 0 || argv == NULL || options == NULL) return NULL;

    i = options->argc;
    
    spDebug(40, "spGetOptionValue", "in: argc = %d, i = %d\n", argc, i);
    
    if (i >= argc)
	return NULL;

    if ((oc = flagEq(options, argv[i])) != SP_UNKNOWN) {
	if (i + 1 >= argc) {
	    incr = setOptionValue(&(options->options[oc]), argv[i], (char *)NULL);
	} else {
	    incr = setOptionValue(&(options->options[oc]), argv[i], argv[i + 1]);
	}
	if (incr == SP_UNKNOWN)
	    spUsage();
    } else {
	getArgFile(options, argv[i], &options->filec);
	incr = 0;
    }

    options->argc += incr + 1;
    
    if (!strnone(sp_help_message) && *sp_help_flag == SP_TRUE)
	spPrintHelp(sp_help_message);
    
    return argv[i];
}

void spGetOptionsValue(int argc, char **argv, spOptions options)
{
    if (options == NULL) return;
    
    while (spGetOptionValue(argc, argv, options) != NULL);
    
    spDebug(40, "spGetOptionsValue", "spGetOptionValue done\n");

#if 0
    if (options->filec < options->num_file - 1) {
	spPrintError("Not enough files.");
    }
#endif
    
    return;
}

void spUpdateOptionsValue(int argc, char **argv, spOptions options)
{
    int i;
    int oc;
    int incr;
    
    if (argc <= 0 || argv == NULL || options == NULL) {
	return;
    }

    i = 0;
    while (1) {
	if (i >= argc) {
	    break;
	}
	
	if ((oc = flagEq(options, argv[i])) != SP_UNKNOWN) {
	    if (i + 1 >= argc) {
		incr = setOptionValue(&(options->options[oc]), argv[i], (char *)NULL);
	    } else {
		incr = setOptionValue(&(options->options[oc]), argv[i], argv[i + 1]);
	    }
	    if (incr == SP_UNKNOWN) {
		incr = 0;
	    }
	} else {
	    incr = 0;
	}
	i += incr + 1;
    }

    return;
}

/*
 *	check number of file
 */
void spCheckNumFile(spOptions options)
{
    if (options == NULL) return;
    
    if (options->filec < options->num_file) {
	spPrintError("Not enough files.");
    } else if (options->filec > options->num_file) {
	spPrintError("Too many files.");
    }
}

/*
 *	get filename from command line
 */
char *spGetFile(spOptions options)
{
    char *file = NULL;

    if (options == NULL) return NULL;
    
    spDebug(10, "spGetFile", "options->file_index = %d, options->num_file = %d\n",
	    options->file_index, options->num_file);
    
    if (options->files != NULL
	&& options->files[options->file_index] != NULL) {
	file = options->files[options->file_index];
	options->file_index++;
    }

    return file;
}

char *xspGetOptionLabel(spOption *option, int index)
{
    int i;
    char *p;
    char *label = NULL;
    char buf[SP_MAX_LINE];

    if (option == NULL || index < 0 || strnone(option->label)) {
	return NULL;
    }

    spStrCopy(buf, SP_MAX_LINE, option->label);

    p = buf;
    for (i = 0;; i++) {
	if (i == index) {
	    label = p;
	    break;
	}
	if ((p = strchr(p, '|')) == NULL) {
	    if (i == 0 && index == 1) {
		return strclone(buf);
	    } else {
		return NULL;
	    }
	}
	p++;
    }

    if (label != NULL) {
	if ((p = strchr(label, '|')) != NULL) {
	    *p = NUL;
	}
	spDebug(50, "xspGetOptionLabel", "label = %s\n", label);
	
	return strclone(label);
    } else {
	return NULL;
    }
}

void spSetOptionDescOffset(int offset)
{
    sp_option_desc_offset = offset;
    return;
}

void spSetHelpMessage(spBool *flag, char *format, ...)
{
    va_list args;
    
    sp_help_flag = flag;
    va_start(args, format);
    vsprintf(sp_help_message, format, args);
    va_end(args);

    return;
}

char *spGetHelpMessage(void)
{
    return sp_help_message;
}

static void printHelpHeader(spOptions options, char *message)
{
    char buf[SP_MAX_LINE];
    
    if (options != NULL) {
	if (options->progname != NULL) {
	    sprintf(buf, "%s (%d)", options->progname, options->section);
	}
	fprintf(stdout, "%-24s- %s\n", buf, message);
    } else {
	fprintf(stdout, "%s\n", message);
    }

    return;
}

void spPrintHelpHeader(char *format, ...)
{
    va_list args;
    char message[SP_MAX_LINE];

    va_start(args, format);
    vsprintf(message, format, args);
    va_end(args);

    printHelpHeader(sp_options, message);
    
    return;
}

/*
 *	print help
 */
void spPrintHelp(char *format, ...)
{
    va_list args;
    char message[SP_MAX_LINE];

    va_start(args, format);
    vsprintf(message, format, args);
    va_end(args);

    printHelpHeader(sp_options, message);
    spUsage();
}

/*
 *	print error
 */
void spPrintError(char *format, ...)
{
    va_list args;
    char message[SP_MAX_LINE];

    va_start(args, format);
    vsprintf(message, format, args);
    va_end(args);

    if (sp_options != NULL) {
	if (sp_options->progname != NULL) {
	    spMessage("%s: %s\n", sp_options->progname, message);
	}
	spUsage();
    } else {
	spMessage("%s\n", message);
    }
}

/*
 *	get option number of being equal to label
 */
static int labelEq(spOptions options, char *label)
{
    int i;
    char *string;

    for (i = 0;; i++) {
	if (i >= options->num_option) {
	    i = SP_UNKNOWN;
	    break;
	}
	if ((string = xspGetOptionLabel(&options->options[i], 0)) != NULL) {
	    if (streq(string, label)) {
		xfree(string);
		break;
	    }
	    xfree(string);
	}
    }

    return i;
}

/*
 *	read setup file
 */
void spReadSetup(char *filename, spOptions options)
{
    int j;
    char *exactname;
    char name[SP_MAX_SETUP_NAME];
    char value[SP_MAX_SETUP_VALUE];
    char line[SP_MAX_SETUP_LINE];
    FILE *fp;

    if (strnone(filename) || options == NULL)
	return;

    exactname = xspGetExactName(filename);

    if (NULL == (fp = fopen(exactname, "r"))) {
	return;
    }

    while (fgetnline(line, SP_MAX_SETUP_LINE, fp) != EOF) {
	sscansetup(line, name, value);
	if (!strnone(value) && (j = labelEq(options, name)) >= 0) {
	    if (options->changes[j] != SP_TRUE) {
		spConvertOptionValue(&options->options[j], value);
	    }
	}
	strcpy(name, "");
	strcpy(value, "");
    }
    fclose(fp);

    xfree(exactname);

    return;
}

/*
 *	write setup file
 */
void spWriteSetup(char *filename, spOptions options)
{
    int i;
    char *label;
    char *string;
    char *exactname;
    FILE *fp;

    if (strnone(filename) || options == NULL)
	return;

    exactname = xspGetExactName(filename);
    
    spDebug(40, "spWriteSetup", "exactname = %s\n", exactname);

    if (NULL == (fp = fopen(exactname, "w"))) {
	spMessage("Can't open setup file: %s\n", exactname);
	return;
    }
    
    for (i = 0; i < options->num_option; i++) {
	if ((label = xspGetOptionLabel(&options->options[i], 0)) == NULL)
	    continue;
	
	fprintf(fp, "%s ", label);
	xfree(label);
	
        if (spEqType(options->options[i].type, SP_TYPE_BOOL)) {
	    fprintf(fp, "%s", spBoolToStr(*(spBool *)options->options[i].value));
	} else if (spEqType(options->options[i].type, SP_TYPE_INT)) {
	    fprintf(fp, "%d", *(int *)options->options[i].value);
	} else if (spEqType(options->options[i].type, SP_TYPE_SHORT)) {
	    fprintf(fp, "%d", *(short *)options->options[i].value);
	} else if (spEqType(options->options[i].type, SP_TYPE_LONG)) {
	    fprintf(fp, "%ld", *(long *)options->options[i].value);
	} else if (spEqType(options->options[i].type, SP_TYPE_FLOAT)) {
	    fprintf(fp, "%f", *(float *)options->options[i].value);
	} else if (spEqType(options->options[i].type, SP_TYPE_DOUBLE)) {
	    fprintf(fp, "%f", *(double *)options->options[i].value);
	} else if (spEqType(options->options[i].type, SP_TYPE_CHAR)) {
	    fprintf(fp, "%c", *(char *)options->options[i].value);
	} else if (spEqType(options->options[i].type,  SP_TYPE_STRING)
		   || spEqType(options->options[i].type,  SP_TYPE_STRING_A)) {
	    if (spEqType(options->options[i].type,  SP_TYPE_STRING)) {
		string = *(char **)options->options[i].value;
	    } else {
		string = (char *)options->options[i].value;
	    }
	    if (strnone(string)) {
		fprintf(fp, "  ");
	    } else {
		fputline(string, fp);
	    }
	}
	fprintf(fp, "\n");
    }
    fclose(fp);

    xfree(exactname);

    spDebug(40, "spWriteSetup", "done\n");
    
    return;
}

static spBool printOption(spOption *option, int desc_offset)
{
    char *p;
    char format[SP_MAX_MESSAGE];
    char buf[SP_MAX_PATHNAME];
    char flag[SP_MAX_LINE];
    char label[SP_MAX_LINE];
    
    if (option == NULL || strnone(option->flag) || strnone(option->desc))
	return SP_FALSE;
    
    if ((p = xspGetOptionLabel(option, 0)) != NULL) {
	spStrCopy(label, SP_MAX_LINE, p);
	xfree(p);
    } else {
	spStrCopy(label, SP_MAX_LINE, SP_USAGE_LABEL_STRING);
    }
    
    if (!strnone(option->subflag)) {
	sprintf(flag, "%s %s", option->flag, option->subflag);
    } else {
	sprintf(flag, "%s", option->flag);
    }

    sprintf(format, "    %%-%ds: %%s\n", desc_offset);
    
    if (spEqType(option->type, SP_TYPE_BOOL)) {
	if (!strnone(option->label)) {
	    if (option->value != NULL) {
		if (*(spBool *)option->value == SP_FALSE) {
		    sprintf(buf, "%s  (%s[False])", flag, label);
		} else {
		    sprintf(buf, "%s  (%s[True])", flag, label);
		}
	    } else {
		sprintf(buf, "%s  (%s)", flag, label);
	    }
	    fprintf(stdout, format, buf, option->desc);
	} else {
	    fprintf(stdout, format, flag, option->desc);
	}
    } else if (option->value != NULL && /*!strnone(option->def_value)*/option->def_value != NULL) {
	if (spEqType(option->type, SP_TYPE_INT)) {
	    sprintf(buf, "%s %s[%d]", flag, label,
		    *(int *)option->value);
	} else if (spEqType(option->type, SP_TYPE_SHORT)) {
	    sprintf(buf, "%s %s[%d]", flag, label,
		    *(short *)option->value);
	} else if (spEqType(option->type, SP_TYPE_LONG)) {
	    sprintf(buf, "%s %s[%ld]", flag, label,
		    *(long *)option->value);
	} else if (spEqType(option->type, SP_TYPE_FLOAT) ||
		   spEqType(option->type, SP_TYPE_DOUBLE)) {
	    int j;
	    char value[SP_MAX_LINE];
	    
	    if (spEqType(option->type, SP_TYPE_FLOAT)) {
		sprintf(value, "%f", *(float *)option->value);
	    } else {
		sprintf(value, "%f", *(double *)option->value);
	    }
	    for (j = strlen(value) - 1; j >= 0; j--) {
		if (value[j] == '.') {
		    value[MIN(j + 2, (int)strlen(value))] = NUL;
		    break;
		} else if (value[j] != '0') {
		    value[j + 1] = NUL;
		    break;
		}
	    }
	    sprintf(buf, "%s %s[%s]", flag, label,
		    value);
	} else if (spEqType(option->type, SP_TYPE_CHAR)) {
	    sprintf(buf, "%s %s[%c]", flag, label,
		    *(char *)option->value);
	} else if (spEqType(option->type, SP_TYPE_STRING)) {
	    if (strnone(*(char **)option->value)) {
		sprintf(buf, "%s %s", flag, label);
	    } else {
		sprintf(buf, "%s %s[%s]", flag, label,
			*(char **)option->value);
	    }
	} else if (spEqType(option->type, SP_TYPE_STRING_A)) {
	    if (strnone((char *)option->value)) {
		sprintf(buf, "%s %s", flag, label);
	    } else {
		sprintf(buf, "%s %s[%s]", flag, label,
			(char *)option->value);
	    }
	} else {
	    spWarning("Unknown option data type.\n");
	    return SP_FALSE;
	}
	
	fprintf(stdout, format, buf, option->desc);
    } else {
	sprintf(buf, "%s %s", flag, label);
	fprintf(stdout, format, buf, option->desc);
    }

    return SP_TRUE;
}

spBool spPrintOption(spOption *option)
{
    return printOption(option, sp_option_desc_offset);
}

spBool spPrintOptions(spOptions options)
{
    int i;
    
    if (options == NULL) return SP_FALSE;
    
    for (i = 0; i < options->num_option; i++) {
	spPrintOption(&options->options[i]);
    }

    return SP_TRUE;
}

void spPrintUsageHeader(void)
{
    int i;
    spOptions options = sp_options;
    char buf[SP_MAX_PATHNAME];
    char filename[SP_MAX_LINE];

    if (options == NULL) return;
    
    strcpy(buf, "");
    strcpy(filename, "");
    
    for (i = 0; i < options->num_file; i++) {
	sprintf(filename, " %s", options->labels[i]);
	strcat(buf, filename);
    }

    if (options->num_option <= 0) {
	if (options->progname != NULL) {
	    fprintf(stdout, "usage: %s%s\n", options->progname, buf);
	}
    } else {
	if (options->progname != NULL) {
	    fprintf(stdout, "usage: %s [options...]%s\n", options->progname, buf);
	    fprintf(stdout, "options:\n");
	}
    }

    return;
}

void spPrintUsage(void)
{
    if (sp_options != NULL) {
	spPrintOptions(sp_options);
	fprintf(stdout, "\n");
    }
    spExit(1);

    return;
}

void spUsage(void)
{
    spPrintUsageHeader();
    spPrintUsage();
    
    return;
}
