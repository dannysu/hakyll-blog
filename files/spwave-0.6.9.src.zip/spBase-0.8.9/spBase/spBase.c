/*
 *	spBase.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spOption.h>

#if defined(_WIN32)
#include <windows.h>
#endif

#if !defined(MACOS)
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#if defined(_WIN32) && !defined(__CYGWIN32__)
#include <io.h>
#include <direct.h>
#include <process.h>
#include <shlobj.h>
#else
#include <unistd.h>
#include <pwd.h>
#endif
#else
#if defined(MACOSX)
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <CoreServices/CoreServices.h>
#include <Carbon/Carbon.h>
#else
#include <MacTypes.h>
#include <Files.h>
#include <Processes.h>
#include <Sound.h>
#include <fcntl.h>
#include <Script.h>
#include <TextEncodingConverter.h>
#endif
#endif

#if defined(_WIN32) && !defined(__CYGWIN32__)
#include <windows.h>
#include <mbctype.h>
#include <mbstring.h>

#define strchr(string, c) ((char *)_mbschr(((unsigned char *)string), (unsigned int)c))
#define strrchr(string, c) ((char *)_mbsrchr(((unsigned char *)string), (unsigned int)c))
#endif

#ifdef NO_WARNING
static int sp_warn_flag = 0;
#else
static int sp_warn_flag = 1;
#endif

static int sp_message_flag = 1;
static int sp_debug_level = -1;
static int sp_debug_stdout = 0;

static spPrintFunc sp_print_func = NULL;

#if defined(MACOS9)
#define SP_STDERR stdout
#else
#define SP_STDERR stderr
#endif

void spSetPrintFunc(spPrintFunc func)
{
    sp_print_func = func;
    return;
}

void spPrint(char *message, FILE *fp)
{
    if (message == NULL) return;
    
    if (sp_print_func != NULL) {
	sp_print_func(message);
    } else {
	if (fp != NULL) {
	    fputs(message, fp);
	} else {
	    fputs(message, SP_STDERR);
	}
    }

    return;
}

void spSetWarningFlag(int flag)
{
    if (flag == 0) sp_warn_flag = 0;
    else sp_warn_flag = 1;
    return;
}

void spWarning(char *format, ...)
{
    va_list args;
    char buf[SP_MAX_MESSAGE];

    if (!sp_warn_flag) return;
    
    va_start (args, format);
    vsprintf(buf, format, args);
    va_end (args);

    spPrint(buf, SP_STDERR);

    return;
}

void spSetMessageFlag(int flag)
{
    if (flag == 0) sp_message_flag = 0;
    else sp_message_flag = 1;
    return;
}

void spMessage(char *format, ...)
{
    va_list args;
    char buf[SP_MAX_MESSAGE];

    if (!sp_message_flag) return;
    
    va_start (args, format);
    vsprintf(buf, format, args);
    va_end (args);

    spPrint(buf, SP_STDERR);

    return;
}

void spError(int status, char *format, ...)
{
    va_list args;
    char buf[SP_MAX_MESSAGE];

    va_start (args, format);
    vsprintf(buf, format, args);
    va_end (args);

    spPrint(buf, SP_STDERR);

#if defined(MACOS)
    SysBeep(30);
    spMSleep(500);
#endif
    spExit(status);
    
    return;
}

void spProgError(char *func_name, char *format, ...)
{
    va_list args;
    char buf[SP_MAX_MESSAGE];
    char buf2[SP_MAX_MESSAGE];

    va_start (args, format);
    vsprintf(buf, format, args);
    va_end (args);

    if (!strnone(func_name)) {
	sprintf(buf2, "%s: %s", func_name, buf);
	spPrint(buf2, SP_STDERR);
    } else {
	spPrint(buf, SP_STDERR);
    }

#if defined(MACOS)
    SysBeep(30);
    spMSleep(500);
#endif
    spExit(1);
    
    return;
}

void spSetDebugStdout(int flag)
{
    if (flag == 0) sp_debug_stdout = 0;
    else sp_debug_stdout = 1;
    return;
}

void spSetDebugLevel(int level)
{
    sp_debug_level = level;
    return;
}

int spGetDebugLevel(void)
{
    return sp_debug_level;
}

void spDebug(int level, char *func_name, char *format, ...)
{
    va_list args;
    char buf[SP_MAX_MESSAGE];
    char buf2[SP_MAX_MESSAGE];

    if (sp_debug_level < level) return;
    
    va_start (args, format);
    vsprintf(buf, format, args);
    va_end (args);

    if (!strnone(func_name)) {
	sprintf(buf2, "%s: %s", func_name, buf);
	if (sp_debug_stdout) {
	    spPrint(buf2, stdout);
	} else {
	    spPrint(buf2, SP_STDERR);
	}
    } else {
	if (sp_debug_stdout) {
	    spPrint(buf, stdout);
	} else {
	    spPrint(buf, SP_STDERR);
	}
    }

    return;
}

void spSleep(int sec)
{
#if defined(_WIN32) && !defined(__CYGWIN32__)
    SleepEx((DWORD)sec * (DWORD)1000, FALSE);
#elif defined(MACOS9)
    {
	unsigned long ticks;
	Delay(60 * (unsigned long)sec, &ticks);
    }
#else
    sleep(sec);
#endif
    return;
}

void spMSleep(int msec)
{
#if defined(_WIN32) && !defined(__CYGWIN32__)
    Sleep((DWORD)msec);
#elif defined(MACOS9)
    {
	unsigned long ticks;
	unsigned long dtime;
	dtime = (unsigned long)spRound(60.0 * (double)msec / 1000.0);
	Delay(dtime, &ticks);
    }
#else
    usleep(msec * 1000);
#endif
    return;
}

int spStrCaseCmp(char *s1, char *s2)
{
    int c1, c2;
    
    while (*s1 != NUL && *s2 != NUL) {
	c1 = isupper((unsigned char)*s1) ? tolower((unsigned char)*s1) : *s1;
	c2 = isupper((unsigned char)*s2) ? tolower((unsigned char)*s2) : *s2;
	if (c1 != c2) {
	    return (c1 - c2);
	}
	s1++;
	s2++;
    }
    
    return (((int)(unsigned char)*s1) - ((int)(unsigned char)*s2));
}

int spStrNCaseCmp(char *s1, char *s2, int n)
{
    int i;
    int c1, c2;
    
    for (i = 1; *s1 != NUL && *s2 != NUL; i++) {
	c1 = isupper((unsigned char)*s1) ? tolower((unsigned char)*s1) : *s1;
	c2 = isupper((unsigned char)*s2) ? tolower((unsigned char)*s2) : *s2;
	if (c1 != c2 || i >= n) {
	    return (c1 - c2);
	}
	s1++;
	s2++;
    }
    
    return (((int)(unsigned char)*s1) - ((int)(unsigned char)*s2));
}

int spStrWhite(char *string)
{
    int i;

    if (strnone(string)) return 0;
    
    for (i = strlen(string) - 1; i >= 0; i--) {
	if (!(string[i] == ' ' || string[i] == '\t')) {
	    return 0;
	}
    }

    return 1;
}

char *xspStrCat(char *dest, char *src)
{
    char *result;

    result = xalloc(strlen(dest) + strlen(src) + 1, char);
    strcpy(result, dest);
    strcat(result, src);
    
    return result;
}

char *spStrCat(char *dest, int destsize, char *src)
{
    int n;
    char *result;
    
    if (dest == NULL) return NULL;

    if (strnone(src)) {
	result = dest;
    } else {
	n = destsize - strlen(dest) - 1;
	if (strlen(src) < n) {
	    result = strcat(dest, src);
	} else {
	    result = strncat(dest, src, n);
	    dest[destsize - 1] = NUL;
	}
    }
    
    return result;
}

char *spStrCopy(char *dest, int destsize, char *src)
{
    if (dest == NULL || destsize <= 0) return NULL;

    if (strnone(src) || destsize <= 1) {
	strcpy(dest, "");
    } else {
	if (strlen(src) < destsize) {
	    strcpy(dest, src);
	} else {
	    destsize--;
	    strncpy(dest, src, destsize);
	    dest[destsize] = NUL;
	}
    }
    
    return dest;
}

char *spGetSuffix(char *name)
{
    char *p1, *p2;
    
    if ((p1 = spGetBaseName(name)) == NULL || (p2 = strrchr(p1, '.')) == NULL) {
	return NULL;
    }

    return p2;
}

int spEqSuffix(char *file1, char *file2)
{
    char *name;
    char *p1, *p2;

    if (file1 == NULL || file2 == NULL) return 0;
    
    if ((name = spGetBaseName(file1)) == NULL || (p1 = strrchr(name, '.')) == NULL) {
	return 0;
    } else {
	p1++;
    }
    if ((name = spGetBaseName(file2)) == NULL || (p2 = strrchr(name, '.')) == NULL) {
	return 0;
    } else {
	p2++;
    }

    return strcaseeq(p1, p2);
}

spBool spRemoveSuffix(char *path, char *suffix)
{
    char *name;
    char *p;
    
    if (path == NULL) return SP_FALSE;

    if ((name = spGetBaseName(path)) != NULL
	&& (p = strrchr(name, '.')) != NULL) {
	if (suffix != NULL) {
	    strcpy(suffix, p);
	}
	*p = NUL;
    } else {
	if (suffix != NULL) {
	    strcpy(suffix, "");
	}
    }

    return SP_TRUE;
}

spBool spReplaceSuffix(char *path, char *suffix)
{
    int len = 0;

    if (strnone(path)) return SP_FALSE;

    if (!strnone(suffix)) {
	len = strlen(suffix);
	
	if (len > 0 && suffix[len-1] != '*') {
	    char *p;
	
	    spRemoveSuffix(path, NULL);

	    p = suffix;
	    if (p[0] == '*') {
		p++;
	    }
	    spStrCat(path, SP_MAX_PATHNAME, p);
	}
    } else {
	spRemoveSuffix(path, NULL);
    }

    return SP_TRUE;
}

/* for Mac string conversion */
void spStrPToC(unsigned char *in_p, char *out_c)
{
    unsigned char len;

    if (in_p == NULL || out_c == NULL) return;
    
    len = *in_p;
    
    if (len > 0) {
	memmove(out_c, in_p + 1, len);
    }
    *(out_c + len) = '\0';

    return;
}

void spStrCToP(char *in_c, unsigned char *out_p)
{
    int len;
    
    if (in_c == NULL || out_p == NULL) return;
    
    len = strlen(in_c);
    len = MIN(len, 255);
    
    *out_p = (unsigned char)len;
    
    if (len > 0) {
	memmove(out_p + 1, in_c, len);
    }
    
    return;
}

void spCopyPStr(unsigned char *source, unsigned char *dest)
{
    unsigned char len;

    if (source == NULL || dest == NULL) return;
	
    len = source[0];
    if (len > 0) {
	memmove(dest + 1, source + 1, len);
    }
    dest[0] = len;

    return;
}

void spCatPStr(unsigned char *target, unsigned char *source)
{
    unsigned char len;
    
    if (target == NULL || source == NULL) return;
    
    len = MIN(source[0], 255 - target[0]);
    
    if (len > 0) {
	memmove(target + target[0] + 1, source + 1, len);
	target[0] += len;
    }

    return;
}

#if defined(MACOS)
spBool spGetApplicationFInfoMac(FInfo *finfo)
{
    spBool flag = SP_FALSE;
    
    if (finfo == NULL) return SP_FALSE;

#if defined(MACOSX)
    {
        CFBundleRef mainBundle;
	
	if ((mainBundle = CFBundleGetMainBundle()) != NULL) {
	    finfo->fdFlags = 0;
	    finfo->fdFldr = 0;
	    CFBundleGetPackageInfo(mainBundle, (UInt32 *)&finfo->fdType, (UInt32 *)&finfo->fdCreator);

	    flag = SP_TRUE;
	}
    }
#endif
    
    if (flag == SP_FALSE) {
	Str255 ppath;
	FSSpec fsspec_process;
	ProcessSerialNumber psn;
	ProcessInfoRec pir;
	
	psn.highLongOfPSN = 0;
	psn.lowLongOfPSN = kCurrentProcess;
	pir.processInfoLength = sizeof(pir);
	pir.processName = ppath;
	pir.processAppSpec = &fsspec_process;
	
	if (GetProcessInformation(&psn, &pir) == noErr) {
	    if (FSpGetFInfo(&fsspec_process, finfo) == noErr) {
		flag = SP_TRUE;
	    }
	}
    }

    return flag;
}

spBool spPathToFSSpecMac(char *filename, FSSpec *fsspec)
{
    if (strnone(filename)) return SP_FALSE;

#if defined(MACOSX)
    {
	FSRef fsref;
	Boolean is_dir;

	if (FSPathMakeRef(filename, &fsref, &is_dir) != noErr
	    || FSGetCatalogInfo(&fsref, kFSCatInfoNone, NULL, NULL, fsspec, NULL) != noErr) {
	    return SP_FALSE;
	}
    }
#else
    {
	Str255 ppath;

	spStrCToP(filename, ppath);
	if (FSMakeFSSpec(0, 0L, ppath, fsspec) != noErr) {
	    return SP_FALSE;
	}
    }
#endif
    return SP_TRUE;
}
#endif

spBool spGetMacFileInfo(char *filename, unsigned long *creator, unsigned long *file_type)
{
#if defined(MACOS)
    FSSpec fsspec;
    FInfo finfo;

    if (filename == NULL) {
	if (spGetApplicationFInfoMac(&finfo) == SP_FALSE) {
	    return SP_FALSE;
	}
    } else {
	if (spPathToFSSpecMac(filename, &fsspec) == SP_FALSE) {
	    return SP_FALSE;
	}
	if (FSpGetFInfo(&fsspec, &finfo) != noErr) {
	    return SP_FALSE;
	}
    }
    if (creator != NULL) {
	*creator = (unsigned long)finfo.fdCreator;
    }
    if (file_type != NULL) {
	*file_type = (unsigned long)finfo.fdType;
    }
    
    return SP_TRUE;
#else
    return SP_FALSE;
#endif
}

spBool spSetMacFileInfo(char *filename, unsigned long creator, unsigned long file_type)
{
#if defined(MACOS)
    FSSpec fsspec;
    FInfo finfo;
    static unsigned long application_creator = 0;

    if (spPathToFSSpecMac(filename, &fsspec) == SP_FALSE) {
	return SP_FALSE;
    }
    if (FSpGetFInfo(&fsspec, &finfo) != noErr) {
	return SP_FALSE;
    }

    if (creator == 0) {
	if (application_creator == 0) {
	    FInfo finfo_process;
	    
	    if (spGetApplicationFInfoMac(&finfo_process) == SP_TRUE) {
		application_creator = finfo_process.fdCreator;
	    }
	}
	creator = application_creator;
    }
    
    finfo.fdCreator = (OSType)creator;
#if 0
    spDebug(10, "spSetMacFileInfo", "creator: %c%c%c%c\n",
	    (char)(finfo.fdCreator>>24),
	    (char)(finfo.fdCreator>>16),
	    (char)(finfo.fdCreator>>8),
	    (char)(finfo.fdCreator));
#endif
    
    if (file_type != 0) {
	finfo.fdType = (OSType)file_type;
    }
#if 0
    spDebug(10, "spSetMacFileInfo", "file type: %c%c%c%c\n",
	    (char)(finfo.fdType>>24),
	    (char)(finfo.fdType>>16),
	    (char)(finfo.fdType>>8),
	    (char)(finfo.fdType));
#endif
    
    if (FSpSetFInfo(&fsspec, &finfo) != noErr) {
	return SP_FALSE;
    }

    return SP_TRUE;
#else
    return SP_FALSE;
#endif
}

FILE *spOpenFile(char *path, char *mode)
{
    FILE *fp;
    char *basename;

    if (strnone(path) || strnone(mode)) return NULL;

    basename = spGetBaseName(path);

    if ((mode[0] == 'r' && streq(basename, "-"))
	|| streq(basename, "stdin")) {
	fp = stdin;
    } else if ((mode[0] == 'w' && streq(basename, "-"))
	       || streq(basename, "stdout")) {
	fp = stdout;
    } else {
	/* open file */
	if (NULL == (fp = fopen(path, mode))) {
	    spWarning("Can't open file: %s\n", path);
	    return NULL;
	}
    }

    return fp;
}

int spCloseFile(FILE *stream)
{
    if (stream == stdin || stream == stdout) return 0;
    
    return fclose(stream);
}

spBool spAddDirSeparator(char *dir)
{
    int i;
    
    if (dir == NULL) return SP_FALSE;

    i = strlen(dir) - 1;
    
    if ((i >= 1 && spIsMBTailCandidate(dir[i-1], dir[i]))
	|| (dir[i] != SP_DIR_SEPARATOR && dir[i] != SP_ANOTHER_DIR_SEPARATOR)) {
	dir[i + 1] = SP_DIR_SEPARATOR;
	dir[i + 2] = NUL;
    }

    return SP_TRUE;
}

spBool spRemoveDirSeparator(char *dir)
{
    int i;
    
    if (dir == NULL) return SP_FALSE;

    i = strlen(dir) - 1;
    
    if ((dir[i] == SP_DIR_SEPARATOR
	 || dir[i] == SP_ANOTHER_DIR_SEPARATOR)
	&& !(i >= 1 && spIsMBTailCandidate(dir[i-1], dir[i]))
	) {
	dir[i] = NUL;
    }

    return SP_TRUE;
}

#if !defined(MACOS9)
#ifndef S_ISDIR
#define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)
#endif

static spBool getFileInfo(char *path, spBool *dir_flag, long *size)
{
#if defined(_WIN32) && !defined(__CYGWIN32__)
    struct _stat status;
#define stat(path,buf) _stat(path,buf)
#else
    struct stat status;
#endif
    
    if (strnone(path)) return SP_FALSE;

    if (stat(path, &status) == 0) {
	spDebug(50, "spGetFileInfo", "stat done\n");
	if (dir_flag != NULL) {
	    if (S_ISDIR(status.st_mode)) {
#if defined(MACOSX)
		if (spEqSuffix(path, "*.app")
		    || spEqSuffix(path, "*.bundle")
		    || spEqSuffix(path, "*.pbproj")
		    || spEqSuffix(path, "*.plugin")) {
		    /* a bundle of Mac OS X */
		    *dir_flag = SP_FALSE;
		    spDebug(50, "spGetFileInfo", "bundle: %s\n", path);
		} else {
		    *dir_flag = SP_TRUE;
		}
#else
		*dir_flag = SP_TRUE;
#endif
	    } else {
		*dir_flag = SP_FALSE;
	    }
	}
	if (size != NULL) {
	    *size = status.st_size;
	}
	
	return SP_TRUE;
    }
    spDebug(50, "spGetFileInfo", "stat failed\n");

    return SP_FALSE;
}
#endif

#if defined(MACOS9)
spBool spGetFileInfo(char *path, spBool *dir_flag, long *size)
{
    Str255 ppath;
    Str255 pname;
    HFileInfo file_info;
    HVolumeParam vol_param;

    spStrCToP(path, ppath);

    file_info.ioNamePtr = ppath;
    file_info.ioFDirIndex = 0;
    file_info.ioVRefNum = 0;
    file_info.ioDirID = 0L;

    if (PBGetCatInfoSync((CInfoPBPtr)&file_info) == noErr) {
	spDebug(50, "spGetFileInfo", "PBGetCatInfoSync done\n");
	vol_param.ioVolIndex = 0;
	vol_param.ioNamePtr = pname;
	vol_param.ioVRefNum = 0;
	
	if (PBHGetVInfoSync((HParmBlkPtr)&vol_param) == noErr) {
	    spDebug(50, "spGetFileInfo", "PBHGetVInfoSync done\n");
	    if (dir_flag != NULL) {
		if (file_info.ioFlAttrib & kioFlAttribDirMask) {
		    *dir_flag = SP_TRUE;
		} else {
		    *dir_flag = SP_FALSE;
		}
	    }
	    if (size != NULL) {
		*size = file_info.ioFlLgLen;
	    }
	    
	    return SP_TRUE;
	}
    }
    spDebug(50, "spGetFileInfo", "failed\n");
#if !defined(MACOS9)
    return getFileInfo(path, dir_flag, size);
#else
    return SP_FALSE;
#endif
}
#else
spBool spGetFileInfo(char *path, spBool *dir_flag, long *size)
{
    return getFileInfo(path, dir_flag, size);
}
#endif

spBool spIsExist(char *path)
{
    return spGetFileInfo(path, NULL, NULL);
}

spBool spIsFile(char *path)
{
    spBool dir_flag = SP_FALSE;
    
    if (spGetFileInfo(path, &dir_flag, NULL) == SP_TRUE
	&& dir_flag == SP_FALSE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spIsDir(char *path)
{
    spBool dir_flag = SP_FALSE;
    
    if (spGetFileInfo(path, &dir_flag, NULL) == SP_TRUE
	&& dir_flag == SP_TRUE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spCreateDir(char *path, unsigned short mode)
{
    if (strnone(path)) return SP_FALSE;

#if defined(MACOS9)
    {
	Str255 ppath;
	HFileParam file_param;

	spStrCToP(path, ppath);

	file_param.ioNamePtr = ppath;
	file_param.ioVRefNum = 0;
	file_param.ioDirID = 0L;
	
	if (PBDirCreateSync((HParmBlkPtr)&file_param) != noErr) {
	    return SP_FALSE;
	}
    }
#else
#if defined(_WIN32) && !defined(__CYGWIN32__)
    /*mkdir(path);*/
    CreateDirectory(path, NULL);
#else
    mkdir(path, mode);
#endif
#endif

    if (spIsDir(path) == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spRemoveDir(char *path)
{
    if (strnone(path)) return SP_FALSE;
    
#if defined(_WIN32) && !defined(__CYGWIN32__)
    if (RemoveDirectory(path)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
#else
    if (rmdir(path) == 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
#endif
}

spBool spRemoveFile(char *path)
{
    if (strnone(path)) return SP_FALSE;

    if (unlink(path) == 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spRenameFile(char *oldpath, char *newpath)
{
    if (strnone(oldpath) || strnone(newpath)) return SP_FALSE;
    
    if (rename(oldpath, newpath) == 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

/*
 *	get base name
 */
char *spGetBaseName(char *name)
{
    char *p, *q;
    
    if (name == NULL || *name == NUL)
	return NULL;

#if 0
    if ((p = strrchr(name, SP_DIR_SEPARATOR)) == NULL
	&& (p = strrchr(name, SP_ANOTHER_DIR_SEPARATOR)) == NULL) {
	return name;
    } else if ((p - name) >= strlen(name) - 1) {
	return NULL;
    }
#else
    p = strrchr(name, SP_DIR_SEPARATOR);
    q = strrchr(name, SP_ANOTHER_DIR_SEPARATOR);
    if (p == NULL && q == NULL) {
        return name;
    }

    p = MAX(p, q);
    if ((p - name) >= (int)strlen(name) - 1) {
	return NULL;
    }
#endif

    return (p + 1);
}

/*
 *	get allocated base name
 */
char *xspGetBaseName(char *name)
{
    char *string;
    char *basename;

    if (name == NULL || *name == NUL)
	return NULL;

    string = spGetBaseName(name);
    basename = strclone(string);

    return basename;
}

/*
 *	get directory name
 */
char *spGetDirName(char *filename)
{
    char *p;

    if (strnone(filename)) return NULL;

    /* get directory name */
    if ((p = strrchr(filename, SP_DIR_SEPARATOR)) == NULL
	&& (p = strrchr(filename, SP_ANOTHER_DIR_SEPARATOR)) == NULL) {
	return NULL;
    } else {
	*p = NUL;
    }

    return filename;
}

char *xspGetDirName(char *filename)
{
    char *p;
    char *dirname;

    /* get directory name */
    if ((dirname = xspGetExactName(filename)) == NULL) {
	dirname = strclone(SP_DEFAULT_DIRECTORY);
    } else {
	if ((p = strrchr(dirname, SP_DIR_SEPARATOR)) == NULL
	    && (p = strrchr(dirname, SP_ANOTHER_DIR_SEPARATOR)) == NULL) {
	    xfree(dirname);
	    dirname = strclone(SP_DEFAULT_DIRECTORY);
	} else {
	    *p = NUL;
	}
    } 

    return dirname;
}

char *xspGetReadablePath(char *real_path)
{
    char *readable_path;

    if (real_path == NULL) return NULL;

#if defined(MACOSX)
    {
	CFStringRef cfstr;
	char buf[SP_MAX_MESSAGE];

	cfstr = CFStringCreateWithCString(NULL, real_path, kCFStringEncodingUTF8);
	if (!CFStringGetCString(cfstr, buf, SP_MAX_PATHNAME, CFStringGetSystemEncoding())) {
	    CFRelease(cfstr);
	    return NULL;
	}
	readable_path = strclone(buf);
	CFRelease(cfstr);
    }
#else
    readable_path = strclone(real_path);
#endif

    return readable_path;
}

char *xspGetRealPath(char *readable_path)
{
    char *real_path;

    if (readable_path == NULL) return NULL;
    
#if defined(MACOSX)
    {
	CFStringRef cfstr;
	char buf[SP_MAX_MESSAGE];

	cfstr = CFStringCreateWithCString(NULL, readable_path, CFStringGetSystemEncoding());
	if (!CFStringGetCString(cfstr, buf, SP_MAX_PATHNAME, kCFStringEncodingUTF8)) {
	    CFRelease(cfstr);
	    return NULL;
	}
	real_path = strclone(buf);
	CFRelease(cfstr);
    }
#else
    real_path = strclone(readable_path);
#endif
    
    return real_path;
}

#if defined(MACOS)
static spBool getParentFSSpecMac(FSSpec *fsspec)
{
    CInfoPBRec	cinfo;

    cinfo.dirInfo.ioNamePtr = fsspec->name;
    cinfo.dirInfo.ioVRefNum = fsspec->vRefNum;
    cinfo.dirInfo.ioFDirIndex = -1;
    cinfo.dirInfo.ioDrDirID = fsspec->parID;
    if (PBGetCatInfo(&cinfo, false) != noErr) {
	return SP_FALSE;
    }
    fsspec->parID = cinfo.dirInfo.ioDrParID;

    return SP_TRUE;
}

spBool spFSSpecToExactNameMac(FSSpec *fsspec, char *filename)
{
    if (fsspec == NULL || filename == NULL) return SP_FALSE;

#if defined(MACOSX)
    {
	int flag = 1;
	FSRef fsref;
	FSSpec fss;
	CFStringRef cfstr;
	char buf[SP_MAX_PATHNAME];

	fss = *fsspec;
	strcpy(buf, "");
	strcpy(filename, "");
	
	while (flag) {
	    if (FSpMakeFSRef(&fss, &fsref) == noErr) {
		strcpy(buf, filename);
		if (FSRefMakePath(&fsref, filename, SP_MAX_PATHNAME) == noErr) {
		    if (strlen(buf) >= 1) {
			strcat(filename, SP_UNIX_DIR_SEPARATOR_STRING);
			strcat(filename, buf);
		    }
		    spDebug(50, "spFSSpecToExactNameMac", "done: filename = %s\n", filename);
		    return SP_TRUE;
		}
	    }
	    if (fss.parID == 2) {
		flag = 0;
	    }

	    strcpy(buf, filename);

	    if ((cfstr = CFStringCreateWithPascalString(NULL, fss.name, CFStringGetSystemEncoding())) != NULL) {
		if (!CFStringGetCString(cfstr, filename, SP_MAX_PATHNAME, kCFStringEncodingUTF8)) {
		    flag = 0;
		}
		CFRelease(cfstr);
	    }
	    if (getParentFSSpecMac(&fss) == SP_FALSE) {
		return SP_FALSE;
	    }

	    if (strlen(buf) >= 1) {
		strcat(filename, SP_UNIX_DIR_SEPARATOR_STRING);
		strcat(filename, buf);
	    }
	    spDebug(50, "spFSSpecToExactNameMac", "filename = %s\n", filename);
	}

	return SP_FALSE;
    }
#else
    {
	int flag = 1;
	char buf[SP_MAX_PATHNAME];
	FSSpec fss;

	spStrPToC(fsspec->name, filename);

	fss = *fsspec;
	while (flag)	{
	    if (fss.parID == 2) {
		flag = 0;
	    }
	    if (getParentFSSpecMac(&fss) == SP_FALSE) {
		return SP_FALSE;
	    }
	    strcpy(buf, filename);
	    spStrPToC(fss.name, filename);
	    strcat(filename, SP_MAC_DIR_SEPARATOR_STRING);
	    strcat(filename, buf);
	}
    }
#endif
    spDebug(50, "spFSSpecToExactNameMac", "filename = %s\n", filename);
    
    return SP_TRUE;
}
#endif

char *spGetCurrentDir(void)
{
    static char sp_current_directory[SP_MAX_PATHNAME] = "";
#if defined(MACOS)
    FSSpec fsspec;
    
    if (FSMakeFSSpec(0, 0L, "\p", &fsspec) != noErr) {
	return NULL;
    }
    spFSSpecToExactNameMac(&fsspec, sp_current_directory);
#else
    if (getcwd(sp_current_directory, SP_MAX_PATHNAME) == NULL) {
	strcpy(sp_current_directory, SP_DEFAULT_DIRECTORY);
    } else {
	spRemoveDirSeparator(sp_current_directory);
    }
#endif

    return sp_current_directory;
}

char *xspGetCurrentDir(void)
{
    return strclone(spGetCurrentDir());
}

char *spGetDefaultDir(void)
{
    static char sp_default_directory[SP_MAX_PATHNAME] = "";

    if (strnone(sp_default_directory)) {
#if defined(_WIN32)
	char path[SP_MAX_PATHNAME];
	
	if (GetModuleFileName(NULL, path, sizeof(path))) {
#if !defined(__CYGWIN32__)
	    char drive[SP_MAX_PATHNAME];
	    char dir[SP_MAX_PATHNAME];
	    
	    _splitpath(path, drive, dir, NULL, NULL);
	    strcpy(path, drive);
	    strcat(path, dir);
	    spRemoveDirSeparator(path);
#else
	    spGetDirName(path);
#endif
	    strcpy(sp_default_directory, path);
	} else {
	    strcpy(sp_default_directory, SP_DEFAULT_DIRECTORY);
	}
#elif defined(MACOS)
	char *dirname;
	
	dirname = xspGetCurrentDir();
	strcpy(sp_default_directory, dirname);
	xfree(dirname);
#else
	strcpy(sp_default_directory, SP_DEFAULT_DIRECTORY);
#endif
    }

    return sp_default_directory;
}

#if defined(_WIN32)
static spBool getSpecialFolderWin(int folder, char *buf)
{
    spBool flag = SP_FALSE;
    LPITEMIDLIST pidl;
    IMalloc *pMalloc;

    if (SHGetMalloc(&pMalloc) == NOERROR) {
	if (SHGetSpecialFolderLocation(NULL, folder, &pidl) == NOERROR) {
	    SHGetPathFromIDList(pidl, buf);
	    spRemoveDirSeparator(buf);
	    pMalloc->lpVtbl->Free(pMalloc, pidl);
	    flag = SP_TRUE;
	}
	pMalloc->lpVtbl->Release(pMalloc);
    }

    return flag;
}
#endif

#define SP_HOME_DIR_ENV "HOME"
    
char *spGetHomeDir(void)
{
    char *string;
    static char sp_home_directory[SP_MAX_PATHNAME] = "";

    if (strnone(sp_home_directory)) {
#if defined(_WIN32)
	strcpy(sp_home_directory, spGetDefaultDir());
	
	if (access(sp_home_directory, 06) == -1) {
	    if (getSpecialFolderWin(CSIDL_PERSONAL, sp_home_directory) == SP_FALSE) {
		char *drive, *path;
	
		if ((drive = getenv("HOMEDRIVE")) != NULL
		    && (path = getenv("HOMEPATH")) != NULL
		    && strlen(path) >= 2) {
		    sprintf(sp_home_directory, "%s%s", drive, path);
		    spRemoveDirSeparator(sp_home_directory);
		    spDebug(50, "spGetHomeDir", "drive = %s, path = %s, sp_home_directory = %s\n",
			    drive, path, sp_home_directory);
		}
	    }
	}
#else
	if ((string = getenv(SP_HOME_DIR_ENV)) == NULL) {
	    strcpy(sp_home_directory, spGetDefaultDir());
	} else {
	    strcpy(sp_home_directory, string);
	    spRemoveDirSeparator(sp_home_directory);
	}
#endif
    }
    
    return sp_home_directory;
}

char *xspGetHomeDir(void)
{
    return strclone(spGetHomeDir());
}

char *spGetTempDir(void)
{
    static char sp_temp_directory[SP_MAX_PATHNAME] = "";

    if (strnone(sp_temp_directory)) {
#if defined(_WIN32) && !defined(__CYGWIN32__)
	if (GetTempPath(SP_MAX_PATHNAME, sp_temp_directory)) {
	    spRemoveDirSeparator(sp_temp_directory);
	} else if (GetWindowsDirectory(sp_temp_directory, SP_MAX_PATHNAME)) {
	    spRemoveDirSeparator(sp_temp_directory);
	    strcat(sp_temp_directory, "\\Temp");
	} else {
	    strcpy(sp_temp_directory, "C:\\Windows\\Temp");
	}
	if (access(sp_temp_directory, 06) == -1) {
	    strcpy(sp_temp_directory, SP_DEFAULT_DIRECTORY);
	}
#elif defined(MACOS9)
	strcpy(sp_temp_directory, spGetDefaultDir());
#else
	strcpy(sp_temp_directory, "/tmp");
#endif
    }

    return sp_temp_directory;
}

char *xspGetTempDir(void)
{
    return strclone(spGetTempDir());
}

#if 1
static char sp_company_id[SP_MAX_LINE] = "";
static char sp_application_id[SP_MAX_LINE] = "";
static char sp_version_id[SP_MAX_LINE] = "";

static spBool sp_app_dir_id_depend = SP_FALSE;
static char sp_application_directory[SP_MAX_PATHNAME] = "";
static char sp_version_application_directory[SP_MAX_PATHNAME] = "";

static char sp_application_temp_directory[SP_MAX_PATHNAME] = "";

spBool spSetApplicationId(char *id)
{
    int num_sep = 0;
    char *p1 = NULL, *p2 = NULL, *p3 = NULL;
    char buf[SP_MAX_LINE];
    
    if (strnone(id)) return SP_FALSE;

    spDebug(50, "spSetApplicationId", "id = %s\n", id);
    strcpy(buf, id);

    if ((p1 = strchr(buf, '/')) != NULL) {
	spDebug(100, "spSetApplicationId", "p1 = %s\n", p1);
	num_sep++;
	if ((p2 = strchr(p1 + 1, '/')) != NULL) {
	    spDebug(100, "spSetApplicationId", "p2 = %s\n", p2);
	    num_sep++;
	    p3 = p2 + 1;
	}
    }
    spDebug(80, "spSetApplicationId", "num_sep = %d\n", num_sep);

    if (num_sep <= 0) {
	strcpy(sp_application_id, buf);
    } else if (num_sep <= 1) {
	strcpy(sp_version_id, p1 + 1);
	*p1 = NUL;
	strcpy(sp_application_id, buf);
    } else {
	strcpy(sp_version_id, p2 + 1);
	*p2 = NUL;
	strcpy(sp_application_id, p1 + 1);
	*p1 = NUL;
	strcpy(sp_company_id, buf);
    }
    
    spDebug(50, "spSetApplicationId", "company = %s, application = %s, version = %s\n",
	    sp_company_id, sp_application_id, sp_version_id);

    if (strnone(sp_application_id)) {
	return SP_FALSE;
    } else {
	return SP_TRUE;
    }
}

char *spGetCompanyId(void)
{
    return sp_company_id;
}

char *spGetApplicationId(void)
{
    return sp_application_id;
}

char *spGetVersionId(void)
{
    return sp_version_id;
}

/*
 * UNIX, Mac: *id_depend == SP_FALSE ? spGetHomeDir() : spGetHomeDir()/.<id>_dir
 * Windows: 1. CSIDL_APPDATA/[<company id>/]<application id>, 2. Module Path, 3. spGetHomeDir()
 */
char *spCreateApplicationDir(spBool *id_depend, spBool *version_depend)
{
    sp_app_dir_id_depend = SP_FALSE;
	
#if defined(_WIN32)
    {
	char *dir;
	char buf[SP_MAX_PATHNAME];
	    
	dir = spGetDefaultDir();
	if (access(dir, 06) == -1) {
	    dir = spGetHomeDir();
	}

#if 1
	if (strnone(sp_application_id)
	    && GetModuleFileName(NULL, buf, sizeof(buf))
	    && spRemoveSuffix(buf, NULL) == SP_TRUE) {
	    strcpy(sp_application_id, spGetBaseName(buf));
	}
#endif
	    
	if (!strnone(sp_application_id)) {
	    if (getSpecialFolderWin(CSIDL_APPDATA, buf) == SP_TRUE) {
		if (!strnone(sp_company_id)) {
		    spAddDirSeparator(buf); strcat(buf, sp_company_id);
		    if (spIsDir(buf) == SP_FALSE) {
			CreateDirectory(buf, NULL);
		    }
		}
		spAddDirSeparator(buf); strcat(buf, sp_application_id);
		if (spIsDir(buf) == SP_TRUE || CreateDirectory(buf, NULL)) {
		    dir = buf;
		    sp_app_dir_id_depend = SP_TRUE;
		}
	    }
	}
	spDebug(80, "spCreateApplicationDir", "dir = %s\n", dir);
	    
	strcpy(sp_application_directory, dir);
    }
#else
    if (id_depend == NULL || *id_depend == SP_FALSE || strnone(sp_application_id)) {
	strcpy(sp_application_directory, spGetHomeDir());
    } else {
	sprintf(sp_application_directory, "%s%c.%s_dir",
		spGetHomeDir(), SP_DIR_SEPARATOR, sp_application_id);
	if (spIsDir(sp_application_directory) == SP_FALSE
	    && spCreateDir(sp_application_directory, 0700) == SP_FALSE) {
	    strcpy(sp_application_directory, spGetHomeDir());
	} else {
	    sp_app_dir_id_depend = SP_TRUE;
	}
    }
#endif

    if (version_depend != NULL && *version_depend == SP_TRUE) {
	if (sp_app_dir_id_depend == SP_TRUE && !strnone(sp_version_id)) {
	    sprintf(sp_version_application_directory, "%s%c%s",
		    sp_application_directory, SP_DIR_SEPARATOR, sp_version_id);
	    
	    if (spIsDir(sp_version_application_directory) == SP_FALSE
		&& spCreateDir(sp_version_application_directory, 0700) == SP_FALSE) {
		strcpy(sp_version_application_directory, "");
		*version_depend = SP_FALSE;
	    }
	} else {
	    strcpy(sp_version_application_directory, "");
	    *version_depend = SP_FALSE;
	}
    }

    if (id_depend != NULL) *id_depend = sp_app_dir_id_depend;
    
    return sp_application_directory;
}

char *spGetApplicationDir(spBool *version_depend)
{
    spBool id_depend = SP_FALSE;
    
    if (version_depend != NULL && *version_depend == SP_TRUE
	&& !strnone(sp_version_application_directory)) {
	return sp_version_application_directory;
    } else {
	if (strnone(sp_application_directory)) {
	    spCreateApplicationDir(&id_depend, NULL);
	}
	if (version_depend != NULL) *version_depend = SP_FALSE;

	return sp_application_directory;
    }
}

char *xspGetApplicationDir(spBool *version_depend)
{
    return strclone(spGetApplicationDir(version_depend));
}

/*
 * 1. spGetApplicationDir()
 * 2. $HOME/.<id>-<version>_tmp (except for Windows)
 * 3. $HOME/.<id>_tmp (except for Windows)
 * 4. spGetTempDir()
 */
char *spGetApplicationTempDir(void)
{
    spBool id_depend = SP_TRUE;
    spBool version_depend = SP_TRUE;
    char *dir;
    
    if (strnone(sp_application_temp_directory)) {
	dir = spGetApplicationDir(&version_depend);
	id_depend = sp_app_dir_id_depend;
	
	if (id_depend == SP_TRUE) {
#if 1
	    sprintf(sp_application_temp_directory, "%s%ctmp", dir, SP_DIR_SEPARATOR);
#else
	    strcpy(sp_application_temp_directory, dir);
#endif
#if !defined(_WIN32)
	} else if (id_depend == SP_FALSE && !strnone(sp_application_id)) {
	    if (!strnone(sp_version_id) && version_depend == SP_TRUE) {
		sprintf(sp_application_temp_directory, "%s%c.%s-%s_tmp",
			dir, SP_DIR_SEPARATOR, sp_application_id, sp_version_id);
	    } else {
		sprintf(sp_application_temp_directory, "%s%c.%s_tmp",
			dir, SP_DIR_SEPARATOR, sp_application_id);
	    }
#endif
	} else {
	    strcpy(sp_application_temp_directory, dir);
	}
	if (spIsDir(sp_application_temp_directory) == SP_FALSE
	    && spCreateDir(sp_application_temp_directory, 0700) == SP_FALSE) {
	    strcpy(sp_application_temp_directory, spGetTempDir());
	}
    }

    return sp_application_temp_directory;
}

char *xspGetApplicationTempDir(void)
{
    return strclone(spGetApplicationTempDir());
}

spBool spSetApplicationTempDir(char *dir)
{
    if (strnone(dir) || access(dir, 06) == -1) {
	return SP_FALSE;
    }
    strcpy(sp_application_temp_directory, dir);

    return SP_TRUE;
}

#if 1
static spBool findDocumentDir(char **list, char *dir)
{
    int i;
    char buf[SP_MAX_PATHNAME];

    for (i = 0; list[i] != NULL; i++) {
	sprintf(buf, "%s%c%s", dir, SP_DIR_SEPARATOR, list[i]);
	if (spIsDir(buf) == SP_TRUE) {
	    strcpy(dir, buf);
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

char *xspGetDocumentDir(spFileKind file_kind)
{
    spBool flag = SP_FALSE;
    char buf[SP_MAX_PATHNAME];
    static char *document_list[] =
    {
	"Documents",
	"documents",
	"docs",
	"doc",
	NULL,
    };
    static char *source_list[] =
    {
	"Sources",
	"sources",
	"source",
	"srcs",
	"src",
	NULL,
    };
    static char *config_list[] =
    {
	"Configs",
	"configs",
	"config",
	"etc",
	NULL,
    };
    static char *include_list[] =
    {
	"Include",
	"Includes",
	"include",
	"includes",
	NULL,
    };
    static char *picture_list[] =
    {
	"My Pictures",
	"Pictures",
	"pictures",
	"picture",
	"pic",
	NULL,
    };
    static char *figure_list[] =
    {
	"My Figures",
	"Figures",
	"figures",
	"figure",
	"fig",
	NULL,
    };
    static char *music_list[] =
    {
	"My Music",
	"Music",
	"music",
	NULL,
    };
    static char *sound_list[] =
    {
	"My Sounds",
	"My Sound",
	"Sounds",
	"Sound",
	"sounds",
	"sound",
	NULL,
    };
    static char *movie_list[] =
    {
	"My Movies",
	"My Movie",
	"Movies",
	"movies",
	"movie",
	NULL,
    };
    static char *application_list[] =
    {
	"My Applications",
	"My Application",
	"Applications",
	"applications",
	"Application",
	"application",
	"bin",
	NULL,
    };
    static char *library_list[] =
    {
	"Libraries",
	"Library",
	"libraries",
	"library",
	"lib",
	NULL,
    };
    static char *archive_list[] =
    {
	"Downloads",
	"Download",
	"downloads",
	"download",
	"Archives",
	"Archive",
	"archive",
	"Tools",
	"Tool",
	"tools",
	"tool",
	NULL,
    };
    static char *uri_list[] =
    {
	"My Sites",
	"My Site",
	"Sites",
	"Site",
	"URIs",
	"URI",
	"URLs",
	"URL",
        "Sites",
	"Site",
	NULL,
    };

#if defined(_WIN32)
    switch (file_kind) {
      case SP_FILE_KIND_DOCUMENT:
	flag = getSpecialFolderWin(CSIDL_PERSONAL, buf);
	break;

#if defined(CSIDL_PICTURES)
      case SP_FILE_KIND_PICTURE:
	flag = getSpecialFolderWin(CSIDL_PICTURES, buf);
	break;
#endif

      default:
	break;
    }
#endif
    
    if (flag == SP_FALSE) {
#if defined(_WIN32)
	getSpecialFolderWin(CSIDL_PERSONAL, buf);
#else
	strcpy(buf, spGetHomeDir());
#endif
	flag = SP_FALSE;
	
	switch (file_kind) {
	  case SP_FILE_KIND_DOCUMENT:
	  case SP_FILE_KIND_SOURCE:
	  case SP_FILE_KIND_CONFIG:
	  case SP_FILE_KIND_INCLUDE:
	    switch (file_kind) {
	      case SP_FILE_KIND_SOURCE:
		flag = findDocumentDir(source_list, buf);
		break;
	      case SP_FILE_KIND_CONFIG:
		flag = findDocumentDir(config_list, buf);
		break;
	      case SP_FILE_KIND_INCLUDE:
		flag = findDocumentDir(include_list, buf);
		break;
	      default:
		break;
	    }
	    if (flag == SP_FALSE) {
		findDocumentDir(document_list, buf);
	    }
	    break;
	    
	  case SP_FILE_KIND_PICTURE:
	  case SP_FILE_KIND_FIGURE:
	    switch (file_kind) {
	      case SP_FILE_KIND_FIGURE:
		flag = findDocumentDir(figure_list, buf);
		break;
	      default:
		break;
	    }
	    if (flag == SP_FALSE) {
		findDocumentDir(picture_list, buf);
	    }
	    break;
	    
	  case SP_FILE_KIND_MUSIC:
	  case SP_FILE_KIND_SOUND:
	    switch (file_kind) {
	      case SP_FILE_KIND_SOUND:
		flag = findDocumentDir(sound_list, buf);
		break;
	      default:
		break;
	    }
	    if (flag == SP_FALSE) {
		findDocumentDir(music_list, buf);
	    }
	    break;
	    
	  case SP_FILE_KIND_MOVIE:
	    findDocumentDir(movie_list, buf);
	    break;
	    
	  case SP_FILE_KIND_APPLICATION:
	    findDocumentDir(application_list, buf);
	    break;
	    
	  case SP_FILE_KIND_LIBRARY:
	    findDocumentDir(library_list, buf);
	    break;
	    
	  case SP_FILE_KIND_ARCHIVE:
	    findDocumentDir(archive_list, buf);
	    break;
	    
	  case SP_FILE_KIND_URI:
	    findDocumentDir(uri_list, buf);
	    break;
	    
	  default:
	    break;
	}
    }
    
    return strclone(buf);
}
#endif
#endif

spBool spIsExactName(char *name)
{
    if (strnone(name)) return SP_FALSE;

#if defined(MACOS9)	/* only for Mac OS 9 in this version */
    {
	char *p;

	if ((p = strrchr(name, SP_DIR_SEPARATOR)) != NULL
	    && name[0] != '~') {
	    return SP_TRUE;
	}
#if defined(MACOSX)
	if (name[0] == '<') {
	    spDebug(10, "spIsExactName", "path includes '<': %s\n", name);
	    return SP_TRUE;
	}
#endif
    }
#elif defined(_WIN32)
    if (strveq(name, SP_DIR_SEPARATOR_STRING)
	|| strveq(name, SP_ANOTHER_DIR_SEPARATOR_STRING)) {
	return SP_TRUE;
    } else {
	int len;

	len = strlen(name);
	if (len >= 2 && name[1] == ':') {
	    return SP_TRUE;
	}
    }
#else
    if (strveq(name, SP_DIR_SEPARATOR_STRING)) {
	return SP_TRUE;
    }
#endif
    
    return SP_FALSE;
}

/*
 *	get exact name
 */
char *xspGetExactName(char *name)
{
    int len;
    char buf[SP_MAX_PATHNAME];
    char *home, *username;
    char *exactname;
    
    if (name == NULL || *name == NUL) {
	exactname = xspGetCurrentDir();
    } else if (*name == '~') {
	name++;
	if (*name == SP_DIR_SEPARATOR || *name == SP_ANOTHER_DIR_SEPARATOR) {
	    name++;
	    home = xspGetHomeDir();
	    len = strlen(home) + strlen(name) + 2;
	    exactname = xalloc(len, char);
	    sprintf(exactname, "%s%c%s", home, SP_DIR_SEPARATOR, name);
	    xfree(home);
	} else {
#if defined(_WIN32) || defined(MACOS)
	    char *p;
	    home = xspGetCurrentDir();
	    if ((p = spGetBaseName(name)) != NULL) {
		name = p;
	    }
	    len = strlen(home) + strlen(name) + 2;
	    exactname = xalloc(len, char);
	    sprintf(exactname, "%s%c%s", home, SP_DIR_SEPARATOR, name);
	    xfree(home);
#else
	    struct passwd *entry;

	    strcpy(buf, name);
            if ((username = strchr(buf, SP_DIR_SEPARATOR)) != NULL)
		*username = NUL;
	    
	    if ((entry = getpwnam(buf)) == NULL) {
		char *p;
		home = xspGetCurrentDir();
		if ((p = spGetBaseName(name)) != NULL) {
		    name = p;
		}
		len = strlen(home) + strlen(name) + 2;
		exactname = xalloc(len, char);
		sprintf(exactname, "%s%c%s", home, SP_DIR_SEPARATOR, name);
		xfree(home);
            } else {
                home = entry->pw_dir;
		while (*name != SP_DIR_SEPARATOR && *name != NUL) {
		    name++;
		}
		name++;
		len = strlen(home) + strlen(name) + 2;
		exactname = xalloc(len, char);
		sprintf(exactname, "%s%c%s", home, SP_DIR_SEPARATOR, name);
	    }    
#endif
	}
    } else {
	if (streq(name, SP_PARENT_DIR_STRING)) {
	    strcpy(buf, spGetCurrentDir());
	    if ((username = strrchr(buf, SP_DIR_SEPARATOR)) != NULL)
		*username = NUL;
	    exactname = strclone(buf);
	} else if (strveq(name, SP_SEPARATED_PARENT_DIR_STRING)) {
	    name += strlen(SP_SEPARATED_PARENT_DIR_STRING);
	    strcpy(buf, spGetCurrentDir());
	    if ((username = strrchr(buf, SP_DIR_SEPARATOR)) != NULL)
		*username = NUL;
	    strcat(buf, SP_DIR_SEPARATOR_STRING);
	    strcat(buf, name);
	    exactname = strclone(buf);
	} else if (streq(name, SP_CURRENT_DIR_STRING)) {
	    strcpy(buf, spGetCurrentDir());
	    exactname = strclone(buf);
	} else if (strveq(name, SP_SEPARATED_CURRENT_DIR_STRING)) {
	    name += strlen(SP_SEPARATED_CURRENT_DIR_STRING);
	    strcpy(buf, spGetCurrentDir());
	    strcat(buf, SP_DIR_SEPARATOR_STRING);
	    strcat(buf, name);
	    exactname = strclone(buf);
	} else if (spIsExactName(name) == SP_TRUE) {
	    exactname = strclone(name);
	} else {
	    strcpy(buf, spGetCurrentDir());
	    strcat(buf, SP_DIR_SEPARATOR_STRING);
	    strcat(buf, name);
	    exactname = strclone(buf);
	}
    }

    return exactname;
}

char *xspCutPathList(char *pathlist, int col)
{
    int i;
    int len;
    char *sep;
    char *exactname;
    char *path = NULL;
    
    if (strnone(pathlist)) {
	return NULL;
    }
    
    for (i = 0; (!strnone(pathlist)); i++) {
	sep = strchr(pathlist, SP_PATHLIST_SEPARATOR);
	if (i == col) {
	    if (sep != NULL) {
		len = (int)(sep - pathlist);
		path = xalloc(len + 1, char);
		strncpy(path, pathlist, len);
		path[len] = NUL;
	    } else {
		path = strclone(pathlist);
	    }

	    break;
	}
	
	if (sep == NULL) {
	    break;
	} else {
	    pathlist = sep + 1;
	}
    }

    if (path != NULL) {
	exactname = xspGetExactName(path);
	xfree(path);
    } else {
	exactname = NULL;
    }
	 
    return exactname;
}

long spGetProcessId(void)
{
#if defined(MACOS9)
    Str32 pname;
    FSSpec fsspec;
    ProcessSerialNumber psn;
    ProcessInfoRec pir;

    psn.highLongOfPSN = 0;
    psn.lowLongOfPSN = kCurrentProcess;
    pir.processInfoLength = sizeof(pir);
    pir.processName = pname;
    pir.processAppSpec = &fsspec;
    
    if (GetProcessInformation(&psn, &pir) != noErr) {
	return 0;
    }

    return (long)pir.processNumber.lowLongOfPSN;
#else
    return (long)getpid();
#endif
}

static char *locale_alias[][2] = {
    /* based on locale.alias of X window system */
    {"POSIX", "C"},
    {"POSIX-UTF2", "C"},
    {"C_C.C", "C"},
    {"C.en", "C"},
    {"C.iso88591", "en_US.ISO8859-1"},
    {"C.iso885915", "en_US.ISO8859-15"},
    {"Cextend", "en_US.ISO8859-1"},
    {"Cextend.en", "en_US.ISO8859-1"},
    {"English_United-States.437", "C"},
    {"ar", "ar_AA.ISO8859-6"},
    {"ar_AA", "ar_AA.ISO8859-6"},
    {"ar_SA.iso88596", "ar_SA.ISO8859-6"},
    {"bg", "bg_BG.ISO8859-5"},
    {"bg_BG", "bg_BG.ISO8859-5"},
    {"bg_BG.iso88595", "bg_BG.ISO8859-5"},
    {"cs", "cs_CZ.ISO8859-2"},
    {"cs_CS", "cs_CZ.ISO8859-2"},
    {"cs_CS.ISO8859-2", "cs_CZ.ISO8859-2"},
    {"cs_CZ", "cs_CZ.ISO8859-2"},
    {"cs_CZ.iso88592", "cs_CZ.ISO8859-2"},
    {"cz", "cz_CZ.ISO8859-2"},
    {"cz_CZ", "cz_CZ.ISO8859-2"},
    {"da", "da_DK.ISO8859-1"},
    {"da_DK", "da_DK.ISO8859-1"},
    {"da_DK.88591", "da_DK.ISO8859-1"},
    {"da_DK.885915", "da_DK.ISO8859-15"},
    {"da_DK.88591.en", "da_DK.ISO8859-1"},
    {"da_DK.885915.en", "da_DK.ISO8859-15"},
    {"da_DK.iso88591", "da_DK.ISO8859-1"},
    {"da_DK.iso885915", "da_DK.ISO8859-15"},
    {"da_DK.ISO_8859-1", "da_DK.ISO8859-1"},
    {"da_DK.ISO_8859-15", "da_DK.ISO8859-15"},
    {"de", "de_DE.ISO8859-1"},
    {"de_AT", "de_AT.ISO8859-1"},
    {"de_AT.ISO_8859-1", "de_AT.ISO8859-1"},
    {"de_AT.ISO_8859-15", "de_AT.ISO8859-15"},
    {"de_CH", "de_CH.ISO8859-1"},
    {"de_CH.ISO_8859-1", "de_CH.ISO8859-1"},
    {"de_CH.ISO_8859-15", "de_CH.ISO8859-15"},
    {"de_DE", "de_DE.ISO8859-1"},
    {"de_DE.88591", "de_DE.ISO8859-1"},
    {"de_DE.885915", "de_DE.ISO8859-15"},
    {"de_DE.88591.en", "de_DE.ISO8859-1"},
    {"de_DE.885915.en", "de_DE.ISO8859-15"},
    {"de_DE.iso88591", "de_DE.ISO8859-1"},
    {"de_DE.iso885915", "de_DE.ISO8859-15"},
    {"de_DE.ISO_8859-1", "de_DE.ISO8859-1"},
    {"de_DE.ISO_8859-15", "de_DE.ISO8859-15"},
    {"GER_DE.8859", "de_DE.ISO8859-1"},
    {"GER_DE.8859.in", "de_DE.ISO8859-1"},
    {"ee", "ee_EE.ISO8859-4"},
    {"el", "el_GR.ISO8859-7"},
    {"el_GR", "el_GR.ISO8859-7"},
    {"el_GR.iso88597", "el_GR.ISO8859-7"},
    {"en", "en_US.ISO8859-1"},
    {"en_AU", "en_AU.ISO8859-1"},
    {"en_AU.ISO_8859-1", "en_AU.ISO8859-1"},
    {"en_AU.ISO_8859-15", "en_AU.ISO8859-15"},
    {"en_CA", "en_CA.ISO8859-1"},
    {"en_CA.ISO_8859-1", "en_CA.ISO8859-1"},
    {"en_CA.ISO_8859-15", "en_CA.ISO8859-15"},
    {"en_GB", "en_GB.ISO8859-1"},
    {"en_GB.88591", "en_GB.ISO8859-1"},
    {"en_GB.885915", "en_GB.ISO8859-15"},
    {"en_GB.88591.en", "en_GB.ISO8859-1"},
    {"en_GB.885915.en", "en_GB.ISO8859-15"},
    {"en_GB.iso88591", "en_GB.ISO8859-1"},
    {"en_GB.iso885915", "en_GB.ISO8859-15"},
    {"en_GB.ISO_8859-1", "en_GB.ISO8859-1"},
    {"en_GB.ISO_8859-15", "en_GB.ISO8859-15"},
    {"en_UK", "en_GB.ISO8859-1"},
    {"ENG_GB.8859", "en_GB.ISO8859-1"},
    {"ENG_GB.8859.in", "en_GB.ISO8859-1"},
    {"en_IE", "en_IE.ISO8859-1"},
    {"en_NZ", "en_NZ.ISO8859-1"},
    {"en_US", "en_US.ISO8859-1"},
    {"en_US.88591", "en_US.ISO8859-1"},
    {"en_US.885915", "en_US.ISO8859-15"},
    {"en_US.88591.en", "en_US.ISO8859-1"},
    {"en_US.885915.en", "en_US.ISO8859-15"},
    {"en_US.iso88591", "en_US.ISO8859-1"},
    {"en_US.iso885915", "en_US.ISO8859-15"},
    {"en_US.ISO_8859-1", "en_US.ISO8859-1"},
    {"en_US.ISO_8859-15", "en_US.ISO8859-15"},
    {"en_US.UTF-8", "en_US.utf"},
    {"es", "es_ES.ISO8859-1"},
    {"es_AR", "es_AR.ISO8859-1"},
    {"es_BO", "es_BO.ISO8859-1"},
    {"es_CL", "es_CL.ISO8859-1"},
    {"es_CO", "es_CO.ISO8859-1"},
    {"es_CR", "es_CR.ISO8859-1"},
    {"es_EC", "es_EC.ISO8859-1"},
    {"es_ES", "es_ES.ISO8859-1"},
    {"es_ES.88591", "es_ES.ISO8859-1"},
    {"es_ES.885915", "es_ES.ISO8859-15"},
    {"es_ES.88591.en", "es_ES.ISO8859-1"},
    {"es_ES.885915.en", "es_ES.ISO8859-15"},
    {"es_ES.iso88591", "es_ES.ISO8859-1"},
    {"es_ES.iso885915", "es_ES.ISO8859-15"},
    {"es_ES.ISO_8859-1", "es_ES.ISO8859-1"},
    {"es_ES.ISO_8859-15", "es_ES.ISO8859-15"},
    {"es_GT", "es_GT.ISO8859-1"},
    {"es_MX", "es_MX.ISO8859-1"},
    {"es_NI", "es_NI.ISO8859-1"},
    {"es_PA", "es_PA.ISO8859-1"},
    {"es_PE", "es_PE.ISO8859-1"},
    {"es_PY", "es_PY.ISO8859-1"},
    {"es_SV", "es_SV.ISO8859-1"},
    {"es_UY", "es_UY.ISO8859-1"},
    {"es_VE", "es_VE.ISO8859-1"},
    {"et", "et_EE.ISO8859-4"},
    {"et_EE", "et_EE.ISO8859-4"},
    {"fi", "fi_FI.ISO8859-1"},
    {"fi_FI", "fi_FI.ISO8859-1"},
    {"fi_FI.88591", "fi_FI.ISO8859-1"},
    {"fi_FI.885915", "fi_FI.ISO8859-15"},
    {"fi_FI.88591.en", "fi_FI.ISO8859-1"},
    {"fi_FI.885915.en", "fi_FI.ISO8859-15"},
    {"fi_FI.iso88591", "fi_FI.ISO8859-1"},
    {"fi_FI.iso885915", "fi_FI.ISO8859-15"},
    {"fi_FI.ISO_8859-1", "fi_FI.ISO8859-1"},
    {"fi_FI.ISO_8859-15", "fi_FI.ISO8859-15"},
    {"fr", "fr_FR.ISO8859-1"},
    {"fr_BE", "fr_BE.ISO8859-1"},
    {"fr_BE.88591", "fr_BE.ISO8859-1"},
    {"fr_BE.885915", "fr_BE.ISO8859-15"},
    {"fr_BE.88591.en", "fr_BE.ISO8859-1"},
    {"fr_BE.885915.en", "fr_BE.ISO8859-15"},
    {"fr_BE.ISO_8859-1", "fr_BE.ISO8859-1"},
    {"fr_BE.ISO_8859-15", "fr_BE.ISO8859-15"},
    {"fr_CA", "fr_CA.ISO8859-1"},
    {"fr_CA.88591", "fr_CA.ISO8859-1"},
    {"fr_CA.885915", "fr_CA.ISO8859-15"},
    {"fr_CA.88591.en", "fr_CA.ISO8859-1"},
    {"fr_CA.885915.en", "fr_CA.ISO8859-15"},
    {"fr_CA.iso88591", "fr_CA.ISO8859-1"},
    {"fr_CA.iso885915", "fr_CA.ISO8859-15"},
    {"fr_CA.ISO_8859-1", "fr_CA.ISO8859-1"},
    {"fr_CA.ISO_8859-15", "fr_CA.ISO8859-15"},
    {"fr_CH", "fr_CH.ISO8859-1"},
    {"fr_CH.88591", "fr_CH.ISO8859-1"},
    {"fr_CH.885915", "fr_CH.ISO8859-15"},
    {"fr_CH.88591.en", "fr_CH.ISO8859-1"},
    {"fr_CH.885915.en", "fr_CH.ISO8859-15"},
    {"fr_CH.ISO_8859-1", "fr_CH.ISO8859-1"},
    {"fr_CH.ISO_8859-15", "fr_CH.ISO8859-15"},
    {"fr_FR", "fr_FR.ISO8859-1"},
    {"fr_FR.88591", "fr_FR.ISO8859-1"},
    {"fr_FR.885915", "fr_FR.ISO8859-15"},
    {"fr_FR.88591.en", "fr_FR.ISO8859-1"},
    {"fr_FR.885915.en", "fr_FR.ISO8859-15"},
    {"fr_FR.iso88591", "fr_FR.ISO8859-1"},
    {"fr_FR.iso885915", "fr_FR.ISO8859-15"},
    {"fr_FR.ISO_8859-1", "fr_FR.ISO8859-1"},
    {"fr_FR.ISO_8859-15", "fr_FR.ISO8859-15"},
    {"FRE_FR.8859", "fr_FR.ISO8859-1"},
    {"FRE_FR.8859.in", "fr_FR.ISO8859-1"},
    {"hr", "hr_HR.ISO8859-2"},
    {"hr_HR", "hr_HR.ISO8859-2"},
    {"hr_HR.iso88592", "hr_HR.ISO8859-2"},
    {"hr_HR.ISO_8859-2", "hr_HR.ISO8859-2"},
    {"hu", "hu_HU.ISO8859-2"},
    {"hu_HU", "hu_HU.ISO8859-2"},
    {"hu_HU.iso88592", "hu_HU.ISO8859-2"},
    {"is", "is_IS.ISO8859-1"},
    {"is_IS", "is_IS.ISO8859-1"},
    {"is_IS.iso88591", "is_IS.ISO8859-1"},
    {"is_IS.iso885915", "is_IS.ISO8859-15"},
    {"is_IS.ISO_8859-1", "is_IS.ISO8859-1"},
    {"is_IS.ISO_8859-15", "is_IS.ISO8859-15"},
    {"it", "it_IT.ISO8859-1"},
    {"it_CH", "it_CH.ISO8859-1"},
    {"it_CH.ISO_8859-1", "it_CH.ISO8859-1"},
    {"it_CH.ISO_8859-15", "it_CH.ISO8859-15"},
    {"it_IT", "it_IT.ISO8859-1"},
    {"it_IT.88591", "it_IT.ISO8859-1"},
    {"it_IT.885915", "it_IT.ISO8859-15"},
    {"it_IT.88591.en", "it_IT.ISO8859-1"},
    {"it_IT.885915.en", "it_IT.ISO8859-15"},
    {"it_IT.iso88591", "it_IT.ISO8859-1"},
    {"it_IT.iso885915", "it_IT.ISO8859-15"},
    {"it_IT.ISO_8859-1", "it_IT.ISO8859-1"},
    {"it_IT.ISO_8859-15", "it_IT.ISO8859-15"},
    {"iw", "iw_IL.ISO8859-8"},
    {"iw_IL", "iw_IL.ISO8859-8"},
    {"iw_IL.iso88598", "iw_IL.ISO8859-8"},
    {"ja", "ja_JP.eucJP"},
    {"ja.JIS", "ja_JP.JIS7"},
    {"ja.SJIS", "ja_JP.SJIS"},
    {"ja_JP", "ja_JP.eucJP"},
    {"ja_JP.ujis", "ja_JP.eucJP"},
    {"ja_JP.eucJP", "ja_JP.eucJP"},
    {"Jp_JP", "ja_JP.eucJP"},
    {"ja_JP.AJEC", "ja_JP.eucJP"},
    {"ja_JP.EUC", "ja_JP.eucJP"},
    {"ja_JP.ISO-2022-JP", "ja_JP.JIS7"},
    {"ja_JP.JIS", "ja_JP.JIS7"},
    {"ja_JP.jis7", "ja_JP.JIS7"},
    {"ja_JP.mscode", "ja_JP.SJIS"},
    {"ja_JP.SJIS", "ja_JP.SJIS"},
    {"ko", "ko_KR.eucKR"},
    {"ko_KR", "ko_KR.eucKR"},
    {"ko_KR.EUC", "ko_KR.eucKR"},
    {"ko_KR.euc", "ko_KR.eucKR"},
    {"lt", "lt_LT.ISO8859-4"},
    {"lv", "lv_LV.ISO8859-4"},
    {"mk", "mk_MK.ISO8859-5"},
    {"mk_MK", "mk_MK.ISO8859-5"},
    {"nl", "nl_NL.ISO8859-1"},
    {"nl_BE", "nl_BE.ISO8859-1"},
    {"nl_BE.88591", "nl_BE.ISO8859-1"},
    {"nl_BE.885915", "nl_BE.ISO8859-15"},
    {"nl_BE.88591.en", "nl_BE.ISO8859-1"},
    {"nl_BE.885915.en", "nl_BE.ISO8859-15"},
    {"nl_BE.ISO_8859-1", "nl_BE.ISO8859-1"},
    {"nl_BE.ISO_8859-15", "nl_BE.ISO8859-15"},
    {"nl_NL", "nl_NL.ISO8859-1"},
    {"nl_NL.88591", "nl_NL.ISO8859-1"},
    {"nl_NL.885915", "nl_NL.ISO8859-15"},
    {"nl_NL.88591.en", "nl_NL.ISO8859-1"},
    {"nl_NL.885915.en", "nl_NL.ISO8859-15"},
    {"nl_NL.iso88591", "nl_NL.ISO8859-1"},
    {"nl_NL.iso885915", "nl_NL.ISO8859-15"},
    {"nl_NL.ISO_8859-1", "nl_NL.ISO8859-1"},
    {"nl_NL.ISO_8859-15", "nl_NL.ISO8859-15"},
    {"no", "no_NO.ISO8859-1"},
    {"no_NO", "no_NO.ISO8859-1"},
    {"no_NO.88591", "no_NO.ISO8859-1"},
    {"no_NO.885915", "no_NO.ISO8859-15"},
    {"no_NO.88591.en", "no_NO.ISO8859-1"},
    {"no_NO.885915.en", "no_NO.ISO8859-15"},
    {"no_NO.iso88591", "no_NO.ISO8859-1"},
    {"no_NO.iso885915", "no_NO.ISO8859-15"},
    {"no_NO.ISO_8859-1", "no_NO.ISO8859-1"},
    {"no_NO.ISO_8859-15", "no_NO.ISO8859-15"},
    {"pl", "pl_PL.ISO8859-2"},
    {"pl_PL", "pl_PL.ISO8859-2"},
    {"pl_PL.iso88592", "pl_PL.ISO8859-2"},
    {"pt", "pt_PT.ISO8859-1"},
    {"pt_BR", "pt_BR.ISO8859-1"},
    {"pt_PT", "pt_PT.ISO8859-1"},
    {"pt_PT.88591", "pt_PT.ISO8859-1"},
    {"pt_PT.885915", "pt_PT.ISO8859-15"},
    {"pt_PT.88591.en", "pt_PT.ISO8859-1"},
    {"pt_PT.885915.en", "pt_PT.ISO8859-15"},
    {"pt_PT.iso88591", "pt_PT.ISO8859-1"},
    {"pt_PT.iso885915", "pt_PT.ISO8859-15"},
    {"pt_PT.ISO_8859-1", "pt_PT.ISO8859-1"},
    {"pt_PT.ISO_8859-15", "pt_PT.ISO8859-15"},
    {"ro", "ro_RO.ISO8859-2"},
    {"ro_RO", "ro_RO.ISO8859-2"},
    {"ro_RO.iso88592", "ro_RO.ISO8859-2"},
    {"ru", "ru_RU.ISO8859-5"},
    {"ru_RU", "ru_RU.ISO8859-5"},
    {"ru_RU.iso88595", "ru_RU.ISO8859-5"},
    {"sh", "sh_YU.ISO8859-2"},
    {"sh_HR.iso88592", "sh_HR.ISO8859-2"},
    {"sh_YU", "sh_YU.ISO8859-2"},
    {"sh_SP", "sh_YU.ISO8859-2"},
    {"sk", "sk_SK.ISO8859-2"},
    {"sk_SK", "sk_SK.ISO8859-2"},
    {"sk_sK.iso88592", "sk_SK.ISO8859-2"},
    {"sl", "sl_CS.ISO8859-2"},
    {"sl_CS", "sl_CS.ISO8859-2"},
    {"sl_SI", "sl_SI.ISO8859-2"},
    {"sl_SI.iso88592", "sl_SI.ISO8859-2"},
    {"sp", "sp_YU.ISO8859-5"},
    {"sp_YU", "sp_YU.ISO8859-5"},
    {"sr_SP", "sr_SP.ISO8859-2"},
    {"sv", "sv_SE.ISO8859-1"},
    {"sv_SE", "sv_SE.ISO8859-1"},
    {"sv_SE.88591", "sv_SE.ISO8859-1"},
    {"sv_SE.885915", "sv_SE.ISO8859-15"},
    {"sv_SE.88591.en", "sv_SE.ISO8859-1"},
    {"sv_SE.885915.en", "sv_SE.ISO8859-15"},
    {"sv_SE.iso88591", "sv_SE.ISO8859-1"},
    {"sv_SE.iso885915", "sv_SE.ISO8859-15"},
    {"sv_SE.ISO_8859-1", "sv_SE.ISO8859-1"},
    {"sv_SE.ISO_8859-15", "sv_SE.ISO8859-15"},
    {"th_TH", "th_TH.TACTIS"},
    {"th_TH.tis620", "th_TH.TACTIS"},
    {"tr", "tr_TR.ISO8859-9"},
    {"tr_TR", "tr_TR.ISO8859-9"},
    {"tr_TR.iso88599", "tr_TR.ISO8859-9"},
    {"zh_CN", "zh_CN.GBK"},
    {"zh_CN.EUC", "zh_CN.eucCN"},
    {"zh_TW", "zh_TW.eucTW"},
    {"zh_TW.EUC", "zh_TW.eucTW"},
    {"zh_CN.big5", "zh_TW.eucTW"},
    {"english_uk.8859", "en_GB.ISO8859-1"},
    {"english_us.8859", "en_US.ISO8859-1"},
    {"english_us.ascii", "en_US.ISO8859-1"},
    {"french_france.8859", "fr_FR.ISO8859-1"},
    {"german_germany.8859", "de_DE.ISO8859-1"},
    {"portuguese_brazil.8859", "pt_BR.ISO8859-1"},
    {"spanish_spain.8859", "es_ES.ISO8859-1"},
    {"american.iso88591", "en_US.ISO8859-1"},
    {"american.iso885915", "en_US.ISO8859-15"},
    {"arabic.iso88596", "ar_AA.ISO8859-6"},
    {"bulgarian", "bg_BG.ISO8859-5"},
    {"c-french.iso88591", "fr_CA.ISO8859-1"},
    {"c-french.iso885915", "fr_CA.ISO8859-15"},
    {"chinese-s", "zh_CN.eucCN"},
    {"chinese-t", "zh_TW.eucTW"},
    {"croatian", "hr_HR.ISO8859-2"},
    {"czech", "cs_CZ.ISO8859-2"},
    {"danish.iso88591", "da_DK.ISO8859-1"},
    {"danish.iso885915", "da_DK.ISO8859-15"},
    {"dutch.iso88591", "nl_BE.ISO8859-1"},
    {"dutch.iso885915", "nl_BE.ISO8859-15"},
    {"english.iso88591", "en_EN.ISO8859-1"},
    {"english.iso885915", "en_EN.ISO8859-15"},
    {"finnish.iso88591", "fi_FI.ISO8859-1"},
    {"finnish.iso885915", "fi_FI.ISO8859-15"},
    {"french.iso88591", "fr_CH.ISO8859-1"},
    {"french.iso885915", "fr_CH.ISO8859-15"},
    {"german.iso88591", "de_CH.ISO8859-1"},
    {"german.iso885915", "de_CH.ISO8859-15"},
    {"greek.iso88597", "el_GR.ISO8859-7"},
    {"hebrew.iso88598", "iw_IL.ISO8859-8"},
    {"hungarian", "hu_HU.ISO8859-2"},
    {"icelandic.iso88591", "is_IS.ISO8859-1"},
    {"icelandic.iso885915", "is_IS.ISO8859-15"},
    {"italian.iso88591", "it_IT.ISO8859-1"},
    {"italian.iso885915", "it_IT.ISO8859-15"},
    {"japanese", "ja_JP.SJIS"},
    {"japanese.euc", "ja_JP.eucJP"},
    {"Japanese_Japan.932", "ja_JP.SJIS"},
    {"korean", "ko_KR.eucKR"},
    {"norwegian.iso88591", "no_NO.ISO8859-1"},
    {"norwegian.iso885915", "no_NO.ISO8859-15"},
    {"polish", "pl_PL.ISO8859-2"},
    {"portuguese.iso88591", "pt_PT.ISO8859-1"},
    {"portuguese.iso885915", "pt_PT.ISO8859-15"},
    {"rumanian", "ro_RO.ISO8859-2"},
    {"russian", "ru_RU.ISO8859-5"},
    {"serbocroatian", "sh_YU.ISO8859-2"},
    {"slovak", "sk_SK.ISO8859-2"},
    {"slovene", "sl_CS.ISO8859-2"},
    {"spanish.iso88591", "es_ES.ISO8859-1"},
    {"spanish.iso885915", "es_ES.ISO8859-15"},
    {"swedish.iso88591", "sv_SE.ISO8859-1"},
    {"swedish.iso885915", "sv_SE.ISO8859-15"},
    {"turkish.iso88599", "tr_TR.ISO8859-9"},
    {"univ.utf8", "en_US.utf"},
    {"universal.utf8@ucs4", "en_US.utf"},
    {"en_US.UTF-8", "en_US.utf"},
    {"iso_8859_1", "en_US.ISO8859-1"},
    {"iso_8859_15", "en_US.ISO8859-15"},
    {"ISO8859-1", "en_US.ISO8859-1"},
    {"ISO8859-15", "en_US.ISO8859-15"},
    {"ISO-8859-1", "en_US.ISO8859-1"},
    {"ISO-8859-15", "en_US.ISO8859-15"},
    {"japan", "ja_JP.eucJP"},
    {"Japanese-EUC", "ja_JP.eucJP"},
    {"", ""},
};

spBool spEqLanguage(char *lang1, char *lang2)
{
    int i;
    spBool flag = SP_FALSE;

    if (lang1 == NULL && lang2 == NULL) {
	return SP_TRUE;
    } else if (lang1 == NULL || lang2 == NULL) {
	return SP_FALSE;
    }

    if (streq(lang1, lang2)) {
	flag = SP_TRUE;
    } else {
	for (i = 0;; i++) {
	    if (strnone(locale_alias[i][0])) {
		break;
	    }

	    if (streq(locale_alias[i][0], lang1) || streq(locale_alias[i][1], lang1)) {
		lang1 = locale_alias[i][1];
		break;
	    }
	}
	for (i = 0;; i++) {
	    if (strnone(locale_alias[i][0])) {
		break;
	    }
	    if (streq(locale_alias[i][0], lang2) || streq(locale_alias[i][1], lang2)) {
		spDebug(10, "spEqLanguage", "lang1 = %s, lang2 = %s (%s)\n",
			lang1, locale_alias[i][0], locale_alias[i][1]);
		if (streq(lang1, locale_alias[i][1])) {
		    flag = SP_TRUE;
		}
		break;
	    }
	}
	
    }

    return flag;
}

spBool spIsJapaneseLang(char *lang)
{
    if (strnone(lang)) return SP_FALSE;
    
    if (spEqLanguage(lang, "ja_JP.eucJP") == SP_TRUE
	|| spEqLanguage(lang, "ja_JP.SJIS") == SP_TRUE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spIsMBTailCandidate(int prev_c, int c)
{
#if defined(_WIN32) && !defined(__CYGWIN32__)
    return (_ismbblead(prev_c) && _ismbbtrail(c)) ? SP_TRUE : SP_FALSE;
#elif defined(_WIN32) || defined(MACOS)
    /* Shift JIS */
    if (((prev_c >= 0x81 && prev_c <= 0x9f) || (prev_c >= 0xe0 && prev_c <= 0xfc))
	&& ((c >= 0x40 && c <= 0x7e) || (c >= 0x80 && c <= 0xfc))) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
#else
    /* EUC-JP */
    if ((prev_c >= 0x8e && prev_c <= 0xfe) && (c >= 0xa1 && c <= 0xfe)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
#endif
}

int spUnicode16ToUTF8(unsigned short *unicode, unsigned char *buf, int buf_size)
{
    int index;
    int buf_index;
    unsigned short u;
    unsigned char c;
    
    if (unicode == NULL) return -1;

    index = 0;
    buf_index = 0;
    u = unicode[index++];

    if (buf == NULL || buf_size <= 0) {
	while (u) {
	    if (u < 0x0080) {
		buf_index += 1;
	    } else if (u < 0x0800) {
		buf_index += 2;
	    } else {
		buf_index += 3;
	    }
	    u = unicode[index++];
	}
	buf_index++;
    } else {
	while (u) {
	    if (u < 0x0080) {
		c = (unsigned char)u;
		buf[buf_index++] = c;
	    } else if (u < 0x0800) {
		if (buf_index + 2 >= buf_size) {
		    break;
		}
		c = (unsigned char)(u >> 6) | 0xc0;
		buf[buf_index++] = c;
		c = (unsigned char)(u & 0x3f) | 0x80;
		buf[buf_index++] = c;
	    } else {
		if (buf_index + 3 >= buf_size) {
		    break;
		}
		c = (unsigned char)(u >> 12) | 0xe0;
		buf[buf_index++] = c;
		c = (unsigned char)((u >> 6) & 0x3f) | 0x80;
		buf[buf_index++] = c;
		c = (unsigned char)(u & 0x3f) | 0x80;
		buf[buf_index++] = c;
	    }
	
	    if (buf_index >= buf_size) {
		buf_index--;
		break;
	    }
	
	    u = unicode[index++];
	}
    
	buf[buf_index++] = 0x00;
    }

    return buf_index;
}

int spUTF8ToUnicode16(unsigned char *utf8, unsigned short *buf, int buf_size)
{
    int index;
    int buf_index;
    unsigned char c;
    
    if (utf8 == NULL) return -1;
    
    index = 0;
    buf_index = 0;
    c = utf8[index++];

    if (buf == NULL || buf_size <= 0) {
	while (c) {
	    if ((c & 0x80) == 0) {
		buf_index++;
	    } else if ((c & 0xfc) == 0xfc) {
		buf_index++;
		index += 5;
	    } else if ((c & 0xf8) == 0xf8) {
		buf_index++;
		index += 4;
	    } else if ((c & 0xf0) == 0xf0) {
		buf_index++;
		index += 3;
	    } else if ((c & 0xe0) == 0xe0) {
		buf_index++;
		index += 2;
	    } else if ((c & 0xc0) == 0xc0) {
		buf_index++;
		index += 1;
	    } else {
		spDebug(80, "spUTF8ToUnicode16", "!!!!!! c = %x\n", c);
	    }
	    c = utf8[index++];
	}
	buf_index++;
    } else {
	while (c) {
	    if ((c & 0x80) == 0) {
		buf[buf_index++] = c;
	    } else if ((c & 0xfc) == 0xfc) {
		buf[buf_index++] = ' ';
		index += 5;
	    } else if ((c & 0xf8) == 0xf8) {
		buf[buf_index++] = ' ';
		index += 4;
	    } else if ((c & 0xf0) == 0xf0) {
		buf[buf_index++] = ' ';
		index += 3;
	    } else if ((c & 0xe0) == 0xe0) {
		buf[buf_index] = (c & 0x1f) << 12;
		
		c = utf8[index++];
		buf[buf_index] |= (c & 0x3f) << 6;
		
		c = utf8[index++];
		buf[buf_index++] |= (c & 0x3f);
	    } else if ((c & 0xc0) == 0xc0) {
		buf[buf_index] = (c & 0x3f) << 6;
		
		c = utf8[index++];
		buf[buf_index++] |= (c & 0x3f);
	    } else {
		spDebug(80, "spUTF8ToUnicode16", "!!!!!! c = %x\n", c);
	    }
	    if (buf_index >= buf_size / 2) {
		buf_index--;
		break;
	    }
	
	    c = utf8[index++];
	}
    
	buf[buf_index++] = 0x00;
    }
    spDebug(80, "spUTF8ToUnicode16", "buf_index = %d\n", buf_index);

    return buf_index * 2;
}

#if 1
#if !defined(MACOS) && !defined(_WIN32)
#include <errno.h>
#include <iconv.h>
#include <langinfo.h>
#endif

struct _spConverter {
#if defined(MACOS)
    TextEncoding ienc;
    TextEncoding oenc;
    TECObjectRef ec;
#elif defined(_WIN32) && !defined(HAVE_ICONV_H)
    char *icode;
    char *ocode;
#else
    iconv_t cd;
#endif
};

static char *getSupportedCode(char *code)
{
#if defined(MACOS)
    if (strnone(code)) {
	return "";
    } else if (strcaseeq(code, "UTF-8") || strcaseeq(code, "UTF8")) {
	return "UTF-8";
    } else if (strcaseeq(code, "UTF-16") || strcaseeq(code, "UTF16")) {
	return "csUnicode";
    } else if (strcaseeq(code, "SJIS") || strcaseeq(code, "mscode")) {
	return "Shift_JIS";
    }
    return code;
#elif defined(_WIN32) && !defined(HAVE_ICONV_H)
    if (strnone(code)) {
	return "ACP";
    } else if (strcaseeq(code, "UTF-8") || strcaseeq(code, "UTF8")) {
	return "UTF-8";
    } else if (strcaseeq(code, "UTF-16") || strcaseeq(code, "UTF16")) {
	return "UTF-16";
    } else {
	return NULL;
    }
#else
    if (strnone(code)) code = nl_langinfo(CODESET);
#endif

    return code;
}

#if defined(MACOS)
static spBool getTextEncoding(char *code, TextEncoding *encoding)
{
    Str255 pstr;

    if (strnone(code)) {
	*encoding = GetScriptManagerVariable(smSysScript);
    } else {
	spStrCToP(code, pstr);
	if (TECGetTextEncodingFromInternetName(encoding, pstr) != noErr) {
	    spDebug(10, "getTextEncoding", "can't get internet name: %s\n", code);
	    return SP_FALSE;
	}
    }
    
    spDebug(80, "getTextEncoding", "\"%s\": encoding = %lx\n", code, *encoding);
    
    return SP_TRUE;
}
#endif

spConverter spOpenConverter(char *icode, char *ocode)
{
    spConverter conv;

    if (strnone(icode) && strnone(ocode)) return NULL;

    if ((icode = getSupportedCode(icode)) == NULL) {
	return NULL;
    }
    if ((ocode = getSupportedCode(ocode)) == NULL) {
	return NULL;
    }
    conv = xalloc(1, struct _spConverter);
    
#if defined(MACOS)
    if (getTextEncoding(icode, &conv->ienc) == SP_FALSE
	|| getTextEncoding(ocode, &conv->oenc) == SP_FALSE
	|| TECCreateConverter(&conv->ec, conv->ienc, conv->oenc) != noErr) {
	xfree(conv);
	return NULL;
    }
#elif defined(_WIN32) && !defined(HAVE_ICONV_H)
    conv->icode = icode;
    conv->ocode = ocode;
#else
    conv->cd = iconv_open(ocode, icode);
    if (conv->cd == (iconv_t)(-1)) {
	xfree(conv);
	return NULL;
    }
#endif
    
    return conv;
}

char *xspConvert(spConverter conv, char *input)
{
    char *buf = NULL;

    if (conv == NULL || input == NULL) return NULL;
    
#if defined(MACOS)
    {
	int ilen;
	ByteCount buf_size;
	ByteCount ail, aol;
	OSStatus status;

	ilen = strlen(input);
	buf_size = MAX(ilen + 1, 32);
	buf = xalloc(buf_size, char);

	while (1) {
	    if ((status = TECConvertText(conv->ec, (ConstTextPtr)input, ilen + 1,
					 &ail, (TextPtr)buf, buf_size, &aol)) == noErr) {
		break;
	    }
	    if (status != kTECOutputBufferFullStatus) {
		return NULL;
	    }
	    buf_size += ilen / 4;
	    buf = xrealloc(buf, buf_size, char);
	}
    }
#elif defined(_WIN32) && !defined(HAVE_ICONV_H)
    {
	int nchar;
	int buf_size;
	
	spDebug(80, "xspConvert", "icode = %s, ocode = %s\n",
		conv->icode, conv->ocode);
	
	if (streq(conv->icode, "ACP")) {
	    nchar = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, (LPSTR)input,
					-1, NULL, 0);

	    buf_size = (nchar + 1) * 2;
	    buf = xalloc(buf_size, char);

	    if (MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, (LPSTR)input, 
				    -1, (LPWSTR)buf, nchar) == 0) {
		xfree(buf); buf = NULL;
	    }

	    if (buf != NULL) {
		if (streq(conv->ocode, "UTF-8")) {
		    int obuf_size;
		    char *obuf;
		    
		    if ((obuf_size = spUnicode16ToUTF8((unsigned short *)buf, NULL, 0)) > 0) {
			spDebug(80, "xspConvert", "obuf_size = %d\n", obuf_size);
			obuf = xalloc(obuf_size, char);
			spUnicode16ToUTF8((unsigned short *)buf, (unsigned char *)obuf, obuf_size);

			xfree(buf);
			buf = obuf;
		    }
		}
	    }
	} else {
	    int ibuf_size = 0;
	    char *ibuf;
	    
	    if (streq(conv->icode, "UTF-8")) {
		if ((ibuf_size = spUTF8ToUnicode16((unsigned char *)input, NULL, 0)) <= 0) {
		    return NULL;
		}
		spDebug(80, "xspConvert", "ibuf_size = %d\n", ibuf_size);
		ibuf = xalloc(ibuf_size, char);
		
		spUTF8ToUnicode16((unsigned char *)input,
				  (unsigned short *)ibuf, ibuf_size);
	    } else {
		ibuf = input;
	    }
	    
	    nchar = WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, (LPCWSTR)ibuf,
					-1, NULL, 0, NULL, NULL);
	    
	    buf_size = nchar + 1;
	    buf = xalloc(buf_size, char);
	    
	    if (WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, (LPCWSTR)ibuf, 
				    -1, (LPSTR)buf, nchar, NULL, NULL) == 0) {
		xfree(buf); buf = NULL;
	    }

	    if (ibuf_size > 0) {
		xfree(ibuf);
	    }
	}
    }
#else
    if (conv->cd != (iconv_t)(-1)) {
	int ilen;
	int buf_size;
	size_t isize, osize;
	char *iptr, *optr;

	iptr = input;
	ilen = strlen(iptr);
	isize = ilen;

	buf_size = isize + 1;
	buf = xalloc(buf_size, char);
	
	while (1) {
	    optr = buf;
	    osize = buf_size - 1;
	
	    if (iconv(conv->cd, (const char **)&iptr, &isize, &optr, &osize) == -1) {
		if (errno == E2BIG) {
		    buf_size += osize;
		    buf = xrealloc(buf, buf_size, char);
		} else {
		    xfree(buf); buf = NULL;
		    break;
		}
	    } else {
		*optr = '\0';
		break;
	    }
	    
	    iptr = input;
	    isize = ilen;
	}
    }
#endif

    return buf;
}

void spCloseConverter(spConverter conv)
{
    if (conv == NULL) return;
    
#if defined(MACOS)
    TECDisposeConverter(conv->ec);
#elif defined(_WIN32) && !defined(HAVE_ICONV_H)
#else
    iconv_close(conv->cd);
#endif

    xfree(conv);
    
    return;
}
#endif

double spRound(double x)
{
    double y;

    y = floor(x + 0.5);

    return y;
}

double spFix(double x)
{
#if defined(MACOS) && !powerc
    long double n;
#else
    double n;
#endif
    double y;

    y = modf(x, &n);

    return n;
}

double spFrac(double x)
{
#if defined(MACOS) && !powerc
    long double n;
#else
    double n;
#endif

    return modf(x, &n);
}

double spRem(double x, double y)
{
#if defined(MACOS) && !powerc
    long double n;
#else
    double n;
#endif
    double z;

    z = modf(x / y, &n);
    z = x - n * y;

    return z;
}

long spFactorial(int n)
{
    long k = 1;
    long m;
    
    if (n > 0) {
	m = (long)n;
	while (1) {
	    k *= m;
	    m--;
	    if (m <= 1) {
		break;
	    }
	}
    }

    return k;
}

void spFtos(char *buf, double x)
{
    int j;
    int flag = 0;
    double n;
    double pn;
    double xi;
    char sxi[SP_MAX_LINE];

    if (x == 0.0) {
	strcpy(buf, "0");
    } else {
	pn = floor(log10(fabs(x)));
	n = pow(10.0, pn);

	if (fabs(pn) >= 4) {
	    xi = x / n;
	    flag = 1;
	} else {
	    xi = x;
	}

	sprintf(sxi, "%f", xi);
	for (j = strlen(sxi) - 1; j >= 0; j--) {
	    if (sxi[j] == '.') {
		sxi[j] = NUL;
		break;
	    } else if (sxi[j] == '-' || sxi[j] == '+') {
		sxi[j + 2] = NUL;
		break;
	    } else if (sxi[j] != '0') {
		sxi[j + 1] = NUL;
		break;
	    }
	}

	if (flag == 1) {
	    sprintf(buf, "%se%.0f", sxi, pn);
	} else {
	    sprintf(buf, "%s", sxi);
	}
    }

    return;
}

/*
 *	next power of 2
 */
long spNextPow2(long n)
{
    long p;
    long value;

    for (p = 1;; p++) {
	value = POW2(p);
	if (value >= n) {
	    break;
	}
    }

    return p;
}

spBool spGetTimeString(double sec, spTimeFormat time_format, char *buf)
{
    int frac;
    double hour, minute;
    
    if (buf == NULL) return SP_FALSE;

    switch (time_format) {
      case SP_TIME_FORMAT_POINT:
	sprintf(buf, "%ld", (long)spRound(sec));
	break;
	
      case SP_TIME_FORMAT_SEC:
	sprintf(buf, "%f", sec);
	break;
      case SP_TIME_FORMAT_FLOORED_SEC:
	sprintf(buf, "%.0f", spRound(sec));
	break;

      case SP_TIME_FORMAT_MSEC:
	sprintf(buf, "%.3f", sec * 1000.0);
	break;
      case SP_TIME_FORMAT_FLOORED_MSEC:
	sprintf(buf, "%.0f", spRound(sec * 1000.0));
	break;

      case SP_TIME_FORMAT_SEPARATED_SEC:
      case SP_TIME_FORMAT_FLOORED_SEPARATED_SEC:
	
	hour = floor(sec / 3600.0);
	sec -= hour * 3600.0;
	minute = floor(sec / 60.0);
	sec -= minute * 60.0;

	if (time_format == SP_TIME_FORMAT_SEPARATED_SEC) {
	    frac = (int)spRound(1000000.0 * spFrac(sec));
	    if (frac >= 1000000) {
		frac -= 1000000;
		sec++;
	    }
	    /*spDebug(100, "spGetTimeString", "sec = %f, frac = %d\n", sec, frac);*/
	    sprintf(buf, "%.0f:%02d:%02d.%06d", hour, (int)minute, (int)sec, frac);
	} else {
	    sprintf(buf, "%.0f:%02d:%02d", hour, (int)minute, (int)spRound(sec));
	}
	break;

      default:
	return SP_FALSE;
    }

    return SP_TRUE;
}

spTimeFormat spConvertTimeString(char *buf, spTimeFormat time_format, double *sec)
{
    int nscan;
    int ihour = 0, iminute = 0;
    double value = 0.0;
    double weight = 1.0;
    
    if (strnone(buf) || sec == NULL) return SP_TIME_FORMAT_UNKNOWN;

    if (strchr(buf, ':') != NULL) {
	time_format = SP_TIME_FORMAT_SEPARATED_SEC;
    }
    
    switch (time_format) {
      case SP_TIME_FORMAT_MSEC:
      case SP_TIME_FORMAT_FLOORED_MSEC:
	weight = 1000.0;

      case SP_TIME_FORMAT_POINT:
      case SP_TIME_FORMAT_SEC:
      case SP_TIME_FORMAT_FLOORED_SEC:
	if (sscanf(buf, "%lf", &value) < 1) {
	    return SP_TIME_FORMAT_UNKNOWN;
	}
	*sec = value / weight;
	break;

      case SP_TIME_FORMAT_SEPARATED_SEC:
      case SP_TIME_FORMAT_FLOORED_SEPARATED_SEC:
	if ((nscan = sscanf(buf, "%d:%d:%lf", &ihour, &iminute, &value)) < 1) {
	    return SP_TIME_FORMAT_UNKNOWN;
	} else if (nscan <= 1) {
	    ihour = 0; iminute = 0; value = 0.0;
	    sscanf(buf, "%lf", &value);
	} else if (nscan <= 2) {
	    ihour = 0; iminute = 0; value = 0.0;
	    sscanf(buf, "%d:%lf", &iminute, &value);
	}
	*sec = 3600.0 * (double)ihour + 60.0 * (double)iminute + value;
	/*spDebug(80, "spConvertTimeFormatString", "SEC: buf = %s, sec = %f, value = %f\n", buf, *sec, value);*/
	break;

      default:
	return SP_TIME_FORMAT_UNKNOWN;
    }
    
    return time_format;
}

static void checkTimeFormatStringPrefix(int len, char *format,
					spBool *floored_flag, spBool *separated_flag)
{
    if (len > 0) {
	if (len > 1) {
	    if (format[0] == 'f') {
		*floored_flag = SP_TRUE;
	    } else if (format[0] == 's') {
		*separated_flag = SP_TRUE;
	    }
	    if (format[1] == 'f') {
		*floored_flag = SP_TRUE;
	    } else if (format[1] == 's') {
		*separated_flag = SP_TRUE;
	    }
	} else {
	    if (format[0] == 'f') {
		*floored_flag = SP_TRUE;
	    } else if (format[0] == 's') {
		*separated_flag = SP_TRUE;
	    }
	}
    }

    return;
}

spBool spGetTimeFormatString(spTimeFormat time_format, char *format)
{
    char floored_string[4];
    char separated_string[4];
    char time_string[8];
    
    if (format == NULL) return SP_FALSE;

    if (time_format & SP_TIME_FORMAT_SEPARATED_MASK) {
	strcpy(separated_string, "s");
    } else {
	strcpy(separated_string, "");
    }
    if (time_format & SP_TIME_FORMAT_FLOORED_MASK) {
	strcpy(floored_string, "f");
    } else {
	strcpy(floored_string, "");
    }

    if (time_format & SP_TIME_FORMAT_POINT_MASK) {
	strcpy(time_string, "point");
    } else if (time_format & SP_TIME_FORMAT_MSEC_MASK) {
	strcpy(time_string, "msec");
    } else {
	strcpy(time_string, "sec");
    }
    
    sprintf(format, "%s%s%s", floored_string, separated_string, time_string);

    return SP_TRUE;
}

spBool spConvertTimeFormatString(char *format, spTimeFormat *time_format)
{
    int len;
    spBool msec_flag = SP_FALSE;
    spBool floored_flag = SP_FALSE;
    spBool separated_flag = SP_FALSE;
    
    if (strnone(format) || time_format == NULL) return SP_FALSE;

    len = strlen(format);
    spDebug(50, "spConvertTimeFormatString", "format = %s, len = %d\n", format, len);

    if (len >= 4 && streq(format + (len - 4), "msec")) {
	msec_flag = SP_TRUE;
	checkTimeFormatStringPrefix(len - 4, format, &floored_flag, &separated_flag);
    } else if (len >= 3 && streq(format + (len - 3), "sec")) {
	checkTimeFormatStringPrefix(len - 3, format, &floored_flag, &separated_flag);
    } else if (len >= 1 && streq(format + (len - 1), "m")) {
	msec_flag = SP_TRUE;
	checkTimeFormatStringPrefix(len - 1, format, &floored_flag, &separated_flag);
    } else if (len >= 1 && streq(format + (len - 1), "s")) {
	checkTimeFormatStringPrefix(len - 1, format, &floored_flag, &separated_flag);
    } else if (streq(format, "point")) {
	*time_format = SP_TIME_FORMAT_POINT;
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }

    if (msec_flag == SP_TRUE) {
	*time_format = SP_TIME_FORMAT_MSEC_MASK;
    } else {
	*time_format = SP_TIME_FORMAT_SEC_MASK;
    }
    
    if (floored_flag == SP_TRUE) {
	*time_format |= SP_TIME_FORMAT_FLOORED_MASK;
    }
    if (separated_flag == SP_TRUE) {
	*time_format |= SP_TIME_FORMAT_SEPARATED_MASK;
    }

    return SP_TRUE;
}
