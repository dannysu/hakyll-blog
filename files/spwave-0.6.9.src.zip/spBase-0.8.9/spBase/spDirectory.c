/*
 *	spDirectory.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spDirectory.h>

#if defined(MACOS9)
/*
 * The following part is derived from Marc Parmet's Macintosh port of GNU Emacs.
 */

/*
 * Copyright (C) 1993, 1994 Marc Parmet.
 * This file is part of the Macintosh port of GNU Emacs.
 *
 * GNU Emacs is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
#include <Files.h>

struct _DIR {
    short dd_volumes;
    short dd_vRefNum;
    long dd_drDirID;
    short dd_index;
    struct dirent dd_dirent;
};

DIR * spOpenDir(char *filename)
{
    short err;
    FSSpec fs;
    CInfoPBRec pb;
    DIR *dirp;
    Str255 pstr;

    if (filename == NULL) return NULL;
    
    dirp = xalloc(1, struct _DIR);
    err = MemError();
    if (err) goto panic;

    spStrCToP(filename, pstr);
    err = FSMakeFSSpec(0, 0, pstr, &fs);
    if (err == nsDrvErr) {
	/* Looking at root.  Need to prepare a list of all volumes. */
	err = noErr;
	dirp->dd_volumes = 1;
	dirp->dd_index = 0;
    }
    else if (err == noErr) {
	pb.dirInfo.ioFDirIndex = 0;
	pb.dirInfo.ioNamePtr = fs.name;
	pb.dirInfo.ioVRefNum = fs.vRefNum;
	pb.dirInfo.ioDrDirID = fs.parID;
	err = PBGetCatInfo(&pb,0);
	if (err) goto panic;
	if (!(pb.dirInfo.ioFlAttrib & 0x10)) {
	    /* Not a directory */
	    err = dirNFErr;
	    goto panic;
	}
	
	dirp->dd_volumes = 0;
	dirp->dd_vRefNum = fs.vRefNum;
	dirp->dd_drDirID = pb.dirInfo.ioDrDirID;
	dirp->dd_index = -1;
    }
    
  panic:
    if (err) {
	spDebug(30, "spOpenDir", "Error.\n");
	
	/*SysError(err);*/
	if (dirp != NULL) xfree(dirp);
	return NULL;
    }
    else
	return dirp;
}

int spCloseDir(DIR *dirp)
{
    if (dirp == NULL) return -1;
    
    xfree(dirp);
    return 0;
}

struct dirent *spReadDir(DIR *dirp)
{
    short err;
    CInfoPBRec pb1;
    HParamBlockRec pb2;
    Str255 pstr;
    
    if (dirp == NULL) return NULL;
    
    err = noErr;
    
    if (dirp->dd_volumes) {
	if (dirp->dd_index == 0) {
	    strcpy(dirp->dd_dirent.d_name, ":");
	    ++dirp->dd_index;
	}
	else {
	    pb2.volumeParam.ioVolIndex = dirp->dd_index++;
	    pb2.volumeParam.ioNamePtr = pstr;
	    err = PBHGetVInfo(&pb2,0);
	    if (err) goto panic;
	    spStrPToC(pstr, dirp->dd_dirent.d_name);
	}
    }
    else {
	if (dirp->dd_index == -1) {
	    strcpy(dirp->dd_dirent.d_name,"::");
	    ++dirp->dd_index;
	}
	else if (dirp->dd_index == 0) {
	    strcpy(dirp->dd_dirent.d_name,":");
	    ++dirp->dd_index;
	}
	else {
	    pb1.hFileInfo.ioVRefNum = dirp->dd_vRefNum;
	    pb1.hFileInfo.ioDirID = dirp->dd_drDirID;
	    pb1.hFileInfo.ioFDirIndex = dirp->dd_index++;
	    pb1.hFileInfo.ioNamePtr = pstr;
	    err = PBGetCatInfo(&pb1,0);
	    if (err) goto panic;
	    spStrPToC(pstr, dirp->dd_dirent.d_name);
	}
    }
    
    dirp->dd_dirent.d_namlen = strlen(dirp->dd_dirent.d_name);
    dirp->dd_dirent.d_ino = 1;
    
  panic:
    if (err) {
	spDebug(30, "spReadDir", "Error.\n");
	
	/*SysError(err);*/
	return NULL;
    }
    return &dirp->dd_dirent;
}

#elif defined(_WIN32) && !defined(__CYGWIN32__)
#include <io.h>

struct _DIR {
    char dd_path[SP_MAX_PATHNAME];
    long dd_hfile;
    struct _finddata_t dd_finddata;
    struct dirent dd_dirent;
};

DIR *spOpenDir(char *path)
{
    DIR *dirp;

    if (path == NULL) return NULL;

    dirp = xalloc(1, struct _DIR);
    strcpy(dirp->dd_path, path);
    dirp->dd_hfile = -1;
    dirp->dd_dirent.d_ino = 1;
    dirp->dd_dirent.d_namlen = 0;
    dirp->dd_dirent.d_name[0] = NUL;

    return dirp;
}

int spCloseDir(DIR *dirp)
{
    if (dirp == NULL) return -1;

    if (dirp->dd_hfile != -1) {
	_findclose(dirp->dd_hfile);
    }
    xfree(dirp);
    
    return 0;
}

struct dirent *spReadDir(DIR *dirp)
{
    char filename[SP_MAX_PATHNAME];
    
    if (dirp == NULL) return NULL;

    if (dirp->dd_hfile == -1) {
	sprintf(filename, "%s%c*", dirp->dd_path, SP_DIR_SEPARATOR);
	
	if ((dirp->dd_hfile = _findfirst(filename, &dirp->dd_finddata)) == -1) {
	    return NULL;
	}
    } else {
	if (_findnext(dirp->dd_hfile, &dirp->dd_finddata) != 0) {
	    return NULL;
	}
    }

    strcpy(dirp->dd_dirent.d_name, dirp->dd_finddata.name);
    dirp->dd_dirent.d_namlen = strlen(dirp->dd_dirent.d_name);

    return &dirp->dd_dirent;
}

#else
#include <dirent.h>

DIR *spOpenDir(char *path)
{
    if (path == NULL) return NULL;

    return opendir(path);
}

struct dirent *spReadDir(DIR *dirp)
{
    if (dirp == NULL) return NULL;

    return readdir(dirp);
}

int spCloseDir(DIR *dirp)
{
    if (dirp == NULL) return -1;

    return closedir(dirp);
}
#endif
