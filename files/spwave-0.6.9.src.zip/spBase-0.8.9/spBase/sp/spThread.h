/*
 *	spThread.h
 */

#ifndef __SPTHREAD_H
#define __SPTHREAD_H

#include <sp/spDefs.h>

#if defined(_WIN32) && !defined(HAVE_PTHREAD)
#include <windows.h>
#if defined(_MSC_VER)
#include <process.h>
#define HAVE_BEGINTHREADEX
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_THREAD_PRIORITY_TIME_CRITICAL 15
#define SP_THREAD_PRIORITY_HIGHEST 2
#define SP_THREAD_PRIORITY_ABOVE_NORMAL 1
#define SP_THREAD_PRIORITY_NORMAL 0
#define SP_THREAD_PRIORITY_BELOW_NORMAL (-1)
#define SP_THREAD_PRIORITY_LOWEST (-2)
#define SP_THREAD_PRIORITY_IDLE (-15)

#define SP_THREAD_EXIT_SUCCESS 0
#define SP_THREAD_EXIT_FAILURE -2
#define SP_THREAD_EXIT_CANCELED -1

typedef enum {
    SP_THREAD_LEVEL_LOW = 0,
    SP_THREAD_LEVEL_BELOW_MIDDLE = 25,
    SP_THREAD_LEVEL_MIDDLE = 50,
    SP_THREAD_LEVEL_ABOVE_MIDDLE = 75,
    SP_THREAD_LEVEL_HIGH = 100,
} spThreadLevel;

#if defined(_WIN32) && !defined(HAVE_PTHREAD)
#if defined(HAVE_BEGINTHREADEX)
/*typedef unsigned __stdcall spThreadReturn;*/
#define spThreadReturn unsigned __stdcall
typedef unsigned (__stdcall *spThreadFunc)(void *data);
#else
#define spThreadReturn DWORD WINAPI
typedef DWORD (WINAPI *spThreadFunc)(void *data);
#endif

#define SP_THREAD_RETURN_SUCCESS 0
#define SP_THREAD_RETURN_FAILURE 1

#else
/* definition for pthread and MacOS */
#define spThreadReturn void *
typedef void *(*spThreadFunc)(void *data);

#define SP_THREAD_RETURN_SUCCESS (void *)0
#define SP_THREAD_RETURN_FAILURE (void *)1
#endif

    
typedef enum {
    SP_COMMAND_THREAD_STARTED = 0, 		/* data: 0 */
    SP_COMMAND_THREAD_FINISHED = 1,		/* data: 0 */
    SP_COMMAND_THREAD_COMMAND_FINISHED = 2, 	/* data: command exit code */
    SP_COMMAND_THREAD_COMMAND_FAILED = 3, 	/* data: errno */
    SP_COMMAND_THREAD_COMMAND_WAIT_FAILED = 4, 	/* data: errno */
} spCommandThreadStatus;

typedef void (*spCommandThreadCallback)(spCommandThreadStatus status, long data, void *user_data);

    
#if defined(MACOS)
#pragma import on
#endif

extern void *spCreateThread(long stacksize, int priority, spThreadFunc func, void *data);
extern void spDestroyThread(void *handle);
extern void spExitThread(long status);
extern void spYieldThread(void);
extern long spWaitThread(void *handle);
extern void *spCreateMutex(char *name);
extern void spDestroyMutex(void *handle);
extern spBool spLockMutex(void *handle);
extern spBool spUnlockMutex(void *handle);
extern spBool spWaitMutex(void *handle);
    
extern spBool spIsThreadLevelVariable(void);
extern spBool spIsLowLevelThreadUsed(void);
extern spBool spSetThreadLevel(spThreadLevel level);
extern spThreadLevel spGetThreadLevel(void);
    
extern spBool spCreateCommandThread(char *command, spCommandThreadCallback func, void *data);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTHREAD_H */
