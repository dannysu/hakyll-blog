/*
 *	spLibrary.h
 */

#ifndef __SPLIBRARY_H
#define __SPLIBRARY_H

#include <sp/spDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void *spOpenLibrary(char *filename);
extern void *spGetSymbolAddress(void *handle, char *symbol);
extern void spCloseLibrary(void *handle);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIBRARY_H */
