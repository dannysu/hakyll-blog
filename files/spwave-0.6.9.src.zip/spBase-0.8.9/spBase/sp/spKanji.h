/*
 *	spKanji.h
 */

#ifndef __SPKANJI_H
#define __SPKANJI_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SP_KANJI_CODE_UNKNOWN = -1,
    SP_KANJI_CODE_JIS = 0,
    SP_KANJI_CODE_EUC = 1,
    SP_KANJI_CODE_SJIS = 2,
    SP_KANJI_CODE_ZENKAKU_SJIS = 3,
    SP_KANJI_CODE_ZENKAKU_JIS = 4,
    SP_KANJI_CODE_ZENKAKU_EUC = 5,
} spKanjiCode;

#define SP_KANJI_CODE_CURRENT SP_KANJI_CODE_UNKNOWN

#if defined(_WIN32) || defined(MACOS)
#define SP_KANJI_CODE_DEFAULT SP_KANJI_CODE_SJIS
#else
#define SP_KANJI_CODE_DEFAULT SP_KANJI_CODE_EUC
#endif
#if (defined(_WIN32) && !defined(__CYGWIN32__)) || defined(MACOS)
#define SP_KANJI_CODE_INTERNAL SP_KANJI_CODE_SJIS
#else
#define SP_KANJI_CODE_INTERNAL SP_KANJI_CODE_EUC
#endif

#if defined(MACOS)
#pragma import on
#endif

extern int spSetKanjiOptions(int n, char **options);
extern void spKanjiUsage(char *name);
extern void spDecodeMime(int flag);
extern void spSetDefaultKanjiCode(spKanjiCode code);
extern void spSetKanjiCode(spKanjiCode icode, spKanjiCode ocode);
extern spKanjiCode spGetKanjiCode(void);
extern char *spGetKanjiCodeLabel(spKanjiCode code);
extern spKanjiCode spGetLocaleKanjiCode(char *lang);

/* converted buffer always terminated with null */
extern spKanjiCode spConvertKanji(unsigned char *lin, unsigned char *lout, int size);
extern spKanjiCode spConvertKanjiCode(unsigned char *lin, unsigned char *lout,
				      int size, spKanjiCode ocode);
extern spKanjiCode spConvertKanjiFromLocaleCode(unsigned char *iobuf, int size, spKanjiCode ocode);
extern spKanjiCode spConvertKanjiToLocaleCode(unsigned char *iobuf, int size, spKanjiCode icode);
    

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPKANJI_H */
