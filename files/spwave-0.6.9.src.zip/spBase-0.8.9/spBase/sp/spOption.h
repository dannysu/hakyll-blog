/*
 *	spOption.h
 */

#ifndef __SPOPTION_H
#define __SPOPTION_H

#include <stdarg.h>

#include <sp/spDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_USAGE_LABEL_STRING "???"
    
#define SP_MAX_SETUP_LINE 	512
#define SP_MAX_SETUP_NAME 	128
#define SP_MAX_SETUP_VALUE 	256

#define SP_UNKNOWN 	(-1)

#define SP_MAX_EXIT_CALLBACK 	16
typedef void (*spExitFunc)(int status);

typedef void *spExitCallbackData;
typedef void (*spExitCallbackFunc)(spExitCallbackData);
    
typedef unsigned short spOptionType;

#define SP_TYPE_NONE 	0
#define SP_TYPE_BOOL	1
#define SP_TYPE_STRING 	2
#define SP_TYPE_INT 	3
#define SP_TYPE_SHORT 	4
#define SP_TYPE_LONG 	5
#define SP_TYPE_FLOAT	6
#define SP_TYPE_DOUBLE 	7
#define SP_TYPE_CHAR 	8
#define SP_TYPE_STRING_A 9	/* string array */
#define SP_TYPE_ENUM 	10
#define SP_TYPE_USER	16
#define SP_TYPE_BOOLEAN	SP_TYPE_BOOL
#define SP_TYPE_STRING_S SP_TYPE_STRING_A

#define SP_TYPE_EDITABLE (1<<8)
#define SP_TYPE_LIST (1<<9)
#define SP_TYPE_COMBO (1<<10)
#define SP_TYPE_TOGGLE (1<<11)
#define SP_TYPE_SHOW_TIP (1<<12)

#define SpNullOption(flag, subflag, type) {flag, subflag, NULL, NULL, type, NULL, NULL}

typedef struct _spOption spOption;
typedef struct _spOptions *spOptions;

struct _spOption {
    char *flag;		/* option flag */
    char *subflag;	/* option subflag */
    char *desc;		/* description for help */
    char *label;	/* label for setup file */
    spOptionType type;	/* type of value */
    void *value;	/* option value */
    char *def_value;	/* default value */
};

#if defined(MACOS)
#pragma import on
#endif

extern spBool spEqType(spOptionType type1, spOptionType type2);
extern void spIgnoreUnknownOption(spOptions options, spBool flag);
extern int spGetNumOption(spOptions options);
extern spOption *spGetOptionList(spOptions options);
extern char *xspCutOptionValue(char *value, int index);
extern int spConvertOptionValue(spOption *option, char *value);
extern spOptions spAllocOptions(int num_option, spOption *option_list);
extern spOptions spCopyOptions(int num_option, spOption *option_list);
extern void _spFreeOptions(spOptions options);
extern spOptions _spGetOptions(int argc, char **argv, int num_option, spOption *option_list,
			       int num_file, char **labels);
extern void spSetSection(spOptions options, int section);
extern void spSetSetup(char *filename);
extern void spWriteGlobalSetup(void);
extern spBool spAddExitCallback(spExitCallbackFunc callback, void *data);
extern spBool spRemoveExitCallback(spExitCallbackFunc callback, void *data);
extern void spExit(int status);
extern char *spGetOptionValue(int argc, char **argv, spOptions options);
extern void spGetOptionsValue(int argc, char **argv, spOptions options);
extern void spUpdateOptionsValue(int argc, char **argv, spOptions options);
extern void spCheckNumFile(spOptions options);
extern char *spGetFile(spOptions options);
extern char *xspGetOptionLabel(spOption *option, int index);
extern void spSetOptionDescOffset(int offset);
extern void spSetHelpMessage(spBool *flag, char *format, ...);
extern void spPrintHelpHeader(char *format, ...);
extern void spPrintHelp(char *format, ...);
extern void spPrintError(char *format, ...);
extern void spReadSetup(char *filename, spOptions options);
extern void spWriteSetup(char *filename, spOptions options);
extern spBool spPrintOption(spOption *option);
extern spBool spPrintOptions(spOptions options);
extern void spPrintUsageHeader(void);
extern void spPrintUsage(void);
extern void spUsage(void);

/* Do not use the following function. This is for internal use. */
extern spBool spSetExitFunc(spExitFunc func);

#if defined(MACOS)
#pragma import off
#endif

#define spFreeOptions(options) {_spFreeOptions(options); (options) = NULL;}
#define spGetOptions(argc, argv, option, argfile) \
_spGetOptions(argc, argv, spArraySize(option), option, spArraySize(argfile), argfile)
    
/*#define spEqType(type1, type2) (((0xff & type1) == (0xff & type2)) ? 1 : 0)*/
#define spStrToBool(value) (((*(value) == 'T') || spStrEq(value, "1") || spStrEq(value, "ON") || spStrEq(value, "On")) ? SP_TRUE : SP_FALSE)
#define spBoolToStr(value) (((value) == SP_TRUE) ? "True" : "False")

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPOPTION_H */
