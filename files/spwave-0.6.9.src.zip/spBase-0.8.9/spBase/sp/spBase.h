/*
 *	spBase.h
 */

#ifndef __SPBASE_H
#define __SPBASE_H

#include <sp/spDefs.h>
#include <sp/spMemory.h>
#if defined(MACOSX)
#include <CoreServices/CoreServices.h>
#elif defined(MACOS)
#include <Files.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*spPrintFunc)(char *message);
    
typedef struct _spConverter *spConverter;

typedef enum {
    SP_FILE_KIND_UNKNOWN = -1,
    SP_FILE_KIND_DOCUMENT = 0,
    SP_FILE_KIND_SOURCE = 1,	/* source files */
    SP_FILE_KIND_CONFIG = 2,	/* configure files */
    SP_FILE_KIND_INCLUDE = 3,	/* include files */
    SP_FILE_KIND_PICTURE = 10,	/* pictures, images */
    SP_FILE_KIND_FIGURE = 11,	/* figures */
    SP_FILE_KIND_MUSIC = 20,	/* MIDI, songs */
    SP_FILE_KIND_SOUND = 21,	/* other sound stuff */
    SP_FILE_KIND_MOVIE = 25,	
    SP_FILE_KIND_APPLICATION = 30,
    SP_FILE_KIND_LIBRARY = 31,
    SP_FILE_KIND_ARCHIVE = 40,
    SP_FILE_KIND_URI = 50,	/* HTML files */
} spFileKind;

#define SP_TIME_FORMAT_MSEC_MASK (1<<0)
#define SP_TIME_FORMAT_SEC_MASK (1<<1)
#define SP_TIME_FORMAT_POINT_MASK (1<<2)
#define SP_TIME_FORMAT_FLOORED_MASK (1<<9)
#define SP_TIME_FORMAT_SEPARATED_MASK (1<<10)
#define SP_TIME_FORMAT_USER1_MASK (1<<12)
#define SP_TIME_FORMAT_USER2_MASK (1<<13)
#define SP_TIME_FORMAT_USER3_MASK (1<<14)
#define SP_TIME_FORMAT_USER4_MASK (1<<15)

typedef enum {
    SP_TIME_FORMAT_UNKNOWN = 0,
    SP_TIME_FORMAT_MSEC = SP_TIME_FORMAT_MSEC_MASK,
    SP_TIME_FORMAT_FLOORED_MSEC = (SP_TIME_FORMAT_FLOORED_MASK|SP_TIME_FORMAT_MSEC_MASK),
    
    SP_TIME_FORMAT_SEC = SP_TIME_FORMAT_SEC_MASK,
    SP_TIME_FORMAT_FLOORED_SEC = (SP_TIME_FORMAT_FLOORED_MASK|SP_TIME_FORMAT_SEC_MASK),
    /* hh:mm:ss.ssssss */    
    SP_TIME_FORMAT_SEPARATED_SEC = (SP_TIME_FORMAT_SEPARATED_MASK|SP_TIME_FORMAT_SEC_MASK),
    /* hh:mm:ss */    
    SP_TIME_FORMAT_FLOORED_SEPARATED_SEC = (SP_TIME_FORMAT_FLOORED_MASK|SP_TIME_FORMAT_SEPARATED_MASK|SP_TIME_FORMAT_SEC_MASK),
    
    SP_TIME_FORMAT_POINT = SP_TIME_FORMAT_POINT_MASK,

    SP_TIME_FORMAT_USER1 = SP_TIME_FORMAT_USER1_MASK,
    SP_TIME_FORMAT_USER2 = SP_TIME_FORMAT_USER2_MASK,
    SP_TIME_FORMAT_USER3 = SP_TIME_FORMAT_USER3_MASK,
    SP_TIME_FORMAT_USER4 = SP_TIME_FORMAT_USER4_MASK,
} spTimeFormat;


#if defined(MACOS)
#pragma import on
#endif

extern void spSetStdinHandle(FILE *fp);
extern void spSetStdoutHandle(FILE *fp);
extern void spSetStderrHandle(FILE *fp);
extern void spSetPrintFunc(spPrintFunc func);
extern void spPrint(char *message, FILE *fp);
extern void spSetWarningFlag(int flag);
extern void spWarning(char *format, ...);
extern void spSetMessageFlag(int flag);
extern void spMessage(char *format, ...);
extern void spError(int status, char *format, ...);
extern void spProgError(char *func_name, char *format, ...);
extern void spSetDebugStdout(int flag);
extern void spSetDebugLevel(int level);
extern int spGetDebugLevel(void);
extern void spDebug(int level, char *func_name, char *format, ...);

extern void spSleep(int sec);
extern void spMSleep(int msec);
extern int spStrCaseCmp(char *s1, char *s2);
extern int spStrNCaseCmp(char *s1, char *s2, int n);
extern int spStrWhite(char *string);
extern char *xspStrCat(char *dest, char *src);
extern char *spStrCat(char *dest, int destsize, char *src); /* dest is always terminated with '\0' regardless of src's length */
extern char *spStrCopy(char *dest, int destsize, char *src); /* dest is always terminated with '\0' regardless of src's length */
extern char *spGetSuffix(char *name);
extern int spEqSuffix(char *file1, char *file2);
extern spBool spRemoveSuffix(char *path, char *suffix);
extern spBool spReplaceSuffix(char *path, char *suffix);
extern void spStrPToC(unsigned char *in_p, char *out_c);
extern void spStrCToP(char *in_c, unsigned char *out_p);
extern void spCopyPStr(unsigned char *source, unsigned char *dest);
extern void spCatPStr(unsigned char *target, unsigned char *source);
extern spBool spGetMacFileInfo(char *filename, unsigned long *creator, unsigned long *file_type);
extern spBool spSetMacFileInfo(char *filename, unsigned long creator, unsigned long file_type);

extern FILE *spOpenFile(char *path, char *mode);
extern int spCloseFile(FILE *stream);
extern spBool spAddDirSeparator(char *dir);
extern spBool spRemoveDirSeparator(char *dir);
extern spBool spGetFileInfo(char *path, spBool *dir_flag, long *size);
extern spBool spIsExist(char *path);
extern spBool spIsFile(char *path);
extern spBool spIsDir(char *path);
extern spBool spCreateDir(char *path, unsigned short mode);
extern spBool spRemoveDir(char *path);
extern spBool spRemoveFile(char *path);
extern spBool spRenameFile(char *oldpath, char *newpath);
extern char *spGetBaseName(char *name);
extern char *xspGetBaseName(char *name);
extern char *spGetDirName(char *filename);
extern char *xspGetDirName(char *filename);
extern char *xspGetReadablePath(char *real_path);
extern char *xspGetRealPath(char *readable_path);

extern char *spGetCurrentDir(void);
extern char *xspGetCurrentDir(void);
extern char *spGetDefaultDir(void);
extern char *spGetHomeDir(void);
extern char *xspGetHomeDir(void);
extern char *spGetTempDir(void);
extern char *xspGetTempDir(void);

extern spBool spSetApplicationId(char *id);
extern char *spGetCompanyId(void);
extern char *spGetApplicationId(void);
extern char *spGetVersionId(void);
extern char *spCreateApplicationDir(spBool *id_depend, spBool *version_depend);
extern char *spGetApplicationDir(spBool *version_depend);
extern char *xspGetApplicationDir(spBool *version_depend);
extern char *spGetApplicationTempDir(void);
extern char *xspGetApplicationTempDir(void);
extern spBool spSetApplicationTempDir(char *dir);
extern char *xspGetDocumentDir(spFileKind file_kind);

extern spBool spIsExactName(char *name);
extern char *xspGetExactName(char *name);
extern char *xspCutPathList(char *pathlist, int col);
extern long spGetProcessId(void);
extern spBool spEqLanguage(char *lang1, char *lang2);
extern spBool spIsJapaneseLang(char *lang);
extern spBool spIsMBTailCandidate(int prev_c, int c);

extern int spUnicode16ToUTF8(unsigned short *unicode, unsigned char *buf, int buf_size);
extern int spUTF8ToUnicode16(unsigned char *utf8, unsigned short *buf, int buf_size);
extern spConverter spOpenConverter(char *icode, char *ocode);
extern char *xspConvert(spConverter conv, char *input);
extern void spCloseConverter(spConverter conv);
    
extern double spRound(double x);
extern double spFix(double x);
extern double spFrac(double x);
extern double spRem(double x, double y);
extern long spFactorial(int n);
extern void spFtos(char *buf, double x);
extern long spNextPow2(long n);

extern spBool spGetTimeString(double sec, spTimeFormat time_format, char *buf);
extern spTimeFormat spConvertTimeString(char *buf, spTimeFormat time_format, double *sec);
extern spBool spGetTimeFormatString(spTimeFormat time_format, char *format);
extern spBool spConvertTimeFormatString(char *format, spTimeFormat *time_format);

#if defined(MACOS)
extern spBool spFSSpecToExactNameMac(FSSpec *fsspec, char *filename);

#pragma import off
#endif

#define spStrCaseEq(s1, s2) ((s1 != NULL) && (s2 != NULL) && (spStrCaseCmp((s1), (s2)) == 0) ? 1 : 0)
#define spStrNCaseEq(s1, s2, n) ((s1 != NULL) && (s2 != NULL) && (spStrNCaseCmp((s1), (s2), n) == 0) ? 1 : 0)
#define spStrVCaseEq(s1, s2) ((s1 != NULL) && (s2 != NULL) && (spStrNCaseCmp((s1), (s2), strlen(s2)) == 0) ? 1 : 0)
#ifndef strcaseeq
#define strcaseeq spStrCaseEq
#endif
#ifndef strncaseeq
#define strncaseeq spStrNCaseEq
#endif
#ifndef strvcaseeq
#define strvcaseeq spStrVCaseEq
#endif

#ifndef strwhite
#define strwhite spStrWhite
#endif

#ifndef xstrcat
#define xstrcat xspStrCat
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPBASE_H */
