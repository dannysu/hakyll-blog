/*
 *	spMain.h
 */

#ifndef __SPMAIN_H
#define __SPMAIN_H

#ifdef __cplusplus
extern "C" {
#endif
    
#if defined(MACOS)

#pragma import on
int spMain(int argc, char *argv[]);
#pragma import off

int main(int argc, char *argv[])
{
#if !TARGET_API_MAC_CARBON
    MaxApplZone();
#endif
    return spMain(argc, argv);
}

#else
#define spMain main
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMAIN_H */
