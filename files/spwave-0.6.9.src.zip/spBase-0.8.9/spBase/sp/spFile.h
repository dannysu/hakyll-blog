/*
 *	spFile.h
 */

#ifndef __SPFILE_H
#define __SPFILE_H

#include <sp/spDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern long getfilesize(char *filename, int headsize);
extern long getfilesize_txt(char *filename);
extern void fskipheader(long headsize, FILE *fp);
extern long fskipbyte(long len, FILE *fp);

extern void shiftshort(short *data, long length, long shift);
extern void shiftlong(long *data, long length, long shift);
extern void shiftfloat(float *data, long length, long shift);
extern void shiftdouble(double *data, long length, long shift);
    
extern void swapshort(short *data, long length);
extern void swaplong(long *data, long length);
extern void swaplong32(spLong32 *data, long length);
extern void swapfloat(float *data, long length);
extern void swapdouble(double *data, long length);

extern long freadshort(short *data, long length, int swap, FILE *fp);
extern long freadlong(long *data, long length, int swap, FILE *fp);
extern long freadlong32(long *data, long length, int swap, FILE *fp);
extern long freadlong24(long *data, long length, int swap, FILE *fp);
extern long freadfloat(float *data, long length, int swap, FILE *fp);
extern long freaddouble(double *data, long length, int swap, FILE *fp);
extern long freadbyte(short *data, long length, FILE *fp);
extern long freadsbyte(short *data, long length, FILE *fp);
extern long freadulaw(short *data, long length, FILE *fp);
extern long freadalaw(short *data, long length, FILE *fp);
extern long freadshorttod(double *data, long length, int swap, FILE *fp);
extern long freadlongtod(double *data, long length, int swap, FILE *fp);
extern long freadfloattod(double *data, long length, int swap, FILE *fp);
extern long fwriteshort(short *data, long length, int swap, FILE *fp);
extern long fwritelong(long *data, long length, int swap, FILE *fp);
extern long fwritelong32(long *data, long length, int swap, FILE *fp);
extern long fwritelong24(long *data, long length, int swap, FILE *fp);
extern long fwritefloat(float *data, long length, int swap, FILE *fp);
extern long fwritebyte(short *data, long length, FILE *fp);
extern long fwritesbyte(short *data, long length, FILE *fp);
extern long fwriteulaw(short *data, long length, FILE *fp);
extern long fwritealaw(short *data, long length, FILE *fp);
extern long fwritedouble(double *data, long length, int swap, FILE *fp);
extern long fwritedoubletos(double *data, long length, int swap, FILE *fp);
extern long fwritedoubletol(double *data, long length, int swap, FILE *fp);
extern long fwritedoubletof(double *data, long length, int swap, FILE *fp);
extern long fwritelong32tos(long *data, long length, int swap, FILE *fp);
extern long fwritelong24tos(long *data, long length, int swap, FILE *fp);

extern int getnumrow(char *filename);
extern int getnumcol(char *filename);
extern int fgetncol(char *buf, int size, int col, FILE *fp);
extern int fgetcol(char *buf, int col, FILE *fp);
extern int sgetncol(char *buf, int size, int col, char *line);
extern int sgetcol(char *buf, int col, char *line);
extern char *sgetnextncol(char *buf, int size, char *line);
extern int fgetnline(char *buf, int size, FILE *fp);
extern int fgetline(char *buf, FILE *fp);
extern int getline(char *buf);
extern int fputline(char *buf, FILE *fp);
extern int fputstring(char *buf, FILE *fp);
extern int sputstring(char *buf, char *line, int size);
extern char *fgetsn(char *buf, int size, FILE *fp);
extern char *getsn(char *buf, int size);
extern char *sgetsn(char *buf, int size, char *string);
extern int sscansetup(char *line, char *name, char *value);

extern unsigned char linear2alaw(int pcm_val);
extern int alaw2linear(unsigned char a_val);
extern unsigned char linear2ulaw(int pcm_val);
extern int ulaw2linear(unsigned char u_val);
extern unsigned char alaw2ulaw(unsigned char aval);
extern unsigned char ulaw2alaw(unsigned char uval);

#if defined(MACOS)
#pragma import off
#endif

#define getsiglen(filename, headsize, type) (getfilesize(filename, headsize) / (long)sizeof(type))
#define fskipdata(len, fp, type) (fskipbyte((len) * (long)sizeof(type), fp) / (long)sizeof(type))

/* for backwards compatibility */
#define skipheader fskipheader
#define skipbyte fskipbyte
#define skipdata fskipdata

#define getnumrow_txt getnumrow
#define getnumcol_txt getnumcol

#define fgetcol_txt fgetcol
#define sgetcol_txt sgetcol

#define gets0 getsn

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFILE_H */
