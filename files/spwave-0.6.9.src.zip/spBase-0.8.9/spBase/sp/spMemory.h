/*
 *	spMemory.h
 */

#ifndef __SPMEMORY_H
#define __SPMEMORY_H

#ifdef MACOS
#include <Memory.h>
#endif
#include <stdlib.h>

#include <sp/spDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef MACOS
#undef SP_USE_MAC_MEMORY
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spSetMemoryErrorExit(int flag);
extern char *xspMalloc(int nbytes);
extern char *xspRemalloc(char *p, int nbytes);
extern void _xspFree(char *p);

extern int **xspIMatAlloc(int row, int col);
extern void xspIMatFree(int **mat, int row);
extern short **xspSMatAlloc(int row, int col);
extern void xspSMatFree(short **mat, int row);
extern long **xspLMatAlloc(int row, int col);
extern void xspLMatFree(long **mat, int row);
extern float **xspFMatAlloc(int row, int col);
extern void xspFMatFree(float **mat, int row);
extern double **xspDMatAlloc(int row, int col);
extern void xspDMatFree(double **mat, int row);

extern char *xspStrClone(char *string);

#if defined(MACOS)
#pragma import off
#endif

#define xspAlloc(n, type) (type *)xspMalloc((int)(n)*sizeof(type))
#define xspRealloc(p, n, type) (type *)xspRemalloc((char *)(p), (int)(n)*sizeof(type))
#define xspFree(p) {_xspFree((char *)(p)); (p) = NULL;}

#define spStrReplace(s1, s2) {if ((s1) != NULL) xspFree(s1); (s1) = (((s2) != NULL) ? xspStrClone(s2) : NULL);}
#define spArrayCopy(p1, p2, n, type) memmove((char *)(p1), (char *)(p2), (unsigned)(n)*sizeof(type))

#ifndef xalloc
#define xalloc xspAlloc
#endif
#ifndef xrealloc
#define xrealloc xspRealloc
#endif
#ifndef xfree
#define xfree xspFree
#endif

#ifndef strclone
#define strclone xspStrClone
#endif
#ifndef strrepl
#define strrepl spStrReplace
#endif
#ifndef arrcpy
#define arrcpy spArrayCopy
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMEMORY_H */
