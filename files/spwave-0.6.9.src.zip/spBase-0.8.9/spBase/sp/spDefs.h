/*
 *	spDefs.h
 */

#ifndef __SPDEFS_H
#define __SPDEFS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SPB_VERSION_STRING	"0.8.9"
#define SPB_VERSION 		0
#define SPB_REVISION		8
#define SPB_UPDATE_LEVEL	9
#define SPB_VERSION_ID		(SPB_VERSION * 1000 + SPB_REVISION)

#define SPB_CHECK_VERSION(version, revision, update) \
    (SPB_VERSION > (version) || \
     (SPB_VERSION == (version) && SPB_REVISION > (revision)) || \
     (SPB_VERSION == (version) && SPB_REVISION == (revision) && SPB_UPDATE_LEVEL >= (update)))
    
typedef int (*spMainFunc)(int argc, char *argv[]);

#if (TARGET_RT_MAC_MACHO || defined(__APPLE__)) && !defined(MACOSX)
#define MACOSX
#endif

#ifdef MACOSX
#ifndef HIGH_LEVEL_EVENT
#define HIGH_LEVEL_EVENT
#endif
#ifndef TARGET_API_MAC_CARBON
#define TARGET_API_MAC_CARBON 1
#endif
#ifndef MACOS
#define MACOS
#endif
#ifndef powerc
#define powerc 1
#endif
#endif
    
#ifndef MACOS
#if (defined(__MWERKS__) && defined(macintosh)) || defined(applec) || defined(__MRC__) ||\
    defined(THINK_C) || defined(__SC__) || defined(TARGET_OS_MAC)
#define MACOS
#if !defined(powerc) && defined(__MRC__)
#define powerc 1
#endif
#endif
#endif
	
#if defined(MACOS) && !defined(MACOSX)
#define MACOS9
#endif
    
#ifndef __P
#if __STDC__
#define __P(args) args
#else
#define __P(args) ()
#endif
#endif

#ifndef LITTLE_ENDIAN
#define LITTLE_ENDIAN 1234
#endif
#ifndef BIG_ENDIAN
#define BIG_ENDIAN 4321
#endif
    
#if !defined(BYTE_ORDER)
#if defined(__i386__) || defined(__alpha__) || defined(__alpha) \
    || defined(_M_IX86) || defined(_M_ALPHA) \
    || (defined(__mips__) && (defined(MIPSEL) || defined (__MIPSEL__)))
#define BYTE_ORDER 1234
#else
#define BYTE_ORDER 4321
#endif
#endif

#if defined(__alpha__) || defined(__alpha)
#define spLong32 int
#else
#define spLong32 long
#endif

#if defined(_WIN32) && !defined(__CYGWIN32__)
#define access _access	
#define mkdir _mkdir
#define unlink _unlink
#define getcwd _getcwd
#define getpid _getpid
#endif
	
#if defined(sun) && !defined(HAVE_MEMCPY)
#define memmove(dst,src,len) bcopy((char *)(src),(char *)(dst),(int)(len))
#define memcpy(dst,src,len) bcopy((char *)(src),(char *)(dst),(int)(len))
#define memcmp(b1,b2,len) bcmp((char *)(b1),(char *)(b2),(int)(len))
#endif
	
#define SP_MAX_NAME	128
#define SP_MAX_LINE	192
#define SP_MAX_PATHNAME	256
#define SP_MAX_MESSAGE	1024
#define SP_MAX_SUFFIX_SIZE 8
#define SP_MAX_LANGUAGE 32	/* for locale */
#define SP_EPSILON	1.0e-10
#define SP_ALITTLE_NUMBER SP_EPSILON

typedef int spBool;

#define SP_TRUE  	1
#define SP_FALSE 	0
#define SP_TRUE_STRING	"1"
#define SP_FALSE_STRING	"0"

#define SP_ON  		SP_TRUE
#define SP_OFF 		SP_FALSE
#define SP_SUCCESS 	1
#define SP_FAILURE 	0
#define SP_EXIT_SUCCESS 0
#define SP_EXIT_FAILURE 1

#define SP_WIN_DIR_SEPARATOR '\\'
#define SP_WIN_DIR_SEPARATOR_STRING "\\"
#define SP_UNIX_DIR_SEPARATOR '/'
#define SP_UNIX_DIR_SEPARATOR_STRING "/"
#define SP_MAC_DIR_SEPARATOR ':'
#define SP_MAC_DIR_SEPARATOR_STRING ":"

#define SP_WIN_PARENT_DIR_STRING ".."
#define SP_WIN_CURRENT_DIR_STRING "."
#define SP_UNIX_PARENT_DIR_STRING ".."
#define SP_UNIX_CURRENT_DIR_STRING "."
#define SP_MAC_PARENT_DIR_STRING "::"
#define SP_MAC_CURRENT_DIR_STRING ":"

#define SP_WIN_SEPARATED_PARENT_DIR_STRING "..\\"
#define SP_WIN_SEPARATED_CURRENT_DIR_STRING ".\\"
#define SP_UNIX_SEPARATED_PARENT_DIR_STRING "../"
#define SP_UNIX_SEPARATED_CURRENT_DIR_STRING "./"
#define SP_MAC_SEPARATED_PARENT_DIR_STRING "::"
#define SP_MAC_SEPARATED_CURRENT_DIR_STRING ":"

#if defined(_WIN32)
#if !defined(__CYGWIN32__)
#define SP_DIR_SEPARATOR SP_WIN_DIR_SEPARATOR
#define SP_DIR_SEPARATOR_STRING SP_WIN_DIR_SEPARATOR_STRING
#define SP_PARENT_DIR_STRING SP_WIN_PARENT_DIR_STRING
#define SP_CURRENT_DIR_STRING SP_WIN_CURRENT_DIR_STRING
#define SP_SEPARATED_PARENT_DIR_STRING SP_WIN_SEPARATED_PARENT_DIR_STRING
#define SP_SEPARATED_CURRENT_DIR_STRING SP_WIN_SEPARATED_CURRENT_DIR_STRING
#define SP_ANOTHER_DIR_SEPARATOR SP_UNIX_DIR_SEPARATOR
#define SP_ANOTHER_DIR_SEPARATOR_STRING SP_UNIX_DIR_SEPARATOR_STRING
#else
#define SP_DIR_SEPARATOR SP_UNIX_DIR_SEPARATOR
#define SP_DIR_SEPARATOR_STRING SP_UNIX_DIR_SEPARATOR_STRING
#define SP_PARENT_DIR_STRING SP_UNIX_PARENT_DIR_STRING
#define SP_CURRENT_DIR_STRING SP_UNIX_CURRENT_DIR_STRING
#define SP_SEPARATED_PARENT_DIR_STRING SP_UNIX_SEPARATED_PARENT_DIR_STRING
#define SP_SEPARATED_CURRENT_DIR_STRING SP_UNIX_SEPARATED_CURRENT_DIR_STRING
#define SP_ANOTHER_DIR_SEPARATOR SP_WIN_DIR_SEPARATOR
#define SP_ANOTHER_DIR_SEPARATOR_STRING SP_WIN_DIR_SEPARATOR_STRING
#endif
    
#define SP_DEFAULT_DIRECTORY "c:"
#define SP_PATHLIST_SEPARATOR ';'

#define SP_DEFAULT_LF_STRING "\r\n"

#elif defined(MACOS9)

#define SP_DIR_SEPARATOR SP_MAC_DIR_SEPARATOR
#define SP_DIR_SEPARATOR_STRING SP_MAC_DIR_SEPARATOR_STRING
#define SP_PARENT_DIR_STRING SP_MAC_PARENT_DIR_STRING
#define SP_CURRENT_DIR_STRING SP_MAC_CURRENT_DIR_STRING
#define SP_SEPARATED_PARENT_DIR_STRING SP_MAC_SEPARATED_PARENT_DIR_STRING
#define SP_SEPARATED_CURRENT_DIR_STRING SP_MAC_SEPARATED_CURRENT_DIR_STRING
    
#define SP_ANOTHER_DIR_SEPARATOR SP_UNIX_DIR_SEPARATOR
#define SP_ANOTHER_DIR_SEPARATOR_STRING SP_UNIX_DIR_SEPARATOR_STRING
#define SP_DEFAULT_DIRECTORY ":"
#define SP_PATHLIST_SEPARATOR ';'

#if defined(MACOSX)
#define SP_DEFAULT_LF_STRING "\n"
#else
#define SP_DEFAULT_LF_STRING "\r"
#endif

#else

#define SP_DIR_SEPARATOR SP_UNIX_DIR_SEPARATOR
#define SP_DIR_SEPARATOR_STRING SP_UNIX_DIR_SEPARATOR_STRING
#define SP_PARENT_DIR_STRING SP_UNIX_PARENT_DIR_STRING
#define SP_CURRENT_DIR_STRING SP_UNIX_CURRENT_DIR_STRING
#define SP_SEPARATED_PARENT_DIR_STRING SP_UNIX_SEPARATED_PARENT_DIR_STRING
#define SP_SEPARATED_CURRENT_DIR_STRING SP_UNIX_SEPARATED_CURRENT_DIR_STRING

#if defined(MACOSX)
#define SP_ANOTHER_DIR_SEPARATOR SP_MAC_DIR_SEPARATOR
#define SP_ANOTHER_DIR_SEPARATOR_STRING SP_MAC_DIR_SEPARATOR_STRING
#define SP_DEFAULT_DIRECTORY "/"
#define SP_PATHLIST_SEPARATOR ';'
#else
#define SP_ANOTHER_DIR_SEPARATOR SP_UNIX_DIR_SEPARATOR
#define SP_ANOTHER_DIR_SEPARATOR_STRING SP_UNIX_DIR_SEPARATOR_STRING
#define SP_DEFAULT_DIRECTORY "/"
#define SP_PATHLIST_SEPARATOR ':'
#endif

#define SP_DEFAULT_LF_STRING "\n"
#endif

#ifdef NUL
#undef NUL
#endif
#define NUL		'\0'

#ifndef NULL
#define NULL		0
#endif

#ifndef PI
#ifdef M_PI
#define PI		M_PI
#else
#define PI		3.1415926535897932385
#endif
#endif

#ifndef RAND_MAX
#ifdef INT_MAX
#define RAND_MAX INT_MAX
#else
#define RAND_MAX 2147483647
#endif
#endif

#define spMax(a, b) ((a) > (b) ? (a) : (b))
#define spMin(a, b) ((a) < (b) ? (a) : (b))
#define spAbs(x) ((x) >= 0 ? (x) : -(x))
#define spCAbs(xr, xi) sqrt((double)(xr)*(double)(xr)+(double)(xi)*(double)(xi))
#define spSquare(x) ((x) * (x))
#define spCSquare(xr, xi) ((xr)*(xr)+(xi)*(xi))
#define spPow2(p) (1 << (long)(p))

/*#define spArraySize(array) (array != NULL ? ((unsigned int)(sizeof(array) / sizeof(array[0]))) : 0)*/
#define spArraySize(array) ((unsigned int)(sizeof(array) / sizeof(array[0])))
#define spStrEq(s1, s2) ((s1 != NULL) && (s2 != NULL) && (strcmp((s1), (s2)) == 0) ? 1 : 0)
#define spStrNEq(s1, s2, n) ((s1 != NULL) && (s2 != NULL) && (strncmp((s1), (s2), n) == 0) ? 1 : 0)
#define spStrVEq(s1, s2) ((s1 != NULL) && (s2 != NULL) && (strncmp((s1), (s2), strlen(s2)) == 0) ? 1 : 0)
#define spStrNone(string) (((string) == NULL || *(string) == NUL) ? 1 : 0)
#define spIsTrue(flag) (flag != SP_FALSE ? SP_TRUE : SP_FALSE)
#define spIsFalse(flag) (flag == SP_FALSE ? SP_TRUE : SP_FALSE)

#define dB(x) (20.0 * log10((double)((x) <= 0.0 ? SP_ALITTLE_NUMBER : (x))))
#define dBpow(x) (10.0 * log10((double)((x) <= 0.0 ? SP_ALITTLE_NUMBER : (x))))

#ifdef XtOffset
#define spOffset XtOffset
#else
#define spOffset(typep,field) \
    ((int) (((char *) (&(((typep)0)->field))) - ((char *)0)))
#endif

#ifdef XtOffsetOf
#define spOffsetOf XtOffsetOf
#else
#ifdef offsetof
#define spOffsetOf offsetof
#else
#define spOffsetOf(type, field) spOffset(type*, field)
#endif
#endif
    
#ifndef MAX
#define MAX spMax
#endif
#ifndef MIN
#define MIN spMin
#endif
#ifndef ABS
#define ABS spAbs
#endif
#ifndef FABS
#define FABS spAbs
#endif
#ifndef CABS
#define CABS spCAbs
#endif
#ifndef SQUARE
#define SQUARE spSquare
#endif
#ifndef CSQUARE
#define CSQUARE spCSquare
#endif
#ifndef POW2
#define POW2 spPow2
#endif

#ifndef arrsize
#define arrsize spArraySize
#endif
#ifndef streq
#define streq spStrEq
#endif
#ifndef strneq
#define strneq spStrNEq
#endif
#ifndef strveq
#define strveq spStrVEq
#endif
#ifndef strnone
#define strnone spStrNone
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#if defined(MACOS9)
#include <MacTypes.h>
#endif

#endif /* __SPDEFS_H */
