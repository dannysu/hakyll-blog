/*
 *	spDirectory.h
 */

#ifndef __SPDIRECTORY_H
#define __SPDIRECTORY_H

#include <sp/spDefs.h>
#if !defined(MACOS9) && !(defined(_WIN32) && !defined(__CYGWIN32__))
#include <dirent.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS9) || (defined(_WIN32) && !defined(__CYGWIN32__))
typedef struct _DIR DIR;

#define MAXNAMLEN 1024

struct dirent {
    char d_name[MAXNAMLEN];
    unsigned short d_namlen;
    long d_ino;
};
#endif

#if defined(MACOS)
#pragma import on
#endif

extern DIR *spOpenDir(char *path);
extern struct dirent *spReadDir(DIR *dirp);
extern int spCloseDir(DIR *dirp);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIRECTORY_H */
