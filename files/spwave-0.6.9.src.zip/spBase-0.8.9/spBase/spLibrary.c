/*
 *	spLibrary.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spLibrary.h>

#if defined(MACOS) && !defined(MACOSX)
#include <Files.h>
#include <Errors.h>
#include <Folders.h>
#include <CodeFragments.h>
#include <Aliases.h>

void *spOpenLibrary(char *filename)
{
    FSSpec file_spec;
    Ptr main_address;
    Str255 error_message;
    Str255 pfilename;
    CFragConnectionID *cid;

    if (strnone(filename)) return NULL;

    if ((cid = malloc(sizeof(CFragConnectionID))) == NULL) {
	return NULL;
    }

    spStrCToP(filename, pfilename);

    FSMakeFSSpec(0, 0, pfilename, &file_spec);

    if (GetDiskFragment(&file_spec, 0, kCFragGoesToEOF, NULL, 
			/*kReferenceCFrag*/kPrivateCFragCopy, cid, &main_address, error_message) != noErr) {
	spDebug(10, "spOpenLibrary", "GetDiskFragment Error.\n");
	free(cid);
	return NULL;
    }

    return (void *)cid;
}

void *spGetSymbolAddress(void *handle, char *symbol)
{
    Str255 psymbol;
    Ptr sym_address;
    CFragSymbolClass sym_class;
    CFragConnectionID *cid;

    if (handle == NULL || strnone(symbol)) return NULL;

    cid = (CFragConnectionID *)handle;
    spStrCToP(symbol, psymbol);
    
    if (FindSymbol(*cid, psymbol, &sym_address, &sym_class) != noErr) {
	spDebug(10, "spGetSymbolAddress", "FindSymbol Error: %s\n", symbol);
	return NULL;
    }
    spDebug(10, "spGetSymbolAddress", "%s: sym_address = %ld\n",
	    symbol, (long)sym_address);
    
    return (void *)sym_address;
}

void spCloseLibrary(void *handle)
{
    CFragConnectionID *cid;

    if (handle == NULL) return;

    cid = (CFragConnectionID *)handle;
    CloseConnection(cid);
    free(cid);

    return;
}

#elif defined(MACOSX)
#include <CoreFoundation/CFBase.h>
#include <CoreFoundation/CFBundle.h>

void *spOpenLibrary(char *filename)
{
    CFURLRef bundleURL;
    CFBundleRef bundle;
    CFStringRef str;

    if (strnone(filename)) return NULL;

    str = CFStringCreateWithCString(NULL, filename, /*CFStringGetSystemEncoding()*/kCFStringEncodingUTF8);
    spDebug(10, "spOpenLibrary", "CFStringCreateWithCString done: %s %ld\n", filename, (long)str);

    if (spIsExist(filename) == SP_TRUE) {
	spDebug(10, "spOpenLibrary", "%s exists, so create path\n", filename);
	bundleURL = CFURLCreateWithFileSystemPath(kCFAllocatorDefault,
						  str, kCFURLPOSIXPathStyle
						  /*kCFURLHFSPathStyle*/, true);
    } else {
        CFBundleRef mainBundle;

	spDebug(10, "spOpenLibrary", "%s doesn't exist, so search resource\n", filename);
	mainBundle = CFBundleGetMainBundle();
	bundleURL = CFBundleCopyResourceURL(mainBundle,
					    str, 
					    NULL, /* any type */
					    NULL); /* no subdir */
    }

    if (bundleURL == NULL) {
	spDebug(10, "spOpenLibrary", "CFURLCreateWithFileSystemPath failed\n");
	CFRelease(str);
	return NULL;
    }
    spDebug(10, "spOpenLibrary", "CFURLCreateWithFileSystemPath done: %ld\n", (long)bundleURL);
    
    if ((bundle = CFBundleCreate(kCFAllocatorDefault, bundleURL)) == NULL) {
	spDebug(10, "spOpenLibrary", "CFBundleCreate failed\n");
	CFRelease(bundleURL);
	CFRelease(str);
	return NULL;
    }
    spDebug(10, "spOpenLibrary", "CFBundleCreate done: %ld\n", (long)CFBundleGetVersionNumber(bundle));
    
    CFRelease(bundleURL);
    spDebug(10, "spOpenLibrary", "release bundleURL done\n");
    CFRelease(str);
    spDebug(10, "spOpenLibrary", "release str done\n");

    if (!CFBundleIsExecutableLoaded(bundle)) {
	if (!CFBundleLoadExecutable(bundle)) {
	    CFRelease(bundle);
	    return NULL;
	}
    }
    spDebug(10, "spOpenLibrary", "CFBundleLoadExecuable done\n");
    
    return (void *)bundle;
}

void *spGetSymbolAddress(void *handle, char *symbol)
{
    void *func;
    CFStringRef str;
    
    if (handle == NULL || strnone(symbol)) return NULL;

    str = CFStringCreateWithCString(NULL, symbol, CFStringGetSystemEncoding());
    
    func = (void *)CFBundleGetFunctionPointerForName((CFBundleRef)handle, str);
    
    CFRelease(str);

    return func;
}

void spCloseLibrary(void *handle)
{
    if (handle == NULL) return;

    /* Unloading a bundle causes a crash when a duplicated bundle of it has already been unloaded.
       So, I give up unloading a bundle. */
    /*CFBundleUnloadExecutable((CFBundleRef)handle);*/
    CFRelease((CFTypeRef)handle);
    
    return;
}

#else

#if defined(_WIN32)
#include <windows.h>
#elif defined(MACOSX)
#include <mach-o/dyld.h>
#else
#include <dlfcn.h>
#endif

void *spOpenLibrary(char *filename)
{
    void *handle;
#if !defined(_WIN32) && !defined(MACOSX)
#ifdef RTLD_LAZY
    int flag = RTLD_LAZY;
#else
    int flag = 1;
#endif
#endif

    if (strnone(filename)) return NULL;

    spDebug(30, "spOpenLibrary", "filename = %s\n", filename);
    
#if defined(_WIN32)
    if ((handle = (void *)LoadLibrary(filename)) == NULL) {
	spDebug(30, "spOpenLibrary", "load library error: %ld\n",
		(long)GetLastError());
	return NULL;
    }
#elif defined(MACOSX)
    {
	NSObjectFileImage image;
	NSObjectFileImageReturnCode ret;
	NSModule module;

	if ((ret = NSCreateObjectFileImageFromFile(filename, &image)) != NSObjectFileImageSuccess) {
	    switch (ret) {
	      case NSObjectFileImageInappropriateFile:
	      case NSObjectFileImageFormat:
		spDebug(10, "spOpenLibrary", "not loadble: %s\n", filename);
		break;
	      case NSObjectFileImageArch:
		spDebug(10, "spOpenLibrary", "wrong architecture: %s\n", filename);
		break;
	      case NSObjectFileImageAccess:
		spDebug(10, "spOpenLibrary", "can't access: %s\n", filename);
		break;
	      default:
		break;
	    }
	    return NULL;
	}

	module = NSLinkModule(image, filename,
			      NSLINKMODULE_OPTION_RETURN_ON_ERROR
			      | NSLINKMODULE_OPTION_PRIVATE/* | NSLINKMODULE_OPTION_BINDNOW*/);
	NSDestroyObjectFileImage(image);
	if (module == NULL) {
	    return NULL;
	}
	
	handle = (void *)module;
    }
#else

#ifdef RTLD_NOW
    flag = RTLD_NOW;
#endif
    if ((handle = dlopen(filename, flag)) == NULL) {
	spDebug(30, "spOpenLibrary", "load library error: %s\n", dlerror());
	return NULL;
    }
    spDebug(30, "spOpenLibrary", "dlopen done\n");
#endif

    return handle;
}

void *spGetSymbolAddress(void *handle, char *symbol)
{
    void *ptr;

    if (handle == NULL || strnone(symbol)) return NULL;
    
#if defined(_WIN32)
    if ((ptr = (void *)GetProcAddress((HINSTANCE)handle, symbol)) == NULL) {
	return NULL;
    }
#elif defined(MACOSX)
    {
	NSSymbol sym;
	char buf[SP_MAX_LINE];

	sprintf(buf, "_%s", symbol);
	if ((sym = NSLookupSymbolInModule((NSModule)handle, buf)) == NULL) {
	    return NULL;
	}
	ptr = NSAddressOfSymbol(sym);
    }
#else
    if ((ptr = dlsym(handle, symbol)) == NULL) {
	return NULL;
    }
#endif

    return ptr;
}

void spCloseLibrary(void *handle)
{
    if (handle == NULL) return;
    
#if defined(_WIN32)
    FreeLibrary((HINSTANCE)handle);
#elif defined(MACOSX)
    NSUnLinkModule((NSModule)handle, 0);
#else
    dlclose(handle);
#endif
    
    return;
}
#endif
