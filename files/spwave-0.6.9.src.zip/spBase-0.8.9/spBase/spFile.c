/*
 *	spFile.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>
#include <sp/spOption.h>

#if !defined(MACOS9)
#include <sys/types.h>
#include <sys/stat.h>
#endif

#if defined(_WIN32) && !defined(__CYGWIN32__)
#include <mbctype.h>
#endif

/*
 *	get file size
 */
long getfilesize(char *filename, int headsize)
{
    long size;
    char *basename;

    /* get base name */
    basename = spGetBaseName(filename);

    if (streq(basename, "-") || streq(basename, "stdin")) {
#ifdef MACOS9
	return 0;
#else
#if defined(_WIN32) && !defined(__CYGWIN32__)
	struct _stat status;
#define fstat(h,buf) _fstat(h,buf)
#else
	struct stat status;
#endif
	
	/* stat file */
	if (fstat(0, &status)) {
	    return 0;
	}
	size = status.st_size;
#endif
    } else {
	if (spGetFileInfo(filename, NULL, &size) == SP_FALSE) {
	    return 0;
	}
    }

    /* get data size */
    size -= (long)headsize;
    size = MAX(size, 0);

    return size;
}

long getfilesize_txt(char *filename)
{
    long size;
    double value;
    char line[SP_MAX_LINE];
    char string[SP_MAX_LINE];
    FILE *fp;

    if (NULL == (fp = spOpenFile(filename, "r"))) {
	return SP_FAILURE;
    }

    size = 0;
    while (fgetline(line, fp) != EOF) {
        sscanf(line, "%s", string);
        if (sscanf(string, "%lf", &value) == 1) {
	    size++;
        }
    }

    spCloseFile(fp);

    return size;
}

/*
 *	skip header
 */
void fskipheader(long headsize, FILE *fp)
{
    if (headsize >= 0)
	fseek(fp, headsize, 0);
    return;
}

/*
 *	skip byte
 */
long fskipbyte(long len, FILE *fp)
{
    long k;
    
    if (len > 0) {
	for (k = 0; k < len; k++) {
	    if (fseek(fp, 1L, 1) != 0) {
		break;
	    }
	}
    } else {
	for (k = 0; k > len; k--) {
	    if (fseek(fp, -1L, 1) != 0) {
		break;
	    }
	}
    }
    
    return k;
}

/*
 *	shift data
 */
void shiftshort(short *data, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (data != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0;
		}
	    }
	}
    }

    return;
}

void shiftlong(long *data, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (data != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0;
		}
	    }
	}
    }

    return;
}

void shiftfloat(float *data, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (data != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0.0;
		}
	    }
	}
    }

    return;
}

void shiftdouble(double *data, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (data != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    data[k] = data[k - shift];
		} else {
		    data[k] = 0.0;
		}
	    }
	}
    }

    return;
}

/*
 *	swap data
 */
void swapshort(short *data, long length)
{
    long k;

    for (k = 0; k < length; k++) {
	data[k] = ((data[k] << 8) & 0xff00) | ((data[k] >> 8) & 0xff);
    }

    return;
}

void swaplong(long *data, long length)
{
    long k;
    int i;
    int num_unit;
    char *pi, *po;
    long vi, vo;

    num_unit = sizeof(long) - 1;

    for (k = 0; k < length; k++) {
	vi = data[k];
	pi = (char *)&vi;
	po = (char *)&vo;
	for (i = 0; i <= num_unit; i++) {
	    po[i] = pi[num_unit - i];
	}
	data[k] = vo;
    }
    
    return;
}

void swaplong32(spLong32 *data, long length)
{
    long k;
    int i;
    int num_unit;
    char *pi, *po;
    spLong32 vi, vo;

    num_unit = sizeof(spLong32) - 1;

    for (k = 0; k < length; k++) {
	vi = data[k];
	pi = (char *)&vi;
	po = (char *)&vo;
	for (i = 0; i <= num_unit; i++) {
	    po[i] = pi[num_unit - i];
	}
	data[k] = vo;
    }
    
    return;
}

void swapfloat(float *data, long length)
{
    long k;
    int i;
    int num_unit;
    char *pi, *po;
    float vi, vo;

    num_unit = sizeof(float) - 1;

    for (k = 0; k < length; k++) {
	vi = data[k];
	pi = (char *)&vi;
	po = (char *)&vo;
	for (i = 0; i <= num_unit; i++) {
	    po[i] = pi[num_unit - i];
	}
	data[k] = vo;
    }
    
    return;
}

void swapdouble(double *data, long length)
{
    long k;
    int i;
    int num_unit;
    char *pi, *po;
    double vi, vo;

    num_unit = sizeof(double) - 1;

    for (k = 0; k < length; k++) {
	vi = data[k];
	pi = (char *)&vi;
	po = (char *)&vo;
	for (i = 0; i <= num_unit; i++) {
	    po[i] = pi[num_unit - i];
	}
	data[k] = vo;
    }
    
    return;
}

/*
 *	read data
 */
long freadshort(short *data, long length, int swap, FILE *fp)
{
    long ndata = 0;
    
    if (data == NULL) return 0;
    
    /* read file */
    if ((ndata = fread((char *)data, sizeof(short), length, fp)) <= 0) {
	return ndata;
    }

    if (swap) {
	/* byte swap */
	swapshort(data, ndata);
    }

    if (ndata < length) {
	long k;
	for (k = ndata; k < length; k++) {
	    data[k] = 0;
	}
    }

    return ndata;
}

long freadlong(long *data, long length, int swap, FILE *fp)
{
    long ndata = 0;
    
    if (data == NULL) return 0;
    
    /* read file */
    if ((ndata = fread((char *)data, sizeof(long), length, fp)) <= 0) {
	return ndata;
    }

    if (swap) {
	/* byte swap */
	swaplong(data, ndata);
    }

    if (ndata < length) {
	long k;
	for (k = ndata; k < length; k++) {
	    data[k] = 0;
	}
    }

    return ndata;
}

long freadlong32(long *data, long length, int swap, FILE *fp)
{
    long nread;
    long k;
    long ndata;
    spLong32 value;
    
    if (data == NULL) return 0;

    for (k = 0, ndata = 0; k < length; k++) {
	nread = fread((char *)&value, sizeof(spLong32), 1, fp);
	if (nread <= 0) {
	    break;
	}

	if (swap) {
	    /* byte swap */
	    swaplong32(&value, 1);
	}

	data[k] = (long)value;
	ndata += (long)nread;
    }

    if (ndata < length) {
	for (k = ndata; k < length; k++) {
	    data[k] = 0;
	}
    }

    return ndata;
}

long freadlong24(long *data, long length, int swap, FILE *fp)
{
    char c;
    long k;
    long ndata;
    spLong32 value;
    char buf[4];
    
    if (data == NULL) return 0;

    for (k = 0, ndata = 0; k < length; k++) {
	if (fread(buf, 3, 1, fp) <= 0) {
	    break;
	}

	if (swap) {
	    c = buf[0]; buf[0] = buf[2]; buf[2] = c;
	}
	
#if BYTE_ORDER == LITTLE_ENDIAN
	value = (((spLong32)buf[2] << 24) & 0xff000000)
	    | (((spLong32)buf[1] << 16) & 0xff0000) | (((spLong32)buf[0] << 8) & 0xff00);
#else
	value = (((spLong32)buf[0] << 24) & 0xff000000)
	    | (((spLong32)buf[1] << 16) & 0xff0000) | (((spLong32)buf[2] << 8) & 0xff00);
#endif
	value /= 256;

	data[k] = (long)value;
	ndata++;
    }

    if (ndata < length) {
	for (k = ndata; k < length; k++) {
	    data[k] = 0;
	}
    }

    return ndata;
}

long freadfloat(float *data, long length, int swap, FILE *fp)
{
    long ndata = 0;
    
    if (data == NULL) return 0;
    
    /* read file */
    if ((ndata = fread((char *)data, sizeof(float), length, fp)) <= 0) {
	return ndata;
    }

    if (swap) {
	/* byte swap */
	swapfloat(data, ndata);
    }

    if (ndata < length) {
	long k;
	for (k = ndata; k < length; k++) {
	    data[k] = 0.0;
	}
    }

    return ndata;
}

long freaddouble(double *data, long length, int swap, FILE *fp)
{
    long ndata = 0;
    
    if (data == NULL) return 0;
    
    /* read file */
    if ((ndata = fread((char *)data, sizeof(double), length, fp)) <= 0) {
	return ndata;
    }

    if (swap) {
	/* byte swap */
	swapdouble(data, ndata);
    }

    if (ndata < length) {
	long k;
	for (k = ndata; k < length; k++) {
	    data[k] = 0.0;
	}
    }

    return ndata;
}

long freadbyte(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0;
	} else {
	    value = 256 * ((short)c - 128);
	    data[k] = value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadsbyte(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    signed char c;
    short value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0;
	} else {
	    value = 256 * (short)c;
	    data[k] = value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadulaw(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0;
	} else {
	    value = ulaw2linear(c);
	    data[k] = value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadalaw(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0;
	} else {
	    value = alaw2linear(c);
	    data[k] = value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadshorttod(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    short value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&value, sizeof(short), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0.0;
	} else {
	    if (swap) {
		/* byte swap */
		swapshort(&value, 1);
	    }
	    
	    data[k] = (double)value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadlongtod(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    long value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&value, sizeof(long), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0.0;
	} else {
	    if (swap) {
		/* byte swap */
		swaplong(&value, 1);
	    }
	    
	    data[k] = (double)value;
	    ndata += n;
	}
    }

    return ndata;
}

long freadfloattod(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    float value;
    
    if (data == NULL) return 0;

    for (k = 0; k < length; k++) {
	/* read file */
	n = fread((char *)&value, sizeof(float), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    }
	    data[k] = 0.0;
	} else {
	    if (swap) {
		/* byte swap */
		swapfloat(&value, 1);
	    }
	    
	    data[k] = (double)value;
	    ndata += n;
	}
    }

    return ndata;
}

/*
 *	write data
 */
long fwriteshort(short *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    
    if (data == NULL) return 0;
    
    if (swap) {
	long k;
	short value;

	for (k = 0; k < length; k++) {
	    value = data[k];
	    
	    /* byte swap */
	    swapshort(&value, 1);

	    /* write file */
	    n = fwrite((char *)&value, sizeof(short), 1, fp);
	    if (n <= 0) {
		if (k <= 0) {
		    return n;
		} else {
		    return ndata;
		}
	    } else {
		ndata += n;
	    }
	}
    } else {
	/* write file */
	ndata = fwrite((char *)data, sizeof(short), length, fp);
    }

    return ndata;
}

long fwritelong(long *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    
    if (data == NULL) return 0;
    
    if (swap) {
	long k;
	long value;

	for (k = 0; k < length; k++) {
	    value = data[k];
	    
	    /* byte swap */
	    swaplong(&value, 1);

	    /* write file */
	    n = fwrite((char *)&value, sizeof(long), 1, fp);
	    if (n <= 0) {
		if (k <= 0) {
		    return n;
		} else {
		    return ndata;
		}
	    } else {
		ndata += n;
	    }
	}
    } else {
	/* write file */
	ndata = fwrite((char *)data, sizeof(long), length, fp);
    }

    return ndata;
}

long fwritelong32(long *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    spLong32 value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (spLong32)data[k];

	if (swap) {
	    /* byte swap */
	    swaplong32(&value, 1);
	}

	/* write file */
	n = fwrite((char *)&value, sizeof(spLong32), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritelong24(long *data, long length, int swap, FILE *fp)
{
    char c;
    long n = 0, ndata = 0;
    long k;
    spLong32 value;
    char buf[4];
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (spLong32)data[k] * 256;

#if BYTE_ORDER == LITTLE_ENDIAN
	buf[2] = (char)((value & 0xff000000) >> 24);
	buf[1] = (char)((value & 0xff0000) >> 16);
	buf[0] = (char)((value & 0xff00) >> 8);
#else
	buf[0] = (char)((value & 0xff000000) >> 24);
	buf[1] = (char)((value & 0xff0000) >> 16);
	buf[2] = (char)((value & 0xff00) >> 8);
#endif

	if (swap) {
	    c = buf[0]; buf[0] = buf[2]; buf[2] = c;
	}
	
	/* write file */
	n = fwrite(buf, 3, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritefloat(float *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    
    if (data == NULL) return 0;
    
    if (swap) {
	long k;
	float value;

	for (k = 0; k < length; k++) {
	    value = data[k];
	    
	    /* byte swap */
	    swapfloat(&value, 1);

	    /* write file */
	    n = fwrite((char *)&value, sizeof(float), 1, fp);
	    if (n <= 0) {
		if (k <= 0) {
		    return n;
		} else {
		    return ndata;
		}
	    } else {
		ndata += n;
	    }
	}
    } else {
	/* write file */
	ndata = fwrite((char *)data, sizeof(float), length, fp);
    }

    return ndata;
}

long fwritedouble(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    
    if (data == NULL) return 0;
    
    if (swap) {
	long k;
	double value;

	for (k = 0; k < length; k++) {
	    value = data[k];
	    
	    /* byte swap */
	    swapdouble(&value, 1);

	    /* write file */
	    n = fwrite((char *)&value, sizeof(double), 1, fp);
	    if (n <= 0) {
		if (k <= 0) {
		    return n;
		} else {
		    return ndata;
		}
	    } else {
		ndata += n;
	    }
	}
    } else {
	/* write file */
	ndata = fwrite((char *)data, sizeof(double), length, fp);
    }

    return ndata;
}

long fwritebyte(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (short)(data[k] / 256) + 128;
	c = (unsigned char)value;
	
	/* write file */
	n = fwrite((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritesbyte(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    signed char c;
    short value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (short)(data[k] / 256);
	c = (char)value;
	
	/* write file */
	n = fwrite((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwriteulaw(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = data[k];
	c = linear2ulaw(value);
	
	/* write file */
	n = fwrite((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritealaw(short *data, long length, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    unsigned char c;
    short value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = data[k];
	c = linear2alaw(value);
	
	/* write file */
	n = fwrite((char *)&c, 1, 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritedoubletos(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    short value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (short)spRound(data[k]);
	
	if (swap) {
	    /* byte swap */
	    swapshort(&value, 1);
	}

	/* write file */
	n = fwrite((char *)&value, sizeof(short), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritedoubletol(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    long value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (long)spRound(data[k]);
	
	if (swap) {
	    /* byte swap */
	    swaplong(&value, 1);
	}

	/* write file */
	n = fwrite((char *)&value, sizeof(long), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

long fwritedoubletof(double *data, long length, int swap, FILE *fp)
{
    long n = 0, ndata = 0;
    long k;
    float value;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	value = (float)data[k];
	
	if (swap) {
	    /* byte swap */
	    swapfloat(&value, 1);
	}

	/* write file */
	n = fwrite((char *)&value, sizeof(float), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}

static long fwritelongvaltos(long *data, long length, int swap, FILE *fp, double value)
{
    long n = 0, ndata = 0;
    long k;
    spLong32 lvalue;
    short svalue;
    
    if (data == NULL) return 0;
    
    for (k = 0; k < length; k++) {
	lvalue = (spLong32)data[k];

	if (swap) {
	    /* byte swap */
	    swaplong32(&lvalue, 1);
	}

	svalue = (short)spRound((double)lvalue / value);

	/* write file */
	n = fwrite((char *)&svalue, sizeof(short), 1, fp);
	if (n <= 0) {
	    if (k <= 0) {
		return n;
	    } else {
		return ndata;
	    }
	} else {
	    ndata += n;
	}
    }

    return ndata;
}


long fwritelong32tos(long *data, long length, int swap, FILE *fp)
{
    return fwritelongvaltos(data, length, swap, fp, 65536.0);
}

long fwritelong24tos(long *data, long length, int swap, FILE *fp)
{
    return fwritelongvaltos(data, length, swap, fp, 256.0);
}

/*
 *	file I/O for text data
 */
int getnumrow(char *filename)
{
    int nrow, ncol;
    FILE *fp;
    char buf[SP_MAX_LINE];

    if (NULL == (fp = spOpenFile(filename, "r"))) {
	return -1;
    }

    nrow = 0;
    while (1) {
	ncol = fgetcol(buf, 0, fp);
	if (ncol == EOF) {
	    break;
	}
	nrow++;
    }

    spCloseFile(fp);

    return nrow;
}

int getnumcol(char *filename)
{
    int ncol;
    FILE *fp;
    char buf[SP_MAX_LINE];

    if (NULL == (fp = spOpenFile(filename, "r"))) {
	return -1;
    }

    ncol = fgetcol(buf, 0, fp);

    spCloseFile(fp);

    return ncol;
}

/*
 *	get column from text file
 */
static int _getncol(char *buf, int size, int col, int *offset, char *line, FILE *fp)
{
    int i;
    int end;
    int ncol;
    int nchar;
    int c, prev_c;
    int quote;

    if (fp == NULL && line == NULL) return EOF;

    i = 0;
    buf[0] = NUL;
    c = NUL;
    prev_c = NUL;
    quote = NUL;
    end = 0;
    ncol = 0;
    nchar = 0;
    while (1) {
	if (fp != NULL) {
	    c = fgetc(fp);
	} else {
	    c = *line;
	    line++;
	}
	i++;
	
	if (c == EOF || (fp == NULL && c == NUL)) {
	    c = EOF;
	    break;
	} else if (quote == NUL && c == '#' && prev_c != '\\') {
	    while (1) {
		if (fp != NULL) {
		    c = fgetc(fp);
		} else {
		    c = *line;
		    line++;
		}
		i++;
		
		if (c == EOF || (fp == NULL && c == NUL)) {
		    c = EOF;
		    end = 1;
		    break;
		} else if (c == '\n' || c == '\r') {
		    if (c == '\r') {
			if (fp != NULL) {
			    if ((c = fgetc(fp)) != '\n') { /* for Mac */
				ungetc(c, fp);
				i--;
			    }
			} else {
			    if ((c = *(line++)) != '\n') {
				line--;
				i--;
			    }
			}
			i++;
		    }
		    if (ncol > 0) {
			end = 1;
		    }
		    break;
		}
	    }
	    
	    if (end == 1) {
		c = EOF;
		break;
	    }
	} else if (quote == NUL && (c == '\n' || c == '\r')) {
	    if (c == '\r') {
		if (fp != NULL) {
		    if ((c = fgetc(fp)) != '\n') { /* for Mac */
			ungetc(c, fp);
			i--;
		    }
		} else {
		    if ((c = *(line++)) != '\n') {
			line--;
			i--;
		    }
		}
		i++;
	    }
	    if (prev_c == '\\' || (prev_c == NUL && nchar <= 0)/**/) {
	    } else if (ncol != 0 || nchar != 0) {
		c = EOF;
		break;
	    }
	} else if (quote == NUL && (c == ' ' || c == '\t') && prev_c != '\\') {
	    if (nchar > 0) {
		if (nchar >= size) {
		    if (nchar == size) {
			buf[nchar - 1] = NUL;
		    }
		} else {
		    if (ncol == col) {
			buf[nchar] = NUL;
		    }
		}
		ncol++;
	    }
	    nchar = 0;
	} else if (c == '\\' && prev_c != '\\'
		   && spIsMBTailCandidate(prev_c, c) == SP_FALSE) {
	} else {
#if 0
	    if (c == '\t') {
		c = ' ';
	    }
#endif
	    
	    spDebug(100, "sgetnextncol", "prev_c = %c, c = %c, quote = %c\n", prev_c, c, quote);
	    
	    if (prev_c != '\\'
		&& spIsMBTailCandidate(prev_c, c) == SP_FALSE
		&& ((quote != NUL && c == quote)
		    || (quote == NUL && (c == '\'' || c == '\"')))) {
		if (quote != NUL && c == quote) {
		    spDebug(60, "sgetnextncol", "quotation %c finished\n", quote);
	    
		    if (nchar <= 0) { /* no characters in this quoation */
			if (ncol == col) {
			    buf[0] = NUL;
			}
			nchar = 1;
		    }
		    quote = NUL;
		} else {
		    quote = c;
		    spDebug(60, "sgetnextncol", "quotation %c started\n", quote);
		}
	    } else {
		if (nchar >= size) {
		    if (nchar == size) {
			buf[nchar - 1] = NUL;
		    }
		} else {
		    if (ncol == col) {
			buf[nchar] = c;
			if (offset != NULL) {
			    *offset = i + 1;
			}
		    }
		}
		nchar++;

		if (c == '\\') {
		    c = NUL;
		}
	    }
	}

	prev_c = c;
    }

    if (nchar > 0) {
	if (ncol == col) {
	    nchar = MIN(nchar, size - 1);
	    for (i = nchar - 1; i >= 0; i--) {
		if (buf[i] == ' ' || buf[i] == '\t') {
		    --nchar;
		} else {
		    break;
		}
	    }

	    if ((nchar >= 1 && buf[nchar - 1] == '\\') ||
		nchar == 0) {
		++nchar;
	    }
	    
	    buf[nchar] = NUL;
	}
	ncol++;
    }

    if (ncol <= col && c == EOF) {
	ncol = EOF;
    }

    return ncol;
}

int fgetncol(char *buf, int size, int col, FILE *fp)
{
    return _getncol(buf, size, col, NULL, NULL, fp);
}

int fgetcol(char *buf, int col, FILE *fp)
{
    return fgetncol(buf, SP_MAX_LINE, col, fp);
}

int sgetncol(char *buf, int size, int col, char *line)
{
    return _getncol(buf, size, col, NULL, line, NULL);
}

int sgetcol(char *buf, int col, char *line)
{
    return sgetncol(buf, SP_MAX_LINE, col, line);
}
    
char *sgetnextncol(char *buf, int size, char *line)
{
    int offset = 0;

    if (line != NULL) {
	if (_getncol(buf, size, 0, &offset, line, NULL) > 1
	    && offset < strlen(line)) {
	    spDebug(80, "sgetnextncol", "offset = %d, line = %s\n", offset, line);
	    return line + offset;
	}
    }

    return NULL;
}

int fgetnline(char *buf, int size, FILE *fp)
{
    int c, prev_c;
    int end;
    int ncol;
    int nchar;
    int pos;

    buf[0] = NUL;
    c = NUL;
    prev_c = NUL;
    end = 0;
    ncol = 0;
    nchar = 0;
    pos = 0;
    while (1) {
	if (pos >= size) {
	    pos--;
	    break;
	}
	
	c = fgetc(fp);
	if (c == EOF) {
	    break;
	} else if (c == '#' && prev_c != '\\') {
	    while (1) {
		c = fgetc(fp);
		if (c == EOF) {
		    end = 1;
		    break;
		} else if (c == '\n' || c == '\r') {
		    if (c == '\r' && (c = fgetc(fp)) != '\n') { /* for Mac */
			ungetc(c, fp);
		    }
		    if (ncol > 0) {
			end = 1;
		    }
		    break;
		}
	    }
	    
	    if (end == 1) {
		break;
	    }
	} else if (c == '\n' || c == '\r') {
	    if (c == '\r' && (c = fgetc(fp)) != '\n') { /* for Mac */
		ungetc(c, fp);
	    }
	    if (prev_c == '\\') {
		pos--;
		nchar--;
	    } else if (ncol != 0 || nchar != 0) {
		break;
	    }
	} else if (c == ' ' || c == '\t') {
	    if (nchar > 0) {
		ncol++;
	    }
	    buf[pos] = c;
	    pos++;
	    nchar = 0;
	} else {
	    buf[pos] = c;
	    pos++;
	    nchar++;

	    if (c == '\\' && spIsMBTailCandidate(prev_c, c) == SP_TRUE) {
		c = NUL;
	    }
	}

	prev_c = c;
    }

    buf[pos] = NUL;

    if (pos <= 0 && c == EOF) {
	pos = EOF;
    }

    return pos;
}

int fgetline(char *buf, FILE *fp)
{
    return fgetnline(buf, SP_MAX_LINE, fp);
}

int getline(char *buf)
{
    return fgetline(buf, stdin);
}

int fputline(char *buf, FILE *fp)
{
    int i, j;
    int prev_c, c;

    if (buf == NULL) return -1;
    
    prev_c = 0;
    for (i = 0, j = 0;; i++) {
	c = buf[i];
	if (c == NUL) {
	    break;
	} else if (c == '#'
		   || (c == '\\'
		       && spIsMBTailCandidate(prev_c, c) == SP_FALSE)
		   || c == '\'' || c == '\"') {
	    putc('\\', fp);
	    putc(c, fp);
	    j += 2;
	} else {
	    putc(c, fp);
	    j++;
	}
	prev_c = c;
    }

    return j;
}

static int _putstring(char *buf, char *line, int size, FILE *fp)
{
    int i, j;
    int prev_c, c;
    int len;
    spBool quoted = SP_FALSE;
    spBool have_space = SP_FALSE;

    if (buf == NULL || (fp == NULL && line == NULL)) {
	return -1;
    }

    len = strlen(buf);
    if (len <= 0) {
	have_space = SP_TRUE;
    } else {
	if (len >= 2
	    && ((buf[0] == '\'' && buf[len - 1] == '\'')
		|| (buf[0] == '\"' && buf[len - 1] == '\"'))) {
	    quoted = SP_TRUE;
	}
	
	for (i = 0; i < len; i++) {
	    if (buf[i] == ' ' || buf[i] == '\t') {
		have_space = SP_TRUE;
		break;
	    }
	}
    }

    j = 0;
    if (quoted == SP_FALSE && have_space == SP_TRUE) {
	if (fp != NULL) {
	    putc('\"', fp);
	} else {
	    if (size < 3) {
		line[0] = NUL;
		return 0;
	    }
	    line[j] = '\"';
	}
	j++;
    }

    prev_c = 0;
    for (i = 0;; i++) {
	c = buf[i];
	if (c == NUL) {
	    break;
	} else if (c == '#'
		   || (c == '\\'
		       && spIsMBTailCandidate(prev_c, c) == SP_FALSE)
		   || c == '\'' || c == '\"') {
	    if (fp != NULL) {
		putc('\\', fp);
		putc(c, fp);
	    } else {
		if (j + 2 >= size) {
		    break;
		}
		line[j] = '\\';
		line[j+1] = c;
	    }
	    j += 2;
	} else {
	    if (fp != NULL) {
		putc(c, fp);
	    } else {
		if (j + 1 >= size) {
		    break;
		}
		line[j] = c;
	    }
	    j++;
	}
	prev_c = c;
    }

    if (quoted == SP_FALSE && have_space == SP_TRUE) {
	if (fp != NULL) {
	    putc('\"', fp);
	} else {
	    if (j + 2 >= size) {
		j = size - 2;
	    }
	    line[j] = '\"';
	}
	j++;
    }
    if (fp == NULL) {
	line[j] = NUL;
    }

    return j;
}

int fputstring(char *buf, FILE *fp)
{
    return _putstring(buf, NULL, 0, fp);
}

int sputstring(char *buf, char *line, int size)
{
    return _putstring(buf, line, size, NULL);
}

char *fgetsn(char *buf, int size, FILE *fp)
{
    int c, prev_c;
    int pos;

    if (fp == NULL) return NULL;
    
    pos = 0;
    c = NUL;
    prev_c = NUL;
    while (1) {
	if (pos >= size) {
	    pos--;
	    break;
	}

	c = fgetc(fp);
	if (c == EOF) {
	    buf[pos] = NUL;
	    if (pos <= 0) {
		return NULL;
	    } else {
		return buf;
	    }
	} else if (c == '\n' || c == '\r') {
	    if (c == '\r' && (c = fgetc(fp)) != '\n') { /* for Mac */
		ungetc(c, fp);
	    }
	    if (prev_c == '\\') {
		pos--;
	    } else {
		break;
	    }
	} else {
	    buf[pos] = c;
	    pos++;

	    if (c == '\\' && spIsMBTailCandidate(prev_c, c) == SP_TRUE) {
		c = NUL;
	    }
	}
    }
    buf[pos] = NUL;

    return buf;
}

char *getsn(char *buf, int size)
{
    return fgetsn(buf, size, stdin);
}

char *sgetsn(char *buf, int size, char *string)
{
    int c, prev_c;
    int pos;

    if (string == NULL || *string == NUL) return NULL;
    
    pos = 0;
    c = NUL;
    prev_c = NUL;
    while (1) {
	if (pos >= size) {
	    pos--;
	    break;
	}

	c = *string++;
	if (c == NUL) {
	    buf[pos] = NUL;
	    if (pos <= 0) {
		return NULL;
	    } else {
		return (string - 1);
		/*return buf;*/
	    }
	} else if (c == '\n' || c == '\r') {
	    if (c == '\r' && (c = *string++) != '\n') { /* for Mac */
		--string;
	    }
	    if (prev_c == '\\') {
		pos--;
	    } else {
		break;
	    }
	} else {
	    buf[pos] = c;
	    pos++;

#if defined(_WIN32) && !defined(__CYGWIN32__)
	    if (c == '\\' && spIsMBTailCandidate(prev_c, c) == SP_TRUE) {
		c = NUL;
	    }
#endif
	}
    }
    buf[pos] = NUL;

    return string;
    /*return buf;*/
}

int sscansetup(char *line, char *name, char *value)
{
    int i;
    int end;
    int ncol;
    int nchar;
    int c, prev_c;

    name[0] = NUL;
    value[0] = NUL;
    
    prev_c = NUL;
    end = 0;
    ncol = 0;
    nchar = 0;
    for (i = 0;; i++) {
	c = line[i];
	if (c == NUL) {
	    c = EOF;
	    break;
	} else if (c == '#' && prev_c != '\\') {
	    for (i = 0;; i++) {
		c = line[i];
		if (c == NUL) {
		    end = 1;
		    break;
		} else if (c == '\n' || c == '\r') {
		    if (c == '\r' && (c = line[++i]) != '\n') { /* for Mac */
			--i;
		    }
		    if (ncol > 0) {
			end = 1;
		    }
		    break;
		}
	    }
	    
	    if (end == 1) {
		c = EOF;
		break;
	    }
	} else if (c == '\n' || c == '\r') {
	    if (c == '\r' && (c = line[++i]) != '\n') { /* for Mac */
		--i;
	    }
	    if (prev_c == '\\' || prev_c == NUL) {
	    } else if (ncol != 0 || nchar != 0) {
		c = EOF;
		break;
	    }
	} else if ((c == ' ' || c == '\t') && prev_c != '\\') {
	    if (nchar > 0 && ncol == 0) {
		if (nchar >= SP_MAX_SETUP_NAME) {
		    if (nchar == SP_MAX_SETUP_NAME) {
			name[nchar - 1] = NUL;
		    }
		} else {
		    name[nchar] = NUL;
		}
		nchar = 0;
		ncol++;
	    } else if (ncol != 0 && !(prev_c == ' ' || prev_c == '\t')) {
		if (nchar >= SP_MAX_SETUP_VALUE) {
		    if (nchar == SP_MAX_SETUP_VALUE) {
			value[nchar - 1] = NUL;
		    }
		} else {
		    value[nchar] = ' ';
		}
		nchar++;
	    }
	} else if (c == '\\' && prev_c != '\\'
		   && spIsMBTailCandidate(prev_c, c) == SP_FALSE) {
	} else {
	    if (c == '\t') {
		c = ' ';
	    }
	    
	    if (ncol == 0) {
		if (nchar >= SP_MAX_SETUP_NAME) {
		    if (nchar == SP_MAX_SETUP_NAME) {
			name[nchar - 1] = NUL;
		    }
		} else {
		    name[nchar] = c;
		}
	    } else {
		if (nchar >= SP_MAX_SETUP_VALUE) {
		    if (nchar == SP_MAX_SETUP_VALUE) {
			value[nchar - 1] = NUL;
		    }
		} else {
		    value[nchar] = c;
		}
	    }
	    nchar++;

	    if (c == '\\') {
		c = NUL;
	    }
	}

	prev_c = c;
    }

    if (nchar > 0) {
	if (ncol == 0) {
	    nchar = MIN(nchar, SP_MAX_SETUP_NAME - 1);
	
	    name[nchar] = NUL;
	} else {
	    nchar = MIN(nchar, SP_MAX_SETUP_VALUE - 1);
	    
	    for (i = nchar - 1; i >= 0; i--) {
		if (value[i] == ' ' || value[i] == '\t') {
		    --nchar;
		} else {
		    break;
		}
	    }

	    if ((nchar >= 1 && value[nchar - 1] == '\\') ||
		nchar == 0) {
		++nchar;
	    }
	    value[nchar] = NUL;
	}
	ncol++;
    }

    if (ncol <= 0 && c == EOF) {
	ncol = EOF;
    }

    return ncol;
}

/* the following is from g711.c */
/*
 * This source code is a product of Sun Microsystems, Inc. and is provided
 * for unrestricted use.  Users may copy or modify this source code without
 * charge.
 *
 * SUN SOURCE CODE IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING
 * THE WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 *
 * Sun source code is provided with no support and without any obligation on
 * the part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 *
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY THIS SOFTWARE
 * OR ANY PART THEREOF.
 *
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 *
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */

/*
 * g711.c
 *
 * u-law, A-law and linear PCM conversions.
 */
#define	SIGN_BIT	(0x80)		/* Sign bit for a A-law byte. */
#define	QUANT_MASK	(0xf)		/* Quantization field mask. */
#define	NSEGS		(8)		/* Number of A-law segments. */
#define	SEG_SHIFT	(4)		/* Left shift for segment number. */
#define	SEG_MASK	(0x70)		/* Segment field mask. */

/* copy from CCITT G.711 specifications */
static unsigned char _u2a[128] = {			/* u- to A-law conversions */
	1,	1,	2,	2,	3,	3,	4,	4,
	5,	5,	6,	6,	7,	7,	8,	8,
	9,	10,	11,	12,	13,	14,	15,	16,
	17,	18,	19,	20,	21,	22,	23,	24,
	25,	27,	29,	31,	33,	34,	35,	36,
	37,	38,	39,	40,	41,	42,	43,	44,
	46,	48,	49,	50,	51,	52,	53,	54,
	55,	56,	57,	58,	59,	60,	61,	62,
	64,	65,	66,	67,	68,	69,	70,	71,
	72,	73,	74,	75,	76,	77,	78,	79,
	81,	82,	83,	84,	85,	86,	87,	88,
	89,	90,	91,	92,	93,	94,	95,	96,
	97,	98,	99,	100,	101,	102,	103,	104,
	105,	106,	107,	108,	109,	110,	111,	112,
	113,	114,	115,	116,	117,	118,	119,	120,
	121,	122,	123,	124,	125,	126,	127,	128};

static unsigned char _a2u[128] = {			/* A- to u-law conversions */
	1,	3,	5,	7,	9,	11,	13,	15,
	16,	17,	18,	19,	20,	21,	22,	23,
	24,	25,	26,	27,	28,	29,	30,	31,
	32,	32,	33,	33,	34,	34,	35,	35,
	36,	37,	38,	39,	40,	41,	42,	43,
	44,	45,	46,	47,	48,	48,	49,	49,
	50,	51,	52,	53,	54,	55,	56,	57,
	58,	59,	60,	61,	62,	63,	64,	64,
	65,	66,	67,	68,	69,	70,	71,	72,
	73,	74,	75,	76,	77,	78,	79,	79,
	80,	81,	82,	83,	84,	85,	86,	87,
	88,	89,	90,	91,	92,	93,	94,	95,
	96,	97,	98,	99,	100,	101,	102,	103,
	104,	105,	106,	107,	108,	109,	110,	111,
	112,	113,	114,	115,	116,	117,	118,	119,
	120,	121,	122,	123,	124,	125,	126,	127};

static short seg_end[8] = {0xFF, 0x1FF, 0x3FF, 0x7FF,
			    0xFFF, 0x1FFF, 0x3FFF, 0x7FFF};

static int search(int val, short *table, int size)
{
	int		i;

	for (i = 0; i < size; i++) {
		if (val <= *table++)
			return (i);
	}
	return (size);
}

/*
 * linear2alaw() - Convert a 16-bit linear PCM value to 8-bit A-law
 *
 * linear2alaw() accepts an 16-bit integer and encodes it as A-law data.
 *
 *		Linear Input Code	Compressed Code
 *	------------------------	---------------
 *	0000000wxyza			000wxyz
 *	0000001wxyza			001wxyz
 *	000001wxyzab			010wxyz
 *	00001wxyzabc			011wxyz
 *	0001wxyzabcd			100wxyz
 *	001wxyzabcde			101wxyz
 *	01wxyzabcdef			110wxyz
 *	1wxyzabcdefg			111wxyz
 *
 * For further information see John C. Bellamy's Digital Telephony, 1982,
 * John Wiley & Sons, pps 98-111 and 472-476.
 */
unsigned char linear2alaw(
			  int pcm_val)	/* 2's complement (16-bit range) */
{
	int		mask;
	int		seg;
	unsigned char	aval;

	if (pcm_val >= 0) {
		mask = 0xD5;		/* sign (7th) bit = 1 */
	} else {
		mask = 0x55;		/* sign bit = 0 */
		pcm_val = -pcm_val - 8;
	}

	/* Convert the scaled magnitude to segment number. */
	seg = search(pcm_val, seg_end, 8);

	/* Combine the sign, segment, and quantization bits. */

	if (seg >= 8)		/* out of range, return maximum value. */
		return (0x7F ^ mask);
	else {
		aval = seg << SEG_SHIFT;
		if (seg < 2)
			aval |= (pcm_val >> 4) & QUANT_MASK;
		else
			aval |= (pcm_val >> (seg + 3)) & QUANT_MASK;
		return (aval ^ mask);
	}
}

/*
 * alaw2linear() - Convert an A-law value to 16-bit linear PCM
 *
 */
int alaw2linear(unsigned char a_val)
{
	int		t;
	int		seg;

	a_val ^= 0x55;

	t = (a_val & QUANT_MASK) << 4;
	seg = ((unsigned)a_val & SEG_MASK) >> SEG_SHIFT;
	switch (seg) {
	case 0:
		t += 8;
		break;
	case 1:
		t += 0x108;
		break;
	default:
		t += 0x108;
		t <<= seg - 1;
	}
	return ((a_val & SIGN_BIT) ? t : -t);
}

#define	BIAS		(0x84)		/* Bias for linear code. */

/*
 * linear2ulaw() - Convert a linear PCM value to u-law
 *
 * In order to simplify the encoding process, the original linear magnitude
 * is biased by adding 33 which shifts the encoding range from (0 - 8158) to
 * (33 - 8191). The result can be seen in the following encoding table:
 *
 *	Biased Linear Input Code	Compressed Code
 *	------------------------	---------------
 *	00000001wxyza			000wxyz
 *	0000001wxyzab			001wxyz
 *	000001wxyzabc			010wxyz
 *	00001wxyzabcd			011wxyz
 *	0001wxyzabcde			100wxyz
 *	001wxyzabcdef			101wxyz
 *	01wxyzabcdefg			110wxyz
 *	1wxyzabcdefgh			111wxyz
 *
 * Each biased linear code has a leading 1 which identifies the segment
 * number. The value of the segment number is equal to 7 minus the number
 * of leading 0's. The quantization interval is directly available as the
 * four bits wxyz.  * The trailing bits (a - h) are ignored.
 *
 * Ordinarily the complement of the resulting code word is used for
 * transmission, and so the code word is complemented before it is returned.
 *
 * For further information see John C. Bellamy's Digital Telephony, 1982,
 * John Wiley & Sons, pps 98-111 and 472-476.
 */
unsigned char linear2ulaw(
			  int pcm_val)	/* 2's complement (16-bit range) */
{
	int		mask;
	int		seg;
	unsigned char	uval;

	/* Get the sign and the magnitude of the value. */
	if (pcm_val < 0) {
		pcm_val = BIAS - pcm_val;
		mask = 0x7F;
	} else {
		pcm_val += BIAS;
		mask = 0xFF;
	}

	/* Convert the scaled magnitude to segment number. */
	seg = search(pcm_val, seg_end, 8);

	/*
	 * Combine the sign, segment, quantization bits;
	 * and complement the code word.
	 */
	if (seg >= 8)		/* out of range, return maximum value. */
		return (0x7F ^ mask);
	else {
		uval = (seg << 4) | ((pcm_val >> (seg + 3)) & 0xF);
		return (uval ^ mask);
	}

}

/*
 * ulaw2linear() - Convert a u-law value to 16-bit linear PCM
 *
 * First, a biased linear code is derived from the code word. An unbiased
 * output can then be obtained by subtracting 33 from the biased code.
 *
 * Note that this function expects to be passed the complement of the
 * original code word. This is in keeping with ISDN conventions.
 */
int ulaw2linear(
		unsigned char u_val)
{
	int		t;

	/* Complement to obtain normal u-law value. */
	u_val = ~u_val;

	/*
	 * Extract and bias the quantization bits. Then
	 * shift up by the segment number and subtract out the bias.
	 */
	t = ((u_val & QUANT_MASK) << 3) + BIAS;
	t <<= ((unsigned)u_val & SEG_MASK) >> SEG_SHIFT;

	return ((u_val & SIGN_BIT) ? (BIAS - t) : (t - BIAS));
}

/* A-law to u-law conversion */
unsigned char alaw2ulaw(
			unsigned char aval)
{
	aval &= 0xff;
	return ((aval & 0x80) ? (0xFF ^ _a2u[aval ^ 0xD5]) :
	    (0x7F ^ _a2u[aval ^ 0x55]));
}

/* u-law to A-law conversion */
unsigned char ulaw2alaw(
			unsigned char uval)
{
	uval &= 0xff;
	return ((uval & 0x80) ? (0xD5 ^ (_u2a[0xFF ^ uval] - 1)) :
	    (0x55 ^ (_u2a[0x7F ^ uval] - 1)));
}
