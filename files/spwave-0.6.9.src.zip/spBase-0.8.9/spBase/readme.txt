
	spBase - Basic Library for spLib

			Last modified: <2000-09-23 10:25:16 hideki>


Introduction
------------

This library is spBase, basic library for spLibs. This has following
features. This includes fundamental functions such as file I/O.
 

Install
-------

To compile this library on UNIX (including Linux) or Cygwin, go to the
source directory of spBase:
 
 % cd spBase-X.X.X/spBase

If your platform is supported by the configuration file, you can easily build
the library by typing:
 
 % make

To install this library to your system directory (e.g /usr/local), login as
root and type:

 # make SPDESTROOT=/usr/local install
 # make SPDESTROOT=/usr/local install.hdr
 # cd ..
 # cp -r lib/sp /usr/local/lib


Supported Platforms
-------------------

spBase is known to work at least on DEC Alpha(Digital UNIX V3.2C),
SunOS(5.6), Linux(Redhat 4.2, Slackware 3.4), Microsoft Windows95/98, and
Cygnus GNU-Win32(Beta 19). It may be possible to compile it by changing
Makefile slightly, if your environment is compatible with UNIX. spBase on
UNIX requires the pthread library from version 0.8.7.


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

License
-------

Please see LICENSE.txt.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
