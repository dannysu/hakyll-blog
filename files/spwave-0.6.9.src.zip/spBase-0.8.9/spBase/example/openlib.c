#include <stdio.h>
#include <stdlib.h>

#include <sp/spBaseLib.h>

int main(int argc, char *argv[])
{
    void *handle;
    void *funcp;
    
    if (argc < 3) {
	fprintf(stderr, "usage: openlib <function name> <plugin name>\n");
	exit(1);
    }

    spSetDebugLevel(10);

    if ((handle = spOpenLibrary(argv[2])) == NULL) {
	fprintf(stderr, "can't open library\n");
	exit(1);
    }
    if ((funcp = spGetSymbolAddress(handle, argv[1])) == NULL) {
	fprintf(stderr, "can't get symbol address\n");
	exit(1);
    }
    fprintf(stderr, "Symbol address: %ld\n", (long)funcp);
    spCloseLibrary(handle);
    
    return 0;
}
