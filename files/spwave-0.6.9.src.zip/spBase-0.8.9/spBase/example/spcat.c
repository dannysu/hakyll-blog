#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spBaseLib.h>
#include <sp/spKanji.h>

#if defined(_WIN32)
#define DEFAULT_LF_TYPE "dos"
#elif defined(MACOS)
#define DEFAULT_LF_TYPE "mac"
#ifndef ALWAYS_KANJI_CONV
#define ALWAYS_KANJI_CONV
#endif
#else
#define DEFAULT_LF_TYPE "unix"
#define SUPPORT_LF_CONV
#endif

#define LINE_SIZE 4096

#ifdef ALWAYS_KANJI_CONV
#define SPCAT_HELP_MESSAGE "Concatenate files and print it with NKF kanji conversion"
#else
#define SPCAT_HELP_MESSAGE "Concatenate files and print it"
#endif

static spBool help_flag = SP_FALSE;
static spBool nkf_help_flag = SP_FALSE;

static spBool show_code_only = SP_FALSE;
static spBool use_number = SP_FALSE;
#ifdef ALWAYS_KANJI_CONV
static spBool kanji_conv = SP_TRUE;
#else
static spBool kanji_conv = SP_FALSE;
#endif

static char line_feed_type[SP_MAX_LINE] = DEFAULT_LF_TYPE;

static spOptions options;
static spOption option[] = {
#ifndef ALWAYS_KANJI_CONV
    {"-k", "-kanji", "convert kanji code using NKF engine", NULL,
	 SP_TYPE_BOOLEAN, &kanji_conv, SP_FALSE_STRING},
#endif
    {"-v", NULL, "display NKF usage", NULL,
	 SP_TYPE_BOOLEAN, &nkf_help_flag, SP_FALSE_STRING},
    {"-C", "-code", "display kanji code only", NULL,
	 SP_TYPE_BOOLEAN, &show_code_only, SP_FALSE_STRING},
#ifdef SUPPORT_LF_CONV
    {"-L", "-lf", "line feed type (dos,mac,unix)", NULL,
	 SP_TYPE_STRING_S, line_feed_type, DEFAULT_LF_TYPE},
#endif
    {"-N", "-number", "use line numbers", NULL,
	 SP_TYPE_BOOLEAN, &use_number, SP_FALSE_STRING},
    {"-h", "-help", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "[input file...]",
};

static int fdumpdata(int count, FILE *fp)
{
    int i;
    static unsigned char lin[LINE_SIZE] = "";
    static unsigned char lout[LINE_SIZE] = "";
    
    for (i = count; fgetsn((char *)lin, LINE_SIZE, fp) != NULL; i++) {
	if (show_code_only == SP_TRUE) {
	    spConvertKanji(lin, lout, LINE_SIZE);
	} else {
	    if (use_number == SP_TRUE) {
		fprintf(stdout, "%6d  ", i);
	    }
	    if (kanji_conv == SP_TRUE) {
		spConvertKanji(lin, lout, LINE_SIZE);
		fputs((char *)lout, stdout);
	    } else {
		fputs((char *)lin, stdout);
	    }
	    if (streq(line_feed_type, "dos")) {
		fputs("\r\n", stdout);
	    } else if (streq(line_feed_type, "mac")) {
		fputs("\r", stdout);
	    } else {
		fputs("\n", stdout);
	    }
	}
    }

    if (show_code_only == SP_TRUE) {
	fprintf(stderr, "Current code: %s\n", spGetKanjiCodeLabel(SP_KANJI_CODE_UNKNOWN));
    }
    
    return i;
}

int main(int argc, char *argv[])
{
    int count;
    FILE *fp;
    char *filename;

    spSetHelpMessage(&help_flag, SPCAT_HELP_MESSAGE);
    options = spGetOptions(argc, argv, option, filelabel);
    spIgnoreUnknownOption(options, SP_TRUE);
    spGetOptionsValue(argc, argv, options);

    if (show_code_only == SP_TRUE) {
	kanji_conv = SP_TRUE;
    }

    if (kanji_conv == SP_TRUE) {
	spSetKanjiCode(SP_KANJI_CODE_UNKNOWN, SP_KANJI_CODE_DEFAULT);
    }
    spSetKanjiOptions(argc - 1, &argv[1]);
    
    if ((filename = spGetFile(options)) == NULL) {
	fp = stdin;
	fdumpdata(1, fp);
    } else {
	count = 1;
	while (filename != NULL) {
	    if ((fp = fopen(filename, "r")) == NULL) {
		spError(1, "Can't open file: %s", filename);
	    } else {
		count = fdumpdata(count, fp);
		fclose(fp);
	    }
	    filename = spGetFile(options);
	}
    }
    
    return 0;
}
