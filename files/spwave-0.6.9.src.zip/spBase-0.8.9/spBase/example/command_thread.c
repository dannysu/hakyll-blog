#include <stdio.h>
#include <stdlib.h>

#include <sp/spBase.h>
#include <sp/spThread.h>

static volatile spBool flag = SP_FALSE;

void command_func(spCommandThreadStatus status, int data, void *user_data)
{
    char *path = (char *)user_data;
    
    switch (status) {
      case SP_COMMAND_THREAD_STARTED:
	fprintf(stdout, "thread started\n");
	break;
	
      case SP_COMMAND_THREAD_FINISHED:
	fprintf(stdout, "thread finished\n");
	flag = SP_TRUE;
	break;
	
      case SP_COMMAND_THREAD_COMMAND_FINISHED:
	fprintf(stdout, "command \"%s\" finished: %d\n", path, data);
	break;
	
      case SP_COMMAND_THREAD_COMMAND_FAILED:
	fprintf(stdout, "command \"%s\" failed: %d\n", path, data);
	break;
	
      default:
	break;
    }
    
    return;
}

int main(int argc, char *argv[])
{
    int i;
    
    if (argc != 2) {
	fprintf(stderr, "usage: command_test <command>\n");
	exit(1);
    }

    spCreateCommandThread(argv[1], command_func, argv[1]);

    for (i = 0;; i++) {
	if (flag == SP_TRUE) {
	    break;
	}
	printf("i = %d\n", i);
    }

    return 0;
}
