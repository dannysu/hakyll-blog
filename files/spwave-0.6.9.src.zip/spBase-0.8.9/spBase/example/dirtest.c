#include <stdio.h>
#include <stdlib.h>

#include <sp/spBaseLib.h>

int main(int argc, char *argv[])
{
#if defined(MACOS9)
    static char dirname[] = ":";
#else
    static char dirname[] = ".";
#endif
    DIR *dirp;
    struct dirent *direntp;
    char *name;

    spSetDebugLevel(20);

    printf("process id = %ld\n", spGetProcessId());

    if ((name = xspGetHomeDir()) != NULL) {
	printf("home directory: %s\n", name);
	xfree(name);
    }

    if ((name = xspGetCurrentDir()) != NULL) {
	printf("current directory: %s\n", name);
	xfree(name);
    }
    
    if ((name = xspGetTempDir()) != NULL) {
	printf("temporary directory: %s\n", name);
	xfree(name);
    }
    
    if ((name = xspGetExactName("~/hoge")) != NULL) {
	printf("~/hoge --> %s\n", name);
	xfree(name);
    }

    if ((name = xspGetExactName("~ftp/hoge")) != NULL) {
	printf("~ftp/hoge --> %s\n", name);
	xfree(name);
    }
    
    if ((dirp = spOpenDir(dirname)) == NULL) {
	fprintf(stderr, "Can't open directory: %s\n", dirname);
	return 1;
    }
    printf("reading directory: %s\n", dirname);

    while ((direntp = spReadDir(dirp)) != NULL) {
	printf("%s\n", direntp->d_name);
    }

    spCloseDir(dirp);

    /* functions introduced from version 0.8.9 */
    {
	spBool id_depend = SP_FALSE;
	spBool version_depend = SP_FALSE;

#if 0
	name = spGetApplicationDir(&version_depend);
	printf("application directory (before set application ID): %s (version depend: %d)\n",
	       name, version_depend);
#endif
	
#if 1
	spSetApplicationId("test");
#elif 0
	version_depend = SP_TRUE;
	spSetApplicationId("test/0.1");
#endif

	if (1) {
	    id_depend = SP_TRUE;
	    name = spCreateApplicationDir(&id_depend, &version_depend);
	    printf("create application directory: %s (id depend: %d, version depend: %d)\n",
		   name, id_depend, version_depend);
	}
	
	name = spGetApplicationDir(&version_depend);
	printf("application directory: %s (version depend: %d)\n", name, version_depend);
	if (version_depend == SP_TRUE) {
	    version_depend = SP_FALSE;
	    name = spGetApplicationDir(&version_depend);
	    printf("application directory: %s (version depend: %d)\n", name, version_depend);
	    version_depend = SP_TRUE;
	}
	
	name = spGetApplicationTempDir();
	printf("application temp directory: %s\n", name);

	if ((name = xspGetDocumentDir(SP_FILE_KIND_DOCUMENT)) != NULL) {
	    printf("document directory: %s\n", name);
	    xfree(name);
	}
	if ((name = xspGetDocumentDir(SP_FILE_KIND_PICTURE)) != NULL) {
	    printf("picture directory: %s\n", name);
	    xfree(name);
	}
	if ((name = xspGetDocumentDir(SP_FILE_KIND_SOUND)) != NULL) {
	    printf("sound directory: %s\n", name);
	    xfree(name);
	}
    }
    
    return 0;
}
