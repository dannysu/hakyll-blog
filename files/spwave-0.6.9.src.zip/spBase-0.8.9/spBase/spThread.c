/*
 *	spThread.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spBase.h>
#include <sp/spOption.h>
#include <sp/spThread.h>
#include <sp/spFile.h>

#if defined(HAVE_PTHREAD)
#include <pthread.h>

#elif defined(MACOS)

#if defined(MACOSX)
#include <pthread.h>
#include <CoreServices/CoreServices.h>
#else
#include <Gestalt.h>
#include <Threads.h>
#endif

#define SP_MAC_IMPLEMENT_MUTEX
#define SP_MAC_MUTEX_ID 3
typedef struct _spThread *spThread;
struct _spThread {
    ThreadID id;
    long return_status;
};
#ifdef SP_MAC_IMPLEMENT_MUTEX
typedef struct _spMutex *spMutex;
struct _spMutex {
    ThreadID owner_thread;
};
#endif

#elif defined(_WIN32)
#include <windows.h>
#if defined(HAVE_BEGINTHREADEX)
#include <process.h>
#endif

static long waitThreadWin(void *handle)
{
    long status = 0;
    
    if (handle == NULL) return SP_THREAD_EXIT_FAILURE;
    
    {
	DWORD flag;
	DWORD nobject;
	MSG msg; 

	nobject = 1;
	while (1) {
	    if ((flag = MsgWaitForMultipleObjects(nobject, &handle, 
			  FALSE, INFINITE, QS_ALLINPUT)) == WAIT_TIMEOUT) {
		return SP_THREAD_EXIT_FAILURE;
	    }

	    if (flag == (WAIT_OBJECT_0 + nobject)) {
		/* received message */
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) { 
		    TranslateMessage(&msg);
		    DispatchMessage(&msg); 
		}
		continue;
	    } else if (flag >= WAIT_OBJECT_0 && flag < WAIT_OBJECT_0 + nobject) {
		/* object is signaled */
		if (!GetExitCodeThread((HANDLE)handle, &flag)) {
		    return SP_THREAD_EXIT_FAILURE;
		}
		status = (long)flag;
		break;
	    } else if (flag >= WAIT_ABANDONED_0 && flag < WAIT_ABANDONED_0 + nobject) {
		/* abandoned */
		status = -1;
		break;
	    } else {
		/* other errors */
		return SP_THREAD_EXIT_FAILURE;
	    }
	}
    }

    return status;
}
#endif

#if defined(HAVE_PTHREAD) || defined(MACOSX)
static void *createThreadPT(long stacksize, int priority, spThreadFunc func, void *data)
{
    pthread_attr_t attr;
    pthread_t *thread;
    
    pthread_attr_init(&attr);
#ifndef linux
    {
	size_t size;
	pthread_attr_getstacksize (&attr, &size);
	if (size < stacksize) {
	    pthread_attr_setstacksize (&attr, size);
	}
    }
#endif

    thread = malloc(sizeof(pthread_t));
    
    if (pthread_create(thread, &attr, func, data) != 0) {
	thread = 0;
    }
    
    pthread_attr_destroy(&attr);

    return (void *)thread;
}

static void destroyThreadPT(void *handle)
{
    pthread_detach((pthread_t)handle);
    free(handle);
    return;
}

static void exitThreadPT(long status)
{
    pthread_exit((void *)status);
    return;
}

static void yieldThreadPT(void)
{
    pthread_testcancel();
    return;
}

static long waitThreadPT(void *handle)
{
    long status = 0;
    void *ptr;
    pthread_t *thread;
    
    thread = (pthread_t *)handle;
    
    if (pthread_join(*thread, &ptr) != 0) {
	return 1;
    }
    if (ptr == (void *)-1) {
	status = SP_THREAD_EXIT_CANCELED;
    } else {
	status = (long)ptr;
    }

    return status;
}
#endif

#if defined(MACOS)
static void *createThreadMac(long stacksize, int priority, spThreadFunc func, void *data)
{
    spThread thread;
    long response;

    if (Gestalt(gestaltThreadMgrAttr, &response) != noErr
	|| !(response & (1 << gestaltThreadMgrPresent))) {
        spDebug(1, "spCreateThread", "thread is not supported.\n");
	return NULL;
    }

    thread = malloc(sizeof(struct _spThread));
    thread->id = 0;
    thread->return_status = 0;
    
    if (NewThread(kCooperativeThread,
		  /*(ThreadEntryProcPtr)*/(ThreadEntryTPP)func, data,
		  stacksize, 0,
		  (void **)&thread->return_status, &thread->id) != noErr) {
        spDebug(1, "spCreateThread", "can't create thread.\n");
	free(thread);
	return NULL;
    }

    return (void *)thread;
}

static void destroyThreadMac(void *handle)
{
    free(handle);
}

static void exitThreadMac(long status)
{
    DisposeThread(kCurrentThreadID, (void *)status, true);
    
    return;
}

static void yieldThreadMac(void)
{
    YieldToAnyThread();
    
    return;
}

static long waitThreadMac(void *handle)
{
    spThread thread = (spThread)handle;
    ThreadState state;
    
    while (1) {
	if (YieldToThread(thread->id) != noErr) {
	    break;
	}
	if (GetThreadState(thread->id, &state) != noErr
	    || state == kStoppedThreadState) {
	    break;
	}
    }

    return thread->return_status;
}
#endif

void *spCreateThread(long stacksize, int priority, spThreadFunc func, void *data)
{
#if defined(HAVE_PTHREAD)
    return createThreadPT(stacksize, priority, func, data);
#elif defined(MACOS)
#if defined(MACOSX)
    if (spIsLowLevelThreadUsed() == SP_TRUE) {
	return createThreadPT(stacksize, priority, func, data);
    }
#endif
    return createThreadMac(stacksize, priority, func, data);
#elif defined(_WIN32)
    void *hthread;
    DWORD thread_id;

#if defined(HAVE_BEGINTHREADEX)
    hthread = (void *)_beginthreadex(NULL, stacksize, (LPTHREAD_START_ROUTINE)func, data,
				     0, (unsigned *)&thread_id);
#else
    hthread = (void *)CreateThread(NULL, stacksize, (LPTHREAD_START_ROUTINE)func, data,
				   0, &thread_id);
#endif
    SetThreadPriority((HANDLE)hthread, priority);
    
    return hthread;
#else
    return NULL;
#endif
}

void spDestroyThread(void *handle)
{
    if (handle == NULL) return;
    
#if defined(HAVE_PTHREAD)
    destroyThreadPT(handle);
#elif defined(MACOS)
#if defined(MACOSX)
    if (spIsLowLevelThreadUsed() == SP_TRUE) {
	destroyThreadPT(handle);
	return;
    }
#endif
    destroyThreadMac(handle);
#elif defined(_WIN32)
    CloseHandle((HANDLE)handle);
#endif
    
    return;
}

void spExitThread(long status)
{
#if defined(HAVE_PTHREAD)
    exitThreadPT(status);
#elif defined(MACOS)
#if defined(MACOSX)
    if (spIsLowLevelThreadUsed() == SP_TRUE) {
	exitThreadPT(status);
	return;
    }
#endif
    exitThreadMac(status);
#elif defined(_WIN32)
#if defined(HAVE_BEGINTHREADEX)
    _endthreadex((unsigned)status);
#else
    ExitThread((DWORD)status);
#endif
#endif
    
    return;
}

void spYieldThread(void)
{
#if defined(HAVE_PTHREAD)
    yieldThreadPT();
#elif defined(MACOS)
#if defined(MACOSX)
    if (spIsLowLevelThreadUsed() == SP_TRUE) {
	yieldThreadPT();
	return;
    }
#endif
    yieldThreadMac();
#endif
    return;
}

long spWaitThread(void *handle)
{
    long status = 0;
    
    if (handle == NULL) return SP_THREAD_EXIT_FAILURE;
    
#if defined(HAVE_PTHREAD)
    status = waitThreadPT(handle);
#elif defined(MACOS)
#if defined(MACOSX)
    if (spIsLowLevelThreadUsed() == SP_TRUE) {
	return waitThreadPT(handle);
    }
#endif
    status = waitThreadMac(handle);
#elif defined(_WIN32)
#if 0
    {
	DWORD flag;
	if ((flag = WaitForSingleObject((HANDLE)handle, INFINITE)) == WAIT_TIMEOUT) {
	    return SP_THREAD_EXIT_FAILURE;
	}
	if (flag == WAIT_ABANDONED) {
	    flag = -1;
	} else {
	    if (!GetExitCodeThread((HANDLE)handle, &flag)) {
		return SP_THREAD_EXIT_FAILURE;
	    }
	}
	status = (long)flag;
    }
#else
    status = waitThreadWin(handle);
#endif
#endif

    return status;
}

void *spCreateMutex(char *name)
{
    void *handle = NULL;
    
#if defined(HAVE_PTHREAD) || defined(MACOSX)
    {
	pthread_mutex_t *mutex;
	
	mutex = malloc(sizeof(pthread_mutex_t));

	pthread_mutex_init(mutex, NULL);
	handle = (void *)mutex;
    }
#elif defined(MACOS)
#ifndef SP_MAC_IMPLEMENT_MUTEX
    handle = (void *)SP_MAC_MUTEX_ID;	/* dummy */
#else
    {
	spMutex mutex;
    
	mutex = malloc(sizeof(struct _spMutex));
	mutex->owner_thread = kNoThreadID;
	handle = (void *)mutex;
    }
#endif
#elif defined(_WIN32)
    handle = (void *)CreateMutex(NULL, FALSE, name);
#endif

    return handle;
}

void spDestroyMutex(void *handle)
{
    if (handle == NULL) return;
    
#if defined(HAVE_PTHREAD) || defined(MACOSX)
    pthread_mutex_destroy((pthread_mutex_t *)handle);
    free(handle);
#elif defined(MACOS)
#ifndef SP_MAC_IMPLEMENT_MUTEX
    /* do nothing */
#else
    free(handle);
#endif
#elif defined(_WIN32)
    CloseHandle((HANDLE)handle);
#endif

    return;
}

spBool spLockMutex(void *handle)
{
    if (handle == NULL) return SP_FALSE;
    
#if defined(HAVE_PTHREAD) || defined(MACOSX)
    if (pthread_mutex_lock((pthread_mutex_t *)handle) != 0) {
	return SP_FALSE;
    }
#elif defined(MACOS)
#ifndef SP_MAC_IMPLEMENT_MUTEX
    if ((long)handle != SP_MAC_MUTEX_ID) {
	return SP_FALSE;
    }
    ThreadBeginCritical();
#else
    {
	spMutex mutex = (spMutex)handle;

	while (mutex->owner_thread != kNoThreadID
	       && YieldToThread(mutex->owner_thread) == noErr) {
	}
	ThreadBeginCritical();
	mutex->owner_thread = kNoThreadID;
	MacGetCurrentThread(&mutex->owner_thread);
	ThreadEndCritical();
    }
#endif
#elif defined(_WIN32)
#if 1
    if (WaitForSingleObject((HANDLE)handle, INFINITE) == WAIT_TIMEOUT) {
	return SP_FALSE;
    }
#else
    if (waitThreadWin(handle) != 0) {
	return SP_FALSE;
    }
#endif
#endif
    return SP_TRUE;
}

spBool spUnlockMutex(void *handle)
{
    if (handle == NULL) return SP_FALSE;
    
#if defined(HAVE_PTHREAD) || defined(MACOSX)
    if (pthread_mutex_unlock((pthread_mutex_t *)handle) != 0) {
	return SP_FALSE;
    }
#elif defined(MACOS)
#ifndef SP_MAC_IMPLEMENT_MUTEX
    if ((long)handle != SP_MAC_MUTEX_ID) {
	return SP_FALSE;
    }
    ThreadEndCritical();
#else
    {
	spMutex mutex = (spMutex)handle;

	ThreadBeginCritical();
	mutex->owner_thread = kNoThreadID;
	ThreadEndCritical();
	/*YieldToAnyThread();*/
    }
#endif
#elif defined(_WIN32)
    ReleaseMutex((HANDLE)handle);
#endif
    return SP_TRUE;
}

spBool spWaitMutex(void *handle)
{
#if defined(MACOS) && !(defined(HAVE_PTHREAD) || defined(MACOSX))
#ifndef SP_MAC_IMPLEMENT_MUTEX
    return SP_TRUE;
#else
    if (handle == NULL) return SP_FALSE;
    
    {
	spMutex mutex = (spMutex)handle;

	while (mutex->owner_thread != kNoThreadID
	       && YieldToThread(mutex->owner_thread) == noErr) {
	}
	ThreadBeginCritical();
	mutex->owner_thread = kNoThreadID;
	ThreadEndCritical();
    }
    
    return SP_FALSE;
#endif
#else
    if (spLockMutex(handle) == SP_TRUE) {
	spUnlockMutex(handle);
	return SP_TRUE;
    }
    
    return SP_FALSE;
#endif
}

#if defined(MACOS)
static spThreadLevel sp_thread_level = SP_THREAD_LEVEL_HIGH;
#else
static spThreadLevel sp_thread_level = SP_THREAD_LEVEL_LOW;
#endif

spBool spIsThreadLevelVariable(void)
{
#if defined(MACOSX)
    return SP_TRUE;
#else
    return SP_FALSE;
#endif
}

spBool spIsLowLevelThreadUsed(void)
{
    if (sp_thread_level == SP_THREAD_LEVEL_LOW) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spSetThreadLevel(spThreadLevel level)
{
#if defined(MACOSX)
    if (level == SP_THREAD_LEVEL_LOW || level == SP_THREAD_LEVEL_HIGH) {
	sp_thread_level = level;
	return SP_TRUE;
    }
#endif
    return SP_FALSE;
}

spThreadLevel spGetThreadLevel(void)
{
    return sp_thread_level;
}

#if !defined(_WIN32) && !defined(MACOS)
#include <errno.h>
#endif

typedef struct _spCommandThreadData
{
    char *command;
    spCommandThreadCallback func;
    void *data;
} *spCommandThreadData;

static spThreadReturn commandThread(void *data)
{
    long err;
    spCommandThreadData thread_data = (spCommandThreadData)data;
#if defined(MACOS9)
    int errno;
#endif
    
    if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_STARTED, 0, thread_data->data);
    
#if defined(_WIN32)
    {
	DWORD flag;
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory(&si, sizeof( STARTUPINFO));
	si.cb = sizeof( STARTUPINFO );
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_SHOWNORMAL;
	
	if (CreateProcess(NULL, thread_data->command,
			  NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
	    CloseHandle(pi.hThread);

	    if ((flag = WaitForSingleObject(pi.hProcess, INFINITE)) != WAIT_OBJECT_0) {
		/* error */
		err = (long)flag;
		if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_COMMAND_WAIT_FAILED, err, thread_data->data);
	    } else {
		if (!GetExitCodeThread(pi.hProcess, &flag)) {
		    flag = -1;
		}
		err = (long)flag;
		
		if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_COMMAND_FINISHED, err, thread_data->data);
	    }
	    
	    
	    CloseHandle(pi.hProcess);
	} else {
	    err = (long)GetLastError();
	    if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_COMMAND_FAILED, err, thread_data->data);
	}
    }
#else
    errno = 0;
    err = system(thread_data->command);
    if (errno != 0 && err != 0) {
	if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_COMMAND_FAILED, err, thread_data->data);
    } else {
	if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_COMMAND_FINISHED, err, thread_data->data);
    }
#endif

    if (thread_data->func != NULL) thread_data->func(SP_COMMAND_THREAD_FINISHED, 0, thread_data->data);

    xfree(thread_data->command);
    xfree(thread_data);
    
    return SP_THREAD_RETURN_SUCCESS;
}

static void commandThreadExitCallback(void *hthread)
{
    if (hthread != NULL) {
        spDebug(1, "commandThreadExitCallback", "command thread %ld is destroyed\n",
		(long)hthread);
	spDestroyThread(hthread);
    }

    return;
}

spBool spCreateCommandThread(char *command, spCommandThreadCallback func, void *data)
{
    void *hthread;
    spCommandThreadData thread_data;

    if (strnone(command)) return SP_FALSE;
    
    spDebug(10, "spCreateCommandThread", "command = %s\n", command);
    
    thread_data = xalloc(1, struct _spCommandThreadData);
#if defined(MACOSX)
    {
	char *args;
	char buf[SP_MAX_PATHNAME];

	thread_data->command = NULL;

	if ((args = sgetnextncol(buf, SP_MAX_PATHNAME, command)) != 0) {
	    spDebug(10, "spCreateCommandThread", "buf = %s\n", buf);
	    
	    if ((spEqSuffix(buf, ".app") == SP_TRUE
		 || spReplaceSuffix(buf, ".app") == SP_TRUE)
		&& spIsExist(buf) == SP_TRUE) {
		char *exename;
		
		exename = xspGetBaseName(buf);
		spRemoveSuffix(exename, NULL);
		spDebug(10, "spCreateCommandThread", "exename = %s\n", exename);

		thread_data->command = xalloc(strlen(buf) + strlen(exename)
					      + strlen(args) + 20, char);
		sprintf(thread_data->command, "\"%s/Contents/MacOS/%s\" %s", buf, exename, args);
		spDebug(10, "spCreateCommandThread", "command = %s\n", thread_data->command);
		
		xfree(exename);
	    }
	}

	if (thread_data->command == NULL) {
	    thread_data->command = strclone(command);
	}
    }
#else
    thread_data->command = strclone(command);
#endif
    thread_data->func = func;
    thread_data->data = data;

    if ((hthread = spCreateThread(0, 0, commandThread, thread_data)) == NULL) {
	return SP_FALSE;
    }
    spAddExitCallback(commandThreadExitCallback, hthread);

    spDebug(10, "spCreateCommandThread", "done\n");
    
    return SP_TRUE;
}
