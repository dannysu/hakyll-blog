/*
 *	memory.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#if defined(MACOSX)
#include <CoreServices/CoreServices.h>
#elif defined(MACOS)
#include <MacTypes.h>
#include <Memory.h>
#include <Sound.h>
#endif

#define MEMORY_SERIES

static int sp_memory_error_exit = 1;

void spSetMemoryErrorExit(int flag)
{
    sp_memory_error_exit = flag;
    return;
}

char *xspMalloc(int nbytes)
{
    char *p;

    if (nbytes <= 0) {
	nbytes = 1;
    }

    p = (char *)malloc((unsigned int)nbytes);
#if defined(MACOS)
    if (p != NULL && MemError() != noErr) {
	_xspFree(p); p = NULL;
    }
#endif

    if (p == NULL && sp_memory_error_exit) {
	spError(-1, "Can't malloc %d bytes\n", nbytes);
    }

    return p;
}

char *xspRemalloc(char *p, int nbytes)
{
    if (nbytes <= 0) {
	nbytes = 1;
    }

    if (p == NULL) {
	return xspMalloc(nbytes);
    }

    p = (char *)realloc(p, (unsigned int)nbytes);
#if defined(MACOS)
    if (p != NULL && MemError() != noErr) {
	p = NULL;
    }
#endif

    if (p == NULL && sp_memory_error_exit) {
	spError(-1, "Can't realloc %d bytes\n",nbytes);
    }

    return p;
}

void _xspFree(char *p)
{
    free(p);
    return;
}

int **xspIMatAlloc(int row, int col)
{
    int i;
    int **mat;
	
    row = MAX(row, 1);
    col = MAX(col, 1);
	
    mat = xalloc(row, int *);

#ifdef MEMORY_SERIES
    *mat = xalloc(row * col, int);
    for (i = 0; i < row; i++) {
	*(mat + i) = *mat + i * col;
    }
#else 
    for (i = 0; i < row; i++) {
	*(mat + i) = xalloc(col, int);
    }
#endif

    return mat;
}

void xspIMatFree(int **mat, int row)
{
    row = MAX(row, 1);

#ifdef MEMORY_SERIES
    xfree(*mat);
#else
    {
	int i;
	for (i = 0; i < row; i++) {
	    xfree(*(mat + i));
	}
    }
#endif

    xfree(mat);
}

short **xspSMatAlloc(int row, int col)
{
    int i;
    short **mat;

    row = MAX(row, 1);
    col = MAX(col, 1);
	
    mat = xalloc(row, short *);

#ifdef MEMORY_SERIES
    *mat = xalloc(row * col, short);
    for (i = 0; i < row; i++) {
	*(mat + i) = *mat + i * col;
    }
#else 
    for (i = 0; i < row; i++) {
	*(mat + i) = xalloc(col, short);
    }
#endif

    return mat;
}

void xspSMatFree(short **mat, int row)
{
    row = MAX(row, 1);

#ifdef MEMORY_SERIES
    xfree(*mat);
#else
    {
	int i;
	for (i = 0; i < row; i++) {
	    xfree(*(mat + i));
	}
    }
#endif

    xfree(mat);
}

long **xspLMatAlloc(int row, int col)
{
    int i;
    long **mat;
	
    row = MAX(row, 1);
    col = MAX(col, 1);
	
    mat = xalloc(row, long *);

#ifdef MEMORY_SERIES
    *mat = xalloc(row * col, long);
    for (i = 0; i < row; i++) {
	*(mat + i) = *mat + i * col;
    }
#else 
    for (i = 0; i < row; i++) {
	*(mat + i) = xalloc(col, long);
    }
#endif

    return mat;
}

void xspLMatFree(long **mat, int row)
{
    row = MAX(row, 1);

#ifdef MEMORY_SERIES
    xfree(*mat);
#else
    {
	int i;
	for (i = 0; i < row; i++) {
	    xfree(*(mat + i));
	}
    }
#endif

    xfree(mat);
}

float **xspFMatAlloc(int row, int col)
{
    int i;
    float **mat;

    row = MAX(row, 1);
    col = MAX(col, 1);
	
    mat = xalloc(row, float *);

#ifdef MEMORY_SERIES
    *mat = xalloc(row * col, float);
    for (i = 0; i < row; i++) {
	*(mat + i) = *mat + i * col;
    }
#else 
    for (i = 0; i < row; i++) {
	*(mat + i) = xalloc(col, float);
    }
#endif

    return mat;
}

void xspFMatFree(float **mat, int row)
{
    row = MAX(row, 1);

#ifdef MEMORY_SERIES
    xfree(*mat);
#else
    {
	int i;
	for (i = 0; i < row; i++) {
	    xfree(*(mat + i));
	}
    }
#endif

    xfree(mat);
}

double **xspDMatAlloc(int row, int col)
{
    int i;
    double **mat;
	
    row = MAX(row, 1);
    col = MAX(col, 1);
	
    mat = xalloc(row, double *);

#ifdef MEMORY_SERIES
    *mat = xalloc(row * col, double);
    for (i = 0; i < row; i++) {
	*(mat + i) = *mat + i * col;
    }
#else 
    for (i = 0; i < row; i++) {
	*(mat + i) = xalloc(col, double);
    }
#endif

    return mat;
}

void xspDMatFree(double **mat, int row)
{
    row = MAX(row, 1);

#ifdef MEMORY_SERIES
    xfree(*mat);
#else
    {
	int i;
	for (i = 0; i < row; i++) {
	    xfree(*(mat + i));
	}
    }
#endif

    xfree(mat);
}

char *xspStrClone(char *string)
{
    char *buf;

    if (string == NULL)
	return NULL;

    buf = xalloc((strlen(string) + 1), char);
    strcpy(buf, string);

    return buf;
}
