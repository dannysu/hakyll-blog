/*
 *	spInputPlugin.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spInputPluginP.h>

spBool spIsInputPlugin(spPlugin *plugin)
{
    if (plugin == NULL) return SP_FALSE;

    if (spEqPluginType(plugin, SP_PLUGIN_INPUT) == SP_TRUE) {
	spDebug(80, "spIsInputPlugin", "SP_TRUE\n");
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

long _spReadPlugin(spPlugin *plugin, char *data, long length)
{
    spInputPluginRec *rec;

    if (spIsInputPlugin(plugin) == SP_FALSE) return -1;
    
    rec = (spInputPluginRec *)plugin->rec;

    if (rec->read == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;
    
    return rec->read(plugin->instance, data, length);
}

#if 1
/* if prev_length < 0, put zeros. */
static long readPluginShift(spPlugin *plugin, long prev_length, long shift_length,
			    char *data, long length, spBool double_flag)
{
    long k;
    int samp_bit;
    int input_samp_bit;
    int file_samp_bit;
    long shift_byte;
    long read_length;
    long offset_length, offset_byte;
    spInputPluginRec *rec;

    if (spIsInputPlugin(plugin) == SP_FALSE || shift_length < 0
	|| data == NULL || length < 0) return -1;
    
    rec = (spInputPluginRec *)plugin->rec;

    if (rec->read == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;

    if (spGetPluginSampleBit(plugin, &file_samp_bit) == SP_FALSE) {
	return -1;
    }
    if (spGetPluginDataSampleBit(plugin, &input_samp_bit) == SP_FALSE) {
	return -1;
    }
    if (double_flag == SP_TRUE) {
	samp_bit = sizeof(double) * 8;
    } else {
	samp_bit = input_samp_bit;
    }

    if (prev_length <= 0) {
	offset_length = -prev_length;
    } else {
	offset_length = prev_length - shift_length;
    }
    read_length = length - MAX(offset_length, 0);
    shift_byte = shift_length * (samp_bit / 8);
    offset_byte = offset_length * (samp_bit / 8);
    
    if (prev_length < 0) {
	if (file_samp_bit > 33 || double_flag == SP_TRUE) {
	    double *ddata;
	    
	    ddata = (double *)data;
	    for (k = 0; k < offset_length; k++) {
		ddata[k] = 0.0;
	    }
	} else if (file_samp_bit == 33) {
	    float *fdata;
	    
	    fdata = (float *)data;
	    for (k = 0; k < offset_length; k++) {
		fdata[k] = 0.0;
	    }
	} else {
	    memset(data, 0, offset_byte);
	}
	
	if (read_length < 0) {
	    read_length = 0;
	}
    } else {
	if (read_length < 0) return -1;
	    
	if (offset_length > 0) {
	    /* shift data */
	    memmove(data, data + shift_byte, offset_byte);
	} else {
	    offset_length = 0;
	    offset_byte = 0;
	}
    }

    if (read_length > 0) {
	if ((read_length = rec->read(plugin->instance, data + offset_byte, read_length)) > 0) {
	    spDebug(80, "readPluginShift", "read_length = %ld\n", read_length);
	    if (double_flag == SP_TRUE && input_samp_bit < sizeof(double) * 8) {
		double *odata;
		
		odata = (double *)(data + offset_byte);
		
		if (file_samp_bit <= 16) {
		    short *sdata;
		
		    sdata = (short *)(data + offset_byte);
		    for (k = read_length - 1; k >= 0; k--) {
			odata[k] = (double)sdata[k];
		    }
		} else if (file_samp_bit <= 32) {
		    long *ldata;
		    
		    ldata = (long *)(data + offset_byte);
		    for (k = read_length - 1; k >= 0; k--) {
			odata[k] = (double)ldata[k];
		    }
		} else if (file_samp_bit == 33) {
		    float *fdata;
		    
		    fdata = (float *)(data + offset_byte);
		    for (k = read_length - 1; k >= 0; k--) {
			odata[k] = (double)fdata[k];
		    }
		}
	    }
	}
    }

    return read_length;
}

long _spReadPluginShift(spPlugin *plugin, long prev_length, long shift_length, char *data, long length)
{
    return readPluginShift(plugin, prev_length, shift_length, data, length, SP_FALSE);
}

long spReadPluginShiftDouble(spPlugin *plugin, long prev_length, long shift_length, double *data, long length)
{
    return readPluginShift(plugin, prev_length, shift_length, (char *)data, length, SP_TRUE);
}
#endif

spBool spSeekPlugin(spPlugin *plugin, long pos)
{
    spInputPluginRec *rec;

    if (spIsInputPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spInputPluginRec *)plugin->rec;

    if (rec->seek == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->seek(plugin->instance, pos);
}

long spGetPluginTotalLength(spPlugin *plugin)
{
    spInputPluginRec *rec;

    if (spIsInputPlugin(plugin) == SP_FALSE) return -1;
    
    rec = (spInputPluginRec *)plugin->rec;

    if (rec->get_total_length == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;
    
    return rec->get_total_length(plugin->instance);
}
