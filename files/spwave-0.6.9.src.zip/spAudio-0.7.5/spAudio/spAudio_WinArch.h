/*
 *	spAudio_WinArch.h
 */

#ifndef __SPAUDIO_WINARCH_H
#define __SPAUDIO_WINARCH_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32) && !defined(WINMMAPI)
#define	WINMMAPI

DECLARE_HANDLE(HWAVE);
DECLARE_HANDLE(HWAVEIN);
DECLARE_HANDLE(HWAVEOUT);
typedef HWAVEIN *LPHWAVEIN;
typedef HWAVEOUT *LPHWAVEOUT;

typedef struct tWAVEFORMATEX {
    WORD wFormatTag;     
    WORD nChannels;      
    DWORD nSamplesPerSec; 
    DWORD nAvgBytesPerSec;
    WORD nBlockAlign;    
    WORD wBitsPerSample; 
    WORD cbSize;         
} WAVEFORMATEX, *PWAVEFORMATEX, *NPWAVEFORMATEX, *LPWAVEFORMATEX;
typedef const WAVEFORMATEX *LPCWAVEFORMATEX;
#endif

#if defined(_WIN32) && !defined(MMSYSERR_NOERROR)
#define MAXPNAMELEN 32
#define MAXERRORLENGTH 256

typedef UINT MMVERSION;
typedef UINT MMRESULT;
typedef UINT *LPUINT;

typedef DWORD FOURCC;
typedef char *HPSTR;

typedef struct wavehdr_tag {
    LPSTR lpData;           
    DWORD dwBufferLength;   
    DWORD dwBytesRecorded;  
    DWORD dwUser;           
    DWORD dwFlags;          
    DWORD dwLoops;          
    struct wavehdr_tag *lpNext;   
    DWORD reserved;         
} WAVEHDR, *PWAVEHDR, *NPWAVEHDR, *LPWAVEHDR;

typedef struct mmtime_tag {
    UINT wType;
    union {
	DWORD ms;     	/* milliseconds */
	DWORD sample;  	/* samples */
	DWORD cb;    	/* byte count */
	DWORD ticks;	/* ticks in MIDI stream */
	/* SMPTE */
	struct {
	    BYTE hour; 	/* hours */
	    BYTE min;   /* minutes */
	    BYTE sec; 	/* seconds */
	    BYTE frame;	/* frames  */
	    BYTE fps;	/* frames per second */
	    BYTE dummy;	/* pad */
	    BYTE pad[2];
	} smpte;
	/* MIDI */
	struct {
	    DWORD songptrpos;	/* song pointer position */
	} midi;
    } u;
} MMTIME, *PMMTIME, *NPMMTIME, *LPMMTIME;

#define TIME_MS 		(0x0001)
#define TIME_SAMPLES 		(0x0002)
#define TIME_BYTES 		(0x0004)
#define TIME_SMPTE 		(0x0008)
#define TIME_MIDI 		(0x0010)
#define TIME_TICKS 		(0x0020)

#define CALLBACK_TYPEMASK 	(0x00070000l)
#define CALLBACK_NULL 		(0x00000000l)
#define CALLBACK_WINDOW 	(0x00010000l)
#define CALLBACK_TASK 		(0x00020000l)
#define CALLBACK_FUNCTION 	(0x00030000l)
#define CALLBACK_THREAD 	(CALLBACK_TASK)
#define CALLBACK_EVENT 		(0x00050000l)

#define MMSYSERR_NOERROR 	0
#define MMSYSERR_ERROR 		(MMSYSERR_BASE + 1)
#define MMSYSERR_BADDEVICEID 	(MMSYSERR_BASE + 2)
#define MMSYSERR_NOTENABLED 	(MMSYSERR_BASE + 3)
#define MMSYSERR_ALLOCATED 	(MMSYSERR_BASE + 4)
#define MMSYSERR_INVALHANDLE 	(MMSYSERR_BASE + 5)
#define MMSYSERR_NODRIVER 	(MMSYSERR_BASE + 6) 
#define MMSYSERR_NOMEM        	(MMSYSERR_BASE + 7) 
#define MMSYSERR_NOTSUPPORTED 	(MMSYSERR_BASE + 8) 
#define MMSYSERR_BADERRNUM    	(MMSYSERR_BASE + 9) 
#define MMSYSERR_INVALFLAG    	(MMSYSERR_BASE + 10)
#define MMSYSERR_INVALPARAM   	(MMSYSERR_BASE + 11)
#define MMSYSERR_HANDLEBUSY   	(MMSYSERR_BASE + 12)
#define MMSYSERR_INVALIDALIAS 	(MMSYSERR_BASE + 13)
#define MMSYSERR_BADDB        	(MMSYSERR_BASE + 14)
#define MMSYSERR_KEYNOTFOUND  	(MMSYSERR_BASE + 15)
#define MMSYSERR_READERROR    	(MMSYSERR_BASE + 16)
#define MMSYSERR_WRITEERROR   	(MMSYSERR_BASE + 17)
#define MMSYSERR_DELETEERROR  	(MMSYSERR_BASE + 18)
#define MMSYSERR_VALNOTFOUND  	(MMSYSERR_BASE + 19)
#define MMSYSERR_NODRIVERCB   	(MMSYSERR_BASE + 20)
#define MMSYSERR_LASTERROR    	(MMSYSERR_BASE + 20)
    
#define WAVERR_BADFORMAT      	(WAVERR_BASE + 0)   
#define WAVERR_STILLPLAYING   	(WAVERR_BASE + 1)   
#define WAVERR_UNPREPARED     	(WAVERR_BASE + 2)   
#define WAVERR_SYNC           	(WAVERR_BASE + 3)   
#define WAVERR_LASTERROR      	(WAVERR_BASE + 3)   

#define WOM_OPEN		MM_WOM_OPEN
#define WOM_CLOSE     		MM_WOM_CLOSE
#define WOM_DONE       		MM_WOM_DONE
#define WIM_OPEN      		MM_WIM_OPEN
#define WIM_CLOSE     		MM_WIM_CLOSE
#define WIM_DATA      		MM_WIM_DATA

#define WAVE_MAPPER   		((UINT)-1)

#define  WAVE_FORMAT_QUERY  	(0x0001)
#define  WAVE_ALLOWSYNC      	(0x0002)
#define  WAVE_MAPPED          	(0x0004)
#define  WAVE_FORMAT_DIRECT   	(0x0008)
#define  WAVE_FORMAT_DIRECT_QUERY	(WAVE_FORMAT_QUERY | WAVE_FORMAT_DIRECT)

#define WHDR_DONE      		(0x00000001)
#define WHDR_PREPARED  		(0x00000002)
#define WHDR_BEGINLOOP 		(0x00000004)
#define WHDR_ENDLOOP   		(0x00000008)
#define WHDR_INQUEUE  		(0x00000010)

#define WAVECAPS_PITCH  	(0x0001)
#define WAVECAPS_PLAYBACKRATE  	(0x0002)
#define WAVECAPS_VOLUME        	(0x0004)
#define WAVECAPS_LRVOLUME      	(0x0008)
#define WAVECAPS_SYNC         	(0x0010)
#define WAVECAPS_SAMPLEACCURATE	(0x0020)
#define WAVECAPS_DIRECTSOUND  	(0x0040)

#ifndef UNICODE_ONLY
typedef struct tagWAVEOUTCAPSA {
    WORD wMid;                 
    WORD wPid;                 
    MMVERSION vDriverVersion;     
    CHAR szPname[MAXPNAMELEN]; 
    DWORD dwFormats;            
    WORD wChannels;            
    WORD wReserved1;           
    DWORD dwSupport;            
} WAVEOUTCAPSA, *PWAVEOUTCAPSA, *NPWAVEOUTCAPSA, *LPWAVEOUTCAPSA;

typedef struct tagWAVEINCAPSA {
    WORD wMid;                 
    WORD wPid;                 
    MMVERSION vDriverVersion;     
    CHAR szPname[MAXPNAMELEN]; 
    DWORD dwFormats;            
    WORD wChannels;            
    WORD wReserved1;           
} WAVEINCAPSA, *PWAVEINCAPSA, *NPWAVEINCAPSA, *LPWAVEINCAPSA;

WINMMAPI MMRESULT WINAPI waveOutGetDevCapsA(UINT uDeviceID, LPWAVEOUTCAPSA pwoc, UINT cbwoc);
WINMMAPI MMRESULT WINAPI waveOutGetErrorTextA(MMRESULT mmrError, LPSTR pszText, UINT cchText);
WINMMAPI MMRESULT WINAPI waveInGetDevCapsA(UINT uDeviceID, LPWAVEINCAPSA pwic, UINT cbwic);
WINMMAPI MMRESULT WINAPI waveInGetErrorTextA(MMRESULT mmrError, LPSTR pszText, UINT cchText);
#endif /* !UNICODE_ONLY */
#ifndef ANSI_ONLY
typedef struct tagWAVEOUTCAPSW {
    WORD wMid;                 
    WORD wPid;                 
    MMVERSION vDriverVersion;     
    WCHAR szPname[MAXPNAMELEN]; 
    DWORD dwFormats;            
    WORD wChannels;            
    WORD wReserved1;           
    DWORD dwSupport;            
} WAVEOUTCAPSW, *PWAVEOUTCAPSW, *NPWAVEOUTCAPSW, *LPWAVEOUTCAPSW;

typedef struct tagWAVEINCAPSW {
    WORD wMid;                 
    WORD wPid;                 
    MMVERSION vDriverVersion;     
    WCHAR szPname[MAXPNAMELEN]; 
    DWORD dwFormats;            
    WORD wChannels;            
    WORD wReserved1;           
} WAVEINCAPSW, *PWAVEINCAPSW, *NPWAVEINCAPSW, *LPWAVEINCAPSW;

WINMMAPI MMRESULT WINAPI waveOutGetDevCapsW(UINT uDeviceID, LPWAVEOUTCAPSW pwoc, UINT cbwoc);
WINMMAPI MMRESULT WINAPI waveOutGetErrorTextW(MMRESULT mmrError, LPWSTR pszText, UINT cchText);
WINMMAPI MMRESULT WINAPI waveInGetDevCapsW(UINT uDeviceID, LPWAVEINCAPSW pwic, UINT cbwic);
WINMMAPI MMRESULT WINAPI waveInGetErrorTextW(MMRESULT mmrError, LPWSTR pszText, UINT cchText);
#endif /* !ANSI_ONLY */
#ifdef UNICODE
typedef WAVEOUTCAPSW WAVEOUTCAPS;
typedef PWAVEOUTCAPSW PWAVEOUTCAPS;
typedef NPWAVEOUTCAPSW NPWAVEOUTCAPS;
typedef LPWAVEOUTCAPSW LPWAVEOUTCAPS;

typedef WAVEINCAPSW WAVEINCAPS;
typedef PWAVEINCAPSW PWAVEINCAPS;
typedef NPWAVEINCAPSW NPWAVEINCAPS;
typedef LPWAVEINCAPSW LPWAVEINCAPS;

#define waveOutGetDevCaps  waveOutGetDevCapsW
#define waveOutGetErrorText  waveOutGetErrorTextW
#define waveInGetDevCaps  waveInGetDevCapsW
#define waveInGetErrorText  waveInGetErrorTextW
#else
typedef WAVEOUTCAPSA WAVEOUTCAPS;
typedef PWAVEOUTCAPSA PWAVEOUTCAPS;
typedef NPWAVEOUTCAPSA NPWAVEOUTCAPS;
typedef LPWAVEOUTCAPSA LPWAVEOUTCAPS;

typedef WAVEINCAPSA WAVEINCAPS;
typedef PWAVEINCAPSA PWAVEINCAPS;
typedef NPWAVEINCAPSA NPWAVEINCAPS;
typedef LPWAVEINCAPSA LPWAVEINCAPS;

#define waveOutGetDevCaps  waveOutGetDevCapsA
#define waveOutGetErrorText  waveOutGetErrorTextA
#define waveInGetDevCaps  waveInGetDevCapsA
#define waveInGetErrorText  waveInGetErrorTextA
#endif /* UNICODE */

WINMMAPI UINT WINAPI waveOutGetNumDevs(void);
WINMMAPI MMRESULT WINAPI waveOutGetVolume(HWAVEOUT hwo, LPDWORD pdwVolume);
WINMMAPI MMRESULT WINAPI waveOutSetVolume(HWAVEOUT hwo, DWORD dwVolume);
WINMMAPI MMRESULT WINAPI waveOutOpen(LPHWAVEOUT phwo, UINT uDeviceID,
    LPCWAVEFORMATEX pwfx, DWORD dwCallback, DWORD dwInstance, DWORD fdwOpen);
WINMMAPI MMRESULT WINAPI waveOutClose(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutPrepareHeader(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutUnprepareHeader(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutWrite(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutPause(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutRestart(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutReset(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutBreakLoop(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutGetPosition(HWAVEOUT hwo, LPMMTIME pmmt, UINT cbmmt);
WINMMAPI MMRESULT WINAPI waveOutGetPitch(HWAVEOUT hwo, LPDWORD pdwPitch);
WINMMAPI MMRESULT WINAPI waveOutSetPitch(HWAVEOUT hwo, DWORD dwPitch);
WINMMAPI MMRESULT WINAPI waveOutGetPlaybackRate(HWAVEOUT hwo, LPDWORD pdwRate);
WINMMAPI MMRESULT WINAPI waveOutSetPlaybackRate(HWAVEOUT hwo, DWORD dwRate);
WINMMAPI MMRESULT WINAPI waveOutGetID(HWAVEOUT hwo, LPUINT puDeviceID);
WINMMAPI MMRESULT WINAPI waveOutMessage(HWAVEOUT hwo, UINT uMsg, DWORD dw1, DWORD dw2);
WINMMAPI UINT WINAPI waveInGetNumDevs(void);
WINMMAPI MMRESULT WINAPI waveInOpen(LPHWAVEIN phwi, UINT uDeviceID,
    LPCWAVEFORMATEX pwfx, DWORD dwCallback, DWORD dwInstance, DWORD fdwOpen);
WINMMAPI MMRESULT WINAPI waveInClose(HWAVEIN hwi);
WINMMAPI MMRESULT WINAPI waveInPrepareHeader(HWAVEIN hwi, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveInUnprepareHeader(HWAVEIN hwi, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveInAddBuffer(HWAVEIN hwi, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveInStart(HWAVEIN hwi);
WINMMAPI MMRESULT WINAPI waveInStop(HWAVEIN hwi);
WINMMAPI MMRESULT WINAPI waveInReset(HWAVEIN hwi);
WINMMAPI MMRESULT WINAPI waveInGetPosition(HWAVEIN hwi, LPMMTIME pmmt, UINT cbmmt);
WINMMAPI MMRESULT WINAPI waveInGetID(HWAVEIN hwi, LPUINT puDeviceID);
WINMMAPI MMRESULT WINAPI waveInMessage(HWAVEIN hwi, UINT uMsg, DWORD dw1, DWORD dw2);

#endif /* defined(_WIN32) && !defined(MMSYSERR_NOERROR) */

extern spWinAudio spInitAudio_Win(long num_buffer, long buffer_size);
extern spBool spFreeAudio_Win(spWinAudio audio);

extern spBool spOpenAudioDevice_Win(spWinAudio audio, int samp_bit, int num_channel,
				    double samp_rate, spBool nonblock_flag, spBool output_flag);
extern spBool spCloseAudioDevice_Win(spWinAudio audio);

extern long spReadWave_Win(spWinAudio audio, char *data, long length);
extern long spWriteWave_Win(spWinAudio audio, char *data, long length);
extern spBool spGetAudioOutputPosition_Win(spWinAudio audio, long *position);
extern spBool spResetDevice_Win(spWinAudio audio);
extern spBool spSyncDevice_Win(spWinAudio audio);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPAUDIO_WINARCH_H */
