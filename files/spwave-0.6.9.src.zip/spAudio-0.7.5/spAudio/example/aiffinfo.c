/*
 *	aiffinfo.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spBaseLib.h>
#include <sp/spWave.h>

static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<filename...>",
};

int main(int argc, char *argv[])
{
    char *filename;
    FILE *fp;
    spWaveInfo wave_info;
    spSongInfo song_info;

    spSetHelpMessage(&help_flag, "Get AIFF file information");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);

    spSetDebugLevel(debug_level);
    
    filename = spGetFile(options);
    if (filename == NULL) {
	spError(1, "Not enough files.\n");
    }

    do {
	/* open file */
	if (NULL == (fp = spOpenFile(filename, "rb"))) {
	    return 1;
	}
	
	printf("%s:\n", filename);
	
	/* read information */
	if (spReadAiffInfo(&wave_info, fp) == SP_FALSE) {
	    printf("  ");
	    printf("This file is not AIFF file.\n");
	} else {
	    printf("  ");
	    printf("Format: %s\n  Number of Channels: %d, Sampling Rate: %.0f [Hz]\n",
		      wave_info.file_desc, wave_info.num_channel,
		      wave_info.samp_rate);
	    printf("  ");
	    printf("Bits/Sample: %d, Data Length: %ld\n",
		      wave_info.samp_bit, wave_info.length);

	    /* read song information */
	    if (spReadAiffSongInfo(&wave_info, &song_info, fp) == SP_TRUE) {
		spShowSongInfo(&song_info, "  ", stdout);
	    }
	}
    
	/* close file */
	spCloseFile(fp);
    } while ((filename = spGetFile(options)) != NULL);
    
    return 0;
}
