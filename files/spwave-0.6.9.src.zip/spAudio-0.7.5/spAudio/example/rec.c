#include <stdio.h>

#include <sp/spBaseLib.h>
#include <sp/spAudio.h>
#include <sp/spWave.h>
#include <sp/spMain.h>

#ifdef SP_SUPPORT_AUDIO

static double samp_freq = 8000.0;
static int num_channel = 1;
static int samp_bit = 16;
static double rec_time = 3.0;
static long buffer_size = 1024;
static char format_string[SP_MAX_LINE] = "wav";
static spBool nonblock_flag = SP_FALSE;

static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-t", "-time", "recording time [sec]", NULL,
	 SP_TYPE_DOUBLE, &rec_time, "3.0"},
    {"-f", "-freq", "sampling frequency for raw data [Hz]", NULL,
	 SP_TYPE_DOUBLE, &samp_freq, "8000.0"},
    {"-c", "-channel", "number of channel for raw data", NULL,
	 SP_TYPE_INT, &num_channel, "1"},
    {"-b", "-bit", "bits per sample for raw data", NULL,
	 SP_TYPE_INT, &samp_bit, "16"},
    {"-F", "-format", "file format (wav|raw|swap|little|big)", NULL,
	 SP_TYPE_STRING_A, format_string, "wav"},
    {"-buf", NULL, "buffer size", NULL,
	 SP_TYPE_LONG, &buffer_size, "1024"},
    {"-n", "-nonblock", "record with nonblocking mode", NULL,
	 SP_TYPE_BOOLEAN, &nonblock_flag, SP_FALSE_STRING},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<filename...>",
};

int spMain(int argc, char *argv[])
{
    spBool swap;
    spBool wav_flag;
    long length;
    long total_length;
    long nwrite, nread;
    short *data;
    char *filename;
    FILE *fp;
    spAudio audio;
    spWaveInfo wave_info;

    spSetHelpMessage(&help_flag, "Record sound file");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);
    spSetMessageFlag(0);

    swap = SP_FALSE;
    wav_flag = SP_FALSE;
    
    if (strcaseeq(format_string, "wav")) {
	spDebug(10, NULL, "format_string = %s\n", format_string);
	wav_flag = SP_TRUE;
    } else if (strcaseeq(format_string, "swap")
	       || (strcaseeq(format_string, "little") && BYTE_ORDER == BIG_ENDIAN)
	       || (strcaseeq(format_string, "big") && BYTE_ORDER == LITTLE_ENDIAN)) {
	swap = SP_TRUE;
    }

    if ((audio = spInitAudio()) == NULL) {
	spError(1, "Can't initialize audio.\n");
    }

    filename = spGetFile(options);
    if (filename == NULL) {
	spError(1, "Not enough files.\n");
    }

    spInitWaveInfo(&wave_info);
    wave_info.samp_rate = samp_freq;
    wave_info.num_channel = num_channel;
    wave_info.length = 1;
    
    spSetAudioSampleRate(audio, wave_info.samp_rate);
    spSetAudioChannel(audio, wave_info.num_channel);
    spSetAudioBufferSize(audio, buffer_size);
    if (nonblock_flag == SP_TRUE) {
	spSetAudioBlockingMode(audio, SP_AUDIO_NONBLOCKING);
    }
    
    /* open output audio device */
    if (!spOpenAudioDevice(audio, "ro")) {
	spError(1, "Can't open audio device.\n");
    }
    
    spGetAudioSampleRate(audio, &wave_info.samp_rate);
    spGetAudioChannel(audio, &wave_info.num_channel);
    total_length = spRound(wave_info.samp_rate * rec_time) * wave_info.num_channel;
    
    /*length = buffer_size / 2;*/
    length = 8 * buffer_size;
    length = MIN(total_length, length);
    data = xalloc(length, short);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	spError(1, "Can't open file: %s\n", filename);
    }
    
    if (wav_flag == SP_TRUE) {
	/* write wave information */
	if (spWriteWavInfo(&wave_info, fp) == SP_FALSE) {
	    spError(1, "Can't write wave information: %s\n", filename);
	}
    }

    wave_info.length = 0;
    while (wave_info.length < total_length) {
	if (wave_info.length + length > total_length) {
	    length = total_length - wave_info.length;
	}
	
	/* read data from audio device */
	if ((nread = spReadAudio(audio, data, length)) <= 0) {
	    break;
	}
	spDebug(1, NULL, "nread = %ld, length = %ld\n", nread, length);

	if (nread > 0) {
	    if (wav_flag == SP_TRUE) {
		nwrite = spWriteWavData(&wave_info, data, nread, fp);
	    } else {
		if (wave_info.samp_bit == 8) {
		    nwrite = fwritebyte(data, nread, fp);
		} else {
		    nwrite = fwriteshort(data, nread, swap, fp);
		}
	    }
	    spDebug(1, NULL, "nwrite = %ld, wave_info.length = %ld\n",
		    nwrite, wave_info.length);
	
	    wave_info.length += nwrite;
	}
    }
    
    /* close audio device */
    spCloseAudioDevice(audio);
    spFreeAudio(audio);
    
    if (wav_flag == SP_TRUE) {
	wave_info.length /= wave_info.num_channel;
	/* write wave information */
	if (spWriteWavInfo(&wave_info, fp) == SP_FALSE) {
	    spError(1, "Can't write wave information: %s\n", filename);
	}
    }

    /* close file */
    spCloseFile(fp);
    
    printf("%s:\n", filename);
    printf("  ");
    if (!strnone(wave_info.file_desc)) {
	printf("Format: %s\n", wave_info.file_desc);
    }
    printf("Number of Channels: %d, Sampling Rate: %.0f [Hz]\n",
	   wave_info.num_channel, wave_info.samp_rate);
    printf("  ");
    printf("Bits/Sample: %d, Data Length: %ld\n",
	   wave_info.samp_bit, wave_info.length);
    
    return 0;
}
#else
int spMain(int argc, char *argv[])
{
    spError(1, "Audio is not supported.\n");
    return 0;
}
#endif

