#include <stdio.h>

#include <sp/spBaseLib.h>
#include <sp/spAudio.h>
#include <sp/spMain.h>

#ifdef SP_SUPPORT_AUDIO

static double rec_time;
static long buffer_size;
static double input_gain;
static double samp_freq;
static int num_channel;
static int num_buffer;

static spBool endless_flag;
static spBool duplex_flag;
static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-f", "-freq", "sampling frequency [Hz]", NULL,
	 SP_TYPE_DOUBLE, &samp_freq, "8000.0"},
    {"-c", "-channel", "number of channel", NULL,
	 SP_TYPE_INT, &num_channel, "1"},
    {"-igain", NULL, "input gain", NULL,
	 SP_TYPE_DOUBLE, &input_gain, "1.0"},
    {"-time", NULL, "recording time [s]", NULL,
	 SP_TYPE_DOUBLE, &rec_time, "3.0"},
    {"-buf", NULL, "buffer size", NULL,
	 SP_TYPE_LONG, &buffer_size, "256"},
    {"-nbuf", NULL, "number of buffers (valid only on Windows)", NULL,
	 SP_TYPE_LONG, &num_buffer, "256"},
    {"-endless", NULL, "recording endlessly (full duplex mode only)", NULL,
	 SP_TYPE_BOOLEAN, &endless_flag, SP_FALSE_STRING},
    {"-duplex", NULL, "full duplex mode", NULL,
	 SP_TYPE_BOOLEAN, &duplex_flag, SP_FALSE_STRING},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "",
};

int spMain(int argc, char *argv[])
{
    long k, l;
    long nread;
    long length;
    long rec_length;
    short *wave_data;
    long wave_length;
    spAudio audio;

    spSetHelpMessage(&help_flag, "Audio I/O test");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    rec_length = (long)spRound(rec_time * samp_freq);

    if ((audio = spInitAudio()) == NULL) {
	spError(1, "Can't initialize audio.\n");
    }
    spDebug(1, NULL, "init audio done\n");

    spSetAudioSampleRate(audio, samp_freq);
    spSetAudioChannel(audio, num_channel);
    spSetAudioNumBuffer(audio, num_buffer);

    spDebug(1, NULL, "set buffer size: %d\n", spSetAudioBufferSize(audio, buffer_size));

    if (duplex_flag == SP_TRUE) {
	for (l = 0; l < 2; l++) {
	    /* open input audio device */
	    if (!spOpenAudioDevice(audio, "r")) {
		spError(1, "Can't open audio device.\n");
	    }
	    spDebug(1, NULL, "open input audio device done\n");
	    
	    /* open output audio device */
	    if (!spOpenAudioDevice(audio, "w")) {
		spError(1, "Can't open audio device with full duplex mode.\n");
	    }
	    
	    spGetAudioChannel(audio, &num_channel);
	    
	    wave_length = buffer_size / 2;
	    wave_data = xalloc(wave_length, short);
	    
	    length = 0;
	    for (;;) {
		if ((nread = spReadAudio(audio, wave_data, wave_length)) < 0) {
		    spWarning("Can't read audio data.\n");
		    break;
		}

		if (input_gain != 1.0) {
		    for (k = 0; k < nread; k++) {
			wave_data[k] = (short)spRound(input_gain * (double)wave_data[k]);
		    }
		}
	    
		spWriteAudio(audio, wave_data, nread);
	    
		if (endless_flag == SP_FALSE) {
		    length += (nread / num_channel);
	    
		    if (length >= rec_length) {
			break;
		    }
		}
	    }
	    
	    spCloseAudioDevice(audio);
	}
    } else {
	for (l = 0; l < 2; l++) {
	    /* open input audio device */
	    if (!spOpenAudioDevice(audio, "r")) {
		spError(1, "Can't open audio device.\n");
	    }
	    spDebug(1, NULL, "open input audio device done\n");
	    
	    spGetAudioChannel(audio, &num_channel);
	    
	    wave_length = rec_length;
	    wave_data = xalloc(wave_length, short);
	    
	    nread = spReadAudio(audio, wave_data, wave_length);
	    spMessage("nread = %ld\n", nread);
	    spCloseAudioDevice(audio);
	    
	    if (input_gain != 1.0) {
		for (k = 0; k < nread; k++) {
		    wave_data[k] = (short)spRound(input_gain * (double)wave_data[k]);
		}
	    }
	    spMessage("read done\n");
	    spSleep(1);
	    
	    /* open output audio device */
	    if (!spOpenAudioDevice(audio, "w")) {
		spError(1, "Can't open audio device.\n");
	    }
	    spDebug(1, NULL, "open output audio device done\n");
	    
	    spWriteAudio(audio, wave_data, nread);
	    spCloseAudioDevice(audio);
	    
	    spMessage("write done\n");
	}
    }

    spFreeAudio(audio);
    
    return 0;
}
#else
int spMain(int argc, char *argv[])
{
    spError(1, "Audio is not supported.\n");
    return 0;
}
#endif
