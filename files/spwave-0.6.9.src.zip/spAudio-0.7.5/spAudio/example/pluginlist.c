#include <stdio.h>
#include <stdlib.h>

#include <sp/spBaseLib.h>
#include <sp/spAudioLib.h>
#include <sp/spMain.h>

int spMain(int argc, char *argv[])
{
    int i;
    char *plugin_name;

    for (i = 0;; i++) {
	if ((plugin_name = xspSearchPluginFile(i)) == NULL) {
	    break;
	}
	printf("%s\n", plugin_name);
	xfree(plugin_name);
    }
    
    return 0;
}
