#include <stdio.h>

#include <sp/spBaseLib.h>
#include <sp/spAudio.h>
#include <sp/spMain.h>

#ifdef SP_SUPPORT_AUDIO

static double fund_freq;
static double dur_time;
static double amplitude;
static double samp_freq;
static long buffer_size;

static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-f", "-freq", "sampling frequency [Hz]", NULL,
	 SP_TYPE_DOUBLE, &samp_freq, "8000.0"},
    {"-f0", NULL, "fundamental frequency [Hz]", NULL,
	 SP_TYPE_DOUBLE, &fund_freq, "1000.0"},
    {"-a", "-amp", "amplitude", NULL,
	 SP_TYPE_DOUBLE, &amplitude, "32000.0"},
    {"-d", "-dur", "duration [s]", NULL,
	 SP_TYPE_DOUBLE, &dur_time, "5.0"},
    {"-buf", NULL, "buffer size", NULL,
	 SP_TYPE_LONG, &buffer_size, "16384"},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "",
};

int spMain(int argc, char *argv[])
{
    long k;
    long offset;
    long data_length;
    double period;
    short *data;
    spAudio audio;

    spSetHelpMessage(&help_flag, "Play sin wave");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);
    spSetDebugStdout(SP_TRUE);

    spDebug(1, NULL, "samp_freq = %f, f0 = %f, duration = %f\n",
	   samp_freq, fund_freq, dur_time);
    
    data_length = (long)spRound(dur_time * samp_freq);
    period = samp_freq / fund_freq;

    spDebug(1, NULL, "data_length = %ld, period = %f\n", data_length, period);
    
    if ((audio = spInitAudio()) == NULL) {
	spError(1, "Can't initialize audio.\n");
    }
    spDebug(1, NULL, "init audio done\n");

    spSetAudioSampleRate(audio, samp_freq);
    spSetAudioChannel(audio, 1);

    spDebug(1, NULL, "set buffer size: %d\n", spSetAudioBufferSize(audio, buffer_size));

    /* open output audio device */
    if (!spOpenAudioDevice(audio, "w")) {
	spError(1, "Can't open audio device.\n");
    }
    spDebug(1, NULL, "open output audio device done\n");

    /* create data */
    data = xalloc(data_length, short);
    for (k = 0; k < data_length; k++) {
	data[k] = (short)spRound(amplitude * sin(2.0 * PI * (double)k / period));
    }
    /*offset = data_length / 2;*//* for checking */
    offset = 0;
    
    /* write data to audio device */
    spWriteAudio(audio, data + offset, data_length - offset);

    /* close audio device */
    spCloseAudioDevice(audio);
    spFreeAudio(audio);
    
    return 0;
}
#else
int spMain(int argc, char *argv[])
{
    spError(1, "Audio is not supported.\n");
    return 0;
}
#endif
