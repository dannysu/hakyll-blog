#include <stdio.h>

#include <sp/spBaseLib.h>
#include <sp/spAudio.h>
#include <sp/spWave.h>
#include <sp/spMain.h>

#ifdef SP_SUPPORT_AUDIO

static double samp_freq = 8000.0;
static int num_channel = 1;
static int samp_bit = 16;
static long buffer_size = 1024;
static char format_string[SP_MAX_LINE] = "raw";

static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-f", "-freq", "sampling frequency for raw data [Hz]", NULL,
	 SP_TYPE_DOUBLE, &samp_freq, "8000.0"},
    {"-c", "-channel", "number of channel for raw data", NULL,
	 SP_TYPE_INT, &num_channel, "1"},
    {"-b", "-bit", "bits per sample for raw data", NULL,
	 SP_TYPE_INT, &samp_bit, "16"},
    {"-F", "-format", "file format for raw data (raw|swap|little|big)", NULL,
	 SP_TYPE_STRING_A, format_string, "raw"},
    {"-buf", NULL, "buffer size", NULL,
	 SP_TYPE_LONG, &buffer_size, "1024"},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<filename...>",
};

int spMain(int argc, char *argv[])
{
    spBool swap;
    spBool wav_flag;
    long length;
    long nread;
    short *data;
    char *filename;
    FILE *fp;
    spAudio audio;
    spWaveInfo wave_info;

    spSetHelpMessage(&help_flag, "Play sound file");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);
    spSetMessageFlag(0);

    if (strcaseeq(format_string, "swap")
	|| (strcaseeq(format_string, "little") && BYTE_ORDER == BIG_ENDIAN)
	|| (strcaseeq(format_string, "big") && BYTE_ORDER == LITTLE_ENDIAN)) {
	swap = SP_TRUE;
    } else {
	swap = SP_FALSE;
    }

    length = buffer_size / 2;
    data = xalloc(length, short);

    if ((audio = spInitAudio()) == NULL) {
	spError(1, "Can't initialize audio.\n");
    }

    filename = spGetFile(options);
    if (filename == NULL) {
	spError(1, "Not enough files.\n");
    }
    
    do {
	/* open file */
	if (NULL == (fp = spOpenFile(filename, "rb"))) {
	    return 1;
	}
	
	printf("%s:\n", filename);
	printf("  ");
	
	/* read information */
	if (spReadWavInfo(&wave_info, fp) == SP_FALSE) {
	    strcpy(wave_info.file_desc, format_string);
	    wave_info.samp_rate = samp_freq;
	    wave_info.samp_bit = samp_bit;
	    wave_info.num_channel = num_channel;
	    wave_info.length = getfilesize(filename, 0) / (samp_bit / 8);
	    wav_flag = SP_FALSE;
	} else {
	    wav_flag = SP_TRUE;
	}
	if (!strnone(wave_info.file_desc)) {
	    printf("Format: %s\n", wave_info.file_desc);
	}
	printf("Number of Channels: %d, Sampling Rate: %.0f [Hz]\n",
	       wave_info.num_channel, wave_info.samp_rate);
	printf("  ");
	printf("Bits/Sample: %d, Data Length: %ld\n",
	       wave_info.samp_bit, wave_info.length);
    
	spSetAudioSampleRate(audio, wave_info.samp_rate);
	spSetAudioChannel(audio, wave_info.num_channel);
	spSetAudioBufferSize(audio, buffer_size);

	/* open output audio device */
	if (!spOpenAudioDevice(audio, "w")) {
	    spError(1, "Can't open audio device.\n");
	}

	for (;;) {
	    if (wav_flag == SP_TRUE) {
		nread = spReadWavData(&wave_info, data, length, fp);
	    } else {
		if (wave_info.samp_bit == 8) {
		    nread = freadbyte(data, length, fp);
		} else {
		    nread = freadshort(data, length, swap, fp);
		}
	    }
	    if (nread <= 0) {
		break;
	    }
	    
	    /* write data to audio device */
	    spWriteAudio(audio, data, nread);
	}
	    
	/* close audio device */
	spCloseAudioDevice(audio);
	
	/* close file */
	spCloseFile(fp);
    } while ((filename = spGetFile(options)) != NULL);
    
    spFreeAudio(audio);
    
    return 0;
}
#else
int spMain(int argc, char *argv[])
{
    spError(1, "Audio is not supported.\n");
    return 0;
}
#endif

