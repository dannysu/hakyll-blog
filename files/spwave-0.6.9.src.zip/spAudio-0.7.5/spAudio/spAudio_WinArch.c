/*
 *	spAudio_WinArch.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spWaveP.h>
#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(_WIN32)
#include <stdio.h>
#include <stdlib.h>

#include "spAudio_WinArch.h"

#define MAX_NUM_WAVE_BUFFER 256

struct _spWinAudio {
    int num_channel;
    long buffer_size;
    long num_prepare_buffer;
    spBool header_allocated;
    spBool start_flag;
    spBool wait_flag;
    spBool nonblock_flag;

    long buffer_index;
    long prev_index;
    long buffer_pos;
    
    long num_buffer;
    HANDLE hbuffer[MAX_NUM_WAVE_BUFFER];
    HPSTR lpbuffer[MAX_NUM_WAVE_BUFFER];
    HGLOBAL hwavehdr[MAX_NUM_WAVE_BUFFER];
    LPWAVEHDR lpwavehdr[MAX_NUM_WAVE_BUFFER];
    HANDLE hmutex;
    HANDLE hsemaphore;

    HWAVEIN hwavein;
    HWAVEOUT hwaveout;
    WAVEFORMATEX waveformat;
};

static void freeWaveBuffer(spWinAudio audio)
{
    long i;

    if (audio->num_buffer > 0) {
	for (i = 0; i < audio->num_buffer; i++) {
	    if (audio->lpbuffer[i] != NULL) {
		GlobalUnlock(audio->hbuffer[i]);
		audio->lpbuffer[i] = NULL;
	    }
	    if (audio->hbuffer[i] != NULL) {
		GlobalFree(audio->hbuffer[i]);
		audio->hbuffer[i] = NULL;
	    }
	}
    }
    
    if (audio->hsemaphore != NULL) {
	CloseHandle(audio->hsemaphore);
	audio->hsemaphore = NULL;
    }
    if (audio->hmutex != NULL) {
	CloseHandle(audio->hmutex);
	audio->hmutex = NULL;
    }
    
    audio->num_buffer = 0;
    
    return;
}

static spBool allocWaveBuffer(spWinAudio audio, long num_buffer, long buffer_size)
{
    long i;

    if (audio->num_buffer > 0) {
	for (i = 0; i < audio->num_buffer; i++) {
	    memset(audio->lpbuffer[i], 0, audio->buffer_size);
	}
	
	return SP_TRUE;
    }
    
    if ((audio->hmutex = CreateMutex(NULL, FALSE, NULL)) == NULL) {
	return SP_FALSE;
    }
    if ((audio->hsemaphore = CreateSemaphore(NULL, num_buffer, num_buffer, NULL)) == NULL) {
	freeWaveBuffer(audio);
	return SP_FALSE;
    }
    
    for (i = 0; i < num_buffer; i++) {
	/* allocate and lock memory for the waveform buffer */ 
	if ((audio->hbuffer[i] = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE | GMEM_ZEROINIT,
					     buffer_size)) == NULL) {
	    spMessage("can't allocate data memory\n");
	    freeWaveBuffer(audio);
	    return SP_FALSE;
	}

	if ((audio->lpbuffer[i] = GlobalLock(audio->hbuffer[i])) == NULL) {
	    spMessage("can't lock data memory\n");
	    freeWaveBuffer(audio);
	    return SP_FALSE;
	}
    }
    
    audio->num_buffer = num_buffer;
    audio->buffer_size = buffer_size;

    return SP_TRUE;
}

static void freeWaveHdr(spWinAudio audio)
{
    long i;

    if (audio->header_allocated == SP_TRUE) {
	for (i = 0; i < audio->num_buffer; i++) {
	    if (audio->lpwavehdr[i] != NULL) {
		GlobalUnlock(audio->hwavehdr[i]);
		audio->lpwavehdr[i] = NULL;
	    }
	    if (audio->hwavehdr[i] != NULL) {
		GlobalFree(audio->hwavehdr[i]);
		audio->hwavehdr[i] = NULL;
	    }
	}
    }
    
    audio->header_allocated = SP_FALSE;
    
    return;
}

static spBool allocWaveHdr(spWinAudio audio)
{
    long i;
    
    if (audio->header_allocated == SP_TRUE) {
	return SP_TRUE;
    }
	
    for (i = 0; i < audio->num_buffer; i++) {
	if ((audio->hwavehdr[i] = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE | GMEM_ZEROINIT,
					      sizeof(WAVEHDR))) == NULL) {
	    spMessage("can't allocate header memory\n");
	    freeWaveHdr(audio);
	    freeWaveBuffer(audio);
	    return SP_FALSE;
	}
	
	if ((audio->lpwavehdr[i] = GlobalLock(audio->hwavehdr[i])) == NULL) {
	    spMessage("can't lock header memory\n");
	    freeWaveHdr(audio);
	    freeWaveBuffer(audio);
	    return SP_FALSE;
	}
    }

    audio->header_allocated = SP_TRUE;
    
    return SP_TRUE;
}

static void CALLBACK waveInProc(HWAVEIN hwavein, UINT uMsg, DWORD dwInstance,  
				 DWORD dwParam1, DWORD dwParam2)
{
    spWinAudio audio = (spWinAudio)dwInstance;

    if (audio == NULL) return;
    
    switch (uMsg) {
      case WIM_DATA:
	ReleaseSemaphore(audio->hsemaphore, 1, NULL);
	break;
      default:
	break;
    }

    return;
}
 
static void CALLBACK waveOutProc(HWAVEOUT hwaveout, UINT uMsg, DWORD dwInstance,  
				 DWORD dwParam1, DWORD dwParam2)
{
    spWinAudio audio = (spWinAudio)dwInstance;
    
    if (audio == NULL) return;
    
    switch (uMsg) {
      case WOM_DONE:
	ReleaseSemaphore(audio->hsemaphore, 1, NULL);
	break;
      default:
	break;
    }

    return;
}

static spBool openDevice(spWinAudio audio, int samp_bit, int num_channel,
			 double samp_rate, spBool nonblock_flag, spBool output_flag)
{
    int err;
    WAVEFORMATEX waveFormatEx;
    
    waveFormatEx.wFormatTag = WAVE_FORMAT_PCM;
    waveFormatEx.nChannels = num_channel;
    waveFormatEx.nSamplesPerSec = (long)spRound(samp_rate);
    waveFormatEx.wBitsPerSample = samp_bit;
    waveFormatEx.nBlockAlign = waveFormatEx.nChannels * waveFormatEx.wBitsPerSample / 8;
    waveFormatEx.nAvgBytesPerSec =
	waveFormatEx.nSamplesPerSec * waveFormatEx.nBlockAlign;
    waveFormatEx.cbSize = 0;

    if (output_flag == SP_TRUE) {
	/* open a waveform output device */ 
	if ((err = waveOutOpen(&audio->hwaveout, 		/*LPHWAVEOUT phwo*/
			       WAVE_MAPPER, 			/*UINT uDeviceID*/
			       (LPWAVEFORMATEX)&waveFormatEx, 	/*LPWAVEFORMATEX pwfx*/
			       (DWORD)waveOutProc, 		/*DWORD dwCallback*/
			       (DWORD)audio, 			/*DWORD dwCallbackInstance*/
			       CALLBACK_FUNCTION | WAVE_ALLOWSYNC 	/*DWORD fdwOpen*/
			       )) != MMSYSERR_NOERROR) {
	    spMessage("open error: %d\n", err);
	    return SP_FALSE;
	}
	audio->hwavein = NULL;
    } else {
	/* open a waveform input device */ 
	if ((err = waveInOpen(&audio->hwavein, 			/*LPHWAVEIN phwi*/
			      WAVE_MAPPER, 			/*UINT uDeviceID*/
			      (LPWAVEFORMATEX)&waveFormatEx, 	/*LPWAVEFORMATEX pwfx*/
			      (DWORD)waveInProc, 		/*DWORD dwCallback*/
			      (DWORD)audio, 			/*DWORD dwCallbackInstance*/
			      CALLBACK_FUNCTION			/*DWORD fdwOpen*/
			      )) != MMSYSERR_NOERROR) {
	    spMessage("open error: %d\n", err);
	    return SP_FALSE;
	}
	audio->hwaveout = NULL;
    }

    audio->nonblock_flag = nonblock_flag;
    audio->num_channel = waveFormatEx.nChannels;

    return SP_TRUE;
}

static spBool waitBuffer(spWinAudio audio, long index)
{
    if (index >= 0) {
	WaitForSingleObject(audio->hsemaphore, INFINITE);
	ReleaseSemaphore(audio->hsemaphore, 1, NULL);
    }
    return SP_TRUE;
}

static spBool waitFinish(spWinAudio audio)
{
    long i;

    WaitForSingleObject(audio->hmutex, INFINITE);
    audio->wait_flag = SP_TRUE;
    ReleaseMutex(audio->hmutex);
    
    for (i = 0; i < audio->num_buffer; i++) {
	if (audio->wait_flag == SP_FALSE) {
	    break;
	}
	WaitForSingleObject(audio->hsemaphore, INFINITE);
    }
    
    WaitForSingleObject(audio->hmutex, INFINITE);
    ReleaseSemaphore(audio->hsemaphore, audio->num_buffer, NULL);
    audio->wait_flag = SP_FALSE;
    ReleaseMutex(audio->hmutex);
    
    return SP_TRUE;
}

static spBool readWaveFrame(spWinAudio audio, long index)
{
    int err;
    
    WaitForSingleObject(audio->hsemaphore, INFINITE);
	    
    if ((err = waveInAddBuffer(audio->hwavein, audio->lpwavehdr[index],
			       sizeof(WAVEHDR))) != MMSYSERR_NOERROR) {
	spMessage("read error: %d\n", err);
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static spBool writeWaveFrame(spWinAudio audio, long index)
{
    int err;
    
    WaitForSingleObject(audio->hsemaphore, INFINITE);
    
    if ((err = waveOutWrite(audio->hwaveout, audio->lpwavehdr[index],
			    sizeof(WAVEHDR))) != MMSYSERR_NOERROR) {
	spMessage("write error: %d\n", err);
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static spBool prepareWaveHdr(spWinAudio audio)
{
    long i;

    for (i = 0; i < audio->num_buffer; i++) {
	audio->lpwavehdr[i]->lpData = audio->lpbuffer[i];
	audio->lpwavehdr[i]->dwBufferLength = audio->buffer_size;
	audio->lpwavehdr[i]->dwFlags = 0;
	audio->lpwavehdr[i]->dwLoops = 0;

	if (audio->hwavein != NULL) {
	    if (waveInPrepareHeader(audio->hwavein, audio->lpwavehdr[i], sizeof(WAVEHDR))
		!= MMSYSERR_NOERROR) {
		spMessage("buffer preparation error.\n");
		return SP_FALSE;
	    }
	} else {
	    if (waveOutPrepareHeader(audio->hwaveout, audio->lpwavehdr[i], sizeof(WAVEHDR))
		!= MMSYSERR_NOERROR) {
		spMessage("buffer preparation error.\n");
		return SP_FALSE;
	    }
	}
	
	if (!(audio->lpwavehdr[i]->dwFlags & WHDR_PREPARED)) {
	    spMessage("buffer preparation error.\n");
	    return SP_FALSE;
	}
    }
    spResetDevice_Win(audio);

    if (audio->hwavein != NULL) {
	for (i = 0; i < audio->num_buffer; i++) {
	    if (readWaveFrame(audio, i) == SP_FALSE) {
		return SP_FALSE;
	    }
	    audio->buffer_index = i;
	}
    } else {
	for (i = 0; i < audio->num_prepare_buffer; i++) {
	    if (writeWaveFrame(audio, i) == SP_FALSE) {
		return SP_FALSE;
	    }
	    audio->buffer_index = i + 1;
	}
    }
    
    return SP_TRUE;
}

static spBool unprepareWaveHdr(spWinAudio audio)
{
    long i;

    if (audio->hwavein != NULL) {
	waveInReset(audio->hwavein);
	
	for (i = 0; i < audio->num_buffer; i++) {
	    if (waveInUnprepareHeader(audio->hwavein, audio->lpwavehdr[i], sizeof(WAVEHDR))
		!= MMSYSERR_NOERROR) {
		spMessage("buffer unpreparation error.\n");
		return SP_FALSE;
	    }
	}
    } else {
	waitFinish(audio);
	waveOutReset(audio->hwaveout);
	
	for (i = 0; i < audio->num_buffer; i++) {
	    if (waveOutUnprepareHeader(audio->hwaveout, audio->lpwavehdr[i], sizeof(WAVEHDR))
		!= MMSYSERR_NOERROR) {
		spMessage("buffer unpreparation error.\n");
		return SP_FALSE;
	    }
	}
    }
	
    audio->prev_index = -1;
    
    return SP_TRUE;
}

static spBool closeDevice(spWinAudio audio)
{
    if (audio->hwavein != NULL) {
	waveInClose(audio->hwavein);
    } else {
	waveOutClose(audio->hwaveout);
    }
    audio->start_flag = SP_FALSE;

    return SP_TRUE;
}

/**/
#define NUM_WAVE_PREPARE_BUFFER 8

spWinAudio spInitAudio_Win(long num_buffer, long buffer_size)
{
    spWinAudio audio;

    audio = xalloc(1, struct _spWinAudio);
    memset(audio, 0, sizeof(struct _spWinAudio));
    audio->num_prepare_buffer = MIN(NUM_WAVE_PREPARE_BUFFER, num_buffer/2);
    audio->num_channel = 1;
    audio->prev_index = -1;

    if (allocWaveBuffer(audio, MIN(num_buffer, MAX_NUM_WAVE_BUFFER), buffer_size) == SP_FALSE) {
	xfree(audio);
	return NULL;
    }
    if (allocWaveHdr(audio) == SP_FALSE) {
	xfree(audio);
	return NULL;
    }

    return audio;
}

spBool spFreeAudio_Win(spWinAudio audio)
{
    if (audio == NULL) return SP_FALSE;

    freeWaveHdr(audio);
    freeWaveBuffer(audio);

    return SP_TRUE;
}

spBool spOpenAudioDevice_Win(spWinAudio audio, int samp_bit, int num_channel,
			     double samp_rate, spBool nonblock_flag, spBool output_flag)
{
    if (audio == NULL) return SP_FALSE;
    
    if (openDevice(audio, samp_bit, num_channel, samp_rate, nonblock_flag, output_flag) == SP_FALSE) {
	return SP_FALSE;
    }
    if (prepareWaveHdr(audio) == SP_FALSE) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spCloseAudioDevice_Win(spWinAudio audio)
{
    if (audio == NULL) return SP_FALSE;
    
    unprepareWaveHdr(audio);
    closeDevice(audio);
    
    return SP_TRUE;
}

long spReadWave_Win(spWinAudio audio, char *data, long length)
{
    long index;
    long count;
    long ncopy;
    long nremain;
    long sample_byte;
    short *sdata;
    static unsigned long prev_sample = 0;

    if (audio->hwavein == NULL) return -1;

    sample_byte = sizeof(short);
    
    if (audio->start_flag == SP_FALSE) {
	waveInStart(audio->hwavein);
	audio->start_flag = SP_TRUE;
	prev_sample = 0;
    }

    if (audio->nonblock_flag == SP_TRUE) {
	MMTIME mmtime;
	unsigned long current_sample;
	unsigned long current_length;
	
	mmtime.wType = TIME_SAMPLES;
	waveInGetPosition(audio->hwavein, &mmtime, sizeof(mmtime));

	current_sample = mmtime.u.sample * audio->num_channel;
	current_length = current_sample - prev_sample;

	if (current_length <= 0) {
	    current_length = audio->buffer_size / sample_byte;
	}
	length = MIN(length, current_length);
	spDebug(1, NULL, "position = %ld, length = %ld\n",
		current_sample, length);
	
	prev_sample += length;
    }

    count = 0;
    nremain = length * sample_byte;
    sdata = (short *)data;
    
    if (audio->prev_index >= 0 && audio->buffer_pos > 0) {
	ncopy = audio->buffer_size - audio->buffer_pos;
	if (nremain <= ncopy) {
	    memmove(sdata, audio->lpbuffer[audio->prev_index] + audio->buffer_pos, nremain);
	    count = nremain;
	    audio->buffer_pos += nremain;
	    nremain = 0;
	} else {
	    if (ncopy > 0) {
		memmove(sdata, audio->lpbuffer[audio->prev_index] + audio->buffer_pos, ncopy);
		count = ncopy;
		nremain -= count;
	    } else {
		count = 0;
	    }
	    audio->buffer_pos = 0;
	    
	    audio->buffer_index++;
	    if (audio->buffer_index >= audio->num_buffer) audio->buffer_index = 0;

	    if (readWaveFrame(audio, audio->buffer_index) == SP_FALSE) {
		return SP_FALSE;
	    }
	}
    }

    if (nremain > 0) {
	while (1) {
	    index = audio->buffer_index - audio->num_buffer + 1;
	    if (index < 0) index += audio->num_buffer;

	    waitBuffer(audio, index);
	
	    audio->prev_index = index;
	
	    if (nremain <= audio->buffer_size) {
		if (nremain > 0) {
		    memmove(sdata + (count / sample_byte), audio->lpbuffer[index], nremain);
		    count += nremain;
		}
		audio->buffer_pos = nremain;
		nremain = 0;
		break;
	    } else {
		memmove(sdata + (count / sample_byte), audio->lpbuffer[index], audio->buffer_size);
		count += audio->buffer_size;
		nremain -= audio->buffer_size;
		audio->buffer_pos = 0;
	    }
	    
	    audio->buffer_index++;
	    if (audio->buffer_index >= audio->num_buffer) audio->buffer_index = 0;

	    if (readWaveFrame(audio, audio->buffer_index) == SP_FALSE) {
		return SP_FALSE;
	    }
	}
    }
    
    return count / sample_byte;
}

long spWriteWave_Win(spWinAudio audio, char *data, long length)
{
    long index;
    long count;
    long nremain;
    long ncopy;
    long sample_byte;
    short *sdata;

    if (audio->hwaveout == NULL) return -1;

    sample_byte = sizeof(short);
    
    if (audio->start_flag == SP_FALSE) {
	audio->start_flag = SP_TRUE;
    }

    count = 0;
    nremain = length * sample_byte;
    sdata = (short *)data;

    while (1) {
	ncopy = MIN(nremain, audio->buffer_size);
	memmove(audio->lpbuffer[audio->buffer_index],
		(char *)(sdata + (count / sample_byte)), ncopy);
	audio->lpwavehdr[audio->buffer_index]->dwBufferLength = ncopy;
	count += ncopy;
	nremain -= ncopy;
	
	if (writeWaveFrame(audio, audio->buffer_index) == SP_FALSE) {
	    return SP_FALSE;
	}

	index = audio->buffer_index - audio->num_buffer + 1;
	
	if (index >= 0) audio->wait_flag = SP_TRUE;
	
	if (audio->wait_flag == SP_TRUE) { /* after buffers are filled */
	    if (index < 0) index += audio->num_buffer;
	    
	    waitBuffer(audio, index);
	}
	
	audio->prev_index = audio->buffer_index;
	
	audio->buffer_index++;
	if (audio->buffer_index >= audio->num_buffer) audio->buffer_index = 0;
	
	if (nremain <= 0) {
	    break;
	}
    }

    return count / sample_byte;
}

spBool spGetAudioOutputPosition_Win(spWinAudio audio, long *position)
{
    MMTIME mmtime;

    if (audio == NULL) return SP_FALSE;

    if (position != NULL) {
	mmtime.wType = TIME_SAMPLES;
	waveOutGetPosition(audio->hwaveout, &mmtime, sizeof(mmtime));
    
	*position = mmtime.u.sample;
    }
    
    return SP_TRUE;
}

spBool spResetDevice_Win(spWinAudio audio)
{
    if (audio == NULL) return SP_FALSE;
    
    if (audio->hwavein != NULL) {
	waveInReset(audio->hwavein);
    } else if (audio->hwaveout != NULL) {
	waveOutReset(audio->hwaveout);
    } else {
	return SP_FALSE;
    }
    
    WaitForSingleObject(audio->hmutex, INFINITE);
    audio->start_flag = SP_FALSE;
    audio->wait_flag = SP_FALSE;
    audio->prev_index = -1;
    audio->buffer_pos = 0;
    ReleaseSemaphore(audio->hsemaphore, audio->num_buffer, NULL);
    ReleaseMutex(audio->hmutex);
    
    return SP_TRUE;
}

spBool spSyncDevice_Win(spWinAudio audio)
{
    long i;

    if (audio == NULL) return SP_FALSE;
    
    if (audio->hwavein != NULL) {
	spResetDevice_Win(audio);
	
	for (i = 0; i < audio->num_buffer; i++) {
	    if (readWaveFrame(audio, i) == SP_FALSE) {
		return SP_FALSE;
	    }
	    audio->buffer_index = i;
	}
    } else {
	waitFinish(audio);
	spResetDevice_Win(audio);
	
	if (audio->num_prepare_buffer > 0) {
	    for (i = 0; i < audio->num_prepare_buffer; i++) {
		if (writeWaveFrame(audio, i) == SP_FALSE) {
		    return SP_FALSE;
		}
		
		audio->buffer_index = i + 1;
	    }
	}
    }
    
    return SP_TRUE;
}

#endif

