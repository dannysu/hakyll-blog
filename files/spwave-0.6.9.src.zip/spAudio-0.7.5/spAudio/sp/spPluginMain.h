/*
 *	spPluginMain.h
 */

#ifndef __SPMAIN_H
#define __SPMAIN_H

#ifdef _WIN32
#include <windows.h>
#endif

#include <sp/spPluginP.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#if defined(__CYGWIN32__)

#ifdef USE_CYGWIN32_DLL
#include <cygwin32/cygwin_dll.h>
#else
#include <cygwin/cygwin_dll.h>
#endif

#if CYGWIN_VERSION_DLLO_MAJOR <= 1001
BOOL WINAPI DllEntry(HANDLE hModule, DWORD reason, LPVOID lpReserved)
{
    return TRUE;
}
#else
int WINAPI DllEntry(HINSTANCE hModule, DWORD reason, LPVOID lpReserved)
{
    return TRUE;
}
#endif

DECLARE_CYGWIN_DLL(DllEntry)
#else
BOOL WINAPI DllMain(HANDLE hModule, DWORD reason, LPVOID lpReserved)
{
    return TRUE;
}
#endif /* defined(__CYGWIN32__) */
#endif /* defined(_WIN32) */

#if defined(MACOS)
#pragma export on
long spPluginSystemVersion(void);
long spPluginSupportedVersion(void);
spPluginRec *spGetPluginRec(void);
#pragma export off
#endif

spPluginExport long spPluginSystemVersion(void)
{
    return SP_PLUGIN_VERSION_ID;
}

spPluginExport long spPluginSupportedVersion(void)
{
    return SP_PLUGIN_SUPPORTED_VERSION_ID;
}

spPluginExport spPluginRec *spGetPluginRec(void);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMAIN_H */
