/*
 *	spInputPlugin.h
 */

#ifndef __SPINPUTPLUGIN_H
#define __SPINPUTPLUGIN_H

#include <sp/spOutputPlugin.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_PLUGIN_INPUT "input 1.3"

typedef struct _spInputPluginRec spInputPluginRec;

#if defined(MACOS)
#pragma import on
#endif

extern spBool spIsInputPlugin(spPlugin *plugin);
extern long _spReadPlugin(spPlugin *plugin, char *data, long length);
extern long _spReadPluginShift(spPlugin *plugin, long prev_length, long shift_length, char *data, long length);
extern long spReadPluginShiftDouble(spPlugin *plugin, long prev_length, long shift_length, double *data, long length);
extern spBool spSeekPlugin(spPlugin *plugin, long pos);
extern long spGetPluginTotalLength(spPlugin *plugin);

#if defined(MACOS)
#pragma import off
#endif

#define spReadPlugin(plugin, data, length) \
_spReadPlugin(plugin, (char *)(data), length)
#define spReadPluginShift(plugin, prev_length, shift_length, data, length) \
_spReadPluginShift(plugin, prev_length, shift_length, (char *)(data), length)

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPINPUTPLUGIN_H */
