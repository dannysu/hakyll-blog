/*
 *	spAudioLib.h
 */

#ifndef __SPAUDIOLIB_H
#define __SPAUDIOLIB_H

#include <sp/spWave.h>
#include <sp/spAudio.h>
#include <sp/spPlugin.h>
#include <sp/spOutputPlugin.h>
#include <sp/spInputPlugin.h>

#endif /* __SPAUDIOLIB_H */
