/*
 *	spWave_Wav.h
 */

#ifndef __SPWAVE_WAV_H
#define __SPWAVE_WAV_H

#ifdef _WIN32
#include <windows.h>
#if !defined(__CYGWIN32__)
#include <mmreg.h>
#endif
#endif

#include <sp/spWave.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef WAVE_FORMAT_PCM
#define	WAVE_FORMAT_PCM			(0x0001)
#endif
    
#ifndef WAVE_FORMAT_UNKNOWN
#define	WAVE_FORMAT_UNKNOWN		(0x0000)
#define	WAVE_FORMAT_ADPCM		(0x0002)
#define	WAVE_FORMAT_ALAW		(0x0006)
#define	WAVE_FORMAT_MULAW		(0x0007)
#define	WAVE_FORMAT_OKI_ADPCM		(0x0010)
#define	WAVE_FORMAT_DIGISTD		(0x0015)
#define	WAVE_FORMAT_DIGIFIX		(0x0016)
#endif /* !WAVE_FORMAT_UNKNOWN */

#ifndef _WIN32
typedef unsigned long DWORD;
typedef unsigned short WORD;
#endif

/*
 * Following parameters must be specified.
 *	wFormatTag
 * 	nChannels
 * 	nSamplesPerSec
 * 	wBitsPerSample
 */
typedef  struct {
    char RiffID[4];		/* 'R', 'I', 'F', 'F' */
    DWORD RiffSize;		/* (file size - 8) [bytes] */
    char WaveID[4];		/* 'W', 'A', 'V', 'E' */
    char FmtID[4];		/* 'f', 'm', 't', ' ' */
    DWORD FmtSize;		/* format chunk size [bytes] */
    WORD wFormatTag;		/* 1: WAVE_FORMAT_PCM, 0x0000: WAVE_FORMAT_UNKNOWN ... */
    WORD nChannels;		/* number of channels */
    DWORD nSamplesPerSec;	/* sampling frequency [Hz] */
    DWORD nAvgBytesPerSec;	/* nSamplesPerSec * nBlockAlign */
    WORD nBlockAlign;		/* (nChannels * wBitsPerSample) / 8 [bytes] */
    WORD wBitsPerSample;	/* 16 or 8 [bits] */
    char DataID[4];		/* 'd' 'a' 't' 'a' */
    DWORD nDataBytes;		/* data chunk size [bytes] */
} WAVEHEADER;

#define WAVE_FORMAT_UNKNOWN_STRING "Microsoft Official Unknown"
#define WAVE_FORMAT_PCM_STRING "Microsoft PCM"
#define WAVE_FORMAT_ADPCM_STRING "Microsoft ADPCM"
#define WAVE_FORMAT_ALAW_STRING "Microsoft A-law"
#define WAVE_FORMAT_MULAW_STRING "Microsoft U-law"
#define WAVE_FORMAT_OKI_ADPCM_STRING "OKI ADPCM format."
#define WAVE_FORMAT_DIGISTD_STRING "Digistd format."
#define WAVE_FORMAT_DIGIFIX_STRING "Digifix format."

#if defined(MACOS)
#pragma import on
#endif

extern char *spGetWavFormatLabelFromTag(unsigned short wFormatTag);
extern char *spGetWavFormatLabel(WAVEHEADER wave_header);
extern long spReadWavHeader(WAVEHEADER *wave_header, FILE *fp);
extern long spWriteWavHeader(WAVEHEADER wave_header, long length, FILE *fp);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPWAVE_WAV_H */
