/*
 *	spAudioP.h
 */

#ifndef __SPAUDIOP_H
#define __SPAUDIOP_H

#include <sp/spAudio.h>

#if defined(linux) && !defined(OSS)
#define OSS
#endif

#if defined(SGI)
#include <dmedia/audio.h>
#elif defined(MACOSX)
#include <Carbon/Carbon.h>
#elif defined(MACOS)
#include <Sound.h>
#elif defined(_WIN32)
#include <windows.h>
#elif defined(sun)
#include <sys/stropts.h>
#include <sys/filio.h>
#ifndef SOLARIS
#include <multimedia/libaudio.h>
#include <multimedia/audio_device.h>
#else
#include <sys/audioio.h>
#endif
#endif

#if defined(MACOS)

#if defined(MACOSX)
#define SP_MAC_SUPPORT_AUDIO_INPUT
#else
#define SP_MAC_SUPPORT_AUDIO_INPUT
#endif

#if defined(SP_MAC_USE_DOUBLE_BUFFER) && TARGET_API_MAC_CARBON
#include "CarbonSndPlayDB.h"
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_DEFAULT_AUDIO_BUFFER_SIZE 8192
#if defined(MACOSX)
#define SP_DEFAULT_NUM_BUFFER 8
#elif defined(MACOS)
#define SP_DEFAULT_NUM_BUFFER 64
#else
#define SP_DEFAULT_NUM_BUFFER 64
#endif

#if defined(_WIN32)    
typedef struct _spWinAudio *spWinAudio;
#endif

struct _spAudio {
    int samp_bit;
    double samp_rate;
    int num_channel;
    int buffer_size;
    long samp_byte;
    int duplex_flag;
    int only_flag;
    int block_mode;
    int specified_samp_bit;
    long input_total;
    long output_total;
    int num_buffer;
#if defined(SP_SUPPORT_AUDIO)
#if defined(OSS)
    int fragment_size;
    int prev_fd;
    int input_fd;
    int output_fd;
    int fd0;
    int samp_bit0;
    int samp_rate0;
    int num_channel0;
    int block_size0;
    int fd1;
    int samp_bit1;
    int samp_rate1;
    int num_channel1;
    int block_size1;
#elif defined(SGI)
    ALconfig audio_config;
    ALport input_port;
    ALport output_port;
#elif defined(_WIN32)
    spWinAudio input_audio;
    spWinAudio output_audio;
#elif defined(sun)
    int input_fd;
    int output_fd;
    audio_info_t audio_info;
#elif defined(MACOS)
    int support_input;
    int support_output;
    int support_16bit;
    int stereo_input;
    int stereo_output;

    SndChannelPtr sndChannel;
    ExtSoundHeaderPtr sndHeader;
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    SndDoubleBufferHeaderPtr sndDoubleHeader;
    SndDoubleBackUPP sndDoubleBackUPP;
#else
    SndCallBackUPP sndCallBackUPP;
#endif

    long playDataSize;
    Ptr playDataBuffer;
    
    int playState;
    long playOffset;
    long playDataOffset;
    long playDataFilled;
    
#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
    SPBPtr pspb;
    SICompletionUPP siCompletionUPP;
    long refNum;
    long recBufferSize;
    
    long recDataSize;
    Ptr recDataBuffer;

    spBool recStarted;
    long recOffset;
    long recDataOffset;
    long recDataFilled;

    SoundConverter recsc;
    unsigned long recConvInputFrames;
    unsigned long recConvBufferSize;
    Ptr recConvBuffer;
    Ptr recConvOutputBuffer;
#endif
#endif
#endif

#ifdef SP_SUPPORT_THREAD_AUDIO
    void *write_thread;
    spAudioCallback write_func;
    void *write_data;
#endif
};

#if defined(MACOS)
#pragma import on
#endif

extern spBool spInitAudioArch(spAudio audio);
extern spBool spSetAudioSampleRateArch(spAudio audio);
extern spBool spSetAudioChannelArch(spAudio audio);
extern spBool spSetAudioBufferSizeArch(spAudio audio);
extern spBool spSetAudioNumBufferArch(spAudio audio);
extern spBool spSetAudioBlockingModeArch(spAudio audio);
extern spBool spOpenInputAudioDeviceArch(spAudio audio);
extern spBool spOpenOutputAudioDeviceArch(spAudio audio);
extern spBool spCloseAudioDeviceArch(spAudio audio);
extern long spReadAudioArch(spAudio audio, char *data, long length);
extern long spWriteAudioArch(spAudio audio, char *data, long length);
extern spBool spGetAudioOutputPositionArch(spAudio audio, long *position);
extern spBool spStopAudioArch(spAudio audio);
extern spBool spSyncAudioArch(spAudio audio);
extern spBool spFreeAudioArch(spAudio audio);
extern void spTerminateAudioArch(void);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPAUDIOP_H */
