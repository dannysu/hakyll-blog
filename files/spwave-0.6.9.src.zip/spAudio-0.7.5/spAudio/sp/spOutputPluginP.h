/*
 *	spOutputPluginP.h
 */

#ifndef __SPOUTPUTPLUGINP_H
#define __SPOUTPUTPLUGINP_H

#include <sp/spPluginP.h>
#include <sp/spOutputPlugin.h>

#ifdef __cplusplus
extern "C" {
#endif

struct _spIoPluginRec
{
    void *host_data;
    void *user_data;
    
    spPluginType type;
    char *plugin_id;
    long version_id;
    int priority;
    unsigned long caps;
    spBool (*init)(char *lang);
    spBool (*free)(void);
    char *description;
    char *information;
    
    void *(*init_instance)(char *lang);
    spBool (*free_instance)(void *instance);
    spOptions (*init_options)(void *instance, char *lang);
    spBool (*free_options)(void *instance, spOptions options);
    
    spPluginDeviceType device_type;
    
    /* get_xxx should work after `open' call for input plugins */
    
    /* for file */
    char **file_type_list;
    char **file_desc_list;
    char **file_filter_list;
    spBool (*is_supported)(char *filename);
    spBool (*set_file_type)(void *instance, int index);
    int (*get_file_type)(void *instance);
    unsigned long song_info_mask;
    spBool (*set_song_info)(void *instance, spSongInfo *song_info);
    spBool (*get_song_info)(void *instance, spSongInfo *song_info);
    char *(*get_best_suffix)(void *instance);
    
    /* for device */
    spBool (*get_num_device)(void *instance, int *num_device);
    char *(*get_device_name)(void *instance, int index);
    spBool (*select_device)(void *instance, int index);
    spBool (*set_buffer_size)(void *instance, int buffer_size);
    spBool (*get_buffer_size)(void *instance, int *buffer_size);
    spBool (*set_volume)(void *instance, int channel, int volume);
    spBool (*get_volume)(void *instance, int channel, int *volume);
    
    /* for file and device */
    spBool (*set_sample_bit)(void *instance, int samp_bit);
    spBool (*get_sample_bit)(void *instance, int *samp_bit);
    spBool (*set_channel)(void *instance, int num_channel);
    spBool (*get_channel)(void *instance, int *num_channel);
    spBool (*set_sample_rate)(void *instance, double samp_rate);
    spBool (*get_sample_rate)(void *instance, double *samp_rate);
    spBool (*set_other_info)(void *instance, char *id, char *data);
    spBool (*get_other_info)(void *instance, char *id, char *data);

    spPluginError (*open)(void *instance, char *filename, char *mode);
    spBool (*close)(void *instance);
    spPluginState (*get_state)(void *instance);
    long (*get_current_pos)(void *instance);
    spBool (*stop)(void *instance);
    spBool (*pause)(void *instance);
    spBool (*restart)(void *instance);
};

struct _spOutputPluginRec
{
    void *host_data;
    void *user_data;
    
    spPluginType type;
    char *plugin_id;
    long version_id;
    int priority;
    unsigned long caps;
    spBool (*init)(char *lang);
    spBool (*free)(void);
    char *description;
    char *information;
    
    void *(*init_instance)(char *lang);
    spBool (*free_instance)(void *instance);
    spOptions (*init_options)(void *instance, char *lang);
    spBool (*free_options)(void *instance, spOptions options);
    
    spPluginDeviceType device_type;
    
    char **file_type_list;
    char **file_desc_list;
    char **file_filter_list;
    spBool (*is_supported)(char *filename);
    spBool (*set_file_type)(void *instance, int index);
    int (*get_file_type)(void *instance);
    unsigned long song_info_mask;
    spBool (*set_song_info)(void *instance, spSongInfo *song_info);
    spBool (*get_song_info)(void *instance, spSongInfo *song_info);
    char *(*get_best_suffix)(void *instance);
    
    spBool (*get_num_device)(void *instance, int *num_device);
    char *(*get_device_name)(void *instance, int index);
    spBool (*select_device)(void *instance, int index);
    spBool (*set_buffer_size)(void *instance, int buffer_size);
    spBool (*get_buffer_size)(void *instance, int *buffer_size);
    spBool (*set_volume)(void *instance, int channel, int volume);
    spBool (*get_volume)(void *instance, int channel, int *volume);
    
    spBool (*set_sample_bit)(void *instance, int samp_bit);
    spBool (*get_sample_bit)(void *instance, int *samp_bit);
    spBool (*set_channel)(void *instance, int num_channel);
    spBool (*get_channel)(void *instance, int *num_channel);
    spBool (*set_sample_rate)(void *instance, double samp_rate);
    spBool (*get_sample_rate)(void *instance, double *samp_rate);
    spBool (*set_other_info)(void *instance, char *id, char *data);
    spBool (*get_other_info)(void *instance, char *id, char *data);

    spPluginError (*open)(void *instance, char *filename, char *mode);
    spBool (*close)(void *instance);
    spPluginState (*get_state)(void *instance);
    long (*get_current_pos)(void *instance);
    spBool (*stop)(void *instance);
    spBool (*pause)(void *instance);
    spBool (*restart)(void *instance);

    long (*write)(void *instance, char *data, long length);
    spBool (*flush)(void *instance);
    spBool (*set_total_length)(void *instance, long total_length);
};

#if defined(MACOS)
#pragma import on
#endif

extern int spFindPluginRecFileTypeIndex(spIoPluginRec *rec, char *type);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPOUTPUTPLUGINP_H */
