/*
 *	spWave_Aiff.h
 */

#ifndef __SPWAVE_AIFF_H
#define __SPWAVE_AIFF_H

#include <sp/spWave.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPWAVE_AIFF_H */
