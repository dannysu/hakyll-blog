/*
 *	spOutputPlugin.h
 */

#ifndef __SPOUTPUTPLUGIN_H
#define __SPOUTPUTPLUGIN_H

#include <sp/spWave.h>
#include <sp/spPlugin.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  - Internal bits/sample must be greater than 16.
 *  - If bits/sample = 8 or 16, internal data must be short format.
 *  - If bits/sample = 33, it means float data.
 *  - If bits/sample >= 33, internal data must be double format.
 *  - If bits/sample = 24 or 32, internal data must be long format.
 */
    
#define SP_PLUGIN_OUTPUT "output 1.3"

/* other information ID */
#define SP_PLUGIN_INFO_SONG_INFO_MASK "song_info_mask"
#define SP_PLUGIN_INFO_BIT_RATE "bit_rate"
#define SP_PLUGIN_INFO_HEADER_LENGTH "header_length"
#define SP_PLUGIN_INFO_MPEG_DECODE_OPTION "mpeg_decode_option"
/* for backwards compatibility */
#define SP_BIT_RATE_ID SP_PLUGIN_INFO_BIT_RATE
#define SP_HEADER_LENGTH_ID SP_PLUGIN_INFO_HEADER_LENGTH
#define SP_MPEG_DECODE_OPTION_ID SP_PLUGIN_INFO_MPEG_DECODE_OPTION

typedef struct _spIoPluginRec spIoPluginRec;
typedef struct _spOutputPluginRec spOutputPluginRec;

#if defined(MACOS)
#pragma import on
#endif

extern spBool spIsIoPlugin(spPlugin *plugin);
extern spBool spIsOutputPlugin(spPlugin *plugin);
extern spPluginDeviceType spGetPluginDeviceType(spPlugin *plugin);

extern int spFindPluginFileTypeIndex(spPlugin *plugin, char *type);
extern spBool spSetPluginFileTypeIndex(spPlugin *plugin, int index);
extern int spGetPluginFileTypeIndex(spPlugin *plugin);
extern char *spGetPluginFileTypeString(spPlugin *plugin, int index);
extern char *spGetPluginFileDescString(spPlugin *plugin, int index);
extern char *spGetPluginFileFilterString(spPlugin *plugin, int index);
extern spBool spSetPluginFileType(spPlugin *plugin, char *type);
extern char *spGetPluginFileType(spPlugin *plugin, spBool long_flag);
extern char *spGetPluginFileDescription(spPlugin *plugin, spBool filter_flag);
extern char *spGetPluginFileFilter(spPlugin *plugin);
extern spBool spSearchPluginFileType(int index, spPluginType plugin_type,
				     spPluginDeviceType device_type, char *plugin_name,
				     char *file_type, char *file_desc, char *file_filter);
extern spBool spSetPluginSongInfo(spPlugin *plugin, spSongInfo *song_info);
extern spBool spGetPluginSongInfo(spPlugin *plugin, spSongInfo *song_info);
extern spBool spGetPluginSongInfoMask(spPlugin *plugin, unsigned long *info_mask);
extern char *spGetPluginBestSuffix(spPlugin *plugin);
extern spBool spIsSupportedByPlugin(spPlugin *plugin, char *filename);

extern spBool spGetPluginNumDevice(spPlugin *plugin, int *num_device);
extern char *spGetPluginDeviceName(spPlugin *plugin, int index);
extern spBool spSelectPluginDevice(spPlugin *plugin, int index);
extern spBool spSetPluginBufferSize(spPlugin *plugin, int buffer_size);
extern spBool spGetPluginBufferSize(spPlugin *plugin, int *buffer_size);
extern spBool spSetPluginVolume(spPlugin *plugin, int channel, int volume);
extern spBool spGetPluginVolume(spPlugin *plugin, int channel, int *volume);
extern spBool spSetPluginVolumeStereo(spPlugin *plugin, int l_volume, int r_volume);
extern spBool spGetPluginVolumeStereo(spPlugin *plugin, int *l_volume, int *r_volume);

extern spBool spSetPluginSampleBit(spPlugin *plugin, int samp_bit);
extern spBool spGetPluginSampleBit(spPlugin *plugin, int *samp_bit);
extern spBool spGetPluginDataSampleBit(spPlugin *plugin, int *samp_bit);
extern spBool spSetPluginChannel(spPlugin *plugin, int num_channel);
extern spBool spGetPluginChannel(spPlugin *plugin, int *num_channel);
extern spBool spSetPluginSampleRate(spPlugin *plugin, double samp_rate);
extern spBool spGetPluginSampleRate(spPlugin *plugin, double *samp_rate);
extern spBool spSetPluginOtherInfo(spPlugin *plugin, char *id, char *data);
extern spBool spGetPluginOtherInfo(spPlugin *plugin, char *id, char *data);

extern spPluginError spOpenPlugin(spPlugin *plugin, char *filename, char *mode);
extern spBool spClosePlugin(spPlugin *plugin);
extern spPluginState spGetPluginState(spPlugin *plugin);
extern long spGetPluginCurrentPosition(spPlugin *plugin);
extern spBool spStopPlugin(spPlugin *plugin);
extern spBool spPausePlugin(spPlugin *plugin);
extern spBool spRestartPlugin(spPlugin *plugin);

extern long _spWritePlugin(spPlugin *plugin, char *data, long length);
extern spBool spFlushPlugin(spPlugin *plugin);

extern char *xspFindRelatedPluginFile(char *plugin_name);
extern char *xspFindSuitablePluginFileWithPriority(spPluginDeviceType device_type,
						   char *filename, char *mode, int *current_priority);
extern char *xspFindSuitablePluginFile(spPluginDeviceType device_type, char *filename, char *mode);
extern spPlugin *spOpenFilePlugin(char *plugin_name, char *filename, char *mode,
				  spPluginDeviceType device_type,
				  spWaveInfo *wave_info, spSongInfo *song_info,
				  spPluginOpenCallback call_func, void *call_data,
				  spPluginError *error);
extern spPlugin *spOpenFilePluginAuto(char *plugin_name, char *filename, char *mode,
				      spPluginDeviceType device_type,
				      spWaveInfo *wave_info, spSongInfo *song_info,
				      spPluginOpenCallback call_func, void *call_data,
				      spPluginError *error);
extern spPlugin *spOpenFilePluginArg(char *plugin_name, char *filename, char *mode,
				     spPluginDeviceType device_type,
				     spWaveInfo *wave_info, spSongInfo *song_info,
				     int argc, char **argv, spPluginError *error);
extern spPlugin *spOpenFilePluginArgAuto(char *plugin_name, char *filename, char *mode,
					 spPluginDeviceType device_type,
					 spWaveInfo *wave_info, spSongInfo *song_info,
					 int argc, char **argv, spPluginError *error);
extern spBool spCloseFilePlugin(spPlugin *plugin);

#define spWritePlugin(plugin, data, length) \
_spWritePlugin(plugin, (char *)(data), length)

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPOUTPUTPLUGIN_H */
