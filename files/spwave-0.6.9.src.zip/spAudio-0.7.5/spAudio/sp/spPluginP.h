/*
 *	spPluginP.h
 */

#ifndef __SPPLUGINP_H
#define __SPPLUGINP_H

#include <sp/spPlugin.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#if defined(__CYGWIN32__)
#define spPluginExport
#define SP_PLUGIN_DEFAULT_SEARCH_PATH "~/sp_plugins;~/.sp_plugins;c:/Program Files/sp/plugins;c:/usr/lib/sp/plugins"
#else
#define spPluginExport __declspec(dllexport)
#define SP_PLUGIN_DEFAULT_SEARCH_PATH "~\\sp_plugins;~\\.sp_plugins;c:\\Program Files\\sp\\plugins;c:\\usr\\lib\\sp\\plugins"
#endif
#define SP_PLUGIN_SUFFIX ".dll"

#elif defined(MACOS)
    
#define spPluginExport

#if defined(MACOSX)
#define SP_PLUGIN_DEFAULT_SEARCH_PATH "./sp_plugins;./.sp_plugins"
#define SP_PLUGIN_SUFFIX ".bundle"
#else
#define SP_PLUGIN_DEFAULT_SEARCH_PATH ":sp_plugins;:.sp_plugins"
#define SP_PLUGIN_SUFFIX ".dll"
#endif

#else
#define spPluginExport

#define SP_PLUGIN_DEFAULT_SEARCH_PATH ".:~/.sp_plugins:/usr/lib/sp/plugins:/usr/local/lib/sp/plugins"
#define SP_PLUGIN_SUFFIX ".so"
#endif
    
#define SP_GET_PLUGIN_REC_FUNC "spGetPluginRec"
#define SP_PLUGIN_SYSTEM_VERSION_FUNC "spPluginSystemVersion"
#define SP_PLUGIN_SUPPORTED_VERSION_FUNC "spPluginSupportedVersion"
#define SP_PLUGIN_PATH_ENV "SP_PLUGIN_PATH"

struct _spPluginRec
{
    void *host_data;		/* host data */
    void *user_data;		/* user data */
    
    spPluginType type;
    char *plugin_id;
    long version_id;
    int priority;
    unsigned long caps;
    spBool (*init)(char *lang);
    spBool (*free)(void);
    char *description;		/* short description */
    char *information;		/* shown in about dialog box. can include '\n' */
    
    void *(*init_instance)(char *lang);		/* must return non-NULL */
    spBool (*free_instance)(void *instance);
    spOptions (*init_options)(void *instance, char *lang); 	/* Don't use pointers to static or global variables for `value'. Use pointers to the variables in an instance. */
    spBool (*free_options)(void *instance, spOptions options);
};

struct _spPluginHost
{
    char *name;			/* plugin file name */
    long version_id;
    long ref_count;
    void *mutex;
    void *data;
    long num_instance;
};

struct _spPlugin
{
    spPluginHost *host;
    spPluginRec *rec;
    
    /* items for instance */
    void *handle;		/* plugin handle */
    void *instance;		/* plugin instance */
};

#if defined(MACOS)
#pragma import on
#endif

extern spBool spAddPluginRecList(spPluginRec *plugin_rec, char *name);
extern spBool spRemovePluginRecList(spPluginRec *plugin_rec, char *name);
extern spPluginRec *spSearchPluginRecList(char *name);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPLUGINP_H */
