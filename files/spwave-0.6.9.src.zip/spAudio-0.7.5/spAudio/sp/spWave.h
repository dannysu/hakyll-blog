/*
 *	spWave.h
 */

#ifndef __SPWAVE_H
#define __SPWAVE_H

#include <sp/spDefs.h>
#include <sp/spAudioDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_WAVE_WAV_ID "wav"
#define SP_WAVE_AIFF_ID "aiff"
#define SP_WAVE_AIFC_ID "aifc"
    
#if BYTE_ORDER == BIG_ENDIAN
#define SP_WAV_NEED_SWAP 1
#else
#define SP_WAV_NEED_SWAP 0
#endif

#if BYTE_ORDER == BIG_ENDIAN
#define SP_AIFF_NEED_SWAP 0
#else
#define SP_AIFF_NEED_SWAP 1
#endif

#define SP_WAVE_FORMAT_SIZE 32
#define SP_WAVE_FILE_TYPE_SIZE 32
#define SP_WAVE_FILE_DESC_SIZE 128
#define SP_WAVE_FILE_FILTER_SIZE 32

typedef struct _spWaveInfo {
    char file_type[SP_WAVE_FILE_TYPE_SIZE]; 	/* format unique ID, e.g. "wav" */
    char file_desc[SP_WAVE_FILE_DESC_SIZE]; 	/* format description, e.g. "Microsoft PCM" */
    char file_filter[SP_WAVE_FILE_FILTER_SIZE];	/* filter mask, e.g. "*.wav" */
    int buffer_size;		/* buffer size for output buffer */
    long header_size;		/* you can skip header by fseek using this size. If you can't, zero will be returned. */
    int samp_bit;		/* bits/sample */
    int num_channel;		/* number of channels */
    double samp_rate;		/* sampling rate [Hz] */
    long bit_rate;		/* bit rate [bits/sec] */
    long length;		/* total length of sound [point] */
} spWaveInfo;

#define SP_SONG_NO_INFO 0
#define SP_SONG_TRACK_MASK (1L<<0)
#define SP_SONG_TITLE_MASK (1L<<1)
#define SP_SONG_ARTIST_MASK (1L<<2)
#define SP_SONG_ALBUM_MASK (1L<<3)
#define SP_SONG_GENRE_MASK (1L<<4)
#define SP_SONG_RELEASE_MASK (1L<<5)
#define SP_SONG_COPYRIGHT_MASK (1L<<6)
#define SP_SONG_ENGINEER_MASK (1L<<7)
#define SP_SONG_SOURCE_MASK (1L<<8)
#define SP_SONG_SOFTWARE_MASK (1L<<9)
#define SP_SONG_SUBJECT_MASK (1L<<10)
#define SP_SONG_COMMENT_MASK (1L<<11)

#define SP_SONG_INFO_SIZE 128

typedef struct _spSongInfo {
    unsigned long info_mask;
    int track;
    char title[SP_SONG_INFO_SIZE];
    char artist[SP_SONG_INFO_SIZE];
    char album[SP_SONG_INFO_SIZE];
    char genre[SP_SONG_INFO_SIZE];
    char release[SP_SONG_INFO_SIZE];
    char copyright[SP_SONG_INFO_SIZE];
    char engineer[SP_SONG_INFO_SIZE];
    char source[SP_SONG_INFO_SIZE];
    char software[SP_SONG_INFO_SIZE];
    char subject[SP_SONG_INFO_SIZE];
    char comment[SP_SONG_INFO_SIZE];
} spSongInfo;
    
typedef struct _spSongInfo *spSongInfoPtr;
    
#if defined(MACOS)
#pragma import on
#endif

extern spBool spIsWavFile(char *filename);
extern spBool spReadWavInfo(spWaveInfo *wave_info, FILE *fp);
extern spBool spWriteWavInfo(spWaveInfo *wave_info, FILE *fp);
extern long _spReadWavData(spWaveInfo *wave_info, char *data, long length, FILE *fp);
extern long _spWriteWavData(spWaveInfo *wave_info, char *data, long length, FILE *fp);
extern unsigned long spGetWavSongInfoMask(void);
extern spBool spGetWavSongInfo(spSongInfo *song_info, FILE *fp); /* fp must be located at file start or data end */
extern spBool spReadWavSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp);
extern spBool spAddWavSongInfo(spSongInfo *song_info, FILE *fp); /* fp must be located at file start or data end */
extern spBool spWriteWavSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp);

/* (data buffer size) = length * sizeof(short), (samp_bit <= 16)
   (data buffer size) = length * sizeof(long), (16 < samp_bit <= 32) */
#define spReadWavData(wave_info, data, length, fp) _spReadWavData(wave_info, (char *)(data), length, fp)
#define spWriteWavData(wave_info, data, length, fp) _spWriteWavData(wave_info, (char *)(data), length, fp)

extern spBool spIsAiffFile(char *filename);
extern spBool spReadAiffInfo(spWaveInfo *wave_info, FILE *fp);
extern spBool spWriteAiffInfo(spWaveInfo *wave_info, FILE *fp);
extern long _spReadAiffData(spWaveInfo *wave_info, char *data, long length, FILE *fp);
extern long _spWriteAiffData(spWaveInfo *wave_info, char *data, long length, FILE *fp);
extern unsigned long spGetAiffSongInfoMask(void);
extern spBool spGetAiffSongInfo(spSongInfo *song_info, FILE *fp); /* location of fp is not restricted */
extern spBool spReadAiffSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp);
extern spBool spAddAiffSongInfo(spSongInfo *song_info, FILE *fp); /* fp must be located at file start or data end */
extern spBool spWriteAiffSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp);

#define spReadAiffData(wave_info, data, length, fp) _spReadAiffData(wave_info, (char *)(data), length, fp)
#define spWriteAiffData(wave_info, data, length, fp) _spWriteAiffData(wave_info, (char *)(data), length, fp)

extern spBool spInitWaveInfo(spWaveInfo *wave_info);
extern spBool spInitSongInfo(spSongInfo *song_info);
extern spBool spCopySongInfo(spSongInfo *dest_info, spSongInfo *src_info);
extern spBool spEqSongInfo(spSongInfo *info1, spSongInfo *info2);
extern spBool spShowSongInfo(spSongInfo *song_info, char *indent, FILE *fp);

/* the following functions may remove in future release */
extern void spPlayFileUseDatLink(spBool flag);
extern void spPlayFileUseWav(spBool flag);
extern spBool spSetPlayCommand(char *format);
extern spBool spPlayFile(char *filename, int num_channel, double samp_rate);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPWAVE_H */
