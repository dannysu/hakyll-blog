/*
 *	spPlugin.h
 */

#ifndef __SPPLUGIN_H
#define __SPPLUGIN_H

#include <sp/spDefs.h>
#include <sp/spOption.h>
#include <sp/spAudioDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_PLUGIN_VERSION_STRING	"1.3.0"
#define SP_PLUGIN_VERSION 		1
#define SP_PLUGIN_REVISION		3
#define SP_PLUGIN_UPDATE_LEVEL		0
#define SP_PLUGIN_VERSION_ID		(SP_PLUGIN_VERSION * 1000 + SP_PLUGIN_REVISION)

#define SP_PLUGIN_CHECK_VERSION(version, revision, update) \
    (SP_PLUGIN_VERSION > (version) || \
     (SP_PLUGIN_VERSION == (version) && SP_PLUGIN_REVISION > (revision)) || \
     (SP_PLUGIN_VERSION == (version) && SP_PLUGIN_REVISION == (revision) && SP_PLUGIN_UPDATE_LEVEL >= (update)))
    
#define SP_PLUGIN_VERIFY_VERSION
#define SP_PLUGIN_SUPPORTED_VERSION_ID	SP_PLUGIN_VERSION_ID

/*
 * spPluginType: 	"plugin_type_name version_id"
 * version_id: 		version.revision
 */    
typedef char *spPluginType;
#define SP_PLUGIN_UNKNOWN NULL
    
typedef enum {
    SP_PLUGIN_CR_NONE = -1,
    SP_PLUGIN_CR_ERROR = 0,
    SP_PLUGIN_CR_OPTION = 1,
} spPluginCallbackReason;

typedef enum {
    SP_PLUGIN_STATE_ERROR = -1,
    SP_PLUGIN_STATE_STOP = 0,
    SP_PLUGIN_STATE_START = 1,
    SP_PLUGIN_STATE_PAUSE,
} spPluginState;
    
typedef enum {
    SP_PLUGIN_DEVICE_UNKNOWN = -1,
    SP_PLUGIN_DEVICE_FILE = 0,
    SP_PLUGIN_DEVICE_AUDIO = 1,
    SP_PLUGIN_DEVICE_CD = 2,
    SP_PLUGIN_DEVICE_MIXER = 3,
    SP_PLUGIN_DEVICE_OTHERS = 4,
} spPluginDeviceType;

/* this parameter is used for finding file. */
#define SP_PLUGIN_PRIORITY_HIGHEST 0
#define SP_PLUGIN_PRIORITY_HIGHER 1
#define SP_PLUGIN_PRIORITY_MIDDLE 2
#define SP_PLUGIN_PRIORITY_LOWER 3
#define SP_PLUGIN_PRIORITY_LOWEST 4
#define SP_PLUGIN_PRIORITY_NULL 5

typedef int spPluginError;
#define SP_PLUGIN_ERROR_SUCCESS SP_TRUE
#define SP_PLUGIN_ERROR_FAILURE SP_FALSE
#define SP_PLUGIN_ERROR_NO_ERROR SP_TRUE
#define SP_PLUGIN_ERROR_WRONG_PLUGIN (-1)
#define SP_PLUGIN_ERROR_OPEN (-2)
#define SP_PLUGIN_ERROR_READ (-3)
#define SP_PLUGIN_ERROR_WRITE (-4)
#define SP_PLUGIN_ERROR_LOAD (-5)
#define SP_PLUGIN_ERROR_SUITABLE_NOT_FOUND (-6)
#define SP_PLUGIN_ERROR_MULTIPLE_INSTANCE (-7)
#define SP_PLUGIN_ERROR_INSTANTIATE (-8)
#define SP_PLUGIN_ERROR_BOGUS_FILE (-10)
#define SP_PLUGIN_ERROR_FILE_TYPE (-11)
#define SP_PLUGIN_ERROR_SAMP_RATE (-12)
#define SP_PLUGIN_ERROR_SAMP_BIT (-13)
#define SP_PLUGIN_ERROR_NUM_CHANNEL (-14)
#define SP_PLUGIN_ERROR_OTHRE_INFO (-15)
#define SP_PLUGIN_ERROR_TOTAL_LENGTH_REQUIRED (-16)
#define SP_PLUGIN_ERROR_UNKNOWN_DEVICE (-20)
#define SP_PLUGIN_ERROR_USER (-256)

#define SP_PLUGIN_CAPS_THREAD_SAFE (1<<1)
#define SP_PLUGIN_CAPS_NEED_LOCK (1<<2)
#define SP_PLUGIN_CAPS_MEMORY_SAFE (1<<3) /* doesn't execute memory related functions in read/write function */
#define SP_PLUGIN_CAPS_KEEP_IN_MEMORY (1<<4)
#define SP_PLUGIN_CAPS_USER_SHIFT 16
#define SP_PLUGIN_CAPS_USER (1<<SP_PLUGIN_CAPS_USER_SHIFT)

typedef struct _spPluginRec spPluginRec;
typedef struct _spPluginHost spPluginHost;
typedef struct _spPlugin spPlugin;

typedef spPluginRec *(*spGetPluginRecFunc)(void);
typedef long (*spPluginVersionFunc)(void);

typedef spBool (*spPluginOpenCallback)(spPlugin *plugin, spPluginCallbackReason reason, void *host_data, void *call_data);

#if defined(MACOS)
#pragma import on
#endif

extern void spSetPluginLang(char *lang);
extern void spSetPluginSearchPath(char *pathlist);

extern spPlugin *spLoadPlugin(char *plugin_name);
extern spBool spFreePlugin(spPlugin *plugin);

extern spBool spEqPluginType(spPlugin *plugin, spPluginType type);
extern char *spGetPluginName(spPlugin *plugin);
extern char *spGetPluginId(spPlugin *plugin);
extern char *spGetPluginDescription(spPlugin *plugin);
extern char *spGetPluginInformation(spPlugin *plugin);
extern long spGetPluginVersionId(spPlugin *plugin);
extern int spGetPluginPriority(spPlugin *plugin);
extern spBool spGetPluginVersion(spPlugin *plugin, int *version, int *revision);
extern unsigned long spGetPluginCaps(spPlugin *plugin);
extern spBool spIsPluginCapable(spPlugin *plugin, unsigned long cap);

extern long spGetNumPluginInstance(spPlugin *plugin);
extern spBool spIsPluginInstantiatable(spPlugin *plugin);
extern spBool spInitPluginInstance(spPlugin *plugin);
extern spBool spFreePluginInstance(spPlugin *plugin);
extern spPlugin *spInstantiatePlugin(char *plugin_name);

extern spOptions spInitPluginOptions(spPlugin *plugin);
extern spBool spFreePluginOptions(spPlugin *plugin, spOptions options);
extern void spPrintPluginOptions(spPlugin *plugin);
extern spBool spPluginUsage(char *plugin_name);

extern spBool spIsPluginFile(char *filename);
extern char *xspSearchPluginFile(int index);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPLUGIN_H */
