/*
 *	spAudioDefs.h
 */

#ifndef __SPAUDIODEFS_H
#define __SPAUDIODEFS_H

#include <sp/spDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_AUDIO_VERSION_STRING	"0.7.5"
#define SP_AUDIO_VERSION 	0
#define SP_AUDIO_REVISION	7
#define SP_AUDIO_UPDATE_LEVEL	5
#define SP_AUDIO_VERSION_ID	(SP_AUDIO_VERSION * 1000 + SP_AUDIO_REVISION)

#define SP_AUDIO_CHECK_VERSION(version, revision, update) \
    (SP_AUDIO_VERSION > (version) || \
     (SP_AUDIO_VERSION == (version) && SP_AUDIO_REVISION > (revision)) || \
     (SP_AUDIO_VERSION == (version) && SP_AUDIO_REVISION == (revision) && SP_AUDIO_UPDATE_LEVEL >= (update)))
    
#undef SP_AUDIO_SUPPORT_PLUGIN
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPAUDIODEFS_H */
