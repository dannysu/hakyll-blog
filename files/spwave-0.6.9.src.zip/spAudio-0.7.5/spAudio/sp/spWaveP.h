/*
 *	spWaveP.h
 */

#ifndef __SPWAVEP_H
#define __SPWAVEP_H

#include <sp/spWave.h>
#include <sp/spWave_Wav.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPWAVEP_H */
