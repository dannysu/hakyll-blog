/*
 *	spAudio.h
 */

#ifndef __SPAUDIO_H
#define __SPAUDIO_H

#include <sp/spDefs.h>
#include <sp/spAudioDefs.h>

#if defined(SGI) || defined(linux) || defined(OSS) || defined(_WIN32) || defined(sun) || defined(MACOS)
#define SP_SUPPORT_AUDIO
#endif

#if 0
#if TARGET_API_MAC_CARBON || defined(MACOSX)
#undef SP_SUPPORT_AUDIO
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spAudio *spAudio;

#define SP_AUDIO_BLOCKING 0
#define SP_AUDIO_NONBLOCKING 1

#if defined(MACOS)
#pragma import on
#endif

extern spAudio spInitAudio(void);
extern spBool spSetAudioSampleRate(spAudio audio, double samp_rate);
extern spBool spGetAudioSampleRate(spAudio audio, double *samp_rate);
extern spBool spSetAudioChannel(spAudio audio, int num_channel);
extern spBool spGetAudioChannel(spAudio audio, int *num_channel);
extern spBool spSetAudioBufferSize(spAudio audio, int buffer_size);
extern spBool spGetAudioBufferSize(spAudio audio, int *buffer_size);
extern spBool spSetAudioNumBuffer(spAudio audio, int num_buffer);
extern spBool spGetAudioNumBuffer(spAudio audio, int *num_buffer);
extern spBool spSetAudioBlockingMode(spAudio audio, int block_mode);
extern spBool spGetAudioBlockingMode(spAudio audio, int *block_mode);
extern spBool spSetAudioSampleBit(spAudio audio, int samp_bit);
extern spBool spGetAudioSampleBit(spAudio audio, int *samp_bit);

extern spBool spOpenAudioDevice(spAudio audio, char *mode);
extern spBool spCloseAudioDevice(spAudio audio);
extern long _spReadAudio(spAudio audio, char *data, long length);
extern long _spWriteAudio(spAudio audio, char *data, long length);
extern spBool spGetAudioOutputPosition(spAudio audio, long *position);
extern spBool spStopAudio(spAudio audio);
extern spBool spSyncAudio(spAudio audio);
extern void _spFreeAudio(spAudio audio);

#if defined(MACOS)
#pragma import off
#endif

#define spReadAudio(audio, data, length) _spReadAudio(audio, (char *)(data), length)
#define spWriteAudio(audio, data, length) _spWriteAudio(audio, (char *)(data), length)
#define spFreeAudio(audio) {_spFreeAudio(audio); (audio) = NULL;}

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPAUDIO_H */
