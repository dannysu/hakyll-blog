/*
 *	spOutputPlugin.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spWave.h>

#include <sp/spOutputPluginP.h>
#include <sp/spInputPluginP.h>

spBool spIsIoPlugin(spPlugin *plugin)
{
    if (plugin == NULL) return SP_FALSE;

    if (spEqPluginType(plugin, SP_PLUGIN_INPUT) == SP_TRUE
	|| spEqPluginType(plugin, SP_PLUGIN_OUTPUT) == SP_TRUE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spIsOutputPlugin(spPlugin *plugin)
{
    if (plugin == NULL) return SP_FALSE;

    if (spEqPluginType(plugin, SP_PLUGIN_OUTPUT) == SP_TRUE) {
	spDebug(100, "spIsOutputPlugin", "SP_TRUE\n");
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spPluginDeviceType spGetPluginDeviceType(spPlugin *plugin)
{
    if (plugin == NULL) return SP_PLUGIN_DEVICE_UNKNOWN;

    if (spIsIoPlugin(plugin) == SP_TRUE) {
	return ((spIoPluginRec *)plugin->rec)->device_type;
    }
    
    return SP_PLUGIN_DEVICE_UNKNOWN;
}

int spFindPluginRecFileTypeIndex(spIoPluginRec *rec, char *type)
{
    int i;
    int index;

    if (rec == NULL) return -1;
    if (strnone(type)) return 0;

    index = 0;
    for (i = 0; rec->file_type_list[i] != NULL; i++) {
	spDebug(100, "spFindPluginFileTypeIndex", "file_type_list[%d] = %s\n",
		i, rec->file_type_list[i]);
	if (strcaseeq(type, rec->file_type_list[i])
	    || (rec->file_desc_list != NULL
		&& strcaseeq(type, rec->file_desc_list[i]))) {
	    index = i;
	    break;
	}
    }
    spDebug(80, "spFindPluginRecFileTypeIndex", "index = %d\n", index);

    return index;
}

int spFindPluginFileTypeIndex(spPlugin *plugin, char *type)
{
    if (plugin == NULL) return -1;

    return spFindPluginRecFileTypeIndex((spIoPluginRec *)plugin->rec, type);
}

spBool spSetPluginFileTypeIndex(spPlugin *plugin, int index)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->set_file_type == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->set_file_type(plugin->instance, index);
}

int spGetPluginFileTypeIndex(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return -1;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_file_type == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;
    
    return rec->get_file_type(plugin->instance);
}

char *spGetPluginFileTypeString(spPlugin *plugin, int index)
{
    int i;
    char *string;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_file_type == NULL || rec->file_type_list == NULL) return NULL;

    if (index < 0) {
	if (plugin->instance == NULL
	    && spInitPluginInstance(plugin) == SP_FALSE) return NULL;
	
	index = rec->get_file_type(plugin->instance);
    }

    string = NULL;
    for (i = 0; rec->file_type_list[i] != NULL; i++) {
	if (index == i) {
	    string = rec->file_type_list[i];
	    break;
	}
    }

    return string;
}

char *spGetPluginFileDescString(spPlugin *plugin, int index)
{
    int i;
    char *string;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_file_type == NULL || rec->file_desc_list == NULL) return NULL;

    if (index < 0) {
	if (plugin->instance == NULL
	    && spInitPluginInstance(plugin) == SP_FALSE) return NULL;
	
	index = rec->get_file_type(plugin->instance);
    }

    string = NULL;
    for (i = 0; rec->file_desc_list[i] != NULL; i++) {
	if (index == i) {
	    string = rec->file_desc_list[i];
	    break;
	}
    }

    return string;
}

char *spGetPluginFileFilterString(spPlugin *plugin, int index)
{
    int i;
    char *string;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_file_type == NULL || rec->file_filter_list == NULL) return NULL;

    if (index < 0) {
	if (plugin->instance == NULL
	    && spInitPluginInstance(plugin) == SP_FALSE) return NULL;
	
	index = rec->get_file_type(plugin->instance);
    }

    string = NULL;
    for (i = 0; rec->file_filter_list[i] != NULL; i++) {
	if (index == i) {
	    string = rec->file_filter_list[i];
	    break;
	}
    }

    return string;
}

spBool spSetPluginFileType(spPlugin *plugin, char *type)
{
    int index;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;

    if (rec->set_file_type == NULL) return SP_FALSE;
    if (rec->file_type_list == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    spDebug(80, "spSetPluginFileType", "type = %s\n", type);

    index = spFindPluginFileTypeIndex(plugin, type);
    
    return rec->set_file_type(plugin->instance, index);
}

char *spGetPluginFileType(spPlugin *plugin, spBool long_flag)
{
    int i;
    int index;
    char *string;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_file_type == NULL) return NULL;
    if (rec->file_type_list == NULL) return NULL;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return NULL;

    index = rec->get_file_type(plugin->instance);
    spDebug(80, "spGetPluginFileType", "index = %d\n", index);
	
    string = NULL;
    for (i = 0; rec->file_type_list[i] != NULL; i++) {
	if (index == i) {
	    if (long_flag == SP_TRUE && rec->file_desc_list != NULL) {
		string = rec->file_desc_list[i];
	    } else {
		string = rec->file_type_list[i];
	    }
    
	    spDebug(80, "spGetPluginFileType", "file_type = %s\n", string);
	    break;
	}
    }
    
    return string;
}

char *spGetPluginFileDescription(spPlugin *plugin, spBool filter_flag)
{
    int i;
    int index;
    char *string;
    static char buf[SP_MAX_LINE] = "";
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_file_type == NULL) return NULL;
    if (rec->file_type_list == NULL) return NULL;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return NULL;

    index = rec->get_file_type(plugin->instance);
	
    string = NULL;
    for (i = 0; rec->file_type_list[i] != NULL; i++) {
	if (index == i) {
	    if (rec->file_desc_list != NULL) {
		string = rec->file_desc_list[i];
	    } else {
		string = rec->file_type_list[i];
	    }
	    break;
	}
    }

    if (string != NULL && filter_flag == SP_TRUE
	&& rec->file_filter_list != NULL) {
	sprintf(buf, "%s (%s)", string, rec->file_filter_list[index]);
	string = buf;
    }
    
    return string;
}

char *spGetPluginFileFilter(spPlugin *plugin)
{
    int i;
    int index;
    char *string;
    static char buf[SP_MAX_LINE] = "";
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_file_type == NULL) return NULL;
    if (rec->file_filter_list == NULL) return NULL;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return NULL;

    index = rec->get_file_type(plugin->instance);
	
    string = NULL;
    for (i = 0; rec->file_filter_list[i] != NULL; i++) {
	if (index == i) {
	    string = rec->file_filter_list[i];
	    break;
	}
    }

    if (string == NULL) {
	strcpy(buf, "*");
	string = buf;
    }
    
    return string;
}

spBool spSearchPluginFileType(int index, spPluginType plugin_type,
			      spPluginDeviceType device_type, char *plugin_name,
			      char *file_type, char *file_desc, char *file_filter)
{
    char *string;
    spPlugin *plugin;
    static char *current_plugin_name = NULL;
    static int current_plugin_index = 0;
    static int current_type_index = 0;

    if (index <= 0) {
	if (current_plugin_name != NULL) {
	    xfree(current_plugin_name);
	}
	current_plugin_name = NULL;
	current_plugin_index = 0;
	current_type_index = 0;
    }

    while (1) {
	if (current_plugin_name == NULL) {
	    if ((current_plugin_name = xspSearchPluginFile(current_plugin_index)) == NULL) {
		break;
	    }
	}
	spDebug(100, "spSearchPluginFileType", "current_plugin_name = %s\n", current_plugin_name);

	if ((plugin = spLoadPlugin(current_plugin_name)) != NULL) {
	    if (spEqPluginType(plugin, plugin_type) == SP_TRUE
		&& spGetPluginDeviceType(plugin) == device_type) {
		if ((string = spGetPluginFileTypeString(plugin, current_type_index)) != NULL) {
		    spDebug(100, "spSearchPluginFileType", "file type = %s\n", string);
		    if (file_type != NULL) {
			strcpy(file_type, string);
		    }
		    if (plugin_name != NULL) {
			strcpy(plugin_name, current_plugin_name);
		    }
		    if (file_desc != NULL) {
			if ((string = spGetPluginFileDescString(plugin, current_type_index)) != NULL) {
			    strcpy(file_desc, string);
			} else {
			    strcpy(file_desc, "");
			}
		    }
		    if (file_filter != NULL) {
			if ((string = spGetPluginFileFilterString(plugin, current_type_index)) != NULL) {
			    strcpy(file_filter, string);
			} else {
			    strcpy(file_filter, "");
			}
		    }
		    current_type_index++;
		    spFreePlugin(plugin);
		    return SP_TRUE;
		}

	    }
	    spFreePlugin(plugin);
	}
	
	xfree(current_plugin_name);
	current_plugin_name = NULL;

	current_type_index = 0;
	current_plugin_index++;
    }
    
    return SP_FALSE;
}

spBool spGetPluginSongInfoMask(spPlugin *plugin, unsigned long *info_mask)
{
    unsigned long mask;
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || info_mask == NULL) return SP_FALSE;

    if (spGetPluginOtherInfo(plugin, SP_PLUGIN_INFO_SONG_INFO_MASK, (char *)&mask) == SP_TRUE) {
	*info_mask = mask;
	spDebug(50, "spGetPluginSongInfoMask", "get mask from other info: mask = %ld\n", mask);
    } else {
	rec = (spIoPluginRec *)plugin->rec;
	*info_mask = rec->song_info_mask;
	spDebug(50, "spGetPluginSongInfoMask", "mask = %ld\n", mask);
    }
    
    return SP_TRUE;
}

spBool spSetPluginSongInfo(spPlugin *plugin, spSongInfo *song_info)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || song_info == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->set_song_info == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->set_song_info(plugin->instance, song_info);
}

spBool spGetPluginSongInfo(spPlugin *plugin, spSongInfo *song_info)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || song_info == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_song_info == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->get_song_info(plugin->instance, song_info);
}

char *spGetPluginBestSuffix(spPlugin *plugin)
{
    spIoPluginRec *rec;
    
    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_best_suffix == NULL) return NULL;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return NULL;

    return rec->get_best_suffix(plugin->instance);
}

spBool spIsSupportedByPlugin(spPlugin *plugin, char *filename)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || filename == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->is_supported == NULL) return SP_FALSE;
    
    return rec->is_supported(filename);
}

spBool spGetPluginNumDevice(spPlugin *plugin, int *num_device)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || num_device == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_num_device == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_num_device(plugin->instance, num_device);
}

char *spGetPluginDeviceName(spPlugin *plugin, int index)
{
    spIoPluginRec *rec;
    
    if (spIsIoPlugin(plugin) == SP_FALSE) return NULL;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_device_name == NULL) return NULL;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return NULL;

    return rec->get_device_name(plugin->instance, index);
}

spBool spSelectPluginDevice(spPlugin *plugin, int index)
{
    spIoPluginRec *rec;
    
    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->select_device == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->select_device(plugin->instance, index);
}

spBool spSetPluginBufferSize(spPlugin *plugin, int buffer_size)
{
    spIoPluginRec *rec;
    
    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->set_buffer_size == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->set_buffer_size(plugin->instance, buffer_size);
}

spBool spGetPluginBufferSize(spPlugin *plugin, int *buffer_size)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || buffer_size == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_buffer_size == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_buffer_size(plugin->instance, buffer_size);
}

spBool spSetPluginVolume(spPlugin *plugin, int channel, int volume)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->set_volume == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->set_volume(plugin->instance, channel, volume);
}

spBool spGetPluginVolume(spPlugin *plugin, int channel, int *volume)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || volume == NULL) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_volume == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_volume(plugin->instance, channel, volume);
}

spBool spSetPluginVolumeStereo(spPlugin *plugin, int l_volume, int r_volume)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->set_volume == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    if (rec->set_volume(plugin->instance, 0, l_volume) == SP_FALSE) {
	return SP_FALSE;
    }
    if (rec->set_volume(plugin->instance, 1, r_volume) == SP_FALSE) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spGetPluginVolumeStereo(spPlugin *plugin, int *l_volume, int *r_volume)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE
	|| (l_volume == NULL && r_volume == NULL)) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_volume == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    if (l_volume != NULL) {
	if (rec->get_volume(plugin->instance, 0, l_volume) == SP_FALSE) {
	    return SP_FALSE;
	}
    }
    if (r_volume != NULL) {
	if (rec->get_volume(plugin->instance, 1, r_volume) == SP_FALSE) {
	    return SP_FALSE;
	}
    }

    return SP_TRUE;
}

spBool spSetPluginSampleBit(spPlugin *plugin, int samp_bit)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->set_sample_bit == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->set_sample_bit(plugin->instance, samp_bit);
}

spBool spGetPluginSampleBit(spPlugin *plugin, int *samp_bit)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || samp_bit == NULL) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_sample_bit == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_sample_bit(plugin->instance, samp_bit);
}

spBool spGetPluginDataSampleBit(spPlugin *plugin, int *samp_bit)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || samp_bit == NULL) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_sample_bit == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    if (rec->get_sample_bit(plugin->instance, samp_bit) == SP_TRUE) {
	if (*samp_bit <= 16) {
	    *samp_bit = sizeof(short) * 8;
	} else if (*samp_bit <= 32) {
	    *samp_bit = sizeof(long) * 8;
	} else if (*samp_bit == 33) {
	    *samp_bit = sizeof(float) * 8;
	} else {
	    *samp_bit = sizeof(double) * 8;
	}

	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spSetPluginChannel(spPlugin *plugin, int num_channel)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->set_channel == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->set_channel(plugin->instance, num_channel);
}

spBool spGetPluginChannel(spPlugin *plugin, int *num_channel)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || num_channel == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_channel == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_channel(plugin->instance, num_channel);
}

spBool spSetPluginSampleRate(spPlugin *plugin, double samp_rate)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->set_sample_rate == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->set_sample_rate(plugin->instance, samp_rate);
}

spBool spGetPluginSampleRate(spPlugin *plugin, double *samp_rate)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || samp_rate == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_sample_rate == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->get_sample_rate(plugin->instance, samp_rate);
}

spBool spSetPluginOtherInfo(spPlugin *plugin, char *id, char *data)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || id == NULL || data == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->set_other_info == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->set_other_info(plugin->instance, id, data);
}

spBool spGetPluginOtherInfo(spPlugin *plugin, char *id, char *data)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE || id == NULL || data == NULL) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->get_other_info == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->get_other_info(plugin->instance, id, data);
}

spPluginError spOpenPlugin(spPlugin *plugin, char *filename, char *mode)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) {
	return SP_PLUGIN_ERROR_WRONG_PLUGIN;
    }
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->open == NULL) {
	return SP_PLUGIN_ERROR_WRONG_PLUGIN;
    }
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->open(plugin->instance, filename, mode);
}

spBool spClosePlugin(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->close == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;

    return rec->close(plugin->instance);
}

spPluginState spGetPluginState(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_PLUGIN_STATE_ERROR;
    
    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_state == NULL) return SP_PLUGIN_STATE_ERROR;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_PLUGIN_STATE_ERROR;
    
    return rec->get_state(plugin->instance);
}

long spGetPluginCurrentPosition(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return -1;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->get_current_pos == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;
    
    return rec->get_current_pos(plugin->instance);
}

spBool spStopPlugin(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->stop == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->stop(plugin->instance);
}

spBool spPausePlugin(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;

    if (rec->pause == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->pause(plugin->instance);
}

spBool spRestartPlugin(spPlugin *plugin)
{
    spIoPluginRec *rec;

    if (spIsIoPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spIoPluginRec *)plugin->rec;
    
    if (rec->restart == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->restart(plugin->instance);
}

long _spWritePlugin(spPlugin *plugin, char *data, long length)
{
    spOutputPluginRec *rec;

    if (spIsOutputPlugin(plugin) == SP_FALSE) return -1;

    rec = (spOutputPluginRec *)plugin->rec;

    if (rec->write == NULL) return -1;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return -1;
    
    return rec->write(plugin->instance, data, length);
}

spBool spFlushPlugin(spPlugin *plugin)
{
    spOutputPluginRec *rec;

    if (spIsOutputPlugin(plugin) == SP_FALSE) return SP_FALSE;
    
    rec = (spOutputPluginRec *)plugin->rec;

    if (rec->flush == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->flush(plugin->instance);
}

spBool spSetPluginTotalLength(spPlugin *plugin, long total_length)
{
    spOutputPluginRec *rec;

    if (spIsOutputPlugin(plugin) == SP_FALSE) return SP_FALSE;

    rec = (spOutputPluginRec *)plugin->rec;

    if (rec->set_total_length == NULL) return SP_FALSE;
    if (plugin->instance == NULL
	&& spInitPluginInstance(plugin) == SP_FALSE) return SP_FALSE;
    
    return rec->set_total_length(plugin->instance, total_length);
}

char *xspFindRelatedPluginFile(char *plugin_name)
{
    int i;
    int input_flag = 0;
    spPlugin *plugin;
    spPlugin *o_plugin;
    spPluginDeviceType device_type;
    char *o_plugin_name = NULL;

    if (strnone(plugin_name)) return NULL;

    spDebug(100, "xspFindRelatedPluginFile", "plugin_name = %s\n", plugin_name);

    /* load input plugin */
    if ((plugin = spLoadPlugin(plugin_name)) == NULL) {
	return NULL;
    }

    device_type = spGetPluginDeviceType(plugin);
    if (spIsInputPlugin(plugin) == SP_TRUE) {
	input_flag = 1;
    } else if (spIsOutputPlugin(plugin) == SP_FALSE) {
	spFreePlugin(plugin);
	return NULL;
    }
    
    for (i = 0;; i++) {
	if ((o_plugin_name = xspSearchPluginFile(i)) == NULL) {
	    break;
	} else {
	    /* load output plugin */
	    if ((o_plugin = spLoadPlugin(o_plugin_name)) != NULL) {
		if (spGetPluginDeviceType(o_plugin) == device_type
		    && streq(spGetPluginId(o_plugin), spGetPluginId(plugin))) {
		    if (!input_flag) {
			if (spIsInputPlugin(o_plugin) == SP_TRUE) {
			    spDebug(80, "xspFindRelatedPluginFile",
				    "o_plugin_name = %s\n", o_plugin_name);
			    spFreePlugin(o_plugin);
			    break;
			}
		    } else {
			if (spIsOutputPlugin(o_plugin) == SP_TRUE) {
			    spDebug(80, "xspFindRelatedPluginFile",
				    "o_plugin_name = %s\n", o_plugin_name);
			    spFreePlugin(o_plugin);
			    break;
			}
		    }
		}

		/* free output plugin */
		spFreePlugin(o_plugin);
	    }
	    
	    xfree(o_plugin_name);
	    o_plugin_name = NULL;
	}
    }

    /* free input plugin */
    spFreePlugin(plugin);
    
    spDebug(100, "xspFindRelatedPluginFile", "done\n");
    
    return o_plugin_name;
}

char *xspFindSuitablePluginFileWithPriority(spPluginDeviceType device_type,
					    char *filename, char *mode, int *current_priority)
{
    int i, j;
    int priority;
    spPlugin *plugin;
    char *plugin_name = NULL;

    if (strnone(mode)) return NULL;

    spDebug(100, "xspFindSuitablePlugin", "mode = %s\n", mode);

    if (current_priority != NULL) {
	priority = MAX(*current_priority, 0);
    } else {
	priority = 0;
    }
    
    for (j = priority; j <= SP_PLUGIN_PRIORITY_LOWEST; j++) {
	if (plugin_name != NULL) {
	    break;
	}
	for (i = 0;; i++) {
	    if ((plugin_name = xspSearchPluginFile(i)) == NULL) {
		break;
	    } else {
		spDebug(80, "xspFindSuitablePlugin", "priority = %d, plugin_name = %s\n",
			j, plugin_name);
    
		/* load plugin */
		if ((plugin = spLoadPlugin(plugin_name)) != NULL) {
		    spDebug(80, "xspFindSuitablePlugin", "load done\n");
		
		    if (spGetPluginPriority(plugin) == j
			&& spGetPluginDeviceType(plugin) == device_type) {
			if (mode[0] == 'r') {
			    if (spIsInputPlugin(plugin) == SP_TRUE) {
				if (spIsSupportedByPlugin(plugin, filename) == SP_TRUE) {
				    spDebug(80, "xspFindSuitablePlugin", "found: %s\n", plugin_name);
				    spFreePlugin(plugin);
				    break;
				}
			    }
			} else if (mode[0] == 'w') {
			    if (spIsOutputPlugin(plugin) == SP_TRUE) {
				if (spIsSupportedByPlugin(plugin, filename) == SP_TRUE) {
				    spFreePlugin(plugin);
				    break;
				}
			    }
			}
		    }

		    /* free plugin */
		    spFreePlugin(plugin);
		}
		
		xfree(plugin_name);
		plugin_name = NULL;
	    }
	}
    }

    if (current_priority != NULL) {
	*current_priority = j;
    }
    
    return plugin_name;
}

char *xspFindSuitablePluginFile(spPluginDeviceType device_type, char *filename, char *mode)
{
    return xspFindSuitablePluginFileWithPriority(device_type, filename, mode, NULL);
}

static spPlugin *openFilePlugin(char *plugin_name, char *filename, char *mode,
				spPluginDeviceType device_type,
				spWaveInfo *wave_info, spSongInfo *song_info,
				spPluginOpenCallback call_func, void *call_data,
				int argc, char **argv, spPluginError *error)
{
    spBool flag;
    char *name;
    char *string;
    spOptions options;
    spPlugin *plugin;
    spPluginError err = SP_PLUGIN_ERROR_SUCCESS;

    if (strnone(mode)) return NULL;
    
    if (strnone(plugin_name)) {
	/* get suitable plugin name */
	if ((name = xspFindSuitablePluginFile(device_type, filename, mode)) == NULL) {
	    err = SP_PLUGIN_ERROR_SUITABLE_NOT_FOUND;
	    spDebug(30, "openFilePlugin", "can't find suitable plugin.\n");
	    if (mode[0] == 'w') {
		if (call_func != NULL) {
		    call_func(NULL, SP_PLUGIN_CR_ERROR, (void *)err, call_data);
		}
	    }
	    *error = err;
	    
	    return NULL;
	}
    } else {
	name = strclone(plugin_name);
    }
    spDebug(20, "openFilePlugin", "plugin_name = %s\n", name);

    /* load plugin */
    if ((plugin = spLoadPlugin(name)) == NULL) {
	err = SP_PLUGIN_ERROR_LOAD;
	spDebug(30, "openFilePlugin", "can't load plugin: %s\n", name);
    } else {
	spDebug(20, "openFilePlugin", "load plugin done\n");
	
	if (spIsPluginInstantiatable(plugin) == SP_FALSE) {
	    err = SP_PLUGIN_ERROR_MULTIPLE_INSTANCE;
	    spDebug(10, "openFilePlugin", "not instantiatable\n");
	} else {
	    if (spInitPluginInstance(plugin) == SP_FALSE) {
		err = SP_PLUGIN_ERROR_INSTANTIATE;
		spDebug(10, "openFilePlugin", "instantiate error\n");
	    }
	}
    }

    if (err != SP_PLUGIN_ERROR_SUCCESS) {
	if (call_func != NULL) {
	    call_func(NULL, SP_PLUGIN_CR_ERROR, (void *)err, call_data);
	}
	
	if (plugin != NULL) spFreePlugin(plugin);
	xfree(name);
	*error = err;
	
	return NULL;
    }

    if (wave_info != NULL) {
	err = SP_PLUGIN_ERROR_SUCCESS;
	if (!strnone(wave_info->file_type)) {
	    if (spSetPluginFileType(plugin, wave_info->file_type) == SP_FALSE) {
#if 1
		err = SP_PLUGIN_ERROR_FILE_TYPE;
#else
		strcpy(wave_info->file_type, "");
#endif
	    }
	}
	if (wave_info->num_channel > 0) {
	    if (spSetPluginChannel(plugin, wave_info->num_channel) == SP_FALSE) {
		err = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    }
	}
	if (wave_info->samp_bit > 0) {
	    if (spSetPluginSampleBit(plugin, wave_info->samp_bit) == SP_FALSE) {
		err = SP_PLUGIN_ERROR_SAMP_BIT;
	    }
	}
	if (wave_info->samp_rate > 0.0) {
	    if (spSetPluginSampleRate(plugin, wave_info->samp_rate) == SP_FALSE) {
		err = SP_PLUGIN_ERROR_SAMP_RATE;
	    }
	}
	if (wave_info->buffer_size > 0) {
	    spSetPluginBufferSize(plugin, wave_info->buffer_size);
	}
	if (wave_info->length > 0) {
	    spSetPluginTotalLength(plugin, wave_info->length);
	}
	if (song_info != NULL) {
	    if (mode[0] == 'w' && song_info->info_mask) {
		spSetPluginSongInfo(plugin, song_info);
	    } else {
		spInitSongInfo(song_info);
	    }
	}

	if (mode[0] == 'w' && err != SP_PLUGIN_ERROR_SUCCESS) {
	    spDebug(20, "openFilePlugin", "wrong file information\n");
	    
	    /* the file information is not supported by this plugin */
	    if (call_func != NULL) {
		call_func(plugin, SP_PLUGIN_CR_ERROR, (void *)err, call_data);
	    }
	    spFreePlugin(plugin);
	    xfree(name);
	    *error = err;
	    
	    return NULL;
	}
    }
    spDebug(20, "openFilePlugin", "set wave_info done\n");
    
    if ((options = spInitPluginOptions(plugin)) != NULL) {
	flag = SP_TRUE;
	if (argc > 0 && argv != NULL) {
	    spUpdateOptionsValue(argc, argv, options);
	}
	if (call_func != NULL) {
	    flag = call_func(plugin, SP_PLUGIN_CR_OPTION, (void *)options, call_data);
	}
	spFreePluginOptions(plugin, options);

	if (flag == SP_FALSE) {	/* maybe processing is canceled */
	    spFreePlugin(plugin);
	    xfree(name);
	    *error = err;
	    
	    return NULL;
	}
    }
    spDebug(20, "openFilePlugin", "update options done\n");
	
    /* open plugin */
    err = spOpenPlugin(plugin, filename, mode);
    *error = err;
    
    spDebug(20, "openFilePlugin", "open done: err = %d\n", err);
    
    if (err != SP_PLUGIN_ERROR_SUCCESS) {
	if (call_func != NULL) {
	    call_func(plugin, SP_PLUGIN_CR_ERROR, (void *)err, call_data);
	}
	
	spFreePlugin(plugin);
	plugin = NULL;
    } else {
	if (wave_info != NULL) {
	    if ((string = spGetPluginFileType(plugin, SP_FALSE)) != NULL) {
		strcpy(wave_info->file_type, string);
	    }
	    if ((string = spGetPluginFileDescription(plugin, SP_FALSE)) != NULL) {
		strcpy(wave_info->file_desc, string);
	    }
	    if ((string = spGetPluginFileFilter(plugin)) != NULL) {
		strcpy(wave_info->file_filter, string);
	    }
	    spGetPluginBufferSize(plugin, &wave_info->buffer_size);
	    spGetPluginSampleBit(plugin, &wave_info->samp_bit);
	    spGetPluginChannel(plugin, &wave_info->num_channel);
	    spGetPluginSampleRate(plugin, &wave_info->samp_rate);
	    if (song_info != NULL) {
		spGetPluginSongInfo(plugin, song_info);
	    }
	    wave_info->length = MAX(spGetPluginTotalLength(plugin), 0);
	    spDebug(20, "openFilePlugin", "length = %ld\n", wave_info->length);
	}
    }
    
    xfree(name);

    return plugin;
}

spPlugin *spOpenFilePlugin(char *plugin_name, char *filename, char *mode,
			   spPluginDeviceType device_type,
			   spWaveInfo *wave_info, spSongInfo *song_info,
			   spPluginOpenCallback call_func, void *call_data,
			   spPluginError *error)
{
    spPlugin *plugin;
    spPluginError err = SP_PLUGIN_ERROR_SUCCESS;
    
    plugin = openFilePlugin(plugin_name, filename, mode, device_type,
			    wave_info, song_info, call_func, call_data,
			    0, NULL, &err);
    if (error != NULL) *error = err;
    
    return plugin;
}

spPlugin *spOpenFilePluginAuto(char *plugin_name, char *filename, char *mode,
			       spPluginDeviceType device_type,
			       spWaveInfo *wave_info, spSongInfo *song_info,
			       spPluginOpenCallback call_func, void *call_data,
			       spPluginError *error)
{
    spPlugin *plugin = NULL;
    spPluginError err = SP_PLUGIN_ERROR_SUCCESS;

    if ((plugin = openFilePlugin(NULL, filename, mode,
				 device_type, wave_info, song_info,
				 call_func, call_data,
				 0, NULL, &err)) == NULL) {
	if (err == SP_PLUGIN_ERROR_SUITABLE_NOT_FOUND
	    || err == SP_PLUGIN_ERROR_FAILURE) {
	    plugin = openFilePlugin(plugin_name, filename, mode,
				    device_type, wave_info, song_info,
				    call_func, call_data,
				    0, NULL, &err);
	}
    }
    if (error != NULL) *error = err;

    return plugin;
}

spPlugin *spOpenFilePluginArg(char *plugin_name, char *filename, char *mode,
			      spPluginDeviceType device_type,
			      spWaveInfo *wave_info, spSongInfo *song_info,
			      int argc, char **argv, spPluginError *error)
{
    spPlugin *plugin;
    spPluginError err = SP_PLUGIN_ERROR_SUCCESS;
    
    plugin = openFilePlugin(plugin_name, filename, mode, device_type,
			    wave_info, song_info, NULL, NULL, argc, argv, &err);
    if (error != NULL) *error = err;
    
    return plugin;
}

spPlugin *spOpenFilePluginArgAuto(char *plugin_name, char *filename, char *mode,
				  spPluginDeviceType device_type,
				  spWaveInfo *wave_info, spSongInfo *song_info,
				  int argc, char **argv, spPluginError *error)
{
    spPlugin *plugin = NULL;
    spPluginError err = SP_PLUGIN_ERROR_SUCCESS;

    if ((plugin = openFilePlugin(NULL, filename, mode,
				 device_type, wave_info, song_info,
				 NULL, NULL, argc, argv, &err)) == NULL) {
	if (err == SP_PLUGIN_ERROR_SUITABLE_NOT_FOUND
	    || err == SP_PLUGIN_ERROR_FAILURE) {
	    plugin = openFilePlugin(plugin_name, filename, mode,
				    device_type, wave_info, song_info,
				    NULL, NULL, argc, argv, &err);
	}
    }
    if (error != NULL) *error = err;
    
    return plugin;
}

spBool spCloseFilePlugin(spPlugin *plugin)
{
    spBool flag = SP_TRUE;
    
    if (plugin == NULL) return SP_FALSE;
    
    /* close plugin */
    if (spClosePlugin(plugin) == SP_FALSE) {
	flag = SP_FALSE;
    }
    
    /* free plugin */
    if (spFreePlugin(plugin) == SP_FALSE) {
	flag = SP_FALSE;
    }
    
    return flag;
}
