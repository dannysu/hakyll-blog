/*
 *	spWave_Wav.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spKanji.h>

#include <sp/spWave_Wav.h>

char *spGetWavFormatLabelFromTag(unsigned short wFormatTag)
{
    switch (wFormatTag) {
      case WAVE_FORMAT_UNKNOWN:
	return WAVE_FORMAT_UNKNOWN_STRING;
      case WAVE_FORMAT_PCM:
	return WAVE_FORMAT_PCM_STRING;
      case WAVE_FORMAT_ADPCM:
	return WAVE_FORMAT_ADPCM_STRING;
      case WAVE_FORMAT_ALAW:
	return WAVE_FORMAT_ALAW_STRING;
      case WAVE_FORMAT_MULAW:
	return WAVE_FORMAT_MULAW_STRING;
      case WAVE_FORMAT_OKI_ADPCM:
	return WAVE_FORMAT_OKI_ADPCM_STRING;
      case WAVE_FORMAT_DIGISTD:
	return WAVE_FORMAT_DIGISTD_STRING;
      case WAVE_FORMAT_DIGIFIX:
	return WAVE_FORMAT_DIGIFIX_STRING;
      default:
	return "Unknown";
    }
}

char *spGetWavFormatLabel(WAVEHEADER wave_header)
{
    return spGetWavFormatLabelFromTag(wave_header.wFormatTag);
}

unsigned short spGetWavFormatTag(char *format)
{
    if (strnone(format)
	|| strcaseeq(format, WAVE_FORMAT_PCM_STRING)) {
	return WAVE_FORMAT_PCM;
    } else if (strcaseeq(format, WAVE_FORMAT_UNKNOWN_STRING)) {
	return WAVE_FORMAT_UNKNOWN;
    } else if (strcaseeq(format, WAVE_FORMAT_ADPCM_STRING)) {
	return WAVE_FORMAT_ADPCM;
    } else if (strcaseeq(format, WAVE_FORMAT_ALAW_STRING)) {
	return WAVE_FORMAT_ALAW;
    } else if (strcaseeq(format, WAVE_FORMAT_MULAW_STRING)) {
	return WAVE_FORMAT_MULAW;
    } else if (strcaseeq(format, WAVE_FORMAT_OKI_ADPCM_STRING)) {
	return WAVE_FORMAT_OKI_ADPCM;
    } else if (strcaseeq(format, WAVE_FORMAT_DIGISTD_STRING)) {
	return WAVE_FORMAT_DIGISTD;
    } else if (strcaseeq(format, WAVE_FORMAT_DIGIFIX_STRING)) {
	return WAVE_FORMAT_DIGIFIX;
    }
    
    return WAVE_FORMAT_UNKNOWN;
}

static long readWavHeader(WAVEHEADER *wave_header, FILE *fp, spBool check_format)
{
    long head_size = 0;
    long len = 0;

    /* seek start of the file */
    fseek(fp, 0L, SEEK_SET);
    
    if (fread(wave_header->RiffID, 1, 4, fp) != 4 ||
	!strneq("RIFF", wave_header->RiffID, 4)) {
	spDebug(1, NULL, "Can't find RIFF chunk.\n");
	return 0;
    }
    head_size += 4;

    freadlong32((long *)&wave_header->RiffSize, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;
    
    if (fread(wave_header->WaveID, 1, 4, fp) != 4 ||
	!strneq(wave_header->WaveID, "WAVE", 4)) {
	spDebug(1, NULL, "Can't find WAVE chunk.\n");
	return 0;
    }
    head_size += 4;

    for (;;) {
	if (fread(wave_header->FmtID, 1, 4, fp) != 4) {
	    spDebug(1, NULL, "Can't find fmt chunk\n");
	    return 0;
	}
	head_size += 4;
	
	freadlong32((long *)&wave_header->FmtSize, 1, SP_WAV_NEED_SWAP, fp);
	len = wave_header->FmtSize;
	head_size += 4;
	
	if (strneq("fmt ", wave_header->FmtID, 4))
	    break;

	while (len > 0 && !feof(fp)) {
	    getc(fp);
	    len--;
	    head_size += 1;
	}
    }
    
    if (len < 16) {
	spDebug(1, NULL, "Fmt chunk is too short.\n");
	return 0;
    }
    
    freadshort((short *)&wave_header->wFormatTag, 1, SP_WAV_NEED_SWAP, fp); len -= 2;
    head_size += 2;

    if (check_format == SP_TRUE) {
	switch (wave_header->wFormatTag) {
	  case WAVE_FORMAT_PCM:
	  case WAVE_FORMAT_ALAW:
	  case WAVE_FORMAT_MULAW:
	    break;
	  default:
	    spDebug(1, NULL, "%s format is not supported.\n", spGetWavFormatLabelFromTag(wave_header->wFormatTag));
	    return 0;
	}
    }
    
    freadshort((short *)&wave_header->nChannels, 1, SP_WAV_NEED_SWAP, fp); len -= 2;
    head_size += 2;
    freadlong32((long *)&wave_header->nSamplesPerSec, 1, SP_WAV_NEED_SWAP, fp); len -= 4;
    head_size += 4;
    freadlong32((long *)&wave_header->nAvgBytesPerSec, 1, SP_WAV_NEED_SWAP, fp); len -= 4;
    head_size += 4;
    freadshort((short *)&wave_header->nBlockAlign, 1, SP_WAV_NEED_SWAP, fp); len -= 2;
    head_size += 2;
    freadshort((short *)&wave_header->wBitsPerSample, 1, SP_WAV_NEED_SWAP, fp); len -= 2;
    head_size += 2;

    while (len > 0 && !feof(fp)) {
	getc(fp);
	len--;
	head_size += 1;
    }
    
    for (;;) {
	if (fread(wave_header->DataID, 1, 4, fp) != 4) {
	    spDebug(1, NULL, "Sorry, missing data chunk\n");
	    return 0;
	}
	head_size += 4;

	freadlong32((long *)&wave_header->nDataBytes, 1, SP_WAV_NEED_SWAP, fp);
	len = wave_header->nDataBytes;
	head_size += 4;
	
	if (strneq("data", wave_header->DataID, 4))
	    break;

	while (len > 0 && !feof(fp)) {
	    getc(fp);
	    len--;
	    head_size += 1;
	}
    }

    spDebug(10, NULL, "%s format, %d channel, %d samp/sec\n",
	    spGetWavFormatLabelFromTag(wave_header->wFormatTag), wave_header->nChannels,
	    wave_header->nSamplesPerSec);
    spDebug(10, NULL, "%d byte/sec, %d block align, %d bits/samp, %u data bytes\n",
	    wave_header->nAvgBytesPerSec, wave_header->nBlockAlign,
	    wave_header->wBitsPerSample, wave_header->nDataBytes);
    spDebug(10, NULL, "header size = %d\n", head_size);

    return head_size;
}

long spReadWavHeader(WAVEHEADER *wave_header, FILE *fp)
{
    return readWavHeader(wave_header, fp, SP_TRUE);
}

long spWriteWavHeader(WAVEHEADER wave_header, long length, FILE *fp)
{
    long head_size = 0;

    switch (wave_header.wFormatTag) {
      case WAVE_FORMAT_PCM:
      case WAVE_FORMAT_ALAW:
      case WAVE_FORMAT_MULAW:
	break;
      default:
	spDebug(1, NULL, "%s format is not supported.\n", spGetWavFormatLabelFromTag(wave_header.wFormatTag));
	return 0;
    }
    if (wave_header.nSamplesPerSec <= 0) {
	spDebug(1, NULL, "Invalid sampling frequency: %ld\n", (long)wave_header.nSamplesPerSec);
	return 0;
    }
    if (wave_header.nChannels <= 0) {
	spDebug(1, NULL, "Invalid number of channels: %d\n", wave_header.nChannels);
	return 0;
    }
    if (wave_header.wBitsPerSample < 8) {
	spDebug(1, NULL, "Invalid bits/sample: %d\n", wave_header.wBitsPerSample);
	return 0;
    }
    
    /* seek start of the file */
    fseek(fp, 0L, SEEK_SET);
    
    /* compute parameters */
    wave_header.FmtSize = 16;
    wave_header.nBlockAlign = wave_header.nChannels * (wave_header.wBitsPerSample / 8);
    wave_header.nAvgBytesPerSec = wave_header.nSamplesPerSec * wave_header.nBlockAlign;
    wave_header.nDataBytes = length * wave_header.nChannels * (wave_header.wBitsPerSample / 8);
    wave_header.RiffSize = wave_header.nDataBytes + 36;
    
    fputs("RIFF", fp);
    head_size += 4;
    fwritelong32((long *)&wave_header.RiffSize, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;
    fputs("WAVE", fp);
    head_size += 4;
    fputs("fmt ", fp);
    head_size += 4;
    fwritelong32((long *)&wave_header.FmtSize, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;
    
    fwriteshort((short *)&wave_header.wFormatTag, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 2;
    fwriteshort((short *)&wave_header.nChannels, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 2;
    fwritelong32((long *)&wave_header.nSamplesPerSec, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;
    fwritelong32((long *)&wave_header.nAvgBytesPerSec, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;
    fwriteshort((short *)&wave_header.nBlockAlign, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 2;
    fwriteshort((short *)&wave_header.wBitsPerSample, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 2;
    
    fputs("data", fp);
    head_size += 4;
    fwritelong32((long *)&wave_header.nDataBytes, 1, SP_WAV_NEED_SWAP, fp);
    head_size += 4;

    spDebug(10, NULL, "%s format, %d channel, %d samp/sec\n",
	    spGetWavFormatLabelFromTag(wave_header.wFormatTag), wave_header.nChannels,
	    wave_header.nSamplesPerSec);
    spDebug(10, NULL, "%d byte/sec, %d block align, %d bits/samp, %u data bytes\n",
	    wave_header.nAvgBytesPerSec, wave_header.nBlockAlign,
	    wave_header.wBitsPerSample, wave_header.nDataBytes);
    spDebug(10, NULL, "header size = %ld\n", head_size);

    return head_size;
}

spBool spIsWavFile(char *filename)
{
    FILE *fp;
    WAVEHEADER wave_header;
    spBool flag = SP_FALSE;
    
    if (filename != NULL && (fp = spOpenFile(filename, "rb")) != NULL) {
	if (spReadWavHeader(&wave_header, fp) > 0) {
	    flag = SP_TRUE;
	}
	spCloseFile(fp);
	spDebug(20, "spIsWavFile", "%s: flag = %d\n", filename, flag);
    }

    return flag;
}

static void updateWavInfo(WAVEHEADER *wave_header, spWaveInfo *wave_info)
{
    strcpy(wave_info->file_type, SP_WAVE_WAV_ID);
    strcpy(wave_info->file_desc, spGetWavFormatLabel(*wave_header));
    strcpy(wave_info->file_filter, "*.wav");

    return;
}

spBool spReadWavInfo(spWaveInfo *wave_info, FILE *fp)
{
    WAVEHEADER wave_header;
    long header_size;

    if (wave_info == NULL || fp == NULL) return SP_FALSE;

    if ((header_size = spReadWavHeader(&wave_header, fp)) <= 0) {
	return SP_FALSE;
    }

    updateWavInfo(&wave_header, wave_info);
    
    wave_info->header_size = header_size;
    wave_info->num_channel = wave_header.nChannels;
    wave_info->samp_bit = wave_header.wBitsPerSample;
    wave_info->samp_rate = (double)wave_header.nSamplesPerSec;
    wave_info->bit_rate = wave_header.nAvgBytesPerSec * 8;
    wave_info->length = wave_header.nDataBytes
	/ (wave_header.nChannels * wave_header.wBitsPerSample / 8);
    
    return SP_TRUE;
}

spBool spWriteWavInfo(spWaveInfo *wave_info, FILE *fp)
{
    WAVEHEADER wave_header;
    long header_size;

    if (wave_info == NULL || fp == NULL) return SP_FALSE;

    /*wave_header.wFormatTag = WAVE_FORMAT_PCM;*/
    wave_header.wFormatTag = spGetWavFormatTag(wave_info->file_desc);
    wave_header.nChannels = wave_info->num_channel;
    wave_header.wBitsPerSample = wave_info->samp_bit;
    wave_header.nSamplesPerSec = (DWORD)spRound(wave_info->samp_rate);
    
    if ((header_size = spWriteWavHeader(wave_header, wave_info->length, fp)) <= 0) {
	return SP_FALSE;
    }
    updateWavInfo(&wave_header, wave_info);

    wave_info->header_size = header_size;

    return SP_TRUE;
}

long _spReadWavData(spWaveInfo *wave_info, char *data, long length, FILE *fp)
{
    long len;
    
    if (wave_info == NULL || fp == NULL) return -1;

    if (wave_info->samp_bit == 16) {
	len = freadshort((short *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 32) {
	len = freadlong32((long *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 24) {
	len = freadlong24((long *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 8) {
	if (strcaseeq(wave_info->file_desc, WAVE_FORMAT_ALAW_STRING)) {
	    len = freadalaw((short *)data, length, fp);
	} else if (strcaseeq(wave_info->file_desc, WAVE_FORMAT_MULAW_STRING)) {
	    len = freadulaw((short *)data, length, fp);
	} else {
	    len = freadbyte((short *)data, length, fp);
	}
    } else {
	return -1;
    }
    
    return len;
}

long _spWriteWavData(spWaveInfo *wave_info, char *data, long length, FILE *fp)
{
    long len;
    
    if (wave_info == NULL || fp == NULL) return -1;

    if (wave_info->samp_bit == 16) {
	len = fwriteshort((short *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 32) {
	len = fwritelong32((long *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 24) {
	len = fwritelong24((long *)data, length, SP_WAV_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 8) {
	if (strcaseeq(wave_info->file_desc, WAVE_FORMAT_ALAW_STRING)) {
	    len = fwritealaw((short *)data, length, fp);
	} else if (strcaseeq(wave_info->file_desc, WAVE_FORMAT_MULAW_STRING)) {
	    len = fwriteulaw((short *)data, length, fp);
	} else {
	    len = fwritebyte((short *)data, length, fp);
	}
    } else {
	return -1;
    }
    
    return len;
}

unsigned long spGetWavSongInfoMask(void)
{
    unsigned long info_mask = SP_SONG_NO_INFO;

    info_mask |= SP_SONG_TITLE_MASK;
    info_mask |= SP_SONG_ARTIST_MASK;
    info_mask |= SP_SONG_COMMENT_MASK;
    info_mask |= SP_SONG_GENRE_MASK;
    info_mask |= SP_SONG_RELEASE_MASK;
    info_mask |= SP_SONG_COPYRIGHT_MASK;
    info_mask |= SP_SONG_ENGINEER_MASK;
    info_mask |= SP_SONG_SOURCE_MASK;
    info_mask |= SP_SONG_SOFTWARE_MASK;
    info_mask |= SP_SONG_SUBJECT_MASK;
    
    return info_mask;
}

long readTextInfo(long info_size, char *info_text,
		  unsigned long info_mask, unsigned long *total_mask, FILE *fp)
{
    int len;
    char buf[1024];
    
    if ((info_size = fread(buf, 1, info_size, fp)) > 0) {
	len = MIN(info_size, SP_SONG_INFO_SIZE - 1);
	strncpy(info_text, buf, len);
	info_text[len] = NUL;

	spConvertKanjiToLocaleCode((unsigned char *)info_text, info_size, SP_KANJI_CODE_SJIS);
    
	*total_mask |= info_mask;
    }
    
    return info_size;
}

spBool spGetWavSongInfo(spSongInfo *song_info, FILE *fp)
{
    long offset;
    long list_size = 0;
    long chunk_size = 0;
    long info_size;
    char id[8];
    
    if (song_info == NULL || fp == NULL) return SP_FALSE;

    if ((offset = ftell(fp)) <= 0) {
	WAVEHEADER wave_header;
	
	if (readWavHeader(&wave_header, fp, SP_FALSE) <= 0
	    || fseek(fp, wave_header.nDataBytes, SEEK_CUR) < 0) {
	    return SP_FALSE;
	}
    }
    
    for (;;) {
	chunk_size = 0;
	if (fread(id, 1, 4, fp) != 4) {
	    spDebug(10, "spGetWavSongInfo", "Can't find LIST chunk.\n");
	    return SP_FALSE;
	}

	while (!isalpha(id[0])) {
	    spDebug(10, "spGetWavSongInfo", "id[0] is not alphabet.\n");
	    id[0] = id[1];
	    id[1] = id[2];
	    id[2] = id[3];
	    if (fread(&id[3], 1, 1, fp) != 1) {
		spDebug(10, "spGetWavSongInfo", "Can't find LIST chunk.\n");
		return SP_FALSE;
	    }
	}

	if (freadlong32((long *)&chunk_size, 1, SP_WAV_NEED_SWAP, fp) != 1) {
	    spDebug(10, "spGetWavSongInfo", "Can't find LIST chunk.\n");
	    return SP_FALSE;
	}
	
	spDebug(10, "spGetWavSongInfo", "chunk id: %c%c%c%c\n", id[0], id[1], id[2], id[3]);
	spDebug(10, "spGetWavSongInfo", "chunk_size = %ld\n", chunk_size);
	
	if (strneq("LIST", id, 4)) {
	    break;
	}

	fseek(fp, chunk_size, SEEK_CUR);
    }
    
    if (fread(id, 1, 4, fp) != 4 ||
	!strneq("INFO", id, 4)) {
	spDebug(10, "spGetWavSongInfo", "Can't find INFO chunk.\n");
	return SP_FALSE;
    }
    list_size += 4;

    spDebug(10, "spGetWavSongInfo", "read INFO chunk done\n");

    memset((char *)song_info, 0, sizeof(spSongInfo));
    song_info->info_mask = SP_SONG_NO_INFO;
    song_info->track = 1;

    while (list_size < chunk_size) {
	if (fread(id, 1, 4, fp) != 4) {
	    break;
	}
	list_size += 4;

	while (!isalpha(id[0])) {
	    spDebug(10, "spGetWavSongInfo", "id[0] is not alphabet.\n");
	    id[0] = id[1];
	    id[1] = id[2];
	    id[2] = id[3];
	    if (fread(&id[3], 1, 1, fp) != 1) {
		break;
	    }
	    list_size += 1;
	}

	spDebug(10, "spGetWavSongInfo", "chunk id: %c%c%c%c\n", id[0], id[1], id[2], id[3]);

	info_size = 0;
	freadlong32((long *)&info_size, 1, SP_WAV_NEED_SWAP, fp);
	list_size += 4;

	spDebug(10, "spGetWavSongInfo", "info_size = %ld\n", info_size);

	if (strneq("INAM", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->title,
				      SP_SONG_TITLE_MASK, &song_info->info_mask, fp);
	} else if (strneq("IART", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->artist,
				      SP_SONG_ARTIST_MASK, &song_info->info_mask, fp);
	} else if (strneq("ICMT", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->comment,
				      SP_SONG_COMMENT_MASK, &song_info->info_mask, fp);
	} else if (strneq("IGNR", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->genre,
				      SP_SONG_GENRE_MASK, &song_info->info_mask, fp);
	} else if (strneq("ICRD", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->release,
				      SP_SONG_RELEASE_MASK, &song_info->info_mask, fp);
	} else if (strneq("ICOP", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->copyright,
				      SP_SONG_COPYRIGHT_MASK, &song_info->info_mask, fp);
	} else if (strneq("IENG", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->engineer,
				      SP_SONG_ENGINEER_MASK, &song_info->info_mask, fp);
	} else if (strneq("ISRC", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->source,
				      SP_SONG_SOURCE_MASK, &song_info->info_mask, fp);
	} else if (strneq("ISFT", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->software,
				      SP_SONG_SOFTWARE_MASK, &song_info->info_mask, fp);
	} else if (strneq("ISBJ", id, 4)) {
	    list_size += readTextInfo(info_size, song_info->subject,
				      SP_SONG_SUBJECT_MASK, &song_info->info_mask, fp);
	} else {
	    fseek(fp, info_size, SEEK_CUR);
	}
    }
    
    spDebug(10, "spGetWavSongInfo", "done\n");
    
    return SP_TRUE;
}

spBool spReadWavSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp)
{
    long offset;
    
    if (wave_info == NULL || song_info == NULL || fp == NULL) return SP_FALSE;
    if (wave_info->header_size <= 0) return SP_FALSE;
    
    offset = (long)wave_info->header_size +
	wave_info->length * (long)wave_info->num_channel * (long)(wave_info->samp_bit / 8);
    if (fseek(fp, offset, SEEK_SET) < 0) {
	return SP_FALSE;
    }

    spDebug(10, "spReadWavSongInfo", "fseek done: %ld\n", offset);

    spGetWavSongInfo(song_info, fp);
    
    return SP_TRUE;
}

static long writeTextInfo(char *id, char *text, FILE *fp)
{
    long info_size;
    char buf[SP_SONG_INFO_SIZE];

    strcpy(buf, text);
    spConvertKanjiFromLocaleCode((unsigned char *)buf, SP_SONG_INFO_SIZE, SP_KANJI_CODE_SJIS);
    info_size = strlen(buf) + 1;
    
    if (info_size <= 1) return 0;
    
    fputs(id, fp);
    fwritelong32(&info_size, 1, SP_WAV_NEED_SWAP, fp);
    fwrite(buf, 1, info_size, fp);

    return (8 + info_size);
}

spBool spAddWavSongInfo(spSongInfo *song_info, FILE *fp)
{
    long offset;
    long chunk_size;

    if (song_info == NULL || fp == NULL 
	|| song_info->info_mask == SP_SONG_NO_INFO) return SP_FALSE;
    
    if ((offset = ftell(fp)) <= 0) {
	fseek(fp, 0, SEEK_END);
	offset = ftell(fp);
    }

    fputs("LIST", fp);
    chunk_size = 4;	/* write dummy size */
    fwritelong32(&chunk_size, 1, SP_WAV_NEED_SWAP, fp);
    fputs("INFO", fp);

    if (song_info->info_mask & SP_SONG_TITLE_MASK) {
	chunk_size += writeTextInfo("INAM", song_info->title, fp);
    }
    if (song_info->info_mask & SP_SONG_ARTIST_MASK) {
	chunk_size += writeTextInfo("IART", song_info->artist, fp);
    }
    if (song_info->info_mask & SP_SONG_COMMENT_MASK) {
	chunk_size += writeTextInfo("ICMT", song_info->comment, fp);
    }
    if (song_info->info_mask & SP_SONG_GENRE_MASK) {
	chunk_size += writeTextInfo("IGNR", song_info->genre, fp);
    }
    if (song_info->info_mask & SP_SONG_RELEASE_MASK) {
	chunk_size += writeTextInfo("ICRD", song_info->release, fp);
    }
    if (song_info->info_mask & SP_SONG_COPYRIGHT_MASK) {
	chunk_size += writeTextInfo("ICOP", song_info->copyright, fp);
    }
    if (song_info->info_mask & SP_SONG_ENGINEER_MASK) {
	chunk_size += writeTextInfo("IENG", song_info->engineer, fp);
    }
    if (song_info->info_mask & SP_SONG_SOURCE_MASK) {
	chunk_size += writeTextInfo("ISRC", song_info->source, fp);
    }
    if (song_info->info_mask & SP_SONG_SOFTWARE_MASK) {
	chunk_size += writeTextInfo("ISFT", song_info->software, fp);
    }
    if (song_info->info_mask & SP_SONG_SUBJECT_MASK) {
	chunk_size += writeTextInfo("ISBJ", song_info->subject, fp);
    }
    
    if (chunk_size > 4 && fseek(fp, offset, SEEK_SET) >= 0) {
	/* write real chunk size */
	fputs("LIST", fp);
	fwritelong32(&chunk_size, 1, SP_WAV_NEED_SWAP, fp);
    }

    /* update RIFF chunk size */
    fseek(fp, 4, SEEK_SET);
    chunk_size += (offset + 8);
    fwritelong32(&chunk_size, 1, SP_WAV_NEED_SWAP, fp);
    
    fseek(fp, 0, SEEK_END);
    
    return SP_TRUE;
}

spBool spWriteWavSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp)
{
    long offset;
    
    if (wave_info == NULL || song_info == NULL || fp == NULL) return SP_FALSE;
    if (wave_info->header_size <= 0 || wave_info->length <= 0) return SP_FALSE;

    offset = (long)wave_info->header_size
	+ wave_info->length * (long)wave_info->num_channel * (long)(wave_info->samp_bit / 8);
    if (fseek(fp, offset, SEEK_SET) < 0) {
	return SP_FALSE;
    }

    return spAddWavSongInfo(song_info, fp);
}


