/*
 *	spAudio_SGI.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(SGI)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <device.h>
#include <sys/types.h>
#include <sys/dir.h>

spBool spInitAudioArch(spAudio audio)
{
    if ((audio->audio_config = ALnewconfig()) == NULL) {
	return SP_FALSE;
    }
    
    ALsetsampfmt(audio->audio_config, AL_SAMPFMT_TWOSCOMP);
    ALsetwidth(audio->audio_config, AL_SAMPLE_16);

    audio->samp_byte = sizeof(short);
    audio->duplex_flag = 1;
    
    return SP_TRUE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    long buf[2];
    
    buf[0] = AL_CHANNEL_MODE;
    buf[1] = audio->num_channel;
    ALsetparams(AL_DEFAULT_DEVICE, buf, 2);
    
    return SP_TRUE;
}

/* size is in bytes */
spBool spSetAudioBufferSizeArch(spAudio audio)
{
    ALsetqueuesize(audio->audio_config, audio->buffer_size / 2);
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
    long buf[2];
    
    buf[0] = AL_INPUT_RATE;
    buf[1] = (long)audio->samp_rate;
    ALsetparams(AL_DEFAULT_DEVICE, buf, 2);
    
    if ((audio->input_port =
	 ALopenport("audio input", "r", audio->audio_config)) == NULL) {
	spMessage("Open audio device failed.\n");
	return SP_FALSE;
    } else {
	return SP_TRUE;
    }
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
    long buf[2];
    
    buf[0] = AL_OUTPUT_RATE;
    buf[1] = (long)audio->samp_rate;
    ALsetparams(AL_DEFAULT_DEVICE, buf, 2);
    
    if ((audio->output_port =
	 ALopenport("audio output", "w", audio->audio_config)) == NULL) {
	spMessage("Open audio device failed.\n");
	return SP_FALSE;
    } else {
	return SP_TRUE;
    }
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    int flag = 0;

    if (audio->output_port != NULL) {
	if (ALcloseport(audio->output_port) < 0) {
	    flag = -1;
	}
    }
    if (audio->input_port != NULL) {
	spSyncAudioArch(audio);
	
	if (ALcloseport(audio->input_port) < 0) {
	    flag = -1;
	}
    }

    return (flag == -1 ? SP_FALSE : SP_TRUE);
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    long filled_length;
    
    if (audio->input_port == NULL) return -1;

    if (audio->block_mode == SP_AUDIO_NONBLOCKING) {
	filled_length = ALgetfilled(audio->input_port);
	if (filled_length > 0) {
	    length = filled_length;
	} else {
	    length = MIN(length, audio->buffer_size / audio->samp_byte);
	}
    }
    
    return (long)ALreadsamps(audio->input_port, data, length);
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    if (audio->output_port == NULL) return -1;
    
    return (long)ALwritesamps(audio->output_port, data, length);
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    long filled_length;
    
    if (audio->output_port == NULL) return SP_FALSE;

    if (position != NULL) {
	filled_length = ALgetfilled(audio->output_port);
    
	*position = MAX((audio->output_total - filled_length) / audio->num_channel, 0);
    }
    
    return SP_TRUE;
}

spBool spStopAudioArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spSyncAudioArch(spAudio audio)
{
    if (audio->input_port != NULL) {
	while (ALgetfilled(audio->input_port) > 0) {
#if 1
	    sginap(1);
#endif
	}
    }

    return SP_TRUE;
}

spBool spFreeAudioArch(spAudio audio)
{
    return SP_TRUE;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
