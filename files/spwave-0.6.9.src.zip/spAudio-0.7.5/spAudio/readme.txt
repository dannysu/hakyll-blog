
	spAudio - Audio I/O Library 

			Last modified: <2002-04-01 13:04:06 hideki>


Introduction
------------

This library is spAudio, audio I/O library which is a part of spLibs. This has
following features.
 - Support for Windows, Macintosh, and Linux.
 - Support for I/O functions of WAV and AIFF files.
 - Support for plug-ins to expand file I/O operations.
 - Support for audio I/O functions (also support for full duplex and real time I/O)
 

Install
-------

To compile this library on UNIX (including Linux) or Cygwin, go to the
spAudio top directory, and make a symbolic link from `include' directory
and `lib' directory of spBase (e.g. /usr/local/include and /usr/local/lib)
like this:

 % cd spAudio-X.X.X
 % ln -s /usr/local/include
 % ln -s /usr/local/lib

If your platform is supported by the configuration file of spBase, you can
build the library by typing in the source directory:

 % cd spAudio
 % make

To install this library to your system directory (e.g. /usr/local), login as
root and type:

 # make SPDESTROOT=/usr/local install
 # make SPDESTROOT=/usr/local install.hdr

If you don't want to make a symbolic link from spBase directory, you can
compile and install by adding TOP=/usr/local option (/usr/local is top
directory of spBase) to the above command line of `make' such as:
 
 % cd spAudio-X.X.X
 % cd spAudio
 % make TOP=/usr/local
 % su
 # make TOP=/usr/local SPDESTROOT=/usr/local install
 # make TOP=/usr/local SPDESTROOT=/usr/local install.hdr


Supported Platforms
-------------------

spAudio is known to work at least on Linux(Redhat 6.2, Vine 2.1), Microsoft
Windows98/2000/XP, Cygwin, Mac OS 9.2/10.1. Although the source code contains
audio I/O functions for SGI, I cannot test it because I don't have a SGI
workstation currently.


BUGS
----

The plug-ins which are compiled on Cygwin can not be loaded (loading the
plug-ins which are compiled by Visual C++ works well). Thus, you cannot
compile plug-ins on Cygwin environment currently.


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

License
-------

Please see LICENSE.txt.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
