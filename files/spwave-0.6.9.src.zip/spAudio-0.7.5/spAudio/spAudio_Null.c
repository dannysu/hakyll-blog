/*
 *	spAudio_Null.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spAudioP.h>

#if !defined(SP_SUPPORT_AUDIO)

spBool spInitAudioArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioBufferSizeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    return SP_TRUE;
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    return length;
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    return length;
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    return SP_TRUE;
}

spBool spStopAudioArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSyncAudioArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spFreeAudioArch(spAudio audio)
{
    return SP_TRUE;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
