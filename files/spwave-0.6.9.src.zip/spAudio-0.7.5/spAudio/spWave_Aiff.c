/*
 *	spWave_Wav.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spKanji.h>

#include <sp/spWave_Aiff.h>

#define AIFF_FILE_DESC_OFFSET 5

static void ConvertToIeeeExtended(double num, char* bytes);
static double ConvertFromIeeeExtended(unsigned char* bytes);

static char *compression_id_list[] = {"NONE", "ULAW", "ALAW", NULL};
static char *compression_name_list[] = {"\016not compressed",
					    "\022ITU-T G.711 mu-law",
					    "\021ITU-T G.711 A-law", NULL};

static long readChunkId(FILE *fp, char *id, long *chunk_size)
{
    long nread;
    long size;
    
    if (fread(id, 1, 4, fp) != 4) {
	spDebug(10, "readChunkId", "Can't read chunk ID.\n");
	return 0;
    }
    nread = 4;
    
    if (freadlong32(&size, 1, SP_AIFF_NEED_SWAP, fp) != 1) {
	spDebug(10, "readChunkId", "Can't read chunk size.\n");
	return 0;
    }
    nread += 4;
    
    if (chunk_size != NULL) {
	*chunk_size = size;
    }

    return nread;
}

static long searchAiffChunk(FILE *fp, long *total_size, spBool *aifc_flag)
{
    char id[4];
    long nread;
    long size;

    if (fp == NULL) return 0;

    if ((nread = readChunkId(fp, id, &size)) <= 0 || !strneq("FORM", id, 4)) {
	spDebug(10, "searchAiffChunk", "Can't find FORM chunk.\n");
	return 0;
    }
    /*nread += 4;*/
    spDebug(10, "searchAiffChunk", "total size: %ld\n", size);
    
    if (fread(id, 1, 4, fp) != 4) {
	spDebug(10, "readChunkId", "Can't read AIFF chunk ID.\n");
	return 0;
    }
    nread += 4;

    if (strneq("AIFC", id, 4)) {
	if (aifc_flag != NULL) {
	    *aifc_flag = SP_TRUE;
	}
    } else if (!strneq("AIFF", id, 4)) {
	spDebug(10, "readChunkId", "Can't find AIFF chunk ID.\n");
	return 0;
    }

    if (total_size != NULL) {
	*total_size = size;
    }
    
    return nread;
}

spBool spIsAiffFile(char *filename)
{
    FILE *fp;
    spBool flag = SP_FALSE;
    
    if (filename != NULL && (fp = spOpenFile(filename, "rb")) != NULL) {
	if (searchAiffChunk(fp, NULL, NULL) > 0) {
	    flag = SP_TRUE;
	}
	spCloseFile(fp);
    }

    return flag;
}

static long skipData(FILE *fp, long data_size)
{
    long len;
    long nread = 0;

    if (fseek(fp, data_size, SEEK_CUR) >= 0) {
	nread = data_size;
    } else {
	len = data_size;
	while (len > 0 && !feof(fp)) {
	    getc(fp);
	    len--;
	    nread += 1;
	}
    }

    return nread;
}

static void updateAiffInfo(spWaveInfo *wave_info, int compression_type)
{
    if (compression_type >= 0) {
	strcpy(wave_info->file_type, SP_WAVE_AIFC_ID);
	strcpy(wave_info->file_desc, "AIFC ");
	strcat(wave_info->file_desc, (compression_name_list[compression_type] + 1));
	strcpy(wave_info->file_filter, "*.afc");
    } else {
	strcpy(wave_info->file_type, SP_WAVE_AIFF_ID);
	strcpy(wave_info->file_desc, "AIFF");
	strcpy(wave_info->file_filter, "*.aif");
    }

    return;
}

static spBool readAiffInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp,
			   spBool seek_data_head)
{
    spBool unknown_chunk;
    spBool aifc_flag;
    int i;
    char id[4];
    char buf[16];
    char cvalue;
    short svalue;
    long lvalue;
    long nread;
    long string_size;
    long total_size;
    long chunk_size;
    long current_size;
    long header_size = 0;
    short num_channel = 0;
    short samp_bit = 0;
    double samp_rate = 0.0;
    long data_size = 0;
    long data_length = 0;
    int compression_type = -1;

    if (fp == NULL) {
	return SP_FALSE;
    }

    fseek(fp, 0, SEEK_SET);
    
    if ((nread = searchAiffChunk(fp, &total_size, &aifc_flag)) <= 0) {
	return SP_FALSE;
    }
    current_size = nread;

    if (song_info != NULL) {
	memset((char *)song_info, 0, sizeof(spSongInfo));
    }

    for (;;) {
	if ((nread = readChunkId(fp, id, &chunk_size)) <= 0 || chunk_size <= 0) {
	    break;
	}
	current_size += nread;
	unknown_chunk = SP_FALSE;
	
	spDebug(10, "readAiffInfo", "nread = %ld, chunk_size = %ld, id = %c%c%c%c\n",
		nread, chunk_size, id[0], id[1], id[2], id[3]);
	
	if (strneq("COMM", id, 4)) {
	    if (chunk_size < 18) {
		spDebug(10, "readAiffInfo", "wrong COMM chunk\n");
		return SP_FALSE;
	    }
	    spDebug(10, "readAiffInfo", "reading COMM chunk\n");
	    
	    if ((nread = freadshort(&num_channel, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += 2;
	    spDebug(10, "readAiffInfo", "num_channel = %d\n", num_channel);
	    
	    if ((nread = freadlong32(&data_length, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += 4;
	    spDebug(10, "readAiffInfo", "data_length = %ld\n", data_length);
	    
	    if ((nread = freadshort(&samp_bit, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += 2;
	    spDebug(10, "readAiffInfo", "samp_bit = %d\n", samp_bit);
	    
	    if ((nread = fread(buf, 1, 10, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += nread;
	    samp_rate = ConvertFromIeeeExtended((unsigned char *)buf);
	    spDebug(10, "readAiffInfo", "samp_rate = %f\n", samp_rate);

	    if (chunk_size > 18) {
		if (aifc_flag == SP_TRUE) {
		    if ((nread = fread(id, 1, 4, fp)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		    
		    for (i = 0; compression_id_list[i] != NULL; i++) {
			if (strneq(compression_id_list[i], id, 4)) {
			    break;
			}
		    }
		    if (compression_id_list[i] == NULL) {
			/* unsupported compression format */
			spDebug(10, "readAiffInfo", "unsupported compression format\n");
			return SP_FALSE;
		    }
		    compression_type = i;
		    spDebug(10, "readAiffInfo", "compression_type = %d\n", compression_type);

		    if ((nread = fread(&cvalue, 1, 1, fp)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		    if ((nread = skipData(fp, cvalue)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		    spDebug(10, "readAiffInfo", "compression name size = %d\n", cvalue);
		    if (!(cvalue % 2)) {	/* cvalue is even */
			getc(fp);
			current_size++;
		    }
		} else {
		    if ((nread = skipData(fp, chunk_size - 18)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		}
	    }
	} else if (strneq("FVER", id, 4)) { /* for AIFC */
	    spDebug(10, "readAiffInfo", "reading FVER chunk: chunk_size = %ld\n", chunk_size);
	    /* do nothing */
	    unknown_chunk = SP_TRUE;
	} else if (strneq("SSND", id, 4)) {
	    long data_offset;
	    long block_size;
	    
	    spDebug(10, "readAiffInfo", "reading SSND chunk: chunk_size = %ld\n", chunk_size);
	    
	    if ((nread = freadlong32(&data_offset, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += 4;
	    spDebug(10, "readAiffInfo", "data_offset = %ld\n", data_offset);

	    if ((nread = freadlong32(&block_size, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		return SP_FALSE;
	    }
	    current_size += 4;
	    spDebug(10, "readAiffInfo", "block_size = %ld\n", block_size);

	    if (data_offset > 0) {
		if ((nread = skipData(fp, data_offset)) <= 0) {
		    return SP_FALSE;
		}
		current_size += nread;
	    }

	    header_size = current_size;
	    data_size = chunk_size - data_offset - 8;
	    spDebug(10, "readAiffInfo", "data_size = %ld, chunk_size = %ld\n", data_size, chunk_size);

	    if ((nread = skipData(fp, data_size)) <= 0) {
		return SP_FALSE;
	    }
	    spDebug(10, "readAiffInfo", "skipped data size = %ld\n", nread);
	    current_size += nread;
	} else if (song_info != NULL) {
	    char *string = NULL;
	    char song_buf[SP_SONG_INFO_SIZE];
	    
	    spDebug(10, "readAiffInfo", "reading song info: chunk_size = %ld\n", chunk_size);

	    string_size = chunk_size;
	    if (strneq("COMT", id, 4)) { /* comment chunk */
		/* read time stamp */
		if ((nread = freadlong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		    return SP_FALSE;
		}
		current_size += 4;

		/* read marker ID */
		if ((nread = freadshort(&svalue, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
		    return SP_FALSE;
		}
		current_size += 2;

		if (svalue == 0) {
		    /* read string size */
		    if ((nread = freadshort(&svalue, 1, SP_AIFF_NEED_SWAP, fp)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += 2;
		    string_size = svalue + (svalue % 2);
		
		    /* This chunk length must be even. */
		    song_info->info_mask |= SP_SONG_COMMENT_MASK;
		    string = song_info->comment;
		} else {
		    if ((nread = skipData(fp, chunk_size - 6)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		}
	    } else {
		if (strneq("ANNO", id, 4)) { /* old comment chunk */
		    song_info->info_mask |= SP_SONG_COMMENT_MASK;
		    string = song_info->comment;
		} else if (strneq("AUTH", id, 4)) {
		    song_info->info_mask |= SP_SONG_ARTIST_MASK;
		    string = song_info->artist;
		} else if (strneq("NAME", id, 4)) {
		    song_info->info_mask |= SP_SONG_TITLE_MASK;
		    string = song_info->title;
		} else if (strneq("(c) ", id, 4)) {
		    song_info->info_mask |= SP_SONG_COPYRIGHT_MASK;
		    string = song_info->copyright;
		} else {
		    unknown_chunk = SP_TRUE;
		}
	    }
		
	    if (string != NULL) {
		if ((nread = fread(song_buf, 1, MIN(string_size, sizeof(song_buf)-1), fp)) <= 0) {
		    return SP_FALSE;
		}
		current_size += nread;
		
		song_buf[nread] = NUL;
		strcpy(string, song_buf);
		spConvertKanjiToLocaleCode((unsigned char *)string, SP_SONG_INFO_SIZE,
					   SP_KANJI_CODE_SJIS);
		
		if (nread < string_size) {
		    if ((nread = skipData(fp, string_size - nread)) <= 0) {
			return SP_FALSE;
		    }
		    current_size += nread;
		}
	    }
	} else {
	    unknown_chunk = SP_TRUE;
	}

	if (unknown_chunk == SP_TRUE) {
	    spDebug(10, "readAiffInfo", "skip unknown chunk\n");
	    if ((nread = skipData(fp, chunk_size)) <= 0) {
		break;
	    }
	    current_size += nread;
	}

	if (chunk_size % 2) {	/* chunk_size is odd */
	    int c;
	    
	    spDebug(10, "readAiffInfo", "chunk size is odd\n");
	    c = getc(fp);
	    current_size++;
	    if (c != 0) {	/* not zero padding: wrong AIFF file */
		ungetc(c, fp);
		current_size--;
	    }
	}
    }

    spDebug(10, "readAiffInfo",
	    "num_channel = %d, samp_bit = %d, data_length = %ld, data_size = %ld, header_size = %ld\n",
	    num_channel, samp_bit, data_length, data_size, header_size);
    
    if (num_channel <= 0 || samp_bit <= 0  || data_length <= 0	/* maybe can't find COMM chunk */
	|| data_size <= 0 || header_size <= 0) {		/* maybe can't find SSND chunk */
	return SP_FALSE;
    }

    if (wave_info != NULL) {
	updateAiffInfo(wave_info, compression_type);
	
	wave_info->header_size = header_size;
	wave_info->num_channel = num_channel;
	wave_info->samp_bit = samp_bit;
	wave_info->samp_rate = samp_rate;
	wave_info->bit_rate = (long)spRound(8.0 * (double)data_size * samp_rate / (double)data_length);
	wave_info->length = data_length;
    }

    if (seek_data_head == SP_TRUE) {
	fseek(fp, header_size, SEEK_SET);
    }
    
    return SP_TRUE;
}

spBool spReadAiffInfo(spWaveInfo *wave_info, FILE *fp)
{
    return readAiffInfo(wave_info, NULL, fp, SP_TRUE);
}

static spBool writeAiffInfo(spWaveInfo *wave_info, FILE *fp)
{
    int i;
    long comm_chunk_size;
    long chunk_size;
    long data_size;
    short svalue;
    long lvalue;
    char buf[10];
    char *compression_id = NULL, *compression_name = NULL;
    char compression_name_len = 0;
    int compression_name_padding = 0;
    int compression_type = -1;
    
    /* seek start of the file */
    fseek(fp, 0L, SEEK_SET);

    spDebug(10, "writeAiffInfo", "file_type = %s, length = %ld\n",
	    wave_info->file_type, wave_info->length);
    
    if (streq(wave_info->file_type, SP_WAVE_AIFC_ID)) {
	compression_type = 0;
	if (strlen(wave_info->file_desc) >= 6) {
	    char *name = wave_info->file_desc + 5;
	    spDebug(10, "writeAiffInfo", "file_desc = %s\n", name);
	    for (i = 0; compression_name_list[i] != NULL; i++) {
		if (streq(compression_name_list[i] + 1, name)) {
		    compression_type = i;
		    break;
		}
	    }
	} 
    }
    spDebug(10, "writeAiffInfo", "compression_type = %d\n", compression_type);
    
    comm_chunk_size = 18;
    data_size = wave_info->length *
	(long)wave_info->num_channel * (long)(wave_info->samp_bit / 8);
    
    chunk_size = 8;		/* COMM header */
    chunk_size += 4;		/* including 'AIFC' */
    chunk_size += 8 + 8; 	/* SSND header & SSND chunk */
    chunk_size += data_size;	/* SSND data */
    
    fputs("FORM", fp);
    if (compression_type >= 0) {
	compression_id = compression_id_list[compression_type];
	compression_name = compression_name_list[compression_type];
	
	compression_name_len = strlen(compression_name);
	if (compression_name_len % 2) {	/* length of compression_name is odd */
	    compression_name_padding = 1;
	}
	/* size of compression information in COMM chunk */
	comm_chunk_size += 4 + compression_name_len + compression_name_padding;
	
	chunk_size += 12;	/* FVER chunk */
	chunk_size += comm_chunk_size;
	
	fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp);
	fputs("AIFC", fp);
    } else {
	chunk_size += comm_chunk_size;
	
	fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp);
	fputs("AIFF", fp);
    }
    wave_info->header_size = 8 + chunk_size - data_size;
    spDebug(10, "writeAiffInfo", "header_size = %ld\n", wave_info->header_size);
    
    /* write COMM header */
    fputs("COMM", fp);
    fwritelong32(&comm_chunk_size, 1, SP_AIFF_NEED_SWAP, fp);

    /* number of channels */
    svalue = wave_info->num_channel;
    fwriteshort(&svalue, 1, SP_AIFF_NEED_SWAP, fp);
    
    /* number of samples */
    lvalue = wave_info->length;
    fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp);
    
    /* bits per sample */
    svalue = wave_info->samp_bit;
    fwriteshort(&svalue, 1, SP_AIFF_NEED_SWAP, fp);
    
    /* sample rate */
    ConvertToIeeeExtended(wave_info->samp_rate, buf);
    fwrite(buf, 1, 10, fp);
    
    if (compression_type >= 0) {
	char cvalue;
	
	fputs(compression_id, fp);
	fwrite(compression_name, 1, compression_name_len, fp);

	if (compression_name_padding) {
	    cvalue = 0;
	    fwrite(&cvalue, 1, 1, fp); 	/* zero padding */
	}
	
	/* write FVER chunk */
	fputs("FVER", fp);
	lvalue = 4;
	fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp);
	lvalue = 0xA2805140;	/* AIFC version 1 */
	fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp);
    }
    updateAiffInfo(wave_info, compression_type);
    
    /* write SSND chunk */
    fputs("SSND", fp);
    chunk_size = data_size + 8;
    fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp);
    lvalue = 0;
    fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp);	/* offset */
    fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp);	/* block size */
    
    spDebug(10, "writeAiffInfo", "done\n");
    
    return SP_TRUE;
}

spBool spWriteAiffInfo(spWaveInfo *wave_info, FILE *fp)
{
    return writeAiffInfo(wave_info, fp);
}

long _spReadAiffData(spWaveInfo *wave_info, char *data, long length, FILE *fp)
{
    long len;
    
    if (wave_info == NULL || fp == NULL) return -1;

    if (wave_info->samp_bit == 16) {
	len = freadshort((short *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 32) {
	len = freadlong32((long *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 24) {
	len = freadlong24((long *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 8) {
	if (strcaseeq(wave_info->file_type, SP_WAVE_AIFC_ID)) {
	    if (strcaseeq(wave_info->file_desc + AIFF_FILE_DESC_OFFSET,
			  (compression_name_list[1] + 1))) {
		len = freadulaw((short *)data, length, fp);
	    } else if (strcaseeq(wave_info->file_desc + AIFF_FILE_DESC_OFFSET,
				 (compression_name_list[2] + 1))) {
		len = freadalaw((short *)data, length, fp);
	    } else {
		len = freadsbyte((short *)data, length, fp);
	    }
	} else {
	    len = freadsbyte((short *)data, length, fp);
	}
    } else {
	return -1;
    }
    
    return len;
}

long _spWriteAiffData(spWaveInfo *wave_info, char *data, long length, FILE *fp)
{
    long len;
    
    if (wave_info == NULL || fp == NULL) return -1;

    if (wave_info->samp_bit == 16) {
	len = fwriteshort((short *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 32) {
	len = fwritelong32((long *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 24) {
	len = fwritelong24((long *)data, length, SP_AIFF_NEED_SWAP, fp);
    } else if (wave_info->samp_bit == 8) {
	if (strcaseeq(wave_info->file_type, SP_WAVE_AIFC_ID)) {
	    if (strcaseeq(wave_info->file_desc + AIFF_FILE_DESC_OFFSET,
			  (compression_name_list[1] + 1))) {
		len = fwriteulaw((short *)data, length, fp);
	    } else if (strcaseeq(wave_info->file_desc + AIFF_FILE_DESC_OFFSET,
				 (compression_name_list[2] + 1))) {
		len = fwritealaw((short *)data, length, fp);
	    } else {
		len = fwritesbyte((short *)data, length, fp);
	    }
	} else {
	    len = fwritesbyte((short *)data, length, fp);
	}
    } else {
	return -1;
    }
    
    return len;
}

unsigned long spGetAiffSongInfoMask(void)
{
    unsigned long info_mask = SP_SONG_NO_INFO;

    info_mask |= SP_SONG_TITLE_MASK;
    info_mask |= SP_SONG_ARTIST_MASK;
    info_mask |= SP_SONG_COMMENT_MASK;
    info_mask |= SP_SONG_COPYRIGHT_MASK;
    
    return info_mask;
}

spBool spGetAiffSongInfo(spSongInfo *song_info, FILE *fp)
{
    if (song_info == NULL) return SP_FALSE;
    
    return readAiffInfo(NULL, song_info, fp, SP_FALSE);
}

spBool spReadAiffSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp)
{
    return readAiffInfo(wave_info, song_info, fp, SP_TRUE);
}

static long writeTextChunk(char *id, char *text, FILE *fp)
{
    char cvalue;
    long chunk_size;
    long nwrite;
    char buf[SP_SONG_INFO_SIZE];
    
    strcpy(buf, text);
    spConvertKanjiFromLocaleCode((unsigned char *)buf, SP_SONG_INFO_SIZE, SP_KANJI_CODE_SJIS);
    
    chunk_size = strlen(buf);

    spDebug(10, "writeTextChunk", "%s: %s\n", id, buf);
    
    if (chunk_size <= 0) return 0;
    
    fputs(id, fp);
    nwrite = 4;
    nwrite += fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp) * 4;
    nwrite += fwrite(buf, 1, chunk_size, fp);
    
    if (chunk_size % 2) {		/* chunk size is odd */
	cvalue = 0;
	nwrite += fwrite(&cvalue, 1, 1, fp); 	/* zero padding */
    }

    return nwrite;
}

spBool spAddAiffSongInfo(spSongInfo *song_info, FILE *fp)
{
    short comment_size;
    short comment_padding;
    long nwrite;
    long chunk_size;
    char cvalue;
    short svalue;
    long lvalue;
    
    if (song_info == NULL || fp == NULL
	|| song_info->info_mask == SP_SONG_NO_INFO) return SP_FALSE;
    
    if (ftell(fp) <= 0) {
	fseek(fp, 0, SEEK_END);
    }
    
    nwrite = 0;

    if (song_info->info_mask & SP_SONG_COMMENT_MASK) {
	comment_size = strlen(song_info->comment);
	if (comment_size > 0) {
	    comment_padding = comment_size % 2;	/* comment size is odd */
	    chunk_size = 2/* number of comments*/ + 4/* time stamp */
		+ 2/* marker ID*/ + 2/* comment size */ + comment_size + comment_padding;
	    
	    fputs("COMT", fp);
	    nwrite += 4;
	    nwrite += fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp) * 4;
	    lvalue = 0;
	    nwrite += fwritelong32(&lvalue, 1, SP_AIFF_NEED_SWAP, fp) * 4; 	/* time stamp */
	    svalue = 0;
	    nwrite += fwriteshort(&svalue, 1, SP_AIFF_NEED_SWAP, fp) * 2; 	/* marker ID */
	    nwrite += fwriteshort(&comment_size, 1, SP_AIFF_NEED_SWAP, fp) * 2;
	    nwrite += fwrite(song_info->comment, 1, comment_size, fp);
	    
	    if (comment_padding) {
		cvalue = 0;
		nwrite += fwrite(&cvalue, 1, 1, fp); /* zero padding */
	    }
	}
    }
    if (song_info->info_mask & SP_SONG_TITLE_MASK) {
	nwrite += writeTextChunk("NAME", song_info->title, fp);
    }
    if (song_info->info_mask & SP_SONG_ARTIST_MASK) {
	nwrite += writeTextChunk("AUTH", song_info->artist, fp);
    }
    if (song_info->info_mask & SP_SONG_COPYRIGHT_MASK) {
	nwrite += writeTextChunk("(c) ", song_info->copyright, fp);
    }
    
    fseek(fp, 0, SEEK_END);
    chunk_size = ftell(fp) - 8;

    /* update FORM chunk size */
    fseek(fp, 4, SEEK_SET);
    fwritelong32(&chunk_size, 1, SP_AIFF_NEED_SWAP, fp);
    
    fseek(fp, 0, SEEK_END);
    
    return SP_TRUE;
}

spBool spWriteAiffSongInfo(spWaveInfo *wave_info, spSongInfo *song_info, FILE *fp)
{
    long offset;
    
    if (wave_info == NULL || song_info == NULL || fp == NULL) return SP_FALSE;
    
    spDebug(10, "spWriteAiffSongInfo", "header_size = %ld, length = %ld\n",
	    wave_info->header_size, wave_info->length);
    
    if (wave_info->header_size <= 0 || wave_info->length <= 0) return SP_FALSE;

    offset = (long)wave_info->header_size +
	wave_info->length * (long)wave_info->num_channel * (long)(wave_info->samp_bit / 8);
    if (fseek(fp, offset, SEEK_SET) < 0) {
	return SP_FALSE;
    }

    return spAddAiffSongInfo(song_info, fp);
}
     
/*
 * C O N V E R T   T O   I E E E   E X T E N D E D
 */

/* Copyright (C) 1988-1991 Apple Computer, Inc.
 * All rights reserved.
 *
 * Machine-independent I/O routines for IEEE floating-point numbers.
 *
 * NaN's and infinities are converted to HUGE_VAL or HUGE, which
 * happens to be infinity on IEEE machines.  Unfortunately, it is
 * impossible to preserve NaN's in a machine-independent way.
 * Infinities are, however, preserved on IEEE machines.
 *
 * These routines have been tested on the following machines:
 *    Apple Macintosh, MPW 3.1 C compiler
 *    Apple Macintosh, THINK C compiler
 *    Silicon Graphics IRIS, MIPS compiler
 *    Cray X/MP and Y/MP
 *    Digital Equipment VAX
 *
 *
 * Implemented by Malcolm Slaney and Ken Turkowski.
 *
 * Malcolm Slaney contributions during 1988-1990 include big- and little-
 * endian file I/O, conversion to and from Motorola's extended 80-bit
 * floating-point format, and conversions to and from IEEE single-
 * precision floating-point format.
 *
 * In 1991, Ken Turkowski implemented the conversions to and from
 * IEEE double-precision format, added more precision to the extended
 * conversions, and accommodated conversions involving +/- infinity,
 * NaN's, and denormalized numbers.
 */

#ifndef HUGE_VAL
#define HUGE_VAL HUGE
#endif /*HUGE_VAL*/

#define FloatToUnsigned(f)      ((unsigned long)(((long)(f - 2147483648.0)) + 2147483647L) + 1)

static void ConvertToIeeeExtended(double num, char* bytes)
{
    int    sign;
    int expon;
    double fMant, fsMant;
    unsigned long hiMant, loMant;

    if (num < 0) {
        sign = 0x8000;
        num *= -1;
    } else {
        sign = 0;
    }

    if (num == 0) {
        expon = 0; hiMant = 0; loMant = 0;
    }
    else {
        fMant = frexp(num, &expon);
        if ((expon > 16384) || !(fMant < 1)) {    /* Infinity or NaN */
            expon = sign|0x7FFF; hiMant = 0; loMant = 0; /* infinity */
        }
        else {    /* Finite */
            expon += 16382;
            if (expon < 0) {    /* denormalized */
                fMant = ldexp(fMant, expon);
                expon = 0;
            }
            expon |= sign;
            fMant = ldexp(fMant, 32);          
            fsMant = floor(fMant); 
            hiMant = FloatToUnsigned(fsMant);
            fMant = ldexp(fMant - fsMant, 32); 
            fsMant = floor(fMant); 
            loMant = FloatToUnsigned(fsMant);
        }
    }
    
    bytes[0] = (char)(expon >> 8);
    bytes[1] = (char)expon;
    bytes[2] = (char)(hiMant >> 24);
    bytes[3] = (char)(hiMant >> 16);
    bytes[4] = (char)(hiMant >> 8);
    bytes[5] = (char)hiMant;
    bytes[6] = (char)(loMant >> 24);
    bytes[7] = (char)(loMant >> 16);
    bytes[8] = (char)(loMant >> 8);
    bytes[9] = (char)loMant;
}


/*
 * C O N V E R T   F R O M   I E E E   E X T E N D E D  
 */

/* 
 * Copyright (C) 1988-1991 Apple Computer, Inc.
 * All rights reserved.
 *
 * Machine-independent I/O routines for IEEE floating-point numbers.
 *
 * NaN's and infinities are converted to HUGE_VAL or HUGE, which
 * happens to be infinity on IEEE machines.  Unfortunately, it is
 * impossible to preserve NaN's in a machine-independent way.
 * Infinities are, however, preserved on IEEE machines.
 *
 * These routines have been tested on the following machines:
 *    Apple Macintosh, MPW 3.1 C compiler
 *    Apple Macintosh, THINK C compiler
 *    Silicon Graphics IRIS, MIPS compiler
 *    Cray X/MP and Y/MP
 *    Digital Equipment VAX
 *
 *
 * Implemented by Malcolm Slaney and Ken Turkowski.
 *
 * Malcolm Slaney contributions during 1988-1990 include big- and little-
 * endian file I/O, conversion to and from Motorola's extended 80-bit
 * floating-point format, and conversions to and from IEEE single-
 * precision floating-point format.
 *
 * In 1991, Ken Turkowski implemented the conversions to and from
 * IEEE double-precision format, added more precision to the extended
 * conversions, and accommodated conversions involving +/- infinity,
 * NaN's, and denormalized numbers.
 */

#ifndef HUGE_VAL
#define HUGE_VAL HUGE
#endif /*HUGE_VAL*/

#define UnsignedToFloat(u)         (((double)((long)(u - 2147483647L - 1))) + 2147483648.0)

/****************************************************************
 * Extended precision IEEE floating-point conversion routine.
 ****************************************************************/

static double ConvertFromIeeeExtended(unsigned char* bytes /* LCN */)
{
    double    f;
    int    expon;
    unsigned long hiMant, loMant;
    
    expon = ((bytes[0] & 0x7F) << 8) | (bytes[1] & 0xFF);
    hiMant    =    ((unsigned long)(bytes[2] & 0xFF) << 24)
            |    ((unsigned long)(bytes[3] & 0xFF) << 16)
            |    ((unsigned long)(bytes[4] & 0xFF) << 8)
            |    ((unsigned long)(bytes[5] & 0xFF));
    loMant    =    ((unsigned long)(bytes[6] & 0xFF) << 24)
            |    ((unsigned long)(bytes[7] & 0xFF) << 16)
            |    ((unsigned long)(bytes[8] & 0xFF) << 8)
            |    ((unsigned long)(bytes[9] & 0xFF));

    if (expon == 0 && hiMant == 0 && loMant == 0) {
        f = 0;
    }
    else {
        if (expon == 0x7FFF) {    /* Infinity or NaN */
            f = HUGE_VAL;
        }
        else {
            expon -= 16383;
            f  = ldexp(UnsignedToFloat(hiMant), expon-=31);
            f += ldexp(UnsignedToFloat(loMant), expon-=32);
        }
    }

    if (bytes[0] & 0x80)
        return -f;
    else
        return f;
}
