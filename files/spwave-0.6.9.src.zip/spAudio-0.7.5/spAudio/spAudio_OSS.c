/*
 *	spAudio_OSS.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(OSS)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/soundcard.h>

spBool spInitAudioArch(spAudio audio)
{
    audio->prev_fd = -1;
    audio->input_fd = -1;
    audio->output_fd = -1;
    audio->fragment_size = 128;

    audio->block_size0 = 0;
    audio->block_size1 = 0;
    
    audio->samp_byte = sizeof(short);
    
    return SP_TRUE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioBufferSizeArch(spAudio audio)
{
    audio->fragment_size = 2 * audio->buffer_size;
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    return SP_TRUE;
}

static int openAudioDevice(spAudio audio, spBool write_flag)
{
    int fd;
    int caps;
    int fragment_size;
    int value;
    int rdwr_success = 0;
    int enable_bits = PCM_ENABLE_INPUT | PCM_ENABLE_OUTPUT;
    int *samp_bit = NULL;
    int *samp_rate = NULL;
    int *num_channel = NULL;
    int *block_size = NULL;

    if (audio->prev_fd == -1) {
	if (audio->only_flag || (fd = open("/dev/dsp", O_RDWR)) == -1) {
	    spDebug(1, NULL, "open /dev/dsp failed: O_RDWR\n");
	    if (write_flag == SP_TRUE) {
		if ((fd = open("/dev/dsp", O_WRONLY)) == -1) {
		    spDebug(1, NULL, "open /dev/dsp failed: O_WRONLY\n");
		    return -1;
		}
	    } else {
		if ((fd = open("/dev/dsp", O_RDONLY)) == -1) {
		    spDebug(1, NULL, "open /dev/dsp failed: O_RDONLY\n");
		    return -1;
		}
	    }
	} else {
	    rdwr_success = 1;
	}
	audio->fd0 = fd;
	spDebug(1, NULL, "open /dev/dsp done: fd = %d\n", fd);
	
	if (ioctl(fd, SNDCTL_DSP_GETCAPS, &caps) == -1) {
	    spWarning("ioctl SNDCTL_DSP_GETCAPS failed\n");
	}
	if (caps & DSP_CAP_DUPLEX) {
	    spDebug(1, NULL, "full duplex supported\n");
	    if (ioctl(fd, SNDCTL_DSP_SETDUPLEX, 0) == -1) {
		spWarning("ioctl SNDCTL_DSP_SETDUPLEX failed\n");
	    } else {
		if (caps & DSP_CAP_TRIGGER) {
		    spDebug(1, NULL, "trigger supported\n");
		    if (ioctl(fd, SNDCTL_DSP_SETTRIGGER, &enable_bits) == -1) {
			spWarning("ioctl SNDCTL_DSP_SETTRIGGER failed\n");
		    }
		}
		
		audio->fragment_size = MAX(audio->fragment_size, 16);
		value = (int)(log10((double)audio->fragment_size) / log10(2.0));
		fragment_size = (0x7fff0000 | (0x0000ffff & value));
		spDebug(1, NULL, "fragment_size = %x\n", fragment_size);
		
		if (ioctl(fd, SNDCTL_DSP_SETFRAGMENT, &fragment_size) == -1) {
		    spWarning("ioctl SNDCTL_DSP_SETFRAGMENT failed\n");
		}
		if (rdwr_success) {
		    audio->duplex_flag = 1;
		}
	    }
	}
	if (caps & DSP_CAP_REALTIME) {
	    spDebug(1, NULL, "real time supported\n");
	}

	audio->samp_bit0 = audio->samp_bit;
	audio->samp_rate0 = (int)audio->samp_rate;
	audio->num_channel0 = audio->num_channel;
	audio->block_size0 = audio->buffer_size;
	samp_bit = &audio->samp_bit0;
	samp_rate = &audio->samp_rate0;
	num_channel = &audio->num_channel0;
	block_size = &audio->block_size0;
	audio->prev_fd = fd;
    } else if (!audio->duplex_flag) {
	if (audio->only_flag || (fd = open("/dev/dsp1", O_RDWR)) == -1) {
	    spDebug(1, NULL, "open /dev/dsp1 failed: O_RDWR\n");
	    if (write_flag == SP_TRUE) {
		if ((fd = open("/dev/dsp1", O_WRONLY)) == -1) {
		    spDebug(1, NULL, "open /dev/dsp1 failed: O_WRONLY\n");
		    return -1;
		}
	    } else {
		if ((fd = open("/dev/dsp1", O_RDONLY)) == -1) {
		    spDebug(1, NULL, "open /dev/dsp1 failed: O_RDONLY\n");
		    return -1;
		}
	    }
	}
	spDebug(1, NULL, "open /dev/dsp1 done: fd = %d\n", fd);
	audio->duplex_flag = 2;
	audio->fd1 = fd;

	audio->samp_bit1 = audio->samp_bit;
	audio->samp_rate1 = (int)audio->samp_rate;
	audio->num_channel1 = audio->num_channel;
	audio->block_size1 = audio->buffer_size;
	samp_bit = &audio->samp_bit1;
	samp_rate = &audio->samp_rate1;
	num_channel = &audio->num_channel1;
	block_size = &audio->block_size1;
    } else {
	spDebug(1, NULL, "open /dev/dsp with duplex mode: fd = %d\n", audio->prev_fd);
	return audio->prev_fd;
    }

    if (ioctl(fd, SOUND_PCM_WRITE_BITS, samp_bit) == -1) {
	spWarning("ioctl SOUND_PCM_WRITE_BITS failed\n");
    }
    spDebug(1, NULL, "bits = %d\n", *samp_bit);
    
    if (ioctl(fd, SOUND_PCM_WRITE_CHANNELS, num_channel) == -1) {
	spWarning("ioctl SOUND_PCM_WRITE_CHANNELS failed\n");
    }
    spDebug(1, NULL, "channels = %d\n", *num_channel);
    
    if (ioctl(fd, SOUND_PCM_WRITE_RATE, samp_rate) == -1) {
	spWarning("ioctl SOUND_PCM_WRITE_RATE failed\n");
    }
    spDebug(1, NULL, "rate = %d\n", *samp_rate);
    
    spDebug(1, NULL, "current block size = %d\n", *block_size);
    if (ioctl(fd, SNDCTL_DSP_GETBLKSIZE, block_size) == -1) {
	spWarning("ioctl SNDCTL_DSP_GETBLKSIZE failed\n");
    }
    spDebug(1, NULL, "block size = %d\n", *block_size);
    audio->buffer_size = *block_size;

    audio->samp_byte = (long)(*samp_bit / 8);
    spDebug(1, NULL, "bit size = %ld\n", audio->samp_byte);

    return fd;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
    if ((audio->input_fd = openAudioDevice(audio, SP_FALSE)) == -1) {
	spMessage("Open audio device failed.\n");
	return SP_FALSE;
    } else {
	return SP_TRUE;
    }
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
    if ((audio->output_fd = openAudioDevice(audio, SP_TRUE)) == -1) {
	spMessage("Open audio device failed.\n");
	return SP_FALSE;
    } else {
	return SP_TRUE;
    }
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    int flag = 0;

    if (audio == NULL) return SP_FALSE;
    
    if (audio->input_fd != -1) {
	ioctl(audio->input_fd, SOUND_PCM_SYNC, 0);
	if (close(audio->input_fd) == -1) {
	    flag = -1;
	} else {
	    if (audio->input_fd == audio->output_fd) {
		audio->output_fd = -1;
	    }
	    audio->input_fd = -1;
	}
    }
    
    if (audio->output_fd != -1) {
	ioctl(audio->output_fd, SOUND_PCM_SYNC, 0);
	if (close(audio->output_fd) == -1) {
	    flag = -1;
	} else {
	    audio->output_fd = -1;
	}
    }
    audio->prev_fd = -1;

    spDebug(1, NULL, "close audio device done\n");
    
    return (flag == -1 ? SP_FALSE : SP_TRUE);
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    long count;
    long nremain;
    audio_buf_info info;
    
    if (audio->input_fd == -1) return -1;

    nremain = length * audio->samp_byte;
    
    if (audio->block_mode == SP_AUDIO_NONBLOCKING
	&& ioctl(audio->input_fd, SNDCTL_DSP_GETISPACE, &info) != -1) {
	if (info.bytes > 0) {
	    nremain = MIN(nremain, info.bytes);
	} else {
	    nremain = MIN(nremain, audio->buffer_size);
	}
    }
    
    count = read(audio->input_fd, data, nremain);
    if (count < 0) return -1;

    return (count / (long)audio->samp_byte);
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    long count;
    long nremain;

    if (audio->output_fd == -1) return -1;
    
    nremain = length * audio->samp_byte;
    count = write(audio->output_fd, data, nremain);
    if (count < 0) return -1;
    
    return (count / (long)audio->samp_byte);
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    count_info info;

    if (audio->output_fd == -1) return SP_FALSE;
    
    if (ioctl(audio->output_fd, SNDCTL_DSP_GETOPTR, &info) == -1) {
	return SP_FALSE;
    }
    if (position != NULL) {
	spDebug(100, "spGetAudioOutputPositionArch", "info.bytes = %d\n", info.bytes);
	*position = (long)info.bytes / (long)audio->samp_byte / (long)audio->num_channel;
    }
    
    return SP_TRUE;
}

spBool spStopAudioArch(spAudio audio)
{
    if (audio->input_fd != -1) {
	ioctl(audio->input_fd, SOUND_PCM_RESET, 0);
    }
    if (audio->output_fd != -1 && audio->output_fd != audio->input_fd) {
	ioctl(audio->output_fd, SOUND_PCM_RESET, 0);
    }

    return SP_TRUE;
}

spBool spSyncAudioArch(spAudio audio)
{
    if (audio->input_fd != -1) {
	ioctl(audio->input_fd, SOUND_PCM_SYNC, 0);
    }
    if (audio->output_fd != -1 && audio->output_fd != audio->input_fd) {
	ioctl(audio->output_fd, SOUND_PCM_SYNC, 0);
    }

    return SP_TRUE;
}

spBool spFreeAudioArch(spAudio audio)
{
    return SP_TRUE;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
