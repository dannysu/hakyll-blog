/*
 *	spAudio.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>
#include <sp/spOption.h>

#include <sp/spAudioP.h>

void spTerminateAudio(spAudio audio);

spAudio spInitAudio(void)
{
    spAudio audio;

    spDebug(1, "spInitAudio", "in\n");
    
    audio = xalloc(1, struct _spAudio);
    audio->samp_bit = 16;
    audio->samp_rate = 8000;
    audio->num_channel = 1;
    audio->buffer_size = SP_DEFAULT_AUDIO_BUFFER_SIZE;
    audio->samp_byte = 2;
    audio->duplex_flag = 0;
    audio->only_flag = 0;
    audio->block_mode = SP_AUDIO_BLOCKING;
    audio->specified_samp_bit = 16;
    audio->input_total = 0;
    audio->output_total = 0;
    audio->num_buffer = SP_DEFAULT_NUM_BUFFER;

#ifdef SP_SUPPORT_THREAD_AUDIO
    audio->write_thread = NULL;
    audio->write_func = NULL;
    audio->write_data = NULL;
#endif

    if (spInitAudioArch(audio) == SP_FALSE) {
	xfree(audio);
	return NULL;
    }

    spAddExitCallback((spExitCallbackFunc)spTerminateAudio, audio);
    
    return audio;
}

spBool spSetAudioSampleRate(spAudio audio, double samp_rate)
{
    if (audio == NULL) return SP_FALSE;
    
    audio->samp_rate = samp_rate;
    spDebug(1, NULL, "sampling rate = %f\n", audio->samp_rate);
    
    return spSetAudioSampleRateArch(audio);
}

spBool spGetAudioSampleRate(spAudio audio, double *samp_rate)
{
    if (audio == NULL) return SP_FALSE;

    if (samp_rate != NULL) {
	*samp_rate = audio->samp_rate;
    }
    
    return SP_TRUE;
}

spBool spSetAudioChannel(spAudio audio, int num_channel)
{
    if (audio == NULL) return SP_FALSE;
    
    audio->num_channel = num_channel;
    spDebug(1, NULL, "channels = %d\n", audio->num_channel);
    
    return spSetAudioChannelArch(audio);
}

spBool spGetAudioChannel(spAudio audio, int *num_channel)
{
    if (audio == NULL) return SP_FALSE;

    if (num_channel != NULL) {
	*num_channel = audio->num_channel;
    }
    
    return SP_TRUE;
}

spBool spSetAudioBufferSize(spAudio audio, int buffer_size)
{
    if (audio == NULL) return SP_FALSE;

    if (buffer_size <= 0) {
	audio->buffer_size = SP_DEFAULT_AUDIO_BUFFER_SIZE;
    } else {
	audio->buffer_size = buffer_size;
    }
    spDebug(1, NULL, "audio buffer size = %d\n", audio->buffer_size);
    
    return spSetAudioBufferSizeArch(audio);
}

spBool spGetAudioBufferSize(spAudio audio, int *buffer_size)
{
    if (audio == NULL) return SP_FALSE;

    if (buffer_size != NULL) {
	*buffer_size = audio->buffer_size;
    }
    
    return SP_TRUE;
}

spBool spSetAudioNumBuffer(spAudio audio, int num_buffer)
{
    if (audio == NULL) return SP_FALSE;

    if (num_buffer <= 0) {
	audio->num_buffer = SP_DEFAULT_NUM_BUFFER;
    } else {
	audio->num_buffer = MAX(num_buffer, 2);
    }
    spDebug(1, NULL, "number of audio buffers = %d\n", audio->num_buffer);
    
    return spSetAudioNumBufferArch(audio);
}

spBool spGetAudioNumBuffer(spAudio audio, int *num_buffer)
{
    if (audio == NULL) return SP_FALSE;

    if (num_buffer != NULL) {
	*num_buffer = audio->num_buffer;
    }
    
    return SP_TRUE;
}

spBool spSetAudioBlockingMode(spAudio audio, int block_mode)
{
    if (audio == NULL) return SP_FALSE;
    
    audio->block_mode = block_mode;
    spDebug(1, NULL, "block_mode = %d\n", audio->block_mode);
    
    return spSetAudioBlockingModeArch(audio);
}

spBool spGetAudioBlockingMode(spAudio audio, int *block_mode)
{
    if (audio == NULL) return SP_FALSE;

    if (block_mode != NULL) {
	*block_mode = audio->block_mode;
    }
    
    return SP_TRUE;
}

spBool spSetAudioSampleBit(spAudio audio, int samp_bit)
{
    if (audio == NULL) return SP_FALSE;

    if (samp_bit == 16 || samp_bit == 24 || samp_bit == 32) {
	audio->specified_samp_bit = samp_bit;
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spGetAudioSampleBit(spAudio audio, int *samp_bit)
{
    if (audio == NULL) return SP_FALSE;

    if (samp_bit != NULL) {
	*samp_bit = audio->samp_bit;
    }
    
    return SP_TRUE;
}

spBool spOpenAudioDevice(spAudio audio, char *mode)
{
    if (audio == NULL || strnone(mode)) return SP_FALSE;

    spDebug(1, "spOpenAudioDevice", "mode = %s\n", mode);

    if (mode[1] == 'o') {
	audio->only_flag = 1;
    }
    
    if (mode[0] == 'r') {
	audio->input_total = 0;
	return spOpenInputAudioDeviceArch(audio);
    } else if (mode[0] == 'w') {
	audio->output_total = 0;
	return spOpenOutputAudioDeviceArch(audio);
    } else {
	spDebug(1, NULL, "Unknown mode: %s\n", mode);
	return SP_FALSE;
    }
}

spBool spCloseAudioDevice(spAudio audio)
{
    if (audio == NULL) return SP_FALSE;
    
    return spCloseAudioDeviceArch(audio);
}

static spBool isUnsupported32bit(spAudio audio)
{
    if ((audio->specified_samp_bit == 24 || audio->specified_samp_bit == 32)
	&& audio->samp_bit != audio->specified_samp_bit) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static long readAudio16To32(spAudio audio, char *data, long length)
{
    long k;
    long nread;
    short *sdata;
    long *ldata;
    
    if ((nread = spReadAudioArch(audio, data, length)) > 0) {
	sdata = (short *)data;
	ldata = (long *)data;

	if (audio->specified_samp_bit == 24) {
	    for (k = length - 1; k >= 0; k--) {
		ldata[k] = (long)sdata[k] * 256;
	    }
	} else {
	    for (k = length - 1; k >= 0; k--) {
		ldata[k] = (long)sdata[k] * 65536;
	    }
	}
    }

    return nread;
    
}

long _spReadAudio(spAudio audio, char *data, long length)
{
    long nread;
    
    if (audio == NULL || data == NULL || length < 0) return -1;

    if (isUnsupported32bit(audio) == SP_TRUE) {
	nread = readAudio16To32(audio, data, length);
    } else {
	nread = spReadAudioArch(audio, data, length);
    }

    if (nread >= 0) {
	audio->input_total += nread;
    }

    return nread;
}

static long writeAudio32To16(spAudio audio, char *data, long length)
{
    long k;
    long nwrite;
    short *sdata;
    long *ldata;

    ldata = (long *)data;
    sdata = xalloc(length, short);
    
    if (audio->specified_samp_bit == 24) {
	for (k = 0; k < length; k++) {
	    sdata[k] = (short)spRound((double)ldata[k] / 256.0);
	}
    } else {
	for (k = 0; k < length; k++) {
	    sdata[k] = (short)spRound((double)ldata[k] / 65536.0);
	}
    }
    
    nwrite = spWriteAudioArch(audio, (char *)sdata, length);

    xfree(sdata);

    return nwrite;
}

long _spWriteAudio(spAudio audio, char *data, long length)
{
    long nwrite;
    
    if (audio == NULL || data == NULL || length < 0) return -1;

    if (isUnsupported32bit(audio) == SP_TRUE) {
	nwrite = writeAudio32To16(audio, data, length);
    } else {
	nwrite = spWriteAudioArch(audio, data, length);
    }

    if (nwrite >= 0) {
	audio->output_total += nwrite;
    }

    return nwrite;
}

spBool spGetAudioOutputPosition(spAudio audio, long *position)
{
    if (audio == NULL) return SP_FALSE;

    return spGetAudioOutputPositionArch(audio, position);
}

spBool spStopAudio(spAudio audio)
{
    if (audio == NULL) return SP_FALSE;

    audio->input_total = 0;
    audio->output_total = 0;
    
    return spStopAudioArch(audio);
}

spBool spSyncAudio(spAudio audio)
{
    if (audio == NULL) return SP_FALSE;

    audio->input_total = 0;
    audio->output_total = 0;

    return spSyncAudioArch(audio);
}

void _spFreeAudio(spAudio audio)
{
    if (audio != NULL) {
	spFreeAudioArch(audio);
	spRemoveExitCallback((spExitCallbackFunc)spTerminateAudio, audio);
	xfree(audio);
    }
    
    return;
}

void spTerminateAudio(spAudio audio)
{
    spDebug(10, "spTerminateAudio", "in\n");

    if (audio != NULL) {
	spCloseAudioDevice(audio);
	spFreeAudio(audio);
	spTerminateAudioArch();
    }

    return;
}
