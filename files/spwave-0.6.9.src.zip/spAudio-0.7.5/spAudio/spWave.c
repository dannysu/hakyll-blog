/*
 *	spWave.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>
#include <sp/spOption.h>
#include <sp/spWave.h>
#include <sp/spAudio.h>

#include <sp/spWaveP.h>

spBool spInitWaveInfo(spWaveInfo *wave_info)
{
    if (wave_info == NULL) return SP_FALSE;

    memset(wave_info, 0, sizeof(spWaveInfo));
    wave_info->samp_bit = 16;
    wave_info->num_channel = 1;
    wave_info->samp_rate = 8000.0;

    return SP_TRUE;
}

spBool spInitSongInfo(spSongInfo *song_info)
{
    if (song_info == NULL) return SP_FALSE;

    memset(song_info, 0, sizeof(spSongInfo));

    return SP_TRUE;
}

spBool spCopySongInfo(spSongInfo *dest_info, spSongInfo *src_info)
{
    if (dest_info == NULL || src_info == NULL) return SP_FALSE;

    memmove(dest_info, src_info, sizeof(spSongInfo));

    return SP_TRUE;
}

spBool spEqSongInfo(spSongInfo *info1, spSongInfo *info2)
{
    if (info1 == NULL || info2 == NULL) return SP_FALSE;

    if (info1->info_mask != info2->info_mask) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_TRACK_MASK) && info1->track != info2->track) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_TITLE_MASK) && !streq(info1->title, info2->title)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_ARTIST_MASK) && !streq(info1->artist, info2->artist)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_ALBUM_MASK) && !streq(info1->album, info2->album)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_GENRE_MASK) && !streq(info1->genre, info2->genre)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_RELEASE_MASK) && !streq(info1->release, info2->release)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_COPYRIGHT_MASK) && !streq(info1->copyright, info2->copyright)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_ENGINEER_MASK) && !streq(info1->engineer, info2->engineer)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_SOURCE_MASK) && !streq(info1->source, info2->source)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_SOFTWARE_MASK) && !streq(info1->software, info2->software)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_SUBJECT_MASK) && !streq(info1->subject, info2->subject)) return SP_FALSE;
    if ((info1->info_mask & SP_SONG_COMMENT_MASK) && !streq(info1->comment, info2->comment)) return SP_FALSE;

    return SP_TRUE;
}

spBool spShowSongInfo(spSongInfo *song_info, char *indent, FILE *fp)
{
    if (song_info == NULL) return SP_FALSE;
    
    spDebug(10, "spShowSongInfo", "song_info->info_mask = %ld\n", song_info->info_mask);

    if (fp == NULL) fp = stderr;
    
    if (song_info->info_mask & SP_SONG_TITLE_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Title: %s\n", song_info->title);
    }
    if (song_info->info_mask & SP_SONG_ARTIST_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Artist: %s\n", song_info->artist);
    }
    if (song_info->info_mask & SP_SONG_ALBUM_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Album: %s\n", song_info->album);
    }
    if (song_info->info_mask & SP_SONG_GENRE_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Genre: %s\n", song_info->genre);
    }
    if (song_info->info_mask & SP_SONG_RELEASE_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Release: %s\n", song_info->release);
    }
    if (song_info->info_mask & SP_SONG_COPYRIGHT_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Copyright: %s\n", song_info->copyright);
    }
    if (song_info->info_mask & SP_SONG_ENGINEER_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Engineer: %s\n", song_info->engineer);
    }
    if (song_info->info_mask & SP_SONG_SOURCE_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Source: %s\n", song_info->source);
    }
    if (song_info->info_mask & SP_SONG_SOFTWARE_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Software: %s\n", song_info->software);
    }
    if (song_info->info_mask & SP_SONG_SUBJECT_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Subject: %s\n", song_info->subject);
    }
    if (song_info->info_mask & SP_SONG_COMMENT_MASK) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Comment: %s\n", song_info->comment);
    }

    return SP_TRUE;
}

static spBool sp_play_use_dat_link = SP_FALSE;
#ifdef _WIN32
static spBool sp_play_use_wav = SP_TRUE;
#else
static spBool sp_play_use_wav = SP_FALSE;
#endif

static spBool spPlayRawFile_DatLink(char *filename, int num_channel, double samp_rate)
{
    int error;
    char command[SP_MAX_MESSAGE];

    if (strnone(filename)) return SP_FALSE;
    
    if (num_channel > 2) {
	spDebug(1, NULL, "Multi channel data can't be played.\n");
	return SP_FALSE;
    }
    
    /* create play command */
    if (num_channel == 2) {
	sprintf(command, "naplay -f native -o stereo -s %.0f %s", samp_rate, filename);
    } else {
	sprintf(command, "naplay -f native -o mono -s %.0f %s", samp_rate, filename);
    }
    spDebug(10, NULL, "%s\n", command);

    /* execute play command */
    error = system(command);

    if (error)
	return SP_FALSE;
    else
	return SP_TRUE;
}

void spPlayFileUseDatLink(spBool flag)
{
    sp_play_use_dat_link = flag;
    return;
}

#ifdef DEC
static spBool spPlayRawFile_DEC(char *filename, int num_channel, double samp_rate)
{
    int error;
    int freq_hz;
    char command[SP_MAX_MESSAGE];

    if (strnone(filename)) return SP_FALSE;
    
    if (num_channel > 2) {
	spDebug(1, NULL, "Multi channel data can't be played.\n");
	return SP_FALSE;
    }
    
    freq_hz = (int)(samp_rate);

    if (freq_hz <= 5512) {
	freq_hz = 5512;
    } else if (freq_hz <= 6615) {
	freq_hz = 6615;
    } else if (freq_hz <= 8000) {
	freq_hz = 8000;
    } else if (freq_hz <= 9600) {
	freq_hz = 9600;
    } else if (freq_hz <= 11025) {
	freq_hz = 11025;
    } else if (freq_hz <= 16000) {
	freq_hz = 16000;
    } else if (freq_hz <= 18900) {
	freq_hz = 18900;
    } else if (freq_hz <= 22050) {
	freq_hz = 22050;
    } else if (freq_hz <= 27428) {
	freq_hz = 27428;
    } else if (freq_hz <= 32000) {
	freq_hz = 32000;
    } else if (freq_hz <= 33075) {
	freq_hz = 33075;
    } else if (freq_hz <= 37800) {
	freq_hz = 37800;
    } else if (freq_hz <= 44100) {
	freq_hz = 44100;
    } else {
	freq_hz = 48000;
    }
	
    /* create play command */
    sprintf(command, "audioplay -filename %s -channels %d -rate %d -bitspersample 16 -encoding pcm > /dev/null", 
            filename, num_channel, freq_hz);
    spDebug(10, NULL, "%s\n", command);

    /* execute play command */
    error = system(command);

    if (error)
	return SP_FALSE;
    else
	return SP_TRUE;
}
#endif

#ifdef SGI
static spBool spPlayRawFile_SGI(char *filename, int num_channel, double samp_rate)
{
    int error;
    char command[SP_MAX_MESSAGE];

    if (strnone(filename)) return SP_FALSE;
    
    if (num_channel > 2) {
	spDebug(1, NULL, "Multi channel data can't be played.\n");
	return SP_FALSE;
    }
    
    /* create play command */
    sprintf(command, "/usr/sbin/sfplay -i rate %.0f channels %d integer 16 2scomp byteorder big end %s",
	    samp_rate, num_channel, filename);
    spDebug(10, NULL, "%s\n", command);

    /* execute play command */
    error = system(command);
    
    if (error)
	return SP_FALSE;
    else
	return SP_TRUE;
}
#endif

#ifdef sun
static spBool spPlayRawFile_Sun(char *filename, int num_channel, double samp_rate)
{
    int error;
    char command[SP_MAX_MESSAGE];

    if (strnone(filename)) return SP_FALSE;
    
    if (num_channel > 2) {
	spDebug(1, NULL, "Multi channel data can't be played.\n");
	return SP_FALSE;
    }
    
    /* create play command */
    if (num_channel == 2) {
	sprintf(command, "audioconvert -i rate=%.0f,channel=stereo,encoding=pcm,format=raw -f dat %s | audioplay - ",
		samp_rate, filename);
    } else {
	sprintf(command, "audioconvert -i rate=%.0f,channel=mono,encoding=pcm,format=raw -f dat %s | audioplay - ",
		samp_rate, filename);
    }
    spDebug(10, NULL, "%s\n", command);

    /* execute play command */
    error = system(command);

    if (error)
	return SP_FALSE;
    else
	return SP_TRUE;
}
#endif

#ifdef _WIN32
#if defined(_WIN32) && !defined(SND_SYNC)
#define SND_SYNC            	(0x0000)
#define SND_ASYNC           	(0x0001)
#define SND_NODEFAULT       	(0x0002)
#define SND_MEMORY          	(0x0004)
#define SND_LOOP            	(0x0008)
#define SND_NOSTOP		(0x0010)
#define SND_NOWAIT		(0x00002000L)
#define SND_ALIAS       	(0x00010000L)
#define SND_ALIAS_ID		(0x00110000L)
#define SND_FILENAME    	(0x00020000L)
#define SND_RESOURCE    	(0x00040004L)
#define SND_PURGE           	(0x0040)
#define SND_APPLICATION     	(0x0080)
#define SND_ALIAS_START		(0)

#ifndef UNICODE_ONLY
WINBOOL WINAPI PlaySoundA(LPCSTR pszSound, HMODULE hmod, DWORD fdwSound);
#endif /* !UNICODE_ONLY */
#ifndef ANSI_ONLY
WINBOOL WINAPI PlaySoundW(LPCWSTR pszSound, HMODULE hmod, DWORD fdwSound);
#endif /* !ANSI_ONLY */

#ifdef UNICODE
#define PlaySound  PlaySoundW
#else	/* ASCII */
#define PlaySound  PlaySoundA
#endif
#endif /* defined(_WIN32) && !defined(SND_SYNC) */

static spBool spPlayWavFile_Win(char *filename, int num_channel, double samp_rate)
{
    if (PlaySound(filename, NULL, SND_SYNC | SND_FILENAME | SND_NODEFAULT)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}
#endif

void spPlayFileUseWav(spBool flag)
{
    sp_play_use_wav = flag;
    return;
}

static char sp_play_command[SP_MAX_MESSAGE] = "";

/*
 *	%C: 	number of channel
 *	%H: 	sampling frequency in herz
 *	%K: 	sampling frequency in kilo herz
 *	%F|%s: 	file name (raw file)
 *	%W: 	file name (wav file)
 */
spBool spPlayFile_Option(char *filename, int num_channel, double samp_rate)
{
    int i;
    int error;
    int channel_flag = 0;
    char c, prev_c;
    char *format;
    char buf[SP_MAX_LINE];
    char command[SP_MAX_MESSAGE];

    if (strnone(sp_play_command) || strnone(filename)) return SP_FALSE;
    
    format = sp_play_command;

    command[0] = NUL;
    prev_c = NUL;
    for (i = 0;; i++) {
	c = format[i];
	if (c == NUL) {
	    break;
	} else if (c == '\\') {
	    c = format[++i];
	} else if (c == '%' && prev_c != '%') {
	    c = format[++i];
	    switch (c) {
	      case 'C':
		sprintf(buf, "%d", num_channel);
		strcat(command, buf);
		channel_flag = 1;
		break;
	      case 'K':
		sprintf(buf, "%.2f", samp_rate / 1000.0);
		strcat(command, buf);
		break;
	      case 'H':
		sprintf(buf, "%.0f", samp_rate);
		strcat(command, buf);
		break;
	      case 'W':	/* Wav file */
	      case 'F':
	      case 's':
		strcat(command, filename);
		break;
	      default:
		c = '%';
		i--;
	    }
	} else {
	    sprintf(buf, "%c", c);
	    strcat(command, buf);
	}
	prev_c = c;
    }

    if (!channel_flag && num_channel >= 2) {
	spDebug(1, NULL, "Multi channel data can't be played.\n");
	return SP_FALSE;
    }
    
    spDebug(10, NULL, "%s\n", command);

    /* execute play command */
    error = system(command);

    if (error)
	return SP_FALSE;
    else
	return SP_TRUE;
}

static spBool (*sp_play_func)(char *filename, int num_channel, double samp_rate) = NULL;

spBool spSetPlayCommand(char *format)
{
    int i;
    char c, prev_c;
    
    if (!strnone(format)) {
	prev_c = NUL;
	for (i = 0;; i++) {
	    c = format[i];
	    if (c == NUL) {
		break;
	    } else if (c == '\\') {
		c = format[++i];
	    } else if (c == '%' && prev_c != '%') {
		c = format[++i];
		switch (c) {
		  case 'W':	/* Wav file */
		    sp_play_use_wav = SP_TRUE;
		    break;
		  case 'F':
		  case 's':
		    sp_play_use_wav = SP_FALSE;
		    break;
		  default:
		    c = '%';
		    i--;
		}
	    }
	    prev_c = c;
	}
	
	strcpy(sp_play_command, format);
	sp_play_func = spPlayFile_Option;
	
	spDebug(10, "spSetPlayCommand", "%s\n", format);
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPlayFile(char *filename, int num_channel, double samp_rate)
{
    spBool flag;
    
    if (sp_play_func == NULL) {
	if (sp_play_use_dat_link == SP_TRUE) {
	    sp_play_func = spPlayRawFile_DatLink;
	    sp_play_use_wav = SP_FALSE;
	} else {
#if defined(SGI)
	    sp_play_func = spPlayRawFile_SGI;
	    sp_play_use_wav = SP_FALSE;
#elif defined(DEC)
	    sp_play_func = spPlayRawFile_DEC;
	    sp_play_use_wav = SP_FALSE;
#elif defined(sun)
	    sp_play_func = spPlayRawFile_Sun;
	    sp_play_use_wav = SP_FALSE;
#elif defined(_WIN32)
	    sp_play_func = spPlayWavFile_Win;
	    sp_play_use_wav = SP_TRUE;
#else
	    return SP_FALSE;
#endif
	}
    }
    
    /* execute play command */
    flag = (*(sp_play_func))(filename, num_channel, samp_rate);

    return flag;
}
