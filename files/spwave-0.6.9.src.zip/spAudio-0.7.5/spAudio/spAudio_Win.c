/*
 *	spAudio_Win.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spWaveP.h>
#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(_WIN32)
#include <stdio.h>
#include <stdlib.h>

#include "spAudio_WinArch.h"

spBool spInitAudioArch(spAudio audio)
{
    audio->input_audio = NULL;
    audio->output_audio = NULL;
    audio->samp_byte = sizeof(short);
    
    return SP_TRUE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioBufferSizeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    audio->num_buffer = MAX(audio->num_buffer, 32);
    return SP_TRUE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
    if (audio->input_audio != NULL) return SP_FALSE;

    audio->input_audio = spInitAudio_Win(audio->num_buffer, audio->buffer_size);
    
    if (spOpenAudioDevice_Win(audio->input_audio, audio->samp_bit, audio->num_channel,
			      audio->samp_rate, audio->block_mode == SP_AUDIO_NONBLOCKING,
			      SP_FALSE) == SP_FALSE) {
	spFreeAudio_Win(audio->input_audio);
	audio->input_audio = NULL;
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
    if (audio->output_audio != NULL) return SP_FALSE;

    audio->output_audio = spInitAudio_Win(audio->num_buffer, audio->buffer_size);
    
    if (spOpenAudioDevice_Win(audio->output_audio, audio->samp_bit, audio->num_channel,
			      audio->samp_rate, audio->block_mode == SP_AUDIO_NONBLOCKING,
			      SP_TRUE) == SP_FALSE) {
	spFreeAudio_Win(audio->output_audio);
	audio->output_audio = NULL;
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    if (audio->input_audio == NULL && audio->output_audio == NULL) {
	return SP_FALSE;
    }
    
    if (audio->input_audio != NULL) {
	spCloseAudioDevice_Win(audio->input_audio);
	spFreeAudio_Win(audio->input_audio);
	audio->input_audio = NULL;
    }
    if (audio->output_audio != NULL) {
	spCloseAudioDevice_Win(audio->output_audio);
	spFreeAudio_Win(audio->output_audio);
	audio->output_audio = NULL;
    }

    return SP_TRUE;
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    if (audio->input_audio == NULL) return -1;
    
    return spReadWave_Win(audio->input_audio, data, length);
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    if (audio->output_audio == NULL) return -1;
    
    return spWriteWave_Win(audio->output_audio, data, length);
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    return spGetAudioOutputPosition_Win(audio->output_audio, position);
}

spBool spStopAudioArch(spAudio audio)
{
    spResetDevice_Win(audio->input_audio);
    spResetDevice_Win(audio->output_audio);
    
    return SP_TRUE;
}

spBool spSyncAudioArch(spAudio audio)
{
    spSyncDevice_Win(audio->input_audio);
    spSyncDevice_Win(audio->output_audio);

    return SP_TRUE;
}

spBool spFreeAudioArch(spAudio audio)
{
    return SP_TRUE;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
