/*
 *	spAudio_Sun.c:	Audio I/O for solaris
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(sun)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/fcntl.h>

spBool spInitAudioArch(spAudio audio)
{
    audio->samp_byte = sizeof(short);
    audio->input_fd = -1;
    audio->output_fd = -1;
    
    return SP_TRUE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioBufferSizeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    if (audio->block_mode == SP_AUDIO_NONBLOCKING) {
	return SP_FALSE;
    }
    return SP_TRUE;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
#if 1
    if (audio->output_fd >= 0) {
	/* full duplex is not supported yet. */
	return SP_FALSE;
    }
#endif
	
    if (audio->input_fd < 0) {
	if ((audio->input_fd = open("/dev/audio", O_RDONLY, 0)) < 0) {
	    return SP_FALSE;
	}

	if (ioctl(audio->input_fd, AUDIO_GETINFO, &audio->audio_info) != -1) {
	    audio->audio_info.record.sample_rate = (int)audio->samp_rate;
	    audio->audio_info.record.channels = audio->num_channel;
#ifdef AUDIO_ENCODING_LINEAR8
	    if (audio->samp_bit <= 8) {
		audio->audio_info.record.encoding = AUDIO_ENCODING_LINEAR8;
		audio->audio_info.record.precision = 8;
	    } else {
		audio->audio_info.record.encoding = AUDIO_ENCODING_LINEAR;
		audio->audio_info.record.precision = audio->samp_bit;
	    }
#else
	    audio->audio_info.record.encoding = AUDIO_ENCODING_LINEAR;
	    audio->audio_info.record.precision = audio->samp_bit;
#endif

	    if (ioctl(audio->input_fd, AUDIO_SETINFO, &audio->audio_info) == -1) {
		spDebug(1, NULL, "can't set audio info: fd = %d\n",
			audio->input_fd);
	    }
	}
    }
    
    return SP_TRUE;
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
#if 1
    if (audio->input_fd >= 0) {
	/* full duplex is not supported yet. */
	return SP_FALSE;
    }
#endif
	
    if (audio->output_fd < 0) {
	if ((audio->output_fd = open("/dev/audio", O_WRONLY, 0)) < 0) {
	    return SP_FALSE;
	}

	if (ioctl(audio->output_fd, AUDIO_GETINFO, &audio->audio_info) != -1) {
	    audio->audio_info.play.sample_rate = (int)audio->samp_rate;
	    audio->audio_info.play.channels = audio->num_channel;
#ifdef AUDIO_ENCODING_LINEAR8
	    if (audio->samp_bit <= 8) {
		audio->audio_info.play.encoding = AUDIO_ENCODING_LINEAR8;
		audio->audio_info.play.precision = 8;
	    } else {
		audio->audio_info.play.encoding = AUDIO_ENCODING_LINEAR;
		audio->audio_info.play.precision = audio->samp_bit;
	    }
#else
	    audio->audio_info.play.encoding = AUDIO_ENCODING_LINEAR;
	    audio->audio_info.play.precision = audio->samp_bit;
#endif

	    if (ioctl(audio->output_fd, AUDIO_SETINFO, &audio->audio_info) == -1) {
		spDebug(1, NULL, "can't set audio info: fd = %d\n",
			audio->output_fd);
	    }
	}
    }
    
    return SP_TRUE;
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    if (audio->input_fd >= 0 || audio->output_fd >= 0) {
	if (audio->output_fd >= 0 && audio->input_fd != audio->output_fd) {
	    close(audio->output_fd);
	}
	if (audio->input_fd >= 0) {
	    close(audio->input_fd);
	}
    }
    audio->input_fd = -1;
    audio->output_fd = -1;
    
    return SP_TRUE;
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    long count;
    long nremain;
    
    if (audio->input_fd == -1) return -1;

    if (audio->block_mode == SP_AUDIO_NONBLOCKING) {
	nremain = length * audio->samp_byte;
	count = read(audio->input_fd, data, nremain);
	if (count < 0) return -1;
    } else {
	char *p;
	long nread;

	count = 0;
	nremain = length * audio->samp_byte;
	p = (char *)data;
	
	while (nremain > 0) {
	    nread = read(audio->input_fd, p, nremain);
	    if (nread < 0) return -1;

	    count += nread;
	    nremain -= nread;
	    p += nread;
	}
    }
	
    return (count / (long)audio->samp_byte);
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    long count;
    long nremain;

    if (audio->output_fd == -1) return -1;
    
    nremain = length * audio->samp_byte;
    count = write(audio->output_fd, data, nremain);
    if (count < 0) return -1;
    
    return (count / (long)audio->samp_byte);
}

spBool spStopAudioArch(spAudio audio)
{
    return SP_FALSE;
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    return SP_FALSE;
}

spBool spSyncAudioArch(spAudio audio)
{
    if (audio->input_fd >= 0 || audio->output_fd >= 0) {
	if (audio->output_fd >= 0 && audio->input_fd != audio->output_fd) {
	    if (ioctl(audio->output_fd, I_FLUSH, FLUSHRW) == -1) {
		spDebug(1, NULL, "can't flush device: fd = %d\n", audio->output_fd);
	    }
	}
	
	if (audio->input_fd >= 0) {
	    if (ioctl(audio->input_fd, I_FLUSH, FLUSHRW) == -1) {
		spDebug(1, NULL, "can't flush device: fd = %d\n", audio->input_fd);
	    }
	}
    }
    
    return SP_TRUE;
}

spBool spFreeAudioArch(spAudio audio)
{
    return SP_TRUE;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
