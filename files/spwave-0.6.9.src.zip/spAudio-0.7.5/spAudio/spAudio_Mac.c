/*
 *	spAudio_Mac.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>

#include <sp/spAudioP.h>

#if defined(SP_SUPPORT_AUDIO) && defined(MACOS)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#if defined(MACOSX)
#include <Carbon/Carbon.h>
#else
#include <Sound.h>
#include <Memory.h>
#include <Gestalt.h>
#endif

#define SP_MAC_SUPPORT_AUDIO_INPUT

#if defined(MACOSX)
#include <pthread.h>

#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
static pthread_mutex_t recMutex;
#endif
#endif

#define SP_MAC_AUDIO_SLEEP_TIME 3

#define SP_MAC_AUDIO_STATE_NORMAL 0
#define SP_MAC_AUDIO_STATE_CLOSE 1
#define SP_MAC_AUDIO_STATE_STOP 2

static spBool getSampleRateId(long samp_rate, UnsignedFixed *id)
{
    if (ABS(samp_rate - 48000) <= 100) {
	*id = rate48khz;
    } else if (ABS(samp_rate - 44100) <= 100) {
	*id = rate44khz;
    } else if (ABS(samp_rate - 32000) <= 100) {
	*id = 0x7D000000;	/* Mac OS X supports 32k */
    } else if (ABS(samp_rate - 22255) <= 100) {
	*id = rate22khz;
    } else if (ABS(samp_rate - 22050) <= 100) {
	*id = rate22050hz;
    } else if (ABS(samp_rate - 16000) <= 100) {
	*id = 0x3E800000;	/* Mac OS X supports 16k */
    } else if (ABS(samp_rate - 11127) <= 100 && samp_rate >= 11080) {
	*id = rate11khz;
    } else if (ABS(samp_rate - 11025) <= 100) {
	*id = rate11025hz;
    } else if (ABS(samp_rate - 8000) <= 100) {
	*id = rate8khz;
    } else {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool openConverter(spAudio audio, SoundConverter *sc, SoundComponentData *inputFormat,
			    unsigned long *inputSize, unsigned long *inputFrames, long *outputSize)
{
    SoundComponentData outputFormat;
    UnsignedFixed sampleRate;
    unsigned long buffSize;

    if (getSampleRateId((long)spRound(audio->samp_rate), &sampleRate) == SP_FALSE) {
	return SP_FALSE;
    }
    
    outputFormat.flags = 0;
    outputFormat.format = k16BitBigEndianFormat;
    outputFormat.numChannels = audio->num_channel;
    outputFormat.sampleSize = audio->samp_bit;
    outputFormat.sampleRate = sampleRate;
    outputFormat.sampleCount = 0;
    outputFormat.buffer = nil;
    outputFormat.reserved = 0;
    
    if (SoundConverterOpen(inputFormat, &outputFormat, sc) != noErr) {
	*sc = nil;
	return SP_FALSE;
    }

    if (SoundConverterGetBufferSizes(*sc, *inputSize, inputFrames,
				     &buffSize, (unsigned long *)outputSize) != noErr) {
	SoundConverterClose(*sc);
	*sc = nil;
	return SP_FALSE;
    }
    spDebug(1, "openConverter", "inputSize = %ld, buffSize = %ld, outputSize = %ld\n",
	    *inputSize, buffSize, *outputSize);
    *inputSize = buffSize;
    
    if (SoundConverterBeginConversion(*sc) != noErr) {
	SoundConverterClose(*sc);
	*sc = nil;
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static long executeConvert(spAudio audio, SoundConverter *sc, char *inputBuffer,
			   unsigned long inputFrames, char *outputBuffer)
{
    unsigned long outputFrames, bufferSize;
    
    bufferSize = 0;
    if (SoundConverterConvertBuffer(*sc, inputBuffer, inputFrames,
				    outputBuffer, &outputFrames, &bufferSize) != noErr) {
	return -1;
    }

    return bufferSize;
}

static spBool closeConverter(spAudio audio, SoundConverter *sc, char *outputBuffer)
{
    unsigned long outputBytes, outputFrames;

    SoundConverterEndConversion(*sc, outputBuffer, &outputFrames, &outputBytes);
    SoundConverterClose(*sc);
    *sc = nil;

    if (outputBytes > 0) {
	/* we ignore this, though we should save obtained buffer. */
    }
    
    return SP_TRUE;
}

#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
pascal void siCompletionProc(SPBPtr pspb)
{
    spAudio audio;
    long bufferSize;
    
    audio = (spAudio)pspb->userLong;
    
    if (pspb->error < 0 || audio == NULL || audio->recOffset < 0) return;

#if defined(MACOSX)
    pthread_mutex_lock(&recMutex);
#endif
	
    if (audio->recDataFilled + audio->recBufferSize <= audio->recDataSize) {
	if (audio->recsc != nil) {
	    if ((bufferSize = executeConvert(audio, &audio->recsc, audio->recConvBuffer, audio->recConvInputFrames,
					     audio->recConvOutputBuffer)) > 0) {
		if (audio->recOffset + bufferSize >= audio->recDataSize) {
		    long offset;
		    offset = audio->recDataSize - audio->recOffset;
		    BlockMove(audio->recConvOutputBuffer, audio->recDataBuffer + audio->recOffset, offset);
		    audio->recOffset = bufferSize - offset;
		    if (audio->recOffset > 0) {
			BlockMove(audio->recConvOutputBuffer + offset, audio->recDataBuffer, audio->recOffset);
		    }
		} else {
		    BlockMove(audio->recConvOutputBuffer, audio->recDataBuffer + audio->recOffset, bufferSize);
		    audio->recOffset += bufferSize;
		}
	    }
	} else {
	    bufferSize = audio->recBufferSize;
	    
	    audio->recOffset += bufferSize;
	    if (audio->recOffset >= audio->recDataSize) {
		audio->recOffset = 0;
	    }
	    pspb->bufferPtr = (audio->recDataBuffer + audio->recOffset);
	    pspb->count = bufferSize;
	    pspb->bufferLength = bufferSize;
	    pspb->milliseconds = 0;
	}
	spDebug(100, "siCompletionProc", "recOffset = %ld, recBufferSize = %ld/%ld, bufferSize = %ld\n",
		audio->recOffset, audio->recBufferSize, audio->recDataSize, bufferSize);
	
	audio->recDataFilled += bufferSize;
	spDebug(100, "siCompletionProc", "recDataFilled = %ld\n", audio->recDataFilled);
	audio->recStarted = SP_TRUE;
    } else {
	audio->recStarted = SP_FALSE;
    }

#if defined(MACOSX)
    pthread_mutex_unlock(&recMutex);
#endif
    
    if (audio->recStarted == SP_FALSE || SPBRecord(pspb, true) != noErr) {
	/* error */
    }
    
    return;
}
#endif

long getNumFrames(spAudio audio, long size)
{
    return 8 * size / (long)(audio->num_channel * audio->samp_bit);
}

#if defined(SP_MAC_USE_DOUBLE_BUFFER)
static long copyDoubleBackData(SndDoubleBufferPtr doubleBuffer, spAudio audio)
{
    long copySize;
    long k;
    long length;
    short *sdata;
    char *data;

    /*if (audio->playOffset > audio->playDataOffset) {*/
    if (audio->playOffset >= audio->playDataOffset) {
	copySize = audio->playDataSize - audio->playOffset;
    } else {
	copySize = audio->playDataOffset - audio->playOffset;
    }
    
    if (copySize > audio->buffer_size) {
	copySize = audio->buffer_size;
    }

    if (copySize > 0) {
	if (audio->samp_bit == 16 && !audio->support_16bit) {
	    length = copySize / 2;
	    sdata = (short *)(audio->playDataBuffer + audio->playOffset);
	    data = (char *)&doubleBuffer->dbSoundData[0];
	    for (k = 0; k < length; k++) {
		data[k] = (char)(sdata[k] / 256);
	    }
	    doubleBuffer->dbNumFrames = length;
	} else {
	    BlockMove(audio->playDataBuffer + audio->playOffset, &doubleBuffer->dbSoundData[0], copySize);
	    if (audio->samp_bit == 16) {
		doubleBuffer->dbNumFrames = copySize / 2;
	    } else {
		doubleBuffer->dbNumFrames = copySize;
	    }
	}
	doubleBuffer->dbNumFrames /= MAX(1, audio->num_channel);
    } else {
	doubleBuffer->dbNumFrames = 0;
    }
    
    doubleBuffer->dbFlags |= dbBufferReady;
    
    return copySize;
}

pascal void sndDoubleBackProc(SndChannelPtr chan, SndDoubleBufferPtr doubleBuffer)
{
    long copySize;
    spAudio audio;

    audio = (spAudio)doubleBuffer->dbUserInfo[0];

    if ((copySize = copyDoubleBackData(doubleBuffer, audio)) > 0) {
	audio->playOffset += copySize;
	if (audio->playOffset >= audio->playDataSize) {
	    audio->playOffset = 0;
	}
	audio->playDataFilled -= copySize;
	audio->playDataFilled = MAX(audio->playDataFilled, 0);
    }

    if (audio->state != SP_MAC_AUDIO_STATE_NORMAL) {
	if (audio->state == SP_MAC_AUDIO_STATE_STOP
	    || audio->playDataFilled <= 0) {
	    doubleBuffer->dbFlags |= dbLastBuffer;
	}
    }

    return;
}

static void initDoubleBackProc(SndChannelPtr chan, SndDoubleBufferPtr doubleBuffer)
{
    long copySize;
    spAudio audio;

    audio = (spAudio)doubleBuffer->dbUserInfo[0];

    if ((copySize = copyDoubleBackData(doubleBuffer, audio)) > 0) {
	audio->playDataFilled += copySize;
    }

    return;
}
#else
#if defined(MACOSX)
static pthread_mutex_t mainMutex;
static pthread_mutex_t playMutex;
static spBool play_mutex_locked = SP_FALSE;
#endif

static long copyBufferData(spAudio audio)
{
    long copySize;
    SndCommand cmd;

#if defined(MACOSX)
    if (play_mutex_locked == SP_TRUE) {
	pthread_mutex_unlock(&playMutex);
	play_mutex_locked = SP_FALSE;
    }
#endif

    spDebug(80, "copyBufferData", "playDataOffset = %ld, playOffset = %ld, playDataFilled = %ld\n",
	    audio->playDataOffset, audio->playOffset, audio->playDataFilled);
    /*if (audio->playOffset > audio->playDataOffset) {*/
    if (audio->playOffset >= audio->playDataOffset) {
	copySize = audio->playDataSize - audio->playOffset;
    } else {
	copySize = audio->playDataOffset - audio->playOffset;
    }
    copySize = MIN(copySize, audio->playDataFilled);
    copySize = MIN(copySize, audio->buffer_size);
    spDebug(80, "copyBufferData", "copySize = %ld\n", copySize);

    if (copySize > 0) {
	BlockMoveData(audio->playDataBuffer + audio->playOffset, audio->sndHeader->samplePtr, copySize);
	audio->sndHeader->numFrames = getNumFrames(audio, copySize);
    } else {
	spDebug(10, "copyBufferData", "copySize = %ld\n", copySize);
	BlockZero(audio->sndHeader->samplePtr, audio->buffer_size);
	audio->sndHeader->numFrames = getNumFrames(audio, audio->buffer_size);
    }
	
    cmd.cmd = bufferCmd;
    cmd.param1 = 0;
    cmd.param2 = (long)audio->sndHeader;
    SndDoCommand(audio->sndChannel, &cmd, true);

    if (copySize > 0) {
	audio->playOffset += copySize;
	if (audio->playOffset >= audio->playDataSize) {
	    audio->playOffset = 0;
	}
	audio->playDataFilled -= copySize;
	audio->playDataFilled = MAX(audio->playDataFilled, 0);
    }

    if (audio->playDataFilled > 0
	|| audio->playState != SP_MAC_AUDIO_STATE_CLOSE) {
	cmd.cmd = callBackCmd;
	cmd.param1 = 0;
	cmd.param2 = (long)audio;
	SndDoCommand(audio->sndChannel, &cmd, true);
	
	spDebug(80, "copyBufferData", "done: playOffset = %ld, playDataFilled = %ld\n",
		audio->playOffset, audio->playDataFilled);
	
#if defined(MACOSX)
	if (play_mutex_locked == SP_TRUE) {
	    spDebug(10, "copyBufferData", "************ warning: playMutex already locked\n");
	}
	pthread_mutex_lock(&playMutex);
	play_mutex_locked = SP_TRUE;
#endif
    }
	
    return copySize;
}

pascal void sndCallBackProc(SndChannelPtr chan, SndCommand *cmd)
{
    long copySize;
    spAudio audio;

    audio = (spAudio)cmd->param2;

#if defined(MACOSX)
    pthread_mutex_lock(&mainMutex);
#endif
    
    copySize = copyBufferData(audio);
    
#if defined(MACOSX)
    pthread_mutex_unlock(&mainMutex);
#endif

#if 0
    if (copySize <= 0) {
	spMSleep(SP_MAC_AUDIO_SLEEP_TIME);
    }
#endif
    
    return;
}
#endif

static spBool startPlay(spAudio audio)
{
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    if (SndPlayDoubleBuffer(audio->sndChannel, audio->sndDoubleHeader) !=  noErr) {
	spDebug(1, "startPlay", "SndPlayDoubleBuffer error.\n");
	return SP_FALSE;
    }
#else
    if (copyBufferData(audio) < 0) {
	return SP_FALSE;
    }
#endif
    audio->playState = SP_MAC_AUDIO_STATE_NORMAL;
    spDebug(50, "startPlay", "done: state = %d\n", audio->playState);

    return SP_TRUE;
}

static spBool waitAudioOutput(spAudio audio, spBool wait_all)
{
    SCStatus stats;

    if (audio->sndChannel == nil) return SP_FALSE;

    if (audio->playState == SP_MAC_AUDIO_STATE_STOP) {
	return SP_TRUE;
    }
    
#if !defined(SP_MAC_USE_DOUBLE_BUFFER) && defined(MACOSX)
    if (audio->playState == SP_MAC_AUDIO_STATE_NORMAL && wait_all == SP_FALSE) {
	return SP_TRUE;
    }
#endif
    
    spDebug(80, "waitAudioOutput", "in\n");

    do {
	if (SndChannelStatus(audio->sndChannel, sizeof(stats), &stats) != noErr) {
	    return SP_FALSE;
	}
	if (audio->playState == SP_MAC_AUDIO_STATE_NORMAL) {
	    spDebug(80, "waitAudioOutput", "playDataFilled = %ld\n",
		    audio->playDataFilled);
	    if (wait_all == SP_TRUE) {
		if (audio->playDataFilled <= 0) {
		    break;
		}
	    } else {
		if (audio->playDataFilled <= audio->playDataSize - audio->buffer_size) {
		    break;
		}
	    }
	} else if (audio->playState == SP_MAC_AUDIO_STATE_STOP) {
	    break;
	}
	spMSleep(SP_MAC_AUDIO_SLEEP_TIME);
    } while (stats.scChannelBusy);

    spDebug(80, "waitAudioOutput", "done\n");
    
    return SP_TRUE;
}

spBool spInitAudioArch(spAudio audio)
{
    long response;

    if (Gestalt(gestaltSoundAttr, &response) != noErr) {
	spDebug(1, "spInitAudioArch", "Gestalt error.\n");
	return SP_FALSE;
    }
#if TARGET_API_MAC_CARBON || !defined(SP_MAC_USE_DOUBLE_BUFFER)
    audio->support_output = 1;
#else
    if (!(response & (1 << gestaltSndPlayDoubleBuffer))) {
	spDebug(1, "spInitAudioArch", "SndPlayDoubleBuffer not supported.\n");
	audio->support_output = 0;
	return SP_FALSE;
    } else {
	audio->support_output = 1;
    }
#endif
    
    if (!(response & (1 << gestalt16BitSoundIO))) {
	spDebug(1, "spInitAudioArch", "16BitSoundIO not supported.\n");
	audio->support_16bit = 0;
    } else {
	audio->support_16bit = 1;
    }
    if (!(response & (1 << gestaltStereoCapability))) {
	spDebug(1, "spInitAudioArch", "stereo output not supported.\n");
	audio->stereo_output = 0;
    } else {
	audio->stereo_output = 1;
    }
    if (!(response & (1 << gestaltHasSoundInputDevice))) {
	spDebug(1, "spInitAudioArch", "sound input not available.\n");
	audio->support_input = 0;
    } else {
	audio->support_input = 1;
    }
    if (!(response & (1 << gestaltStereoInput))) {
	spDebug(1, "spInitAudioArch", "stereo sound input not supported.\n");
	audio->stereo_input = 0;
    } else {
	audio->stereo_input = 1;
    }

    audio->sndChannel = nil;
    audio->sndHeader = nil;
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    audio->sndDoubleHeader = nil;
#if TARGET_API_MAC_CARBON
    audio->sndDoubleBackUPP = sndDoubleBackProc;
#else
    audio->sndDoubleBackUPP = NewSndDoubleBackProc(sndDoubleBackProc);
#endif
#else
    audio->sndCallBackUPP = NewSndCallBackUPP(sndCallBackProc);
#if defined(MACOSX)
    pthread_mutex_init(&mainMutex, NULL);
    pthread_mutex_init(&playMutex, NULL);
    play_mutex_locked = SP_FALSE;
#endif
#endif
    
    audio->playDataSize = 0;
    audio->playDataBuffer = nil;
    
    audio->playState = SP_MAC_AUDIO_STATE_STOP;
    audio->playOffset = 0;
    audio->playDataOffset = 0;
    audio->playDataFilled = 0;
    
#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
    audio->refNum = 0;
    audio->recBufferSize = 0;
    audio->recDataSize = 0;
    audio->recDataBuffer = nil;
    
    audio->recStarted = SP_FALSE;
    audio->recOffset = 0;
    audio->recDataOffset = 0;
    audio->recDataFilled = 0;
    
    audio->pspb = nil;
    audio->siCompletionUPP = nil;

    audio->recsc = nil;
    audio->recConvInputFrames = 0;
    audio->recConvBufferSize = 0;
    audio->recConvBuffer = nil;
    audio->recConvOutputBuffer = nil;
    
#if defined(MACOSX)
    pthread_mutex_init(&recMutex, NULL);
#endif
    
    audio->pspb = (SPBPtr)NewPtrClear(sizeof(SPB));
    audio->siCompletionUPP = NewSICompletionUPP(siCompletionProc);

    /* open sound input device */
    if (SPBOpenDevice(nil, siWritePermission, &audio->refNum) != noErr) {
	audio->refNum = 0;
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBOpenDevice failed\n");
	/*return SP_FALSE;*/
    }
    spDebug(1, "spInitAudioArch", "refNum of opened device: %ld\n", audio->refNum);
#endif
    
    return SP_TRUE;
}

spBool spSetAudioSampleRateArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioChannelArch(spAudio audio)
{
    return SP_TRUE;
}

/* size is in bytes */
spBool spSetAudioBufferSizeArch(spAudio audio)
{
    return SP_TRUE;
}

spBool spSetAudioNumBufferArch(spAudio audio)
{
    audio->num_buffer = MAX(audio->num_buffer, 2);
    return SP_FALSE;
}

spBool spSetAudioBlockingModeArch(spAudio audio)
{
    return SP_TRUE;
}

static spBool closeInputDevice(spAudio audio)
{
    spBool flag = SP_TRUE;

#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
    if (audio->refNum != 0) {
	short recordingStat, meterlevel;
	unsigned long totalSamples, numberOfSamples, totalMSec, numberOfMSec;
	
	spDebug(1, "closeInputDevice", "close device\n");

	if (audio->recOffset >= 0
	    && SPBGetRecordingStatus(audio->refNum, &recordingStat, &meterlevel,
				     &totalSamples, &numberOfSamples, &totalMSec, &numberOfMSec) == noErr) {
	    spDebug(1, "closeInputDevice", "recordingStat = %d, meterLevel = %d\n", recordingStat, meterlevel);
	    spDebug(1, "closeInputDevice", "totalSamples = %ld, numberOfSamples = %ld\n", totalSamples, numberOfSamples);
	    if (recordingStat > 0) {
		SPBStopRecording(audio->refNum);
	    }
	}
    }
    audio->recOffset = -1;
    audio->recStarted = SP_FALSE;

    if (audio->recsc != nil) {
	closeConverter(audio, &audio->recsc, audio->recDataBuffer);
	audio->recsc = nil;

	if (audio->recConvBuffer != nil) {
	    DisposePtr(audio->recConvBuffer);
	    audio->recConvBuffer = nil;
	}
	if (audio->recConvOutputBuffer != nil) {
	    DisposePtr(audio->recConvOutputBuffer);
	    audio->recConvOutputBuffer = nil;
	}
    }
    
    if (audio->recDataBuffer != nil) {
	DisposePtr(audio->recDataBuffer);
	audio->recDataBuffer = nil;
    }
    
    spDebug(1, "closeInputDevice", "done\n");
#endif
    
    return flag;
}

static spBool closeOutputDevice(spAudio audio)
{
    spBool flag = SP_TRUE;

    spDebug(10, "closeOutputDevice", "in\n");
    
    /* dispose audio channel */
    if (audio->sndChannel != nil) {
#if !defined(SP_MAC_USE_DOUBLE_BUFFER)
	if (audio->playDataFilled > 0 && audio->playState == SP_MAC_AUDIO_STATE_STOP) {
	    /* not played yet */
	    startPlay(audio);
	}
#endif
	
	audio->playState = SP_MAC_AUDIO_STATE_CLOSE;
	flag = waitAudioOutput(audio, SP_TRUE);

	if (SndDisposeChannel(audio->sndChannel, true) != noErr) {
	    flag = SP_FALSE;
	}
	audio->sndChannel = nil;
    }

    /* dispose header */
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    if (audio->sndDoubleHeader != nil) {
	int i;
	
	for (i = 0; i <= 1; i++) {
	    if (audio->sndDoubleHeader->dbhBufferPtr[i] != nil) {
		DisposePtr((Ptr)audio->sndDoubleHeader->dbhBufferPtr[i]);
	    }
	}
	DisposePtr((Ptr)audio->sndDoubleHeader);
	audio->sndDoubleHeader = nil;
    }
#endif
    if (audio->sndHeader != nil) {
#if !defined(SP_MAC_USE_DOUBLE_BUFFER)
	if (audio->sndHeader->samplePtr != nil) {
	    DisposePtr(audio->sndHeader->samplePtr);
	}
#endif
	DisposePtr((Ptr)audio->sndHeader);
	audio->sndHeader = nil;
    }

    /* dispose data buffer */
    if (audio->playDataBuffer != nil) {
	DisposePtr(audio->playDataBuffer);
	audio->playDataBuffer = nil;
    }

    spDebug(10, "closeOutputDevice", "done: flag = %d\n", flag);
    
    return flag;
}

spBool spOpenInputAudioDeviceArch(spAudio audio)
{
#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
    spBool convert_flag = SP_FALSE;
    short flag;
    UnsignedFixed sampleRate;
    short sampleSize;
    OSType compression;
    short numberOfChannels;
    long internalBuffer;
    SPBPtr pspb;
    short voxParams[3] = {0,0,0};

    if (audio->refNum == 0) return SP_FALSE;
    
    audio->recStarted = SP_FALSE;
    audio->recOffset = -1;
    audio->recDataBuffer = nil;
    
    audio->recsc = nil;
    audio->recConvBuffer = nil;
    audio->recConvOutputBuffer = nil;
    
    flag = 1;
    if (SPBSetDeviceInfo(audio->refNum, siContinuous, (Ptr)&flag) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBSetDeviceInfo of siContinuous failed\n");
	closeInputDevice(audio);
	return SP_FALSE;
    }

    /* set sample rate */
    spDebug(1, "spOpenInputAudioDeviceArch", "audio->samp_rate = %f\n", audio->samp_rate);
    if (getSampleRateId((long)spRound(audio->samp_rate), &sampleRate) == SP_FALSE) {
	spDebug(1, "spOpenInputAudioDeviceArch", "Sample rate %f not supported.\n", audio->samp_rate);
	closeInputDevice(audio);
	return SP_FALSE;
    }
#if 0	/* the following code causes crash when an external microphone is connected */
    if (SPBSetDeviceInfo(audio->refNum, siSampleRate, (Ptr)&sampleRate) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBSetDeviceInfo of siSampleRate failed\n");
	SPBGetDeviceInfo(audio->refNum, siSampleRate, (Ptr)&sampleRate);
	convert_flag = SP_TRUE;
    }
#else
    {
	UnsignedFixed deviceSampleRate = rate44khz;
	
	SPBGetDeviceInfo(audio->refNum, siSampleRate, (Ptr)&deviceSampleRate);
	if (deviceSampleRate != sampleRate) {
	    convert_flag = SP_TRUE;
	    sampleRate = deviceSampleRate;
	}
    }
#endif
    spDebug(1, "spOpenInputAudioDeviceArch", "sampleRate = %ld\n", sampleRate);

    /* set sample size */
    sampleSize = 16;
    if (SPBSetDeviceInfo(audio->refNum, siSampleSize, (Ptr)&sampleSize) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBSetDeviceInfo of siSampleSize failed\n");
	SPBGetDeviceInfo(audio->refNum, siSampleSize, (Ptr)&sampleSize);
	convert_flag = SP_TRUE;
    }
		
    /* set compression type */
    compression = 'NONE';
    if (SPBSetDeviceInfo(audio->refNum, siCompressionType, (Ptr)&compression) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBSetDeviceInfo of siCompressionType failed\n");
	SPBGetDeviceInfo(audio->refNum, siCompressionType, (Ptr)&compression);
	convert_flag = SP_TRUE;
    }
		
    /* set number of channels */
    numberOfChannels = audio->num_channel;
    if (SPBSetDeviceInfo (audio->refNum, siNumberChannels, (Ptr)&numberOfChannels) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBSetDeviceInfo of siNumberChannels failed\n");
	SPBGetDeviceInfo(audio->refNum, siNumberChannels, (Ptr)&numberOfChannels);
	convert_flag = SP_TRUE;
    }
		
    /* set vox parameters */
    SPBSetDeviceInfo (audio->refNum, siVoxRecordInfo, (Ptr)voxParams);
    SPBSetDeviceInfo (audio->refNum, siVoxStopInfo, (Ptr)voxParams);
    
    /* get internal buffer size */
    internalBuffer = audio->buffer_size;
    SPBSetDeviceInfo (audio->refNum, siDeviceBufferInfo, (Ptr) &internalBuffer);
    if (SPBGetDeviceInfo (audio->refNum, siDeviceBufferInfo, (Ptr) &internalBuffer) != noErr) {
	spDebug(1, "spOpenInputAudioDeviceArch", "SPBGetDeviceInfo of siDeviceBufferInfo failed\n");
	closeInputDevice(audio);
	return SP_FALSE;
    }
    spDebug(1, "spOpenInputAudioDeviceArch", "internalBuffer = %ld\n", internalBuffer);
    internalBuffer = MAX(8, internalBuffer);

    if (convert_flag == SP_TRUE) {
	/* open converter */
	SoundComponentData inputFormat;

	audio->recConvBufferSize = MAX((long)audio->buffer_size / internalBuffer, 1) * internalBuffer;
	
	inputFormat.flags = 0;
	inputFormat.format = compression;
	inputFormat.numChannels = numberOfChannels;
	inputFormat.sampleSize = sampleSize;
	inputFormat.sampleRate = sampleRate;
	inputFormat.sampleCount = 0;
	inputFormat.buffer = nil;
	inputFormat.reserved = 0;

	audio->recsc = nil;
	if (openConverter(audio, &audio->recsc, &inputFormat, &audio->recConvBufferSize,
			  &audio->recConvInputFrames, &audio->recBufferSize) == SP_FALSE) {
	    spDebug(1, "spOpenInputAudioDeviceArch", "openConverter failed\n");
	    closeInputDevice(audio);
	    return SP_FALSE;
	}
	spDebug(1, "spOpenInputAudioDeviceArch", "recConvBufferSize = %ld\n", audio->recConvBufferSize);
	audio->recConvBuffer = NewPtrClear(audio->recConvBufferSize);
	audio->recConvOutputBuffer = NewPtrClear(audio->recBufferSize);
	if (MemError() != noErr || audio->recConvBuffer == nil || audio->recConvOutputBuffer == nil) {
	    closeInputDevice(audio);
	    return SP_FALSE;
	}
    } else {
	audio->recsc = nil;
	audio->recBufferSize = MAX((long)audio->buffer_size / internalBuffer, 1) * internalBuffer;
    }
    audio->recDataSize = audio->recBufferSize * MAX(audio->num_buffer, 64);
    spDebug(1, "spOpenInputAudioDeviceArch", "recDataSize = %ld\n", audio->recDataSize);
    audio->recDataBuffer = NewPtrClear(audio->recDataSize);
    if (MemError() != noErr || audio->recDataBuffer == nil) {
	spDebug(1, "spOpenInputAudioDeviceArch", "memory allocation of buffer failed\n");
	closeInputDevice(audio);
	return SP_FALSE;
    }
    spDebug(1, "spOpenInputAudioDeviceArch", "recBufferSize = %ld\n", audio->recBufferSize);

    audio->recDataOffset = 0;
    audio->recDataFilled = 0;
    
    pspb = audio->pspb;
    pspb->inRefNum = audio->refNum;
    pspb->milliseconds = 0;
    if (audio->recsc != nil) {
	pspb->count = audio->recConvBufferSize;
	pspb->bufferLength = (unsigned long)audio->recConvBufferSize;
	pspb->bufferPtr = audio->recConvBuffer;
    } else {
	pspb->count = audio->recBufferSize;
	pspb->bufferLength = (unsigned long)audio->recBufferSize;
	pspb->bufferPtr = audio->recDataBuffer;
    }

    pspb->completionRoutine = audio->siCompletionUPP;
    pspb->interruptRoutine = nil;
    pspb->userLong = (long)audio;
    pspb->error = noErr;

    spDebug(1, "spOpenInputAudioDeviceArch", "done\n");
    
    return SP_TRUE;
#else
    return SP_FALSE;
#endif
}

spBool spOpenOutputAudioDeviceArch(spAudio audio)
{
    UnsignedFixed sampRateId;
    ExtSoundHeaderPtr sndHeader;
    SndCallBackUPP userRoutine = nil;
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    int i;
    SndDoubleBufferHeaderPtr sndDoubleHeader;
    SndDoubleBufferPtr sndDoubleBuffer;
#endif

    audio->sndChannel = nil;
    audio->sndHeader = nil;
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    audio->sndDoubleHeader = nil;
#endif
    audio->playDataBuffer = nil;
    
#if !defined(SP_MAC_USE_DOUBLE_BUFFER)
    userRoutine = audio->sndCallBackUPP;
#endif
    audio->playState = SP_MAC_AUDIO_STATE_STOP;

    /* compute sample rate */
    if (getSampleRateId((long)spRound(audio->samp_rate), &sampRateId) == SP_FALSE) {
	spDebug(1, "spOpenOutputAudioDeviceArch", "Sample rate %f not supported.\n",
		audio->samp_rate);
	return SP_FALSE;
    }

    if (SndNewChannel(&audio->sndChannel, sampledSynth, 0, userRoutine) != noErr) {
	spDebug(1, "spOpenOutputAudioDeviceArch", "SndNewChannel error.\n");
	return SP_FALSE;
    }
    
    spDebug(10, "spOpenOutputAudioDeviceArch", "SndNewChannel done\n");

    /* allocate buffer */
    audio->playDataSize = audio->buffer_size * audio->num_buffer;
    audio->playDataBuffer = NewPtrClear(audio->playDataSize);
    if (MemError() != noErr || audio->playDataBuffer == nil) {
	closeOutputDevice(audio);
	return SP_FALSE;
    }

    audio->playOffset = 0;
    audio->playDataOffset = 0;
    audio->playDataFilled = 0;
    
    spDebug(10, "spOpenOutputAudioDeviceArch", "allocate buffer done: num_buffer = %d, playDataSize = %ld\n",
	    audio->num_buffer, audio->playDataSize);
    
    sndHeader = (ExtSoundHeaderPtr)NewPtrClear(sizeof(ExtSoundHeader));
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    sndHeader->samplePtr = audio->playDataBuffer;
    sndHeader->numFrames = getNumFrames(audio, audio->playDataSize);
#else
    sndHeader->samplePtr = NewPtrClear(audio->buffer_size);
    sndHeader->numFrames = getNumFrames(audio, audio->buffer_size);
#endif
    sndHeader->numChannels = audio->num_channel;
    sndHeader->encode = extSH;
    sndHeader->baseFrequency = 60;
    sndHeader->sampleRate = sampRateId;
    sndHeader->sampleSize = audio->samp_bit;
    
    audio->sndHeader = sndHeader;
    spDebug(10, "spOpenOutputAudioDeviceArch", "allocate sndHeader done\n");
    
#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    sndDoubleHeader =
	(SndDoubleBufferHeaderPtr)NewPtrClear(sizeof(SndDoubleBufferHeader));
    sndDoubleHeader->dbhNumChannels = audio->num_channel;
    if (audio->samp_bit == 8 || !audio->support_16bit) {
	sndDoubleHeader->dbhSampleSize = 8;
    } else {
	sndDoubleHeader->dbhSampleSize = 16;
    }
    sndDoubleHeader->dbhCompressionID = 0;
    sndDoubleHeader->dbhPacketSize = 0;
    sndDoubleHeader->dbhSampleRate = sndHeader->sampleRate;
    sndDoubleHeader->dbhBufferPtr[0] = nil;
    sndDoubleHeader->dbhBufferPtr[1] = nil;
    
    sndDoubleHeader->dbhDoubleBack = audio->sndDoubleBackUPP;

    spDebug(10, "spOpenOutputAudioDeviceArch", "allocate sndDoubleHeader done\n");
    
    audio->playDataOffset = audio->buffer_size * 2;
    
    /* initialize buffers */
    for (i = 0; i <= 1; i++) {
	sndDoubleHeader->dbhBufferPtr[i] = nil;
	sndDoubleBuffer = (SndDoubleBufferPtr)NewPtrClear(sizeof(SndDoubleBuffer) +
							  audio->buffer_size);
	if (sndDoubleBuffer == nil || MemError() != 0) {
	    closeOutputDevice(audio);
	    return SP_FALSE;
	}
	
	sndDoubleBuffer->dbNumFrames = 0;
	sndDoubleBuffer->dbFlags = 0;
	sndDoubleBuffer->dbUserInfo[0] = (long)audio;

	initDoubleBackProc(audio->sndChannel, sndDoubleBuffer);
	sndDoubleHeader->dbhBufferPtr[i] = sndDoubleBuffer;
    }

    audio->sndDoubleHeader = sndDoubleHeader;
#endif

    spDebug(10, "spOpenOutputAudioDeviceArch", "done\n");
    
    return SP_TRUE;
}

spBool spCloseAudioDeviceArch(spAudio audio)
{
    spBool flag = SP_TRUE;

    spDebug(10, "spCloseAudioDeviceArch", "in\n");
    
    if (closeInputDevice(audio) == SP_FALSE) {
	flag = SP_FALSE;
    }
    if (closeOutputDevice(audio) == SP_FALSE) {
	flag = SP_FALSE;
    }
    spDebug(10, "spCloseAudioDeviceArch", "done: flag = %d\n", flag);
    
    return flag;
}

long spReadAudioArch(spAudio audio, char *data, long length)
{
    long copySize;
    long totalSize;
    long currentSize;

    if (/*audio->recOffset < 0*/audio->recStarted == SP_FALSE
	&& audio->recDataFilled + audio->recBufferSize <= audio->recDataSize) {
	OSErr err;
	
	spDebug(80, "spReadAudioArch", "restart SPBRecord: recDataFilled = %ld/%ld, recOffset = %ld\n",
		audio->recDataFilled, audio->recDataSize, audio->recOffset);
	
	audio->recStarted = SP_TRUE;
	if (audio->recOffset < 0) {
	    audio->recOffset = 0;
	}

	if ((err = SPBRecord(audio->pspb, true)) != noErr) {
	    spDebug(1, "spReadAudioArch", "SPBRecord failed: %d\n", err);
	    return -1;
	}
    }

    totalSize = length * (audio->samp_bit / 8);
    currentSize = 0;
    spDebug(80, "spReadAudioArch", "totalSize = %ld\n", totalSize);
    
    while (currentSize < totalSize) {
	/* wait until buffer has data */
	while (audio->recDataFilled < audio->recBufferSize) {
	    spMSleep(SP_MAC_AUDIO_SLEEP_TIME);
	    spDebug(100, "spReadAudioArch", "waiting: recDataFilled = %ld/%ld\n",
		    audio->recDataFilled, audio->recBufferSize);
	}
	
	while (audio->recDataFilled >= audio->recBufferSize) {
	    copySize = MIN(audio->recDataSize - audio->recDataOffset, totalSize - currentSize);
	    copySize = MIN(copySize, audio->recBufferSize);
	    if (copySize <= 0) {
		break;
	    }
	    BlockMove(audio->recDataBuffer + audio->recDataOffset, data + currentSize, copySize);
	    spDebug(100, "spReadAudioArch",
		    "loop: copySize = %ld, recDataFilled = %ld, recDataOffset = %ld/%ld\n",
		    copySize, audio->recDataFilled, audio->recDataOffset, audio->recDataSize);
	    
#if defined(MACOSX)
	    pthread_mutex_lock(&recMutex);
#endif

	    audio->recDataFilled -= copySize;
	    
	    if (audio->recDataOffset + copySize >= audio->recDataSize)  {
		audio->recDataOffset = 0;
	    } else {
		audio->recDataOffset += copySize;
	    }
	    
	    currentSize += copySize;
	
#if defined(MACOSX)
	    pthread_mutex_unlock(&recMutex);
#endif
	}
	
	spDebug(100, "spReadAudioArch", "currentSize = %ld, recDataFilled = %ld/%ld\n",
		currentSize, audio->recDataFilled, audio->recDataSize);
	
	if (audio->block_mode == SP_AUDIO_NONBLOCKING
	    && audio->recDataFilled < audio->recBufferSize) {
	    break;
	}
    }
    
    spDebug(80, "spReadAudioArch", "currentSize = %ld\n", currentSize);

    if (currentSize <= 0) {
	return currentSize;
    } else {
	return currentSize / (audio->samp_bit / 8);
    }
}

long spWriteAudioArch(spAudio audio, char *data, long length)
{
    long copySize;
    long totalSize;
    long currentSize;

#if defined(SP_MAC_USE_DOUBLE_BUFFER)
    if (audio->playState == SP_MAC_AUDIO_STATE_STOP) {
	startPlay(audio);
    }
#endif

    totalSize = length * (audio->samp_bit / 8);
    currentSize = 0;
    
    while (currentSize < totalSize) {
	waitAudioOutput(audio, SP_FALSE);

#if !defined(SP_MAC_USE_DOUBLE_BUFFER) && defined(MACOSX)
	pthread_mutex_lock(&mainMutex);
#endif
	copySize = MIN(audio->playDataSize - audio->playDataOffset, totalSize - currentSize);
	copySize = MIN(copySize, audio->buffer_size);
	
	spDebug(50, "spWriteAudioArch",
		"copySize = %ld, playDataOffset = %ld, playOffset = %ld, playDataFilled = %ld\n",
		copySize, audio->playDataOffset, audio->playOffset, audio->playDataFilled);
	BlockMoveData(data + currentSize, audio->playDataBuffer + audio->playDataOffset, copySize);

	audio->playDataFilled += copySize;
	audio->playDataOffset += copySize;
	if (audio->playDataOffset >= audio->playDataSize)  {
	    audio->playDataOffset = 0;
	}

#if !defined(SP_MAC_USE_DOUBLE_BUFFER)
	if (audio->playState == SP_MAC_AUDIO_STATE_STOP
	    && audio->playDataFilled >= audio->buffer_size
	    /*audio->playDataFilled >= MAX(audio->num_buffer / 2, 1) * audio->buffer_size*/
	    /*audio->playDataFilled > audio->playDataSize - audio->buffer_size*/) {
	    startPlay(audio);
	}
#endif
	currentSize += copySize;

#if !defined(SP_MAC_USE_DOUBLE_BUFFER) && defined(MACOSX)
	pthread_mutex_unlock(&mainMutex);
	
	while (audio->playDataFilled > audio->playDataSize - audio->buffer_size) {
	    spDebug(50, "spWriteAudioArch", "wait playMutex\n");
	    pthread_mutex_lock(&playMutex);
	    pthread_mutex_unlock(&playMutex);
	}
#endif
    }
    spDebug(50, "spWriteAudioArch", "done: currentSize = %ld\n", currentSize);

    return length;
}

spBool spStopAudioArch(spAudio audio)
{
    SndCommand cmd;
    audio->playState = SP_MAC_AUDIO_STATE_STOP;

    if (audio->sndChannel != nil) {
	cmd.cmd = quietCmd;
	cmd.param1 = 0; cmd.param2 = 0;
	
	if (SndDoImmediate(audio->sndChannel, &cmd) != noErr) {
	    return SP_FALSE;
	}
#if !defined(SP_MAC_USE_DOUBLE_BUFFER) && defined(MACOSX)
	if (play_mutex_locked == SP_TRUE) {
	    spDebug(10, "spStopAudioArch", "unlock playMutex\n");
	    pthread_mutex_unlock(&playMutex);
	    play_mutex_locked = SP_FALSE;
	}
#endif
	
	audio->playDataFilled = 0;
    }
    
    return SP_TRUE;
}

spBool spGetAudioOutputPositionArch(spAudio audio, long *position)
{
    long filled_length;
    
    if (position != NULL) {
	if (audio->output_total <= 0) {
	    *position = 0;
	} else {
	    filled_length = (audio->playDataFilled - audio->buffer_size * 2) / (audio->samp_bit / 8);
	    filled_length = MAX(filled_length, 0);
	    spDebug(50, "spGetAudioOutputPositionArch", "playDataFilled = %ld, filled_length = %ld\n",
		    audio->playDataFilled, filled_length);
	
	    *position = MAX((audio->output_total - filled_length) / audio->num_channel, 0);
	}
    }
    
    return SP_TRUE;
}

spBool spSyncAudioArch(spAudio audio)
{
    return waitAudioOutput(audio, SP_TRUE);
}

spBool spFreeAudioArch(spAudio audio)
{
    spBool flag = SP_TRUE;

    spStopAudioArch(audio);
    spCloseAudioDeviceArch(audio);
    
#if defined(SP_MAC_SUPPORT_AUDIO_INPUT)
    if (SPBCloseDevice(audio->refNum) != noErr) {
	flag = SP_FALSE;
    }
    spDebug(1, "spFreeAudioArch", "closing device done\n");
	
    if (audio->pspb != nil) {
	DisposePtr((Ptr)audio->pspb);
	audio->pspb = nil;
    }
    if (audio->siCompletionUPP != nil) {
	DisposeSICompletionUPP(audio->siCompletionUPP);
	audio->siCompletionUPP = nil;
    }
#if defined(MACOSX)
    pthread_mutex_destroy(&recMutex);
#endif
#endif

#if defined(SP_MAC_USE_DOUBLE_BUFFER)
#if !TARGET_API_MAC_CARBON
    if (audio->sndDoubleBackUPP != nil) {
	DisposeRoutineDescriptor(audio->sndDoubleBackUPP);
    }
#endif
#else
    if (audio->sndCallBackUPP != nil) {
	DisposeSndCallBackUPP(audio->sndCallBackUPP);
    }
#if defined(MACOSX)
    pthread_mutex_destroy(&mainMutex);
    pthread_mutex_destroy(&playMutex);
#endif
#endif
    
    return flag;
}

void spTerminateAudioArch(void)
{
    return;
}
#endif
