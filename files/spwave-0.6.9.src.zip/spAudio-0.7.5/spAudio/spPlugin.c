/*
 *	spPlugin.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spLibrary.h>
#include <sp/spDirectory.h>
#include <sp/spOption.h>

#include <sp/spPluginP.h>

static char sp_plugin_lang[SP_MAX_LINE] = "";

static char sp_plugin_default_search_path[] = SP_PLUGIN_DEFAULT_SEARCH_PATH;
static char *sp_plugin_search_path = NULL;

typedef struct _spPluginRecList *spPluginRecList;
struct _spPluginRecList
{
    char *name;
    spPluginRec *plugin_rec;

    spPluginRecList prev;
    spPluginRecList next;
};

static spPluginRecList sp_plugin_rec_list = NULL;

spBool spAddPluginRecList(spPluginRec *plugin_rec, char *name)
{
    spPluginRecList next;
    spPluginRecList list;
    
    if (plugin_rec == NULL || name == NULL) return SP_FALSE;
    
    list = xalloc(1, struct _spPluginRecList);
    list->name = strclone(name);
    list->plugin_rec = plugin_rec;
    list->prev = NULL;
    list->next = NULL;
    
    if (sp_plugin_rec_list == NULL) {
	sp_plugin_rec_list = list;
    } else {
	next = sp_plugin_rec_list->next;
	while (1) {
	    if (next->next == NULL) {
		next->next = list;
		list->prev = next;
	    }
	    next = next->next;
	}
    }
    
    return SP_TRUE;
}

spBool spRemovePluginRecList(spPluginRec *plugin_rec, char *name)
{
    spPluginRecList list;
    
    if (plugin_rec == NULL || name == NULL || sp_plugin_rec_list == NULL) return SP_FALSE;

    list = sp_plugin_rec_list;
	
    while (list != NULL) {
	if (list->plugin_rec == plugin_rec && streq(list->name, name)) {
	    if (list->prev != NULL) {
		list->prev->next = list->next;
	    }
	    if (list->next != NULL) {
		list->next->prev = list->prev;
	    }
	    if (sp_plugin_rec_list->plugin_rec == plugin_rec) {
		if (sp_plugin_rec_list->next == NULL) {
		    sp_plugin_rec_list = NULL;
		} else {
		    sp_plugin_rec_list = sp_plugin_rec_list->next;
		}
	    }
	    xfree(list->name);
	    xfree(list);
	    break;
	}

	list = list->next;
    }

    return SP_TRUE;
}

spPluginRec *spSearchPluginRecList(char *name)
{
    spPluginRecList list;
    
    if (sp_plugin_rec_list == NULL || name == NULL) return NULL;

    list = sp_plugin_rec_list;

    while (list != NULL) {
	if (streq(list->name, name)) {
	    return list->plugin_rec;
	}
	list = list->next;
    }
    
    return NULL;
}

char *spGetPluginRecListName(int index)
{
    int i;
    spPluginRecList list;
    
    if (sp_plugin_rec_list == NULL || index < 0) return NULL;

    list = sp_plugin_rec_list;

    for (i = 0; list != NULL; i++) {
	if (i == index) {
	    return list->name;
	}
	list = list->next;
    }
    
    return NULL;
}

void spSetPluginLang(char *lang)
{
    if (!strnone(lang)) {
	strcpy(sp_plugin_lang, lang);
    }
    return;
}

void spSetPluginSearchPath(char *pathlist)
{
    if (sp_plugin_search_path != NULL) {
	xfree(sp_plugin_search_path);
    }
    
    if (pathlist == NULL) {
	sp_plugin_search_path = NULL;
    } else {
	sp_plugin_search_path = strclone(pathlist);
    }
    
    return;
}

static char *spGetPluginSearchPath(void)
{
    char *path;
    
    if (sp_plugin_search_path == NULL) {
	if ((path = getenv(SP_PLUGIN_PATH_ENV)) == NULL) {
	    path = sp_plugin_default_search_path;
	}
	sp_plugin_search_path = strclone(path);
    }

    return sp_plugin_search_path;
}

static char *xspCutPluginPathList(int index)
{
    int offset = 0;

#if defined(_WIN32) || defined(MACOS)
    offset = 2;
    if (index <= 0) {
	return strclone(spGetDefaultDir());
    } else if (index <= 1) {
	char buf[SP_MAX_PATHNAME];
	sprintf(buf, "%s%cplugins", spGetDefaultDir(), SP_DIR_SEPARATOR);
	return strclone(buf);
    }
#endif
    
    return xspCutPathList(spGetPluginSearchPath(), index - offset);
}

static spBool isPluginCandidate(char *filename)
{
    if (strnone(filename)) return SP_FALSE;

#if defined(MACOSX)
    if (spIsExist(filename) == SP_TRUE) {
	spDebug(50, "isPluginCandidate", "this may be plugin: %s\n", filename);
	return SP_TRUE;
    }
#else
    if (spIsFile(filename) == SP_TRUE) {
	return SP_TRUE;
    }
#endif

    return SP_FALSE;
}

static char *xgetExactPluginName(char *plugin_name)
{
    int i;
    char *path;
    char *exactname;
    char filename[SP_MAX_PATHNAME];

    spDebug(100, "xgetExactPluginName", "plugin_name = %s\n", plugin_name);
    
    if (spIsExactName(plugin_name) == SP_TRUE) {
	if (isPluginCandidate(plugin_name) == SP_TRUE) {
	    exactname = strclone(plugin_name);
	    return exactname;
	} else {
	    sprintf(filename, "%s%s", plugin_name, SP_PLUGIN_SUFFIX);
	    spDebug(80, "xgetExactPluginName", "added suffix: %s\n", filename);
	    if (isPluginCandidate(filename) == SP_TRUE) {
		spDebug(80, "xgetExactPluginName", "exact plugin name = %s\n", filename);
		exactname = strclone(filename);
		return exactname;
	    }
	}
	plugin_name = spGetBaseName(plugin_name);
    }

    if (strnone(plugin_name)) {
	return NULL;
    }

    exactname = NULL;
    strcpy(filename, "");
    for (i = 0;; i++) {
	if ((path = xspCutPluginPathList(i)) == NULL) {
	    sprintf(filename, "%s%s", plugin_name, SP_PLUGIN_SUFFIX);
	    exactname = strclone(filename);
	    break;
	}
	spDebug(100, "xgetExactPluginName", "path = %s\n", path);

	sprintf(filename, "%s%c%s%s", path, SP_DIR_SEPARATOR,
		plugin_name, SP_PLUGIN_SUFFIX);
	exactname = xspGetExactName(filename);
	
	spDebug(100, "xgetExactPluginName",
		"filename = %s, exactname = %s\n", filename, exactname);
	
	if (isPluginCandidate(exactname) == SP_TRUE) {
	    xfree(path);
	    break;
	} else {
	    sprintf(filename, "%s%c%s", path, SP_DIR_SEPARATOR, plugin_name);
	    xfree(exactname);
	    exactname = xspGetExactName(filename);
	    
	    if (isPluginCandidate(exactname) == SP_TRUE) {
		xfree(path);
		break;
	    }
	}
	
	xfree(path);
	xfree(exactname);
    }

    spDebug(100, "xgetExactPluginName", "exactname = %s\n", exactname);
    
    return exactname;
}

static spBool checkPluginVersion(void *handle)
{
    spPluginVersionFunc version_func;
    spBool supported = SP_TRUE;
    long system_version_id = -1;
    long supported_version_id = -1;
    
    if ((version_func = (spPluginVersionFunc)spGetSymbolAddress(handle,
								SP_PLUGIN_SYSTEM_VERSION_FUNC)) == NULL
	|| (system_version_id = version_func()) < SP_PLUGIN_SUPPORTED_VERSION_ID) {
	spDebug(10, "checkPluginVersion", "old plugin file\n");
	supported = SP_FALSE;
    }
    spDebug(80, "checkPluginVersion", "system version = %ld\n", system_version_id);
    
    if ((version_func = (spPluginVersionFunc)spGetSymbolAddress(handle,
								SP_PLUGIN_SUPPORTED_VERSION_FUNC)) == NULL
	|| (supported_version_id = version_func()) > SP_PLUGIN_VERSION_ID) {
	spDebug(10, "checkPluginVersion", "unsupported plugin file\n");
	supported = SP_FALSE;
    }
    spDebug(80, "checkPluginVersion", "supported version = %ld\n", supported_version_id);

    return supported;
}

spPlugin *spLoadPlugin(char *plugin_name)
{
    char *filename;
    void *handle;
    spPlugin *plugin;
    spPluginRec *rec;
    spPluginHost *host;
    spGetPluginRecFunc plugin_rec_func = NULL;

    if (plugin_name == NULL) return NULL;

    filename = NULL;
    handle = NULL;
    
    if ((rec = spSearchPluginRecList(plugin_name)) == NULL) {
	if ((filename = xgetExactPluginName(plugin_name)) == NULL) {
	    return NULL;
	}
	spDebug(80, "spLoadPlugin", "filename = %s\n", filename);

	if ((handle = spOpenLibrary(filename)) != NULL) {
	    spDebug(100, "spLoadPlugin", "get handle done\n");
	    
	    if ((plugin_rec_func = (spGetPluginRecFunc)spGetSymbolAddress(handle,
									  SP_GET_PLUGIN_REC_FUNC)) != NULL) {
		spDebug(100, "spLoadPlugin", "get symbol done\n");
		
#ifdef SP_PLUGIN_VERIFY_VERSION
		if (checkPluginVersion(handle) == SP_FALSE) {
		    plugin_rec_func = NULL;
		}
#endif
	    }
	}
    
	if (plugin_rec_func == NULL) {
	    if (handle != NULL) {
		spCloseLibrary(handle);
	    }
	    xfree(filename);
	    return NULL;
	}
	rec = plugin_rec_func();
    }
    
    plugin = xalloc(1, struct _spPlugin);
    plugin->rec = rec;
    plugin->handle = handle;
    plugin->instance = NULL;

    if (rec->host_data == NULL) {
	host = xalloc(1, struct _spPluginHost);
	if (filename == NULL) {
	    host->name = strclone(plugin_name);
	} else {
	    host->name = strclone(filename);
	}
	host->version_id = SP_PLUGIN_VERSION_ID;
	host->ref_count = 1;
	host->data = NULL;
	host->mutex = NULL;
	host->num_instance = 0;

	rec->host_data = (void *)host;
	
	if (rec->init != NULL && rec->init(sp_plugin_lang) == SP_FALSE) {
	    spFreePlugin(plugin);
	    xfree(filename);
	    return NULL;
	}
    } else {
	host = (spPluginHost *)rec->host_data;
	host->ref_count++;

	spDebug(40, "spLoadPlugin", "ref_count = %ld\n", host->ref_count);
    }
    plugin->host = host;
    
    spDebug(80, "spLoadPlugin", "handle = %d\n", (int)plugin->handle);
    
    if (filename != NULL) {
	xfree(filename);
    }
    
    return plugin;
}

spBool spFreePlugin(spPlugin *plugin)
{
    void *handle;

    if (plugin == NULL) return SP_FALSE;

    spDebug(80, "spFreePlugin", "%s: in\n", plugin->host->name);

    handle = plugin->handle;

    if (plugin->instance != NULL) {
	spFreePluginInstance(plugin);
    }
    
    if (plugin->host != NULL) {
	spDebug(40, "spFreePlugin", "ref_count = %ld\n", plugin->host->ref_count);
	
	if (plugin->host->ref_count <= 1) {
	    if (plugin->rec->free != NULL) {
		plugin->rec->free();
	    }
	    plugin->handle = NULL;
	    
	    if (plugin->host->name != NULL) {
		xfree(plugin->host->name);
	    }
	    plugin->host->name = NULL;
	    
	    xfree(plugin->host);
	    plugin->host = NULL;
	    plugin->rec->host_data = NULL;
	} else {
	    plugin->host->ref_count--;
	}
    }
    if (handle != NULL) {
	spCloseLibrary(handle);
    }
    
    xfree(plugin);

    spDebug(80, "spFreePlugin", "done\n");
    
    return SP_TRUE;
}

spBool spEqPluginType(spPlugin *plugin, spPluginType type)
{
    int n;
    int version = 0, t_version = 0;
    int revision = 0, t_revision = 0;
    char buf[SP_MAX_LINE];
    char t_buf[SP_MAX_LINE];
    
    if (plugin == NULL) return SP_FALSE;

    n = sscanf(plugin->rec->type, "%s %d.%d", buf, &version, &revision);
    if (n == 1) {
	if (streq(plugin->rec->type, type)) {
	    return SP_TRUE;
	}
    } else if (n == 3) {
	spDebug(100, "spEqPluginType", "buf = %s, version = %d, revision = %d\n",
		buf, version, revision);

	n = sscanf(type, "%s %d.%d", t_buf, &t_version, &t_revision);

	if (n == 1) {
	    if (streq(buf, t_buf)) {
		return SP_TRUE;
	    }
	} else if (n == 3) {
	    spDebug(100, "spEqPluginType", "t_buf = %s, t_version = %d, t_revision = %d\n",
		    t_buf, t_version, t_revision);

	    if (streq(buf, t_buf)
		&& version == t_version && revision == t_revision) {
		return SP_TRUE;
	    }
	}
    }

    return SP_FALSE;
}

char *spGetPluginName(spPlugin *plugin)
{
    if (plugin == NULL) return NULL;

    return plugin->host->name;
}

char *spGetPluginId(spPlugin *plugin)
{
    if (plugin == NULL) return NULL;

    return plugin->rec->plugin_id;
}

char *spGetPluginDescription(spPlugin *plugin)
{
    if (plugin == NULL) return NULL;

    return plugin->rec->description;
}

char *spGetPluginInformation(spPlugin *plugin)
{
    if (plugin == NULL) return NULL;

    return plugin->rec->information;
}


long spGetPluginVersionId(spPlugin *plugin)
{
    if (plugin == NULL) return -1;

    return plugin->rec->version_id;
}

int spGetPluginPriority(spPlugin *plugin)
{
    if (plugin == NULL) return SP_PLUGIN_PRIORITY_NULL;

    return plugin->rec->priority;
}

spBool spGetPluginVersion(spPlugin *plugin, int *version, int *revision)
{
    long v, r;
    
    if (plugin == NULL) return SP_FALSE;

    v = spGetPluginVersionId(plugin) / 1000;
    r = spGetPluginVersionId(plugin) - 1000 * v;
    
    if (version != NULL) {
	*version = (int)v;
    }
    if (revision != NULL) {
	*revision = (int)r;
    }
    
    return plugin->rec->version_id;
}

unsigned long spGetPluginCaps(spPlugin *plugin)
{
    if (plugin == NULL) return 0;

    return plugin->rec->caps;
}

spBool spIsPluginCapable(spPlugin *plugin, unsigned long cap)
{
    if (plugin == NULL) return SP_FALSE;

    if (plugin->rec->caps & cap) {
	return SP_TRUE;
    }
    return SP_FALSE;
}

long spGetNumPluginInstance(spPlugin *plugin)
{
    if (plugin == NULL || plugin->host == NULL) return -1;

    return plugin->host->num_instance;
}

spBool spIsPluginInstantiatable(spPlugin *plugin)
{
    if (plugin == NULL || plugin->host == NULL
	|| plugin->rec->init_instance == NULL) return SP_FALSE;
    
    if (spIsPluginCapable(plugin, SP_PLUGIN_CAPS_THREAD_SAFE) == SP_FALSE
	&& plugin->host->num_instance >= 1) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spInitPluginInstance(spPlugin *plugin)
{
    if (spIsPluginInstantiatable(plugin) == SP_FALSE) {
	return SP_FALSE;
    }
    
    if ((plugin->instance = plugin->rec->init_instance(sp_plugin_lang)) == NULL) {
	return SP_FALSE;
    }
    plugin->host->num_instance++;
    
    return SP_TRUE;
}

spBool spFreePluginInstance(spPlugin *plugin)
{
    spBool flag;
    
    if (plugin == NULL || plugin->host == NULL || plugin->instance == NULL
	|| plugin->rec->free_instance == NULL) return SP_FALSE;

    flag = plugin->rec->free_instance(plugin->instance);
    plugin->instance = NULL;
    plugin->host->num_instance--;
    
    return flag;
}

spPlugin *spInstantiatePlugin(char *plugin_name)
{
    spPlugin *plugin;
    
    if ((plugin = spLoadPlugin(plugin_name)) == NULL) {
	return NULL;
    }
    if (spInitPluginInstance(plugin) == SP_FALSE) {
	spFreePlugin(plugin);
	return NULL;
    }

    return plugin;
}

spOptions spInitPluginOptions(spPlugin *plugin)
{
    if (plugin == NULL || plugin->instance == NULL) return NULL;
    if (plugin->rec->init_options == NULL) return NULL;

    return plugin->rec->init_options(plugin->instance, sp_plugin_lang);
}

spBool spFreePluginOptions(spPlugin *plugin, spOptions options)
{
    if (plugin == NULL || plugin->instance == NULL || options == NULL) return SP_FALSE;
    if (plugin->rec->free_options == NULL) return SP_FALSE;

    return plugin->rec->free_options(plugin->instance, options);
}

void spPrintPluginOptions(spPlugin *plugin)
{
    spOptions options;
    
    /* get options */
    if ((options = spInitPluginOptions(plugin)) != NULL) {
	/* print options */
	spPrintOptions(options);
	
	spFreePluginOptions(plugin, options);
    }

    return;
}

spBool spPluginUsage(char *plugin_name)
{
    spPlugin *plugin;

    /* load plugin */
    if ((plugin = spLoadPlugin(plugin_name)) == NULL) {
	return SP_FALSE;
    }
    
    if (spInitPluginInstance(plugin) == SP_TRUE) {
	/* print options */
	spPrintPluginOptions(plugin);
    
	spFreePluginInstance(plugin);
    }
    
    /* free input plugin */
    spFreePlugin(plugin);

    return SP_TRUE;
}


spBool spIsPluginFile(char *filename)
{
    if (filename == NULL) return SP_FALSE;

    if (isPluginCandidate(filename) == SP_TRUE
	&& spEqSuffix(filename, SP_PLUGIN_SUFFIX) == SP_TRUE) {
#if 1
	spPlugin *plugin;
	if ((plugin = spLoadPlugin(filename)) != NULL) {
	    spFreePlugin(plugin);
	    return SP_TRUE;
	}
#else
	return SP_TRUE;
#endif
    }
    
    return SP_FALSE;
}

#define SP_NUM_PLUGIN_BUFFER 8

char *xspSearchPluginFile(int index)
{
    int i;
    char *path;
    char buf[SP_MAX_PATHNAME];
    struct dirent *dp;
    DIR *dirp = NULL;
    int num_plugin_buffer;
    static int num_plugin_file = 0;
    static char **plugin_files = NULL;

    if (plugin_files == NULL) {
	num_plugin_buffer = SP_NUM_PLUGIN_BUFFER;
	plugin_files = xalloc(num_plugin_buffer, char *);
	
	for (i = 0;; i++) {
	    if ((path = xspCutPluginPathList(i)) == NULL) {
		if (i == 0) {
		    path = xspGetCurrentDir();
		} else {
		    break;
		}
	    }
	    spDebug(80, "xspSearchPluginFile", "path = %s\n", path);
	    
	    /* open directory */
	    if ((dirp = spOpenDir(path)) != NULL) {
		while (1) {
		    /* read directory */
		    if ((dp = spReadDir(dirp)) == NULL) {
			spDebug(80, "xspSearchPluginFile", "can't read dir: %s\n", path);
			break;
		    }
		    spDebug(80, "xspSearchPluginFile", "dp->d_name = %s\n", dp->d_name);

		    if (!streq(dp->d_name, SP_CURRENT_DIR_STRING)
			&& !streq(dp->d_name, SP_PARENT_DIR_STRING)) {
			sprintf(buf, "%s%c%s", path, SP_DIR_SEPARATOR, dp->d_name);
			spDebug(80, "xspSearchPluginFile", "found file = %s\n", buf);
		
			if (spIsPluginFile(buf) == SP_TRUE) {
			    spDebug(50, "xspSearchPluginFile", "num_plugin_file = %d, buf = %s\n",
				    num_plugin_file, buf);
		
			    plugin_files[num_plugin_file] = strclone(buf);
			    num_plugin_file++;
	    
			    if (num_plugin_file >= num_plugin_buffer) {
				num_plugin_buffer += SP_NUM_PLUGIN_BUFFER;
				plugin_files = xrealloc(plugin_files, num_plugin_buffer, char *);
			    }
			}
		    }
		}
		spCloseDir(dirp);
	    }
	    spDebug(80, "xspSearchPluginFile", "%s dir search finished\n", path);
	    xfree(path);
	}
    }

    if (index >= num_plugin_file) {
	if ((path = spGetPluginRecListName(index - num_plugin_file)) != NULL) {
	    return strclone(path);
	} else {
	    return NULL;
	}
    }
    spDebug(80, "xspSearchPluginFile", "plugin file = %s\n", plugin_files[index]);
    
    return strclone(plugin_files[index]);
}

