/*
 *	input_wav.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spInputPluginP.h>
#include <sp/spPluginMain.h>

#include <sp/spWaveP.h>

#include "plugin_wav.c"

static char *sp_wav_file_type_list[] = {
    SP_WAVE_WAV_ID,
    SP_WAVE_WAV_ID,
    SP_WAVE_WAV_ID,
    NULL,
};
static char *sp_wav_file_desc_list[] = {
    WAVE_FORMAT_PCM_STRING,
    WAVE_FORMAT_MULAW_STRING,
    WAVE_FORMAT_ALAW_STRING,
    NULL,
};
static char *sp_wav_file_filter_list[] = {
    "*.wav",
    "*.wav",
    "*.wav",
    NULL,
};
    
static spBool spIsSupportedByPluginWav(char *filename);

static spPluginError spOpenPluginWav(void *instance, char *filename, char *mode);
static spBool spClosePluginWav(void *instance);
static spPluginState spGetPluginStateWav(void *instance);
static long spGetPluginCurrentPositionWav(void *instance);
static spBool spStopPluginWav(void *instance);
static spBool spPausePluginWav(void *instance);
static spBool spRestartPluginWav(void *instance);

static long spReadPluginWav(void *instance, char *data, long length);
static spBool spSeekPluginWav(void *instance, long pos);
static long spGetPluginTotalLengthWav(void *instance);


static spInputPluginRec sp_input_plugin_wav = {
    NULL,
    NULL,

    SP_PLUGIN_INPUT,
    "Wav",
    2,
    SP_PLUGIN_PRIORITY_MIDDLE,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginWav,
    spFreePluginWav,
    "Wav Input Plugin",
    "Wav Input Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceWav,
    spFreePluginInstanceWav,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_wav_file_type_list,
    sp_wav_file_desc_list,
    sp_wav_file_filter_list,
    spIsSupportedByPluginWav,
    spSetPluginFileTypeWav,  
    spGetPluginFileTypeWav,
    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK
     | SP_SONG_GENRE_MASK | SP_SONG_RELEASE_MASK | SP_SONG_COPYRIGHT_MASK
     | SP_SONG_ENGINEER_MASK | SP_SONG_SOURCE_MASK | SP_SONG_SOFTWARE_MASK
     | SP_SONG_SUBJECT_MASK),
    spSetPluginSongInfoWav,
    spGetPluginSongInfoWav,
    spGetPluginBestSuffixWav,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,

    spSetPluginSampleBitWav,   
    spGetPluginSampleBitWav,   
    spSetPluginChannelWav,     
    spGetPluginChannelWav,     
    spSetPluginSampleRateWav,  
    spGetPluginSampleRateWav,  
    spSetPluginOtherInfoWav,   
    spGetPluginOtherInfoWav,
    
    spOpenPluginWav,              
    spClosePluginWav,             
    spGetPluginStateWav,          
    spGetPluginCurrentPositionWav,
    spStopPluginWav,              
    spPausePluginWav,             
    spRestartPluginWav,

    spReadPluginWav,             
    spSeekPluginWav,
    spGetPluginTotalLengthWav,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_input_plugin_wav;
}

static spBool spIsSupportedByPluginWav(char *filename)
{
    return spIsWavFile(filename);
}

static spPluginError spOpenPluginWav(void *instance, char *filename, char *mode)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    /* open file */
    if (strnone(filename) || (pinstance->fp = spOpenFile(filename, "rb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    spDebug(10, "spOpenPluginWav", "filename = %s\n", filename);

    /* read header */
    if (spReadWavInfo(&pinstance->info, pinstance->fp) == SP_FALSE) {
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_FAILURE;
    }
    if (spSetPluginSampleBitWav(instance, pinstance->info.samp_bit) == SP_FALSE) {
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_SAMP_BIT;
    }
    pinstance->type_index =
	spFindPluginRecFileTypeIndex((spIoPluginRec *)&sp_input_plugin_wav, pinstance->info.file_desc);
    
    pinstance->current_pos = 0;

    /* read song info */
    spReadWavSongInfo(&pinstance->info, &pinstance->song_info, pinstance->fp);
    fseek(pinstance->fp, pinstance->info.header_size, SEEK_SET);
    spDebug(10, "spOpenPluginWav", "pinstance->info.header_size = %d\n", pinstance->info.header_size);
    
    spGetPluginTotalLengthWav(instance);
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->info.header_size = 0;
	pinstance->current_pos = 0;
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	fseek(pinstance->fp, pinstance->info.header_size, SEEK_SET);
    }
    pinstance->current_pos = 0;

    return SP_TRUE;
}

static spBool spPausePluginWav(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginWav(void *instance)
{

    return SP_TRUE;
}

/*
 * The data for spReadPluginWav must be 16 bit data
 * regardless of argument for spSetPluginSampleBitWav.
 */
static long spReadPluginWav(void *instance, char *data, long length)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;    
    long nread;
    long pos;
    
    if (pinstance->fp == NULL) return -1;

    if ((nread = spReadWavData(&pinstance->info, data, length, pinstance->fp)) < 0) {
	return -1;
    }
    pos = pinstance->current_pos + (nread / pinstance->info.num_channel);

    if (pos > pinstance->total_length) {
	pos = pinstance->total_length;
	nread = (pos - pinstance->current_pos) * pinstance->info.num_channel;
    }
    pinstance->current_pos = pos;
    
    return nread;
}

static spBool spSeekPluginWav(void *instance, long pos)
{
    long k, nloop;
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->fp == NULL) return SP_FALSE;
    
    fseek(pinstance->fp, pinstance->info.header_size, SEEK_SET);
    
    /* for a long file */
    nloop = (long)pinstance->info.num_channel * (long)(pinstance->info.samp_bit / 8);
    for (k = 0; k < nloop; k++) {
	fseek(pinstance->fp, pos, SEEK_CUR);
    }
    pinstance->current_pos = pos;
    
    return SP_TRUE;
}

static long spGetPluginTotalLengthWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->total_length <= 0) {
	pinstance->total_length = pinstance->info.length;
    }

    return pinstance->total_length;
}

