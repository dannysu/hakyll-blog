/*
 *	plugin_wav.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>
#include <sp/spInputPluginP.h>

#define SP_NUM_WAV_TYPE 3
#define SP_WAV_TYPE_PCM 0
#define SP_WAV_TYPE_ULAW 1
#define SP_WAV_TYPE_ALAW 2

typedef struct _spWavPluginInstance
{
    int type_index;
    spWaveInfo info;
    spSongInfo song_info;
    
    char filename[SP_MAX_PATHNAME];
    FILE *fp;
    long current_pos;
    long total_length;
} *spWavPluginInstance;

static spBool spInitPluginWav(char *lang)
{
    return SP_TRUE;
}

static spBool spFreePluginWav(void)
{
    return SP_TRUE;
}

static void *spInitPluginInstanceWav(char *lang)
{
    spWavPluginInstance instance;
    
    instance = xalloc(1, struct _spWavPluginInstance);
    instance->type_index = SP_WAV_TYPE_PCM;
    spInitWaveInfo(&instance->info);
    spInitSongInfo(&instance->song_info);
    
    strcpy(instance->filename, "");
    instance->fp = NULL;
    instance->current_pos = 0;
    instance->total_length = 0;

    return (void *)instance;
}

static spBool spFreePluginInstanceWav(void *instance)
{
    xfree(instance);
    return SP_TRUE;
}

static spBool spSetPluginFileTypeWav(void *instance, int index)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    switch (index) {
      case SP_WAV_TYPE_PCM:
      case SP_WAV_TYPE_ULAW:
      case SP_WAV_TYPE_ALAW:
	pinstance->type_index = index;
	break;
      default:
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static int spGetPluginFileTypeWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    return pinstance->type_index;
}

static spBool spSetPluginSongInfoWav(void *instance, spSongInfo *song_info)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    spCopySongInfo(&pinstance->song_info, song_info);

    return SP_TRUE;
}

static spBool spGetPluginSongInfoWav(void *instance, spSongInfo *song_info)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    spCopySongInfo(song_info, &pinstance->song_info);

    return SP_TRUE;
}

static char *spGetPluginBestSuffixWav(void *instance)
{
    return ".wav";
}

static spBool spSetPluginSampleBitWav(void *instance, int samp_bit)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (samp_bit == 8) {
	pinstance->info.samp_bit = 8;
    } else if (samp_bit == 16) {
	pinstance->info.samp_bit = 16;
    } else if (samp_bit == 24) {
	pinstance->info.samp_bit = 24;
    } else if (samp_bit == 32) {
	pinstance->info.samp_bit = 32;
    } else {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spGetPluginSampleBitWav(void *instance, int *samp_bit)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    *samp_bit = pinstance->info.samp_bit;

    return SP_TRUE;
}

static spBool spSetPluginChannelWav(void *instance, int num_channel)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    pinstance->info.num_channel = MAX(num_channel, 1);
    
    return SP_TRUE;
}

static spBool spGetPluginChannelWav(void *instance, int *num_channel)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    *num_channel = pinstance->info.num_channel;

    return SP_TRUE;
}

static spBool spSetPluginSampleRateWav(void *instance, double samp_rate)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    pinstance->info.samp_rate = samp_rate;

    return SP_TRUE;
}

static spBool spGetPluginSampleRateWav(void *instance, double *samp_rate)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    *samp_rate = pinstance->info.samp_rate;

    return SP_TRUE;
}

static spBool spSetPluginOtherInfoWav(void *instance, char *id, char *data)
{
    
    return SP_FALSE;
}

static spBool spGetPluginOtherInfoWav(void *instance, char *id, char *data)
{

    return SP_FALSE;
}
