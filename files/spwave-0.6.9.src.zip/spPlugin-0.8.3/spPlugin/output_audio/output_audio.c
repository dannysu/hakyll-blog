/*
 *	output_audio.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spAudio.h>

#include <sp/spPluginMain.h>
#include <sp/spOutputPluginP.h>
#include <sp/spInputPluginP.h>

static spBool spInitPluginAudio(char *lang);
static spBool spFreePluginAudio(void);

static void *spInitPluginInstanceAudio(char *lang);
static spBool spFreePluginInstanceAudio(void *instance);

static spBool spGetPluginNumDeviceAudio(void *instance, int *num_device);
static char *spGetPluginDeviceNameAudio(void *instance, int index);
static spBool spSelectPluginDeviceAudio(void *instance, int index);
static spBool spSetPluginBufferSizeAudio(void *instance, int buffer_size);
static spBool spGetPluginBufferSizeAudio(void *instance, int *buffer_size);
static spBool spSetPluginVolumeAudio(void *instance, int channel, int volume);
static spBool spGetPluginVolumeAudio(void *instance, int channel, int *volume);

static spBool spSetPluginSampleBitAudio(void *instance, int samp_bit);
static spBool spGetPluginSampleBitAudio(void *instance, int *samp_bit);
static spBool spSetPluginChannelAudio(void *instance, int num_channel);
static spBool spGetPluginChannelAudio(void *instance, int *num_channel);
static spBool spSetPluginSampleRateAudio(void *instance, double samp_rate);
static spBool spGetPluginSampleRateAudio(void *instance, double *samp_rate);
static spBool spSetPluginOtherInfoAudio(void *instance, char *id, char *data);
static spBool spGetPluginOtherInfoAudio(void *instance, char *id, char *data);

static spBool spOpenPluginAudio(void *instance, char *filename, char *mode);
static spBool spClosePluginAudio(void *instance);
static spPluginState spGetPluginStateAudio(void *instance);
static long spGetPluginCurrentPositionAudio(void *instance);
static spBool spStopPluginAudio(void *instance);
static spBool spPausePluginAudio(void *instance);
static spBool spRestartPluginAudio(void *instance);

static long spWritePluginAudio(void *instance, char *data, long length);
static spBool spFlushPluginAudio(void *instance);


static spOutputPluginRec sp_output_plugin_audio = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "Audio",
    2,
    SP_PLUGIN_PRIORITY_NULL,
    0,
    spInitPluginAudio,
    spFreePluginAudio,
    "Audio Output Plugin",
    "Audio Output Plugin Version 0.1\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",

    spInitPluginInstanceAudio,
    spFreePluginInstanceAudio,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_AUDIO,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    NULL,
    
    spGetPluginNumDeviceAudio,
    spGetPluginDeviceNameAudio,
    spSelectPluginDeviceAudio,
    spSetPluginBufferSizeAudio,  
    spGetPluginBufferSizeAudio,  
    spSetPluginVolumeAudio,      
    spGetPluginVolumeAudio,

    spSetPluginSampleBitAudio,   
    spGetPluginSampleBitAudio,   
    spSetPluginChannelAudio,     
    spGetPluginChannelAudio,     
    spSetPluginSampleRateAudio,  
    spGetPluginSampleRateAudio,  
    spSetPluginOtherInfoAudio,   
    spGetPluginOtherInfoAudio,
    
    spOpenPluginAudio,              
    spClosePluginAudio,             
    spGetPluginStateAudio,          
    spGetPluginCurrentPositionAudio,
    spStopPluginAudio,              
    spPausePluginAudio,             
    spRestartPluginAudio,
    
    spWritePluginAudio,             
    spFlushPluginAudio,
    NULL,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_audio;
}

typedef struct _spAudioPluginInstance
{
    spAudio output_audio;
} *spAudioPluginInstance;

static spBool spInitPluginAudio(char *lang)
{
#if !defined(SP_SUPPORT_AUDIO)
    return SP_FALSE;
#else
    return SP_TRUE;
#endif
}

static spBool spFreePluginAudio(void)
{
#if !defined(SP_SUPPORT_AUDIO)
    return SP_FALSE;
#else
    return SP_TRUE;
#endif
}

static void *spInitPluginInstanceAudio(char *lang)
{
    spAudio audio;
    spAudioPluginInstance instance;

    if ((audio = spInitAudio()) == NULL) {
	return NULL;
    }
    
    instance = xalloc(1, struct _spAudioPluginInstance);
    instance->output_audio = audio;
    
    return (void *)instance;
}

static spBool spFreePluginInstanceAudio(void *instance)
{
    spFreeAudio(((spAudioPluginInstance)instance)->output_audio);
    xfree(instance);
    
    return SP_TRUE;
}

static spBool spGetPluginNumDeviceAudio(void *instance, int *num_device)
{
    return 1;
}

static char *spGetPluginDeviceNameAudio(void *instance, int index)
{
    if (index == 0) {
	return "default";
    }

    return NULL;
}

static spBool spSelectPluginDeviceAudio(void *instance, int index)
{
    if (index == 0) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spBool spSetPluginBufferSizeAudio(void *instance, int buffer_size)
{
    return spSetAudioBufferSize(((spAudioPluginInstance)instance)->output_audio, buffer_size);
}

static spBool spGetPluginBufferSizeAudio(void *instance, int *buffer_size)
{
    return spGetAudioBufferSize(((spAudioPluginInstance)instance)->output_audio, buffer_size);
}

static spBool spSetPluginSampleBitAudio(void *instance, int samp_bit)
{
    return spSetAudioSampleBit(((spAudioPluginInstance)instance)->output_audio, MAX(samp_bit, 16));
}

static spBool spGetPluginSampleBitAudio(void *instance, int *samp_bit)
{
    return spGetAudioSampleBit(((spAudioPluginInstance)instance)->output_audio, samp_bit);
}

static spBool spSetPluginChannelAudio(void *instance, int num_channel)
{
    return spSetAudioChannel(((spAudioPluginInstance)instance)->output_audio, num_channel);
}

static spBool spGetPluginChannelAudio(void *instance, int *num_channel)
{
    return spGetAudioChannel(((spAudioPluginInstance)instance)->output_audio, num_channel);
}

static spBool spSetPluginSampleRateAudio(void *instance, double samp_rate)
{
    return spSetAudioSampleRate(((spAudioPluginInstance)instance)->output_audio, samp_rate);
}

static spBool spGetPluginSampleRateAudio(void *instance, double *samp_rate)
{
    return spGetAudioSampleRate(((spAudioPluginInstance)instance)->output_audio, samp_rate);
}

static spBool spSetPluginVolumeAudio(void *instance, int channel, int volume)
{
    return SP_FALSE;
}

static spBool spGetPluginVolumeAudio(void *instance, int channel, int *volume)
{

    return SP_FALSE;
}

static spBool spSetPluginOtherInfoAudio(void *instance, char *id, char *data)
{

    return SP_FALSE;
}

static spBool spGetPluginOtherInfoAudio(void *instance, char *id, char *data)
{

    return SP_FALSE;
}

static long sp_current_pos = 0;

static spBool spOpenPluginAudio(void *instance, char *filename, char *mode)
{
    spDebug(10, "spOpenPluginAudio", "in\n");
    
    if (spOpenAudioDevice(((spAudioPluginInstance)instance)->output_audio, mode) == SP_TRUE) {
	return SP_PLUGIN_ERROR_SUCCESS;
    } else {
	return SP_PLUGIN_ERROR_OPEN;
    }
}

static spBool spClosePluginAudio(void *instance)
{
    sp_current_pos = 0;
    
    return spCloseAudioDevice(((spAudioPluginInstance)instance)->output_audio);
}

static spPluginState spGetPluginStateAudio(void *instance)
{
    if (sp_current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionAudio(void *instance)
{
    long position;
    
    if (spGetAudioOutputPosition(((spAudioPluginInstance)instance)->output_audio, &position) == SP_TRUE) {
	return position;
    }

    return sp_current_pos;
}

static spBool spStopPluginAudio(void *instance)
{
    sp_current_pos = 0;

    return spStopAudio(((spAudioPluginInstance)instance)->output_audio);
}

static spBool spPausePluginAudio(void *instance)
{

    return SP_FALSE;
}

static spBool spRestartPluginAudio(void *instance)
{

    return SP_FALSE;
}

static long spWritePluginAudio(void *instance, char *data, long length)
{
    int num_channel = 1;
    long nwrite;
    
    nwrite = spWriteAudio(((spAudioPluginInstance)instance)->output_audio, data, length);
    spGetAudioChannel(((spAudioPluginInstance)instance)->output_audio, &num_channel);
    
    sp_current_pos += (nwrite / num_channel);

    return nwrite;
}

static spBool spFlushPluginAudio(void *instance)
{
    return spSyncAudio(((spAudioPluginInstance)instance)->output_audio);
}

