#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spMain.h>
#include <sp/spBaseLib.h>

#include <sp/spPlugin.h>
#include <sp/spOutputPlugin.h>
#include <sp/spInputPlugin.h>

static spBool help_flag;
static spBool version_id_flag;
static int debug_level = -1;
static char *plugin_search_path = NULL;

static spOptions options;
static spOption option[] = {
    {"-path", NULL, "plugin search path", NULL,
	 SP_TYPE_STRING, &plugin_search_path, NULL},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-vid", NULL, "display version ID", NULL,
	 SP_TYPE_BOOLEAN, &version_id_flag, SP_FALSE_STRING},
    {"-help", "-h", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<plugin name...>",
};

int spMain(int argc, char *argv[])
{
    int version, revision;
    char *filename;
    spPlugin *plugin;

    spSetHelpMessage(&help_flag, "Plugin test");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    if (!strnone(plugin_search_path)) {
	spDebug(10, "spMain", "plugin_search_path: %s\n", plugin_search_path);
	spSetPluginSearchPath(plugin_search_path);
    }

    while ((filename = spGetFile(options)) != NULL) {
	/* load plugin */
	if ((plugin = spLoadPlugin(filename)) == NULL) {
	    fprintf(stderr, "can't load plugin: %s\n", filename);
	    spExit(1);
	}
	
	if (version_id_flag == SP_TRUE) {
	    printf("%ld\n", spGetPluginVersionId(plugin));
	} else {
	    printf("Name: %s\n", spGetBaseName(spGetPluginName(plugin)));
	    if (spGetPluginVersion(plugin, &version, &revision) == SP_TRUE) {
		printf("Version: %d.%d\n", version, revision);
	    }
	    printf("Description: %s\n", spGetPluginDescription(plugin));
	}
	
	/* free plugin */
	spFreePlugin(plugin);

	printf("\n");
    }
    
    return 0;
}
