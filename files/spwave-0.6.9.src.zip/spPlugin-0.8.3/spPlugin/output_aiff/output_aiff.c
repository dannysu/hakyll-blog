/*
 *	output_aiff.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#include <sp/spWaveP.h>

#include "plugin_aiff.c"

static char *sp_aiff_file_type_list[] = {
    SP_WAVE_AIFF_ID,
    SP_WAVE_AIFC_ID,
    SP_WAVE_AIFC_ID,
    SP_WAVE_AIFC_ID,
    NULL,
};
static char *sp_aiff_file_desc_list[] = {
    SP_AIFF_TYPE_NONE_STRING,
    SP_AIFF_TYPE_PCM_STRING,
    SP_AIFF_TYPE_ULAW_STRING,
    SP_AIFF_TYPE_ALAW_STRING,
    NULL,
};
static char *sp_aiff_file_filter_list[] = {
    "*.aif",
    "*.afc",
    "*.afc",
    "*.afc",
    NULL,
};
    
static spBool spIsSupportedByPluginAiff(char *filename);

static spPluginError spOpenPluginAiff(void *instance, char *filename, char *mode);
static spBool spClosePluginAiff(void *instance);
static spPluginState spGetPluginStateAiff(void *instance);
static long spGetPluginCurrentPositionAiff(void *instance);
static spBool spStopPluginAiff(void *instance);
static spBool spPausePluginAiff(void *instance);
static spBool spRestartPluginAiff(void *instance);

static long spWritePluginAiff(void *instance, char *data, long length);
static spBool spFlushPluginAiff(void *instance);


static spOutputPluginRec sp_output_plugin_aiff = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "AIFF",
    2,
    SP_PLUGIN_PRIORITY_MIDDLE,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginAiff,
    spFreePluginAiff,
    "AIFF Output Plugin",
    "AIFF Output Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceAiff,
    spFreePluginInstanceAiff,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_aiff_file_type_list,
    sp_aiff_file_desc_list,
    sp_aiff_file_filter_list,
    spIsSupportedByPluginAiff,
    spSetPluginFileTypeAiff,  
    spGetPluginFileTypeAiff,
    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK | SP_SONG_COPYRIGHT_MASK),
    spSetPluginSongInfoAiff,
    spGetPluginSongInfoAiff,
    spGetPluginBestSuffixAiff,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
	    
    spSetPluginSampleBitAiff,   
    spGetPluginSampleBitAiff,   
    spSetPluginChannelAiff,     
    spGetPluginChannelAiff,     
    spSetPluginSampleRateAiff,  
    spGetPluginSampleRateAiff,  
    spSetPluginOtherInfoAiff,   
    spGetPluginOtherInfoAiff,
    
    spOpenPluginAiff,              
    spClosePluginAiff,             
    spGetPluginStateAiff,          
    spGetPluginCurrentPositionAiff,
    spStopPluginAiff,              
    spPausePluginAiff,             
    spRestartPluginAiff,

    spWritePluginAiff,             
    spFlushPluginAiff,
    NULL,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_aiff;
}

static spBool spIsSupportedByPluginAiff(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".aiff")
	    || strcaseeq(p, ".aif")
	    || strcaseeq(p, ".aifc")
	    || strcaseeq(p, ".afc")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spPluginError spOpenPluginAiff(void *instance, char *filename, char *mode)
{
    spAiffPluginInstance pinstance = (spAiffPluginInstance)instance;
    
    /* open file */
    if (strnone(filename)) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    if (pinstance->type_index == SP_AIFF_TYPE_NONE) {
	char *p;
	if ((p = strrchr(filename, '.')) != NULL) {
	    if (strcaseeq(p, ".aifc") || strcaseeq(p, ".afc")) {
		pinstance->type_index = SP_AIFF_TYPE_PCM;
	    }
	}
    }

    if (pinstance->type_index == SP_AIFF_TYPE_ULAW || pinstance->type_index == SP_AIFF_TYPE_ALAW) {
	if (pinstance->info.samp_bit > 16) {
	    return SP_PLUGIN_ERROR_SAMP_BIT;
	}
	pinstance->info.samp_bit = 8;
    }
    
    if (spSetPluginSampleBitAiff(instance, pinstance->info.samp_bit) == SP_FALSE) {
	return SP_PLUGIN_ERROR_SAMP_BIT;
    }

    if ((pinstance->fp = spOpenFile(filename, "wb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    
    /* write aiff header using length 1 */
    pinstance->info.length = 1;
    strcpy(pinstance->info.file_type, sp_aiff_file_type_list[pinstance->type_index]);
    strcpy(pinstance->info.file_desc, sp_aiff_file_desc_list[pinstance->type_index]);
    if (spWriteAiffInfo(&pinstance->info, pinstance->fp) == SP_FALSE) {
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_WRITE;
    }
    pinstance->current_pos = 0;
    strcpy(pinstance->filename, filename);

    spDebug(10, "spOpenPluginAiff", "file_type = %s, file_desc = %s\n",
	    pinstance->info.file_type, pinstance->info.file_desc);

    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginAiff(void *instance)
{
    spAiffPluginInstance pinstance = (spAiffPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	spDebug(10, "spClosePluginAiff", "file_type = %s, file_desc = %s\n",
		pinstance->info.file_type, pinstance->info.file_desc);
    
	/* write aiff header using exact length */
	pinstance->info.length = pinstance->current_pos;
	spWriteAiffInfo(&pinstance->info, pinstance->fp);
	
	/* write song info */
	spWriteAiffSongInfo(&pinstance->info, &pinstance->song_info, pinstance->fp);
	
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->current_pos = 0;

#ifdef MACOS
	if (pinstance->type_index == SP_AIFF_TYPE_NONE) {
	    spSetMacFileInfo(pinstance->filename, 0, 'AIFF');
	} else {
	    spSetMacFileInfo(pinstance->filename, 0, 'AIFC');
	}
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateAiff(void *instance)
{
    spAiffPluginInstance pinstance = (spAiffPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionAiff(void *instance)
{
    spAiffPluginInstance pinstance = (spAiffPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginAiff(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginAiff(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginAiff(void *instance)
{

    return SP_TRUE;
}

/*
 * The data for spWritePluginAiff must be 16 bit data
 * regardless of argument for spSetPluginSampleBitAiff.
 */
static long spWritePluginAiff(void *instance, char *data, long length)
{
    spAiffPluginInstance pinstance = (spAiffPluginInstance)instance;    
    long nwrite;
    
    if (pinstance->fp == NULL) return -1;

    if ((nwrite = spWriteAiffData(&pinstance->info, data, length, pinstance->fp)) < 0) {
	return -1;
    }
    pinstance->current_pos += (nwrite / pinstance->info.num_channel);

    return nwrite;
}

static spBool spFlushPluginAiff(void *instance)
{

    return SP_TRUE;
}

