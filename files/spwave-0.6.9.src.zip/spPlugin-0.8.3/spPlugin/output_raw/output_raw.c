/*
 *	output_raw.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#include "plugin_raw.c"

static char *sp_raw_file_type_list[] = {
    "raw",
    "swap",
    "little",
    "big",
    "ulaw",
    "alaw",
    NULL,
};
static char *sp_raw_file_desc_list[] = {
    "Raw",
    "Swap Raw",
    "Little Endian",
    "Big Endian",
    "U-law",
    "A-law",
    NULL,
};
static char *sp_raw_file_filter_list[] = {
    "*",
    "*",
    "*",
    "*",
    "*",
    "*",
    NULL,
};

static spBool spIsSupportedByPluginRaw(char *filename);

static spPluginError spOpenPluginRaw(void *instance, char *filename, char *mode);
static spBool spClosePluginRaw(void *instance);
static spPluginState spGetPluginStateRaw(void *instance);
static long spGetPluginCurrentPositionRaw(void *instance);
static spBool spStopPluginRaw(void *instance);
static spBool spPausePluginRaw(void *instance);
static spBool spRestartPluginRaw(void *instance);

static long spWritePluginRaw(void *instance, char *data, long length);
static spBool spFlushPluginRaw(void *instance);

static spOutputPluginRec sp_output_plugin_raw = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "Raw",
    2,
    SP_PLUGIN_PRIORITY_LOWEST,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginRaw,
    spFreePluginRaw,
    "Raw Output Plugin",
    "Raw Output Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceRaw,
    spFreePluginInstanceRaw,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_raw_file_type_list,
    sp_raw_file_desc_list,
    sp_raw_file_filter_list,
    spIsSupportedByPluginRaw,
    spSetPluginFileTypeRaw,  
    spGetPluginFileTypeRaw,
    0,
    spSetPluginSongInfoRaw,
    spGetPluginSongInfoRaw,
    spGetPluginBestSuffixRaw,

    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
    
    spSetPluginSampleBitRaw,   
    spGetPluginSampleBitRaw,   
    spSetPluginChannelRaw,     
    spGetPluginChannelRaw,     
    spSetPluginSampleRateRaw,  
    spGetPluginSampleRateRaw,  
    spSetPluginOtherInfoRaw,   
    spGetPluginOtherInfoRaw,
    
    spOpenPluginRaw,              
    spClosePluginRaw,             
    spGetPluginStateRaw,          
    spGetPluginCurrentPositionRaw,
    spStopPluginRaw,              
    spPausePluginRaw,             
    spRestartPluginRaw,

    spWritePluginRaw,             
    spFlushPluginRaw,
    NULL,
};

static void updateFileTypeIndex(spRawPluginInstance instance)
{
    int index;
    
    if (!strnone(instance->type)) {
	if ((index = spFindPluginRecFileTypeIndex((spIoPluginRec *)&sp_output_plugin_raw,
						  instance->type)) >= 0) {
	    instance->type_index = index;
	}
    }

    return;
}

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_raw;
}

static spBool spIsSupportedByPluginRaw(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".raw")
	    || strcaseeq(p, ".dat")
	    || strcaseeq(p, ".ad")
	    || strcaseeq(p, ".ad0")
	    || strcaseeq(p, ".ul")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spPluginError spOpenPluginRaw(void *instance, char *filename, char *mode)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;
    char *p;
    
    if (strnone(filename)) return SP_PLUGIN_ERROR_OPEN;

    spDebug(10, "spOpenPluginRaw", "filename = %s\n", filename);

    updateFileTypeIndex(rinstance);

    if (spSetPluginSampleBitRaw(instance, rinstance->samp_bit) == SP_FALSE) {
	return SP_PLUGIN_ERROR_SAMP_BIT;
    }
    
    if ((p = strrchr(filename, '.')) != NULL && strcaseeq(p, ".ul")) {
	rinstance->type_index = SP_RAW_TYPE_ULAW;
    }
    
    if (rinstance->type_index == SP_RAW_TYPE_ULAW || rinstance->type_index == SP_RAW_TYPE_ALAW) {
	if (rinstance->samp_bit > 16) {
	    return SP_PLUGIN_ERROR_SAMP_BIT;
	}
	rinstance->samp_bit = 8;
    }
    
    spDebug(10, "spOpenPluginRaw", "type_index = %d, samp_bit = %d\n",
	    rinstance->type_index, rinstance->samp_bit);

    /* open file */
    if (NULL == (rinstance->fp = spOpenFile(filename, "wb"))) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    strcpy(rinstance->filename, filename);
    rinstance->current_pos = 0;
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginRaw(void *instance)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;
    
    if (rinstance->fp != NULL) {
	/* close file */
	spCloseFile(rinstance->fp);
	rinstance->fp = NULL;
	/*rinstance->head_len = 0;*/
	rinstance->current_pos = 0;

#ifdef MACOS
	spSetMacFileInfo(rinstance->filename, 0, 'disk'); /* FIXME: 'disk' is OK? */
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateRaw(void *instance)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;
    
    if (rinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionRaw(void *instance)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;

    return rinstance->current_pos;
}

static spBool spStopPluginRaw(void *instance)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;
    
    rinstance->current_pos = 0;

    return SP_TRUE;
}

static spBool spPausePluginRaw(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginRaw(void *instance)
{

    return SP_TRUE;
}

static long spWritePluginRaw(void *instance, char *data, long length)
{
    spRawPluginInstance rinstance = (spRawPluginInstance)instance;
    long nwrite;
    spBool swap_flag = SP_FALSE;
    
    if (rinstance->fp == NULL) return -1;

    if (rinstance->type_index == SP_RAW_TYPE_SWAP) {
	swap_flag = SP_TRUE;
    } else {
#if BYTE_ORDER == BIG_ENDIAN
	if (rinstance->type_index == SP_RAW_TYPE_LITTLE) {
	    swap_flag = SP_TRUE;
	}
#else
	if (rinstance->type_index == SP_RAW_TYPE_BIG) {
	    swap_flag = SP_TRUE;
	}
#endif
    }
    
    if (rinstance->samp_bit == 8) {
	if (rinstance->type_index == SP_RAW_TYPE_ULAW) {
	    nwrite = fwriteulaw((short *)data, length, rinstance->fp);
	} else if (rinstance->type_index == SP_RAW_TYPE_ALAW) {
	    nwrite = fwritealaw((short *)data, length, rinstance->fp);
	} else {
	    nwrite = fwritebyte((short *)data, length, rinstance->fp);
	}
    } else if (rinstance->samp_bit == 64) {
	nwrite = fwritedouble((double *)data, length, swap_flag, rinstance->fp);
    } else if (rinstance->samp_bit == 33) {
	nwrite = fwritedoubletof((double *)data, length, swap_flag, rinstance->fp);
    } else if (rinstance->samp_bit == 32) {
	nwrite = fwritelong32((long *)data, length, swap_flag, rinstance->fp);
    } else if (rinstance->samp_bit == 24) {
	nwrite = fwritelong24((long *)data, length, swap_flag, rinstance->fp);
    } else {
	nwrite = fwriteshort((short *)data, length, swap_flag, rinstance->fp);
    }
    rinstance->current_pos += (nwrite / rinstance->num_channel);

    return nwrite;
}

static spBool spFlushPluginRaw(void *instance)
{

    return SP_TRUE;
}

