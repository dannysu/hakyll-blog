
	spPlugin - plug-ins for spAudio I/O

			Last modified: <2002-05-05 00:03:36 hideki>


Introduction
------------

This is a collection of plug-ins for spAudio I/O
(see http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/).
This distribution includes a powerful command-line sound player `spplay'
which uses spPlugin.


BUGS
----

The plug-ins which are compiled on Cygwin can not be loaded (loading the
plug-ins which are compiled by Visual C++ works well). Thus you cannot
create plug-ins on Cygwin environment currently.


License
-------

Please see LICENSE.txt. The licenses of the libraries that spPlugin uses are
not coverted by LICENSE.txt.


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

Thanks To
---------

spPlugin uses the following libraries. I'd like to thank developers of the
libraries.

  * AU/SND, PARIS, NIST, IRCAM, WAV ADPCM, ... (introduced from spPlugin version 0.8.3)
    - libsndfile (http://www.zip.com.au/~erikd/libsndfile/)
      Reading and writing of many of above formats was made possible by
      libsndfile. Thanks Erik.

  * Ogg Vorbis (introduced from spPlugin version 0.8.3)
    - libvorbis and libogg (http://www.vorbis.com/)
 
I also would like to thank people who send me patches, bug reports, and
requests.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
