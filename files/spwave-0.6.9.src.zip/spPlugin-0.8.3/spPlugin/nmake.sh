#! /bin/sh

progs=`ls`
target=""

origlib=$LIB
echo $LIB

if [ .$1 = .clean ]; then
    target="CLEAN"
fi

for prog in $progs ; do
	if [ -d "$prog" -a -f "$prog/$prog.mak" ] ; then
		cd "$prog"
		LIB="$origlib;..\\..\\lib"
		echo $LIB
		if [ -d libsndfile/Makefile ] ; then
		    cd libsndfile
		    make distclean
		    cd ..
		fi
		nmake /f  "$prog.mak" CFG="$prog - Win32 Release" $target
		cd ..
	fi
done

