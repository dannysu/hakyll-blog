/*
 *	output_text.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>
#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#include "plugin_text.c"

static char *sp_text_file_type_list[] = {
    "text",
    "time",
    "freq",
    NULL,
};
static char *sp_text_file_desc_list[] = {
    "Text",
    "Text with Time",
    "Text with Frequency",
    NULL,
};
static char *sp_text_file_filter_list[] = {
    "*",
    "*",
    "*",
    NULL,
};
    
static spBool spIsSupportedByPluginText(char *filename);

static spPluginError spOpenPluginText(void *instance, char *filename, char *mode);
static spBool spClosePluginText(void *instance);
static spPluginState spGetPluginStateText(void *instance);
static long spGetPluginCurrentPositionText(void *instance);
static spBool spStopPluginText(void *instance);
static spBool spPausePluginText(void *instance);
static spBool spRestartPluginText(void *instance);

static long spWritePluginText(void *instance, char *data, long length);
static spBool spFlushPluginText(void *instance);
static spBool spSetPluginTotalLengthText(void *instance, long total_length);

static spOutputPluginRec sp_output_plugin_text = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "Text",
    2,
    SP_PLUGIN_PRIORITY_LOWEST,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginText,
    spFreePluginText,
    "Text Output Plugin",
    "Text Output Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceText,
    spFreePluginInstanceText,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_text_file_type_list,
    sp_text_file_desc_list,
    sp_text_file_filter_list,
    spIsSupportedByPluginText,
    spSetPluginFileTypeText,  
    spGetPluginFileTypeText,
    0,
    spSetPluginSongInfoText,
    spGetPluginSongInfoText,
    spGetPluginBestSuffixText,

    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
    
    spSetPluginSampleBitText,   
    spGetPluginSampleBitText,   
    spSetPluginChannelText,     
    spGetPluginChannelText,     
    spSetPluginSampleRateText,  
    spGetPluginSampleRateText,  
    spSetPluginOtherInfoText,   
    spGetPluginOtherInfoText,
    
    spOpenPluginText,              
    spClosePluginText,             
    spGetPluginStateText,          
    spGetPluginCurrentPositionText,
    spStopPluginText,              
    spPausePluginText,             
    spRestartPluginText,

    spWritePluginText,             
    spFlushPluginText,
    spSetPluginTotalLengthText,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_text;
}

static spBool spIsSupportedByPluginText(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".text")
	    || strcaseeq(p, ".txt")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spPluginError spOpenPluginText(void *instance, char *filename, char *mode)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->type_index == SP_TEXT_TYPE_FREQ
	&& pinstance->file_length <= 0) {
	return SP_PLUGIN_ERROR_TOTAL_LENGTH_REQUIRED;
    }
    
    /* open file */
    if (strnone(filename) || (pinstance->fp = spOpenFile(filename, "w")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    spDebug(10, "spOpenPluginText", "filename = %s\n", filename);

    strcpy(pinstance->filename, filename);
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->head_len = 0;
	pinstance->current_pos = 0;

#ifdef MACOS
	spSetMacFileInfo(pinstance->filename, 0, 'TEXT');
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginText(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginText(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginText(void *instance)
{

    return SP_TRUE;
}

static long spWritePluginText(void *instance, char *data, long length)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    long i;
    long nwrite;
    double *ddata = (double *)data;
    long *ldata = (long *)data;
    short *sdata = (short *)data;
    
    if (pinstance->fp == NULL) return -1;
    if (pinstance->type_index == SP_TEXT_TYPE_FREQ
	&& pinstance->file_length <= 0) return -1;
    
    nwrite = 0;
    for (nwrite = 0; nwrite < length;) {
	if (pinstance->type_index == SP_TEXT_TYPE_TIME) {
	    fprintf(pinstance->fp, "%f ",
		    (double)(pinstance->current_pos +
			     (nwrite / pinstance->num_channel)) / pinstance->samp_rate);
	} else if (pinstance->type_index == SP_TEXT_TYPE_FREQ) {
	    fprintf(pinstance->fp, "%f ",
		    0.5 * pinstance->samp_rate *
		    (double)(pinstance->current_pos + (nwrite / pinstance->num_channel))
		    / (double)(pinstance->file_length-1));
	}
	for (i = 0; i < pinstance->num_channel; i++) {
	    if (pinstance->samp_bit >= 64) {
		fprintf(pinstance->fp, "%.12f ", ddata[nwrite]);
	    } else if (pinstance->samp_bit > 32) {
		fprintf(pinstance->fp, "%f ", ddata[nwrite]);
	    } else if (pinstance->samp_bit > 16) {
		fprintf(pinstance->fp, "%ld ", ldata[nwrite]);
	    } else {
		fprintf(pinstance->fp, "%d ", sdata[nwrite]);
	    }
		
	    nwrite++;
	}
	fprintf(pinstance->fp, "\n");
    }
    
    pinstance->current_pos += (nwrite / pinstance->num_channel);

    return nwrite;
}

static spBool spFlushPluginText(void *instance)
{
    return SP_TRUE;
}

static spBool spSetPluginTotalLengthText(void *instance, long total_length)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;

    pinstance->file_length = total_length;
    
    return SP_TRUE;
}

