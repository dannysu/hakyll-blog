/*
 *	input_sndfile.c
 */

#include <sndfile.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spInputPluginP.h>
#include <sp/spPluginMain.h>

#include <sp/spWaveP.h>

#include "plugin_sndfile.c"

static char *sp_snd_file_type_list[] = {
    "sfwav",
    "sfwavadpcm",
    "sfwavima",
    "sfwavgsm",
    "sfwavml",
    "sfwaval",
    "sfaiff",
    "sfau",
    "sfauml",
    "sfaual",
    "sfaug721",
    "sfaug723",
    "sfaule",
    "sfauleml",
    "sfauleal",
    "sfauleg721",
    "sfauleg723",
    "sfpafbe",
    "sfpafle",
    "sfnistle",
    "sfnistbe",
    "sfircam",
    "sfircamml",
    "sfircamal",
    NULL,
};
static char *sp_snd_file_desc_list[] = {
    SP_SND_TYPE_WAVE_STRING,
    SP_SND_TYPE_WAVE_ADPCM_STRING,
    SP_SND_TYPE_WAVE_IMA_ADPCM_STRING,
    SP_SND_TYPE_WAVE_GSM_STRING,
    SP_SND_TYPE_WAVE_MULAW_STRING,
    SP_SND_TYPE_WAVE_ALAW_STRING,
    SP_SND_TYPE_AIFF_STRING,
    SP_SND_TYPE_AU_STRING,
    SP_SND_TYPE_AU_ULAW_STRING,
    SP_SND_TYPE_AU_ALAW_STRING,
    SP_SND_TYPE_AU_G721_STRING,
    SP_SND_TYPE_AU_G723_STRING,
    SP_SND_TYPE_AULE_STRING,
    SP_SND_TYPE_AULE_ULAW_STRING,
    SP_SND_TYPE_AULE_ALAW_STRING,
    SP_SND_TYPE_AULE_G721_STRING,
    SP_SND_TYPE_AULE_G723_STRING,
    SP_SND_TYPE_PAF_BE_STRING,
    SP_SND_TYPE_PAF_LE_STRING,
    SP_SND_TYPE_NIST_BE_STRING,
    SP_SND_TYPE_NIST_LE_STRING,
    SP_SND_TYPE_IRCAM_STRING,
    SP_SND_TYPE_IRCAM_ULAW_STRING,
    SP_SND_TYPE_IRCAM_ALAW_STRING,
    NULL,
};
static char *sp_snd_file_filter_list[] = {
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.aif",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.paf",
    "*.paf",
    "*.wav",
    "*.wav",
    "*.ircam",
    "*.ircam",
    "*.ircam",
    NULL,
};

static spBool spIsSupportedByPluginSnd(char *filename);

static spPluginError spOpenPluginSnd(void *instance, char *filename, char *mode);
static spBool spClosePluginSnd(void *instance);
static spPluginState spGetPluginStateSnd(void *instance);
static long spGetPluginCurrentPositionSnd(void *instance);
static spBool spStopPluginSnd(void *instance);
static spBool spPausePluginSnd(void *instance);
static spBool spRestartPluginSnd(void *instance);

static long spReadPluginSnd(void *instance, char *data, long length);
static spBool spSeekPluginSnd(void *instance, long pos);
static long spGetPluginTotalLengthSnd(void *instance);

static spInputPluginRec sp_input_plugin_snd = {
    NULL,
    NULL,

    SP_PLUGIN_INPUT,
    "Libsndfile",
    2,
    SP_PLUGIN_PRIORITY_LOWER,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginSnd,
    spFreePluginSnd,
    "Libsndfile Input Plugin",
    "Libsndfile Input Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceSnd,
    spFreePluginInstanceSnd,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_snd_file_type_list,
    sp_snd_file_desc_list,
    sp_snd_file_filter_list,
    spIsSupportedByPluginSnd,
    spSetPluginFileTypeSnd,  
    spGetPluginFileTypeSnd,
    0,
    spSetPluginSongInfoSnd,
    spGetPluginSongInfoSnd,
    spGetPluginBestSuffixSnd,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,

    spSetPluginSampleBitSnd,   
    spGetPluginSampleBitSnd,   
    spSetPluginChannelSnd,     
    spGetPluginChannelSnd,     
    spSetPluginSampleRateSnd,  
    spGetPluginSampleRateSnd,  
    spSetPluginOtherInfoSnd,   
    spGetPluginOtherInfoSnd,
    
    spOpenPluginSnd,              
    spClosePluginSnd,             
    spGetPluginStateSnd,          
    spGetPluginCurrentPositionSnd,
    spStopPluginSnd,              
    spPausePluginSnd,             
    spRestartPluginSnd,

    spReadPluginSnd,             
    spSeekPluginSnd,
    spGetPluginTotalLengthSnd,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_input_plugin_snd;
}

static spBool spIsSupportedByPluginSnd(char *filename)
{
    SNDFILE *sndfile;
    SF_INFO sfinfo;
    
    spDebug(10, "spIsSupportedByPluginSnd", "filename = %s\n", filename);
    
    memset(&sfinfo, 0, sizeof(SF_INFO));

    if ((sndfile = sf_open_read(filename, &sfinfo)) != NULL) {
	spDebug(10, "spIsSupportedByPluginSnd", "supported: %s\n", filename);
	sf_close(sndfile);
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spBool convertSF_INFOToType(SF_INFO *sfinfo, int *type_index)
{
    if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_WAV) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_MS_ADPCM) {
	    *type_index = SP_SND_TYPE_WAVE_ADPCM;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_IMA_ADPCM) {
	    *type_index = SP_SND_TYPE_WAVE_IMA_ADPCM;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_GSM610) {
	    *type_index = SP_SND_TYPE_WAVE_GSM;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ULAW) {
	    *type_index = SP_SND_TYPE_WAVE_ULAW;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ALAW) {
	    *type_index = SP_SND_TYPE_WAVE_ALAW;
	} else {
	    *type_index = SP_SND_TYPE_WAVE;
	}
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_AIFF) {
	*type_index = SP_SND_TYPE_AIFF;
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_AU) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_G721_32) {
	    *type_index = SP_SND_TYPE_AU_G721;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_G723_24) {
	    *type_index = SP_SND_TYPE_AU_G723;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ULAW) {
	    *type_index = SP_SND_TYPE_AU_ULAW;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ALAW) {
	    *type_index = SP_SND_TYPE_AU_ALAW;
	} else {
	    *type_index = SP_SND_TYPE_AU;
	}
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_AULE) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_G721_32) {
	    *type_index = SP_SND_TYPE_AULE_G721;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_G723_24) {
	    *type_index = SP_SND_TYPE_AULE_G723;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ULAW) {
	    *type_index = SP_SND_TYPE_AULE_ULAW;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ALAW) {
	    *type_index = SP_SND_TYPE_AULE_ALAW;
	} else {
	    *type_index = SP_SND_TYPE_AULE;
	}
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_PAF) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_PCM_BE) {
	    *type_index = SP_SND_TYPE_PAF_BE;
	} else {
	    *type_index = SP_SND_TYPE_PAF_LE;
	}
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_NIST) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_PCM_BE) {
	    *type_index = SP_SND_TYPE_NIST_BE;
	} else {
	    *type_index = SP_SND_TYPE_NIST_LE;
	}
    } else if ((sfinfo->format & SF_FORMAT_TYPEMASK) == SF_FORMAT_IRCAM) {
	if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ULAW) {
	    *type_index = SP_SND_TYPE_IRCAM_ULAW;
	} else if ((sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_ALAW) {
	    *type_index = SP_SND_TYPE_IRCAM_ALAW;
	} else {
	    *type_index = SP_SND_TYPE_IRCAM;
	}
    } else {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static spBool loadSongInfo(spSndPluginInstance pinstance, char *filename)
{
    FILE *fp;

    if (strnone(filename)) return SP_FALSE;
    
    spDebug(10, "loadSongInfo", "filename = %s\n", filename);
    
    spInitSongInfo(&pinstance->song_info);
    pinstance->song_info_mask = 0;
    
    if ((fp = spOpenFile(filename, "rb")) != NULL) {
	if (spGetWavSongInfo(&pinstance->song_info, fp) == SP_TRUE) {
	    /* do nothing */
	} else if (fseek(fp, 0, SEEK_SET) == 0
		   && spGetAiffSongInfo(&pinstance->song_info, fp) == SP_TRUE) {
	    /* do nothing */
	}
	spCloseFile(fp);
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spPluginError spOpenPluginSnd(void *instance, char *filename, char *mode)
{
    unsigned int format_type;
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;

    if (loadSongInfo(pinstance, filename) == SP_FALSE) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    strcpy(pinstance->filename, "");
    
    /* open file */
    if ((pinstance->sndfile = sf_open_read(filename, &pinstance->sfinfo)) == NULL) {
	sf_perror(NULL);
	spDebug(10, "spOpenPluginSnd", "sf_open_read failed\n");
	return SP_PLUGIN_ERROR_OPEN;
    }
    if (convertSF_INFOToType(&pinstance->sfinfo, &pinstance->type_index) == SP_FALSE
	|| pinstance->type_index < 0) {
	spClosePluginSnd(instance);
	return SP_PLUGIN_ERROR_FILE_TYPE;
    }

    format_type = pinstance->sfinfo.format & SF_FORMAT_TYPEMASK;
    
    if (format_type == SF_FORMAT_WAV) {
	pinstance->song_info_mask =
	    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK
	     | SP_SONG_GENRE_MASK | SP_SONG_RELEASE_MASK | SP_SONG_COPYRIGHT_MASK
	     | SP_SONG_ENGINEER_MASK | SP_SONG_SOURCE_MASK | SP_SONG_SOFTWARE_MASK
	     | SP_SONG_SUBJECT_MASK);
    } else if (format_type == SF_FORMAT_AIFF) {
	pinstance->song_info_mask =
	    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK
	     | SP_SONG_COMMENT_MASK | SP_SONG_COPYRIGHT_MASK);
    }
	
    pinstance->current_pos = 0;
    strcpy(pinstance->filename, filename);

    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->sndfile != NULL) {
	/* close file */
	sf_close(pinstance->sndfile);
	pinstance->sndfile = NULL;
	pinstance->current_pos = 0;

	return SP_TRUE;
    }

    return SP_FALSE;
}

static spPluginState spGetPluginStateSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->sndfile != NULL) {
	sf_seek(pinstance->sndfile, 0, SEEK_SET);
    }
    pinstance->current_pos = 0;

    return SP_TRUE;
}

static spBool spPausePluginSnd(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginSnd(void *instance)
{

    return SP_TRUE;
}

static long spReadPluginSnd(void *instance, char *data, long length)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;    
    long nread;
    
    if (pinstance->sndfile == NULL) return -1;

    spDebug(10, "spReadPluginSnd", "pcmbitwidth = %d\n", pinstance->sfinfo.pcmbitwidth);
	
    if (pinstance->sfinfo.pcmbitwidth <= 16) {
	nread = sf_read_short(pinstance->sndfile, (short *)data, length);
	if (pinstance->sfinfo.pcmbitwidth < 16) {
	    long k;
	    short *sdata = (short *)data;
	    
	    for (k = 0; k < nread; k++) {
		sdata[k] *= 256;
	    }
	}
    } else if (pinstance->sfinfo.pcmbitwidth == 32
	       && (pinstance->sfinfo.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT) {
	nread = sf_read_float(pinstance->sndfile, (float *)data, length);
    } else if (pinstance->sfinfo.pcmbitwidth <= 32) {
	nread = sf_read_int(pinstance->sndfile, (int *)data, length);
	if (sizeof(int) != sizeof(long)) {
	    long k;
	    int *idata = (int *)data;
	    long *ldata = (long *)data;
	    
	    spDebug(10, "spReadPluginSnd", "convert int (%d byte) to long (%d byte)\n",
		    sizeof(int), sizeof(long));

	    for (k = nread - 1; k >= 0; k--) {
		ldata[k] = idata[k];
	    }
	}
    } else {
	nread = sf_read_double(pinstance->sndfile, (double *)data, length, 0);
    }
    if (nread < 0) {
	return -1;
    }
    pinstance->current_pos += (nread / pinstance->sfinfo.channels);
    
    return nread;
}

static spBool spSeekPluginSnd(void *instance, long pos)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->sndfile == NULL) return SP_FALSE;
    
    if (sf_seek(pinstance->sndfile, pos, SEEK_SET) < 0) {
	return SP_FALSE;
    }
    pinstance->current_pos = pos;
    
    return SP_TRUE;
}

static long spGetPluginTotalLengthSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->total_length <= 0) {
	pinstance->total_length = pinstance->sfinfo.samples;
    }

    return pinstance->total_length;
}

