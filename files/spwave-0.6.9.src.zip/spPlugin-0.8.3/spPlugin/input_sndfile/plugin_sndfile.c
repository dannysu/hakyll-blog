/*
 *	plugin_sndfile.c
 */

#include <sndfile.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spInputPluginP.h>

#define SP_SND_TYPE_WAVE 0
#define SP_SND_TYPE_WAVE_ADPCM 1
#define SP_SND_TYPE_WAVE_IMA_ADPCM 2
#define SP_SND_TYPE_WAVE_GSM 3
#define SP_SND_TYPE_WAVE_ULAW 4
#define SP_SND_TYPE_WAVE_ALAW 5
#define SP_SND_TYPE_AIFF 6
#define SP_SND_TYPE_AU 7
#define SP_SND_TYPE_AU_ULAW 8
#define SP_SND_TYPE_AU_ALAW 9
#define SP_SND_TYPE_AU_G721 10
#define SP_SND_TYPE_AU_G723 11
#define SP_SND_TYPE_AULE 12
#define SP_SND_TYPE_AULE_ULAW 13
#define SP_SND_TYPE_AULE_ALAW 14
#define SP_SND_TYPE_AULE_G721 15
#define SP_SND_TYPE_AULE_G723 16
#define SP_SND_TYPE_PAF_BE 17
#define SP_SND_TYPE_PAF_LE 18
#define SP_SND_TYPE_NIST_BE 19
#define SP_SND_TYPE_NIST_LE 20
#define SP_SND_TYPE_IRCAM 21
#define SP_SND_TYPE_IRCAM_ULAW 22
#define SP_SND_TYPE_IRCAM_ALAW 23
#define SP_NUM_SND_TYPE (SP_SND_TYPE_IRCAM_ALAW+1)

#define SP_SND_TYPE_WAVE_STRING "Microsoft PCM (libsndfile)"
#define SP_SND_TYPE_WAVE_ADPCM_STRING "Microsoft ADPCM (libsndfile)"
#define SP_SND_TYPE_WAVE_IMA_ADPCM_STRING "WAVE IMA ADPCM (libsndfile)"
#define SP_SND_TYPE_WAVE_GSM_STRING "Microsoft GSM 6.10 (libsndfile)"
#define SP_SND_TYPE_WAVE_MULAW_STRING "Microsoft U-law (libsndfile)"
#define SP_SND_TYPE_WAVE_ALAW_STRING "Microsoft A-law (libsndfile)"
#define SP_SND_TYPE_AIFF_STRING "AIFF (libsndfile)"
#define SP_SND_TYPE_AU_STRING "Sun/NeXT AU/SND (libsndfile)"
#define SP_SND_TYPE_AU_ULAW_STRING "Sun/NeXT AU/SND U-law (libsndfile)"
#define SP_SND_TYPE_AU_ALAW_STRING "Sun/NeXT AU/SND A-law (libsndfile)"
#define SP_SND_TYPE_AU_G721_STRING "Sun/NeXT AU/SND G721 (libsndfile)"
#define SP_SND_TYPE_AU_G723_STRING "Sun/NeXT AU/SND G723 (libsndfile)"
#define SP_SND_TYPE_AULE_STRING "Dec AU (libsndfile)"
#define SP_SND_TYPE_AULE_ULAW_STRING "Dec AU U-law (libsndfile)"
#define SP_SND_TYPE_AULE_ALAW_STRING "Dec AU A-law (libsndfile)"
#define SP_SND_TYPE_AULE_G721_STRING "Dec AU G721 (libsndfile)"
#define SP_SND_TYPE_AULE_G723_STRING "Dec AU G723 (libsndfile)"
#define SP_SND_TYPE_PAF_BE_STRING "Ensoniq PARIS Big Endian (libsndfile)"
#define SP_SND_TYPE_PAF_LE_STRING "Ensoniq PARIS Little Endian (libsndfile)"
#define SP_SND_TYPE_NIST_BE_STRING "Sphere NIST Big Endian (libsndfile)"
#define SP_SND_TYPE_NIST_LE_STRING "Sphere NIST Little Endian (libsndfile)"
#define SP_SND_TYPE_IRCAM_STRING "IRCAM (libsndfile)"
#define SP_SND_TYPE_IRCAM_ULAW_STRING "IRCAM U-law (libsndfile)"
#define SP_SND_TYPE_IRCAM_ALAW_STRING "IRCAM AU A-law (libsndfile)"

typedef struct _spSndPluginInstance
{
    int type_index;
    SNDFILE *sndfile;
    SF_INFO sfinfo;

    unsigned long song_info_mask;
    spSongInfo song_info;
    char filename[SP_MAX_PATHNAME];
    long current_pos;
    long total_length;

    char *buffer;
    long buffer_size;
} *spSndPluginInstance;

static spBool spInitPluginSnd(char *lang)
{
    return SP_TRUE;
}

static spBool spFreePluginSnd(void)
{
    return SP_TRUE;
}

static void *spInitPluginInstanceSnd(char *lang)
{
    spSndPluginInstance instance;
    
    instance = xalloc(1, struct _spSndPluginInstance);
    instance->type_index = /*SP_SND_TYPE_WAVE*/-1;
    instance->sndfile = NULL;
    memset(&instance->sfinfo, 0, sizeof(SF_INFO));
    instance->sfinfo.format = SF_FORMAT_PCM;

    instance->song_info_mask = 0;
    strcpy(instance->filename, "");
    instance->current_pos = 0;
    instance->total_length = 0;

    instance->buffer = NULL;
    instance->buffer_size = 0;
    
    return (void *)instance;
}

static spBool spFreePluginInstanceSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->buffer != NULL) {
	xfree(pinstance->buffer);
    }
    
    xfree(pinstance);
    return SP_TRUE;
}

static spBool spSetPluginFileTypeSnd(void *instance, int index)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;

    spDebug(10, "spSetPluginFileTypeSnd", "index = %d\n", index);
    
    if (index >= 0 && index < SP_NUM_SND_TYPE) {
	pinstance->type_index = index;
    } else {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static int spGetPluginFileTypeSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    return pinstance->type_index;
}

static spBool spSetPluginSongInfoSnd(void *instance, spSongInfo *song_info)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    spCopySongInfo(&pinstance->song_info, song_info);

    return SP_TRUE;
}

static spBool spGetPluginSongInfoSnd(void *instance, spSongInfo *song_info)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    spCopySongInfo(song_info, &pinstance->song_info);

    return SP_TRUE;
}

static char *spGetPluginBestSuffixSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    switch (pinstance->type_index) {
      case SP_SND_TYPE_WAVE:
      case SP_SND_TYPE_WAVE_ADPCM:
      case SP_SND_TYPE_WAVE_IMA_ADPCM:
      case SP_SND_TYPE_WAVE_GSM:
      case SP_SND_TYPE_WAVE_ULAW:
      case SP_SND_TYPE_WAVE_ALAW:
	return ".wav";

      case SP_SND_TYPE_AIFF:
	return ".aif";
	
      case SP_SND_TYPE_AU:
      case SP_SND_TYPE_AU_ULAW:
      case SP_SND_TYPE_AU_ALAW:
      case SP_SND_TYPE_AU_G721:
      case SP_SND_TYPE_AU_G723:
      case SP_SND_TYPE_AULE:
      case SP_SND_TYPE_AULE_ULAW:
      case SP_SND_TYPE_AULE_ALAW:
      case SP_SND_TYPE_AULE_G721:
      case SP_SND_TYPE_AULE_G723:
	return ".au";

      case SP_SND_TYPE_PAF_BE:
      case SP_SND_TYPE_PAF_LE:
	return ".paf";
	
      case SP_SND_TYPE_NIST_BE:
      case SP_SND_TYPE_NIST_LE:
	return ".wav";
	
      case SP_SND_TYPE_IRCAM:
      case SP_SND_TYPE_IRCAM_ULAW:
      case SP_SND_TYPE_IRCAM_ALAW:
	return ".ircam";
	
      default:
	break;
    }

    return NULL;
}

static spBool spSetPluginSampleBitSnd(void *instance, int samp_bit)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (samp_bit == 8) {
	pinstance->sfinfo.pcmbitwidth = 8;
    } else if (samp_bit == 16) {
	pinstance->sfinfo.pcmbitwidth = 16;
    } else if (samp_bit == 24) {
	pinstance->sfinfo.pcmbitwidth = 24;
    } else if (samp_bit == 32) {
	pinstance->sfinfo.pcmbitwidth = 32;
    } else if (samp_bit == 33) {
	pinstance->sfinfo.pcmbitwidth = 32;
	pinstance->sfinfo.format &= SF_FORMAT_TYPEMASK;
	pinstance->sfinfo.format |= SF_FORMAT_FLOAT;
    } else {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spGetPluginSampleBitSnd(void *instance, int *samp_bit)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;

    if (pinstance->sfinfo.pcmbitwidth == 32
	&& (pinstance->sfinfo.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT) {
	*samp_bit = 33;
    } else {
	*samp_bit = pinstance->sfinfo.pcmbitwidth;
    }
    spDebug(10, "spGetPluginSampleBitSnd", "samp_bit = %d\n", *samp_bit);

    return SP_TRUE;
}

static spBool spSetPluginChannelSnd(void *instance, int num_channel)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    pinstance->sfinfo.channels = MAX(num_channel, 1);
    
    return SP_TRUE;
}

static spBool spGetPluginChannelSnd(void *instance, int *num_channel)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    *num_channel = pinstance->sfinfo.channels;

    return SP_TRUE;
}

static spBool spSetPluginSampleRateSnd(void *instance, double samp_rate)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    pinstance->sfinfo.samplerate = (unsigned int)spRound(samp_rate);

    return SP_TRUE;
}

static spBool spGetPluginSampleRateSnd(void *instance, double *samp_rate)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    *samp_rate = (double)pinstance->sfinfo.samplerate;

    return SP_TRUE;
}

static spBool spSetPluginOtherInfoSnd(void *instance, char *id, char *data)
{
    return SP_FALSE;
}

static spBool spGetPluginOtherInfoSnd(void *instance, char *id, char *data)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (streq(id, SP_PLUGIN_INFO_SONG_INFO_MASK)) {
	unsigned long *mask;
	
	mask = (unsigned long *)data;
	*mask = pinstance->song_info_mask;
	return SP_TRUE;
    }
    
    return SP_FALSE;
}
