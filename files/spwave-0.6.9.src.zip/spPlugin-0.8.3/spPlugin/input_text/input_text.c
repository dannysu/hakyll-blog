/*
 *	input_text.c
 */
#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>
#include <sp/spInputPluginP.h>
#include <sp/spPluginMain.h>

#include "plugin_text.c"

static char *sp_text_file_type_list[] = {
    "text",
    "time",
    "freq",
    NULL,
};
static char *sp_text_file_desc_list[] = {
    "Text",
    "Text with Time",
    "Text with Frequency",
    NULL,
};
static char *sp_text_file_filter_list[] = {
    "*",
    "*",
    "*",
    NULL,
};
    
static spOptions spInitPluginOptionsText(void *instance, char *lang);
static spBool spFreePluginOptionsText(void *instance, spOptions options);
static spBool spIsSupportedByPluginText(char *filename);

static spPluginError spOpenPluginText(void *instance, char *filename, char *mode);
static spBool spClosePluginText(void *instance);
static spPluginState spGetPluginStateText(void *instance);
static long spGetPluginCurrentPositionText(void *instance);
static spBool spStopPluginText(void *instance);
static spBool spPausePluginText(void *instance);
static spBool spRestartPluginText(void *instance);

static long spReadPluginText(void *instance, char *data, long length);
static spBool spSeekPluginText(void *instance, long pos);
static long spGetPluginTotalLengthText(void *instance);

static spInputPluginRec sp_input_plugin_text = {
    NULL,
    NULL,

    SP_PLUGIN_INPUT,
    "Text",
    2,
    SP_PLUGIN_PRIORITY_NULL,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginText,
    spFreePluginText,
    "Text Input Plugin",
    "Text Input Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",

    spInitPluginInstanceText,
    spFreePluginInstanceText,
    spInitPluginOptionsText,
    spFreePluginOptionsText,
    
    SP_PLUGIN_DEVICE_FILE,
    sp_text_file_type_list,
    sp_text_file_desc_list,
    sp_text_file_filter_list,
    spIsSupportedByPluginText,
    spSetPluginFileTypeText,  
    spGetPluginFileTypeText,
    0,
    spSetPluginSongInfoText,
    spGetPluginSongInfoText,
    spGetPluginBestSuffixText,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
    
    spSetPluginSampleBitText,   
    spGetPluginSampleBitText,   
    spSetPluginChannelText,     
    spGetPluginChannelText,     
    spSetPluginSampleRateText,  
    spGetPluginSampleRateText,  
    spSetPluginOtherInfoText,   
    spGetPluginOtherInfoText,
    
    spOpenPluginText,              
    spClosePluginText,             
    spGetPluginStateText,          
    spGetPluginCurrentPositionText,
    spStopPluginText,              
    spPausePluginText,             
    spRestartPluginText,

    spReadPluginText,             
    spSeekPluginText,
    spGetPluginTotalLengthText,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_input_plugin_text;
}

static spOptions spInitPluginOptionsText(void *instance, char *lang)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    spOption options[] = {
	{"-f", "-freq", "sampling frequency for text data [Hz]",
	     "samp_freq|Sampling Frequency|120|0|Hz|0",
	     SP_TYPE_EDITABLE|SP_TYPE_COMBO|SP_TYPE_DOUBLE, NULL,
	     "8000.0|11025.0|12000.0|16000.0|22050.0|24000.0|32000.0|44100.0|48000.0|96000.0"},
	{"-c", "-channel", "number of channel for text data",
	     "num_channel|Number of Channel|120",
	     SP_TYPE_EDITABLE|SP_TYPE_COMBO|SP_TYPE_INT, NULL,
	     "1|2|3|4|5|6|8|10|12|16"},
	{"-b", "-bit", "bits per sample for text data",
	     "bits_per_sample|Bits/Sample|120|0|bits",
	     SP_TYPE_COMBO|SP_TYPE_INT, NULL,
	     "8|@16|64"},
    };
    options[0].value = &pinstance->samp_rate;
    options[1].value = &pinstance->num_channel;
    options[2].value = &pinstance->samp_bit;

    return spCopyOptions(spArraySize(options), options);
}

static spBool spFreePluginOptionsText(void *instance, spOptions options)
{
    spFreeOptions(options);
    return SP_TRUE;
}

static spBool spIsSupportedByPluginText(char *filename)
{
#if 0
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".text")
	    || strcaseeq(p, ".txt")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
#else
    return SP_TRUE;
#endif
}

static spPluginError spOpenPluginText(void *instance, char *filename, char *mode)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (strnone(filename)) return SP_PLUGIN_ERROR_OPEN;

    spDebug(10, "spOpenPluginText", "filename = %s\n", filename);

    /* get file length */
    pinstance->file_length = getfilesize_txt(filename);
    
    /* open file */
    if (NULL == (pinstance->fp = spOpenFile(filename, "r"))) {
	return SP_PLUGIN_ERROR_FAILURE;
    }

    /* skip header */
    fseek(pinstance->fp, pinstance->head_len, SEEK_SET);
    pinstance->current_pos = 0;

    spDebug(10, "spOpenPluginText", "head_len = %d\n", pinstance->head_len);
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->head_len = 0;
	pinstance->current_pos = 0;
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	fseek(pinstance->fp, pinstance->head_len, SEEK_SET);
    }
    pinstance->current_pos = 0;

    return SP_TRUE;
}

static spBool spPausePluginText(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginText(void *instance)
{

    return SP_TRUE;
}

static long spReadPluginText(void *instance, char *data, long length)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    long offset;
    long i;
    long nread;
    char line[SP_MAX_LINE];
    char buf[SP_MAX_LINE];
    double *ddata = (double *)data;
    long *ldata = (long *)data;
    short *sdata = (short *)data;

    if (pinstance->fp == NULL) return -1;

    if (pinstance->type_index == SP_TEXT_TYPE_NORMAL) {
	offset = 0;
    } else {
	offset = 1;
    }
    
    nread = 0;
    while (fgetnline(line, SP_MAX_LINE, pinstance->fp) != EOF) {
	if (nread >= length) {
	    break;
	}
	    
	for (i = offset; i < pinstance->num_channel + offset; i++) {
	    if (sgetncol(buf, SP_MAX_LINE, i, line) != EOF) {
		if (pinstance->samp_bit > 32) {
		    ddata[nread] = atof(buf);
		} else if (pinstance->samp_bit > 16) {
		    ldata[nread] = atol(buf);
		} else {
		    sdata[nread] = atoi(buf);
		}
	    } else {
		if (pinstance->samp_bit > 32) {
		    ddata[nread] = 0.0;
		} else if (pinstance->samp_bit > 16) {
		    ldata[nread] = 0;
		} else {
		    sdata[nread] = 0;
		}
	    }
	    nread++;
	}
    }
    pinstance->current_pos += (nread / pinstance->num_channel);
    
    return nread;
}

static spBool spSeekPluginText(void *instance, long pos)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    long k;
    char line[SP_MAX_LINE];
    
    if (pinstance->fp == NULL) return SP_FALSE;

    fseek(pinstance->fp, pinstance->head_len, SEEK_SET);

    k = 0;
    do {
	if (k >= pos) {
	    break;
	}
	k++;
    } while (fgetnline(line, SP_MAX_LINE, pinstance->fp) != EOF);
    
    pinstance->current_pos = pos;
    
    return SP_TRUE;
}

static long spGetPluginTotalLengthText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    return pinstance->file_length;
}

