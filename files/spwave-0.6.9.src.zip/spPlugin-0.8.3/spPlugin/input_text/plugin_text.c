/*
 *	plugin_text.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>
#include <sp/spOutputPluginP.h>

#define SP_TEXT_TYPE_NORMAL 0
#define SP_TEXT_TYPE_TIME 1
#define SP_TEXT_TYPE_FREQ 2

typedef struct _spTextPluginInstance
{
    int type_index;
    int samp_bit;
    int num_channel;
    double samp_rate;
    long head_len;

    char filename[SP_MAX_PATHNAME];
    FILE *fp;
    long current_pos;
    long file_length;
} *spTextPluginInstance;

static spBool spInitPluginText(char *lang)
{
    /*spSetDebugLevel(10);*/

    return SP_TRUE;
}

static spBool spFreePluginText(void)
{

    return SP_TRUE;
}

static void *spInitPluginInstanceText(char *lang)
{
    spTextPluginInstance instance;
    
    instance = xalloc(1, struct _spTextPluginInstance);
    instance->type_index = SP_TEXT_TYPE_NORMAL;
    instance->samp_bit = 16;
    instance->num_channel = 1;
    instance->samp_rate = 8000.0;
    instance->head_len = 0;
    
    strcpy(instance->filename, "");
    instance->fp = NULL;
    instance->current_pos = 0;
    instance->file_length = 0;

    return (void *)instance;
}

static spBool spFreePluginInstanceText(void *instance)
{
    xfree(instance);
    return SP_TRUE;
}

static spBool spSetPluginFileTypeText(void *instance, int index)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    pinstance->type_index = index;
    
    return SP_TRUE;
}

static int spGetPluginFileTypeText(void *instance)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    return pinstance->type_index;
}

static spBool spSetPluginSongInfoText(void *instance, spSongInfo *song_info)
{

    return SP_FALSE;
}

static spBool spGetPluginSongInfoText(void *instance, spSongInfo *song_info)
{

    return SP_FALSE;
}

static char *spGetPluginBestSuffixText(void *instance)
{

    return NULL;
}

static spBool spSetPluginSampleBitText(void *instance, int samp_bit)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;

#if 0
    if (samp_bit == 8 || samp_bit == 16 || samp_bit == 64) {
	pinstance->samp_bit = samp_bit;
	return SP_TRUE;
    }
    
    return SP_FALSE;
#else
    pinstance->samp_bit = samp_bit;
    
    return SP_TRUE;
#endif
}

static spBool spGetPluginSampleBitText(void *instance, int *samp_bit)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    *samp_bit = pinstance->samp_bit;
    
    return SP_TRUE;
}

static spBool spSetPluginChannelText(void *instance, int num_channel)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    pinstance->num_channel = num_channel;
    
    return SP_TRUE;
}

static spBool spGetPluginChannelText(void *instance, int *num_channel)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    *num_channel = pinstance->num_channel;
    
    return SP_TRUE;
}

static spBool spSetPluginSampleRateText(void *instance, double samp_rate)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    pinstance->samp_rate = samp_rate;
    
    return SP_TRUE;
}

static spBool spGetPluginSampleRateText(void *instance, double *samp_rate)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    *samp_rate = pinstance->samp_rate;
    
    return SP_TRUE;
}

static spBool spSetPluginOtherInfoText(void *instance, char *id, char *data)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (strcaseeq(id, SP_HEADER_LENGTH_ID)) {
	long *len = (long *)data;
	pinstance->head_len = *len;
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool spGetPluginOtherInfoText(void *instance, char *id, char *data)
{
    spTextPluginInstance pinstance = (spTextPluginInstance)instance;
    
    if (strcaseeq(id, SP_HEADER_LENGTH_ID)) {
	long *len = (long *)data;
	*len = pinstance->head_len;
	return SP_TRUE;
    }

    return SP_FALSE;
}
