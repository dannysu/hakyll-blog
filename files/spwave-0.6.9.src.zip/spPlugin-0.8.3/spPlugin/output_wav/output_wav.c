/*
 *	output_wav.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#include <sp/spWaveP.h>

#include "plugin_wav.c"

static char *sp_wav_file_type_list[] = {
    SP_WAVE_WAV_ID,
    SP_WAVE_WAV_ID,
    SP_WAVE_WAV_ID,
    NULL,
};
static char *sp_wav_file_desc_list[] = {
    WAVE_FORMAT_PCM_STRING,
    WAVE_FORMAT_MULAW_STRING,
    WAVE_FORMAT_ALAW_STRING,
    NULL,
};
static char *sp_wav_file_filter_list[] = {
    "*.wav",
    "*.wav",
    "*.wav",
    NULL,
};
    
static spBool spIsSupportedByPluginWav(char *filename);

static spPluginError spOpenPluginWav(void *instance, char *filename, char *mode);
static spBool spClosePluginWav(void *instance);
static spPluginState spGetPluginStateWav(void *instance);
static long spGetPluginCurrentPositionWav(void *instance);
static spBool spStopPluginWav(void *instance);
static spBool spPausePluginWav(void *instance);
static spBool spRestartPluginWav(void *instance);

static long spWritePluginWav(void *instance, char *data, long length);
static spBool spFlushPluginWav(void *instance);


static spOutputPluginRec sp_output_plugin_wav = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "Wav",
    2,
    SP_PLUGIN_PRIORITY_MIDDLE,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginWav,
    spFreePluginWav,
    "Wav Output Plugin",
    "Wav Output Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",

    spInitPluginInstanceWav,
    spFreePluginInstanceWav,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_wav_file_type_list,
    sp_wav_file_desc_list,
    sp_wav_file_filter_list,
    spIsSupportedByPluginWav,
    spSetPluginFileTypeWav,  
    spGetPluginFileTypeWav,
    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK
     | SP_SONG_GENRE_MASK | SP_SONG_RELEASE_MASK | SP_SONG_COPYRIGHT_MASK
     | SP_SONG_ENGINEER_MASK | SP_SONG_SOURCE_MASK | SP_SONG_SOFTWARE_MASK
     | SP_SONG_SUBJECT_MASK),
    spSetPluginSongInfoWav,
    spGetPluginSongInfoWav,
    spGetPluginBestSuffixWav,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
	    
    spSetPluginSampleBitWav,   
    spGetPluginSampleBitWav,   
    spSetPluginChannelWav,     
    spGetPluginChannelWav,     
    spSetPluginSampleRateWav,  
    spGetPluginSampleRateWav,  
    spSetPluginOtherInfoWav,   
    spGetPluginOtherInfoWav,
    
    spOpenPluginWav,              
    spClosePluginWav,             
    spGetPluginStateWav,          
    spGetPluginCurrentPositionWav,
    spStopPluginWav,              
    spPausePluginWav,             
    spRestartPluginWav,

    spWritePluginWav,             
    spFlushPluginWav,
    NULL,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_wav;
}

static spBool spIsSupportedByPluginWav(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".wav")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spPluginError spOpenPluginWav(void *instance, char *filename, char *mode)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    /* open file */
    if (strnone(filename)) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    if (pinstance->type_index == SP_WAV_TYPE_ULAW || pinstance->type_index == SP_WAV_TYPE_ALAW) {
	if (pinstance->info.samp_bit > 16) {
	    return SP_PLUGIN_ERROR_SAMP_BIT;
	}
	pinstance->info.samp_bit = 8;
    }
    
    if (spSetPluginSampleBitWav(instance, pinstance->info.samp_bit) == SP_FALSE) {
	return SP_PLUGIN_ERROR_SAMP_BIT;
    }
    
    if ((pinstance->fp = spOpenFile(filename, "wb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    
    /* write wav header using length 1 */
    pinstance->info.length = 1;
    strcpy(pinstance->info.file_type, sp_wav_file_type_list[pinstance->type_index]);
    strcpy(pinstance->info.file_desc, sp_wav_file_desc_list[pinstance->type_index]);
    if (spWriteWavInfo(&pinstance->info, pinstance->fp) == SP_FALSE) {
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_WRITE;
    }
    
    pinstance->current_pos = 0;
    strcpy(pinstance->filename, filename);

    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	/* write wav header using exact length */
	pinstance->info.length = pinstance->current_pos;
	spWriteWavInfo(&pinstance->info, pinstance->fp);
	
	/* write song info */
	spWriteWavSongInfo(&pinstance->info, &pinstance->song_info, pinstance->fp);
	
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->current_pos = 0;

#ifdef MACOS
	spSetMacFileInfo(pinstance->filename, 0, 'WAVE');
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionWav(void *instance)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginWav(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginWav(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginWav(void *instance)
{

    return SP_TRUE;
}

/*
 * The data for spWritePluginWav must be 16 bit data
 * regardless of argument for spSetPluginSampleBitWav.
 */
static long spWritePluginWav(void *instance, char *data, long length)
{
    spWavPluginInstance pinstance = (spWavPluginInstance)instance;    
    long nwrite;
    
    if (pinstance->fp == NULL) return -1;

    if ((nwrite = spWriteWavData(&pinstance->info, data, length, pinstance->fp)) < 0) {
	return -1;
    }
    pinstance->current_pos += (nwrite / pinstance->info.num_channel);

    return nwrite;
}

static spBool spFlushPluginWav(void *instance)
{

    return SP_TRUE;
}

