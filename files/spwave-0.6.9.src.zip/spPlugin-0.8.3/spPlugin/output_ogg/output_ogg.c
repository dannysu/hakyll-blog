/*
 *	output_ogg.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spWave.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#include <vorbis/vorbisfile.h>
#include <vorbis/vorbisenc.h>

#include "plugin_ogg.c"

static char *sp_ogg_file_type_list[] = {
    "ogg",
    NULL,
};
static char *sp_ogg_file_desc_list[] = {
    "Ogg Vorbis",
    NULL,
};
static char *sp_ogg_file_filter_list[] = {
    "*.ogg",
    NULL,
};
    
static spOptions spInitPluginOptionsOgg(void *instance, char *lang);
static spBool spFreePluginOptionsOgg(void *instance, spOptions options);

static spBool spIsSupportedByPluginOgg(char *filename);

static spPluginError spOpenPluginOgg(void *instance, char *filename, char *mode);
static spBool spClosePluginOgg(void *instance);
static spPluginState spGetPluginStateOgg(void *instance);
static long spGetPluginCurrentPositionOgg(void *instance);
static spBool spStopPluginOgg(void *instance);
static spBool spPausePluginOgg(void *instance);
static spBool spRestartPluginOgg(void *instance);

static long spWritePluginOgg(void *instance, char *data, long length);
static spBool spFlushPluginOgg(void *instance);


static spOutputPluginRec sp_output_plugin_ogg = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "OGG",
    1,
    SP_PLUGIN_PRIORITY_HIGHER,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginOgg,
    spFreePluginOgg,
    "Ogg Vorbis Output Plugin",
    "Ogg Vorbis Output Plugin Version 0.1\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceOgg,
    spFreePluginInstanceOgg,
    spInitPluginOptionsOgg,
    spFreePluginOptionsOgg,

    SP_PLUGIN_DEVICE_FILE,
    sp_ogg_file_type_list,
    sp_ogg_file_desc_list,
    sp_ogg_file_filter_list,
    spIsSupportedByPluginOgg,
    spSetPluginFileTypeOgg,  
    spGetPluginFileTypeOgg,
    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK
     | SP_SONG_GENRE_MASK | SP_SONG_RELEASE_MASK | SP_SONG_COPYRIGHT_MASK
     | SP_SONG_TRACK_MASK | SP_SONG_SOURCE_MASK | SP_SONG_ALBUM_MASK),
    spSetPluginSongInfoOgg,
    spGetPluginSongInfoOgg,
    spGetPluginBestSuffixOgg,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
	    
    spSetPluginSampleBitOgg,   
    spGetPluginSampleBitOgg,   
    spSetPluginChannelOgg,     
    spGetPluginChannelOgg,     
    spSetPluginSampleRateOgg,  
    spGetPluginSampleRateOgg,  
    spSetPluginOtherInfoOgg,   
    spGetPluginOtherInfoOgg,
    
    spOpenPluginOgg,              
    spClosePluginOgg,             
    spGetPluginStateOgg,          
    spGetPluginCurrentPositionOgg,
    spStopPluginOgg,              
    spPausePluginOgg,             
    spRestartPluginOgg,

    spWritePluginOgg,             
    spFlushPluginOgg,
    NULL,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_ogg;
}

static spOptions spInitPluginOptionsOgg(void *instance, char *lang)
{
    int i;
    int num_option;
    spOption *options;
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;
#if defined(_WIN32) || defined(MACOS)
#include "options_SJIS.h"
    char *ja_lang = "ja_JP.SJIS";
#else
#include "options_EUCJP.h"
    char *ja_lang = "ja_JP.eucJP";
#endif
    spOption options_en[] = {
	{"-br", NULL, "averate bit rate (0: Variable Bit Rate)", "bit_rate|Bit Rate|130|0|kbit/sec|0",
	     SP_TYPE_COMBO|SP_TYPE_LONG|SP_TYPE_SHOW_TIP, NULL, "0|64|80|96|112|128|160|192|224|256|320"},
	{"-quality", NULL, "quality for VBR (0: low, 10: high)", "quality|Quality|130",
	     SP_TYPE_COMBO|SP_TYPE_INT|SP_TYPE_SHOW_TIP, NULL, "0|1|2|3|@4|5|6|7|8|9|10"},
    };

    if (spEqLanguage(lang, ja_lang)) {
	num_option = spArraySize(options_ja);
	options = options_ja;
    } else {
	num_option = spArraySize(options_en);
	options = options_en;
    }
    i = 0;
    options[i++].value = &pinstance->bit_rate;
    options[i++].value = &pinstance->quality;

    return spCopyOptions(num_option, options);
}

static spBool spFreePluginOptionsOgg(void *instance, spOptions options)
{
    spFreeOptions(options);
    return SP_TRUE;
}

static spBool spIsSupportedByPluginOgg(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".ogg")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spBool setComments(spOggPluginInstance pinstance, spSongInfo *song_info)
{
    spConverter conv;
    char buf[SP_SONG_INFO_SIZE];
    
    vorbis_comment_init(&pinstance->vc);
    vorbis_comment_add_tag(&pinstance->vc, "ENCODER", "spPlugin");
    spDebug(10, "setComments", "comment init done\n");

    if (song_info->info_mask & SP_SONG_TRACK_MASK) {
	sprintf(buf, "%d", song_info->track);
	vorbis_comment_add_tag(&pinstance->vc, "TRACKNUMBER", buf);
    }

    if ((conv = spOpenConverter(NULL, "UTF-8")) != NULL) {
	int i;
	char *name;
	char *iptr, *ostr;
	
	for (i = 0; sp_ogg_song_info_table[i].mask; i++) {
	    iptr = (char *)song_info + sp_ogg_song_info_table[i].offset;
	    
	    if (song_info->info_mask & sp_ogg_song_info_table[i].mask && !strnone(iptr)) {
		name = sp_ogg_song_info_table[i].name;
		spDebug(10, "setComments", "add tag: i = %d, name = %s, iptr = %s\n", i, name, iptr);
	    
		if ((ostr = xspConvert(conv, iptr)) != NULL) {
		    vorbis_comment_add_tag(&pinstance->vc, name, ostr);
		    xfree(ostr);
		}
	    }
	}

	spCloseConverter(conv);
	spDebug(10, "setComments", "done\n");
	
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spPluginError spOpenPluginOgg(void *instance, char *filename, char *mode)
{
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;
    
    /* open file */
    if (strnone(filename)) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    if ((pinstance->fp = spOpenFile(filename, "wb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    spDebug(10, "spOpenPluginOgg", "open file done: %s\n", filename);

    pinstance->num_channel = MAX(1, pinstance->num_channel);

    vorbis_info_init(&pinstance->vi);
    if (pinstance->bit_rate <= 0) {
	vorbis_encode_init_vbr(&pinstance->vi, pinstance->num_channel,
			       pinstance->samp_rate, (float)pinstance->quality / 10.0);
    } else {
	vorbis_encode_init(&pinstance->vi, pinstance->num_channel, pinstance->samp_rate,
			   -1, pinstance->bit_rate * 1000, -1);
    }
    spDebug(10, "spOpenPluginOgg", "encode init done: %ld\n", pinstance->bit_rate);

    /* add a comment */
    setComments(pinstance, &pinstance->song_info);
    
    vorbis_analysis_init(&pinstance->vd, &pinstance->vi);
    vorbis_block_init(&pinstance->vd, &pinstance->vb);
    ogg_stream_init(&pinstance->os, rand());
    spDebug(10, "spOpenPluginOgg", "ogg_stream_init done\n");
    
    {
	ogg_packet header;
	ogg_packet header_comm;
	ogg_packet header_code;

	vorbis_analysis_headerout(&pinstance->vd, &pinstance->vc,
				  &header, &header_comm, &header_code);
	ogg_stream_packetin(&pinstance->os, &header);
	ogg_stream_packetin(&pinstance->os, &header_comm);
	ogg_stream_packetin(&pinstance->os, &header_code);

        while (1){
	    if (ogg_stream_flush(&pinstance->os, &pinstance->og) == 0) {
		break;
	    }
	    fwrite(pinstance->og.header, 1, pinstance->og.header_len,pinstance->fp);
	    fwrite(pinstance->og.body, 1, pinstance->og.body_len,pinstance->fp);
        }

    }
     
    pinstance->current_pos = 0;
    
    strcpy(pinstance->filename, filename);

    spDebug(10, "spOpenPluginOgg", "done\n");
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginOgg(void *instance)
{
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	ogg_stream_clear(&pinstance->os);
	vorbis_block_clear(&pinstance->vb);
	vorbis_dsp_clear(&pinstance->vd);
	vorbis_comment_clear(&pinstance->vc);
	vorbis_info_clear(&pinstance->vi);

	pinstance->total_length = pinstance->current_pos;
	
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	pinstance->current_pos = 0;
	
#ifdef MACOS
	spSetMacFileInfo(pinstance->filename, 0, 'OggS');
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateOgg(void *instance)
{
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionOgg(void *instance)
{
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginOgg(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginOgg(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginOgg(void *instance)
{

    return SP_TRUE;
}

static long writeSegment(spOggPluginInstance pinstance, short *sdata, long length)
{
    long i;
    long k;
    int eos = 0;
    float **buffer;
    
    buffer = vorbis_analysis_buffer(&pinstance->vd, length / pinstance->num_channel);
    spDebug(10, "spWritePluginOgg", "vorbis_analysis_buffer done: segment length = %ld\n", length);
      
    /* uninterleave samples */
    for(k = 0; k < length; k += pinstance->num_channel){
	for (i = 0; i < pinstance->num_channel; i++) {
	    buffer[i][k/pinstance->num_channel] = (float)sdata[k + i] / 32768.0;
	}
    }
    spDebug(10, "spWritePluginOgg", "uninterleave done\n");
    
    vorbis_analysis_wrote(&pinstance->vd, length / pinstance->num_channel);
    spDebug(10, "spWritePluginOgg", "analysis_wrote done\n");

    while (vorbis_analysis_blockout(&pinstance->vd, &pinstance->vb) == 1) {
	/* analysis, assume we want to use bitrate management */
	vorbis_analysis(&pinstance->vb, NULL);
	vorbis_bitrate_addblock(&pinstance->vb);
	spDebug(10, "spWritePluginOgg", "vorbis_bitrate_addblock done\n");

	while (vorbis_bitrate_flushpacket(&pinstance->vd, &pinstance->op)){
        
	    /* weld the packet into the bitstream */
	    ogg_stream_packetin(&pinstance->os, &pinstance->op);
	    spDebug(10, "spWritePluginOgg", "ogg_stream_packetin done\n");
        
	    /* write out pages (if any) */
	    while(!eos){
		if (ogg_stream_pageout(&pinstance->os, &pinstance->og) == 0) {
		    break;
		}
		spDebug(10, "spWritePluginOgg", "ogg_stream_pageout done: header_len = %d, body_len = %d\n",
			pinstance->og.header_len, pinstance->og.body_len);
		
		fwrite(pinstance->og.header, 1, pinstance->og.header_len, pinstance->fp);
		fwrite(pinstance->og.body, 1, pinstance->og.body_len, pinstance->fp);
          
		/* this could be set above, but for illustrative purposes, I do
		   it here (to show that vorbis does know where the stream ends) */
          
		if (ogg_page_eos(&pinstance->og)) eos=1;
	    }
	}
    }

    return length;
}

static long spWritePluginOgg(void *instance, char *data, long length)
{
    long offset;
    long nwrite;
    short *sdata;
    spOggPluginInstance pinstance = (spOggPluginInstance)instance;    
    
    if (pinstance->fp == NULL) return -1;

    spDebug(10, "spWritePluginOgg", "in: length = %ld\n", length);

    sdata = (short *)data;
    offset = 0;

    while (offset < length) {
	nwrite = MIN(1024, length - offset);
	if ((nwrite = writeSegment(pinstance, sdata + offset, nwrite)) < 0) {
	    break;
	}
	offset += nwrite;
    }
    
    pinstance->current_pos += offset / pinstance->num_channel;
    spDebug(10, "spWritePluginOgg", "done: current_pos = %ld\n", pinstance->current_pos);

    return length;
}

static spBool spFlushPluginOgg(void *instance)
{

    return SP_TRUE;
}

