/*
 *	output_sndfile.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#define SP_SND_BUFFER_SIZE 1024

#include "plugin_sndfile.c"

static char *sp_snd_file_type_list[] = {
    "sfwav",
    "sfwavadpcm",
    "sfwavima",
    "sfwavgsm",
    "sfwavml",
    "sfwaval",
    "sfsndfile",
    "sfau",
    "sfauml",
    "sfaual",
    "sfaug721",
    "sfaug723",
    "sfaule",
    "sfauleml",
    "sfauleal",
    "sfauleg721",
    "sfauleg723",
    "sfpafbe",
    "sfpafle",
    "sfnistle",
    "sfnistbe",
    "sfircam",
    "sfircamml",
    "sfircamal",
    NULL,
};
static char *sp_snd_file_desc_list[] = {
    SP_SND_TYPE_WAVE_STRING,
    SP_SND_TYPE_WAVE_ADPCM_STRING,
    SP_SND_TYPE_WAVE_IMA_ADPCM_STRING,
    SP_SND_TYPE_WAVE_GSM_STRING,
    SP_SND_TYPE_WAVE_MULAW_STRING,
    SP_SND_TYPE_WAVE_ALAW_STRING,
    SP_SND_TYPE_AIFF_STRING,
    SP_SND_TYPE_AU_STRING,
    SP_SND_TYPE_AU_ULAW_STRING,
    SP_SND_TYPE_AU_ALAW_STRING,
    SP_SND_TYPE_AU_G721_STRING,
    SP_SND_TYPE_AU_G723_STRING,
    SP_SND_TYPE_AULE_STRING,
    SP_SND_TYPE_AULE_ULAW_STRING,
    SP_SND_TYPE_AULE_ALAW_STRING,
    SP_SND_TYPE_AULE_G721_STRING,
    SP_SND_TYPE_AULE_G723_STRING,
    SP_SND_TYPE_PAF_BE_STRING,
    SP_SND_TYPE_PAF_LE_STRING,
    SP_SND_TYPE_NIST_BE_STRING,
    SP_SND_TYPE_NIST_LE_STRING,
    SP_SND_TYPE_IRCAM_STRING,
    SP_SND_TYPE_IRCAM_ULAW_STRING,
    SP_SND_TYPE_IRCAM_ALAW_STRING,
    NULL,
};
static char *sp_snd_file_filter_list[] = {
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.wav",
    "*.aif",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.au",
    "*.paf",
    "*.paf",
    "*.wav",
    "*.wav",
    "*.ircam",
    "*.ircam",
    "*.ircam",
    NULL,
};
    
static spBool spIsSupportedByPluginSnd(char *filename);

static spPluginError spOpenPluginSnd(void *instance, char *filename, char *mode);
static spBool spClosePluginSnd(void *instance);
static spPluginState spGetPluginStateSnd(void *instance);
static long spGetPluginCurrentPositionSnd(void *instance);
static spBool spStopPluginSnd(void *instance);
static spBool spPausePluginSnd(void *instance);
static spBool spRestartPluginSnd(void *instance);

static long spWritePluginSnd(void *instance, char *data, long length);
static spBool spFlushPluginSnd(void *instance);
static spBool spSetPluginTotalLengthSnd(void *instance, long total_length);


static spOutputPluginRec sp_output_plugin_snd = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "Libsndfile",
    2,
    SP_PLUGIN_PRIORITY_LOWER,
    SP_PLUGIN_CAPS_THREAD_SAFE,
    spInitPluginSnd,
    spFreePluginSnd,
    "Libsndfile Output Plugin",
    "Libsndfile Output Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",

    spInitPluginInstanceSnd,
    spFreePluginInstanceSnd,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_snd_file_type_list,
    sp_snd_file_desc_list,
    sp_snd_file_filter_list,
    spIsSupportedByPluginSnd,
    spSetPluginFileTypeSnd,  
    spGetPluginFileTypeSnd,
    0,
    spSetPluginSongInfoSnd,
    spGetPluginSongInfoSnd,
    spGetPluginBestSuffixSnd,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
	    
    spSetPluginSampleBitSnd,   
    spGetPluginSampleBitSnd,   
    spSetPluginChannelSnd,     
    spGetPluginChannelSnd,     
    spSetPluginSampleRateSnd,  
    spGetPluginSampleRateSnd,  
    spSetPluginOtherInfoSnd,   
    spGetPluginOtherInfoSnd,
    
    spOpenPluginSnd,              
    spClosePluginSnd,             
    spGetPluginStateSnd,          
    spGetPluginCurrentPositionSnd,
    spStopPluginSnd,              
    spPausePluginSnd,             
    spRestartPluginSnd,

    spWritePluginSnd,             
    spFlushPluginSnd,
    spSetPluginTotalLengthSnd,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_snd;
}

static int convertFileNameToType(char *filename)
{
    char *p;
    int type = -1;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (strcaseeq(p, ".wav")) {
	    type = SP_SND_TYPE_WAVE;
	} else if (strcaseeq(p, ".aif")
		   || strcaseeq(p, ".sndfile")
		   || strcaseeq(p, ".afc")
		   || strcaseeq(p, ".aifc")) {
	    type = SP_SND_TYPE_AIFF;
	} else if (strcaseeq(p, ".au") || strcaseeq(p, ".snd")) {
	    type = SP_SND_TYPE_AU;
	} else if (strcaseeq(p, ".paf")) {
#if BYTE_ORDER == LITTLE_ENDIAN
	    type = SP_SND_TYPE_PAF_LE;
#else
	    type = SP_SND_TYPE_PAF_BE;
#endif
	} else if (strcaseeq(p, ".nist")) {
#if BYTE_ORDER == LITTLE_ENDIAN
	    type = SP_SND_TYPE_NIST_LE;
#else
	    type = SP_SND_TYPE_NIST_BE;
#endif
	} else if (strcaseeq(p, ".ircam") || strcaseeq(p, ".sf")) {
	    type = SP_SND_TYPE_IRCAM;
	}
    }

    return type;
}

static spBool spIsSupportedByPluginSnd(char *filename)
{
    if (convertFileNameToType(filename) < 0) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spPluginError convertTypeToSF_INFO(int type_index, SF_INFO *sfinfo)
{
    spPluginError error = SP_PLUGIN_ERROR_NO_ERROR;

    if (sfinfo->pcmbitwidth > 32
	|| (type_index != SP_SND_TYPE_WAVE
	    && type_index != SP_SND_TYPE_AIFF
	    && type_index != SP_SND_TYPE_AU
	    && type_index != SP_SND_TYPE_IRCAM
	    && (sfinfo->format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT)) {
	error = SP_PLUGIN_ERROR_SAMP_BIT;
    } else {
	switch (type_index) {
	  case SP_SND_TYPE_WAVE:
	    sfinfo->format &= SF_FORMAT_SUBMASK;
	    sfinfo->format |= SF_FORMAT_WAV;
	    break;
	  case SP_SND_TYPE_WAVE_ADPCM:
	    if (sfinfo->channels >= 3) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		if (sfinfo->pcmbitwidth < 16) sfinfo->pcmbitwidth = 16;
		sfinfo->format = SF_FORMAT_WAV | SF_FORMAT_MS_ADPCM;
	    }
	    break;
	  case SP_SND_TYPE_WAVE_IMA_ADPCM:
	    if (sfinfo->channels >= 3) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		if (sfinfo->pcmbitwidth < 16) sfinfo->pcmbitwidth = 16;
		sfinfo->format = SF_FORMAT_WAV | SF_FORMAT_IMA_ADPCM;
	    }
	    break;
	  case SP_SND_TYPE_WAVE_GSM:
	    if (sfinfo->channels >= 2) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		if (sfinfo->pcmbitwidth < 16) sfinfo->pcmbitwidth = 16;
		sfinfo->format = SF_FORMAT_WAV | SF_FORMAT_GSM610;
	    }
	    break;
	  case SP_SND_TYPE_WAVE_ULAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_WAV | SF_FORMAT_ULAW;
	    }
	    break;
	  case SP_SND_TYPE_WAVE_ALAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_WAV | SF_FORMAT_ALAW;
	    }
	    break;

	  case SP_SND_TYPE_AIFF:
	    sfinfo->format &= SF_FORMAT_SUBMASK;
	    sfinfo->format |= SF_FORMAT_AIFF;
	    break;

	  case SP_SND_TYPE_AU:
	    sfinfo->format &= SF_FORMAT_SUBMASK;
	    sfinfo->format |= SF_FORMAT_AU;
	    break;
	  case SP_SND_TYPE_AU_ULAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_AU | SF_FORMAT_ULAW;
	    }
	    break;
	  case SP_SND_TYPE_AU_ALAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_AU | SF_FORMAT_ALAW;
	    }
	    break;
	  case SP_SND_TYPE_AU_G721:
	    if (sfinfo->channels >= 2) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else {
		sfinfo->format = SF_FORMAT_AU | SF_FORMAT_G721_32;
	    }
	    break;
	  case SP_SND_TYPE_AU_G723:
	    if (sfinfo->channels >= 2) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else {
		sfinfo->format = SF_FORMAT_AU | SF_FORMAT_G723_24;
	    }
	    break;
	
	  case SP_SND_TYPE_AULE:
	    sfinfo->format &= SF_FORMAT_SUBMASK;
	    sfinfo->format |= SF_FORMAT_AULE;
	    break;
	  case SP_SND_TYPE_AULE_ULAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_AULE | SF_FORMAT_ULAW;
	    }
	    break;
	  case SP_SND_TYPE_AULE_ALAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_AULE | SF_FORMAT_ALAW;
	    }
	    break;
	  case SP_SND_TYPE_AULE_G721:
	    if (sfinfo->channels >= 2) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else {
		sfinfo->format = SF_FORMAT_AULE | SF_FORMAT_G721_32;
	    }
	    break;
	  case SP_SND_TYPE_AULE_G723:
	    if (sfinfo->channels >= 2) {
		error = SP_PLUGIN_ERROR_NUM_CHANNEL;
	    } else {
		sfinfo->format = SF_FORMAT_AULE | SF_FORMAT_G723_24;
	    }
	    break;
	
	  case SP_SND_TYPE_PAF_BE:
	    if (sfinfo->pcmbitwidth > 24 || sfinfo->pcmbitwidth < 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_PAF | SF_FORMAT_PCM_BE;
	    }
	    break;
	  case SP_SND_TYPE_PAF_LE:
	    if (sfinfo->pcmbitwidth > 24 || sfinfo->pcmbitwidth < 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_PAF | SF_FORMAT_PCM_LE;
	    }
	    break;
	
	  case SP_SND_TYPE_NIST_BE:
	    sfinfo->format = SF_FORMAT_NIST | SF_FORMAT_PCM_BE;
	    break;
	  case SP_SND_TYPE_NIST_LE:
	    sfinfo->format = SF_FORMAT_NIST | SF_FORMAT_PCM_LE;
	    break;

	  case SP_SND_TYPE_IRCAM:
	    if (sfinfo->pcmbitwidth < 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format &= SF_FORMAT_SUBMASK;
		sfinfo->format |= SF_FORMAT_IRCAM;
	    }
	    break;
	  case SP_SND_TYPE_IRCAM_ULAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_IRCAM | SF_FORMAT_ULAW;
	    }
	    break;
	  case SP_SND_TYPE_IRCAM_ALAW:
	    if (sfinfo->pcmbitwidth > 16) {
		error = SP_PLUGIN_ERROR_SAMP_BIT;
	    } else {
		sfinfo->format = SF_FORMAT_IRCAM | SF_FORMAT_ALAW;
	    }
	    break;
	    
	  default:
	    break;
	}

	if (error == SP_PLUGIN_ERROR_NO_ERROR
	    && (sfinfo->format & SF_FORMAT_SUBMASK) == 0) {
	    sfinfo->format |= SF_FORMAT_PCM;
	}
    }
    
    return error;
}

static spPluginError spOpenPluginSnd(void *instance, char *filename, char *mode)
{
    spPluginError error;
    unsigned int format_type;
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;

    pinstance->song_info_mask = 0;
    strcpy(pinstance->filename, "");
    
    if (pinstance->type_index <= 0) {
	if ((pinstance->type_index = convertFileNameToType(filename)) < 0) {
	    return SP_PLUGIN_ERROR_OPEN;
	}
    }
    
    spDebug(10, "spOpenPluginSnd", "type_index = %d\n", pinstance->type_index);
    
    if ((error = convertTypeToSF_INFO(pinstance->type_index, &pinstance->sfinfo))
	!= SP_PLUGIN_ERROR_NO_ERROR) {
	return error;
    }
    spDebug(10, "spOpenPluginSnd", "samplerate = %d, samples = %d, channels = %d, pcmbitwidth = %d, format = %x\n",
	    pinstance->sfinfo.samplerate, pinstance->sfinfo.samples, pinstance->sfinfo.channels,
	    pinstance->sfinfo.pcmbitwidth, pinstance->sfinfo.format);
    
    /* open file */
    if ((pinstance->sndfile = sf_open_write(filename, &pinstance->sfinfo)) == NULL) {
	sf_perror(NULL);
	spDebug(10, "spOpenPluginSnd", "sf_open_write failed\n");
	return SP_PLUGIN_ERROR_OPEN;
    }

    format_type = (pinstance->sfinfo.format & SF_FORMAT_TYPEMASK);

    if (format_type == SF_FORMAT_WAV) {
	pinstance->song_info_mask =
	    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_COMMENT_MASK
	     | SP_SONG_GENRE_MASK | SP_SONG_RELEASE_MASK | SP_SONG_COPYRIGHT_MASK
	     | SP_SONG_ENGINEER_MASK | SP_SONG_SOURCE_MASK | SP_SONG_SOFTWARE_MASK
	     | SP_SONG_SUBJECT_MASK);
    } else if (format_type == SF_FORMAT_AIFF) {
	pinstance->song_info_mask =
	    (SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK
	     | SP_SONG_COMMENT_MASK | SP_SONG_COPYRIGHT_MASK);
    }
    
    pinstance->current_pos = 0;
    strcpy(pinstance->filename, filename);

    if (pinstance->sfinfo.pcmbitwidth < 16
	|| (sizeof(int) != sizeof(long)
	    && pinstance->sfinfo.pcmbitwidth > 16
	    && pinstance->sfinfo.pcmbitwidth <= 32
	    && (pinstance->sfinfo.format & SF_FORMAT_SUBMASK) != SF_FORMAT_FLOAT)) {
	if (pinstance->buffer == NULL) {
	    pinstance->buffer_size = SP_SND_BUFFER_SIZE;
	    pinstance->buffer = xalloc(pinstance->buffer_size, char);
	}
    }
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginSnd(void *instance)
{
    FILE *fp;
    unsigned int format_type;
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->sndfile != NULL) {
	/* close file */
	sf_close(pinstance->sndfile);
	pinstance->sndfile = NULL;
	pinstance->current_pos = 0;

	if (!strnone(pinstance->filename)) {
	    format_type = (pinstance->sfinfo.format & SF_FORMAT_TYPEMASK);

	    if (format_type == SF_FORMAT_WAV || format_type == SF_FORMAT_AIFF) {
		if ((fp = spOpenFile(pinstance->filename, "r+b")) != NULL) {
		    if (format_type == SF_FORMAT_WAV) {
			spAddWavSongInfo(&pinstance->song_info, fp);
		    } else if (format_type == SF_FORMAT_AIFF) {
			spAddAiffSongInfo(&pinstance->song_info, fp);
		    }
		    spCloseFile(fp);
		}
	    }
	
#ifdef MACOS
	    if (format_type == SF_FORMAT_WAV) {
		spSetMacFileInfo(pinstance->filename, 0, 'WAVE');
	    } else if (format_type == SF_FORMAT_AIFF) {
		spSetMacFileInfo(pinstance->filename, 0, 'AIFF');
	    } else if (format_type == SF_FORMAT_AU
		       || format_type == SF_FORMAT_AULE) {
		spSetMacFileInfo(pinstance->filename, 0, 'ULAW');
	    } else if (format_type == SF_FORMAT_IRCAM) {
		spSetMacFileInfo(pinstance->filename, 0, 'IRCM');
	    } else if (format_type == SF_FORMAT_PAF) {
		spSetMacFileInfo(pinstance->filename, 0, 'paf ');
	    } else {
		spSetMacFileInfo(pinstance->filename, 0, 'BINA');
	    }
#endif
	}

	return SP_TRUE;
    }

    return SP_FALSE;
}

static spPluginState spGetPluginStateSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionSnd(void *instance)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginSnd(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginSnd(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginSnd(void *instance)
{

    return SP_TRUE;
}

static long spWritePluginSnd(void *instance, char *data, long length)
{
    int ret;
    long k;
    long nremain;
    long olength;
    long nwrite;
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;    
    
    if (pinstance->sndfile == NULL) return -1;

    if (pinstance->sfinfo.pcmbitwidth < 16) {
	short *odata;
	short *sdata = (short *)data;

	if (pinstance->buffer == NULL) return -1;
	
	olength = pinstance->buffer_size / 2;
	odata = (short *)pinstance->buffer;

	nwrite = 0;
	nremain = length;

	while (nremain > 0) {
	    olength = MIN(olength, nremain);
	    
	    for (k = 0; k < olength; k++) {
		odata[k] = sdata[k + nwrite] / 256;
	    }
	    if ((ret = sf_write_short(pinstance->sndfile, odata, olength)) < 0) {
		nwrite = ret;
		break;
	    }
	    nwrite += ret;
	    nremain -= ret;
	}
    } else if (pinstance->sfinfo.pcmbitwidth <= 16) {
	nwrite = sf_write_short(pinstance->sndfile, (short *)data, length);
    } else if (pinstance->sfinfo.pcmbitwidth == 32
	       && (pinstance->sfinfo.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT) {
	nwrite = sf_write_float(pinstance->sndfile, (float *)data, length);
    } else if (pinstance->sfinfo.pcmbitwidth <= 32) {
	if (sizeof(int) != sizeof(long)) {
	    int *odata;
	    long *ldata = (long *)data;

	    if (pinstance->buffer == NULL) return -1;
	
	    olength = pinstance->buffer_size / sizeof(int);
	    odata = (int *)pinstance->buffer;

	    nwrite = 0;
	    nremain = length;

	    while (nremain > 0) {
		olength = MIN(olength, nremain);
	    
		for (k = 0; k < olength; k++) {
		    odata[k] = (int)ldata[k + nwrite];
		}
		if ((ret = sf_write_int(pinstance->sndfile, odata, olength)) < 0) {
		    nwrite = ret;
		    break;
		}
		nwrite += ret;
		nremain -= ret;
	    }
	} else {
	    nwrite = sf_write_int(pinstance->sndfile, (int *)data, length);
	}
    } else {
	nwrite = sf_write_double(pinstance->sndfile, (double *)data, length, 0);
    }
    if (nwrite < 0) {
	return -1;
    }
    pinstance->current_pos += (nwrite / pinstance->sfinfo.channels);

    return nwrite;
}

static spBool spFlushPluginSnd(void *instance)
{

    return SP_TRUE;
}

static spBool spSetPluginTotalLengthSnd(void *instance, long total_length)
{
    spSndPluginInstance pinstance = (spSndPluginInstance)instance;

    pinstance->sfinfo.samples = total_length;
    
    return SP_TRUE;
}
