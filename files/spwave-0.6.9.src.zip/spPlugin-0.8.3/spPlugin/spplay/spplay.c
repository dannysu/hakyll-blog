#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spMain.h>
#include <sp/spBaseLib.h>

#include <sp/spPlugin.h>
#include <sp/spOutputPlugin.h>
#include <sp/spInputPlugin.h>

#define SPPLAY_HELP_MESSAGE "play sound file"

#define SPPLAY_MIN_BUF_LENGTH 128

static spBool help_flag;
static spBool quiet_flag;
static spBool second_flag;
static spBool supported_only;
static int debug_level = -1;

/*static char *plugin_search_path = NULL;*/
static char *plugin_search_path;
static char o_plugin_name[SP_MAX_LINE] = "";

static double samp_freq = 0.0;
static int num_channel = 0;
static int samp_bit = 0;

static long buffer_length = 0;
static double offset_s = 0.0;
static double length_s = 0.0;
#if 0
static double output_gain = 1.0;
#endif
static char output_file[SP_MAX_PATHNAME] = "";

static spOptions options;
static spOption option[] = {
    {"-o", "-offset", "offset time [s]", "offset",
	 SP_TYPE_DOUBLE, &offset_s, NULL},
    {"-l", "-length", "length of playing [s]", "length",
	 SP_TYPE_DOUBLE, &length_s, NULL},
    {"-O", "-output", "output file (default format: wav)", NULL,
	 SP_TYPE_STRING_S, &output_file, NULL},
#if 0
    {"-g", "-gain", "output gain", "output_gain",
	 SP_TYPE_DOUBLE, &output_gain, "1.0"},
#endif
    {"-buf", NULL, "buffer length for audio output", "buffer_length",
	 SP_TYPE_LONG, &buffer_length, "1024"},
    {"-op", "-oplugin", "plugin name for output", "output_plugin",
	 SP_TYPE_STRING_S, o_plugin_name, "output_audio"},
    {"-path", NULL, "plugin search path", "plugin_path",
	 SP_TYPE_STRING, &plugin_search_path, NULL},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-so", NULL, "play supported file only", "supported_only",
	 SP_TYPE_BOOLEAN, &supported_only, SP_FALSE_STRING},
    {"-s", "-sec", "display time in second", "time_second",
	 SP_TYPE_BOOLEAN, &second_flag, SP_FALSE_STRING},
    {"-q", "-quiet", "quiet mode", NULL,
	 SP_TYPE_BOOLEAN, &quiet_flag, SP_FALSE_STRING},
    {"-h", "-help", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
    /* options for input_raw */
    SpNullOption("-f", "-freq", SP_TYPE_NONE),
    SpNullOption("-c", "-channel", SP_TYPE_NONE),
    SpNullOption("-b", "-bit", SP_TYPE_NONE),
    SpNullOption("-H", "-head", SP_TYPE_NONE),
    SpNullOption("-F", "-format", SP_TYPE_NONE),
};

static char *filelabel[] = {
    "<input file...>",
};

static void usage(spPlugin *i_plugin, spPlugin *o_plugin)
{
    spPrintHelpHeader(SPPLAY_HELP_MESSAGE);
    spPrintUsageHeader();
    
    if (i_plugin != NULL) {
	spPrintPluginOptions(i_plugin);
	spCloseFilePlugin(i_plugin);
    } else {
	spPluginUsage("input_raw");
    }
    
    if (o_plugin != NULL) {
	spPrintPluginOptions(o_plugin);
	spCloseFilePlugin(o_plugin);
    }
    spPrintUsage();
    
    return;
}

int spMain(int argc, char *argv[])
{
    int i;
    int samp_byte;
    long len;
    long nread;
    long offset;
    long length;
    long total_length;
    long current_length;
    long position;
    char *buf;
    char *i_filename;
    char *o_filename;
    spPluginDeviceType device_type;
    spWaveInfo wave_info;
    spPlugin *i_plugin = NULL;
    spPlugin *o_plugin = NULL;

    options = spGetOptions(argc, argv, option, filelabel);
    spIgnoreUnknownOption(options, SP_TRUE);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    if (!strnone(plugin_search_path)) {
	spDebug(10, "spMain", "plugin_search_path: %s\n", plugin_search_path);
	spSetPluginSearchPath(plugin_search_path);
    }
    
    buf = xalloc(buffer_length * sizeof(double), char);

    if ((i_filename = spGetFile(options)) == NULL) {
	if (help_flag == SP_TRUE) {
	    usage(NULL, NULL);
	} else {
	    spError(1, "Not enough files.\n");
	}
    }

    do {
	/* initialize option */
	spInitWaveInfo(&wave_info);
	wave_info.samp_bit = samp_bit;
	wave_info.num_channel = num_channel;
	wave_info.samp_rate = samp_freq;
	
	/* open input file */
	if ((i_plugin = spOpenFilePluginArg(NULL, i_filename, "r",
					    SP_PLUGIN_DEVICE_FILE,
					    &wave_info, NULL, argc, argv, NULL)) == NULL) {
	    if (supported_only == SP_TRUE) {
		continue;
	    }
	    
	    spDebug(10, "spMain", "can't find suitable plugin\n");
	    if ((i_plugin = spOpenFilePluginArg("input_raw", i_filename, "r",
						SP_PLUGIN_DEVICE_FILE,
						&wave_info, NULL, argc, argv, NULL)) == NULL) {
		/*spError(1, "Can't find plugins.\n");*/
		continue;
	    }
	}
	total_length = spGetPluginTotalLength(i_plugin);
	samp_byte = wave_info.samp_bit / 8;
	
	if (quiet_flag == SP_FALSE) {
	    char *string;

	    printf("Input Filename: %s\n", i_filename);
	    
	    if ((string = spGetPluginFileType(i_plugin, SP_TRUE)) != NULL) {
		printf("File Type: %s\n", string);
	    }
	    printf("Sampling Rate: %f\n", wave_info.samp_rate);
	    printf("Number of Channels: %d\n", wave_info.num_channel);
	    printf("Bits/Sample: %d\n", wave_info.samp_bit);
	    printf("Total Length: %ld\n", total_length);
	}
	
	spDebug(11, NULL, "input plugin: %s\n", spGetPluginName(i_plugin));
	spDebug(10, NULL, "total length: %ld\n", total_length);

	/* open output plugin */
	if (!strnone(output_file)) {
	    device_type = SP_PLUGIN_DEVICE_FILE;
	    o_filename = output_file;
	    if (streq(o_plugin_name, "output_audio")) {
		strcpy(o_plugin_name, "output_wav");
	    }
	} else {
	    device_type = SP_PLUGIN_DEVICE_AUDIO;

	    /* buffer length limitation to prevent long waiting on DOS */
	    len = total_length * wave_info.num_channel / 32;
	    if (len <= buffer_length) {
		wave_info.buffer_size =
		    MAX(len / SPPLAY_MIN_BUF_LENGTH, 1)
			* SPPLAY_MIN_BUF_LENGTH * samp_byte;
	    } else {
		wave_info.buffer_size = buffer_length * samp_byte;
	    }
	    o_filename = NULL;
	}
	strcpy(wave_info.file_type, "");
	strcpy(wave_info.file_desc, "");
	strcpy(wave_info.file_filter, "");
	if ((o_plugin = spOpenFilePluginArg(o_plugin_name, o_filename, "w",
					    device_type,
					    &wave_info, NULL, 0, NULL, NULL)) == NULL) {
	    fprintf(stderr, "Can't open output plugin.\n");
	    spExit(1);
	}
	
	spDebug(10, NULL, "output plugin: %s\n", spGetPluginName(o_plugin));
	spDebug(10, NULL, "output buffer size: %d\n", wave_info.buffer_size);

	if (help_flag == SP_TRUE) {
	    usage(i_plugin, o_plugin);
	}
	
	offset = (long)spRound(offset_s * wave_info.samp_rate);
	length = (long)spRound(length_s * wave_info.samp_rate) * wave_info.num_channel;

	if (offset > 0) {
	    spSeekPlugin(i_plugin, offset);
	}

	spDebug(10, NULL, "main loop\n");
	
	current_length = 0;
	for (i = 0;; i++) {
	    if (quiet_flag == SP_FALSE) {
		if ((position = spGetPluginCurrentPosition(o_plugin)) < 0) {
		    position = current_length / wave_info.num_channel;
		}
		spDebug(10, NULL, "position = %ld\n", position);
		
		if (second_flag == SP_TRUE) {
		    spMessage("Time: %5.2f [s] %c%c",
			      (double)(position + offset) / wave_info.samp_rate, 
			      (char)13, (char)0);
		} else {
		    int hour, minute, second;
		    
		    second = (int)((double)(position + offset) / wave_info.samp_rate);
		    minute = second / 60;
		    hour = minute / 60;
		    spDebug(10, NULL, "%.2d:%.2d:%.2d\n", hour, minute, second);
		    minute %= 60;
		    second %= 60;
		    
		    spMessage("Time: %.2d:%.2d:%.2d %c%c",
			      hour, minute, second, (char)13, (char)0);
		}
	    }

	    if ((nread = spReadPlugin(i_plugin, buf, buffer_length)) <= 0) {
		break;
	    }
	    current_length += nread;
	    
	    if (length > 0 && current_length >= length) {
		spWritePlugin(o_plugin, buf,
			      nread - (current_length - length));
		break;
	    } else {
		spWritePlugin(o_plugin, buf, nread);
	    }
	}

	spDebug(10, NULL, "main loop done\n");
	
	/* close plugin */
	spCloseFilePlugin(i_plugin);
	spCloseFilePlugin(o_plugin);


	if (device_type == SP_PLUGIN_DEVICE_FILE) {
	    printf("\nOutput Filename: %s\n", o_filename);
	    printf("File Type: %s\n", wave_info.file_type);
	    printf("Sampling Rate: %f\n", wave_info.samp_rate);
	    printf("Number of Channels: %d\n", wave_info.num_channel);
	    printf("Bits/Sample: %d\n", wave_info.samp_bit);
	    break;
	}
	
    } while ((i_filename = spGetFile(options)) != NULL);
    
    xfree(buf);

    return 0;
}
