/*
 *	spContainer.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>

#include <sp/spContainerP.h>

static spParamTable sp_container_param_tables[] = {
    {SppBorderOn, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spContainer, container.border_on), SP_FALSE_STRING},
    {SppTitleOn, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spContainer, container.title_on), SP_FALSE_STRING},
    {SppUseTextHeight, SP_CREATE_ACCESS,
	 spOffset(spContainer, container.use_text_height), SP_FALSE_STRING},
    {SppSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spContainer, container.size), "0"},
};

spContainerClassRec SpContainerClassRec = {
    /* spObjectClassPart */
    {
	SpContainer,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spContainerRec),
	spArraySize(sp_container_param_tables),
	sp_container_param_tables,
	spContainerPartInit,
	spContainerPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spContainerCreate,
	NULL,
	spContainerSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spContainerClassPart */
    {
	0,
    },
};

spComponentClass SpContainerClass = (spComponentClass)&SpContainerClassRec;

void spContainerPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;

    SpContainerPart(component).title_offset = 0;
    
    return;
}

void spContainerPartFree(spObject object)
{
    return;
}

void spContainerCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spContainerSetDefaultSize(component);
    spContainerCreateArch(component);

    return;
}

void spContainerSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spContainerSetParamsArch(component);

    return;
}

void spContainerSetDefaultSize(spComponent component)
{
    if (spIsContainer(component) == SP_FALSE) return;
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (SpParentComponentPart(component).orientation == SP_HORIZONTAL) {
	SpComponentPart(component).width = SpContainerPart(component).size;
	SpComponentPart(component).height = 0;
    } else {
	SpComponentPart(component).width = 0;
	if (SpContainerPart(component).use_text_height == SP_TRUE) {
	    SpContainerPart(component).size =
		SP_DEFAULT_TEXT_HEIGHT + 2 * SpComponentPart(component).margin_height;
	}
	SpComponentPart(component).height = SpContainerPart(component).size;
    }
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;

    return;
}

spBool spIsContainer(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    return SpGetComponentClass(component)->component.container_flag;
}

spComponent spCreateBox(spComponent parent, char *name, int size, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, size);
    spGetArgs(argp, args, num_arg);
    va_end(argp);
    
    spSetArg(args[num_arg], SppSize, size); num_arg++;

    return spCreateComponentArg(SpContainerClass, SpBox, name, parent, args, num_arg);
}

