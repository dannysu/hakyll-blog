/*
 *	spLocale.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spKanji.h>

#include <sp/spLocaleDefs.h>

#include <sp/spLocaleP.h>
#include <sp/spTopLevelP.h>

static char sp_language[SP_MAX_LINE] = "";
static char sp_internal_language[SP_MAX_LINE] = "";

char *spSetLanguage(char *lang)
{
    if (strnone(sp_language) || !strnone(lang)) {
	spSetLanguageArch(lang, sp_language);
    }
    spInitStringTable();
    
    spDebug(10, "spSetLanugange", "lang = %s\n", sp_language);
    
    return sp_language;
}

char *spGetLanguage(void)
{
    return sp_language;
}

char *spSetInternalLanguage(char *lang)
{
    strncpy(sp_internal_language, lang, SP_MAX_LINE-1);
    sp_internal_language[SP_MAX_LINE-1] = NUL;
    
    return sp_internal_language;
}

char *spGetInternalLanguage(void)
{
    if (!strnone(sp_internal_language)) {
	return sp_internal_language;
    } else if (spIsJapaneseLang(sp_language) == SP_TRUE) {
#if (defined(_WIN32) && !defined(__CYGWIN32__)) || (defined(MACOS) && !defined(MACOSX))
	strcpy(sp_internal_language, "ja_JP.SJIS");
#else
	strcpy(sp_internal_language, "ja_JP.eucJP");
#endif
	spDebug(10, "spGetInternalLanguage", "lang = %s\n",
		sp_internal_language);
    
	return sp_internal_language;
    }
    
    return sp_language;
}

#define SP_STRING_BUFFER 16

static long sp_num_string = 0;
static long sp_num_string_buffer = 0;
static spStringTable *sp_strings = NULL;		/* global string buffer */

#define SP_NUM_LOCALE_TABLE_BUFFER 16

static long sp_prev_num_user_locale_table = 0;
static long sp_num_user_locale_table = 0;
static long sp_num_user_locale_table_buffer = 0;
static spLocaleTable *sp_user_locale_tables = NULL;	/* user defined locale table */

/*
 * 	check if lang is a member of the locale table
 */
static spBool matchLanguage(char *lang1, char *lang2)
{
    if (lang1 != NULL) {
	if (strnone(lang2)) {
	    /* if lang1 means 'C', return TRUE */
	    if (spEqLanguage(lang1, "C") == SP_TRUE) {
		return SP_TRUE;
	    } else {
		return SP_FALSE;
	    }
	} else {
	    return spEqLanguage(lang1, lang2);
	}
    }

    return SP_FALSE;
}

/*
 * 	copy string to global string buffer
 */
static void copyStringTable(spStringTable *string_table, char *string_lang)
{
    long i, j, k;
    char *lang;
    unsigned char buf[SP_MAX_MESSAGE];
    spKanjiCode icode = SP_KANJI_CODE_UNKNOWN;
    spKanjiCode ocode = SP_KANJI_CODE_UNKNOWN;
    
    if (string_table == NULL) return;

    lang = spGetLanguage();
    if (spEqLanguage(lang, string_lang) == SP_FALSE
	&& spIsJapaneseLang(string_lang) == SP_TRUE) {
	spDebug(60, "copyStringTable", "string_lang = %s, lang = %s\n", string_lang, lang);
	icode = spGetLocaleKanjiCode(string_lang);
	ocode = spGetLocaleKanjiCode(lang);
	spSetKanjiCode(icode, ocode);
    }
    
    for (i = 0;; i++) {
	if (string_table[i].id == NULL) {
	    break;
	}

	for (j = 0; j < sp_num_string; j++) {
	    if (streq(sp_strings[j].id, string_table[i].id)) {
		break;
	    }
	}
	
	if (j >= sp_num_string_buffer) {
	    k = sp_num_string_buffer;
	    sp_num_string_buffer += SP_STRING_BUFFER;
	    sp_strings = xrealloc(sp_strings, sp_num_string_buffer, spStringTable);
	    for (; k < sp_num_string_buffer; k++) {
		sp_strings[k].id = NULL;
		sp_strings[k].string = NULL;
	    }
	}

	if (sp_strings[j].id == NULL
	    || !streq(sp_strings[j].id, string_table[i].id)) {
	    if (sp_strings[j].id != NULL) {
		xfree(sp_strings[j].id);
	    }
	    sp_strings[j].id = strclone(string_table[i].id);
	}
	
	if (sp_strings[j].string == NULL
	    || (!streq(sp_strings[j].string, string_table[i].string)
		/*&& spEqLanguage(string_lang, "C") == SP_FALSE*/)) {
	    if (sp_strings[j].string != NULL) {
		xfree(sp_strings[j].string);
	    }
	    if (icode != SP_KANJI_CODE_UNKNOWN && ocode != SP_KANJI_CODE_UNKNOWN) {
		spConvertKanji((unsigned char *)string_table[i].string, buf, SP_MAX_MESSAGE);
		sp_strings[j].string = strclone((char *)buf);
	    } else {
		sp_strings[j].string = strclone(string_table[i].string);
	    }
	    spDebug(100, "copyStringTable", "sp_strings[%ld] = %s\n", j, sp_strings[j].string);
	}

	sp_num_string = MAX(sp_num_string, j + 1);
    }


    return;
}

char *spGetString(char *id)
{
    long i;
    static char *null_string = "";
    
    for (i = 0; i < sp_num_string; i++) {
	if (streq(sp_strings[i].id, id)) {
	    return sp_strings[i].string;
	}
    }

    return null_string;
}

/*
 * 	set user defined string table
 *	this function should be called before spInitialize
 */
void spSetStringTable(char *lang, spStringTable *string_table)
{
    if (string_table == NULL) return;

    if (sp_num_user_locale_table + 1 >= sp_num_user_locale_table_buffer) {
	sp_num_user_locale_table_buffer += SP_NUM_LOCALE_TABLE_BUFFER;
	sp_user_locale_tables = xrealloc(sp_user_locale_tables, sp_num_user_locale_table_buffer,
					 spLocaleTable);
    }
    sp_user_locale_tables[sp_num_user_locale_table].lang = strclone(lang);
    sp_user_locale_tables[sp_num_user_locale_table].string_table = string_table;
    sp_num_user_locale_table++;

    return;
}

static void updateStringTable(char *internal_lang)
{
    long i, j;
    
    spDebug(60, "updateStringTable", "sp_num_user_locale_table = %ld\n", sp_num_user_locale_table);
    
    if (sp_num_user_locale_table >= 1) {
	/* get user defined string table. */
	for (j = 0; j <= 1; j++) {
	    for (i = sp_prev_num_user_locale_table; i < sp_num_user_locale_table; i++) {
		if (matchLanguage(sp_user_locale_tables[i].lang,
				  (j == 0 ? NULL : internal_lang)) == SP_TRUE) {
		    /* if j == 0, copy "C" table */
		    copyStringTable(sp_user_locale_tables[i].string_table,
				    sp_user_locale_tables[i].lang);
		}
	    }
	    
	    if (spEqLanguage(internal_lang, "C") == SP_TRUE) {
		break;
	    }
	}
	sp_prev_num_user_locale_table = sp_num_user_locale_table;
    }

    return;
}

void spUpdateStringTable(void)
{
    if (sp_num_string > 0) {
	updateStringTable(spGetInternalLanguage());
    } else {
	spInitStringTable();
    }
    
    return;
}

/*
 * 	initialize global string buffer
 */
void spInitStringTable(void)
{
    long i;
    char *internal_lang = NULL;
    char *string_lang = NULL;
    spStringTable *string_table = NULL;

    sp_prev_num_user_locale_table = 0;

    /* get current language */
    internal_lang = spGetInternalLanguage();

    updateStringTable(internal_lang);

    /* get system string table */
    string_table = sp_string_table_c;
    string_lang = NULL;
	if (!strnone(internal_lang)) {
		for (i = 0;; i++) {
		    if (sp_locale_tables[i].lang == NULL) {
				break;
			}

			if (matchLanguage(sp_locale_tables[i].lang, internal_lang) == SP_TRUE) {
				string_table = sp_locale_tables[i].string_table;
				string_lang = sp_locale_tables[i].lang;
				break;
			}
		}
    }
    copyStringTable(string_table, string_lang);

    return;
}

void spFreeStringTable(void)
{
    long i;

    if (sp_num_string > 0) {
	for (i = 0; i < sp_num_string; i++) {
	    if (sp_strings[i].id != NULL) xfree(sp_strings[i].id);
	    if (sp_strings[i].string != NULL) xfree(sp_strings[i].string);
	}
    }
    
    if (sp_strings != NULL) xfree(sp_strings);
    sp_strings = NULL;
    sp_num_string_buffer = 0;
    sp_num_string = 0;

    if (sp_num_user_locale_table > 0) {
	for (i = 0; i < sp_num_user_locale_table; i++) {
	    if (sp_user_locale_tables[i].lang != NULL) 
		xfree(sp_user_locale_tables[i].lang);
	}
    }

    if (sp_user_locale_tables != NULL) xfree(sp_user_locale_tables);
    sp_user_locale_tables = NULL;
    sp_num_user_locale_table_buffer = 0;
    sp_num_user_locale_table = 0;
    
    return;
}

spBool spSupportLocale(char *lang)
{
    long i;
    spBool flag = SP_FALSE;
    
    if (sp_num_user_locale_table >= 1) {
	for (i = 0; i < sp_num_user_locale_table; i++) {
	    if (matchLanguage(sp_user_locale_tables[i].lang, lang) == SP_TRUE) {
		flag = SP_TRUE;
		break;
	    }
	}
    } else {
	for (i = 0;; i++) {
	    if (sp_locale_tables[i].lang == NULL) {
		break;
	    }

	    if (matchLanguage(sp_locale_tables[i].lang, lang) == SP_TRUE) {
		flag = SP_TRUE;
		break;
	    }
	}
    }

    return flag;
}
