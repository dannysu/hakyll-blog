/*
 *	spTabBox_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/keysym.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/PushB.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spTabBoxP.h>

extern spTopLevel sp_toplevel;

void spTabBoxPartInitArch(spComponent component)
{
    SpTabBoxArch(component).num_label_buffer = 0;
    SpTabBoxArch(component).labels = NULL;
    SpTabBoxArch(component).focus_flag = SP_FALSE;
    SpTabBoxArch(component).need_map = SP_TRUE;
    
    return;
}

void spTabBoxPartFreeArch(spComponent component)
{
    return;
}

static void drawTabBox(spComponent tab_box)
{
    int i;
    int size;
    int width, height;
    static int flag = 0;
    static Pixel black_pixel = 0L, bg_pixel = 0L;
    static Pixel hilit_pixel = 0L, shadow_pixel = 0L;
    short sw, sh, sx, sy;
    Window window;

    if (flag == 0) {
	black_pixel = BlackPixelOfScreen(SpTopLevelArch(sp_toplevel).screen);
	XtVaGetValues(SpPrimitiveArch(tab_box).widget,
		      XmNbackground, &bg_pixel,
		      XmNtopShadowColor, &hilit_pixel,
		      XmNbottomShadowColor, &shadow_pixel,
		      NULL);
	flag = 1;
    }

    window = XtWindow(SpPrimitiveArch(tab_box).widget);
    
    if (spGetSize(tab_box, &width, &height) == SP_TRUE && window != None) {
	XtVaGetValues(SpTabBoxArch(tab_box).labels[SpTabBoxPart(tab_box).selected_index],
		      XmNwidth, &sw,
		      XmNheight, &sh,
		      NULL);
	spDebug(80, "drawTabBox", "label size: %d, %d\n", sw, sh);
	if (SpTabBoxArch(tab_box).focus_flag == SP_TRUE) {
	    XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
			   black_pixel);
	} else {
	    XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
			   bg_pixel);
	}
	XDrawRectangle(SpTopLevelArch(sp_toplevel).display,
		       XtWindow(SpTabBoxArch(tab_box).labels[SpTabBoxPart(tab_box).selected_index]),
		       SpTopLevelArch(sp_toplevel).fg_gc,
		       2, 5, sw - 5, sh - 10);

	XtVaGetValues(SpPrimitiveArch(tab_box).sub_widget,
		      XmNwidth, &sw,
		      XmNheight, &sh,
		      NULL);
	spDebug(80, "drawTabBox", "tab size: %d, %d\n", sw, sh);
	
	/* draw background */
	XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
		       bg_pixel);
	XFillRectangle(SpTopLevelArch(sp_toplevel).display, window,
		       SpTopLevelArch(sp_toplevel).fg_gc,
		       0, 0, width, height);
	
	/* draw highlight */
	XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
		       hilit_pixel);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  0, sh, 0, height - 1);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  1, sh, 1, height - 2);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  sw, sh, width - 1, sh);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  sw, sh + 1, width - 2, sh + 1);

	/* draw shadow */
	XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
		       shadow_pixel);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  0, height - 1, width - 1, height - 1);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  1, height - 2, width - 2, height - 2);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  width - 1, sh, width - 1, height - 1);
	XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
		  SpTopLevelArch(sp_toplevel).fg_gc,
		  width - 2, sh + 1, width - 2, height - 2);
	
	for (i = 0; i < SpTabBoxPart(tab_box).num_item; i++) {
	    if (i == SpTabBoxPart(tab_box).selected_index) {
		XtVaSetValues(SpTabBoxArch(tab_box).labels[i],
			      XmNtopOffset, 0,
			      XmNleftOffset, 0,
			      NULL);
	    } else {
		XtVaSetValues(SpTabBoxArch(tab_box).labels[i],
			      XmNtopOffset, 4,
			      XmNleftOffset, 2,
			      NULL);
	    }

	    /* get tab size */
	    XtVaGetValues(SpTabBoxArch(tab_box).labels[i],
			  XmNwidth, &sw,
			  XmNheight, &sh,
			  XmNx, &sx,
			  NULL);
	    sy = 0;
	    size = SP_TAB_CORNER_SIZE;
	
	    /* draw highlight */
	    XSetForeground(SpTopLevelArch(sp_toplevel).display,
			   SpTopLevelArch(sp_toplevel).fg_gc,
			   hilit_pixel);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      0, size - 1, size - 1, 0);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      1, size - 1, size - 1, 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      0, size, 0, sy + sh - 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      1, size, 1, sy + sh - 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      size, 0, sw - size, 0);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      size, 1, sw - size, 1);
	    
	    if (i == SpTabBoxPart(tab_box).selected_index) {
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  0, sy + sh, sx + 1, sy + sh);
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  1, sy + sh + 1, sx + 1, sy + sh + 1);
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  sx + sw, sy + sh, width - 1, sy + sh);
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  sx + sw, sy + sh + 1, width - 2, sy + sh + 1);
	    }
	    
	    /* draw shadow */
	    XSetForeground(SpTopLevelArch(sp_toplevel).display,
			   SpTopLevelArch(sp_toplevel).fg_gc,
			   shadow_pixel);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      sw - size, 0, sw - 1, size - 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      sw - size, 1, sw - 2, size - 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      sw - 1, size, sw - 1, sy + sh - 1);
	    XDrawLine(SpTopLevelArch(sp_toplevel).display,
		      XtWindow(SpTabBoxArch(tab_box).labels[i]),
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      sw - 2, size, sw - 2, sy + sh - 1);
	    
	    if (i == SpTabBoxPart(tab_box).selected_index) {
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  sx + sw - 2, sy + sh, sx + sw - 1, sy + sh);
		XDrawLine(SpTopLevelArch(sp_toplevel).display, window,
			  SpTopLevelArch(sp_toplevel).fg_gc,
			  sx + sw - 2, sy + sh + 1, sx + sw - 1, sy + sh + 1);
	    }
	}

	XSetForeground(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).fg_gc,
		       black_pixel);
    }
    
    return;
}

static void drawTabBoxCB(Widget widget, XtPointer client_data, XtPointer xt_call_data)
{
    spComponent tab_box = (spComponent)client_data;

    {
	XmAnyCallbackStruct *cbs;
	
	cbs = (XmAnyCallbackStruct *)xt_call_data;
	spDebug(80, "drawTabBoxCB", "reason: %d\n", cbs->reason);

	if (cbs->reason == XmCR_EXPOSE && SpTabBoxArch(tab_box).need_map == SP_TRUE) {
	    spMapTabItem(tab_box, SpTabBoxPart(tab_box).selected_index);
	    SpTabBoxArch(tab_box).need_map = SP_FALSE;
	}
    }
    
    drawTabBox(tab_box);
    return;
}

void spTabBoxCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];
    
    spDebug(30, "spTabBoxCreateArch", "in\n");
    
    SpComponentPart(component).border_width = 4;
    
    /* create tab box */
    XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
    XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
    XtSetArg(args[narg], XmNresizePolicy, XmRESIZE_NONE); narg++;
    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			      xmDrawingAreaWidgetClass, SpParentPrimitiveArch(component).widget,
			      args, narg);
    XtAddCallback(SpPrimitiveArch(component).widget, XmNexposeCallback,
		  (XtCallbackProc)drawTabBoxCB, (XtPointer)component);
    XtAddCallback(SpPrimitiveArch(component).widget, XmNresizeCallback,
		  (XtCallbackProc)drawTabBoxCB, (XtPointer)component);
    
    SpPrimitiveArch(component).sub_widget =
	XtVaCreateManagedWidget("",
				xmFormWidgetClass, SpPrimitiveArch(component).widget,
				XmNx, 0, XmNy, 0,
				XmNheight, SP_DEFAULT_TAB_HEIGHT,
				XmNresizePolicy, XmRESIZE_NONE,
				NULL);
    
    return;
}

void spTabBoxSetParamsArch(spComponent component)
{
    return;
}

void spTabBoxDestroyArch(spComponent component)
{
    if (SpTabBoxArch(component).labels != NULL) {
	xfree(SpTabBoxArch(component).labels);
	SpTabBoxArch(component).labels = NULL;
    }
    
    return;
}

int spGetSelectedTabIndexArch(spComponent component)
{
    return SpTabBoxPart(component).selected_index;
}

static void selectTabItemCB(Widget widget, XtPointer client_data,
			    XButtonEvent *event)
{
    spComponent tab_box;
    spComponent component = (spComponent)client_data;

    tab_box = spGetParent(component);
    
    if (spIsTabBox(tab_box) == SP_FALSE) return;

    if (SpPrimitivePart(component).index >= 0
	&& SpPrimitivePart(component).index < SpTabBoxPart(tab_box).num_item) {
	XmProcessTraversal(widget, XmTRAVERSE_CURRENT);
	
	spMapTabItem(tab_box, SpPrimitivePart(component).index);

	SpTabBoxPart(tab_box).selected_index = SpPrimitivePart(component).index;
	drawTabBox(tab_box);
    }
    
    return;
}

static void keyPressTabItemCB(Widget widget, XtPointer client_data, XEvent *event)
{
    int index;
    KeySym xks;
    int buf_size = 1024;
    char buf[1024];
    spComponent tab_box = (spComponent)client_data;

    if (event->type == KeyPress) {
	index = SpTabBoxPart(tab_box).selected_index;
	XLookupString(&event->xkey, buf, buf_size, &xks, NULL);
	if (xks == XK_Left) {
	    index--;
	} else if (xks == XK_Right) {
	    index++;
	}
	if (index < 0) {
	    index = SpTabBoxPart(tab_box).num_item - 1;
	} else if (index >= SpTabBoxPart(tab_box).num_item) {
	    index = 0;
	}
	spMapTabItem(tab_box, index);
	SpTabBoxPart(tab_box).selected_index = index;
	drawTabBox(tab_box);
    }
    
    return;
}

static void focusTabItemCB(Widget widget, XtPointer client_data, XEvent *event)
{
    spComponent tab_box = (spComponent)client_data;
    
    switch (event->type) {
      case FocusIn:
	if (SpTabBoxArch(tab_box).focus_flag == SP_FALSE) {
	    spDebug(100, "focusTabItemCB", "FocusIn\n");
	    SpTabBoxArch(tab_box).focus_flag = SP_TRUE;
	    drawTabBox(tab_box);
	}
	break;
      case FocusOut:
	if (SpTabBoxArch(tab_box).focus_flag == SP_TRUE) {
	    spDebug(100, "focusTabItemCB", "FocusOut\n");
	    SpTabBoxArch(tab_box).focus_flag = SP_FALSE;
	    drawTabBox(tab_box);
	}
	break;
      default:
	break;
    }
    
    return;
}

void spAddTabItemArch(spComponent component, int index)
{
    int i;
    char *title;
    XmString xmstr;
    int narg = 0;
    Arg args[10];
    spComponent tab_box;

    spDebug(30, "spAddTabItemArch", "in\n");
    
    tab_box = SpGetParent(component);
    SpComponentPart(component).top_offset += SP_DEFAULT_TAB_HEIGHT;

    if (SpTabBoxArch(tab_box).num_label_buffer < SpTabBoxPart(tab_box).num_item) {
	if (SpTabBoxArch(tab_box).num_label_buffer <= 0) {
	    SpTabBoxArch(tab_box).num_label_buffer += SP_TAB_ITEM_BUFFER;

	    SpTabBoxArch(tab_box).labels =
		xalloc(SpTabBoxArch(tab_box).num_label_buffer, Widget);

	} else {
	    SpTabBoxArch(tab_box).num_label_buffer += SP_TAB_ITEM_BUFFER;
	    
	    SpTabBoxArch(tab_box).labels =
		xrealloc(SpTabBoxArch(tab_box).labels,
			 SpTabBoxArch(tab_box).num_label_buffer, Widget);
	}
    }

    for (i = SpTabBoxPart(tab_box).num_item - 1; i > index; i--) {
	SpTabBoxArch(tab_box).labels[i] = SpTabBoxArch(tab_box).labels[i - 1];
    }
    
    narg = 0;
    XtSetArg(args[narg], XmNtraversalOn, True); narg++;
    XtSetArg(args[narg], XmNtopAttachment, XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNtopOffset, 0); narg++;
    XtSetArg(args[narg], XmNbottomAttachment, XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNbottomOffset, 0); narg++;
    XtSetArg(args[narg], XmNborderWidth, 0); narg++;
    XtSetArg(args[narg], XmNshowAsDefault, 0); narg++;
    XtSetArg(args[narg], XmNshadowThickness, 0); narg++;
    XtSetArg(args[narg], XmNhighlightThickness, 0); narg++;
    SpTabBoxArch(tab_box).labels[index] = 
	XtCreateManagedWidget("",
			      xmLabelWidgetClass,
			      SpPrimitiveArch(tab_box).sub_widget,
			      args, narg);
    XtAddEventHandler(SpTabBoxArch(tab_box).labels[index], ButtonPressMask, False,
		      (XtEventHandler)selectTabItemCB, (XtPointer)component);

    title = spGetTitle(component);
    if (!strnone(title)) {
	xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpTabBoxArch(tab_box).labels[index],
		      XmNlabelString, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    if (index >= 1) {
	narg = 0;
	XtSetArg(args[narg], XmNleftAttachment, XmATTACH_WIDGET); narg++;
	XtSetArg(args[narg], XmNleftWidget, SpTabBoxArch(tab_box).labels[index - 1]); narg++;
	XtSetArg(args[narg], XmNleftOffset, 2); narg++;
    } else {
	narg = 0;
	XtSetArg(args[narg], XmNleftAttachment, XmATTACH_FORM); narg++;
	XtSetArg(args[narg], XmNleftOffset, 0); narg++;
    }
    XtSetValues(SpTabBoxArch(tab_box).labels[index], args, narg);
    
    if (index <= SpTabBoxPart(tab_box).num_item - 2) {
	narg = 0;
	XtSetArg(args[narg], XmNleftAttachment, XmATTACH_WIDGET); narg++;
	XtSetArg(args[narg], XmNleftWidget, SpTabBoxArch(tab_box).labels[index]); narg++;
	XtSetArg(args[narg], XmNleftOffset, 0); narg++;
	XtSetValues(SpTabBoxArch(tab_box).labels[index + 1], args, narg);
    }

    XtAddEventHandler(SpTabBoxArch(tab_box).labels[index], FocusChangeMask,
		      False, (XtEventHandler)focusTabItemCB, (XtPointer)tab_box);
    XtAddEventHandler(SpTabBoxArch(tab_box).labels[index], KeyPressMask,
		      False, (XtEventHandler)keyPressTabItemCB, (XtPointer)tab_box);
    
    return;
}
