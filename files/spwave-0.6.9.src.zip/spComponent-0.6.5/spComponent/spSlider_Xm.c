/*
 *	spSlider_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/ScrolledW.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/Scale.h>
#include <Xm/ScrollBar.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spSliderP.h>

void spSliderCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[20];

    XtSetArg(args[narg], XmNminimum, SpSliderPart(component).minimum); narg++;
    XtSetArg(args[narg], XmNmaximum, SpSliderPart(component).maximum); narg++;
    XtSetArg(args[narg], XmNincrement, SpSliderPart(component).increment); narg++;
    XtSetArg(args[narg], XmNpageIncrement, SpSliderPart(component).page_increment); narg++;
    XtSetArg(args[narg], XmNvalue, SpSliderPart(component).value); narg++;
    
    if (spIsSubClass(component, SpTrackBar) == SP_FALSE) {
	XtSetArg(args[narg], XmNsliderSize, SpSliderPart(component).page_size); narg++;
    } else {
	XtSetArg(args[narg], XmNdecimalPoints, SpSliderPart(component).decimal_points); narg++;
    }
    
    XtSetArg(args[narg], XmNorientation,
	     (SpComponentPart(component).orientation == SP_HORIZONTAL ?
	      XmHORIZONTAL : XmVERTICAL)); narg++;
    
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	if (SpSliderPart(component).show_value == SP_TRUE) {
	    XtSetArg(args[narg], XmNshowValue, True); narg++;
	}
	    
	/* create scale */
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
				  xmScaleWidgetClass, SpParentPrimitiveArch(component).widget,
				  args, narg);
    } else {
	/* create scroll bar */
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
				  xmScrollBarWidgetClass, SpParentPrimitiveArch(component).widget,
				  args, narg);
    }
    
    return;
}

void spTrackBarCreateArch(spComponent component)
{
    spSliderCreateArch(component);
    return;
}

void spSliderSetParamsArch(spComponent component)
{
    int narg = 0;
    Arg args[20];

    XtSetArg(args[narg], XmNminimum, SpSliderPart(component).minimum); narg++;
    XtSetArg(args[narg], XmNmaximum, SpSliderPart(component).maximum); narg++;
    XtSetArg(args[narg], XmNincrement, SpSliderPart(component).increment); narg++;
    XtSetArg(args[narg], XmNpageIncrement, SpSliderPart(component).page_increment); narg++;
    XtSetArg(args[narg], XmNvalue, SpSliderPart(component).value); narg++;
    
    if (spIsSubClass(component, SpTrackBar) == SP_FALSE) {
	XtSetArg(args[narg], XmNsliderSize, SpSliderPart(component).page_size); narg++;
    } else {
	XtSetArg(args[narg], XmNdecimalPoints, SpSliderPart(component).decimal_points); narg++;
    }
    
    XtSetValues(SpPrimitiveArch(component).widget, args, narg);
    
    return;
}

void spTrackBarSetParamsArch(spComponent component)
{
    spSliderSetParamsArch(component);
    return;
}

void spSetSliderValueArch(spComponent component)
{
    XtVaSetValues(SpPrimitiveArch(component).widget,
		  XmNvalue, SpSliderPart(component).value,
		  NULL);
    
    return;
}

int spGetSliderValueArch(spComponent component)
{
    int value;
    
    XtVaGetValues(SpPrimitiveArch(component).widget,
		  XmNvalue, &value,
		  NULL);
    
    return value;
}
