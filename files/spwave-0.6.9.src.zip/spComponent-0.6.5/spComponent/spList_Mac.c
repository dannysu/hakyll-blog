/*
 *	spList_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spTextP.h>
#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spMenuItemP.h>
#include <sp/spListP.h>
#include <sp/spComboBoxP.h>

void spGetListFrameRectMac(spComponent list, Rect *prect)
{
    Rect rect;
    
    rect = SpPrimitiveArch(list).rect;
    InsetRect(&rect, -1, -1);
    spDebug(100, "spGetListFrameRectMac", "rect.left = %d, rect.right = %d, rect.top = %d, rect.bottom = %d\n",
	    rect.left, rect.right, rect.top, rect.bottom);
    
    *prect = rect;

    return;
}

spBool spActivateListMac(spComponent list, spBool activate, spBool foreground)
{
    spBool sensitive_flag;
    spComponent window;
    Rect rect;
    GrafPtr save_port;
    
    if (spIsVisible(list) == SP_FALSE || SpPrimitiveArch(list).map_flag == SP_FALSE) {
	return SP_FALSE;
    }
    
    window = SpGetWindow(list);
	
    if (SpPrimitiveArch(list).control != NULL) {
	if (activate == SP_TRUE) {
	    if (SpFrameArch(window).key_send_component == list) {
		SetKeyboardFocus(SpPrimitiveArch(window).window,
				 SpPrimitiveArch(list).control,
				 kControlListBoxPart);
	    }
	    if (foreground == SP_TRUE) {
		ActivateControl(SpPrimitiveArch(list).control);
	    }
	} else {
	    SetKeyboardFocus(SpPrimitiveArch(window).window,
			     SpPrimitiveArch(list).control,
			     kControlFocusNoPart);
	    if (foreground == SP_FALSE) {
		DeactivateControl(SpPrimitiveArch(list).control);
	    }
	}
    } else {
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	
	if (activate == SP_FALSE && foreground == SP_FALSE) {
	    sensitive_flag = SP_FALSE;
	} else {
	    sensitive_flag = SpPrimitiveArch(list).sensitive_flag;
	}
	
	spGetListFrameRectMac(list, &rect);
	
	if (activate == SP_TRUE) {
	    spDrawTextFrameMac(rect, sensitive_flag, SpFrameArch(window).key_send_component == list);
	} else {
	    spDrawTextFrameMac(rect, sensitive_flag, SP_FALSE);
	}

	spGetOriginalRGBMac();
	if (sensitive_flag == SP_TRUE) {
	    spSetNormalRGBMac();
	} else {
	    spSetDeactivateRGBMac();
	}
	LActivate((activate == SP_TRUE), SpListArch(list).list);
	spSetOriginalRGBMac();
	
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);

	spDrawListMac(list, SP_TRUE);
    }
	
    spDebug(10, "spActivateListMac", "done\n");
    
    return SP_TRUE;
}

void spDrawListMac(spComponent component, spBool update)
{
    spComponent window;
    Rect rect;
    GrafPtr save_port;
    spBool sensitive_flag = SP_TRUE;

    if (spIsVisible(component) == SP_FALSE || SpPrimitiveArch(component).map_flag == SP_FALSE) {
	return;
    }
    
    window = SpGetWindow(component);
	
    if (SpPrimitiveArch(component).control != NULL) {
	spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
				     SpPrimitiveArch(window).window);
    } else {
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	spGetOriginalRGBMac();
	
	spGetListFrameRectMac(component, &rect);
	spSetNormalRGBMac();
	EraseRect(&rect);
	
	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(window).activate_flag == SP_FALSE) {
	    sensitive_flag = SP_FALSE;
	    spSetDeactivateRGBMac();
	} else {
	    spSetNormalRGBMac();
	}
	
	LUpdate(spGetVisibleRegionMac(SpPrimitiveArch(window).window),
		SpListArch(component).list);
	
	spSetOriginalRGBMac();
	
	if (SpFrameArch(window).key_send_component == component) {
	    spDrawTextFrameMac(rect, sensitive_flag, SP_TRUE);
	} else {
	    spDrawTextFrameMac(rect, sensitive_flag, SP_FALSE);
	}
	
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);
    }
	
    spDebug(10, "spDrawListMac", "done: update = %d, current_width = %d, current_height = %d\n",
	    update, SpComponentPart(component).current_width, SpComponentPart(component).current_height);
    
    return;
}

static int getSelectedListIndex(spComponent component)
{
    Cell cell;
    
    SetPt(&cell, 0, 0);
    if (LGetSelect(true, &cell, SpListArch(component).list) == true) {
	spDebug(50, "getSelectedListIndex", "get select = %d/%d, index = %d\n",
		cell.v, (*SpListArch(component).list)->dataBounds.bottom, SpPrimitivePart(component).index);
	if (cell.v < (*SpListArch(component).list)->dataBounds.bottom) {
	    return cell.v;
	}
    }

    return -1;
}

static spBool handleListValueChanged(spComponent list)
{
    int index;

    index = getSelectedListIndex(list);
    
    if (SpPrimitivePart(list).index != index) {
	spSelectListIndexArch(list, index);
	spPostMessageMac(list, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spHandleListValueChangedMac(spComponent list, ControlPartCode part)
{
    if (spIsSubClass(list, SpList) == SP_FALSE || part == kControlNoPart) return SP_FALSE;
    
    spDebug(10, "spHandleListValueChangedMac", "part = %d\n", part);
    
    if (part == kControlListBoxDoubleClickPart) {
	spDebug(10, "spHandleListValueChangedMac", "list double clicked\n");
	spPostMessageMac(list, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
	return SP_TRUE;
    }

    return handleListValueChanged(list);
}

spBool spHandleListMouseMac(spComponent list, Point point, EventModifiers modifiers)
{
    Rect rect;
    GrafPtr save_port;
    ControlPartCode part = kControlNoPart;
    
    if (spIsSubClass(list, SpList) == SP_FALSE) return SP_FALSE;
    
    spDebug(80, "spHandleListMouseMac", "in\n");
    
    rect = SpPrimitiveArch(list).rect;
    
    if (SpPrimitiveArch(list).control != NULL) {
	part = HandleControlClick(SpPrimitiveArch(list).control,
				  point, modifiers, (ControlActionUPP)-1);
	spDebug(10, "spHandleListMouseMac", "part = %d\n", part);
    } else {
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(list)).window, &save_port);
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
	
	if (LClick(point, modifiers, SpListArch(list).list)) {
	    part = kControlListBoxDoubleClickPart;
	} else {
	    part = kControlListBoxPart;
	}
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(list)).window, save_port);
    }
    spFocusComponentMac(SpGetWindow(list), list);

    spHandleListValueChangedMac(list, part);
    
    spDebug(10, "spHandleListMouseMac", "done\n");
    
    return SP_TRUE;
}

static int scrollList(spComponent list, int increment)
{
    int index;
    spBool inverse_flag = SP_FALSE;

    if (increment == 0) return -1;
    
    spDebug(10, "scrollList", "increment = %d\n", increment);
    
    index = spGetSelectedListIndexArch(list);
    index += increment;
    if (increment < 0) {
	if (index < 0) {
	    index = spGetListNumItemMac(list) - 1;
	    inverse_flag = SP_TRUE;
	}
    } else {
	index = MAX(index, 0);
	if (index >= spGetListNumItemMac(list)) {
	    index = 0;
	    inverse_flag = SP_TRUE;
	}
    }
    spDebug(10, "scrollList", "index = %d\n", index);

#if 1	/* comment out if you want to do inverse search */
    if (inverse_flag == SP_TRUE) {
	return -1;
    }
#endif
    
    if (spIsComboBox(list) == SP_FALSE) {
	Rect rect;
	GrafPtr save_port;
		    
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(list)).window, &save_port);
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
	rect = (*SpListArch(list).list)->visible;
	if (index < rect.top) {
	    LScroll(0, index - rect.top, SpListArch(list).list);
	} else if (index >= rect.bottom) {
	    LScroll(0, index - rect.bottom + 1, SpListArch(list).list);
	}
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(list)).window, save_port);
    } else {
	spChangeEditMenuStateMac(SpGetWindow(list));
    }

    return index;
}

void spScrollListMac(spComponent list, int increment)
{
    int index;
    
    if ((index = scrollList(list, increment)) >= 0) {
	spSelectListIndexArch(list, index);
	
	if (spIsComboBox(list) == SP_FALSE) {
	    spPostMessageMac(list, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
	}
    }
    
    spDebug(10, "spScrollListMac", "done: index = %d\n", index);
    
    return;
}

spBool spHandleListKeyDownMac(spComponent list, EventModifiers modifiers, int keycode, char key)
{
    ControlPartCode part = kControlNoPart;
    
    if (spIsList(list) == SP_FALSE) return SP_FALSE;
    
    if (SpPrimitiveArch(list).control != NULL && spIsComboBox(list) == SP_FALSE) {
	spDebug(50, "spHandleListKeyDownMac", "modifiers = %d, keycode = %d, key = %c\n", modifiers, keycode, key);
	part = HandleControlKey(SpPrimitiveArch(list).control, keycode, key, modifiers);
	spDebug(50, "spHandleListKeyDownMac", "handled part = %d\n", part);
    } else if (key == kUpArrowCharCode) {
	spScrollListMac(list, -1);
	return SP_TRUE;
    } else if (key == kDownArrowCharCode) {
	spScrollListMac(list, 1);
	return SP_TRUE;
    }

    if (spIsComboBox(list) == SP_FALSE
	&& (key == '\r' || key == '\n' || key == kEnterCharCode)) {
	part = kControlListBoxDoubleClickPart;
    }

    return spHandleListValueChangedMac(list, part);
}

void spListCreateArch(spComponent component)
{
    Rect rect;
    GrafPtr save_port;
    Boolean visible;
    Rect bound_rect = {0, 0, 0, 1};
    Point cell_size = {0, 0};
    spComponent window;
    
    spSetComponentRectMac(component, SP_DEFAULT_LIST_WIDTH, SP_DEFAULT_LIST_HEIGHT);
    rect = SpPrimitiveArch(component).rect;
    rect.right = rect.right - SP_DEFAULT_SLIDER_WIDTH;
    rect.bottom = rect.bottom - SP_DEFAULT_SLIDER_WIDTH;
    OffsetRect(&rect, 5000, 5000); /* for strange drawing at first time */

    spDebug(50, "spListCreateArch", "left = %d, right = %d, top = %d, bottom = %d\n",
	    rect.left, rect.right, rect.top, rect.bottom);

    visible = spIsVisibleMac(component);
    /*visible = false;*/
    
    window = SpGetWindow(component);
    
    spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	
    if (spIsAquaMac() == SP_TRUE) {
	Size actualSize;

#if TARGET_API_MAC_CARBON
	ListDefSpec listDef;
	
	listDef.defType = kListDefStandardTextType;
	CreateListBoxControl(SpPrimitiveArch(window).window, &rect,
			     false, 0, 1, true,
			     true, 0, 0, false, &listDef, &SpPrimitiveArch(component).control);
	if (!visible) {
	    HideControl(SpPrimitiveArch(component).control);
	}
#else
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &rect, "\p", visible, 0, 0, 0,
		       kControlListBoxProc, 0);
#endif
	
	GetControlData(SpPrimitiveArch(component).control,
		       kControlEntireControl, kControlListBoxListHandleTag,
		       sizeof(SpListArch(component).list), (Ptr)&SpListArch(component).list,
		       &actualSize);

	if (!visible) {
	    LSetDrawingMode(false, SpListArch(component).list);
	}
	
	spSetReferenceMac(component);
    } else {
	SpListArch(component).list =
	    LNew(&rect		/* view rect*/,
		 &bound_rect,
		 cell_size,
		 0		/* LDEF Proc ID */,
		 SpPrimitiveArch(window).window,
		 visible	/* draw */, false /* hasGrow */,
		 true		/* scrollHoriz */, true /* scrollVert */);
    }
	
    spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);
    
    (*SpListArch(component).list)->selFlags |= lOnlyOne;

    spSetNeedUpdateMac(component);
    spSetKeySendComponentMac(component, SP_FALSE);
    
    return;
}

void spListSetParamsArch(spComponent component)
{
    return;
}

void spListGetParamsArch(spComponent component)
{
    return;
}

int spGetListNumItemMac(spComponent component)
{
    int num_item;

    if (spIsComboBox(component) == SP_TRUE) {
	num_item = CountMenuItems(SpPrimitiveArch(component).menu);
    } else {
	num_item = (*SpListArch(component).list)->dataBounds.bottom;
    }
    
    return num_item;
}

static void setMenuItemText(spComponent component, int index, Str255 pstr)
{
    InsertMenuItem(SpPrimitiveArch(component).menu, "\p ", index);
    spSetMenuItemTextMac(SpPrimitiveArch(component).menu, index, pstr);

    return;
}

static void getMenuItemText(spComponent component, int index, Str255 pstr)
{
    spGetMenuItemTextMac(SpPrimitiveArch(component).menu, index, pstr);
    
    return;
}

int spAddListItemArch(spComponent component, char *item)
{
    Str255 pstr;
    Cell cell;
    int count = 0;
    
    spStrCToP(item, pstr);
    
    if (spIsComboBox(component) == SP_TRUE) {
	count = CountMenuItems(SpPrimitiveArch(component).menu);
	setMenuItemText(component, count + 1, pstr);
    } else {
	spComponent window;
	GrafPtr save_port;
	
	window = SpGetWindow(component);
	
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    
	count = LAddRow(1, (*SpListArch(component).list)->dataBounds.bottom,
			SpListArch(component).list);
	SetPt(&cell, 0, count);
	LSetCell(&pstr[1], pstr[0], cell, SpListArch(component).list);
	
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);

#if 1
	if (SpPrimitiveArch(component).control != NULL) {
	    spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
					 SpPrimitiveArch(window).window);
	}
#endif
    }
    
    spDebug(50, "spAddListItemArch", "count = %d, item = %s\n", count, item);
	
    return count;
}

int spAddListIndexArch(spComponent component, char *item, int index)
{
    Str255 pstr;
    int count;
    Cell cell;
    
    spDebug(50, "spAddListIndexArch", "item = %s, index = %d\n", item, index);
	
    spStrCToP(item, pstr);
    
    if (spIsComboBox(component) == SP_TRUE) {
	setMenuItemText(component, index + 1, pstr);
    } else {
	spComponent window;
	GrafPtr save_port;
	
	window = SpGetWindow(component);
	
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
	
	count = LAddRow(1, index,
			SpListArch(component).list);
	spDebug(50, "spAddListIndexArch", "count = %d\n", count);
	SetPt(&cell, 0, count);
	LSetCell(&pstr[1], pstr[0], cell, SpListArch(component).list);
	
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);

#if 1
	if (SpPrimitiveArch(component).control != NULL) {
	    spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
					 SpPrimitiveArch(window).window);
	}
#endif
    }
    
    return index;
}

static int findComboItem(spComponent component, char *item)
{
    int index = -1;
    int i;
    int num_item;
    Str255 pstr, pitem;
    
    spStrCToP(item, pstr);
    num_item = CountMenuItems(SpPrimitiveArch(component).menu);
    
    for (i = 1; i <= num_item; i++) {
	getMenuItemText(component, i, pitem);

	if (pstr[0] == pitem[0]
	    && strneq((char *)(pstr + 1), (char *)(pitem + 1), (int)pstr[0])) {
	    index = i - 1;
	    break;
	}
    }
    
    return index;
}

static int findListItem(spComponent component, char *item)
{
    int index = -1;
    short len;
    int i;
    int num_item;
    Str255 pstr, pitem;
    Cell cell;
    
    spStrCToP(item, pstr);
    num_item = (*SpListArch(component).list)->dataBounds.bottom;
    spDebug(50, "findListItem", "num_item = %d\n", num_item);
    
    for (i = 0; i < num_item; i++) {
	SetPt(&cell, 0, i);
	len = 255;
	LGetCell(&pitem[1], &len, cell, SpListArch(component).list);
	pitem[0] = len;
	spDebug(50, "findListItem", "%d, %d\n", (int)pstr[0], (int)pitem[0]);

	if (pstr[0] == pitem[0]
	    && strneq((char *)(pstr + 1), (char *)(pitem + 1), (int)pstr[0])) {
	    index = i;
	    break;
	}
    }
    spDebug(50, "findListItem", "index = %d\n", index);
    
    return index;
}

int spDeleteListItemArch(spComponent component, char *item)
{
    int index;
    
    if (spIsComboBox(component) == SP_TRUE) {
	if ((index = findComboItem(component, item)) >= 0) {
	    DeleteMenuItem(SpPrimitiveArch(component).menu, index + 1);
	    return index;
	}
    } else {
	if ((index = findListItem(component, item)) >= 0) {
	    spComponent window;
	    GrafPtr save_port;
	
	    window = SpGetWindow(component);
	
	    spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	    spGetOriginalRGBMac();
	    spSetNormalRGBMac();
	    
	    LDelRow(1, index, SpListArch(component).list);
	    
	    spSetOriginalRGBMac();
	    spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);

#if 1
	    if (SpPrimitiveArch(component).control != NULL) {
		spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
					     SpPrimitiveArch(window).window);
	    }
#endif
	    
	    return index;
	}
    }
    
    return -1;
}

int spDeleteListIndexArch(spComponent component, int index)
{
    if (spIsComboBox(component) == SP_TRUE) {
	if (index >= CountMenuItems(SpPrimitiveArch(component).menu)) {
	    return -1;
	}	
	DeleteMenuItem(SpPrimitiveArch(component).menu, index + 1);
    } else {
	spComponent window;
	GrafPtr save_port;
	
	spDebug(50, "spDeleteListIndexArch", "index = %d, bottom = %d\n",
		index, (*SpListArch(component).list)->dataBounds.bottom);
	
	if (index >= (*SpListArch(component).list)->dataBounds.bottom) {
	    return -1;
	}
	
	window = SpGetWindow(component);
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
	
	LDelRow(1, index, SpListArch(component).list);
	
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);

#if 1
	if (SpPrimitiveArch(component).control != NULL) {
	    spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
					 SpPrimitiveArch(window).window);
	}
#endif
    }
    
    return index;
}

int spFindListItemArch(spComponent component, char *item)
{
    if (spIsComboBox(component) == SP_TRUE) {
	return findComboItem(component, item);
    } else {
	return findListItem(component, item);
    }
}

int spSelectListItemArch(spComponent component, char *item)
{
    int index;
    
    if ((index = spFindListItemArch(component, item)) >= 0) {
	if (spIsComboBox(component) == SP_TRUE) {
	    SpPrimitivePart(component).index = index;
	    spSetTextStringMac(component, item);
	    spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
	    return index;
	} else {
	    return spSelectListIndexArch(component, index);
	}
    }
    
    return -1;
}

static int getSelectedListItem(spComponent component, char *buf)
{
    short len;
    Cell cell;
    
    if (SpPrimitivePart(component).index < 0
	|| (SpPrimitivePart(component).index >=
	    (*SpListArch(component).list)->dataBounds.bottom)) {
	SpPrimitivePart(component).index = -1;
    } else {
	SetPt(&cell, 0, SpPrimitivePart(component).index);
	len = 255;
	LGetCell(buf, &len, cell, SpListArch(component).list);
	buf[len] = NUL;
	spDebug(50, "getSelectedListItem", "index = %d, buf = %s\n",
		SpPrimitivePart(component).index, buf);
    }
    
    return SpPrimitivePart(component).index;
}

static int getSelectedComboItem(spComponent component, char *buf)
{
    Str255 pstr;

    if (SpPrimitivePart(component).index < 0
	|| (SpPrimitivePart(component).index >=
	    CountMenuItems(SpPrimitiveArch(component).menu))) {
	SpPrimitivePart(component).index = -1;
    } else {
	getMenuItemText(component,
			SpPrimitivePart(component).index + 1, pstr);
	spStrPToC(pstr, buf);
    }
    
    return SpPrimitivePart(component).index;
}

int spSelectListIndexArch(spComponent component, int index)
{
    Cell cell;
    char buf[SP_MAX_LINE];
    
    if (spIsComboBox(component) == SP_TRUE) {
	spDebug(50, "spSelectListIndexArch", "index = %d\n", index);
	SpPrimitivePart(component).index = index;
	if (getSelectedComboItem(component, buf) < 0) {
	    return -1;
	}
	spSetTextStringMac(component, buf);
	spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
    } else {
	spComponent window;
	GrafPtr save_port;
	
	window = SpGetWindow(component);
	
	spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    
	if (SpPrimitivePart(component).index >= 0) {
	    /* clear previous selection */
	    SetPt(&cell, 0, SpPrimitivePart(component).index);
	    LSetSelect(false, cell, SpListArch(component).list);
	}
	
	/* select current item */
	SpPrimitivePart(component).index = index;
	SetPt(&cell, 0, SpPrimitivePart(component).index);
	LSetSelect(true, cell, SpListArch(component).list);
	
	spSetOriginalRGBMac();
	spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);
    }
    
    return index;
}

char *xspGetSelectedListItemArch(spComponent component)
{
    char buf[SP_MAX_LINE];
    int index = -1;
    
    if (spIsComboBox(component) == SP_TRUE) {
	index = getSelectedComboItem(component, buf);
    } else {
	if (spGetSelectedListIndexArch(component) >= 0) {
	    index = getSelectedListItem(component, buf);
	}
    }

    if (index >= 0) {
	return strclone(buf);
    }

    return NULL;
}

int spGetSelectedListIndexArch(spComponent component)
{
    if (spIsComboBox(component) == SP_FALSE) {
	SpPrimitivePart(component).index = getSelectedListIndex(component);
    }
    
    return SpPrimitivePart(component).index;
}

