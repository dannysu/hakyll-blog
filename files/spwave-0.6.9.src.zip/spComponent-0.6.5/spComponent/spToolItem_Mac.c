/*
 *	spToolItem_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if !defined(MACOSX)
#include <Icons.h>
#include <Resources.h>
#endif

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spCanvas.h>
#include <sp/spButton.h>

#include <sp/spFrameP.h>
#include <sp/spTopLevelP.h>
#include <sp/spToolItemP.h>

static spBool sp_set_balloon_forcedly = SP_FALSE;

static spBool showBalloon(spComponent component, Point point, unsigned long dsec)
{
    spBool flag = SP_FALSE;
    
    if (strnone(SpComponentPart(component).description)) return SP_FALSE;
    
#if !TARGET_API_MAC_CARBON
    if (!HMIsBalloon()) {
	Point tip, pt;
	Rect rect, hotrect;
	Str255 pstr;
	GrafPtr save_port;
	HMMessageRecord message;

	rect = SpPrimitiveArch(component).rect;
	
	spDebug(100, "spHandleComponentMouseMoveMac", "dsec = %ld\n", dsec);

	if (HMGetBalloons()) {
	    flag = SP_TRUE;
	}
	
	if (flag == SP_FALSE && dsec >= 2 && dsec < 10) {
	    HMSetBalloons(true);
	    sp_set_balloon_forcedly = SP_TRUE;
	    flag = SP_TRUE;
	}

	if (flag == SP_TRUE) {
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	    
	    tip = point;
	    LocalToGlobal(&tip);
	    
	    pt.v = rect.top; pt.h = rect.left;
	    LocalToGlobal(&pt);
	    hotrect.top = pt.v; hotrect.left = pt.h;
	    
	    pt.v = rect.bottom; pt.h = rect.right;
	    LocalToGlobal(&pt);
	    hotrect.bottom = pt.v; hotrect.right = pt.h;
	    
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	    
	    spStrCToP(SpComponentPart(component).description, pstr);
	    message.hmmHelpType = khmmString;
	    memcpy(message.u.hmmString, pstr, pstr[0]+1);
	    
	    if (HMShowBalloon(&message, tip, &hotrect,
			      NULL, 0, 0, kHMRegularWindow) != noErr) {
		flag = SP_FALSE;
	    }
	}
    }
#endif

    return flag;
}

static spBool hideBalloon(EventRecord *event)
{
    spDebug(100, "hideBalloon", "sp_set_balloon_forcedly = %d\n",
	    sp_set_balloon_forcedly);
    
    if (sp_set_balloon_forcedly == SP_TRUE) {
#if !TARGET_API_MAC_CARBON
	if (HMIsBalloon()) {
	    HMRemoveBalloon();
	}
	HMSetBalloons(false);
#endif
	sp_set_balloon_forcedly = SP_FALSE;
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spSetToolTipMac(spComponent component)
{
#if TARGET_API_MAC_CARBON
    ControlRef control;
    HMHelpContentRec helpContent;
    
    if (SpPrimitiveArch(component).control != NULL
	&& !strnone(SpComponentPart(component).description)) {
	control = SpPrimitiveArch(component).control;
			
	helpContent.version = kMacHelpVersion;
	GetControlBounds(control, &helpContent.absHotRect);
			
	LocalToGlobal(&spRectTopLeft(helpContent.absHotRect));
	LocalToGlobal(&spRectBotRight(helpContent.absHotRect));
			
	helpContent.tagSide = kHMDefaultSide;
			
	helpContent.content[kHMMinimumContentIndex].contentType = kHMPascalStrContent;
	spStrCToP(SpComponentPart(component).description,
		  helpContent.content[kHMMinimumContentIndex].u.tagString);
			
	helpContent.content[kHMMaximumContentIndex].contentType = kHMNoContent;
			
	HMSetControlHelpContent(control, &helpContent);
	return SP_TRUE;
    }
#endif

    return SP_FALSE;
}

spBool spShowToolTipMac(spComponent component, Point point, unsigned long dsec)
{
    return showBalloon(component, point, dsec);
}

spBool spHideToolTipMac(EventRecord *event)
{
    return hideBalloon(event);
}

spBool spUseBevelButtonForToolItemMac(void)
{
    /* Bevel button doesn't work on Mac OS X if you use pthread-based threads. */
    if (spIsAquaMac() == SP_FALSE && spGetAppearanceVersionMac() >= 0x00000101) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spDrawToolItemMac(spComponent component, spBool sensitive)
{
    Rect rect;
    GrafPtr save_port;
    
    if (spUseBevelButtonForToolItemMac() == SP_FALSE) {
	spDebug(50, "spDrawToolItemMac", "sensitive = %d\n", sensitive);
	if (SpToolItemArch(component).cicon != NULL) {
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);

	    rect = SpPrimitiveArch(component).rect;
	    InsetRect(&rect, 4, 4);

	    PlotCIconHandle(&rect, kAlignAbsoluteCenter,
			    (sensitive == SP_FALSE ? kTransformDisabled : kTransformNone),
			    SpToolItemArch(component).cicon);
			      
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	}
	
	spDebug(50, "spDrawToolItemMac", "done\n");
    }
    
    return;
}

static spBool spToolItemMouseLoopMac(spComponent component)
{
    Point point;
    EventRecord event;
    WindowPtr window;
    ControlRef control;
    GrafPtr save_port;
    spBool already_set = SP_FALSE;
    spBool flag = SP_FALSE;

    control = SpPrimitiveArch(component).control;

    if (spIsToggleButton(component) == SP_TRUE && GetControlValue(control)) {
	already_set = SP_TRUE;
    } else {
	HiliteControl(control, kControlButtonPart);
	spDrawToolItemMac(component, SP_TRUE);
    }

    while (1) {
	if (WaitNextEvent(everyEvent, &event, 1L, 0L)) {
	    if (event.what == mouseUp) {
		if (FindWindow(event.where, &window) == inContent) {
		    point = event.where;
		    spLockWindowPort(window, &save_port);
		    GlobalToLocal(&point);
		    spUnlockWindowPort(window, save_port);
		    
		    spDebug(10, "spToolItemMouseLoopMac", "x = %d, y = %d\n", point.h, point.v);	
	
		    if (PtInRect(point, &SpPrimitiveArch(component).rect)) {
			if (spIsToggleButton(component) == SP_TRUE && already_set == SP_FALSE) {
			    HiliteControl(control, kControlButtonPart);
			    SetControlValue(control, true);
			} else {
			    HiliteControl(control, 0);
			    SetControlValue(control, false);
			}
			spDrawToolItemMac(component, SP_TRUE);

			if (spIsToggleButton(component) == SP_TRUE) {
			    spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK,
					     SP_CR_VALUE_CHANGED);
			} else {
			    spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
			}
			
			flag = SP_TRUE;
		    }
		} else {
		    if (already_set == SP_FALSE) {
			HiliteControl(control, 0);
			spDrawToolItemMac(component, SP_TRUE);
			
			SetControlValue(control, false);
		    }
		}
		break;
	    }
	}
    }
    
    return flag;
}

spBool spHandleToolItemMouseDownMac(spComponent component, Point point)
{
    if (spIsToolItem(component) == SP_TRUE && spUseBevelButtonForToolItemMac() == SP_FALSE) {
	spToolItemMouseLoopMac(component);
	return SP_TRUE;
    }

    return SP_FALSE;
}

void spToolItemPartInitArch(spComponent component)
{
    SpToolItemArch(component).cicon = NULL;
    return;
}

void spToolItemPartFreeArch(spComponent component)
{
    return;
}

void spToolItemCreateArch(spComponent component)
{
    spComponent window;
	
    window = SpGetWindow(component);

    if (SpFramePart(window).tool_bar != NULL) {
	spComponent tool_bar;
	char resname[SP_MAX_LINE];
	Rect rect;
	Str255 pstr;
	Handle hres;
	short res_id;
	ResType res_type;
	Str255 pname;
	SInt16 min;
	ControlButtonContentInfo content_info;

	if (spIsSubClass(component, SpToolSeparator)) {
	} else {
	    tool_bar = SpGetParent(component);

#if 1
	    sprintf(resname, "%s%d", SpGetName(tool_bar), SpPrimitivePart(component).index);
	    spStrCToP(resname, pstr);
	    hres = Get1NamedResource('cicn', pstr);
	    GetResInfo(hres, &res_id, &res_type, pname);
	    ReleaseResource(hres);

	    SpToolItemArch(component).cicon = GetCIcon(res_id);
#else
	    SpToolItemArch(component).cicon = NULL;
#endif
	    
	    spSetComponentRectMac(component,
				  SpComponentPart(component).current_width,
				  SpComponentPart(component).current_height);
	    rect = SpPrimitiveArch(component).rect;
	    
	    if (SpToolItemArch(component).cicon != NULL) {
		HLock((Handle)SpToolItemArch(component).cicon);
		min = kControlContentCIconHandle;
		spStrCToP("", pstr);
	    } else {
		min = kControlContentTextOnly;
		spStrCToP(spGetTitle(component), pstr);
	    }

	    if (spUseBevelButtonForToolItemMac() == SP_TRUE) {
		if (spIsSubClass(component, SpCheckToolItem)) {
		    min += kControlBehaviorToggles;
		}
		SpPrimitiveArch(component).control =
		    NewControl(SpPrimitiveArch(window).window,
			       &rect, pstr, spIsVisibleMac(component),
			       0, min, 0, kControlBevelButtonSmallBevelProc, 0);
		
		if (SpToolItemArch(component).cicon != NULL) {
		    content_info.contentType = kControlContentCIconHandle;
		    content_info.u.cIconHandle = SpToolItemArch(component).cicon;
		    SetBevelButtonContentInfo(SpPrimitiveArch(component).control, &content_info);
		}
	    } else {
		SpPrimitiveArch(component).control =
		    NewControl(SpPrimitiveArch(window).window,
			       &rect, "\p", spIsVisibleMac(component),
			       0, 0, 1, pushButProc, 0);
	    }
	    
	    spSetReferenceMac(component);
	    spSetNeedUpdateMac(component);
	    spSetNeedMoveCallMac(component);
	}
    }
    
    return;
}

void spToolItemSetParamsArch(spComponent component)
{
    return;
}

void spToolItemDestroyArch(spComponent component)
{
    if (SpToolItemArch(component).cicon != NULL) {
	HUnlock((Handle)SpToolItemArch(component).cicon);
	DisposeCIcon(SpToolItemArch(component).cicon);
	SpToolItemArch(component).cicon = NULL;
    }
    
    return;
}

void spSetToolItemToggleStateArch(spComponent component)
{
    if (SpPrimitiveArch(component).control != NULL) {
	spDebug(50, "spSetToolItemToggleStateArch", "SpToolItemPart(component).set = %d\n",
		SpToolItemPart(component).set);
	if (SpToolItemPart(component).set == SP_TRUE) {
	    SetControlValue(SpPrimitiveArch(component).control, 1);
	    HiliteControl(SpPrimitiveArch(component).control, kControlButtonPart);
	} else {
	    SetControlValue(SpPrimitiveArch(component).control, 0);
	    HiliteControl(SpPrimitiveArch(component).control, 0);
	}
    }
    return;
}

void spGetToolItemToggleStateArch(spComponent component)
{
#if 0
    if (SpPrimitiveArch(component).control != NULL) {
	if (GetControlValue(SpPrimitiveArch(component).control)) {
	    SpToolItemPart(component).set = SP_TRUE;
	} else {
	    SpToolItemPart(component).set = SP_FALSE;
	}
    }
#endif
    return;
}
