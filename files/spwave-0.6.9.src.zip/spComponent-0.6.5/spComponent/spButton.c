/*
 *	spButton.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spToolItem.h>

#include <sp/spFrameP.h>
#include <sp/spMenuItemP.h>
#include <sp/spButtonP.h>

static spParamTable sp_button_param_tables[] = {
    {SppSet, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spButton, button.set), SP_FALSE_STRING},
    {SppDefaultButton, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spButton, button.default_flag), SP_FALSE_STRING},
    {SppCancelButton, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spButton, button.cancel_flag), SP_FALSE_STRING},
    {SppRadioEnd, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spButton, button.radio_end), SP_FALSE_STRING},
};

spButtonClassRec SpButtonClassRec = {
    /* spObjectClassPart */
    {
	SpButton,
	(spObjectClass)&SpLabelClassRec,
	sizeof(spButtonRec),
	spArraySize(sp_button_param_tables),
	sp_button_param_tables,
	spButtonPartInit,
	spButtonPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spButtonCreate,
	NULL,
	spButtonSetParams,
	spButtonGetParams,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spLabelClassPart */
    {
	0,
    },
    /* spButtonClassPart */
    {
	0,
    },
};

spComponentClass SpButtonClass = (spComponentClass)&SpButtonClassRec;

int spGetMnemonic(char *label, char *text)
{
    int i, j;
    int len;
    int c = NUL;
    int prev_c = NUL;

    len = strlen(label);
    spDebug(40, "spGetMnemonic", "strlen = %d\n", len);
    
    for (i = 0, j = 0; i < len; i++) {
	if (label[i] == '&' && label[i + 1] == '&') {
	    i++;
	    text[j] = label[i];
	    j++;
	} else if (label[i] == '&') {
	    c = label[i + 1];
#ifndef SP_SUPPORT_MNEMONIC
	    if (prev_c == '(' && c != NUL && label[i + 2] == ')') {
		j--;
		i += 2;
	    }
#endif
	} else {
	    text[j] = label[i];
	    j++;
	}
	prev_c = label[i];
    }
    text[j] = NUL;

#ifdef MNEMONIC_LOWER
    if (isupper(c)) {
	c = tolower(c);
    }
#endif
    
    spDebug(30, NULL, "label = %s, mnemonic = %c, text = %s\n", label, c, text);
    
    return c;
}

void spButtonPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).spacing_flag = SP_TRUE;
    SpButtonPart(component).set = SP_FALSE;
    SpButtonPart(component).default_flag = SP_FALSE;
    SpButtonPart(component).cancel_flag = SP_FALSE;
    SpButtonPart(component).radio_end = SP_FALSE;

    return;
}

void spButtonPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == SpFramePart(SpGetWindow(component)).default_button) {
	SpFramePart(SpGetWindow(component)).default_button = NULL;
    }
    if (component == SpFramePart(SpGetWindow(component)).cancel_button) {
	SpFramePart(SpGetWindow(component)).cancel_button = NULL;
    }
    
    return;
}

void spButtonCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (SpButtonPart(component).default_flag == SP_TRUE) {
	SpFramePart(SpGetWindow(component)).default_button = component;
    }
    if (SpButtonPart(component).cancel_flag == SP_TRUE) {
	SpFramePart(SpGetWindow(component)).cancel_button = component;
    }
    
    spPrimitiveSetDefaultSize(component);
    spButtonCreateArch(component);
    spShowToolTip(component);
	
    if (spIsToggleButton(component) == SP_TRUE) {
	spSetToggleState(component, SpButtonPart(component).set);
    }
    
    if (SpComponentPart(component).call_func != NULL) {
	spDebug(40, "spButtonCreate", "add callback\n");
	if (spIsToggleButton(component) == SP_TRUE) {
	    spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	} else {
	    spAddCallback(component, SP_ACTIVATE_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	}
    }
    
    return;
}

void spButtonSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spButtonSetParamsArch(component);

    if (spIsToggleButton(component) == SP_TRUE) {
	spSetToggleStateArch(component);
    }
    
    return;
}

void spButtonGetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (spIsToggleButton(component) == SP_TRUE) {
	spGetToggleStateArch(component);
    }
    
    return;
}

spBool spIsButton(spComponent component)
{
    return spIsSubClass(component, SpButton);
}

spBool spIsToggleButton(spComponent component)
{
    if (spIsSubClass(component, SpToggleButton) == SP_TRUE
	|| spIsSubClass(component, SpCheckBox) == SP_TRUE
	|| spIsSubClass(component, SpRadioButton) == SP_TRUE
	|| spIsSubClass(component, SpCheckBoxMenuItem) == SP_TRUE
	|| spIsSubClass(component, SpRadioButtonMenuItem) == SP_TRUE
	|| spIsSubClass(component, SpCheckToolItem) == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spIsRadioButton(spComponent component)
{
    if (spIsSubClass(component, SpRadioButton) == SP_TRUE
	|| spIsSubClass(component, SpRadioButtonMenuItem) == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spComponent spCreatePushButton(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpButtonClass, SpPushButton, name, parent, args, num_arg);
}

spComponent spCreateCheckBox(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpButtonClass, SpCheckBox, name, parent, args, num_arg);
}

spComponent spCreateRadioButton(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpButtonClass, SpRadioButton, name, parent, args, num_arg);
}

spBool spSetToggleState(spComponent component, spBool set)
{
    if (spIsToggleButton(component) == SP_FALSE) {
#if 1
	if (spIsToggleButton(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
#else
	return SP_FALSE;
#endif
    }

    if (spIsToolItem(component) == SP_TRUE) {
	return spSetToolItemToggleState(component, set);
    } else {
	SpButtonPart(component).set = set;
	spDebug(50, "spSetToggleState", "set: %d\n",
		SpButtonPart(component).set);
	spSetToggleStateArch(component);
    }

    return SP_TRUE;
}

spBool spGetToggleState(spComponent component, spBool *set)
{
    if (spIsToggleButton(component) == SP_FALSE) {
#if 1
	if (spIsToggleButton(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
#else
	return SP_FALSE;
#endif
    }
    
    if (spIsToolItem(component) == SP_TRUE) {
	return spGetToolItemToggleState(component, set);
    } else {
	spGetToggleStateArch(component);
	if (set != NULL) *set = SpButtonPart(component).set;
    }
    
    return SP_TRUE;
}

static spBool sp_radio_group_start = SP_FALSE;

void spAddRadioGroup(spComponent component, spBool radio_end)
{
    if (component == NULL) return;
    
    if (sp_radio_group_start == SP_FALSE) {
	sp_radio_group_start = SP_TRUE;
	SpPrimitivePart(component).index = SP_RADIO_GROUP_START;
    } else {
	if (radio_end == SP_TRUE) {
	    sp_radio_group_start = SP_FALSE;
	    SpPrimitivePart(component).index = SP_RADIO_GROUP_END;
	} else {
	    SpPrimitivePart(component).index = SP_RADIO_GROUP_MEMBER;
	}
    }
    
    return;
}

void spCheckRadioButton(spComponent component, spComponent first,
			spComponent last)
{
    spComponent temp;

    temp = first;
    while (1) {
	if (temp == NULL) break;

	if (temp == component) {
	    spSetToggleState(component, SP_TRUE);
	} else if (spIsRadioButton(temp) == SP_TRUE) {
	    spSetToggleState(temp, SP_FALSE);

	    spDebug(40, "spCheckRadioButton", "set false\n");
	}
	if (temp == last) break;
	    
	temp = SpGetNextComponent(temp);
    }

    return;
}

void spCheckRadioButtonCB(spComponent component, void *data)
{
    spComponent temp;
    spComponent prev_radio;
    spComponent first_radio = NULL;
    spComponent last_radio = NULL;
    
    if (spIsCreated(component) == SP_FALSE ||
	spIsRadioButton(component) == SP_FALSE) return;

    /* find first radio button */
    temp = component;
    prev_radio = component;
    first_radio = component;
    while (1) {
	if (temp == NULL) {
	    first_radio = prev_radio;
	    break;
	} else if (spIsRadioButton(temp) == SP_TRUE) {
	    if (SpPrimitivePart(temp).index == SP_RADIO_GROUP_START) {
		first_radio = temp;
		break;
	    } else {
		prev_radio = temp;
	    }
	}

	temp = SpGetPrevComponent(temp);
    }
    
    /* find last radio button */
    temp = component;
    prev_radio = component;
    while (1) {
	if (temp == NULL) {
	    last_radio = prev_radio;
	    break;
	} else if (spIsRadioButton(temp) == SP_TRUE) {
	    if (SpPrimitivePart(temp).index == SP_RADIO_GROUP_END) {
		last_radio = temp;
		break;
	    } else {
		prev_radio = temp;
	    }
	}

	temp = SpGetNextComponent(temp);
    }

    spCheckRadioButton(component, first_radio, last_radio);

    return;
}
