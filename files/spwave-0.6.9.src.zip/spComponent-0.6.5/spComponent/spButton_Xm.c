/*
 *	spButton_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/keysym.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItemP.h>
#include <sp/spButtonP.h>

void spButtonCreateArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_BUTTON_LABEL] = "";
    XmString xmstr;
    int narg = 0;
    Arg args[10];

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }

#ifdef XmNrecomputeSize
    XtSetArg(args[narg], XmNrecomputeSize, False); narg++;
#endif
    
    if (spIsToggleButton(component) == SP_TRUE) {
	if (spIsRadioButton(component) == SP_TRUE) {
	    XtSetArg(args[narg], XmNindicatorType, XmONE_OF_MANY); narg++;
	}
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_BEGINNING); narg++;
	XtSetArg(args[narg], XmNvisibleWhenOff, True); narg++;
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component))
				   ? SpGetName(component) : ""),
				  xmToggleButtonWidgetClass,
				  SpParentPrimitiveArch(component).widget,
				  args, narg);
    } else {
#ifdef SP_USE_BULLETIN_BOARD_FOR_WINDOW
	if (SpButtonPart(component).default_flag == SP_TRUE) {
	    XtSetArg(args[narg], XmNdefaultButtonShadowThickness, 1); narg++;
	    XtSetArg(args[narg], XmNshowAsDefault, 1); narg++;
	} else {
	    XtSetArg(args[narg], XmNdefaultButtonShadowThickness, 0); narg++;
	    XtSetArg(args[narg], XmNshowAsDefault, 0); narg++;
	}
#endif
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component))
				   ? SpGetName(component) : ""),
				  xmPushButtonWidgetClass,
				  SpParentPrimitiveArch(component).widget,
				  args, narg);
#ifdef SP_USE_BULLETIN_BOARD_FOR_WINDOW
	if (SpButtonPart(component).default_flag == SP_TRUE) {
	    XtVaSetValues(SpPrimitiveArch(SpGetWindow(component)).widget,
			  XmNdefaultButton, SpPrimitiveArch(component).widget,
			  NULL);
	}
	if (SpButtonPart(component).cancel_flag == SP_TRUE) {
	    XtVaSetValues(SpPrimitiveArch(SpGetWindow(component)).widget,
			  XmNcancelButton, SpPrimitiveArch(component).widget,
			  NULL);
	}
#endif
    }
    
    if (!strnone(label)) {
	xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNmnemonic, mnemonic,
		      XmNlabelString, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    if (spIsRadioButton(component) == SP_TRUE) {
	spAddRadioGroup(component, SpButtonPart(component).radio_end);
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK, spCheckRadioButtonCB, NULL);
    }

    return;
}

void spButtonSetParamsArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_BUTTON_LABEL] = "";
    XmString xmstr;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    short w, h;

	    /* get current size to keep component size */
	    XtVaGetValues(SpPrimitiveArch(component).widget,
			  XmNwidth, &w, XmNheight, &h,
			  NULL);
	    
	    xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	    XtVaSetValues(SpPrimitiveArch(component).widget,
			  XmNmnemonic, mnemonic,
			  XmNlabelString, xmstr,
			  NULL);
	    XmStringFree(xmstr);
	    
	    /* set previous size */
	    XtVaSetValues(SpPrimitiveArch(component).widget,
			  XmNwidth, w, XmNheight, h,
			  NULL);
	}
    }

    return;
}

void spSetToggleStateArch(spComponent component)
{
    XmToggleButtonSetState(SpPrimitiveArch(component).widget,
			   (SpButtonPart(component).set == SP_ON ? True : False), False);
    
    return;
}

void spGetToggleStateArch(spComponent component)
{
    if (XmToggleButtonGetState(SpPrimitiveArch(component).widget)) {
	SpButtonPart(component).set = SP_TRUE;
    } else {
	SpButtonPart(component).set = SP_FALSE;
    }

    return;
}
