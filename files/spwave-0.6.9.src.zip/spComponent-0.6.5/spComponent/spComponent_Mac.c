/*
 *	spComponent_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spOption.h>
#include <sp/spMemory.h>

#include <sp/spComponentP.h>

