/*
 *	spDialog_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdarg.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLabel.h>

#include <sp/spTopLevelP.h>
#include <sp/spParamFieldP.h>
#include <sp/spFrameP.h>
#include <sp/spGraphicsP.h>
#include <sp/spDialogP.h>

#include <gdk/gdkkeysyms.h>

static void modalLoop(GtkWidget *dialog)
{
    GtkWidget *prev_grabbed;
    
    gtk_widget_show(dialog);
    prev_grabbed = spAddGrabGtk(dialog);
	
    spMainLoopGtk();
	
    spAddGrabGtk(prev_grabbed);
    gtk_widget_hide(dialog);

    return;
}

void spDialogPartInitArch(spComponent component)
{
    SpDialogArch(component).file_type_field = NULL;
    
    return;
}

static void mainQuit(void)
{
    spRemoveGrabGtk(NULL);
    spMainQuitGtk();
    
    return;
}


static gint deleteEventCB(GtkWidget *widget, GdkEvent *event, void *data)
{
    mainQuit();
    return TRUE;
}

static void messageBoxCB(GtkWidget *widget, spDialogResponse *response)
{
    if (response != NULL) {
	*response = GPOINTER_TO_INT(gtk_object_get_data(GTK_OBJECT(widget), "value"));
    }
    
    mainQuit();
    return;
}

static gint keyPressEventCB(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    gint flag = FALSE;

    if (event->type == GDK_KEY_PRESS) {
	if (event->key.keyval == GDK_Escape) {
	    mainQuit();
	    flag = TRUE;
	}
    }

    return flag;
}

spDialogResponse spPopupMessageBox(spComponent component, char *message)
{
    spDialogResponse response = SP_DR_NONE;
    char *title;
    GtkWidget *label;
    GtkWidget *vbox;
    GtkWidget *dialog = NULL;
    GtkWidget *button1 = NULL;
    GtkWidget *button2 = NULL;
    GtkWidget *button3 = NULL;

    title = spGetMessageBoxTitle(component);
    
    dialog = gtk_dialog_new();
    vbox = GTK_DIALOG(dialog)->vbox;

    if (!strnone(title)) {
	spDebug(30, "createMessageDialog", "title = %s\n", title);
	gtk_window_set_title(GTK_WINDOW(dialog), title);
    }

    if (!strnone(message)) {
	spDebug(30, "createMessageDialog", "message = %s\n", message);
	
	label = gtk_label_new(message);
	/*gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);*/
	gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);
	gtk_widget_show(label);
    }

    gtk_signal_connect(GTK_OBJECT(dialog), "delete_event",
		       GTK_SIGNAL_FUNC(deleteEventCB), NULL);
    gtk_signal_connect(GTK_OBJECT(dialog), "key_press_event",
		       GTK_SIGNAL_FUNC(keyPressEventCB), NULL);
    
    if (SpDialogPart(component).button_type == SP_MB_OK) {
	button1 = gtk_button_new_with_label(SP_OK_LABEL);
	GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button1, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button1), "value", (gpointer)SP_DR_OK);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_grab_default(button1);
	gtk_widget_show(button1);
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	button1 = gtk_button_new_with_label(SP_OK_LABEL);
	GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button1, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button1), "value", (gpointer)SP_DR_OK);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_grab_default(button1);
	gtk_widget_show(button1);

	button2 = gtk_button_new_with_label(SP_CANCEL_LABEL);
	GTK_WIDGET_SET_FLAGS(button2, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button2, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button2), "value", (gpointer)SP_DR_CANCEL);
	gtk_signal_connect(GTK_OBJECT(button2), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_show(button2);
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	button1 = gtk_button_new_with_label(SP_YES_LABEL);
	GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button1, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button1), "value", (gpointer)SP_DR_YES);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_grab_default(button1);
	gtk_widget_show(button1);

	button2 = gtk_button_new_with_label(SP_NO_LABEL);
	GTK_WIDGET_SET_FLAGS(button2, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button2, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button2), "value", (gpointer)SP_DR_NO);

	gtk_signal_connect(GTK_OBJECT(button2), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_show(button2);
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	button1 = gtk_button_new_with_label(SP_YES_LABEL);
	GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button1, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button1), "value", (gpointer)SP_DR_YES);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_grab_default(button1);
	gtk_widget_show(button1);

	button2 = gtk_button_new_with_label(SP_NO_LABEL);
	GTK_WIDGET_SET_FLAGS(button2, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button2, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button2), "value", (gpointer)SP_DR_NO);
	gtk_signal_connect(GTK_OBJECT(button2), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_show(button2);

	button3 = gtk_button_new_with_label(SP_CANCEL_LABEL);
	GTK_WIDGET_SET_FLAGS(button3, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button3, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button3), "value", (gpointer)SP_DR_CANCEL);
	gtk_signal_connect(GTK_OBJECT(button3), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_show(button3);
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	button1 = gtk_button_new_with_label(SP_RETRY_LABEL);
	GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button1, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button1), "value", (gpointer)SP_DR_RETRY);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_grab_default(button1);
	gtk_widget_show(button1);

	button2 = gtk_button_new_with_label(SP_CANCEL_LABEL);
	GTK_WIDGET_SET_FLAGS(button2, GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button2, TRUE, TRUE, 2);
	gtk_object_set_data(GTK_OBJECT(button2), "value", (gpointer)SP_DR_CANCEL);
	gtk_signal_connect(GTK_OBJECT(button2), "clicked",
			   GTK_SIGNAL_FUNC(messageBoxCB), &response);
	gtk_widget_show(button2);
    }

    modalLoop(dialog);

    return response;
}

static char sp_fd_filename[SP_MAX_PATHNAME] = "";

static void file_selection_ok(GtkWidget *widget,
			      spComponent component)
{
    struct stat status;
    static char buf[SP_MAX_PATHNAME];

    if (component == NULL ||
	SpPrimitiveArch(component).widget == NULL) return;
    
    strcpy(sp_fd_filename,
	   gtk_file_selection_get_filename(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget)));
    
    if (stat(sp_fd_filename, &status) == 0) {
	if (S_ISDIR(status.st_mode)) { /* name is directory name */
	    if (SpDialogPart(component).dialog_type != SP_DIR_SELECTION_DIALOG) {
		SpDialogPart(component).initial_dir = sp_fd_filename;
		strcpy(sp_fd_filename, "");
		return;
	    }
	} else if (SpDialogPart(component).dialog_type == SP_DIR_SELECTION_DIALOG) {
	    spDisplayError(component, NULL, SP_NOT_DIR_MESSAGE);
	    strcpy(sp_fd_filename, "");
	    return;
	} else if (SpDialogPart(component).overwrite_prompt == SP_TRUE) {
	    if (spOverwritePrompt(component, sp_fd_filename) == SP_FALSE) {
		strcpy(sp_fd_filename, "");
		return;
	    }
	}
    } else if (SpDialogPart(component).dialog_type == SP_DIR_SELECTION_DIALOG) {
	/* not found such directory */
	spDisplayError(component, NULL,
		       SP_NOT_FOUND_PATH_MESSAGE);
	strcpy(sp_fd_filename, "");
	return;
    } else if (SpDialogPart(component).file_must_exist == SP_TRUE) {
	spDisplayError(component, NULL,
		       SP_NOT_FOUND_FILE_MESSAGE);
	strcpy(sp_fd_filename, "");
	return;
    } else if (SpDialogPart(component).path_must_exist == SP_TRUE) {
	strcpy(buf, sp_fd_filename);
	spGetDirName(buf);
	
	if (stat(buf, &status) != 0 || !S_ISDIR(status.st_mode)) {
	    /* not found such directory */
	    spDisplayError(component, NULL,
			   SP_NOT_FOUND_PATH_MESSAGE);
	    strcpy(sp_fd_filename, "");
	    return;
	}
    }
    
    mainQuit();
    return;
}

static void file_selection_cancel(GtkWidget *widget,
				  spComponent component)
{
    mainQuit();
    return;
}

static gint file_selection_delete(GtkWidget *widget, GdkEvent *event,
				  gpointer data)
{
    mainQuit();
    return TRUE;
}

static char *sp_default_file_filters[] =
{
    "*",
    NULL,
};

static void setFileMask(spComponent component, int index, spBool complete)
{
    char **file_filters;
    static char **prev_file_filters = NULL;
    static int prev_index = -1;

    if (component == NULL) return;

    if (index < 0) return;
    
    spDebug(10, "setFileMask", "index =  %d\n", index);
    
    if (SpDialogPart(component).filter_index != NULL) {
	*(SpDialogPart(component).filter_index) = index;
    }
    SpPrimitivePart(component).index = index;
    
    if (SpDialogPart(component).file_filters != NULL) {
	file_filters = SpDialogPart(component).file_filters;
    } else {
	file_filters = sp_default_file_filters;
    }

    if (file_filters == prev_file_filters && index == prev_index)
	return;

    if (complete == SP_TRUE) {
	if (SpDialogPart(component).dialog_type == SP_OPEN_FILE_DIALOG) {
#if GTK_CHECK_VERSION(1,2,0)
	    gtk_file_selection_complete(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget), 
					file_filters[index]);
#endif
	} else if (SpDialogPart(component).dialog_type == SP_SAVE_FILE_DIALOG) {
	    char buf[SP_MAX_PATHNAME];
	
	    spStrCopy(buf, sizeof(buf),
		      gtk_file_selection_get_filename(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget)));
	    if (!strnone(buf)) {
		spReplaceSuffix(buf, file_filters[index]);
		gtk_file_selection_set_filename(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget), buf);
	    }
	}
    }
    
    prev_index = index;
    prev_file_filters = file_filters;
    
    return;
}

static void selectFileTypeCB(spComponent component, void *data)
{
    int index;
    spComponent dialog = (spComponent)data;

    /* get selected index of combo box */
    index = spGetSelectedListIndex(component);

    if (GTK_WIDGET_MAPPED(SpPrimitiveArch(dialog).widget)) {
	setFileMask(dialog, index, SP_TRUE);
    } else {
	setFileMask(dialog, index, SP_FALSE);
    }
    
    return;
}

static void setFileTypes(spComponent component)
{
    int i;
    char **file_types;

    if (SpDialogPart(component).file_types != NULL) {
	file_types = SpDialogPart(component).file_types;
    } else if (SpDialogPart(component).file_filters != NULL) {
	file_types = SpDialogPart(component).file_filters;
    } else {
	file_types = sp_default_file_filters;
    }
    
    if (SpDialogArch(component).file_type_field == NULL) {
	SpObjectPart(component).create_flag = SP_TRUE;
	SpDialogArch(component).file_type_field =
	    spCreateParamField(component, "fileTypeField", 70,
			       SppTitle, SP_FILE_TYPE_LABEL,
			       SppEditable, SP_FALSE,
			       SppFieldOffset, 110,
			       SppFieldSize, 180,
			       SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
			       SppFieldStrings, file_types,
			       SppCallbackFunc, selectFileTypeCB,
			       SppCallbackData, component,
			       NULL);
	spAdjustComponentSize(SpParamFieldPart(SpDialogArch(component).file_type_field).box);
    } else {
	while (spDeleteListIndex(SpDialogArch(component).file_type_field, 0) >= 0);
	
	for (i = 0; file_types[i] != NULL; i++) {
	    spAddListItem(SpDialogArch(component).file_type_field, file_types[i]);
	}
    }

    if (SpDialogPart(component).filter_index != NULL) {
	SpPrimitivePart(component).index = MAX(*(SpDialogPart(component).filter_index), 0);
    } else {
	SpPrimitivePart(component).index = MAX(SpPrimitivePart(component).index, 0);
    }
    
    /* select index of list */
    spSelectListIndex(SpDialogArch(component).file_type_field, SpPrimitivePart(component).index);

    /* set file mask */
    setFileMask(component, SpPrimitivePart(component).index, SP_FALSE);

    spDebug(10, "setFileTypes", "done\n");
    
    return;
}

static void createFileDialog(spComponent component, spFileDialogType dialog_type)
{
    GtkWidget *dialog;
    
    if (spIsCreated(component) == SP_FALSE) {
	spDebug(10, "createFileDialog", "create\n");
    
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    dialog = gtk_file_selection_new(SP_SAVE_TITLE);
	    gtk_file_selection_show_fileop_buttons(GTK_FILE_SELECTION(dialog));
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    dialog = gtk_file_selection_new(SP_DIR_SELECTION_TITLE);
	    gtk_file_selection_show_fileop_buttons(GTK_FILE_SELECTION(dialog));
	} else {
	    dialog = gtk_file_selection_new(SP_OPEN_TITLE);
	    gtk_file_selection_hide_fileop_buttons(GTK_FILE_SELECTION(dialog));
	}
	gtk_window_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
	gtk_signal_connect(GTK_OBJECT(dialog), "delete_event",
			   GTK_SIGNAL_FUNC(file_selection_delete), NULL);
	gtk_signal_connect(GTK_OBJECT(dialog), "key_press_event",
			   GTK_SIGNAL_FUNC(keyPressEventCB), NULL);
	SpPrimitiveArch(component).widget = dialog;
	
	gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(dialog)->ok_button),
			   "clicked", GTK_SIGNAL_FUNC(file_selection_ok),
			   (gpointer)component);
	gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(dialog)->cancel_button),
			   "clicked", GTK_SIGNAL_FUNC(file_selection_cancel),
			   (gpointer)component);
	spDebug(10, "createFileDialog", "create done\n");
    }

    if (!strnone(SpComponentPart(component).title)) {
	spDebug(10, "createFileDialog", "title = %s\n", SpComponentPart(component).title);
    
	gtk_window_set_title(GTK_WINDOW(SpPrimitiveArch(component).widget),
			     SpComponentPart(component).title);
    }

    return;
}

char *xspPopupFileSelectionBoxArg(spComponent parent, char *name,
				  spFileDialogType dialog_type,
				  spArg *args, int num_arg)
{
    spComponent component;
    static spComponent sp_open_dialog = NULL;
    static spComponent sp_save_dialog = NULL;
    static spComponent sp_dir_dialog = NULL;

    spDebug(10, "xspPopupFileSelectionBoxArg", "in: num_arg = %d\n", num_arg);
    
    if ((dialog_type == SP_FD_TYPE_SAVE && sp_save_dialog == NULL) ||
	(dialog_type == SP_FD_TYPE_OPEN && sp_open_dialog == NULL) ||
	(dialog_type == SP_FD_TYPE_DIR && sp_dir_dialog == NULL)) {
	component = spCreateComponentArg(SpDialogClass, SpFileDialog,
					 name, NULL, args, num_arg);
	SpObjectPart(component).create_flag = SP_FALSE;
	createFileDialog(component, dialog_type);
	SpObjectPart(component).create_flag = SP_TRUE;
	
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    SpDialogPart(component).dialog_type = SP_SAVE_FILE_DIALOG;
	    sp_save_dialog = component;
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    SpDialogPart(component).dialog_type = SP_DIR_SELECTION_DIALOG;
	    sp_dir_dialog = component;
	} else {
	    SpDialogPart(component).dialog_type = SP_OPEN_FILE_DIALOG;
	    sp_open_dialog = component;
	}
    } else {
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    component = sp_save_dialog;
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    component = sp_dir_dialog;
	} else {
	    component = sp_open_dialog;
	}
	spSetParamsArg(component, args, num_arg);
	createFileDialog(component, dialog_type);
    }
    
    setFileTypes(component);
    
    if (!strnone(SpDialogPart(component).initial_file_name)) {
	gtk_file_selection_set_filename(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget), 
					spGetBaseName(SpDialogPart(component).initial_file_name));
    } else {
	gtk_file_selection_set_filename(GTK_FILE_SELECTION(SpPrimitiveArch(component).widget), "");
    }
    
    strcpy(sp_fd_filename, "");

    modalLoop(SpPrimitiveArch(component).widget);

    if (!strnone(sp_fd_filename)) {
	return strclone(sp_fd_filename);
    }
    
    return NULL;
}

#if GTK_CHECK_VERSION(1,2,0)
static char sp_selected_font[SP_MAX_PATHNAME] = "";

static void font_selection_ok (GtkWidget *w,
			       GtkFontSelectionDialog *fs)
{
    gchar *s = gtk_font_selection_dialog_get_font_name (fs);

    if (s != NULL) {
	spDebug(10, "font_selection_ok", "font = %s\n", s);
	spStrCopy(sp_selected_font, SP_MAX_PATHNAME, s);
    
	g_free(s);
    } else {
	strcpy(sp_selected_font, "");
    }
    
    mainQuit();
    
    return;
}

static void font_selection_cancel(GtkWidget *widget,
				  GtkFontSelectionDialog *fs)
{
    strcpy(sp_selected_font, "");
    mainQuit();
    return;
}

static gint font_selection_delete(GtkWidget *widget, GdkEvent *event,
				  gpointer data)
{
    strcpy(sp_selected_font, "");
    mainQuit();
    return TRUE;
}

static GtkWidget *createFontDialog(spComponent component)
{
    GtkWidget *dialog;
    
    dialog = gtk_font_selection_dialog_new(SP_FONT_SELECTION_TITLE);
    gtk_window_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);

    if (!strnone(SpDialogPart(component).initial_font)) {
	gtk_font_selection_dialog_set_font_name(GTK_FONT_SELECTION_DIALOG(dialog),
						SpDialogPart(component).initial_font);
    }

    gtk_signal_connect(GTK_OBJECT(dialog), "delete_event",
		       GTK_SIGNAL_FUNC(font_selection_delete), NULL);
    gtk_signal_connect (GTK_OBJECT(GTK_FONT_SELECTION_DIALOG(dialog)->ok_button),
			"clicked", GTK_SIGNAL_FUNC(font_selection_ok),
			GTK_FONT_SELECTION_DIALOG(dialog));
    gtk_signal_connect(GTK_OBJECT(GTK_FONT_SELECTION_DIALOG(dialog)->cancel_button),
		       "clicked", GTK_SIGNAL_FUNC(font_selection_cancel),
		       GTK_FONT_SELECTION_DIALOG(dialog));
	
    return dialog;
}
     
char *xspChooseFontArch(spComponent component)
{
    GtkWidget *dialog;

    dialog = createFontDialog(component);
    
    strcpy(sp_selected_font, "");
    modalLoop(dialog);

    gtk_widget_destroy(dialog);
    
    if (!strnone(sp_selected_font)) {
	return strclone(sp_selected_font);
    }
    
    return NULL;
}
#else
#include <sp/spDialogBoxP.h>

char *xspChooseFontArch(spComponent component)
{
    return xspChooseFontDefault(component);
}
#endif

#if 0
static char sp_selected_color[SP_MAX_PATHNAME] = "";

static void updateColorName(gdouble *color)
{
    spPixel pixel;

    if (color == NULL) {
	strcpy(sp_selected_color, "");
    } else {
	pixel = spRGB(spRound(255 * color[0]), spRound(255 * color[1]), spRound(255 * color[2]));
	spGetColorName(pixel, sp_selected_color);
    }

    return;
}

static void color_selection_ok(GtkWidget *w,
			       GtkColorSelectionDialog *cs)
{
    GtkColorSelection *colorsel;
    gdouble color[4];

    colorsel = GTK_COLOR_SELECTION(cs->colorsel);

    gtk_color_selection_get_color(colorsel, color);

    updateColorName(color);
    
    mainQuit();
    
    return;
}

static void color_selection_cancel(GtkWidget *widget,
				  GtkColorSelectionDialog *fs)
{
    strcpy(sp_selected_color, "");
    mainQuit();
    return;
}

static gint color_selection_delete(GtkWidget *widget, GdkEvent *event,
				  gpointer data)
{
    strcpy(sp_selected_color, "");
    mainQuit();
    return TRUE;
}

static GtkWidget *createColorDialog(spComponent component)
{
    GtkWidget *dialog;
    
    dialog = gtk_color_selection_dialog_new(SP_COLOR_SELECTION_TITLE);
    gtk_window_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
    gtk_color_selection_set_opacity (
		GTK_COLOR_SELECTION(GTK_COLOR_SELECTION_DIALOG(dialog)->colorsel),
		FALSE);
    gtk_color_selection_set_update_policy(
		GTK_COLOR_SELECTION(GTK_COLOR_SELECTION_DIALOG(dialog)->colorsel),
		GTK_UPDATE_CONTINUOUS);
    gtk_widget_hide(GTK_COLOR_SELECTION_DIALOG(dialog)->help_button);

    if (!strnone(SpDialogPart(component).initial_color)) {
	GdkColor gdkcolor;
	gdouble color[4];
	
	spGetColorValue(SpDialogPart(component).initial_color,
			&gdkcolor);
	color[0] = (double)gdkcolor.red / 65535.0;
	color[1] = (double)gdkcolor.green / 65535.0;
	color[2] = (double)gdkcolor.blue / 65535.0;
	color[3] = 0.0;
	
	gtk_color_selection_set_color(
	        GTK_COLOR_SELECTION(GTK_COLOR_SELECTION_DIALOG(dialog)->colorsel),
		color);
    }

    gtk_signal_connect(GTK_OBJECT(dialog), "delete_event",
		       GTK_SIGNAL_FUNC(color_selection_delete), NULL);
    gtk_signal_connect (GTK_OBJECT(GTK_COLOR_SELECTION_DIALOG(dialog)->ok_button),
			"clicked", GTK_SIGNAL_FUNC(color_selection_ok),
			GTK_COLOR_SELECTION_DIALOG(dialog));
    gtk_signal_connect(GTK_OBJECT(GTK_COLOR_SELECTION_DIALOG(dialog)->cancel_button),
		       "clicked", GTK_SIGNAL_FUNC(color_selection_cancel),
		       GTK_COLOR_SELECTION_DIALOG(dialog));
	
    return dialog;
}

char *xspChooseColorArch(spComponent component)
{
    GtkWidget *dialog;

    dialog = createColorDialog(component);
    
    strcpy(sp_selected_color, "");
    modalLoop(dialog);

    gtk_widget_destroy(dialog);
    
    if (!strnone(sp_selected_color)) {
	return strclone(sp_selected_color);
    }
    
    return NULL;
}
#else
#include <sp/spDialogBoxP.h>

char *xspChooseColorArch(spComponent component)
{
    return xspChooseColorDefault(component);
}
#endif
