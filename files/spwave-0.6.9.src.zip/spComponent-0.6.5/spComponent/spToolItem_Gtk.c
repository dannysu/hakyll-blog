/*
 *	spToolItem_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spToolBarP.h>
#include <sp/spToolItemP.h>

extern spTopLevel sp_toplevel;

void spToolItemPartInitArch(spComponent component)
{
    SpToolItemArch(component).bitmap = NULL;
    SpToolItemArch(component).insens_pixmap = NULL;
    return;
}

void spToolItemPartFreeArch(spComponent component)
{
    return;
}

static void drawInsensitivePixmap(GdkPixmap *pixmap, int width, int height)
{
    int x, y;
    int size = 2;

    for (y = 0; y < height; y += size) {
	for (x = 0; x < width; x += size) {
	    if (((x / size) % 2 == 0 && (y / size) % 2 == 0)
		|| ((x / size) % 2 == 1 && (y / size) % 2 == 1)) {
		gdk_draw_rectangle(pixmap,
				   SpTopLevelArch(sp_toplevel).bg_gc,
				   TRUE, 
				   x, y, size, size);
	    }
	}
    }

    return;
}

static void addToolItem(GtkWidget *widget, spComponent component)
{
    GdkBitmap *bitmap = NULL;
	    
    if (SpParentPrimitiveArch(component).pixmap != NULL) {
	/* create pixmap */
	SpPrimitiveArch(component).pixmap =
	    gdk_pixmap_new(SpParentPrimitiveArch(component).widget->window,
			   SpParentToolBarPart(component).bitmap_width,
			   SpParentToolBarPart(component).bitmap_height,
			   -1);
	gdk_draw_pixmap(SpPrimitiveArch(component).pixmap,
			SpTopLevelArch(sp_toplevel).fg_gc,
			SpParentPrimitiveArch(component).pixmap,
			SpPrimitivePart(component).index * SpParentToolBarPart(component).bitmap_width,
			0,
			0, 0,
			SpParentToolBarPart(component).bitmap_width,
			SpParentToolBarPart(component).bitmap_height);

	/* create insensitive pixmap */
	SpToolItemArch(component).insens_pixmap = 
	    gdk_pixmap_new(SpParentPrimitiveArch(component).widget->window,
			   SpParentToolBarPart(component).bitmap_width,
			   SpParentToolBarPart(component).bitmap_height,
			   -1);
	gdk_draw_pixmap(SpToolItemArch(component).insens_pixmap,
			SpTopLevelArch(sp_toplevel).fg_gc,
			SpParentPrimitiveArch(component).pixmap,
			SpPrimitivePart(component).index * SpParentToolBarPart(component).bitmap_width,
			0,
			0, 0,
			SpParentToolBarPart(component).bitmap_width,
			SpParentToolBarPart(component).bitmap_height);
	drawInsensitivePixmap(SpToolItemArch(component).insens_pixmap,
			      SpParentToolBarPart(component).bitmap_width,
			      SpParentToolBarPart(component).bitmap_height);

	/* create mask bitmap */
	if (SpParentToolBarArch(component).bitmap != NULL) {
	    GdkGC *gc;
	    
	    SpToolBarArch(component).bitmap =
		gdk_pixmap_new(NULL,
			       SpParentToolBarPart(component).bitmap_width,
			       SpParentToolBarPart(component).bitmap_height,
			       1);

	    gc = gdk_gc_new(SpToolBarArch(component).bitmap);
	    
	    gdk_draw_pixmap(SpToolBarArch(component).bitmap,
			    gc,
			    SpParentToolBarArch(component).bitmap,
			    SpPrimitivePart(component).index * SpParentToolBarPart(component).bitmap_width,
			    0,
			    0, 0,
			    SpParentToolBarPart(component).bitmap_width,
			    SpParentToolBarPart(component).bitmap_height);
	    
	    gdk_gc_destroy(gc);
	    
	    bitmap = SpToolBarArch(component).bitmap;
	}
	
	SpPrimitiveArch(component).sub_widget =
	    gtk_pixmap_new(SpPrimitiveArch(component).pixmap, bitmap);
	
	if (spIsSubClass(component, SpCheckToolItem)) {
	    SpPrimitiveArch(component).widget =
		gtk_toolbar_append_element(GTK_TOOLBAR(SpParentPrimitiveArch(component).widget),
					   GTK_TOOLBAR_CHILD_TOGGLEBUTTON, NULL,
					   SpComponentPart(component).description,
					   SpComponentPart(component).description,
					   NULL,
					   SpPrimitiveArch(component).sub_widget,
					   NULL, NULL);
	} else {
	    SpPrimitiveArch(component).widget =
		gtk_toolbar_append_item(GTK_TOOLBAR(SpParentPrimitiveArch(component).widget),
					SpComponentPart(component).description,
					SpComponentPart(component).description,
					NULL,
					SpPrimitiveArch(component).sub_widget,
					NULL, NULL);
	}
	
	if (spIsSubClass(component, SpCheckToolItem)) {
	    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(SpPrimitiveArch(component).widget),
					(SpToolItemPart(component).set == SP_ON ? TRUE : FALSE));
	}
    }
    
    return;
}
    
void spToolItemCreateArch(spComponent component)
{
    if (spIsSubClass(component, SpToolSeparator) == SP_FALSE) {
	if (GTK_WIDGET_REALIZED(SpParentPrimitiveArch(component).widget)) {
	    addToolItem(SpParentPrimitiveArch(component).widget, component);
	} else {
	    gtk_signal_connect(GTK_OBJECT(SpParentPrimitiveArch(component).widget),
			       "realize", GTK_SIGNAL_FUNC(addToolItem),
			       (gpointer)component);
	}
    }
    
    return;
}

void spToolItemSetParamsArch(spComponent component)
{
    return;
}

void spToolItemDestroyArch(spComponent component)
{
    if (SpToolItemArch(component).bitmap != NULL) {
	gdk_bitmap_unref(SpToolItemArch(component).bitmap);
    }
    
    if (SpToolItemArch(component).insens_pixmap != NULL) {
	gdk_pixmap_unref(SpToolItemArch(component).insens_pixmap);
    }

    return;
}

void spSetToolItemToggleStateArch(spComponent component)
{
    if (GTK_WIDGET_REALIZED(SpParentPrimitiveArch(component).widget)) {
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(SpPrimitiveArch(component).widget),
				    (SpToolItemPart(component).set == SP_ON ? TRUE : FALSE));
    }
    
    return;
}

void spGetToolItemToggleStateArch(spComponent component)
{
    if (GTK_WIDGET_REALIZED(SpParentPrimitiveArch(component).widget)) {
	if (GTK_TOGGLE_BUTTON(SpPrimitiveArch(component).widget)->active) {
	    SpToolItemPart(component).set = SP_TRUE;
	} else {
	    SpToolItemPart(component).set = SP_FALSE;
	}
    }
    
    return;
}
