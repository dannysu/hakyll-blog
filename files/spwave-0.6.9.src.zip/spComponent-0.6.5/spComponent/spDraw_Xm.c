/*
 *	spDraw_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

void spImageCreateArch(spComponent component)
{
    return;
}

spBool spIsDrawable(spComponent component)
{
    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).pixmap != None) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spGetDisplayInfo(spComponent component)
{
    if (component == NULL) return;
    
    if (SpPrimitiveArch(component).display == NULL) {
	if (SpPrimitiveArch(component).widget == NULL) {
	    SpPrimitiveArch(component).display = SpTopLevelArch(sp_toplevel).display;
	} else {
	    SpPrimitiveArch(component).display = XtDisplay(SpPrimitiveArch(component).widget);
	}
    }
    if (SpPrimitiveArch(component).screen == NULL) {
	if (SpPrimitiveArch(component).widget == NULL) {
	    SpPrimitiveArch(component).screen = SpTopLevelArch(sp_toplevel).screen;
	} else {
	    SpPrimitiveArch(component).screen = XtScreen(SpPrimitiveArch(component).widget);
	}
    }

    return;
}

void spDrawImageArch(spComponent component)
{
    spGetDisplayInfo(component);
    
    XFillRectangle(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
		   SpTopLevelArch(sp_toplevel).bg_gc,
		   0, 0, SpComponentPart(component).client_width,
		   SpComponentPart(component).client_height);
    
    return;
}

void spRedrawImageArch(spComponent component)
{
    spGetDisplayInfo(component);
    
    if (SpPrimitiveArch(component).pixmap != None) {
	XFreePixmap(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap);
	SpPrimitiveArch(component).pixmap = None;
    }
    
    /* create pixmap */
    if ((SpPrimitiveArch(component).pixmap = 
	 XCreatePixmap(SpPrimitiveArch(component).display, 
		       RootWindowOfScreen(SpPrimitiveArch(component).screen),
		       SpComponentPart(component).client_width, SpComponentPart(component).client_height,
		       DefaultDepthOfScreen(SpPrimitiveArch(component).screen))) == None) {
	spError(1, "can't create pixmap\n");
    }
    
    return;
}

void spCopyImageArch(spComponent src, spComponent dest,
		     int src_x, int src_y, int width, int height,
		     int dest_x, int dest_y)
{
    XCopyArea(SpPrimitiveArch(dest).display, SpPrimitiveArch(src).pixmap,
	      SpPrimitiveArch(dest).pixmap, SpTopLevelArch(sp_toplevel).fg_gc,
	      src_x, src_y,
	      MIN(SpComponentPart(src).client_width, width),
	      MIN(SpComponentPart(src).client_height, height),
	      dest_x, dest_y);

    return;
}

void spFillRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XFillRectangle(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
		   (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		    SpGraphicsArch(graphics).gc),
		   x, y, width, height);

    return;
}

void spDrawRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XDrawRectangle(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
		   (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		    SpGraphicsArch(graphics).gc),
		   x, y, width, height);

    return;
}

void spFillArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XFillArc(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	     (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
	      SpGraphicsArch(graphics).gc),
	     x, y, width, height, angle1 * 64, angle2 * 64);

    return;
}

void spDrawArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XDrawArc(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	     (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
	      SpGraphicsArch(graphics).gc),
	     x, y, width, height, angle1 * 64, angle2 * 64);

    return;
}

void spDrawLine(spComponent component, spGraphics graphics,
		int x1, int y1, int x2, int y2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XDrawLine(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	      (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
	       SpGraphicsArch(graphics).gc),
	      x1, y1, x2, y2);
#if 1
    XDrawPoint(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	       (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		SpGraphicsArch(graphics).gc),
	       x2, y2);
#endif
    
    return;
}

void spDrawPoint(spComponent component, spGraphics graphics,
		 int x, int y)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    XDrawPoint(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	       (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		SpGraphicsArch(graphics).gc),
	       x, y);
    
    return;
}

void spDrawString(spComponent component, spGraphics graphics,
		  int x, int y, char *string)
{
    if (spIsDrawable(component) == SP_FALSE || strnone(string)) return;

#if 0
    XDrawString(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
		(graphics == NULL ? sp_toplevel->gc : SpGraphicsArch(graphics).gc),
		x, y, string, strlen(string));
#else
    XmbDrawString(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
		  (graphics == NULL ? SpTopLevelArch(sp_toplevel).font_set :
		   SpGraphicsArch(graphics).font_set),
		  (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		   SpGraphicsArch(graphics).gc),
		  x, y, string, strlen(string));
#endif
    
    return;
}

spBool spGetStringExtent(spGraphics graphics, char *string,
			 int *x, int *y, int *width, int *height)
{
    XRectangle ink, log;
    
    if (strnone(string)) return SP_FALSE;
    
    XmbTextExtents((graphics == NULL ? SpTopLevelArch(sp_toplevel).font_set :
		    SpGraphicsArch(graphics).font_set),
		   string, strlen(string), &ink, &log);
    
    if (x != NULL) *x = log.x;
    if (y != NULL) *y = log.y;
    if (width != NULL) *width = log.width;
    if (height != NULL) *height = log.height;
    
    return SP_TRUE;
}

#if 0
/* for GL */
/*spGLContext*/

spGLMakeCurrent();
spGLCreateContext();
spGLDestroyContext();
spGLCopyContext();
spGLSwapBuffers();
spGLCurrentContext();
spGLCurrentDrawable();
spGLWait();
spGLWaitSystem();
#endif
