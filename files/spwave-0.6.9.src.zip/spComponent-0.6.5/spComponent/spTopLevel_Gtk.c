/*
 *	spTopLevel_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <glib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spThread.h>

#include <sp/spLocaleP.h>
#include <sp/spComponentP.h>
#include <sp/spTopLevelP.h>
#include <sp/spGraphicsP.h>

#if defined(HAVE_PTHREAD)
#include <pthread.h>

static pthread_t sp_main_thread_id;
static pthread_mutex_t sp_thread_loop_mutex, sp_main_loop_mutex, sp_thread_enter_mutex;
#endif

static volatile spBool sp_gtk_main_loop_exist = SP_FALSE;

void spTopLevelPartInitArch(spTopLevel toplevel)
{
    return;
}

void spTopLevelPartFreeArch(spTopLevel toplevel)
{
    return;
}

void spTopLevelCreateArch(spTopLevel toplevel)
{
    char buf[1024];
    GdkGCValues gc_values;
    GdkGCValuesMask gc_values_mask;

#if defined(HAVE_PTHREAD) && GTK_CHECK_VERSION(1,2,4) /* menus may not work before 1.2.4. */
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	g_thread_init(NULL);
	if (g_thread_supported()) {
	    pthread_mutex_init(&sp_main_loop_mutex, NULL);
	    pthread_mutex_init(&sp_thread_loop_mutex, NULL);
	    pthread_mutex_init(&sp_thread_enter_mutex, NULL);
	    sp_main_thread_id = pthread_self();
	    spDebug(50, "spTopLevelCreateArch", "main_thread = %ld\n", (long)sp_main_thread_id);
	} else {
	    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
	}
    }
#else
    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
#endif
    
    gtk_init(SpTopLevelPart(toplevel).argcp, SpTopLevelPart(toplevel).argvp);
    spDebug(50, "spTopLevelCreateArch", "gtk_init done\n");
    
    sprintf(buf, "%s/.gtkrc", getenv("HOME"));
    gtk_rc_parse(buf);
    spDebug(50, "spTopLevelCreateArch", "gtkrc parse done\n");

    SpTopLevelArch(toplevel).pixmap = gdk_pixmap_new(NULL, 1, 1,
						     gdk_visual_get_best_depth());
    SpTopLevelArch(toplevel).colormap = gdk_colormap_get_system();
    
    gdk_color_black(SpTopLevelArch(toplevel).colormap,
		    &SpTopLevelArch(toplevel).black);
    gdk_color_white(SpTopLevelArch(toplevel).colormap,
		    &SpTopLevelArch(toplevel).white);
    gdk_color_parse("#d7d7d7", &SpTopLevelArch(toplevel).gray);
    gdk_color_alloc(SpTopLevelArch(toplevel).colormap, &SpTopLevelArch(toplevel).gray);
    
    if ((SpTopLevelArch(toplevel).font = gdk_fontset_load("-*-*-medium-r-normal--14-*-*-*-*-*-*-*")) == NULL) {
	SpTopLevelArch(toplevel).font = gdk_fontset_load("-*-*-*-*-*--*-*-*-*-*-*-*-*");
    }
    
    gc_values.foreground = SpTopLevelArch(toplevel).black;
    gc_values.background = SpTopLevelArch(toplevel).white;
    gc_values.font = SpTopLevelArch(toplevel).font;
    gc_values_mask = GDK_GC_FOREGROUND | GDK_GC_BACKGROUND | GDK_GC_FONT;
    SpTopLevelArch(toplevel).fg_gc = gdk_gc_new_with_values(SpTopLevelArch(toplevel).pixmap,
							    &gc_values,
							    gc_values_mask);

    gc_values.foreground = SpTopLevelArch(toplevel).gray;
    gc_values.background = SpTopLevelArch(toplevel).black;
    gc_values.font = SpTopLevelArch(toplevel).font;
    gc_values_mask = GDK_GC_FOREGROUND | GDK_GC_BACKGROUND | GDK_GC_FONT;
    SpTopLevelArch(toplevel).bg_gc = gdk_gc_new_with_values(SpTopLevelArch(toplevel).pixmap,
							    &gc_values,
							    gc_values_mask);
    
    spDebug(50, "spTopLevelCreateArch", "done\n");

    spSetExitFunc(gtk_exit);
    
    return;
}

void spTopLevelSetParamsArch(spTopLevel toplevel)
{
    return;
}
    
void spTopLevelDestroyArch(spTopLevel toplevel)
{
    if (SpTopLevelArch(toplevel).pixmap != NULL) {
	gdk_pixmap_unref(SpTopLevelArch(toplevel).pixmap);
    }
    if (SpTopLevelArch(toplevel).font != NULL) {
	gdk_font_unref(SpTopLevelArch(toplevel).font);
    }
    if (SpTopLevelArch(toplevel).fg_gc != NULL) {
	gdk_gc_unref(SpTopLevelArch(toplevel).fg_gc);
    }
    if (SpTopLevelArch(toplevel).bg_gc != NULL) {
	gdk_gc_unref(SpTopLevelArch(toplevel).bg_gc);
    }
#if defined(HAVE_PTHREAD)
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	pthread_mutex_destroy(&sp_main_loop_mutex);
	pthread_mutex_destroy(&sp_thread_loop_mutex);
	pthread_mutex_destroy(&sp_thread_enter_mutex);
    }
#endif
    
    return;
}

void spQuitArch(int status)
{
    if (sp_gtk_main_loop_exist == SP_TRUE) {
	gtk_main_quit();
    }
    return;
}

int spWaitEventArch(spTopLevel toplevel)
{
    gtk_main_iteration_do(TRUE);
    
    return 1;
}

int spDispatchEventArch(spTopLevel toplevel)
{
    int flag = 0;
    
    while (gtk_events_pending() > 0) {
	spWaitEventArch(toplevel);
	flag = 1;
    }

    return flag;
}

void spMainQuitGtk(void)
{
    gtk_main_quit();
    
    return;
}

void spMainLoopGtk(void)
{
#if defined(HAVE_PTHREAD)
    if (g_thread_supported()) {
	if (pthread_self() != sp_main_thread_id) {
	    spDebug(30, "spMainLoopGtk", "main_loop_exist = %d\n", sp_gtk_main_loop_exist);
	    
	    /* prevent from going to next main loop of main thread */	
	    pthread_mutex_lock(&sp_thread_loop_mutex);
		
	    if (sp_gtk_main_loop_exist == SP_TRUE) {
		gtk_main_quit();
		gdk_flush();		/* flush current events */
		gdk_threads_leave();	/* leave thread for a while to go back to main thread */
		
		/* just waiting for finish of main loop of main thread */
		pthread_mutex_lock(&sp_main_loop_mutex);
		pthread_mutex_unlock(&sp_main_loop_mutex);
		
		gdk_threads_enter();	/* enter thread again */
	    }
	    spDebug(30, "spMainLoopGtk", "in thread: main entered\n");
	    gtk_main();
	    spDebug(30, "spMainLoopGtk", "in thread: main finished\n");
	    
	    /* now, go back to next main loop of main thread */
	    pthread_mutex_unlock(&sp_thread_loop_mutex);
	} else {
	    if (sp_gtk_main_loop_exist == SP_FALSE) {
		gdk_threads_enter();
	    }
	    gtk_main();
	    if (sp_gtk_main_loop_exist == SP_FALSE) {
		gdk_threads_leave();
	    }
	}
	return;
    }
#endif
    
    gtk_main();
    
    return;
}

int spMainLoopArch(spTopLevel toplevel)
{
    while (1) {
	spDebug(30, "spMainLoopArch", "loop start\n");
#if defined(HAVE_PTHREAD)
	if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	    pthread_mutex_lock(&sp_thread_enter_mutex);
	    pthread_mutex_unlock(&sp_thread_enter_mutex);
	    
	    /* waiting for finish of thread loop */
	    pthread_mutex_lock(&sp_thread_loop_mutex);
	    pthread_mutex_unlock(&sp_thread_loop_mutex);
	    
	    pthread_mutex_lock(&sp_main_loop_mutex);
	    
	    gdk_threads_enter();
	    spDebug(30, "spMainLoopArch", "main entered\n");
	    sp_gtk_main_loop_exist = SP_TRUE;
	    gtk_main();
	    sp_gtk_main_loop_exist = SP_FALSE;
	    gdk_threads_leave();
	    spDebug(30, "spMainLoopArch", "main quited\n");

	    pthread_mutex_unlock(&sp_main_loop_mutex);
	} else {
	    sp_gtk_main_loop_exist = SP_TRUE;
	    gtk_main();
	    sp_gtk_main_loop_exist = SP_FALSE;
	}
#else
	sp_gtk_main_loop_exist = SP_TRUE;
	gtk_main();
	sp_gtk_main_loop_exist = SP_FALSE;
#endif
    }
    
    return 0;
}

spBool spThreadEnterArch(spTopLevel toplevel)
{
#if defined(HAVE_PTHREAD)
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	if (pthread_self() != sp_main_thread_id) {
	    pthread_mutex_lock(&sp_thread_enter_mutex);
	}
	gdk_threads_enter();
	return SP_TRUE;
    }
#endif
    return SP_FALSE;
}

spBool spThreadLeaveArch(spTopLevel toplevel)
{
#if defined(HAVE_PTHREAD)
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	gdk_flush();
	gdk_threads_leave();
	if (pthread_self() != sp_main_thread_id) {
	    pthread_mutex_unlock(&sp_thread_enter_mutex);
	}
	return SP_TRUE;
    }
#endif
    return SP_FALSE;
}
