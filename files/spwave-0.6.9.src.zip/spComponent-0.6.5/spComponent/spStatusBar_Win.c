/*
 *	spStatusBar_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spStatusBarP.h>

extern spTopLevel sp_toplevel;

void spStatusBarPartInitArch(spComponent component)
{
    return;
}

void spStatusBarPartFreeArch(spComponent component)
{
    return;
}

void spStatusBarCreateArch(spComponent component, int *num_item)
{
    int i;
    int length;
    int num_part = 0;
    int parts[SP_MAX_STATUS_ITEM];
    
    /* create status bar */
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(0, STATUSCLASSNAME, NULL,
		       WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP | SBT_TOOLTIPS,
		       0, 0, 0, 0,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    
    if (SpStatusBarPart(component).item_sizes != NULL) {
	length = 0;
	for (i = 0; i < SP_MAX_STATUS_ITEM; i++) {
	    if (SpStatusBarPart(component).item_sizes[i] <= 0) {
		if (SpStatusBarPart(component).use_last_item == SP_TRUE
		    || i <= 0) {
		    SpStatusBarPart(component).use_last_item = SP_TRUE;
		    num_part = i + 1;
		} else {
		    num_part = i;
		}
		parts[i] = -1;
		break;
	    } else {
		length += SpStatusBarPart(component).item_sizes[i];
		parts[i] = length;
	    }
	}
    } else {
	parts[0] = -1;
	num_part = 1;
    }
    SendMessage(SpPrimitiveArch(component).hwnd, SB_SETPARTS,
		(WPARAM)num_part, (LPARAM)parts);
    *num_item = num_part;
    
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));
    
    return;
}

void spStatusBarSetParamsArch(spComponent component)
{
    return;
}

void spStatusBarDestroyArch(spComponent component)
{
    return;
}

spBool spSetStatusTextArch(spComponent component, int index, char *string)
{
    SendMessage(SpPrimitiveArch(component).hwnd, SB_SETTEXT,
		(WPARAM)(index | 0), (LPARAM)string);
    SendMessage(SpPrimitiveArch(component).hwnd, SB_SETTIPTEXT,
		(WPARAM)index, (LPARAM)string);

    return SP_TRUE;
}
