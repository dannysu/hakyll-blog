/*
 *	spButton_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spToolItemP.h>
#include <sp/spDrawP.h>
#include <sp/spTextP.h>
#include <sp/spFrameP.h>
#include <sp/spButtonP.h>

spBool spToggleComponentMac(spComponent component)
{
    spBool set;

    if (spIsToggleButton(component) == SP_FALSE) {
	return SP_FALSE;
    }

    if (spIsToolItem(component) == SP_TRUE) {
	spDebug(50, "spToggleComponentMac", "SpToolItemPart(component).set = %d\n",
		SpToolItemPart(component).set);
    
	SpToolItemPart(component).set =
	    ((SpToolItemPart(component).set == SP_TRUE) ? SP_FALSE : SP_TRUE);
	spSetToolItemToggleStateArch(component);
	return SP_TRUE;
    } else {
	spDebug(50, "spToggleComponentMac", "SpButtonPart(component).set = %d\n",
		SpButtonPart(component).set);
    
	if (spIsRadioButton(component) == SP_TRUE) {
	    set = SP_TRUE;
	} else {
	    set = ((SpButtonPart(component).set == SP_TRUE) ? SP_FALSE : SP_TRUE);
	}
	
	if (SpButtonPart(component).set != set) {
	    SpButtonPart(component).set = set;
	    if (spIsRadioButton(component) == SP_TRUE) {
		spCheckRadioButtonCB(component, NULL);
	    } else {
		spSetToggleStateArch(component);
	    }
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

void spDrawDefaultButtonMac(spComponent component)
{
#if !TARGET_API_MAC_CARBON
    Rect rect;
    GrafPtr save_port;
    
    if (spIsSubClass(component, SpPushButton) == SP_TRUE
	&& SpButtonPart(component).default_flag == SP_TRUE) {
	spDebug(70, "spDrawDefaultButtonMac", "draw default button\n");
	
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
	rect = SpPrimitiveArch(component).rect;
	
	PenSize(3,3);
	InsetRect(&rect, -4, -4);

	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	    spGetOriginalRGBMac();
	    spSetDeactivateRGBMac();
	    FrameRoundRect(&rect, 16,16);
	    spSetOriginalRGBMac();
	} else {
	    FrameRoundRect(&rect, 16,16);
	}
	
	PenNormal();
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    }
#endif
    
    return;
}

void spDrawButtonMac(spComponent component)
{
    spDrawControlMac(component);
    spDrawDefaultButtonMac(component);

    return;
}

spBool spPressButtonMac(spComponent component)
{
    unsigned long throw_away;

    spDebug(70, "spPressDefaultButtonMac", "in\n");
    
    if (spIsSubClass(component, SpPushButton) == SP_TRUE) {
	if (spIsAquaMac() == SP_FALSE) {
	    HiliteControl(SpPrimitiveArch(component).control, true);
	    Delay(8, &throw_away);
	    HiliteControl(SpPrimitiveArch(component).control, false);
	}
	
	return spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
    }

    return SP_FALSE;
}

void spButtonCreateArch(spComponent component)
{
    char label[SP_MAX_BUTTON_LABEL];
    Str255 pstr;
    Rect rect;
    spComponent window;

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	spGetMnemonic(SpComponentPart(component).title, label);
    } else {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
    }
    spStrCToP(label, pstr);

    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    rect = SpPrimitiveArch(component).rect;

    window = SpGetWindow(component);

    if (spIsSubClass(component, SpCheckBox)) {
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &rect, pstr, spIsVisibleMac(component), 0, 0, 1, checkBoxProc, 0);
    } else if (spIsSubClass(component, SpRadioButton)) {
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &rect, pstr, spIsVisibleMac(component), 0, 0, 1, radioButProc, 0);
    } else {
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &rect, pstr, spIsVisibleMac(component), 0, 0, 1, pushButProc, 0);
	
#if TARGET_API_MAC_CARBON
	if (SpButtonPart(component).default_flag == SP_TRUE) {
	    Boolean flag = true;
	    
	    SetControlData(SpPrimitiveArch(component).control,
			   kControlEntireControl, kControlPushButtonDefaultTag,
			   sizeof(Boolean), (Ptr)&flag);
	}
#endif
    }

    spSetReferenceMac(component);
    spSetNeedUpdateMac(component);
    spSetNeedMoveCallMac(component);
    
    return;
}

void spButtonSetParamsArch(spComponent component)
{
    Str255 pstr;
    char label[SP_MAX_BUTTON_LABEL];

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {
    	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    spStrCToP(label, pstr);
	    if (spEqClass(component, SpLabel) == SP_TRUE) {
#if TARGET_API_MAC_CARBON
		SetControlData(SpPrimitiveArch(component).control,
			       kControlEntireControl, kControlStaticTextTextTag,
			       pstr[0], (Ptr)&pstr[1]);
#endif
	    } else {
		SetControlTitle(SpPrimitiveArch(component).control, pstr);
	    }
	}
    }
    
    return;
}

void spSetToggleStateArch(spComponent component)
{
    if (SpPrimitiveArch(component).control != NULL) {
	SetControlValue(SpPrimitiveArch(component).control,
			(SpButtonPart(component).set == SP_TRUE ? 1 : 0));
    } else if (SpPrimitiveArch(component).menu_id > 0) {
	CheckMenuItem(SpParentPrimitiveArch(component).menu,
		      SpPrimitiveArch(component).menu_id,
		      (SpButtonPart(component).set == SP_TRUE ? true : false));
    }
    
    return;
}

void spGetToggleStateArch(spComponent component)
{
    return;
}
