/*
 *	spLocale_Mac.c
 */

#if defined(MACOSX)
#include <Carbon/Carbon.h>
#include <locale.h>
#else
#include <Script.h>
#endif

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>

void spSetLanguageArch(char *lang, char *o_lang)
{
#if defined(MACOSX)
    if ((lang = getenv("LANG")) != NULL	&& spSupportLocale(lang) == SP_TRUE) {
	spDebug(10, "spSetLanguageArch", "getenv: lang = %s\n", lang);

	if (spIsJapaneseLang(lang) == SP_TRUE) {
	    strcpy(o_lang, "ja_JP.SJIS");
	} else {
	    strcpy(o_lang, lang);
	}
	spDebug(10, "spSetLanguageArch", "o_lang = %s\n", o_lang);
	return;
    }
#endif

    if (GetScriptVariable(smSystemScript, smScriptLang) == langJapanese
	/*GetScriptVariable(smJapanese,smScriptEnabled) != 0*/
	&& (strnone(lang) || spIsJapaneseLang(lang) == SP_TRUE)) {
	strcpy(o_lang, "ja_JP.SJIS");
    } else {
	strcpy(o_lang, "C");
    }
    
    return;
}

