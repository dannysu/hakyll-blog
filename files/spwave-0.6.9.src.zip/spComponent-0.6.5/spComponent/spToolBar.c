/*
 *	spToolBar.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spList.h>

#include <sp/spFrameP.h>
#include <sp/spContainerP.h>
#include <sp/spToolItemP.h>
#include <sp/spToolBarP.h>

static spParamTable sp_tool_bar_param_tables[] = {
    {SppNumBitmap, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolBar, tool_bar.num_bitmap), "0"},
    {SppBitmapWidth, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolBar, tool_bar.bitmap_width), "16"},
    {SppBitmapHeight, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolBar, tool_bar.bitmap_height), "16"},
    {SppBitmapPathEnv, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolBar, tool_bar.bitmap_path_env), NULL},
    /* only for X version */
    {SppBitmapData, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolBar, tool_bar.bitmap_data), NULL},
};

spToolBarClassRec SpToolBarClassRec = {
    /* spObjectClassPart */
    {
	SpToolBar,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spToolBarRec),
	spArraySize(sp_tool_bar_param_tables),
	sp_tool_bar_param_tables,
	spToolBarPartInit,
	spToolBarPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spToolBarCreate,
	spToolBarDestroy,
	spToolBarSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE/*SP_FALSE*/,
	SP_FALSE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spToolBarClassPart */
    {
	0,
    },
};

spComponentClass SpToolBarClass = (spComponentClass)&SpToolBarClassRec;

void spToolBarPartInit(spObject object)
{
    spComponent component = (spComponent)object;

    SpComponentPart(component).margin_width = SP_DEFAULT_TOOL_ITEM_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_TOOL_ITEM_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_TOOL_ITEM_SPACING;
    
    SpToolBarPart(component).current_index = 0;
    SpToolBarPart(component).bitmap_path_env = NULL;
    SpToolBarPart(component).bitmap_data = NULL;
    
    spToolBarPartInitArch(component);

    return;
}

void spToolBarPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spToolBarPartFreeArch(component);
    
    return;
}

void spToolBarCreate(spObject object)
{
    spComponent component = (spComponent)object;
    spComponent window;
    
    if (component == NULL) return;

    SpComponentPart(component).orientation = SP_HORIZONTAL;
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    SpComponentPart(component).width = 0;
    SpComponentPart(component).height = SpToolBarPart(component).bitmap_height
	+ 8 + 2 * SpComponentPart(component).margin_height;
    /*SpComponentPart(component).height = SpToolBarPart(component).bitmap_height + 12;*/
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;
    
    if ((window = SpGetWindow(component)) != NULL && spIsFrame(window) == SP_TRUE) {
	SpFramePart(window).tool_bar = component;
    }
	
    spToolBarCreateArch(component);
    
    return;
}

void spToolBarSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spToolBarSetParamsArch(component);
	
    return;
}

void spToolBarDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spToolBarDestroyArch(component);
    spPrimitiveDestroyArch(component);

    return;
}

spBool spIsToolBar(spComponent component)
{
    return spIsSubClass(component, SpToolBar);
}

spComponent spCreateToolBar(spComponent parent, char *name, int num_bitmap, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsWindow(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, num_bitmap);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetArg(args[num_arg], SppNumBitmap, num_bitmap); num_arg++;

    return spCreateComponentArg(SpToolBarClass, NULL, name, parent, args, num_arg);
}
