/*
 *	spLabel.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>

#include <sp/spLabelP.h>

static spParamTable sp_label_param_tables[] = {
    {SppAlignment, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spLabel, label.alignment), SP_ALIGNMENT_CENTER_STRING},
};

spLabelClassRec SpLabelClassRec = {
    /* spObjectClassPart */
    {
	SpLabel,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spLabelRec),
	spArraySize(sp_label_param_tables),
	sp_label_param_tables,
	spLabelPartInit,
	spLabelPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spLabelCreate,
	NULL,
	spLabelSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spLabelClassPart */
    {
	0,
    },
};

spComponentClass SpLabelClass = (spComponentClass)&SpLabelClassRec;

void spLabelPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).spacing_flag = SP_TRUE;

    return;
}

void spLabelPartFree(spObject object)
{
    return;
}

void spLabelCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spPrimitiveSetDefaultSize(component);
    spLabelCreateArch(component);

#if 0
    if (spIsCreated(component) == SP_FALSE) {
	spShowToolTip(component);
    }
#endif
    
    return;
}

void spLabelSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spLabelSetParamsArch(component);

    return;
}

spBool spIsLabel(spComponent component)
{
    return spIsSubClass(component, SpLabel);
}

spComponent spCreateLabel(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;

    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpLabelClass, SpLabel, name, parent, args, num_arg);
}
