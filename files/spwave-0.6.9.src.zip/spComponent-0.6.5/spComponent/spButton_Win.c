/*
 *	spButton_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spButtonP.h>

extern spTopLevel sp_toplevel;

void spButtonCreateArch(spComponent component)
{
    char *title;

    title = SpComponentPart(component).title;
    
    if (title == NULL) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    if (spIsSubClass(component, SpCheckBox)) {
	SpPrimitiveArch(component).hwnd =
	    CreateWindow("BUTTON", title,
			 BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
			 SpComponentPart(component).x, SpComponentPart(component).y,
			 SpComponentPart(component).current_width,
			 SpComponentPart(component).current_height,
			 SpParentPrimitiveArch(component).hwnd,
			 (HMENU)SpComponentPart(component).component_id,
			 SpTopLevelArch(sp_toplevel).hThisInst,
			 NULL);
    } else if (spIsSubClass(component, SpRadioButton)) {
	SpPrimitiveArch(component).hwnd =
	    CreateWindow("BUTTON",
			 title,
			 BS_RADIOBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
			 SpComponentPart(component).x, SpComponentPart(component).y,
			 SpComponentPart(component).current_width,
			 SpComponentPart(component).current_height,
			 SpParentPrimitiveArch(component).hwnd,
			 (HMENU)SpComponentPart(component).component_id,
			 SpTopLevelArch(sp_toplevel).hThisInst,
			 NULL);
    } else {
	SpPrimitiveArch(component).hwnd =
	    CreateWindow("BUTTON",
			 title,
			 BS_PUSHBUTTON | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
			 SpComponentPart(component).x, SpComponentPart(component).y,
			 SpComponentPart(component).current_width,
			 SpComponentPart(component).current_height,
			 SpParentPrimitiveArch(component).hwnd,
			 (HMENU)SpComponentPart(component).component_id,
			 SpTopLevelArch(sp_toplevel).hThisInst,
			 NULL);
    }
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));

    if (spIsRadioButton(component) == SP_TRUE) {
	spAddRadioGroup(component, SpButtonPart(component).radio_end);
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK, spCheckRadioButtonCB, NULL);
    }

    return;
}

void spButtonSetParamsArch(spComponent component)
{
    char *title;
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;

	if (title != NULL) {
	    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
			(WPARAM)0, (LPARAM)(LPCTSTR)title);
	}
    }
    
    return;
}

void spSetToggleStateArch(spComponent component)
{
    if (SpPrimitiveArch(component).hwnd != NULL) {
	SendMessage(SpPrimitiveArch(component).hwnd, BM_SETCHECK,
		    (SpButtonPart(component).set == SP_TRUE ? 1 : 0), 0);
    } else {
#if 1
	CheckMenuItem(SpParentPrimitiveArch(component).hmenu,
		      (UINT)SpComponentPart(component).component_id,
		      MF_BYCOMMAND
		      | (SpButtonPart(component).set == SP_TRUE ? MF_CHECKED : MF_UNCHECKED));
#else
	MENUITEMINFO minfo;
	
	minfo.cbSize = sizeof(minfo);
	minfo.fMask = MIIM_STATE;
	if (GetMenuItemInfo(SpParentPrimitiveArch(component).hmenu,
			    (UINT)SpComponentPart(component).component_id,
			    FALSE, &minfo)) {
	    if (SpButtonPart(component).set == SP_TRUE) {
		minfo.fState &= ~MFS_UNCHECKED;
		minfo.fState |= MFS_CHECKED;
	    } else {
		minfo.fState &= ~MFS_CHECKED;
		minfo.fState |= MFS_UNCHECKED;
	    }
	    
	    minfo.cbSize = sizeof(minfo);
	    minfo.fMask = MIIM_STATE;
	    SetMenuItemInfo(SpParentPrimitiveArch(component).hmenu,
			    (UINT)SpComponentPart(component).component_id,
			    FALSE, &minfo);
	}
#endif
	spDebug(50, "spSetToggleStateArch", "%s: set: %d\n",
		spGetTitle(component), SpButtonPart(component).set);
    }

    return;
}

void spGetToggleStateArch(spComponent component)
{
    spBool lset;
    
    if (SpPrimitiveArch(component).hwnd != NULL) {
	if (SendMessage(SpPrimitiveArch(component).hwnd, BM_GETCHECK, 0, 0)) {
	    lset = SP_TRUE;
	} else {
	    lset = SP_FALSE;
	}
    } else {
	if (GetMenuState(SpParentPrimitiveArch(component).hmenu,
			 (UINT)SpComponentPart(component).component_id,
			 MF_BYCOMMAND) & MF_CHECKED) {
	    lset = SP_TRUE;
	} else {
	    lset = SP_FALSE;
	}
    }
    SpButtonPart(component).set = lset;
    
    return;
}
