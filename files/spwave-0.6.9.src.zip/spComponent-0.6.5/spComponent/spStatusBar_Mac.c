/*
 *	spStatusBar_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spStatusBarP.h>

void spDrawStatusBarMac(spComponent component)
{
#if 1
    int i;
    int x, y;
    int width, height;
    spBool sensitive_flag = SP_TRUE;
    Rect rect;
    GrafPtr save_port;

    if (spIsCreated(component) == SP_FALSE) return;

    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    
    rect = SpPrimitiveArch(component).rect;
    EraseRect(&rect);

    if (SpPrimitiveArch(component).map_flag == SP_TRUE) {
	spDebug(10, "spDrawStatusBarMac", "top = %d, bottom = %d\n",
		rect.top, rect.bottom);
	
	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	    sensitive_flag = SP_FALSE;
	    spGetOriginalRGBMac();
	    spSetDeactivateRGBMac();
	}
	
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top + 1;
	height = SP_DEFAULT_SLIDER_WIDTH;
	
	for (i = 0;; i++) {
	    if ((width = spGetStatusItemSize(component, i)) < 0) {
		break;
	    }
	    spDebug(10, "spDrawStatusBarMac", "i = %d, width = %d\n", i, width);
	    
	    if (width <= 0) {
		width = SpPrimitiveArch(component).rect.right - x;
	    }
	    
	    if (spGetAppearanceVersionMac() >= 0x00000101) {
		SetRect(&rect, x, y, x + width + 1, y + height);
		if (sensitive_flag == SP_FALSE) {
		    DrawThemePlacard(&rect, kThemeStateInactive);
		} else {
		    DrawThemePlacard(&rect, kThemeStateActive);
		}
	    } else {
		/* draw separator */
		if (i > 0) {
		    MoveTo(x, y);
		    LineTo(x, y + height);
		}
	    }
	    
	    /* draw string */
	    if (SpStatusBarArch(component).labels != NULL) {
		if (!strnone(SpStatusBarArch(component).labels[i])) {
		    MoveTo(x + 4, y + SP_DEFAULT_SLIDER_WIDTH - 4);
		    DrawText(SpStatusBarArch(component).labels[i], 0,
			     strlen(SpStatusBarArch(component).labels[i]));
		}
	    }
	    
	    x += width;
	}
	
	if (!(spGetAppearanceVersionMac() >= 0x00000101)) {
	    MoveTo(SpPrimitiveArch(component).rect.left, y);
	    LineTo(SpPrimitiveArch(component).rect.right, y);
	}

	if (sensitive_flag == SP_FALSE) {
	    spSetOriginalRGBMac();
	}
	
	spDebug(10, "spDrawStatusBarMac", "finished: x = %d, y = %d\n", x, y);
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
#endif
    
    return;
}

void spStatusBarPartInitArch(spComponent component)
{
    SpStatusBarArch(component).labels = NULL;
    
    return;
}

void spStatusBarPartFreeArch(spComponent component)
{
    return;
}

void spStatusBarCreateArch(spComponent component, int *num_item)
{
    int i;
    int item_size;

    for (i = 0;; i++) {
	if ((item_size = spGetStatusItemSize(component, i)) < 0) {
	    break;
	}
    }
    *num_item = i;

    SpStatusBarArch(component).labels = xalloc(*num_item, char *);
    for (i = 0; i < *num_item; i++) {
	SpStatusBarArch(component).labels[i] = NULL;
    }

    spSetNeedUpdateMac(component);
    return;
}

void spStatusBarSetParamsArch(spComponent component)
{
    return;
}

void spStatusBarDestroyArch(spComponent component)
{
    int i;
    
    if (SpStatusBarArch(component).labels != NULL) {
	for (i = 0; i < SpStatusBarPart(component).num_item; i++) {
	    if (SpStatusBarArch(component).labels[i] != NULL) {
		xfree(SpStatusBarArch(component).labels[i]);
	    }
	}
	xfree(SpStatusBarArch(component).labels);
	SpStatusBarArch(component).labels = NULL;
    }
    
    return;
}

spBool spSetStatusTextArch(spComponent component, int index, char *string)
{
    spComponent window;
    
    if (SpStatusBarArch(component).labels[index] != NULL) {
	xfree(SpStatusBarArch(component).labels[index]);
    }
    SpStatusBarArch(component).labels[index] = strclone(string);
    spDrawStatusBarMac(component);
    
    window = SpGetWindow(component);
    if (SpFramePart(window).resize_flag == SP_TRUE) {
	spDrawGrowIconMac(SpPrimitiveArch(window).window);
    }
    
    return SP_TRUE;
}
