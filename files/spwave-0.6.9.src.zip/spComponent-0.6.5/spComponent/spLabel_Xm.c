/*
 *	spLabel_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLabelP.h>

void spLabelCreateArch(spComponent component)
{
    char *title = NULL;
    XmString xmstr;
    int narg = 0;
    Arg args[10];

    title = SpComponentPart(component).title;
    
    if (SpLabelPart(component).alignment == SP_ALIGNMENT_BEGINNING) {
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_BEGINNING); narg++;
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_CENTER); narg++;
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_END); narg++;
    }
    
    SpPrimitiveArch(component).widget = XtCreateManagedWidget((!strnone(SpGetName(component))
							       ? SpGetName(component) : ""),
							      xmLabelWidgetClass,
							      SpParentPrimitiveArch(component).widget,
							      args, narg);

    if (!strnone(title)) {
	xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNlabelString, xmstr, NULL);
	XmStringFree(xmstr);
    }

    return;
}

void spLabelSetParamsArch(spComponent component)
{
    char *title = NULL;
    XmString xmstr;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;
	
	if (!strnone(title)) {
	    xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	    XtVaSetValues(SpPrimitiveArch(component).widget, XmNlabelString, xmstr, NULL);
	    XmStringFree(xmstr);
	}
    }

    return;
}
