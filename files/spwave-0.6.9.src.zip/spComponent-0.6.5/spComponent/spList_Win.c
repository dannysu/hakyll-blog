/*
 *	spList_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spComboBoxP.h>

extern spTopLevel sp_toplevel;

void spListCreateArch(spComponent component)
{
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(WS_EX_CLIENTEDGE, "LISTBOX",
		       (!strnone(SpGetName(component))
			? SpGetName(component) : ""),
		       WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_TABSTOP |
		       WS_VSCROLL | LBS_NOTIFY | LBS_DISABLENOSCROLL,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComponentPart(component).current_height,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));
    
    SpObjectPart(component).create_flag = SP_TRUE;
    
    return;
}

void spListSetParamsArch(spComponent component)
{
    return;
}

void spListGetParamsArch(spComponent component)
{
    spGetSelectedListIndex(component);
    return;
}

int spAddListItemArch(spComponent component, char *item)
{
    int index;
    
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_ADDSTRING : LB_ADDSTRING),
			(WPARAM)0, (LPARAM)(LPCTSTR)item);
    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

int spAddListIndexArch(spComponent component, char *item, int index)
{
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_INSERTSTRING : LB_INSERTSTRING),
			(WPARAM)index, (LPARAM)(LPCTSTR)item);
    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

int spDeleteListItemArch(spComponent component, char *item)
{
    int index;
    
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ?
			 CB_FINDSTRINGEXACT : LB_FINDSTRINGEXACT),
			(WPARAM)-1, (LPARAM)(LPCTSTR)item);
    if (index >= 0
	&& SendMessage(SpPrimitiveArch(component).hwnd,
		       (spIsComboBox(component) == SP_TRUE ? CB_DELETESTRING : LB_DELETESTRING),
		       (WPARAM)index, (LPARAM)0) >= 0) {
	return index;
    } else {
	return -1;
    }
}

int spDeleteListIndexArch(spComponent component, int index)
{
    if (index >= 0) {
	if (SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_DELETESTRING : LB_DELETESTRING),
			(WPARAM)index, (LPARAM)0) >= 0) {
	    return index;
	}
    }
    
    return -1;
}

int spFindListItemArch(spComponent component, char *item)
{
    int index;
    
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ?
			 CB_FINDSTRINGEXACT : LB_FINDSTRINGEXACT),
			(WPARAM)-1, (LPARAM)(LPCTSTR)item);
    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

int spSelectListItemArch(spComponent component, char *item)
{
    int index;
    
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_SELECTSTRING: LB_SELECTSTRING),
			(WPARAM)-1, (LPARAM)(LPCTSTR)item);

    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

int spSelectListIndexArch(spComponent component, int index)
{
    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_SETCURSEL: LB_SETCURSEL),
			(WPARAM)index, (LPARAM)0);

    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

char *xspGetSelectedListItemArch(spComponent component)
{
    int index;
    char string[SP_MAX_LINE];
    char *item = NULL;

    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_GETCURSEL : LB_GETCURSEL),
			(WPARAM)0, (LPARAM)0);
    if (index >= 0) {
	SendMessage(SpPrimitiveArch(component).hwnd,
		    (spIsComboBox(component) == SP_TRUE ? CB_GETLBTEXT: LB_GETTEXT),
		    (WPARAM)index, (LPARAM)(LPCTSTR)string);
	item = strclone(string);
	return item;
    }
    
    return NULL;
}

int spGetSelectedListIndexArch(spComponent component)
{
    int index;

    index = SendMessage(SpPrimitiveArch(component).hwnd,
			(spIsComboBox(component) == SP_TRUE ? CB_GETCURSEL : LB_GETCURSEL),
			(WPARAM)0, (LPARAM)0);
    if (index >= 0) {
	return index;
    } else {
	return -1;
    }
}

