/*
 *	spCanvas.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>

#include <sp/spDraw.h>

#include <sp/spCanvasP.h>

static spParamTable sp_canvas_param_tables[] = {
    {SppBorderOn, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spCanvas, canvas.border_on), SP_FALSE_STRING},
    {SppFocusable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spCanvas, canvas.focusable), SP_FALSE_STRING},
    {SppDrawBackground, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spCanvas, canvas.draw_background), SP_FALSE_STRING},
    {SppUseTabKey, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spCanvas, canvas.use_tab_key), SP_FALSE_STRING},
    {SppUseArrowKey, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spCanvas, canvas.use_arrow_key), SP_FALSE_STRING},
};

spCanvasClassRec SpCanvasClassRec = {
    /* spObjectClassPart */
    {
	SpCanvas,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spCanvasRec),
	spArraySize(sp_canvas_param_tables),
	sp_canvas_param_tables,
	spCanvasPartInit,
	spCanvasPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spCanvasCreate,
	spCanvasDestroy,
	spCanvasSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spCanvasClassPart */
    {
	0,
    },
};

spComponentClass SpCanvasClass = (spComponentClass)&SpCanvasClassRec;

void spCanvasPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;
    
    SpCanvasPart(component).prev_width = 0;
    SpCanvasPart(component).prev_height = 0;
    SpCanvasPart(component).capture_flag = SP_FALSE;
    SpCanvasPart(component).size = 0;

    return;
}

void spCanvasPartFree(spObject object)
{
    return;
}

void spExposeCanvasCB(spComponent component, void *data)
{
    spDebug(50, "spExposeCanvasCB", "canvas exposed\n");
    
    if (spIsCreated(component) == SP_TRUE) {
	if (spIsCanvasExposed(component) == SP_FALSE) {
	    spDebug(30, NULL, "first exposure\n");
	    
	    spExposeCanvasCBArch(component);

	    /* get canvas size */
	    spGetSize(component, NULL, NULL);
	    
	    /* draw canvas */
	    spRedrawCanvas(component);
	} else {
	    spGetSize(component, NULL, NULL);
	    
	    if (SpCanvasPart(component).prev_width != SpComponentPart(component).client_width
		|| SpCanvasPart(component).prev_height != SpComponentPart(component).client_height) {
		
		spRedrawCanvas(component);
	    } else {
		/* refresh canvas */
		spRefreshCanvas(component);
	    }
	}
	SpCanvasPart(component).prev_width = SpComponentPart(component).client_width;
	SpCanvasPart(component).prev_height = SpComponentPart(component).client_height;
    }
	    
    spDebug(50, "spExposeCanvasCB", "done\n");
    
    return;
}

void spResizeCanvasCB(spComponent component, void *data)
{
    spDebug(30, "spResizeCanvasCB", "window resized\n");
    
    if (spIsCreated(component) == SP_TRUE) {
	spGetSize(component, NULL, NULL);
	spRedrawCanvas(component);
    }
    
    spDebug(30, "spResizeCanvasCB", "done\n");
    
    return;
}

void spCanvasCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spCanvasSetDefaultSize(component);
    spCanvasCreateArch(component);
	 
    if (SpComponentPart(component).call_func != NULL) {
	SpPrimitivePart(component).draw_func = SpComponentPart(component).call_func;
	SpPrimitivePart(component).draw_data = SpComponentPart(component).call_data;
    }

    spAddCallback(component, SP_EXPOSE_CALLBACK, spExposeCanvasCB, NULL);

    return;
}

void spCanvasSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spCanvasSetParamsArch(component);
	 
    return;
}

void spCanvasDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spCanvasDestroyArch(component);
	 
    return;
}

void spCanvasSetDefaultSize(spComponent component)
{
    if (spIsSubClass(component, SpCanvas) == SP_FALSE) return;

    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;

    return;
}

spBool spIsCanvasExposed(spComponent component)
{
    if (spIsCanvas(component) == SP_FALSE) return SP_FALSE;

    return spIsCanvasExposedArch(component);
}

spBool spIsCanvas(spComponent component)
{
    return spIsSubClass(component, SpCanvas);
}

spComponent spCreateCanvas(spComponent parent, char *name,
			   int canvas_width, int canvas_height, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, canvas_height);
    spGetArgs(argp, args, num_arg);
    va_end(argp);
    
    spSetArg(args[num_arg], SppInitialWidth, canvas_width); num_arg++;
    spSetArg(args[num_arg], SppInitialHeight, canvas_height); num_arg++;

    return spCreateComponentArg(SpCanvasClass, NULL, name, parent, args, num_arg);
}

void spRefreshCanvas(spComponent component)
{
    if (spIsDrawable(component) == SP_FALSE || spIsCanvas(component) == SP_FALSE
 	|| (SpComponentPart(component).client_width <= 0 || SpComponentPart(component).client_height <= 0))
	return;
    
    spDebug(50, "spRefreshCanvas", "width = %d, height = %d\n", 
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);
 
    spRefreshCanvasArch(component);
    
    return;
}

void spRedrawCanvas(spComponent component)
{
    if (spIsPrimitive(component) == SP_FALSE
	|| (SpComponentPart(component).client_width <= 0 
	    || SpComponentPart(component).client_height <= 0))
	return;
    
    spDebug(30, "spRedrawCanvas", "client_width = %d, client_height = %d\n",
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);

    spRedrawCanvasArch(component);

    spDrawImage(component);
    spRefreshCanvas(component);

    return;
}

spBool spSetCanvasCapture(spComponent component, spBool flag)
{
    if (spIsCreated(component) == SP_FALSE
	|| spIsCanvas(component) == SP_FALSE) return SP_FALSE;

    SpCanvasPart(component).capture_flag = flag;

    return spSetCanvasCaptureArch(component);
}

spBool spSetCanvasCursor(spComponent component, spCursor cursor)
{
    if (spIsCreated(component) == SP_FALSE
	|| spIsCanvas(component) == SP_FALSE) {
	return SP_FALSE;
    }
    if (cursor == NULL) {
	return spUnsetCanvasCursor(component);
    }

    return spSetCanvasCursorArch(component, cursor);
}

spBool spUnsetCanvasCursor(spComponent component)
{
    if (spIsCreated(component) == SP_FALSE
	|| spIsCanvas(component) == SP_FALSE) {
	return SP_FALSE;
    }

    return spUnsetCanvasCursorArch(component);
}

spBool spIsCanvasFocused(spComponent component)
{
    if (spIsCreated(component) == SP_FALSE
	|| spIsCanvas(component) == SP_FALSE
	|| SpCanvasPart(component).focusable == SP_FALSE) return SP_FALSE;

    return spIsCanvasFocusedArch(component);
}
