/*
 *	spLabel_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spLabelP.h>

extern spTopLevel sp_toplevel;

void spLabelCreateArch(spComponent component)
{
    char *title = NULL;

    title = SpComponentPart(component).title;
    
    if (title == NULL) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    SpPrimitiveArch(component).hwnd =
	CreateWindow("STATIC", title,
		     (SpLabelPart(component).alignment == SP_ALIGNMENT_END ? SS_RIGHT :
		      (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER ? SS_CENTER:
		       SS_LEFTNOWORDWRAP)) | WS_CHILD | WS_VISIBLE,
		     SpComponentPart(component).x, SpComponentPart(component).y,
		     SpComponentPart(component).current_width,
		     SpComponentPart(component).current_height,
		     SpParentPrimitiveArch(component).hwnd,
		     (HMENU)SpComponentPart(component).component_id,
		     SpTopLevelArch(sp_toplevel).hThisInst,
		     NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));
    
    return;
}

void spLabelSetParamsArch(spComponent component)
{
    char *title = NULL;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;
    
	if (title != NULL) {
	    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
			(WPARAM)0, (LPARAM)(LPCTSTR)title);
	}
    }

    return;
}
