/*
 *	spLocale_Win.c
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>

void spSetLanguageArch(char *lang, char *o_lang)
{
#ifdef __CYGWIN32__
    if (!strnone(lang)) {
	sscanf(lang, "%s", o_lang);
    } else {
	if ((lang = getenv("LANG")) != NULL) {
	    sscanf(lang, "%s", o_lang);
	} else {
	    sscanf(setlocale(LC_ALL, NULL), "%s", o_lang);
	}
    }
#else
    if (!strnone(lang)) {
	if (setlocale(LC_ALL, lang) == NULL) {
	    spWarning("locale not supported by C library, locale unchanged\n");
	}
    } else {
	if ((lang = getenv("LANG")) != NULL) {
	    if (setlocale(LC_ALL, lang) == NULL) {
		spWarning("locale not supported by C library, locale unchanged\n");
	    }
	} else {
	    if (setlocale(LC_ALL, "") == NULL) {
		spWarning("locale not supported by C library, locale unchanged\n");
	    }
	}
    }
    sscanf(setlocale(LC_ALL, NULL), "%s", o_lang);
#endif
    
    if (strnone(o_lang) || spSupportLocale(o_lang) == SP_FALSE) {
	spWarning("locale not supported, locale set to C\n");
	sscanf(setlocale(LC_ALL, "C"), "%s", o_lang);
    }
    
    return;
}

