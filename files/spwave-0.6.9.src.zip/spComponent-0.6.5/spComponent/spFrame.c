/*
 *	spFrame.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spTopLevel.h>
#include <sp/spPrimitive.h>
#include <sp/spDialog.h>

#include <sp/spFrameP.h>

static spParamTable sp_frame_param_tables[] = {
    {SppIconName, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.icon_name), ""},
    {SppTaskTrayIcon, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.task_tray_icon), ""},
    {SppTaskTrayTip, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.task_tray_tip), ""},
    {SppWindowType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.window_type), SP_NORMAL_WINDOW_STRING},
    {SppPopupStyle, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.popup_style), SP_MODELESS_POPUP_STRING},
    {SppCloseStyle, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.close_style), NULL},
    {SppResizable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.resize_flag), SP_TRUE_STRING},
    {SppIconfiable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.iconfy_flag), SP_TRUE_STRING},
    {SppSimplifiable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.simplify_flag), SP_FALSE_STRING},
    {SppTaskTrayVisible, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.task_tray_visible), SP_FALSE_STRING},
    {SppInternalWindow, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.internal_flag), SP_FALSE_STRING},
    {SppParentWindow, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spFrame, frame.parent_window), NULL},
};

spFrameClassRec SpFrameClassRec = {
    /* spObjectClassPart */
    {
	SpFrame,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spFrameRec),
	spArraySize(sp_frame_param_tables),
	sp_frame_param_tables,
	spFramePartInit,
	spFramePartFree,
	SP_FALSE,
	NULL,
	NULL,
	spFrameCreate,
	spFrameDestroy,
	spFrameSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_TRUE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spFrameClassPart */
    {
	0,
    },
};

spComponentClass SpFrameClass = (spComponentClass)&SpFrameClassRec;

void spFramePartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;
    SpComponentPart(component).visible_flag = SP_FALSE;

    SpFramePart(component).menu_bar = NULL;
    SpFramePart(component).tool_bar = NULL;
    SpFramePart(component).status_bar = NULL;
    SpFramePart(component).task_tray_menu = NULL;
    SpFramePart(component).default_button = NULL;
    SpFramePart(component).cancel_button = NULL;
    SpFramePart(component).parent_window = NULL;
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE) {
	SpFramePart(component).close_style = SP_DESTROY_CLOSE;
    } else {
	SpFramePart(component).close_style = SP_NO_CLOSE;
    }

    spFramePartInitArch(component);
    
    return;
}

void spFramePartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spFramePartFreeArch(component);
    return;
}

void spFrameCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spDebug(30, "spFrameCreate", "in\n");
    
    spPrimitiveSetDefaultSize(component);
    spFrameCreateArch(component);
    
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_CLOSE_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }

    return;
}

void spFrameDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spDebug(30, "spFrameDestroy", "in\n");

    spFrameDestroyArch(component);
    spPrimitiveDestroyArch(component);

    return;
}

void spFrameSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spDebug(30, "spFrameSetParams", "in\n");
    
    spFrameSetParamsArch(component);

    return;
}

spBool spIsFrame(spComponent component)
{
    if (spIsSubClass(component, SpFrame) == SP_TRUE
	|| spIsSubClass(component, SpMainFrame) == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spComponent spCreateFrame(char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsTopLevelCreated() == SP_FALSE) spError(1, "spInitialize should be called.\n");
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spDebug(60, "spCreateFrame", "spGetArgs done\n");
    
    return spCreateComponentArg(SpFrameClass, SpFrame, name, NULL, args, num_arg);
}

spComponent spCreateMainFrame(char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsTopLevelCreated() == SP_FALSE) spError(1, "spInitialize should be called.\n");
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpFrameClass, SpMainFrame, name, NULL, args, num_arg);
}

spBool spAddDropCallback(spComponent component, spDropCallbackFunc call_func, void *call_data)
{
    if (spIsFrame(component) == SP_FALSE || call_func == NULL) return SP_FALSE;
    
    return spAddDropCallbackArch(component, call_func, call_data);
}

void spAddFrameCallback(spComponent component, spDrawFunc draw_func,
			spMouseFunc mouse_func, spKeyFunc key_func,
			spForegroundFunc foreground_func, spBackgroundFunc background_func, 
			void *data)
{
#if defined(MACOS)
    if (spIsFrame(component) == SP_FALSE) return;
    
    spAddFrameCallbackMac(component, draw_func, mouse_func, key_func,
			  foreground_func, background_func, data);
#endif
    return;
}
