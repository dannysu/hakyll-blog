/*
 *	spCanvas_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spCanvasP.h>

void spDrawCanvasMac(spComponent component)
{
    Rect rect;
    
#ifdef SP_DRAW_CANVAS_BORDER
    if (SpCanvasPart(component).border_on == SP_TRUE) {
	if (spGetAppearanceVersionMac() >= 0x00000101) {
	    GrafPtr save_port;

	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
	    rect = SpPrimitiveArch(component).rect;
	    InsetRect(&rect, -SP_CANVAS_BORDER, -SP_CANVAS_BORDER);

	    spDebug(10, "spDrawCanvasMac", "draw border\n");

	    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
		|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
		DrawThemeSecondaryGroup(&rect, kThemeStateInactive);
	    } else {
		DrawThemeSecondaryGroup(&rect, kThemeStateActive);
	    }

	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	}
    }
#endif

    return;
}

spMouseButton spGetPressedMouseButtonMac(short modifiers)
{
    spMouseButton button = SP_LBUTTON;
    
    if ((controlKey & modifiers) != 0
	|| (rightControlKey & modifiers) != 0) {	/* control key down */
	button = SP_RBUTTON;
    } else if ((optionKey & modifiers) != 0
	       || (rightOptionKey & modifiers) != 0) {	/* option key down */
	button = SP_MBUTTON;	
    }

    return button;
}

spBool spHandleCanvasMouseMac(spComponent component, int button_id, Point point,
			      short modifiers, spBool pressed)
{
    spCallbackType call_type;
    spCallbackReason call_reason;
    spMouseButton button;
    GrafPtr save_port;
    static spComponent pressed_canvas = NULL;
    
    if (spIsCanvas(component) == SP_TRUE) {
	if (pressed == SP_TRUE) {
	    spComponent window;
	    Point gpoint;
	
	    window = SpGetWindow(component);
	    if (SpFramePart(window).window_type == SP_TRANSIENT_WINDOW) {
		spSelectMenuBarMac(window, NULL);
	    
		gpoint = point;
		spLockWindowPort(SpPrimitiveArch(window).window, &save_port);
		LocalToGlobal(&gpoint);
		spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);
		spDragWindowMac(SpPrimitiveArch(window).window, gpoint);

		return SP_TRUE;
	    }
	
	    spFocusComponentMac(window, component);
	    
	    pressed_canvas = component;
	} else {
	    if (component != pressed_canvas) {
		return SP_FALSE;
	    }
	    pressed_canvas = NULL;
	}
	
	if (pressed == SP_TRUE) {
	    SpFrameArch(SpGetWindow(component)).key_send_component = component;	
	}
    }
    
    if (button_id > 1) {
	button = button_id - 1;
    } else {
	button = spGetPressedMouseButtonMac(modifiers);
    }
    
    if (button == SP_RBUTTON) {
	call_reason = (pressed == SP_TRUE ? SP_CR_RBUTTON_PRESS : SP_CR_RBUTTON_RELEASE);
    } else if (button == SP_MBUTTON) {
	call_reason = (pressed == SP_TRUE ? SP_CR_MBUTTON_PRESS : SP_CR_MBUTTON_RELEASE);
    } else {
	call_reason = (pressed == SP_TRUE ? SP_CR_LBUTTON_PRESS : SP_CR_LBUTTON_RELEASE);
    }
    call_type = (pressed == SP_TRUE ? SP_BUTTON_PRESS_CALLBACK : SP_BUTTON_RELEASE_CALLBACK);
    spDebug(40, "spHandleCanvasMouseMac", "pressed = %d, button = %d, call_reason = %d\n",
	    pressed, button, call_reason);
    
    return spPostMessageMac(component, call_type, call_reason);
}

spBool spHandleCanvasKeyDownMac(spComponent component, EventRecord *event)
{
    spBool flag = SP_FALSE;
    
    if (spIsCanvas(component) == SP_TRUE) {
	if (spIsVisible(component) == SP_TRUE
	    && SpPrimitiveArch(component).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(component).map_flag == SP_TRUE) {
	    SpPrimitiveArch(component).event = *event;
	    flag = spPostMessageMac(component, SP_KEY_PRESS_CALLBACK, SP_CR_KEY_PRESS);
	}
    }

    return flag;
}

spBool spIsCanvasExposedArch(spComponent component)
{
    if (SpComponentPart(component).client_width >= 0
	&& SpComponentPart(component).client_height >= 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spExposeCanvasCBArch(spComponent component)
{
    return;
}

void spCanvasCreateArch(spComponent component)
{
    spImageCreateArch(component);
    spSetNeedUpdateMac(component);
    spSetNeedMoveCallMac(component);

    if (SpCanvasPart(component).focusable == SP_TRUE) {
	spSetKeySendComponentMac(component, SP_TRUE);
    }
    
    return;
}

void spCanvasSetParamsArch(spComponent component)
{
    return;
}
    
void spCanvasDestroyArch(spComponent component)
{
    return;
}
    
void spRefreshCanvasArch(spComponent component)
{
    Rect src_rect;
    Rect dest_rect;
    WindowPtr window;
    PixMapHandle pixmap;
    BitMap *bitmap;
    RgnHandle orig_rgn;
    GrafPtr save_port;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    CGrafPtr window_port;

    spLockControlMutexMac();
    spLockDrawMutexMac();
    
    if ((pixmap = spGetLockedPixmapMac(component)) != NULL) {
	window = SpPrimitiveArch(SpGetWindow(component)).window;
	window_port = GetWindowPort(window);
	
	spLockWindowPort(window, &save_port);
	
	GetGWorld(&save_gwp, &save_gdh);
	SetGWorld(window_port, NULL);
    
	bitmap = spGetPortBitMapMac(window);
	
	SetRect(&src_rect, 0, 0, SpComponentPart(component).client_width,
		SpComponentPart(component).client_height);
	dest_rect = SpPrimitiveArch(component).rect;

	spDebug(50, "spRefreshCanvasArch",
		"src: left = %d, right = %d, top = %d, bottom = %d\n",
		src_rect.left, src_rect.right, src_rect.top, src_rect.bottom);
	spDebug(50, "spRefreshCanvasArch",
		"dest: left = %d, right = %d, top = %d, bottom = %d\n",
		dest_rect.left, dest_rect.right, dest_rect.top, dest_rect.bottom);

	/* store original region */
	orig_rgn = NewRgn();
	GetClip(orig_rgn);
	
	/* set clip region */
	SetClip(spGetVisibleRegionMac(window));

	/* set default RGB */
	spGetOriginalRGBMac();
	spSetNormalRGBMac();

	/* copy pixmap to window */
	CopyBits((BitMap *)*pixmap, bitmap, &src_rect, &dest_rect, srcCopy, NULL);
	spUnlockPixmapMac(component, pixmap);

	/* restore RGB */
	spSetOriginalRGBMac();
	
	/* restore original region */
	SetClip(orig_rgn);
	DisposeRgn(orig_rgn);
	
	SetGWorld(save_gwp, save_gdh);
	
	spUnlockWindowPort(window, save_port);

#if TARGET_API_MAC_CARBON
	if (QDIsPortBuffered(window_port)) {
	    QDFlushPortBuffer(window_port, NULL);
	}
#endif
    }
    
    spUnlockDrawMutexMac();
    spUnlockControlMutexMac();

    return;
}

void spRedrawCanvasArch(spComponent component)
{
    spRedrawImageArch(component);
    return;
}

spBool spSetCanvasCaptureArch(spComponent window)
{
    return SP_TRUE;
}

void spSetCanvasCursorMac(spComponent component)
{
    CursHandle cursor;
    
    if (SpPrimitiveArch(component).cursor_type != SP_CURSOR_UNKNOWN
	&& (cursor = spGetCursorMac(SpPrimitiveArch(component).cursor_type)) != NULL) {
	spDebug(10, "spSetCanvasCursorMac", "in\n");
	spSetCursorMac(cursor);
    } else {
	spUnsetCursorMac();
    }
    
    return;
}

void spUnsetCanvasCursorMac(spComponent component)
{
    spDebug(10, "spUnsetCanvasCursorMac", "in\n");
    spUnsetCursorMac();
    return;
}

spBool spSetCanvasCursorArch(spComponent component, spCursor cursor)
{
    SpPrimitiveArch(component).cursor_type = cursor->type;
    return SP_TRUE;
}

spBool spUnsetCanvasCursorArch(spComponent component)
{
    SpPrimitiveArch(component).cursor_type = SP_CURSOR_UNKNOWN;
    return SP_TRUE;
}

spBool spIsCanvasFocusedArch(spComponent component)
{
    if (SpFrameArch(SpGetWindow(component)).key_send_component == component) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}
