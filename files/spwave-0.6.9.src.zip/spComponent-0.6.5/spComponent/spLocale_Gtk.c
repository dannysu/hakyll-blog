/*
 *	spLocale_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <gtk/gtk.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>

void spSetLanguageArch(char *lang, char *o_lang)
{
    sscanf(gtk_set_locale(), "%s", o_lang);
    spDebug(10, NULL, "locale = %s\n", o_lang);
    
    return;
}
