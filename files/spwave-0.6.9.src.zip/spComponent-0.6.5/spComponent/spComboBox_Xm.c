/*
 *	spComboBox_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/keysym.h>
#include <Xm/MenuShell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/BulletinB.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/DrawnB.h>
#include <Xm/ArrowB.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/List.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spList.h>

#include <sp/spGraphicsP.h>
#include <sp/spComboBoxP.h>

spBool spGetScreenGeometry(Widget widget, int *x, int *y, int *width, int *height)
{
    int cx, cy;
    int root_x, root_y;
    unsigned int w, h;
    unsigned int border, depth;
    Display *display;
    Window root_return;
    Window root_window;
    Window parent_window;
    Window window;
    int num_child;
    Window *children;

    if (widget != NULL) {
	display = XtDisplay(widget);
	root_window = DefaultRootWindow(display);
	parent_window = None;

	root_x = 0;
	root_y = 0;
	window = XtWindow(widget);
	
	while (parent_window != root_window) {
	    XGetGeometry(display, window, &root_return, &cx, &cy, &w, &h, &border, &depth);
	    root_x += cx;
	    root_y += cy;
	    XQueryTree(display, window, &root_return, &parent_window, &children, &num_child);
	    window = parent_window;
	}
	
	XGetGeometry(display, XtWindow(widget), &root_return, &cx, &cy, &w, &h, &border, &depth);

	if (x != NULL) *x = root_x;
	if (y != NULL) *y = root_y;
	if (width != NULL) *width = w;
	if (height != NULL) *height = h;
	
	return SP_TRUE;
    }

    return SP_FALSE;
}

static Widget sp_combo_shell = NULL;
static spBool sp_combo_selected = SP_FALSE;
static spBool sp_combo_armed = SP_FALSE;
static int sp_combo_prev_index = 0;

static void selectComboListCB(Widget widget, XtPointer client_data, XmListCallbackStruct *cbs)
{
    spComponent component = (spComponent)client_data;

    if (spIsCreated(component) == SP_FALSE) return;

    SpPrimitivePart(component).index = cbs->item_position - 1;
    sp_combo_selected = SP_TRUE;
    spDebug(30, "selectListCB", "index = %d\n", SpPrimitivePart(component).index);

    return;
}

static void popupComboListCB(Widget widget, XtPointer client_data, XtPointer call_data)
{
    int x, y;
    int width, height;
    Widget list;
    Display *display;
    spComponent component = (spComponent)client_data;

    if (spIsCreated(component) == SP_FALSE
	|| sp_combo_armed == SP_FALSE) return;

    spDebug(40, "popupComboListCB", "in\n");

    /* get current position of combo box */
    spGetScreenGeometry(SpPrimitiveArch(component).top_widget, &x, &y, &width, &height);

    /* find shell widget */
    list = SpPrimitiveArch(component).sub_widget;
    sp_combo_shell = XtParent(list);
    while (XtIsShell(sp_combo_shell) == False) {
	sp_combo_shell = XtParent(sp_combo_shell);
    }

    /* set current position to shell widget */
    XtVaSetValues(sp_combo_shell,
		  XmNx, x,
		  XmNy, y + height,
		  XmNwidth, width,
		  XmNheight, SpComboBoxPart(component).size,
		  NULL);
    
    /* popup list part of combo box */
    XtPopupSpringLoaded(sp_combo_shell);
    sp_combo_selected = SP_FALSE;
    sp_combo_armed = SP_FALSE;
    sp_combo_prev_index = SpPrimitivePart(component).index;

    /* grab pointer */
    display = XtDisplay(sp_combo_shell);
    XGrabKeyboard(display, XtWindow(sp_combo_shell), False,
		  GrabModeAsync, GrabModeAsync, CurrentTime);
    XGrabPointer(display, DefaultRootWindow(display), True,
		 ButtonPressMask | ButtonReleaseMask | ButtonMotionMask,
		 GrabModeAsync, GrabModeAsync, None, None, CurrentTime);
    
    return;
}

static void resetComboList(spComponent component)
{
    SpPrimitivePart(component).index = sp_combo_prev_index;
    XmListSelectPos(SpPrimitiveArch(component).sub_widget,
		    SpPrimitivePart(component).index + 1, False);
    sp_combo_selected = SP_FALSE;

    return;
}

static void popdownComboListCB(Widget widget, XtPointer client_data, XEvent *event)
{
    char *string;
    Display *display;
    spComponent component = (spComponent)client_data;
    
    if (sp_combo_shell == NULL) return;

    spDebug(40, "popdownComboListCB", "in\n");

    display = XtDisplay(sp_combo_shell);
    
    if (XtIsShell(widget) == True && event->type != KeyPress) {
	Window window, root;
	Window child = None;
	int rx, ry, wx, wy;
	unsigned int mask;

	window = XtWindow(sp_combo_shell);
	XQueryPointer(display, window, &root, &child, &rx, &ry, &wx, &wy, &mask);
	if (child != None) {
	    /* if pointer is inside child, do noting. */
	    return;
	}
	resetComboList(component);
    }

    /* ungrab pointer */
    XUngrabPointer(display, XtLastTimestampProcessed(display));
    XUngrabKeyboard(display, XtLastTimestampProcessed(display));
    
    /* popdown list part of combo box */
    XtPopdown(sp_combo_shell);
    sp_combo_shell = NULL;

    if (sp_combo_selected == SP_TRUE) {
	string = xspGetSelectedListItem(component);
	spSetTextString(component, string);
	xfree(string);
    }
    
    return;
}

static void popdownComboShellCB(Widget widget, XtPointer client_data, XEvent *event)
{
    spDebug(40, "popdownComboShellCB", "in\n");
    if (sp_combo_shell != NULL) {
	XGrabKeyboard(XtDisplay(sp_combo_shell), XtWindow(sp_combo_shell), False,
		      GrabModeAsync, GrabModeAsync, CurrentTime);
    }
    return;
}

static void keyPressComboListCB(Widget widget, XtPointer client_data, XEvent *event)
{
    KeySym xks;
    int buf_size = 1024;
    char buf[1024];
    spComponent component = (spComponent)client_data;
    
    if (event->type == KeyPress) {
	XLookupString(&event->xkey, buf, buf_size, &xks, NULL);
	spDebug(80, "keyPressComboListCB", "in\n");
	if (xks == XK_Escape || xks == XK_Return) {
	    if (xks == XK_Escape) {
		resetComboList(component);
	    }
	    popdownComboListCB(widget, client_data, event);
	}
    }

    return;
}

static void armComboButtonCB(Widget widget, XtPointer client_data,
			     XButtonEvent *event)
{
    sp_combo_armed = SP_TRUE;
    return;
}

void spComboBoxCreateArch(spComponent component)
{
    int narg = 0, narg2 = 0;
    Arg args[10], args2[10];
    Widget button;
    Widget shell;

    XtSetArg(args[narg], XmNeditable,
	     (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
    
    SpPrimitiveArch(component).top_widget =
	XtVaCreateManagedWidget("form", xmFormWidgetClass,
				SpParentPrimitiveArch(component).widget,
				NULL);
    
    XtSetArg(args[narg], XmNtopAttachment, XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNbottomAttachment,XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNleftAttachment, XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNrightAttachment, XmATTACH_FORM); narg++;
    XtSetArg(args[narg], XmNleftOffset, 0); narg++;
    XtSetArg(args[narg], XmNrightOffset, 25); narg++;
    
#ifdef MOTIF_USE_CS_TEXT
    /* create text */
    XtSetArg(args[narg], XmNrows, 1); narg++;
    SpPrimitiveArch(component).widget =
	XmCreateCSText(SpPrimitiveArch(component).top_widget,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       args, narg);
    XtManageChild(SpPrimitiveArch(component).widget);
#else
    /* create text field */
    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			      xmTextFieldWidgetClass, SpPrimitiveArch(component).top_widget,
			      args, narg);
#endif
    
    button = XtVaCreateManagedWidget("", xmArrowButtonWidgetClass,
				     SpPrimitiveArch(component).top_widget,
				     /*XmNtraversalOn, False,*/
				     XmNarrowDirection, XmARROW_DOWN,
				     XmNforeground, spGetColorPixelXm("#c0c0c0"),
				     XmNtopAttachment, XmATTACH_FORM,
				     XmNbottomAttachment,XmATTACH_FORM,
				     XmNleftAttachment, XmATTACH_WIDGET,
				     XmNrightAttachment,XmATTACH_FORM,
				     XmNleftWidget, SpPrimitiveArch(component).widget,
				     XmNleftOffset, 0,
				     NULL);
    
    shell = XtVaAppCreateShell("ComboPopup", "comboPopup",
			       /*overrideShellWidgetClass*/topLevelShellWidgetClass,
			       XtDisplay(SpPrimitiveArch(component).top_widget),
			       XmNoverrideRedirect, True,
			       XmNdeleteResponse, XmUNMAP,
			       NULL);
    
    XtSetArg(args2[narg2], XmNautomaticSelection, True); narg2++;
    XtSetArg(args2[narg2], XmNselectionPolicy, XmBROWSE_SELECT); narg2++;
    XtSetArg(args2[narg2], XmNlistSizePolicy, XmVARIABLE); narg2++;
    XtSetArg(args2[narg2], XmNscrollBarDisplayPolicy, XmSTATIC); narg2++;
    SpPrimitiveArch(component).sub_widget = XmCreateScrolledList(shell, "list",
								 args2, narg2);
    XtManageChild(SpPrimitiveArch(component).sub_widget);
    XtAddCallback(SpPrimitiveArch(component).sub_widget, XmNbrowseSelectionCallback,
		  (XtCallbackProc)selectComboListCB, (XtPointer)component);
    
    XtAddCallback(button, XmNarmCallback,
		  (XtCallbackProc)armComboButtonCB, (XtPointer)component);
    XtAddCallback(button, XmNactivateCallback,
		  (XtCallbackProc)popupComboListCB, (XtPointer)component);
    XtAddEventHandler(SpPrimitiveArch(component).sub_widget, ButtonReleaseMask, False,
		      (XtEventHandler)popdownComboListCB, (XtPointer)component);
    XtAddEventHandler(shell, ButtonReleaseMask, False,
		      (XtEventHandler)popdownComboShellCB, (XtPointer)component);
    XtAddEventHandler(shell, ButtonPressMask, False,
		      (XtEventHandler)popdownComboListCB, (XtPointer)component);
    XtAddEventHandler(shell, KeyPressMask, False,
		      (XtEventHandler)keyPressComboListCB, (XtPointer)component);

    return;
}

void spComboBoxSetParamsArch(spComponent component)
{
    int narg = 0;
    Arg args[10];

    XtSetArg(args[narg], XmNeditable,
	     (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
    
    XtSetValues(SpPrimitiveArch(component).widget, args, narg);

    return;
}
