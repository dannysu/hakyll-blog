/*
 *	spTopLevel_Mac.c
 */
#if defined(MACOSX)
#include <Carbon/Carbon.h>
#else
#include <Gestalt.h>
#include <MacTypes.h>
#include <Quickdraw.h>
#include <MacWindows.h>
#include <Dialogs.h>
#include <Menus.h>
#include <Devices.h>
#include <Events.h>
#include <ToolUtils.h>
#include <Controls.h>
#include <ControlDefinitions.h>
#include <Devices.h>
#include <LowMem.h>
#endif

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spThread.h>

#include <sp/spGraphicsP.h>
#include <sp/spComponentP.h>
#include <sp/spPrimitiveP.h>
#include <sp/spMenuP.h>
#include <sp/spFrameP.h>
#include <sp/spButtonP.h>
#include <sp/spSliderP.h>
#include <sp/spTopLevelP.h>

#if !TARGET_API_MAC_CARBON
#if !defined(THINK_C) && !defined(__MWERKS__)
QDGlobals qd;
#endif
#endif

#if defined(MACOSX)
#include <pthread.h>

static pthread_t sp_main_thread = NULL;
static void *sp_main_mutex = NULL;
static void *sp_port_mutex = NULL;
static void *sp_draw_mutex = NULL;
static void *sp_control_mutex = NULL;

/*#define DISPATCH_MUTEX_LOCK*/
#undef DISPATCH_MUTEX_LOCK
#endif

#if 0
#define SP_USE_DEBUG_WINDOW
#else
#undef SP_USE_DEBUG_WINDOW
#endif

#if 0
#define SP_USE_DEBUG_FILE_OUT
#else
#undef SP_USE_DEBUG_FILE_OUT
#endif
#define SP_DEBUG_FILE_ALWAYS_FOPEN

#if defined(SP_USE_DEBUG_WINDOW)
static WindowPtr sp_debug_window = NULL;

#define SP_DEBUG_WINDOW_LEFT 100
#define SP_DEBUG_WINDOW_TOP 100
#define SP_DEBUG_WINDOW_WIDTH 700
#define SP_DEBUG_WINDOW_HEIGHT 450

#define SP_DEBUG_WINDOW_VMARGIN 20
#define SP_DEBUG_WINDOW_HMARGIN 20
#define SP_DEBUG_WINDOW_LINE_SKIP 20

void spShowDebugMessage(char *message)
{
    Rect rect;
    Str255 pstr;
    GrafPtr save_port;
    static int current_top = SP_DEBUG_WINDOW_VMARGIN;
    
    if (sp_debug_window != NULL) {
	spLockWindowPort(sp_debug_window, &save_port);

	if (current_top >= SP_DEBUG_WINDOW_HEIGHT - SP_DEBUG_WINDOW_VMARGIN) {
	    spGetPortRectMac(sp_debug_window, &rect);
	    EraseRect(&rect);
	    current_top = SP_DEBUG_WINDOW_VMARGIN;
	}

	MoveTo(SP_DEBUG_WINDOW_HMARGIN, current_top);
	spStrCToP(message, pstr);
	DrawString(pstr);
	current_top += SP_DEBUG_WINDOW_LINE_SKIP;
	
	spUnlockWindowPort(sp_debug_window, save_port);
    }

    return;
}
#elif defined(SP_USE_DEBUG_FILE_OUT)
FILE *sp_debug_fp = NULL;

void spShowDebugMessage(char *message)
{
#ifndef SP_DEBUG_FILE_ALWAYS_FOPEN
    if (sp_debug_fp != NULL) {
	fprintf(sp_debug_fp, message);
	fflush(sp_debug_fp);
    }
#else
    if ((sp_debug_fp = fopen("stdout", "a")) != NULL) {
	fprintf(sp_debug_fp, message);
	fclose(sp_debug_fp);
    }
    sp_debug_fp = NULL;
#endif
    return;
}
#endif

static void getMenuLabel(char *label, char *shortcut, Str255 plabel)
{
    char buf[SP_MAX_MENU_LABEL];
    char string[SP_MAX_MENU_LABEL];

    spGetMnemonic(label, string);
    
    if (shortcut == NULL) {
	strcpy(buf, string);
    } else {
	sprintf(buf, "%s%s", string, shortcut);
    }
    spDebug(50, "getMenulabel", "buf = %s\n", buf);
    
    spStrCToP(buf, plabel);
    return;
}

static void spCreateDefaultMenuMac(spTopLevel toplevel)
{
    int i;
    int num_file_menu;
    Str255 plabel;
    
    SpTopLevelArch(toplevel).menu_bar = GetMenuBar();
    SpTopLevelArch(toplevel).apple_menu = NewMenu(SP_APPLE_MENU_ID, "\p\024");
    getMenuLabel(SP_ABOUT_MENU_LABEL, NULL, plabel);
    AppendMenu(SpTopLevelArch(toplevel).apple_menu, plabel);
    AppendMenu(SpTopLevelArch(toplevel).apple_menu, "\p(-");
#if !TARGET_API_MAC_CARBON
    AppendResMenu(SpTopLevelArch(toplevel).apple_menu, 'DRVR');
#endif
    InsertMenu(SpTopLevelArch(toplevel).apple_menu, 0);

    getMenuLabel(SP_FILE_MENU_LABEL, NULL, plabel);
    SpTopLevelArch(toplevel).file_menu = NewMenu(SP_FILE_MENU_ID, plabel);
    getMenuLabel(SP_NEW_MENU_LABEL, "/N", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    getMenuLabel(SP_OPEN_MENU_LABEL, "/O", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, "\p(-");
    getMenuLabel(SP_CLOSE_MENU_LABEL, "/C", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    getMenuLabel(SP_SAVE_MENU_LABEL, "/S", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    getMenuLabel(SP_SAVE_AS_MENU_LABEL, NULL, plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, "\p(-");
    getMenuLabel(SP_PAGE_SETUP_MENU_LABEL, NULL, plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    getMenuLabel(SP_PRINT_MENU_LABEL, "/P", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);

    SpTopLevelArch(toplevel).window_menu = NULL;
    
#if !TARGET_API_MAC_CARBON
    AppendMenu(SpTopLevelArch(toplevel).file_menu, "\p(-");
    getMenuLabel(SP_QUIT_MENU_LABEL, "/Q", plabel);
    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
    num_file_menu = SP_QUIT_MENU_ITEM_ID;
#else
    {
	if (spIsAquaMac() == SP_TRUE) {
	    num_file_menu = SP_QUIT_MENU_ITEM_ID - 1;
	} else {
	    AppendMenu(SpTopLevelArch(toplevel).file_menu, "\p(-");
	    getMenuLabel(SP_QUIT_MENU_LABEL, "/Q", plabel);
	    AppendMenu(SpTopLevelArch(toplevel).file_menu, plabel);
	    
	    SetMenuItemCommandID(SpTopLevelArch(toplevel).file_menu,
				 SP_QUIT_MENU_ITEM_ID, 'quit');
	    
	    num_file_menu = SP_QUIT_MENU_ITEM_ID;
	}

	if (SpTopLevelPart(toplevel).use_window_menu == SP_TRUE) {
	    if (CreateStandardWindowMenu(0, &SpTopLevelArch(toplevel).window_menu) == noErr) {
		SetMenuID(SpTopLevelArch(toplevel).window_menu, SP_WINDOW_MENU_ID);
		InsertMenu(SpTopLevelArch(toplevel).window_menu, 0);
	    }
	}
    }
#endif
    for (i = 1; i < num_file_menu; i++) {
	DisableMenuItem(SpTopLevelArch(toplevel).file_menu, i);
    }
    
    getMenuLabel(SP_EDIT_MENU_LABEL, NULL, plabel);
    SpTopLevelArch(toplevel).edit_menu = NewMenu(SP_EDIT_MENU_ID, plabel);
    getMenuLabel(SP_UNDO_MENU_LABEL, "/Z", plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, "\p(-");
    getMenuLabel(SP_CUT_MENU_LABEL, "/X", plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    getMenuLabel(SP_COPY_MENU_LABEL, "/C", plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    getMenuLabel(SP_PASTE_MENU_LABEL, "/V", plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    getMenuLabel(SP_DELETE_MENU_LABEL, NULL, plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, "\p(-");
    getMenuLabel(SP_SELECT_ALL_MENU_LABEL, "/A", plabel);
    AppendMenu(SpTopLevelArch(toplevel).edit_menu, plabel);
    DisableMenuItem(SpTopLevelArch(toplevel).edit_menu, SP_UNDO_MENU_ITEM_ID);

#if !TARGET_API_MAC_CARBON
    HMGetHelpMenuHandle(&SpTopLevelArch(toplevel).help_menu);
#else
    HMGetHelpMenu(&SpTopLevelArch(toplevel).help_menu, NULL);
#endif
    SpTopLevelArch(toplevel).num_help_menu = CountMenuItems(SpTopLevelArch(toplevel).help_menu);
    
    return;
}

static void spCreateDebugWindowMac(void)
{
    spDebug(50, "spCreateDebugWindowMac", "in\n");
#if defined(SP_USE_DEBUG_WINDOW)
    if (1/*spGetDebugLevel() >= 0*/) {
	Ptr ptr;
	Rect rect;

	spDebug(50, "spCreateDebugWindowMac", "create window\n");
	
#if !TARGET_API_MAC_CARBON
	ptr = NewPtr(sizeof(CWindowRecord));
#else
	ptr = NULL;
#endif
	
	SetRect(&rect,
		SP_DEBUG_WINDOW_LEFT, SP_DEBUG_WINDOW_TOP,
		SP_DEBUG_WINDOW_LEFT + SP_DEBUG_WINDOW_WIDTH,
		SP_DEBUG_WINDOW_TOP + SP_DEBUG_WINDOW_HEIGHT);
	
#if !TARGET_API_MAC_CARBON
	sp_debug_window = NewCWindow(ptr, &rect, "\pDebug", true,
				     zoomDocProc, (WindowPtr)-1, true, 0L);
#else
	sp_debug_window = NULL;
	if (CreateNewWindow(kDocumentWindowClass,
			    kWindowCloseBoxAttribute | kWindowStandardHandlerAttribute,
			    &rect, &sp_debug_window) == noErr) {
	    SetWTitle(sp_debug_window, "\pDebug");
	    ShowWindow(sp_debug_window);
	}
#endif
	if (sp_debug_window != NULL) {
	    spSetPrintFunc(spShowDebugMessage);
	}
	spDebug(50, "spCreateDebugWindowMac", "done\n");
    }
#elif defined(SP_USE_DEBUG_FILE_OUT)
    {
#ifndef SP_DEBUG_FILE_ALWAYS_FOPEN
	if ((sp_debug_fp = fopen("stdout", "w")) != NULL) {
	    spSetPrintFunc(spShowDebugMessage);
	}
#endif
    }
#endif

    return;
}

static GWorldPtr sp_dummy_gworld = NULL;

static void spCreateDummyGWorldMac(void)
{
    Rect rect;
    
    SetRect(&rect, 0, 0, SP_DUMMY_GWORLD_WIDTH, SP_DUMMY_GWORLD_HEIGHT);
    
    if (noErr != NewGWorld(&sp_dummy_gworld,
			   0, &rect, NULL, NULL, useTempMem)) {
	sp_dummy_gworld = NULL;
    }
    
    return;
}

static void spDestroyDummyGWorldMac(void)
{
    if (sp_dummy_gworld != NULL) {
	DisposeGWorld(sp_dummy_gworld);
    }

    return;
}

spBool spSetDummyGWorldMac(void)
{
    if (sp_dummy_gworld != NULL) {
	SetGWorld(sp_dummy_gworld, NULL);
    }
    return SP_TRUE;
}

static SInt32 sp_system_version = 0;
static SInt32 sp_appearance_version = 0;
static SInt32 sp_carbon_version = 0;
static spBool sp_is_aqua = SP_FALSE;
static spBool sp_carbon_event_available = SP_FALSE;

void spInitManagersMac(void)
{
    static int flag = 0;
    SInt32 response;

    if (flag == 0) {
#if !TARGET_API_MAC_CARBON
	InitGraf(&qd.thePort);
	InitFonts();
	InitWindows();
	InitMenus();
	TEInit();
	InitDialogs(0L);
#endif
	FlushEvents(everyEvent,0);
	InitCursor();

	if (Gestalt(gestaltSystemVersion, &response) == noErr) {
	    sp_system_version = response;
	}
	if (Gestalt(gestaltAppearanceAttr, &response) == noErr
	    && Gestalt(gestaltAppearanceVersion,&response) == noErr) {
	    sp_appearance_version = response;
	}
#if TARGET_API_MAC_CARBON
	if (Gestalt(gestaltCarbonVersion, &response) == noErr) {
	    sp_carbon_version = response;
	}
	if (Gestalt(gestaltMenuMgrAttr, &response) == noErr) {
	    if (response & gestaltMenuMgrAquaLayoutMask) {
		sp_is_aqua = SP_TRUE;
	    } else {
		sp_is_aqua = SP_FALSE;
	    }
	}
	if (sp_is_aqua == SP_TRUE || sp_carbon_version >= 0x130) {
	    sp_carbon_event_available = SP_TRUE;
	}
#endif

#if defined(MACOSX)
	if (sp_main_thread == NULL) {
	    sp_main_thread = pthread_self();
	}
	if (sp_main_mutex == NULL) {
	    sp_main_mutex = spCreateMutex(NULL);
	}
	if (sp_port_mutex == NULL) {
	    sp_port_mutex = spCreateMutex(NULL);
	}
	if (sp_draw_mutex == NULL) {
	    sp_draw_mutex = spCreateMutex(NULL);
	}
	if (sp_control_mutex == NULL) {
	    sp_control_mutex = spCreateMutex(NULL);
	}
#endif

	spCreateDebugWindowMac();
	
	flag = 1;
    }

    return;
}

long spGetSystemVersionMac(void)
{
    return (long)sp_system_version;
}

long spGetAppearanceVersionMac(void)
{
#if 1
    return (long)sp_appearance_version;
#else
    return 0;
#endif
}

long spGetCarbonVersionMac(void)
{
    return (long)sp_carbon_version;
}

spBool spIsCarbonEventAvailableMac(void)
{
#if TARGET_API_MAC_CARBON
    return sp_carbon_event_available;
#else
    return SP_FALSE;
#endif
}

spBool spIsAquaMac(void)
{
    return (long)sp_is_aqua;
}

int spGetPixelDepthMac(Boolean *is_color)
{
    static GDHandle device = NULL;
    int depth;

    if (device == NULL) {
	device = GetGDevice();
    }

    depth = (*(*device)->gdPMap)->pixelSize;
    if (is_color != NULL) {
	*is_color = BitTst(&(*device)->gdFlags,gdDevType);
    }

    return depth;
}

static CursHandle sp_prev_cursor = NULL;

void spSetCursorMac(CursHandle cursor)
{
    if (cursor == NULL) return;
    
    if (cursor != sp_prev_cursor) {
	if (sp_prev_cursor != NULL) {
	    ReleaseResource((Handle)sp_prev_cursor);
	}
	spDebug(10, "spSetCursorMac", "cursor = %ld, prev_cursor = %ld\n",
		(long)cursor, (long)sp_prev_cursor);
        HLock((Handle)cursor);
	SetCursor(*cursor);
        HUnlock((Handle)cursor);
	sp_prev_cursor = cursor;
    }
    
    return;
}

void spUnsetCursorMac(void)
{
#if !TARGET_API_MAC_CARBON
    SetCursor(&qd.arrow);
#else
    Cursor arrow;

    SetCursor(GetQDGlobalsArrow(&arrow));
#endif
    if (sp_prev_cursor != NULL) {
	ReleaseResource((Handle)sp_prev_cursor);
	sp_prev_cursor = NULL;
    }
    
    return;
}

static spBool sp_done = SP_FALSE;
static spBool sp_started = SP_FALSE;
static int sp_argc = 0;
static char **sp_argv = NULL;
static spMainFunc sp_main_func = NULL;

pascal OSErr spHandleOpenAppEvent(AppleEvent *appEvent, AppleEvent *reply, SInt32 refCon)
{
    spDebug(10, "spHandleOpenAppEvent", "in\n");
    if (sp_started == SP_FALSE) {
	sp_started = SP_TRUE;
	if (sp_main_func != NULL) {
	    sp_main_func(sp_argc, sp_argv);
	}
	sp_done = SP_TRUE;
    }
    
    return noErr;
}

pascal OSErr spHandleQuitAppEvent(AppleEvent *appEvent, AppleEvent *reply, SInt32 refCon)
{
    spComponent window;
    
    spDebug(10, "spHandleQuitAppEvent", "in\n");

    window = spGetCurrentWindowMac();
    
    if (spIsFrame(window) == SP_TRUE && SpFrameArch(window).quit_menu_item != NULL) {
	spPostMessageMac(SpFrameArch(window).quit_menu_item, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
    } else {
	spQuit(0);
    }
    
    return noErr;
}

pascal OSErr spHandleOpenDocsEvent(AppleEvent *appEvent, AppleEvent *reply, SInt32 refCon)
{
    int i;
    FSSpec fileSpec;
    AEDescList docList;
    OSErr err;
    SInt32 numItems;
    Size actualSize;
    AEKeyword keyWord;
    DescType returnedType;
    char filename[SP_MAX_PATHNAME];
    int argc;
    char **argv;
    
    spDebug(10, "spHandleOpenDocsEvent", "in\n");
    
    if ((err = AEGetParamDesc(appEvent, keyDirectObject, typeAEList, &docList)) == noErr) {
	AECountItems(&docList, &numItems);
	if (sp_started == SP_TRUE) {
	    argv = xalloc(numItems, char *);
	    argc = 0;
	} else {
	    if (sp_argv != NULL) {
		argv = xalloc(numItems + sp_argc, char *);
		for (argc = 0; argc < sp_argc; argc++) {
		    argv[argc] = strclone(sp_argv[argc]);
		}
	    } else {
		argv = xalloc(numItems + 1, char *);
		argv[0] = strclone("a.out");
		argc = 1;
	    }
	}
	
	for (i = 1; i <= numItems; i++) {
	    if ((err = AEGetNthPtr(&docList, i, typeFSS, &keyWord, &returnedType,
				   (Ptr)&fileSpec, sizeof(fileSpec), &actualSize)) != noErr) {
		break;
	    }

	    if (spFSSpecToExactNameMac(&fileSpec, filename) == SP_TRUE) {
		spDebug(10, "spHandleOpenDocsEvent", "filename = %s\n", filename);
		argv[argc++] = strclone(filename);
	    }
	}
	spDebug(10, "spHandleOpenDocsEvent", "started = %d, argc = %d\n", sp_started, argc);
	
	AEDisposeDesc(&docList);

	if (sp_started == SP_TRUE) {
	    spComponent component;
	    
	    component = spGetCurrentWindowMac();
	    spDebug(10, "spHandleOpenDocsEvent", "component = %ld\n", (long)component);
	    
	    if (spIsFrame(component) == SP_TRUE
		&& SpFrameArch(component).drop_call_func != NULL) {
		spDebug(10, "spHandleOpenDocsEvent", "drop callback\n");
		/* drop callback */
		SpFrameArch(component).drop_call_func(component, SpFrameArch(component).drop_call_data,
						      argc, argv);
	    }
	} else {
	    sp_started = SP_TRUE;
	    if (sp_main_func != NULL) {
		sp_main_func(argc, argv);
	    }
	    sp_done = SP_TRUE;
	}
	    
	for (i = 0; i < argc; i++) {
	    xfree(argv[i]);
	}
	xfree(argv);
	
	return noErr;
    }
    
    return err;
}

pascal OSErr spHandlePrintDocsEvent(AppleEvent *appEvent, AppleEvent *reply, SInt32 refCon)
{
    spDebug(10, "spHandlePrintDocsEvent", "in\n");
    return errAEEventNotHandled;
}

static AEEventHandlerUPP spHandleOpenAppEventUPP = NULL;
static AEEventHandlerUPP spHandleQuitAppEventUPP = NULL;
static AEEventHandlerUPP spHandleOpenDocsEventUPP = NULL;
static AEEventHandlerUPP spHandlePrintDocsEventUPP = NULL;
#if TARGET_API_MAC_CARBON
static EventHandlerUPP spAppEventHandlerUPP = NULL;
#endif

spBool spInitializeMac(int argc, char **argv, spMainFunc func)
{
    if (argc >= 2 && strneq(argv[1], "-psn_", 5)) {
	argc = 1;
    }
    sp_argc = argc;
    sp_argv = argv;
    
    spDebug(10, "spInitializeMac", "in\n");
    
    spInitManagersMac();

    sp_main_func = func;
    
    spHandleOpenAppEventUPP = NewAEEventHandlerUPP((AEEventHandlerProcPtr)spHandleOpenAppEvent);
    spHandleQuitAppEventUPP = NewAEEventHandlerUPP((AEEventHandlerProcPtr)spHandleQuitAppEvent);
    spHandleOpenDocsEventUPP = NewAEEventHandlerUPP((AEEventHandlerProcPtr)spHandleOpenDocsEvent);
    spHandlePrintDocsEventUPP = NewAEEventHandlerUPP((AEEventHandlerProcPtr)spHandlePrintDocsEvent);
    
    if (AEInstallEventHandler(kCoreEventClass, kAEOpenApplication, spHandleOpenAppEventUPP,
			      0L, false) != noErr) {
	return SP_FALSE;
    }
    if (AEInstallEventHandler(kCoreEventClass, kAEQuitApplication, spHandleQuitAppEventUPP,
			      0L, false) != noErr) {
	return SP_FALSE;
    }
    if (AEInstallEventHandler(kCoreEventClass, kAEOpenDocuments, spHandleOpenDocsEventUPP,
			      0L, false) != noErr) {
	return SP_FALSE;
    }
    if (AEInstallEventHandler(kCoreEventClass, kAEPrintDocuments, spHandlePrintDocsEventUPP,
			      0L, false) != noErr) {
	return SP_FALSE;
    }

#if TARGET_API_MAC_CARBON
    if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	EventHandlerRef ehref;
	EventTypeSpec list[]={ 
	    { kEventClassCommand, kEventCommandProcess },
	    { kEventClassAppleEvent, kEventAppleEvent },
	    { kEventClassMouse, kEventMouseDown },
	    { kEventClassMouse, kEventMouseUp },
	    { kEventClassMouse, kEventMouseMoved },
	    { kEventClassMouse, kEventMouseDragged },
	    { kEventClassMouse, kEventMouseWheelMoved },
	    { kEventClassMenu, kEventMenuTargetItem },
#if 0
	    { kEventClassMenu, kEventMenuOpening },
	    { kEventClassMenu, kEventMenuClosed },
	    { kEventClassMenu, kEventMenuMatchKey },
	    { kEventClassMenu, kEventMenuBeginTracking },
	    { kEventClassMenu, kEventMenuEndTracking },
	    { kEventClassMenu, kEventMenuEnableItems },
#endif
	};

	spAppEventHandlerUPP = spNewAppEventHandlerUPP();
	InstallApplicationEventHandler(spAppEventHandlerUPP, spArraySize(list), list, 0, &ehref);
    }
#endif
    
    spDebug(10, "spInitializeMac", "done\n");
    
    return SP_TRUE;
}

void spWaitHighLevelEventMac(void)
{
    EventRecord	event;
    
    sp_done = SP_FALSE;

#if TARGET_API_MAC_CARBON
    if (spIsCarbonEventAvailableMac() == SP_TRUE){
	RunApplicationEventLoop();
	spDebug(10, "spWaitHighLevelEventMac", "RunApplicationEventLoop done\n");
	return;
    }
#endif
    
    while (sp_done == SP_FALSE) {
	if (WaitNextEvent(everyEvent, &event, 0x7FFFFFFF, 0L)) {
	    switch(event.what) {
	      case kHighLevelEvent:
		AEProcessAppleEvent(&event);
		break;
	      default:
		break;
	    }
	}
    }

    return;
}

spBool spIsInPThreadMac(void)
{
#if defined(MACOSX)
    pthread_t current_thread;
    current_thread = pthread_self();
    
    if (!pthread_equal(sp_main_thread, current_thread)) {
	return SP_TRUE;
    }
#endif

    return SP_FALSE;
}

void spLockMainMutexMac(void)
{
#if defined(MACOSX)
    spLockMutex(sp_main_mutex);
#endif
    return;
}
    
void spUnlockMainMutexMac(void)
{
#if defined(MACOSX)
    spUnlockMutex(sp_main_mutex);
#endif
    return;
}

void spLockMainMutexForMainMac(void)
{
#if defined(MACOSX)
    if (spIsInPThreadMac() == SP_FALSE) {
	spLockMainMutexMac();
    }
#endif
    return;
}
    
void spUnlockMainMutexForMainMac(void)
{
#if defined(MACOSX)
    if (spIsInPThreadMac() == SP_FALSE) {
	spUnlockMainMutexMac();
    }
#endif
    return;
}
    
void spLockMainMutexForThreadMac(void)
{
#if defined(MACOSX)
    if (spIsInPThreadMac() == SP_TRUE) {
	spLockMainMutexMac();
    }
#endif
    return;
}
    
void spUnlockMainMutexForThreadMac(void)
{
#if defined(MACOSX)
    if (spIsInPThreadMac() == SP_TRUE) {
	spUnlockMainMutexMac();
    }
#endif
    return;
}
    
void spLockPortMutexMac(void)
{
#if defined(MACOSX)
    spLockMutex(sp_port_mutex);
#endif
    return;
}
    
void spUnlockPortMutexMac(void)
{
#if defined(MACOSX)
    spUnlockMutex(sp_port_mutex);
#endif
    return;
}
    
void spLockDrawMutexMac(void)
{
#if defined(MACOSX)
    spLockMutex(sp_draw_mutex);
#endif
    return;
}
    
void spUnlockDrawMutexMac(void)
{
#if defined(MACOSX)
    spUnlockMutex(sp_draw_mutex);
#endif
    return;
}
    
void spLockControlMutexMac(void)
{
#if defined(MACOSX)
    spLockMutex(sp_control_mutex);
#endif
    return;
}
    
void spUnlockControlMutexMac(void)
{
#if defined(MACOSX)
    spUnlockMutex(sp_control_mutex);
#endif
    return;
}
    
void spLockMenuMutexMac(void)
{
#if 1
    /*spLockDrawMutexMac();*/
    spLockControlMutexMac();
#endif
    return;
}

void spUnlockMenuMutexMac(void)
{
#if 1
    spUnlockControlMutexMac();
    /*spUnlockDrawMutexMac();*/
#endif
    return;
}

void spTopLevelPartInitArch(spTopLevel toplevel)
{
    spInitManagersMac();
#if defined(DISPATCH_MUTEX_LOCK)
    spLockMainMutexMac();
#endif

    return;
}

void spTopLevelPartFreeArch(spTopLevel toplevel)
{
    spDestroyActionProcMac();
    spDestroyDummyGWorldMac();
#if defined(DISPATCH_MUTEX_LOCK)
    spUnlockMainMutexMac();
#endif
    
#if defined(MACOSX)
    if (sp_control_mutex != NULL) {
	spDestroyMutex(sp_control_mutex);
	sp_control_mutex = NULL;
    }
    if (sp_draw_mutex != NULL) {
	spDestroyMutex(sp_draw_mutex);
	sp_draw_mutex = NULL;
    }
    if (sp_port_mutex != NULL) {
	spDestroyMutex(sp_port_mutex);
	sp_port_mutex = NULL;
    }
    if (sp_main_mutex != NULL) {
	spDestroyMutex(sp_main_mutex);
	sp_main_mutex = NULL;
    }
#endif
    
    return;
}

void spTopLevelCreateArch(spTopLevel toplevel)
{
    spCreateActionProcMac();
    spCreateDummyGWorldMac();
    spCreateDefaultMenuMac(toplevel);

    return;
}

void spTopLevelSetParamsArch(spTopLevel toplevel)
{
    return;
}
    
void spTopLevelDestroyArch(spTopLevel toplevel)
{
    return;
}

void spQuitArch(int status)
{
#if defined(SP_USE_DEBUG_WINDOW)
#elif defined(SP_USE_DEBUG_FILE_OUT)
#ifndef SP_DEBUG_FILE_ALWAYS_FOPEN
    if (sp_debug_fp != NULL) {
	fclose(sp_debug_fp);
    }
#endif
#endif
    
    sp_done = SP_TRUE;
    
    spDebug(10, "spQuitArch", "done\n");
    
    return;
}

int spWaitEventArch(spTopLevel toplevel)
{
    spDispatchEventMac(toplevel, 0x7FFFFFFF);
    return 1;
}

#if TARGET_API_MAC_CARBON
int spDispatchEventCarbonMac(spTopLevel toplevel, unsigned long sleep)
{
    int flag = 0;
    EventTargetRef target;
    EventRef event;
    EventTimeout timeout = kEventDurationNoWait;

#if defined(DISPATCH_MUTEX_LOCK)
    spUnlockMainMutexMac();
#endif

    if (sleep <= 0) {
	timeout = kEventDurationNoWait;
    } else if (sleep >= 0x7FFFFFFF) {
	timeout = kEventDurationForever;
    } else {
	timeout = TicksToEventTime(sleep);
    }

    if (ReceiveNextEvent(0, NULL, timeout, true, &event) == noErr) {
	flag = 1;
    }

#if defined(DISPATCH_MUTEX_LOCK)
    spLockMainMutexMac();
#endif

    if (flag) {
	target = GetEventDispatcherTarget();
	SendEventToEventTarget(event, target);
	ReleaseEvent(event);
    }
    
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	spYieldThread();
    }
    
    return flag;
}
#endif
    
static UInt32 sp_last_event_modifiers = 0;

UInt32 spGetLastEventModifiersMac(void)
{
#if TARGET_API_MAC_CARBON
    return GetCurrentKeyModifiers();
#else
    return sp_last_event_modifiers;
#endif
}

int spDispatchEventNonCarbonMac(spTopLevel toplevel, unsigned long sleep)
{
    int flag = 0;
    EventRecord	event;

#if defined(DISPATCH_MUTEX_LOCK)
    spUnlockMainMutexMac();
#endif
    
    if (WaitNextEvent(everyEvent, &event, (UInt32)sleep, 0L)) {
	flag = 1;
    }
    sp_last_event_modifiers = event.modifiers;
    
#if defined(DISPATCH_MUTEX_LOCK)
    spLockMainMutexMac();
#endif

    if (flag) {
	flag = 0;
	if (spHandleEventMac(&event) == SP_TRUE) {
	    flag = 1;
	}
    } else {
	spHandleIdleMac(&event);
    }
    
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	spYieldThread();
    }
    
    return flag;
}

int spDispatchEventMac(spTopLevel toplevel, unsigned long sleep)
{
#if TARGET_API_MAC_CARBON
    if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	return spDispatchEventCarbonMac(toplevel, sleep);
    }
#endif

    return spDispatchEventNonCarbonMac(toplevel, sleep);
}
    
int spDispatchEventEffectiveMac(spTopLevel toplevel)
{
    int flag;
    
    if (spIsAquaMac() == SP_TRUE) {
	if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	    if (spIsLowLevelThreadUsed() == SP_TRUE) {
		/* using pthread */
		flag = spDispatchEventMac(toplevel, 0x7FFFFFFF);
	    } else {
		flag = spDispatchEventMac(toplevel, 0);
	    }
	} else {
	    flag = spDispatchEventMac(toplevel, 1);
	}
    } else {
	flag = spDispatchEventMac(toplevel, 1);
    }

    return flag;
}

int spDispatchEventArch(spTopLevel toplevel)
{
    int flag;
    
    if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	flag = spDispatchEventMac(toplevel, 0);
    } else {
	flag = spDispatchEventMac(toplevel, 1);
    }

    return flag;
}
    
int spMainLoopArch(spTopLevel toplevel)
{
    while (1) {
	spDispatchEventEffectiveMac(toplevel);
    }
    
    return 0;
}

GrafPtr spThreadEnterMac(GrafPtr new_port)
{
    GrafPtr old_port = nil;

#if defined(DISPATCH_MUTEX_LOCK)
    spLockMainMutexMac();
#elif defined(MACOSX)
    spLockMainMutexForThreadMac();
#endif

    GetPort(&old_port);
    if (new_port != nil) SetPort(new_port);
    
    return old_port;
}

GrafPtr spThreadLeaveMac(GrafPtr new_port)
{
    GrafPtr old_port = nil;

    GetPort(&old_port);
    if (new_port != nil) SetPort(new_port);

#if defined(DISPATCH_MUTEX_LOCK)
    spUnlockMainMutexMac();
#elif defined(MACOSX)
    spUnlockMainMutexForThreadMac();
#endif
    spYieldThread();
    
    return old_port;
}

static GrafPtr sp_old_port = nil;

spBool spThreadEnterArch(spTopLevel toplevel)
{
    sp_old_port = spThreadEnterMac(nil);
    
    return SP_TRUE;
}

spBool spThreadLeaveArch(spTopLevel toplevel)
{
    spThreadLeaveMac(sp_old_port);
    
    return SP_TRUE;
}
