/*
 *	spComboBox_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spComboBoxP.h>

void spComboBoxCreateArch(spComponent component)
{
    SpPrimitiveArch(component).widget = gtk_combo_new();
    
    gtk_entry_set_editable(GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
			   (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
    
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    return;
}

void spComboBoxSetParamsArch(spComponent component)
{
    if (SpTextPart(SpOldObject(component)).editable != SpTextPart(component).editable) {
	gtk_entry_set_editable(GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
			       (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
    }
    
    return;
}
