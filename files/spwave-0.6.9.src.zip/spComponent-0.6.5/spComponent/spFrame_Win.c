/*
 *	spFrame_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spButton.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>

extern spTopLevel sp_toplevel;

static spBool sp_main_frame_created = SP_FALSE;

void spFramePartInitArch(spComponent component)
{
    SpFrameArch(component).task_tray_added = SP_FALSE;
    memset(&SpFrameArch(component).nicon, 0, sizeof(NOTIFYICONDATA));
    SpFrameArch(component).hfocus_text = NULL;
    SpFrameArch(component).drop_call_func = NULL;
    SpFrameArch(component).drop_call_data = NULL;
    
    return;
}

void spFramePartFreeArch(spComponent component)
{
    return;
}

static void getDesktopCenter(int *x, int *y)
{
    HWND hdesk;
    RECT rect;
    
    hdesk = GetDesktopWindow();
    GetClientRect(hdesk, &rect);

    if (x != NULL) {
	*x = (rect.right - rect.left) / 2;
    }
    if (x != NULL) {
	*y = (rect.bottom - rect.top) / 2;
    }

    return;
}

static void getDesktopSize(int *width, int *height)
{
    HWND hdesk;
    RECT rect;
    
    hdesk = GetDesktopWindow();
    GetClientRect(hdesk, &rect);

    if (width != NULL) {
	*width = (rect.right - rect.left);
    }
    if (height != NULL) {
	*height = (rect.bottom - rect.top);
    }

    return;
}

void spFrameCreateArch(spComponent component)
{
    char *title = NULL;
    char *icon_name = NULL;
    DWORD dwexstyle = WS_EX_CONTROLPARENT;
    DWORD dwstyle = WS_CLIPCHILDREN;
    HMENU hsysmenu = NULL;

    if (!strnone(SpFramePart(component).icon_name)) {
	icon_name = SpFramePart(component).icon_name;
    }
    
    if (!strnone(SpComponentPart(component).title)) {
	title = SpComponentPart(component).title;
    }

    if (title == NULL) {
	if (icon_name != NULL) {
	    title = icon_name;
	} else {
	    title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
	}
    }
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE
	&& sp_main_frame_created == SP_FALSE) {
	sp_main_frame_created = SP_TRUE;
    }
    
    if (SpFramePart(component).window_type == SP_DIALOG_WINDOW) {
	dwstyle |= WS_CAPTION | WS_SYSMENU;
    } else if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	dwstyle |= WS_POPUP | WS_CLIPCHILDREN;
	dwexstyle |= WS_EX_TOOLWINDOW;
    } else {
	dwstyle |= WS_CAPTION | WS_SYSMENU;
    }
    
    if (SpFramePart(component).window_type != SP_TRANSIENT_WINDOW) {
	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    dwstyle |= WS_MAXIMIZEBOX | WS_SIZEBOX | WS_SYSMENU;
	} else {
	    dwstyle &= (~WS_MAXIMIZEBOX);
	    dwstyle &= (~WS_SIZEBOX);
	}
	if (SpFramePart(component).iconfy_flag == SP_TRUE) {
	    dwstyle |= WS_MINIMIZEBOX | WS_SYSMENU;
	} else {
	    dwstyle &= (~WS_MINIMIZEBOX);
	}
    }

    if (SpComponentPart(component).x == 0
	&& SpComponentPart(component).y == 0) {
	int width, height;
	static int x = SP_INIT_WINDOW_X_POS;
	static int y = SP_INIT_WINDOW_Y_POS;
	
	getDesktopSize(&width, &height);
	
	SpComponentPart(component).x = x;
	SpComponentPart(component).y = y;
	if (x > width / 3 || y > height / 3) {
	    x = SP_INIT_WINDOW_X_POS;
	    y = SP_INIT_WINDOW_Y_POS;
	} else {
	    x += SP_WINDOW_X_INCR;
	    y += SP_WINDOW_Y_INCR;
	}
    }
    
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(dwexstyle,
		       SP_WINDOW_CLASS_NAME,
		       title,
		       dwstyle,
		       SpComponentPart(component).x,
		       SpComponentPart(component).y,
		       SP_DEFAULT_WINDOW_WIDTH,
		       SP_DEFAULT_WINDOW_HEIGHT,
		       HWND_DESKTOP,
		       NULL,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    if (SpFramePart(component).window_type != SP_TRANSIENT_WINDOW) {
	hsysmenu = GetSystemMenu(SpPrimitiveArch(component).hwnd, FALSE);
	if (SpFramePart(component).close_style == SP_NO_CLOSE) {
	    EnableMenuItem(hsysmenu, SC_CLOSE,
			   MF_BYCOMMAND | MF_GRAYED);
	}
	if (SpFramePart(component).resize_flag == SP_FALSE) {
	    EnableMenuItem(hsysmenu, SC_SIZE,
			   MF_BYCOMMAND | MF_GRAYED);
	    EnableMenuItem(hsysmenu, SC_MAXIMIZE,
			   MF_BYCOMMAND | MF_GRAYED);
	}
    }

    return;
}

void spFrameDestroyArch(spComponent component)
{
    return;
}
    
void spFrameSetParamsArch(spComponent component)
{
    char *title = NULL;
    char *icon_name = NULL;
    HMENU hsysmenu = NULL;

    if (SpFramePart(SpOldObject(component)).icon_name != SpFramePart(component).icon_name) {    
	if (!strnone(SpFramePart(component).icon_name)) {
	    icon_name = SpFramePart(component).icon_name;
	}
    }
    
    if (SpFramePart(SpOldObject(component)).close_style != SpFramePart(component).close_style) {
	hsysmenu = GetSystemMenu(SpPrimitiveArch(component).hwnd, FALSE);
	if (SpFramePart(component).close_style == SP_NO_CLOSE) {
	    EnableMenuItem(hsysmenu, SC_CLOSE,
			   MF_BYCOMMAND | MF_GRAYED);
	} else {
	    EnableMenuItem(hsysmenu, SC_CLOSE,
			   MF_BYCOMMAND | MF_ENABLED);
	}
    }
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	if (!strnone(SpComponentPart(component).title)) {
	    title = SpComponentPart(component).title;
	}
    }

    if (title != NULL) {
	SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
		    (WPARAM)0, (LPARAM)(LPCTSTR)title);
    } else if (icon_name != NULL) {
	SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
		    (WPARAM)0, (LPARAM)(LPCTSTR)icon_name);
    }

    return;
}

void *spGetArchFrame(spComponent component)
{
    return (void *)SpPrimitiveArch(component).hwnd;
}

spBool spIsTaskTraySupported(void)
{
    return SP_TRUE;
}

spBool spShowTaskTrayArch(spComponent window, spBool flag)
{
    char *icon_name;
    char *message;
    HICON hIcon;

    spDebug(10, "spShowTaskTrayArch", "in\n");

    SpFrameArch(window).nicon.cbSize = sizeof(NOTIFYICONDATA);
    SpFrameArch(window).nicon.uID = 1;
    
    if (flag == SP_TRUE) {
	if (SpPrimitiveArch(window).realize_flag == SP_FALSE) {
	    if (SpPrimitiveArch(window).hmenu != NULL) {
		SetMenu(SpPrimitiveArch(window).hwnd, SpPrimitiveArch(window).hmenu);
	    }
	    ShowWindow(SpPrimitiveArch(window).hwnd, SW_HIDE);
	    if (SpFramePart(window).window_type == SP_TRANSIENT_WINDOW) {
		spAdjustComponentSize(window);
	    }
	    SpPrimitiveArch(window).realize_flag = SP_TRUE;
	    UpdateWindow(SpPrimitiveArch(window).hwnd);
	}
	
	if (!strnone(SpFramePart(window).task_tray_icon)) {
	    icon_name = SpFramePart(window).task_tray_icon;
	} else if (!strnone(SpTopLevelPart(sp_toplevel).icon_name)) {
	    icon_name = SpTopLevelPart(sp_toplevel).icon_name;
	} else {
	    icon_name = NULL;
	}

	if (icon_name != NULL) {
	    spDebug(10, "spShowTaskTrayArch", "icon_name = %s\n", icon_name);
	    if ((hIcon = LoadIcon(SpTopLevelArch(sp_toplevel).hThisInst,
				  icon_name)) == NULL) {
		return SP_FALSE;
	    }
	} else {
	    if ((hIcon = LoadIcon(NULL, IDI_WINLOGO)) == NULL) {
		return SP_FALSE;
	    }
	}
	
	SpFrameArch(window).nicon.hWnd = SpPrimitiveArch(window).hwnd;
	SpFrameArch(window).nicon.uFlags = NIF_ICON | NIF_MESSAGE;
	SpFrameArch(window).nicon.hIcon = hIcon;
	SpFrameArch(window).nicon.uCallbackMessage = WM_TASKTRAY;

	if (!strnone(SpFramePart(window).task_tray_tip)) {
	    message = SpFramePart(window).task_tray_tip;
	} else if (!strnone(SpComponentPart(window).description)) {
	    message = SpComponentPart(window).description;
	} else {
	    message = spGetTitle(window);
	}
	if (!strnone(message)) {
	    spDebug(10, "spShowTaskTrayArch", "tip = %s\n", message);
	    SpFrameArch(window).nicon.uFlags |= NIF_TIP;
	    strcpy(SpFrameArch(window).nicon.szTip, message);
	}
	
	if (SpFrameArch(window).task_tray_added == SP_FALSE) {
	    Shell_NotifyIcon(NIM_ADD, &SpFrameArch(window).nicon);
	    SpFrameArch(window).task_tray_added = SP_TRUE;
	} else {
	    Shell_NotifyIcon(NIM_MODIFY, &SpFrameArch(window).nicon);
	}
    } else {
	if (SpFrameArch(window).task_tray_added == SP_TRUE) {
	    Shell_NotifyIcon(NIM_DELETE, &SpFrameArch(window).nicon);
	    SpFrameArch(window).task_tray_added = SP_FALSE;
	}
    }

    return SP_TRUE;
}

static spComponent sp_grabbed_window = NULL;

void spRemoveGrabWin(spComponent window)
{
    spComponent first_window, next_window;
    
    if (sp_grabbed_window != NULL
	&& (window == NULL || sp_grabbed_window == window)) {
	window = sp_grabbed_window;

	next_window = spGetNextWindow(window, SP_TRUE);
	first_window = next_window;
	while (next_window != window && spIsCreated(next_window) == SP_TRUE) {
	    if (spIsPrimitive(next_window) == SP_TRUE
		&& SpPrimitiveArch(next_window).hwnd != NULL) {
		EnableWindow(SpPrimitiveArch(next_window).hwnd,
			     SpComponentPart(next_window).sensitive_flag);
	    }
	    next_window = spGetNextWindow(next_window, SP_TRUE);

	    if (next_window == first_window) {
		break;
	    }
	}
	
	sp_grabbed_window = NULL;
    }
    
    return;
}

spComponent spAddGrabWin(spComponent window)
{
    spComponent prev = NULL;
    spComponent next_window;

    if (sp_grabbed_window != NULL) {
	prev = sp_grabbed_window;
	spRemoveGrabWin(NULL);
    }
    
    if (spIsCreated(window) == SP_TRUE) {
	next_window = spGetNextWindow(window, SP_TRUE);
	while (next_window != window && spIsCreated(next_window) == SP_TRUE) {
	    if (spIsPrimitive(next_window) == SP_TRUE
		&& SpPrimitiveArch(next_window).hwnd != NULL) {
		EnableWindow(SpPrimitiveArch(next_window).hwnd, FALSE);
	    }
	    next_window = spGetNextWindow(next_window, SP_TRUE);
	}
	
	sp_grabbed_window = window;
    }
    
    return prev;
}

static spBool setFramePosition(spComponent window, int *x, int *y)
{
    RECT rect;
    int width, height;

    getDesktopSize(&width, &height);
    
    while (*x >= width) {
	*x -= width;
    }
    while (*x < 0) {
	*x += width;
    }
    
    while (*y >= height) {
	*y -= height;
    }
    while (*y < 0) {
	*y += height;
    }
    spDebug(10, "setFramePosition", "x = %d, y = %d\n", *x, *y);
    
    GetWindowRect(SpPrimitiveArch(window).hwnd, &rect);
    MoveWindow(SpPrimitiveArch(window).hwnd,
	       *x, *y, rect.right - rect.left, rect.bottom - rect.top, TRUE);

    return SP_TRUE;
}

void spPopupFrameArch(spComponent window, spBool move_cursor)
{
    spDebug(30, "spPopupFrameArch", "in\n");
    
    if (SpPrimitiveArch(window).realize_flag == SP_FALSE) {
	if (SpPrimitiveArch(window).hmenu != NULL) {
	    SetMenu(SpPrimitiveArch(window).hwnd, SpPrimitiveArch(window).hmenu);
	}
	ShowWindow(SpPrimitiveArch(window).hwnd, SpTopLevelArch(sp_toplevel).nWinMode);
	spDebug(50, "spPopupFrameArch", "show window done\n");
	
	if (SpFramePart(window).window_type == SP_TRANSIENT_WINDOW) {
	    spAdjustComponentSize(window);
	}
	if (spIsButton(SpFramePart(window).default_button) == SP_TRUE) {
	    SendMessage(SpPrimitiveArch(SpFramePart(window).default_button).hwnd,
			BM_SETSTYLE, (WPARAM)BS_DEFPUSHBUTTON, TRUE);
	}
	
	SpPrimitiveArch(window).realize_flag = SP_TRUE;
    } else {
	ShowWindow(SpPrimitiveArch(window).hwnd, SW_RESTORE);
	SetForegroundWindow(SpPrimitiveArch(window).hwnd);
    }
    UpdateWindow(SpPrimitiveArch(window).hwnd);
    
    if (SpFramePart(window).task_tray_visible == SP_TRUE
	&& SpFrameArch(window).task_tray_added == SP_FALSE) {
	spShowTaskTrayArch(window, SpFramePart(window).task_tray_visible);
    }

    if (SpFramePart(window).popup_style == SP_MODAL_POPUP) {
	HWND hwnd;
	spComponent prev_grabbed;
	
	prev_grabbed = spAddGrabWin(window);
	
	hwnd = SpPrimitiveArch(window).hwnd;
	
	spDebug(30, "spPopupFrameArch", "loop in\n");
	while (1) {
	    spWaitEvent(sp_toplevel);
	    
	    if (hwnd == NULL || IsWindowVisible(hwnd) == FALSE) {
		break;
	    }
	}
	spDebug(30, "spPopupFrameArch", "loop end\n");

	spAddGrabWin(prev_grabbed);
    }
	
    spDebug(30, "spPopupFrameArch", "done\n");
    
    return;
}

void spPopdownFrameArch(spComponent window)
{
    spRemoveGrabWin(NULL);
    
    if (SpPrimitiveArch(window).hwnd != NULL) {
	ShowWindow(SpPrimitiveArch(window).hwnd, SW_HIDE);
    }
    
    spDebug(30, "spPopdownFrameArch", "done\n");

    return;
}

void spRaiseFrameArch(spComponent window)
{
    SetWindowPos(SpPrimitiveArch(window).hwnd, HWND_TOP,
		 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SetForegroundWindow(SpPrimitiveArch(window).hwnd);
    return;
}

void spLowerFrameArch(spComponent window)
{
    SetWindowPos(SpPrimitiveArch(window).hwnd, HWND_BOTTOM,
		 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    
    return;
}

spBool spSetFramePositionArch(spComponent window, int x, int y)
{
    return setFramePosition(window, &x, &y);
}

spBool spGetFramePositionArch(spComponent window, int *x, int *y)
{
    RECT rect;
    
    GetWindowRect(SpPrimitiveArch(window).hwnd, &rect);
    
    *x = rect.left;
    *y = rect.top;
    
    return SP_TRUE;
}

spBool spGetFrameModifierKeyMaskArch(spComponent window, spModifierMask *mask)
{
    *mask = 0L;
    
    if (GetAsyncKeyState(VK_SHIFT) & 0x8000) {
	*mask |= SP_SHIFT_MASK;
    }
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) {
	*mask |= SP_CONTROL_MASK;
    }
    if (GetAsyncKeyState(VK_MENU) & 0x8000) {
	*mask |= SP_ALT_MASK;
    }
    if (LOBYTE(GetKeyState(VK_CAPITAL))) {
	*mask |= SP_LOCK_MASK;
    }
    
    return SP_TRUE;
}

spBool spAddDropCallbackArch(spComponent component, spDropCallbackFunc call_func, void *call_data)
{
    if (call_func == NULL) {
	DragAcceptFiles(SpPrimitiveArch(component).hwnd, FALSE);
	SpFrameArch(component).drop_call_func = NULL;
	SpFrameArch(component).drop_call_data = NULL;
    } else {
	if (SpFrameArch(component).drop_call_func == NULL) {
	    DragAcceptFiles(SpPrimitiveArch(component).hwnd, TRUE);
	}
	SpFrameArch(component).drop_call_func = call_func;
	SpFrameArch(component).drop_call_data = call_data;
    }

    return SP_TRUE;
}
