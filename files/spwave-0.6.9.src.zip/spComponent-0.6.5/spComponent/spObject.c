/*
 *	spObject.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spObjectP.h>

spBool spIsObjectCreated(spObject object)
{
    if (object != NULL) {
	/*spDebug(100, "spIsObjectCreated", "flag = %d\n", object->object.create_flag);*/
	return object->object.create_flag;
    } else {
	return SP_FALSE;
    }
}

spBool spNoParam(spParam param)
{
    if (strnone(param)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spEqParam(spParam param1, spParam param2)
{
    if ((param1 == NULL && param2 == NULL) || streq(param1, param2)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spParamType spGetParamType(spParam param)
{
    static spParamType enum_type = SP_TYPE_NONE;
    
    if (spNoParam(param) == SP_TRUE) return SP_FALSE;

    if (param[0] == 'e') {
	if (enum_type == SP_TYPE_NONE) {
	    enum {SP_DUMMY1, SP_DUMMY2} dummy;
	
	    if (sizeof(dummy) == sizeof(char)) {
		enum_type = SP_TYPE_CHAR;
	    } else if (sizeof(dummy) == sizeof(short)) {
		enum_type = SP_TYPE_SHORT;
	    } else if (sizeof(dummy) == sizeof(long)) {
		enum_type = SP_TYPE_LONG;
	    } else {
		enum_type = SP_TYPE_INT;
	    }
	    spDebug(60, "spGetParamType", "enum_type = %d\n",
		    (int)enum_type);
	}
	return enum_type;
    } else if (param[0] == 'b') {
	return SP_TYPE_BOOL;
    } else if (param[0] == 'i') {
	return SP_TYPE_INT;
    } else if (param[0] == 's') {
	return SP_TYPE_SHORT;
    } else if (param[0] == 'l') {
	return SP_TYPE_LONG;
    } else if (param[0] == 'f') {
	return SP_TYPE_FLOAT;
    } else if (param[0] == 'd') {
	return SP_TYPE_DOUBLE;
    } else if (param[0] == 'c') {
	return SP_TYPE_CHAR;
    } else if (param[0] == 'S') {
	return SP_TYPE_STRING;
    } else if (param[0] == 'L') {
	return SP_TYPE_STRINGS;
    } else if (param[0] == 'P') {
	return SP_TYPE_POINTER;
    } else if (param[0] == 'F') {
	return SP_TYPE_FUNCTION;
    }
    
    return SP_TYPE_NONE;
}

void spInitObjectParams(spObject object)
{
    int j;
    int offset;
    spObjectClass object_class;

    if (object == NULL) return;
    
    object_class = SpGetObjectClass(object);
    
    while (object_class != NULL) {
	spDebug(80, "spInitObjectParams", "num_param_table = %d\n",
		object_class->object.num_param_table);
    
	for (j = 0; j < object_class->object.num_param_table; j++) {
	    spDebug(80, "spInitObjectParams", "j = %d, offset = %d\n",
		    j, object_class->object.param_tables[j].param_offset);
    
	    offset = object_class->object.param_tables[j].param_offset;
	    spDebug(80, "spInitObjectParams", "param = %s\n",
		    object_class->object.param_tables[j].param);
	    if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_BOOL) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(spBool *)((char *)object + offset)
			= spStrToBool(object_class->object.param_tables[j].param_default);
		} else {
		    *(spBool *)((char *)object + offset) = SP_FALSE;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_INT) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(int *)((char *)object + offset)
			= atoi(object_class->object.param_tables[j].param_default);
		} else {
		    *(int *)((char *)object + offset) = 0;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_SHORT) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(short *)((char *)object + offset)
			= (short)atoi(object_class->object.param_tables[j].param_default);
		} else {
		    *(short *)((char *)object + offset) = 0;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_LONG) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(long *)((char *)object + offset)
			= (long)atoi(object_class->object.param_tables[j].param_default);
		} else {
		    *(long *)((char *)object + offset) = 0;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FLOAT) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(float *)((char *)object + offset)
			= (float)atof(object_class->object.param_tables[j].param_default);
		} else {
		    *(float *)((char *)object + offset) = 0.0;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_DOUBLE) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(double *)((char *)object + offset)
			= atof(object_class->object.param_tables[j].param_default);
		} else {
		    *(double *)((char *)object + offset) = 0.0;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_CHAR) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(char *)((char *)object + offset)
			= object_class->object.param_tables[j].param_default[0];
		} else {
		    *(char *)((char *)object + offset) = NUL;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    *(char **)((char *)object + offset)
			= strclone(object_class->object.param_tables[j].param_default);
		} else {
		    *(char **)((char *)object + offset) = NULL;
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING_A) {
		if (object_class->object.param_tables[j].param_default != NULL) {
		    strcpy((char *)((char *)object + offset),
			   object_class->object.param_tables[j].param_default);
		} else {
		    strcpy((char *)((char *)object + offset), "");
		}
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRINGS) {
#if 1
		*(char ***)((char *)object + offset) = NULL;
#else
		*(char **)((char *)object + offset) = NULL;
#endif
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FUNCTION) {
		*(char **)((char *)object + offset) = NULL;
	    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_POINTER) {
		*(char **)((char *)object + offset) = NULL;
	    }
	}
	object_class = (spObjectClass)object_class->object.super_class;
    }
	    
    spDebug(80, "spInitObjectParams", "done\n");
    
    return;
}

void spFreeObjectParams(spObject object)
{
    int j;
    int offset;
    spObjectClass object_class;
    
    if (object == NULL) return;

    object_class = SpGetObjectClass(object);
    
    while (object_class != NULL) {
	spDebug(60, "spFreeObjectParams", "class_name = %s\n", object_class->object.class_name);
	
	for (j = 0; j < object_class->object.num_param_table; j++) {
	    spDebug(80, "spFreeObjectParams", "j = %d, offset = %d\n",
		    j, object_class->object.param_tables[j].param_offset);
    
	    offset = object_class->object.param_tables[j].param_offset;
	    spDebug(80, "spFreeObjectParams", "param = %s\n",
		    object_class->object.param_tables[j].param);
	    
	    if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING) {
		if (*(char **)((char *)object + offset) != NULL) {
		    xfree(*(char **)((char *)object + offset));
		}
		*(char **)((char *)object + offset) = NULL;
	    }
	}
	object_class = (spObjectClass)object_class->object.super_class;
    }

    if (object->object.old_object != NULL) {
	xfree(object->object.old_object);
	object->object.old_object = NULL;
    }
    
    spDebug(60, "spFreeObjectParams", "done\n");
    
    return;
}

void spSetObjectParamsArg(spObject object, spArg *args, int num_arg)
{
    int i, j;
    int offset;
    spBool created;
    spObjectClass object_class;
    spObject old_object;
    int num_free_list = 0;
    char *free_list[SP_MAX_NUM_ARG];
    
    if (object == NULL) return;

    created = spIsObjectCreated(object);

    object_class = SpGetObjectClass(object);
    
    if (object->object.old_object != NULL) {
	xfree(object->object.old_object);
	object->object.old_object = NULL;
    }
	
    /* copy old data to old_object */
    if (created == SP_TRUE) {
	old_object = (spObject)xalloc(object_class->object.object_size, char);
	memmove((char *)old_object, (char *)object, object_class->object.object_size);
	object->object.old_object = old_object;
    }

    while (object_class != NULL) {
	spDebug(60, "spSetObjectParamsArg", "class_name = %s, num_arg = %d\n",
		object_class->object.class_name, num_arg);
	for (i = 0; i < num_arg; i++) {
	    for (j = 0; j < object_class->object.num_param_table; j++) {
		if (created == SP_TRUE
		    && !(object_class->object.param_tables[j].param_access & SP_SET_ACCESS)) {
		    continue;
		} else if (!(object_class->object.param_tables[j].param_access & SP_CREATE_ACCESS)) {
		    continue;
		}
		if (spEqParam(args[i].param, SppNone)) {
		    break;
		} else if (spEqParam(object_class->object.param_tables[j].param,
				     args[i].param)) {
		    spDebug(60, "spSetObjectParamsArg", "param = %s\n", args[i].param);
		    offset = object_class->object.param_tables[j].param_offset;
		    if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_BOOL) {
			*(spBool *)((char *)object + offset) = (spBool)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_INT) {
			*(int *)((char *)object + offset) = (int)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_SHORT) {
			*(short *)((char *)object + offset) = (short)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_LONG) {
			*(long *)((char *)object + offset) = (long)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FLOAT) {
			*(float *)((char *)object + offset) = (float)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_DOUBLE) {
			*(double *)((char *)object + offset) = (double)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_CHAR) {
			*(char *)((char *)object + offset) = (char)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING) {
			if ((char *)args[i].value != NULL) {
			    if (*(char **)((char *)object + offset) != NULL) {
			        free_list[num_free_list] = *(char **)((char *)object + offset);
				num_free_list++;
			    }
			    *(char **)((char *)object + offset) = strclone((char *)args[i].value);
			}
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING_A) {
			strcpy((char *)((char *)object + offset), (char *)args[i].value);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRINGS) {
#if 1
			*(char ***)((char *)object + offset) = (char **)args[i].value;
#else
			*(char **)((char *)object + offset) = (char *)args[i].value;
#endif
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FUNCTION) {
			*(char **)((char *)object + offset) = (char *)args[i].value;
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_POINTER) {
			*(char **)((char *)object + offset) = (char *)args[i].value;
		    }
		}
	    }
	}
	object_class = (spObjectClass)object_class->object.super_class;
    }

    object_class = SpGetObjectClass(object);
    while (object_class != NULL) {
	if (created == SP_FALSE) {
	    if (object_class->object.create != NULL) {
		object_class->object.create(object);
		object->object.create_flag = SP_TRUE;
		break;
	    }
	} else {
	    if (object_class->object.set_params != NULL) {
		object_class->object.set_params(object);
		break;
	    }
	}
		
	object_class = object_class->object.super_class;
    }

    if (num_free_list > 0) {
	for (i = 0; i < num_free_list; i++) {
	    xfree(free_list[i]);
	}
    }

    if (object->object.old_object != NULL) {
	xfree(object->object.old_object);
	object->object.old_object = NULL;
    }
    
    spDebug(60, "spSetObjectParamsArg", "done\n");
    
    return;
}

void spSetObjectParams(spObject object, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (object == NULL) return;
    
    va_start(argp, object);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetObjectParamsArg(object, args, num_arg);

    return;
}
    
void spGetObjectParamsArg(spObject object, spArg *args, int num_arg)
{
    int i, j;
    int offset;
    spObjectClass object_class;
    
    if (object == NULL) return;

    object_class = SpGetObjectClass(object);
    
    while (object_class != NULL) {
	for (i = 0; i < num_arg; i++) {
	    for (j = 0; j < object_class->object.num_param_table; j++) {
		if (!(object_class->object.param_tables[j].param_access & SP_GET_ACCESS)) {
		    continue;
		}
		if (spEqParam(args[i].param, SppNone)) {
		    break;
		} else if (spEqParam(object_class->object.param_tables[j].param,
				     args[i].param)) {
		    offset = object_class->object.param_tables[j].param_offset;
		    if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_BOOL) {
			*(spBool *)args[i].value = *(spBool *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_INT) {
			*(int *)args[i].value = *(int *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_SHORT) {
			*(short *)args[i].value = *(short *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_LONG) {
			*(long *)args[i].value = *(long *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FLOAT) {
			*(float *)args[i].value = *(float *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_DOUBLE) {
			*(double *)args[i].value = *(double *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_CHAR) {
			*(char *)args[i].value = *(char *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING) {
			*(char **)args[i].value = *(char **)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRING_A) {
			*(char **)args[i].value = (char *)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_STRINGS) {
#if 1
			*(char ***)args[i].value = *(char ***)((char *)object + offset);
#else
			*(char **)args[i].value = *(char **)((char *)object + offset);
#endif
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_FUNCTION) {
			*(char **)args[i].value = *(char **)((char *)object + offset);
		    } else if (spGetParamType(object_class->object.param_tables[j].param) == SP_TYPE_POINTER) {
			*(char **)args[i].value = *(char **)((char *)object + offset);
		    }
		}
	    }
	}
	object_class = (spObjectClass)object_class->object.super_class;
    }

    return;
}

void spGetObjectParams(spObject object, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (object == NULL) return;
    
    va_start(argp, object);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spGetObjectParamsArg(object, args, num_arg);

    return;
}

spObject spAllocObject(spObjectClass object_class, char *class_name, char *name)
{
    int i;
    int num_class;
    spObject object;
    spObjectClass current_class;
    spObjectClass *classes;

    if (object_class == NULL) return NULL;
    
    spDebug(80, "spAllocObject", "object_size = %d\n", object_class->object.object_size);
    
    object = (spObject)xalloc(object_class->object.object_size, char);
    object->object.object_class = object_class;
    if (!strnone(class_name)) {
	object->object.class_name = strclone(class_name);
    } else {
	object->object.class_name = NULL;
    }
    if (!strnone(name)) {
	object->object.name = strclone(name);
    } else {
	object->object.name = NULL;
    }
    object->object.create_flag = SP_FALSE;
    object->object.old_object = NULL;

    spDebug(80, "spAllocObject", "allocation done\n");
    
    spInitObjectParams(object);

    num_class = 0;
    current_class = object_class;
    while (current_class != NULL) {
	num_class++;
	current_class = current_class->object.super_class;
    }

    spDebug(80, "spAllocObject", "num_class = %d\n", num_class);
    
    if (num_class >= 1) {
	classes = xalloc(num_class, spObjectClass);
	
	current_class = object_class;
	for (i = 0; i < num_class; i++) {
	    classes[i] = current_class;
	    current_class = current_class->object.super_class;
	}
	
	for (i = num_class - 1; i >= 0; i--) {
	    current_class = classes[i];
	    if (current_class->object.object_part_init != NULL) {
		current_class->object.object_part_init(object);
	    }
	    spDebug(80, "spAllocObject", "class_name = %s\n",
		    current_class->object.class_name);
	}
	
	xfree(classes);
    }
    
    spDebug(80, "spAllocObject", "done\n");
    
    return object;
}

spObject spCreateObjectArg(spObjectClass object_class, char *class_name,
			   char *name, spArg *args, int num_arg)
{
    spObject object;

    if (object_class == NULL)
	return NULL;
    
    if ((object = spAllocObject(object_class, class_name, name)) == NULL) {
	return NULL;
    }
    
    spSetObjectParamsArg(object, args, num_arg);

    return object;

}
    
void spFreeObject(spObject object)
{
    spObjectClass object_class;
    
    if (object != NULL) {
	spDebug(60, "spFreeObject", "in\n");
	
	object->object.create_flag = SP_FALSE;

	spFreeObjectParams(object);
	
	object_class = object->object.object_class;
	spDebug(60, "spFreeObject", "class_name = %s\n", object_class->object.class_name);
	while (object_class != NULL) {
	    if (object_class->object.object_part_free != NULL) {
		object_class->object.object_part_free(object);
	    }
	    object_class = object_class->object.super_class;
	}
	if (object->object.class_name != NULL)
	    xfree(object->object.class_name);
	if (object->object.name != NULL)
	    xfree(object->object.name);
	xfree(object);
    }
    
    spDebug(60, "spFreeObject", "done\n");
    
    return;
}

void spDestroyObject(spObject object)
{
    spObjectClass object_class;

    if (spIsObjectCreated(object) == SP_FALSE) return;

    object->object.create_flag = SP_FALSE;
    
    object_class = SpGetObjectClass(object);

    while (object_class != NULL) {
	if (object_class->object.destroy != NULL) {
	    object_class->object.destroy(object);
	    break;
	}

	object_class = object_class->object.super_class;
    }

    spFreeObject(object);
    
    spDebug(60, "spDestroyObject", "done\n");
    
    return;
}
