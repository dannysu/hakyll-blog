/*
 *	spParamField.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spFrame.h>
#include <sp/spContainer.h>
#include <sp/spButton.h>
#include <sp/spDialog.h>

#include <sp/spParamFieldP.h>

#if defined(MACOS)
#pragma import on
#endif

extern spTopLevel sp_toplevel;

#if defined(MACOS)
#pragma import off
#endif

static spParamTable sp_param_field_param_tables[] = {
    {SppFieldType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.field_type), SP_FIELD_TYPE_TEXT_STRING},
    {SppSet, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.set), SP_TRUE_STRING},
    {SppBorderOn, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.border_on), SP_FALSE_STRING},
    {SppSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.size), "0"},
    {SppEditable, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.editable), SP_TRUE_STRING},
    {SppUseCheckBox, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.use_check_box), SP_FALSE_STRING},
    {SppFieldOffset, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.field_offset), "0"},
    {SppFieldSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.field_size), "0"},
    {SppDimensionSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.dim_size), "0"},
    {SppFieldString, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.string), NULL},
    {SppFieldStrings, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.strings), NULL},
    {SppDimension, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.dim_string), NULL},
    
    {SppFileFilters, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.file_filters), NULL},
    {SppFileTypes, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.file_types), NULL},
    {SppFileFilterIndex, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.filter_index), NULL},
    {SppInitialDir, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.initial_dir), NULL},
    {SppInitialFont, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.initial_font), NULL},
    {SppInitialColor, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spParamField, param_field.initial_color), NULL},
};

spParamFieldClassRec SpParamFieldClassRec = {
    /* spObjectClassPart */
    {
	SpParamField,
	(spObjectClass)&SpComponentClassRec,
	sizeof(spParamFieldRec),
	spArraySize(sp_param_field_param_tables),
	sp_param_field_param_tables,
	spParamFieldPartInit,
	spParamFieldPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spParamFieldCreate,
	spParamFieldDestroy,
	spParamFieldSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_TRUE,
	spParamFieldMap,
	spParamFieldUnmap,
	spParamFieldSetSize,
	spParamFieldGetSize,
	spParamFieldGetClientSize,
	spParamFieldSetSensitive,
	spParamFieldIsComponentType,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spParamFieldClassPart */
    {
	0,
    },
};

spComponentClass SpParamFieldClass = (spComponentClass)&SpParamFieldClassRec;

void spParamFieldPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpParamFieldPart(component).box = NULL;
    SpParamFieldPart(component).title_label = NULL;
    SpParamFieldPart(component).field = NULL;
    SpParamFieldPart(component).dim_label = NULL;

    SpComponentPart(component).orientation = SP_HORIZONTAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;
    SpComponentPart(component).spacing_flag = SP_TRUE;

    return;
}

void spParamFieldPartFree(spObject object)
{
    return;
}

static void checkBoxCB(spComponent component, spComponent param_field)
{
    if (spIsCreated(param_field) == SP_FALSE) return;
    
    if (spGetToggleState(component, &SpParamFieldPart(param_field).set) == SP_TRUE) {
	spSetSensitive(SpParamFieldPart(param_field).field,
		       SpParamFieldPart(param_field).set);
	if (SpParamFieldPart(param_field).dim_label != NULL) {
	    spSetSensitive(SpParamFieldPart(param_field).dim_label,
			   SpParamFieldPart(param_field).set);
	}
    }
    
    return;
}

static void pushButtonCB(spComponent component, spComponent param_field)
{
    char *string = NULL;
    char initial_dir[SP_MAX_PATHNAME];
    
    if (spIsCreated(param_field) == SP_FALSE) return;

    if (!strnone(SpParamFieldPart(param_field).initial_dir)) {
	spStrCopy(initial_dir, SP_MAX_PATHNAME, SpParamFieldPart(param_field).initial_dir);
    } else {
	strcpy(initial_dir, "");
	
	if (1 || strnone(SpParamFieldPart(param_field).string)) {
	    if (SpParamFieldPart(param_field).string != NULL)
		xfree(SpParamFieldPart(param_field).string);

	    SpParamFieldPart(param_field).string
		= xspGetTextString(SpParamFieldPart(param_field).field);
	    spStrCopy(initial_dir, sizeof(initial_dir), SpParamFieldPart(param_field).string);
	}
	
	if (SpParamFieldPart(param_field).field_type != SP_FIELD_TYPE_DIR_TEXT) {
	    if (spIsDir(initial_dir) == SP_FALSE) {
		spGetDirName(initial_dir);
	    }
	}
    }

    if (SpParamFieldPart(param_field).field_type == SP_FIELD_TYPE_OPEN_FILE_TEXT) {
	string = xspGetOpenFileName(component, NULL,
				    SppPathMustExist, SP_TRUE,
				    SppFileMustExist, SP_TRUE,
				    SppFileFilters, SpParamFieldPart(param_field).file_filters,
				    SppFileTypes, SpParamFieldPart(param_field).file_types,
				    SppFileFilterIndex, SpParamFieldPart(param_field).filter_index,
				    SppInitialDir, initial_dir,
				    NULL);
    } else if (SpParamFieldPart(param_field).field_type == SP_FIELD_TYPE_SAVE_FILE_TEXT) {
	string = xspGetSaveFileName(component, NULL,
				    SppPathMustExist, SP_TRUE,
				    SppFileMustExist, SP_FALSE,
				    SppOverwritePrompt, SP_TRUE,
				    SppFileFilters, SpParamFieldPart(param_field).file_filters,
				    SppFileTypes, SpParamFieldPart(param_field).file_types,
				    SppFileFilterIndex, SpParamFieldPart(param_field).filter_index,
				    SppInitialDir, initial_dir,
				    SppInitialFileName, SpParamFieldPart(param_field).string,
				    NULL);
    } else {
	string = xspGetSelectedDirName(component, NULL,
				       SppPathMustExist, SP_TRUE,
				       SppInitialDir, initial_dir,
				       NULL);
    }

    if (string != NULL) {
	char *readable;
	if ((readable = xspGetReadablePath(string)) != NULL) {
	    spSetTextString(SpParamFieldPart(param_field).field, readable);
	    xfree(readable);
	}
    
	xfree(string);
    }

    return;
}

void spParamFieldCreate(spObject object)
{
    char *string;
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (SpParentComponentPart(component).orientation == SP_HORIZONTAL) {
	SpComponentPart(component).width = SpParamFieldPart(component).size;
	SpComponentPart(component).height = 0;
    } else {
	SpComponentPart(component).width = 0;
	if (SpParamFieldPart(component).size == 0) {
	    SpParamFieldPart(component).size = SP_DEFAULT_TEXT_HEIGHT;
	    if (SpComponentPart(component).spacing_flag == SP_TRUE) {
		SpParamFieldPart(component).size += (2 * SpComponentPart(component).margin_height);
	    }
	}
	SpComponentPart(component).height = SpParamFieldPart(component).size;
    }
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;

    /* create main box */
    SpParamFieldPart(component).box =
	spCreateBox(SpGetParent(component), "_ParamField_Box",
		    SpParamFieldPart(component).size,
		    SppOrientation, SP_HORIZONTAL,
		    SppMarginWidth, SpComponentPart(component).margin_width,
		    SppMarginHeight, SpComponentPart(component).margin_height,
		    SppSpacing, SpComponentPart(component).spacing,
		    SppBorderOn, SpParamFieldPart(component).border_on,
		    NULL);
	
    /* create title label */
    string = (strnone(SpComponentPart(component).title) ?
	      SpGetName(component) : SpComponentPart(component).title);
    if (SpParamFieldPart(component).use_check_box == SP_TRUE) {
	SpParamFieldPart(component).title_label =
	    spCreateCheckBox(SpParamFieldPart(component).box, "_ParamField_TitleLabel",
			     SppTitle, string,
			     SppSet, SpParamFieldPart(component).set,
			     SppWidth, SpParamFieldPart(component).field_offset,
			     SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			     SppSpacingOn, SpComponentPart(component).spacing_flag,
			     SppCallbackFunc, checkBoxCB,
			     SppCallbackData, component,
			     NULL);
    } else {
	SpParamFieldPart(component).title_label =
	    spCreateLabel(SpParamFieldPart(component).box, "_ParamField_TitleLabel",
			  SppTitle, string,
			  SppAlignment, SP_ALIGNMENT_BEGINNING,
			  SppWidth, SpParamFieldPart(component).field_offset,
			  SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			  SppSpacingOn, SpComponentPart(component).spacing_flag,
			  NULL);
    }
    spDebug(80, "spParamFieldCreate", "create label done\n");
	
    /* create field */
    if (SpParamFieldPart(component).field_type == SP_FIELD_TYPE_COMBO_BOX) {
	spDebug(80, "spParamFieldCreate", "combo: field_size = %d\n",
		SpParamFieldPart(component).field_size);
	SpParamFieldPart(component).field =
	    spCreateComboBox(SpParamFieldPart(component).box, "_ParamField_ComboBox",
			     SppWidth, SpParamFieldPart(component).field_size,
			     SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			     SppSpacingOn, SpComponentPart(component).spacing_flag,
			     SppEditable, SpParamFieldPart(component).editable,
			     SppTextString, SpParamFieldPart(component).string,
			     SppListStrings, SpParamFieldPart(component).strings,
			     SppDescription, SpComponentPart(component).description,
			     SppCallbackFunc, SpComponentPart(component).call_func,
			     SppCallbackData, SpComponentPart(component).call_data,
			     SppUserData, SpComponentPart(component).user_data,
			     NULL);
    } else {
	spDebug(80, "spParamFieldCreate", "text: field_size = %d\n",
		SpParamFieldPart(component).field_size);
	SpParamFieldPart(component).field =
	    spCreateTextField(SpParamFieldPart(component).box, "_ParamField_TextField",
			      SppWidth, SpParamFieldPart(component).field_size,
			      SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			      SppSpacingOn, SpComponentPart(component).spacing_flag,
			      SppEditable, SpParamFieldPart(component).editable,
			      SppTextString, SpParamFieldPart(component).string,
			      SppDescription, SpComponentPart(component).description,
			      SppCallbackFunc, SpComponentPart(component).call_func,
			      SppCallbackData, SpComponentPart(component).call_data,
			      SppUserData, SpComponentPart(component).user_data,
			      NULL);
    }
    spDebug(80, "spParamFieldCreate", "create field done\n");

    if (SpParamFieldPart(component).field_type == SP_FIELD_TYPE_DIR_TEXT
	|| SpParamFieldPart(component).field_type == SP_FIELD_TYPE_OPEN_FILE_TEXT
	|| SpParamFieldPart(component).field_type == SP_FIELD_TYPE_SAVE_FILE_TEXT) {
	if (!strnone(SpParamFieldPart(component).dim_string)) {
	    string = SpParamFieldPart(component).dim_string;
	} else {
	    if (SpParamFieldPart(component).field_type == SP_FIELD_TYPE_DIR_TEXT) {
		string = SP_DIR_SELECTION_BUTTON;
	    } else {
		string = SP_FILE_SELECTION_BUTTON;
	    }
	}
	if (SpParamFieldPart(component).dim_size == 0) {
	    SpParamFieldPart(component).dim_size = (2 * SP_DEFAULT_BUTTON_WIDTH) / 3;
	}
	
	/* create selection button */
	SpParamFieldPart(component).dim_label =
	    spCreatePushButton(SpParamFieldPart(component).box, "_ParamField_DimensionLabel",
			       SppTitle, string,
			       SppWidth, SpParamFieldPart(component).dim_size,
			       SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			       SppSpacingOn, SpComponentPart(component).spacing_flag,
			       SppCallbackFunc, pushButtonCB,
			       SppCallbackData, component,
			       NULL);
    } else if (!strnone(SpParamFieldPart(component).dim_string)) {
	/* create dimension label */
	SpParamFieldPart(component).dim_label =
	    spCreateLabel(SpParamFieldPart(component).box, "_ParamField_DimensionLabel",
			  SppTitle, SpParamFieldPart(component).dim_string,
			  SppAlignment, SP_ALIGNMENT_BEGINNING,
			  /*SppWidth, -SpComponentPart(component).margin_width,*/
			  SppWidth, SpParamFieldPart(component).dim_size,
			  SppHeight, SP_DEFAULT_TEXT_HEIGHT,
			  SppSpacingOn, SpComponentPart(component).spacing_flag,
			  NULL);
    }
    spDebug(80, "spParamFieldCreate", "create dimension done\n");

    SpComponentPart(component).component = SpParamFieldPart(component).field;

    if (SpGetParent(component) != NULL) {
	SpGetWindow(component) = SpParentComponentPart(component).window;
    } else {
	SpGetWindow(component) = NULL;
    }

    return;
}

void spParamFieldDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spDestroyComponent(SpParamFieldPart(component).box);

    return;
}

void spParamFieldSetParams(spObject object)
{
    spComponent component = (spComponent)object;

    if (SpComponentPart(component).title != NULL) {
	spSetParams(SpParamFieldPart(component).title_label,
		    SppTitle, SpComponentPart(component).title,
		    NULL);
    }

    if (SpParamFieldPart(component).string != NULL) {
	spSetParams(SpParamFieldPart(component).field,
		    SppTextString, SpParamFieldPart(component).string,
		    NULL);
    }
    
    if (SpParamFieldPart(component).strings != NULL) {
	spSetParams(SpParamFieldPart(component).field,
		    SppListStrings, SpParamFieldPart(component).strings,
		    NULL);
    }

    if (SpParamFieldPart(component).dim_string != NULL
	&& SpParamFieldPart(component).dim_label != NULL) {
	spSetParams(SpParamFieldPart(component).dim_label,
		    SppTitle, SpParamFieldPart(component).dim_string,
		    NULL);
    }
    
    return;
}

void spParamFieldMap(spComponent component)
{
    spMapComponent(SpParamFieldPart(component).box);
    
    return;
}

void spParamFieldUnmap(spComponent component)
{
    spUnmapComponent(SpParamFieldPart(component).box);
    
    return;
}

spBool spParamFieldSetSize(spComponent component, int width, int height)
{
    return spSetSize(SpParamFieldPart(component).box, width, height);
}

spBool spParamFieldGetSize(spComponent component, int *width, int *height)
{
    return spGetSize(SpParamFieldPart(component).box, width, height);
}

spBool spParamFieldGetClientSize(spComponent component, int *width, int *height)
{
    return spGetClientSize(SpParamFieldPart(component).box, width, height);
}

spBool spParamFieldSetSensitive(spComponent component, spBool flag)
{
    return spSetSensitive(SpParamFieldPart(component).box, flag);
}

spBool spParamFieldIsComponentType(spComponent component, char *class_name)
{
    return SP_FALSE;
}

spBool spIsParamField(spComponent component)
{
    return spIsSubClass(component, SpParamField);
}

spComponent spCreateParamField(spComponent parent, char *name, int size, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, size);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetArg(args[num_arg], SppSize, size); num_arg++;
    
    return spCreateComponentArg(SpParamFieldClass, NULL, name, parent, args, num_arg);
}
