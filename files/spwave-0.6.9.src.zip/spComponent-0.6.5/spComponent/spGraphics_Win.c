/*
 *	spGraphics_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocale.h>

#include <sp/spTopLevelP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

spPixel spGetColorPixel(char *color_name)
{
    return spGetColorPixelNormal(color_name);
}

spBool spGetCursorArch(spCursor cursor)
{
    char *cursor_name;
    spCursorType cursor_type = cursor->type;
    
    switch (cursor_type) {
      case SP_CURSOR_TEXT:
	cursor_name = IDC_IBEAM;
	break;
      case SP_CURSOR_WAIT:
	cursor_name = IDC_WAIT;
	break;
      case SP_CURSOR_CROSS:
	cursor_name = IDC_CROSS;
	break;
      case SP_CURSOR_HAND:
#ifdef IDC_HAND
	cursor_name = IDC_HAND;
#else
	cursor_name = MAKEINTRESOURCE(32649);
#endif
	break;
      case SP_CURSOR_MOVE:
      case SP_CURSOR_SIZE:
	cursor_name = IDC_SIZEALL;
	break;
      case SP_CURSOR_SW_RESIZE:
	cursor_name = IDC_SIZENESW;
	break;
      case SP_CURSOR_SE_RESIZE:
	cursor_name = IDC_SIZENWSE;
	break;
      case SP_CURSOR_NW_RESIZE:
	cursor_name = IDC_SIZENWSE;
	break;
      case SP_CURSOR_NE_RESIZE:
	cursor_name = IDC_SIZENESW;
	break;
      case SP_CURSOR_N_RESIZE:
	cursor_name = IDC_SIZENS;
	break;
      case SP_CURSOR_S_RESIZE:
	cursor_name = IDC_SIZENS;
	break;
      case SP_CURSOR_W_RESIZE:
	cursor_name = IDC_SIZEWE;
	break;
      case SP_CURSOR_E_RESIZE:
	cursor_name = IDC_SIZEWE;
	break;
      default:
	cursor_name = IDC_ARROW;
	break;
    }

    if ((SpCursorArch(cursor).hcursor = LoadCursor(NULL, cursor_name)) == NULL) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

void spDestroyCursorArch(spCursor cursor)
{
    return;
}

void spSetGraphicsModeArch(spGraphics graphics, spGraphicsMode mode)
{
    if (graphics == NULL) return;
    
    switch (mode) {
      case SP_GM_COPY:
	SpGraphicsArch(graphics).mode = R2_COPYPEN;
	break;
      case SP_GM_XOR:
	SpGraphicsArch(graphics).mode = R2_XORPEN;
	break;
      case SP_GM_INVERT:
	SpGraphicsArch(graphics).mode = R2_NOTCOPYPEN;
	break;
      case SP_GM_AND:
	SpGraphicsArch(graphics).mode = R2_MASKPEN;
	break;
      case SP_GM_OR:
	SpGraphicsArch(graphics).mode = R2_MERGEPEN;
	break;
      default:
	break;
    }

    return;
}

void spGraphicsPartInitArch(spGraphics graphics)
{
    SpGraphicsArch(graphics).font = NULL;
    SpGraphicsArch(graphics).hdc = NULL;
    SpGraphicsArch(graphics).pen = NULL;
    SpGraphicsArch(graphics).brush = NULL;
    SpGraphicsArch(graphics).bg_brush = NULL;
    SpGraphicsArch(graphics).mode = R2_COPYPEN;

    return;
}

void spGraphicsPartFreeArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).pen != NULL) {
	DeleteObject(SpGraphicsArch(graphics).pen);
    }
    if (SpGraphicsArch(graphics).brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).brush);
    }
    if (SpGraphicsArch(graphics).bg_brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).bg_brush);
    }
    if (SpGraphicsArch(graphics).font != NULL) {
	DeleteObject(SpGraphicsArch(graphics).font);
    }

    return;
}

static int getLineType(spGraphics graphics)
{
    int style = PS_SOLID;

    if (graphics == NULL) return style;

    switch (SpGraphicsPart(graphics).line_type) {
      case SP_LINE_SOLID:
	style = PS_SOLID;
	break;
      case SP_LINE_DASH:
	style = PS_DASH;
	break;
      case SP_LINE_DOT:
	style = PS_DOT;
	break;
      case SP_LINE_DASH_DOT:
	style = PS_DASHDOT;
	break;
      case SP_LINE_DASH_DOT_DOT:
	style = PS_DASHDOTDOT;
	break;
      default:
	style = PS_NULL;
	break;
    }

    return style;
}

void spGraphicsCreateArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).pen != NULL) {
	DeleteObject(SpGraphicsArch(graphics).pen);
    }
    if (SpGraphicsArch(graphics).brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).brush);
    }
    if (SpGraphicsArch(graphics).bg_brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).bg_brush);
    }
    
    SpGraphicsArch(graphics).pen = CreatePen(getLineType(graphics), SpGraphicsPart(graphics).line_width,
					     SpGraphicsPart(graphics).fg_pixel);
    SpGraphicsArch(graphics).brush = CreateSolidBrush(SpGraphicsPart(graphics).fg_pixel);
    SpGraphicsArch(graphics).bg_brush = CreateSolidBrush(SpGraphicsPart(graphics).bg_pixel);
    
    spSetGraphicsModeArch(graphics, SpGraphicsPart(graphics).mode);
    
    return;
}

void spLOGFONTToFontName(LOGFONT *lf, char *font_name)
{
    char size_string[SP_MAX_FONTNAME];
    char family_string[SP_MAX_FONTNAME];
    char slant_string[SP_MAX_FONTNAME];
    char weight_string[SP_MAX_FONTNAME];
    char spacing_string[SP_MAX_FONTNAME];

    if (lf->lfHeight == 0) {
	strcpy(size_string, "*");
    } else {
	sprintf(size_string, "%ld", ABS(lf->lfHeight));
    }
    
    strcpy(family_string, lf->lfFaceName);

    if (lf->lfWeight >= 800) {
	strcpy(weight_string, "black");
    } else if (lf->lfWeight >= 600) {
	strcpy(weight_string, "bold");
    } else if (lf->lfWeight <= 300) {
	strcpy(weight_string, "light");
    } else {
	strcpy(weight_string, "medium");
    }

    if (lf->lfItalic) {
	strcpy(slant_string, "i");
    } else {
	strcpy(slant_string, "r");
    }
    
    if (lf->lfPitchAndFamily & VARIABLE_PITCH) {
	strcpy(spacing_string, "p");
    } else if (lf->lfPitchAndFamily & FIXED_PITCH) {
	strcpy(spacing_string, "c");
    } else {
	strcpy(spacing_string, "*");
    }

    sprintf(font_name, "-*-%s-%s-%s-*--%s-*-*-*-*-%s-*-*",
	    family_string, weight_string, slant_string,
	    size_string, spacing_string);
    
    return;
}

void spFontNameToLOGFONT(char *font_name, LOGFONT *lf)
{
    int size = 14;
    unsigned long style = 0;
    DWORD weight = FW_REGULAR;
    BYTE italic = FALSE;
    BYTE charset = DEFAULT_CHARSET;
    BYTE pitch = DEFAULT_PITCH;
    BYTE family = FF_MODERN;
    static char name[SP_MAX_FONTNAME] = "";

    if (spParseFontName(font_name, name, &style, &size) == SP_TRUE) {
	if (style & SP_FONT_WEIGHT_BLACK) {
	    weight = FW_HEAVY;
	} else if (style & SP_FONT_WEIGHT_BOLD) {
	    weight = FW_BOLD;
	} else if (style & SP_FONT_WEIGHT_LIGHT) {
	    weight = FW_LIGHT;
	}
	if (style & SP_FONT_SLANT_ITALIC || style & SP_FONT_SLANT_OBLIQUE) {
	    italic = TRUE;
	}
	if (style & SP_FONT_PITCH_VARIABLE) {
	    pitch = VARIABLE_PITCH;
	} else if (style & SP_FONT_PITCH_FIXED || style & SP_FONT_PITCH_CELL) {
	    pitch = FIXED_PITCH;
	}
    } else if (!strnone(font_name)) {
	strcpy(name, font_name);
    }
    
    if (spIsJapaneseLang(spGetLanguage()) == SP_TRUE) {
	charset = SHIFTJIS_CHARSET;
    }

    spDebug(20, "spFontNameToLOGFONT", "size = %d, weight = %d, italic = %d, name = %s\n",
	    size, weight, italic, name);

    lf->lfHeight = size;
    lf->lfWidth = 0;
    lf->lfEscapement = 0;	/* angle of text */
    lf->lfOrientation = 0; 
    lf->lfWeight = weight;	/* weight of font */
    lf->lfItalic = italic;	/* is italic? */
    lf->lfUnderline = FALSE;
    lf->lfStrikeOut = FALSE;
    lf->lfCharSet = charset;
    lf->lfOutPrecision = OUT_DEFAULT_PRECIS;
    lf->lfClipPrecision = CLIP_DEFAULT_PRECIS;
    lf->lfQuality = PROOF_QUALITY;
    lf->lfPitchAndFamily = pitch | family;
    strcpy(lf->lfFaceName, name);
    
    return;
}

void spSetFontArch(spGraphics graphics)
{
    LOGFONT lf;
    
    if (SpGraphicsArch(graphics).font != NULL) {
	DeleteObject(SpGraphicsArch(graphics).font);
    }

    spFontNameToLOGFONT(SpGraphicsPart(graphics).font_name, &lf);

    SpGraphicsArch(graphics).font = CreateFontIndirect(&lf);
  
    return;
}

spBool spGetSystemColorPixelArch(spSystemColorType type, spPixel *pixel)
{
    switch (type) {
      case SP_SYSTEM_COLOR_BACKGROUND:
      case SP_SYSTEM_COLOR_TAB_BACKGROUND:
	*pixel = (spPixel)GetSysColor(COLOR_BTNFACE);
	break;
      case SP_SYSTEM_COLOR_TOP_SHADOW:
	*pixel = (spPixel)GetSysColor(COLOR_BTNHILIGHT);
	break;
      case SP_SYSTEM_COLOR_BOTTOM_SHADOW:
	*pixel = (spPixel)GetSysColor(COLOR_BTNSHADOW);
	break;
      case SP_SYSTEM_COLOR_HIGHLIGHT:
	*pixel = (spPixel)GetSysColor(COLOR_3DLIGHT);
	break;
      case SP_SYSTEM_COLOR_DARK_SHADOW:
	*pixel = (spPixel)GetSysColor(COLOR_3DDKSHADOW);
	break;
      case SP_SYSTEM_COLOR_BLACK:
      case SP_SYSTEM_COLOR_FOCUS:
	*pixel = 0;
	break;
      case SP_SYSTEM_COLOR_WHITE:
	*pixel = spRGB(255, 255, 255);
	break;
	
      default:
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spSetForegroundPixelArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).pen != NULL) {
	DeleteObject(SpGraphicsArch(graphics).pen);
    }
    if (SpGraphicsArch(graphics).brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).brush);
    }
    SpGraphicsArch(graphics).pen = CreatePen(getLineType(graphics), SpGraphicsPart(graphics).line_width,
					     SpGraphicsPart(graphics).fg_pixel);
    SpGraphicsArch(graphics).brush = CreateSolidBrush(SpGraphicsPart(graphics).fg_pixel);
					     
    return SP_TRUE;
}

spBool spSetBackgroundPixelArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).bg_brush != NULL) {
	DeleteObject(SpGraphicsArch(graphics).bg_brush);
    }
    SpGraphicsArch(graphics).bg_brush = CreateSolidBrush(SpGraphicsPart(graphics).bg_pixel);
    return SP_TRUE;
}

char **spGetFontFamilyListArch(void)
{
    return NULL;
}

spBool spIsFontSizeSupportedArch(int family, unsigned long style, int size)
{
    return SP_FALSE;
}
