/*
 *	spCanvas_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/DrawingA.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComboBoxP.h>
#include <sp/spGraphicsP.h>
#include <sp/spDrawP.h>
#include <sp/spCanvasP.h>

static spComponent sp_focus_canvas = NULL;

spBool spIsCanvasExposedArch(spComponent component)
{
    if (SpPrimitiveArch(component).drawable != None) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spExposeCanvasCBArch(spComponent component)
{
    if (SpPrimitiveArch(component).drawable == None) {
	SpPrimitiveArch(component).drawable = XtWindow(SpPrimitiveArch(component).widget);
    }
    
    return;
}

static void focusChangeCB(Widget widget, XtPointer client_data, XEvent *event)
{
    spComponent canvas = (spComponent)client_data;

    if (SpCanvasPart(canvas).focusable == SP_TRUE
	&& SpPrimitiveArch(canvas).widget
	== XtGetKeyboardFocusWidget(SpPrimitiveArch(SpGetWindow(canvas)).widget)) {
	if (event->type == FocusIn) {
	    spDebug(80, "focusChangeCB", "focus in\n");
	    if (sp_focus_canvas != NULL) {
		spComponent temp;
		temp = sp_focus_canvas;
		sp_focus_canvas = NULL;
		spRedrawCanvas(temp);
	    }
	    sp_focus_canvas = canvas;
	} else if (event->type == FocusOut) {
	    spDebug(80, "focusChangeCB", "focus out\n");
	    sp_focus_canvas = NULL;
	}
	spRedrawCanvas(canvas);
    }
    
    return;
}

void spCanvasCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[20];

#ifndef LESSTIF_FRAME_BUG
    if (SpCanvasPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).border_width = 2;
	SpPrimitiveArch(component).top_widget =
	    XtVaCreateManagedWidget("",
				    xmFrameWidgetClass, SpParentPrimitiveArch(component).widget,
				    XmNshadowType, XmSHADOW_IN,
				    XmNshadowThickness, 2,
				    XmNmarginWidth, 0,
				    XmNmarginHeight, 0,
				    NULL);
    }
#endif
    
    XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
    XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
    XtSetArg(args[narg], XmNresizePolicy, XmRESIZE_NONE); narg++;
    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			      xmDrawingAreaWidgetClass,
			      (SpPrimitiveArch(component).top_widget != NULL ?
			       SpPrimitiveArch(component).top_widget : SpParentPrimitiveArch(component).widget),
			      args, narg);
    XtAddEventHandler(SpPrimitiveArch(component).widget, FocusChangeMask,
		      False, (XtEventHandler)focusChangeCB, (XtPointer)component);

    return;
}

void spCanvasSetParamsArch(spComponent component)
{
    return;
}
    
void spCanvasDestroyArch(spComponent component)
{
    if (sp_focus_canvas == component) {
	sp_focus_canvas = NULL;
    }
    
    return;
}
    
void spRefreshCanvasArch(spComponent component)
{
    if (SpPrimitiveArch(component).drawable == None) return;
    
    spDebug(50, "spRefreshCanvasArch", "in\n");

    spGetDisplayInfo(component);

    XCopyArea(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap,
	      SpPrimitiveArch(component).drawable, DefaultGCOfScreen(SpPrimitiveArch(component).screen),
	      0, 0, SpComponentPart(component).client_width, SpComponentPart(component).client_height, 0, 0);

    spDebug(50, "spRefreshCanvasArch", "width = %d, height = %d\n", 
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);
    
    return;
}

void spRedrawCanvasArch(spComponent component)
{
    if (SpPrimitiveArch(component).drawable == None)
	return;
    
    spDebug(50, "spRedrawCanvas", "client_width = %d, client_height = %d\n",
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);

    spGetDisplayInfo(component);
    
    if (SpPrimitiveArch(component).pixmap != None) {
	XFreePixmap(SpPrimitiveArch(component).display, SpPrimitiveArch(component).pixmap);
	SpPrimitiveArch(component).pixmap = None;
    }

    /* create pixmap */
    if ((SpPrimitiveArch(component).pixmap = 
	 XCreatePixmap(SpPrimitiveArch(component).display, 
		       RootWindowOfScreen(SpPrimitiveArch(component).screen),
		       SpComponentPart(component).client_width, SpComponentPart(component).client_height,
		       DefaultDepthOfScreen(SpPrimitiveArch(component).screen))) == None) {
	spError(1, "can't create pixmap\n");
    }

    spAddCallback(component, SP_RESIZE_CALLBACK, spResizeCanvasCB, NULL);

    return;
}

static void captureCanvas(Widget widget, XtPointer client_data, XEvent *event)
{
    short x, y;
    spComponent component;
    spComponent window;
    static int prev_dx = 0, prev_dy = 0;
    static Widget prev_widget = NULL;

    component = (spComponent)client_data;
    
    if (component == NULL
	|| SpCanvasPart(component).capture_flag == SP_FALSE) return;
    
    window = SpGetWindow(component);
    
    if (event->type == MotionNotify) {
	if (widget != prev_widget) return;

	spDebug(10, "captureCanvas", "prev_dx = %d, prev_dy = %d, x_root = %d, y_root = %d\n",
		prev_dx, prev_dy, event->xmotion.x_root, event->xmotion.y_root);

	SpComponentPart(window).x = event->xmotion.x_root + prev_dx;
	SpComponentPart(window).y = event->xmotion.y_root + prev_dy;
	
	XtVaSetValues(SpPrimitiveArch(window).toplevel,
		      XmNx, SpComponentPart(window).x,
		      XmNy, SpComponentPart(window).y,
		      NULL);
    } else if (event->type == ButtonPress) {
	x = 0; y = 0;
	XtVaGetValues(SpPrimitiveArch(window).toplevel,
		      XmNx, &x,
		      XmNy, &y,
		      NULL);
	spDebug(10, "captureCanvas", "x = %d, y = %d, x_root = %d, y_root = %d\n",
		x, y, event->xbutton.x_root, event->xbutton.y_root);

	prev_dx = x - event->xbutton.x_root;
	prev_dy = y - event->xbutton.y_root;
	
	prev_widget = widget;
    } else if (event->type == ButtonRelease) {
	prev_dx = 0;
	prev_dy = 0;
	prev_widget = NULL;
    }

    return;
}

spBool spSetCanvasCaptureArch(spComponent component)
{
    XtAddEventHandler(SpPrimitiveArch(component).widget,
		      ButtonPressMask | ButtonReleaseMask
		      | Button1MotionMask | Button3MotionMask | Button2MotionMask,
		      False, (XtEventHandler)captureCanvas, (XtPointer)component);

    return SP_TRUE;
}

spBool spSetCanvasCursorArch(spComponent component, spCursor cursor)
{
    return spSetCursorXm(SpPrimitiveArch(component).widget, cursor);
}

spBool spUnsetCanvasCursorArch(spComponent component)
{
    return spUnsetCursorXm(SpPrimitiveArch(component).widget);
}

spBool spIsCanvasFocusedArch(spComponent component)
{
    if (component == sp_focus_canvas) {
	return SP_TRUE;
    }

    return SP_FALSE;
}
