/*
 *	spPrimitive_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spFrame.h>
#include <sp/spDialog.h>
#include <sp/spComboBox.h>
#include <sp/spToolBar.h>
#include <sp/spToolItem.h>
#include <sp/spStatusBar.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItemP.h>
#include <sp/spButtonP.h>
#include <sp/spSliderP.h>
#include <sp/spTabBoxP.h>
#include <sp/spContainerP.h>
#include <sp/spCanvasP.h>
#include <sp/spGraphicsP.h>
#include <sp/spPrimitiveP.h>

extern spTopLevel sp_toplevel;

static spCallbackTable sp_callback_tables[] = {
    {SP_NO_CALLBACK, NULL, WM_NULL, 0},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, WM_CHAR, 0},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, WM_IME_CHAR, 0},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, WM_KEYDOWN, 0},
    {SP_KEY_RELEASE_CALLBACK, SpCanvas, WM_KEYUP, 0},
    {SP_BUTTON_PRESS_CALLBACK, SpFrame, WM_TASKTRAY, 0},
    {SP_BUTTON_PRESS_CALLBACK, SpPrimitive, WM_LBUTTONDOWN, 0},
    {SP_BUTTON_PRESS_CALLBACK, SpPrimitive, WM_RBUTTONDOWN, 0},
    {SP_BUTTON_PRESS_CALLBACK, SpPrimitive, WM_MBUTTONDOWN, 0},
    {SP_BUTTON_RELEASE_CALLBACK, SpPrimitive, WM_LBUTTONUP, 0},
    {SP_BUTTON_RELEASE_CALLBACK, SpPrimitive, WM_RBUTTONUP, 0},
    {SP_BUTTON_RELEASE_CALLBACK, SpPrimitive, WM_MBUTTONUP, 0},
    {SP_POINTER_MOTION_CALLBACK, SpCanvas, WM_MOUSEMOVE, 0},
    {SP_BUTTON_MOTION_CALLBACK, SpCanvas, WM_MOUSEMOVE,
	MK_LBUTTON|MK_RBUTTON|MK_MBUTTON},
#if 0
    {SP_ENTER_WINDOW_CALLBACK, SpCanvas, WM_NULL, 0},
    {SP_LEAVE_WINDOW_CALLBACK, SpCanvas, WM_NULL, 0},
#endif
    /**/
    {SP_DESTROY_CALLBACK, SpFrame, WM_DESTROY, 0},
    {SP_CLOSE_CALLBACK, SpFrame, WM_CLOSE, 0},
    {SP_ACTIVATE_CALLBACK, SpPushButton, WM_COMMAND, 0},
    {SP_ACTIVATE_CALLBACK, SpMenuItem, WM_COMMAND, 0},
    {SP_ACTIVATE_CALLBACK, SpToolItem, WM_COMMAND, 0},
    {SP_ACTIVATE_CALLBACK, SpTextField, WM_KEYDOWN, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBox, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButton, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBoxMenuItem, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButtonMenuItem, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckToolItem, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpSlider, WM_VSCROLL, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpSlider, WM_HSCROLL, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpText, WM_COMMAND, 0},
    {SP_VALUE_CHANGED_CALLBACK, SpList, WM_COMMAND, 0},
#if 0
    {SP_MAP_CALLBACK, SpPrimitive, WM_NULL, 0},
    {SP_UNMAP_CALLBACK, SpPrimitive, WM_NULL, 0},
#endif
    {SP_EXPOSE_CALLBACK, SpCanvas, WM_PAINT, 0},
    {SP_EXPOSE_CALLBACK, SpContainer, WM_PAINT, 0},
    {SP_RESIZE_CALLBACK, SpCanvas, WM_SIZE, 0},
    /**/
    {SP_OK_CALLBACK, SpPushButton, WM_COMMAND, IDOK},
    {SP_OK_CALLBACK, SpDialog, WM_COMMAND, IDOK},
    {SP_CANCEL_CALLBACK, SpPushButton, WM_COMMAND, IDCANCEL},
    {SP_CANCEL_CALLBACK, SpDialog, WM_COMMAND, IDCANCEL},
    {SP_HELP_CALLBACK, SpPushButton, WM_COMMAND, IDHELP},
    {SP_HELP_CALLBACK, SpDialog, WM_COMMAND, IDHELP},
#if 0
    {SP_APPLY_CALLBACK, SpPushButton, WM_NULL, 0},
    {SP_APPLY_CALLBACK, SpDialog, WM_NULL, 0},
#endif
};
static int sp_num_callback_table = 0;

extern spTopLevel sp_toplevel;

static spComponent getCurrentMenu(spComponent component, HMENU hmenu,
				  UINT uitem, UINT uflags)
{
    spComponent child;
    spComponent current = NULL;
    spComponent current_menu = NULL;

    if (hmenu == NULL
	|| (uflags & MF_SYSMENU) != 0) return NULL;
    
    if (component == NULL) {
	child = spGetChild(NULL);
    } else {
	if (spIsCreated(component) == SP_FALSE) {
	    return NULL;
	} else {
	    child = SpGetChild(component);
	}

	if (spIsMenu(component) == SP_TRUE
	    && SpPrimitiveArch(component).hmenu == hmenu) {
	    current = component;
	}
    }

    if (current == NULL) {
	while (child != NULL) {
	    if (spIsMenu(child) == SP_TRUE
		&& SpPrimitiveArch(child).hmenu == hmenu) {
		current = child;
		break;
	    } else if ((current_menu = getCurrentMenu(child, hmenu, uitem, uflags)) != NULL) {
		return current_menu;
	    }
	    child = SpGetNextComponent(child);
	}
    }

    if (current != NULL) {
	UINT i;
	
	child = SpGetChild(current);
	
	for (i = 0; child != NULL; i++) {
	    if (uflags & MF_POPUP) {
		if (i == uitem) {
		    current_menu = child;
		    break;
		}
	    } else {
		if ((UINT)SpGetComponentId(child) == uitem) {
		    current_menu = child;
		    break;
		}
	    }

	    child = SpGetNextComponent(child);
	}
    }

    return current_menu;
}

static spComponent getCurrentComponent(spComponent component, HWND hwnd)
{
    spComponent child;
    spComponent current = NULL;

    if (hwnd == NULL) return NULL;
    
    if (component == NULL) {
	child = spGetChild(NULL);
    } else {
	child = SpGetChild(component);

	if (SpPrimitiveArch(component).hwnd == hwnd) {
	    current = component;
	}
    }

    if (current == NULL) {
	while (child != NULL) {
	    if (SpPrimitiveArch(child).hwnd == hwnd) {
		current = child;
		break;
	    } else if ((current = getCurrentComponent(child, hwnd)) != NULL) {
		break;
	    }
	    child = SpGetNextComponent(child);
	}
    }

    return current;
}

static spComponent getCurrentWindow(HWND hwnd, UINT message,
				    WPARAM wParam, LPARAM lParam)
{
    spComponent window = NULL;

    if ((window = getCurrentComponent(NULL, hwnd)) != NULL) {
	SpPrimitiveArch(window).message = message;
	SpPrimitiveArch(window).wParam = wParam;
	SpPrimitiveArch(window).lParam = lParam;
    }

    return window;
}

static UINT getCallbackMessage(spComponent component, spCallbackType call_type, UINT *command_id, int *count)
{
    int i;
    UINT message = WM_NULL;
    
    if (call_type == SP_NO_CALLBACK) {
	return message;
    }

    if (sp_num_callback_table <= 0) {
	sp_num_callback_table = spArraySize(sp_callback_tables);
    }

    if (*count < sp_num_callback_table) {
	for (i = *count; i < sp_num_callback_table; i++) {
	    if (sp_callback_tables[i].component_type == NULL
		|| spIsSubClass(component, sp_callback_tables[i].component_type) == SP_TRUE) {
		if (call_type & sp_callback_tables[i].call_type &&
		    sp_callback_tables[i].message != WM_NULL) {
		    message = sp_callback_tables[i].message;
		    if (command_id != NULL) {
			*command_id = sp_callback_tables[i].command_id;
		    }
		    *count = i + 1;
		    break;
		}
	    }
	}
	if (i >= sp_num_callback_table) {
	    *count = sp_num_callback_table;
	}
    }
    
    return message;
}

void spInitCallbackArch(spCallback *callback)
{
    callback->component = NULL;
    callback->call_func = NULL;
    callback->call_data = NULL;
    callback->propagate = SP_FALSE;

    callback->component_id = -1;
    callback->message = WM_NULL;
    callback->command_id = 0;
    
    return;
}

static spBool addCallback(spComponent component, spBool propagate, UINT message, UINT command_id,
			  spCallbackFunc call_func, void *call_data)
{
    long k;
    spBool flag = SP_FALSE;
    spComponent window = NULL;
    
    if (spIsPrimitive(component) == SP_TRUE && message != WM_NULL &&
	call_func != NULL) {
	window = SpGetWindow(component);
	if (spIsPrimitive(window) == SP_FALSE) {
	    return SP_FALSE;
	}
	
	for (k = 0; k < SpPrimitivePart(window).num_callback; k++) {
	    if (SpPrimitivePart(window).callbacks[k].component == component &&
		SpPrimitivePart(window).callbacks[k].component_id == SpComponentPart(component).component_id &&
		SpPrimitivePart(window).callbacks[k].message == message &&
		SpPrimitivePart(window).callbacks[k].command_id == command_id &&
		SpPrimitivePart(window).callbacks[k].call_func == call_func &&
		SpPrimitivePart(window).callbacks[k].call_data == call_data) {
		return SP_FALSE;
	    } else if (SpPrimitivePart(window).callbacks[k].call_func == NULL) {
		break;
	    }
	}
	
	if (k >= SpPrimitivePart(window).num_callback) {
	    spAllocCallbacks(window);
	    SpPrimitivePart(window).num_callback++;
	}
	
	SpPrimitivePart(window).callbacks[k].component = component;
	SpPrimitivePart(window).callbacks[k].component_id = SpComponentPart(component).component_id;
	SpPrimitivePart(window).callbacks[k].message = message;
	SpPrimitivePart(window).callbacks[k].command_id = command_id;
	SpPrimitivePart(window).callbacks[k].call_func = call_func;
	SpPrimitivePart(window).callbacks[k].call_data = call_data;
	SpPrimitivePart(window).callbacks[k].propagate = propagate;

	spDebug(80, "addCallback", "message = %d\n", message);
    }

    return flag;
}

static spBool removeCallbackMain(spComponent component, UINT message, UINT command_id,
				 spCallbackFunc call_func, void *call_data, spBool all_flag)
{
    long k;
    spBool flag = SP_FALSE;
    spComponent window = NULL;
    
    if (spIsPrimitive(component) == SP_TRUE &&
	(all_flag == SP_TRUE ||	(message != WM_NULL && call_func != NULL))) {
	window = SpGetWindow(component);
	if (spIsPrimitive(window) == SP_FALSE) {
	    return SP_FALSE;
	}
	
	for (k = 0; k < SpPrimitivePart(window).num_callback; k++) {
	    if ((all_flag == SP_TRUE
		 && SpPrimitivePart(window).callbacks[k].component == component)
		|| (SpPrimitivePart(window).callbacks[k].component == component &&
		    SpPrimitivePart(window).callbacks[k].component_id == SpComponentPart(component).component_id &&
		    SpPrimitivePart(window).callbacks[k].message == message &&
		    SpPrimitivePart(window).callbacks[k].command_id == command_id &&
		    SpPrimitivePart(window).callbacks[k].call_func == call_func &&
		    SpPrimitivePart(window).callbacks[k].call_data == call_data)) {
		SpPrimitivePart(window).callbacks[k].component = NULL;
		SpPrimitivePart(window).callbacks[k].component_id = -1;
		SpPrimitivePart(window).callbacks[k].message = WM_NULL;
		SpPrimitivePart(window).callbacks[k].command_id = 0;
		SpPrimitivePart(window).callbacks[k].call_func = NULL;
		SpPrimitivePart(window).callbacks[k].call_data = NULL;

		flag = SP_TRUE;
		spDebug(80, "removeCallback", "component_id = %ld\n",
			SpComponentPart(component).component_id);
		break;
	    }
	}
    }

    return flag;
}

static spBool removeCallback(spComponent component, UINT message, UINT command_id,
			     spCallbackFunc call_func, void *call_data)
{
    return removeCallbackMain(component, message, command_id, call_func, call_data, SP_FALSE);
}

static spBool removeAllCallback(spComponent component)
{
    return removeCallbackMain(component, WM_NULL, 0, NULL, NULL, SP_TRUE);
}

spBool spPrimitiveAddCallbackArch(spComponent component, spBool propagate, spCallbackType call_type,
				  spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    UINT message;
    UINT command_id = 0;
    
    while ((message = getCallbackMessage(component, call_type, &command_id, &count)) != WM_NULL) {
	flag = addCallback(component, propagate, message, command_id, call_func, call_data);
	command_id = 0;
    }

    return flag;
}

spBool spPrimitiveRemoveCallbackArch(spComponent component, spCallbackType call_type,
				     spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    UINT message;
    UINT command_id = 0;
    
    while ((message = getCallbackMessage(component, call_type, &command_id, &count)) != WM_NULL) {
	flag = removeCallback(component, message, command_id, call_func, call_data);
	command_id = 0;
    }

    return flag;
}

spCallbackReason spPrimitiveGetCallbackReasonArch(spComponent component)
{
    spCallbackReason call_reason = SP_CR_NONE;

    if (SpPrimitiveArch(component).message != WM_NULL) {
	switch (SpPrimitiveArch(component).message) {
	  case WM_COMMAND:
	    if (spIsSubClass(component, SpList) == SP_TRUE) {
		if (HIWORD(SpPrimitiveArch(component).wParam) == LBN_DBLCLK) {
		    call_reason = SP_CR_ACTIVATE;
		} else {
		    call_reason = SP_CR_VALUE_CHANGED;
		}
	    } else if (spIsText(component) == SP_TRUE) {
		call_reason = SP_CR_VALUE_CHANGED;
	    } else if (streq(SpGetName(component), "yesButton")) {
		call_reason = SP_CR_YES;
	    } else if (streq(SpGetName(component), "noButton")) {
		call_reason = SP_CR_NO;
	    } else if (streq(SpGetName(component), "retryButton")) {
		call_reason = SP_CR_RETRY;
	    } else {
		call_reason = SP_CR_ACTIVATE;
	    }
	    break;
	  case WM_KEYDOWN:
	    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
		call_reason = SP_CR_ACTIVATE;
		break;
	    }
	  case WM_CHAR:
	  case WM_IME_CHAR:
	    call_reason = SP_CR_KEY_PRESS;
	    break;
	  case WM_KEYUP:
	    call_reason = SP_CR_KEY_RELEASE;
	    break;
	  case WM_LBUTTONDOWN:
	    call_reason = SP_CR_LBUTTON_PRESS;
	    break;
	  case WM_RBUTTONDOWN:
	    call_reason = SP_CR_RBUTTON_PRESS;
	    break;
	  case WM_MBUTTONDOWN:
	    call_reason = SP_CR_MBUTTON_PRESS;
	    break;
	  case WM_LBUTTONUP:
	    call_reason = SP_CR_LBUTTON_RELEASE;
	    break;
	  case WM_RBUTTONUP:
	    call_reason = SP_CR_RBUTTON_RELEASE;
	    break;
	  case WM_MBUTTONUP:
	    call_reason = SP_CR_MBUTTON_RELEASE;
	    break;
	  case WM_MOUSEMOVE:
	    if (SpPrimitiveArch(component).wParam & MK_LBUTTON) {
		call_reason = SP_CR_LBUTTON_MOTION;
	    } else if (SpPrimitiveArch(component).wParam & MK_RBUTTON) {
		call_reason = SP_CR_RBUTTON_MOTION;
	    } else if (SpPrimitiveArch(component).wParam & MK_MBUTTON) {
		call_reason = SP_CR_MBUTTON_MOTION;
	    } else {
		call_reason = SP_CR_POINTER_MOTION;
	    }
	    break;
	  case WM_VSCROLL:
	  case WM_HSCROLL:
	    call_reason = SP_CR_VALUE_CHANGED;
	    break;
	  case WM_PAINT:
	    call_reason = SP_CR_EXPOSE;
	    break;
	  case WM_SIZE:
	    call_reason = SP_CR_RESIZE;
	    break;
	  case WM_TASKTRAY:
	    if (SpPrimitiveArch(component).lParam == WM_LBUTTONDOWN) {
		call_reason = SP_CR_LBUTTON_PRESS;
	    } else if (SpPrimitiveArch(component).lParam == WM_MBUTTONDOWN) {
		call_reason = SP_CR_MBUTTON_PRESS;
	    } else if (SpPrimitiveArch(component).lParam == WM_RBUTTONDOWN) {
		call_reason = SP_CR_RBUTTON_PRESS;
	    }
	    break;
	  case WM_CLOSE:
	    call_reason = SP_CR_CLOSE;
	    break;
	  case WM_DESTROY:
	    call_reason = SP_CR_DESTROY;
	    break;
	  default:
	    call_reason = SP_CR_UNKNOWN;
	    break;
	}
    }
    
    return call_reason;
}

spBool spPrimitiveGetCallbackMousePositionArch(spComponent component, int *x, int *y)
{
    short lx = 0, ly = 0;
    POINT point;
    
    if ((x != NULL || y != NULL)) {
	switch (SpPrimitiveArch(component).message) {
	  case WM_LBUTTONDOWN:
	  case WM_RBUTTONDOWN:
	  case WM_MBUTTONDOWN:
	  case WM_LBUTTONUP:
	  case WM_RBUTTONUP:
	  case WM_MBUTTONUP:
	  case WM_MOUSEMOVE:
	    if (x != NULL) {
		lx = LOWORD(SpPrimitiveArch(component).lParam);
		spDebug(100, "spPrimitiveGetCallbackMousePositionArch",
			"lx = %d\n", lx);
		*x = lx;
	    }
	    if (y != NULL) {
		ly = HIWORD(SpPrimitiveArch(component).lParam);
		spDebug(100, "spPrimitiveGetCallbackMousePositionArch",
			"ly = %d\n", ly);
		*y = ly;
	    }
	    break;
	  case WM_TASKTRAY:
	    if (GetCursorPos(&point)) {
		if (x != NULL) {
		    *x = point.x;
		}
		if (y != NULL) {
		    *y = point.y;
		}
	    } else {
		return SP_FALSE;
	    }
	    break;
	  default:
	    return SP_FALSE;
	}
	
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spKeySym convertKeySym(int key_sym)
{
    if ((key_sym >= '0' && key_sym <= '9')
	|| (key_sym >= 'A' && key_sym <= 'Z')
	|| (key_sym >= 0x60 && key_sym <= 0x6F)
	|| key_sym == VK_SPACE) {
	return SPK_Character;
    } else {
	switch (key_sym) {
	  case VK_BACK:
	    return SPK_BackSpace;
	  case VK_TAB:
	    return SPK_Tab;
	  case VK_CLEAR:
	    return SPK_Clear;
	  case VK_RETURN:
	    return SPK_Return;
	  case VK_PAUSE:        
	    return SPK_Pause;
	  case VK_SCROLL:
	    return SPK_ScrollLock;
	  case VK_ESCAPE:       
	    return SPK_Escape;
	  case VK_DELETE:       
	    return SPK_Delete;
	  case VK_SHIFT:
	    return SPK_Shift;
	  case VK_CONTROL:      
	    return SPK_Control;
	  case VK_CAPITAL:
	    return SPK_CapsLock;
	  case VK_HOME:         
	    return SPK_Home;
	  case VK_LEFT:         
	    return SPK_Left;
	  case VK_UP:           
	    return SPK_Up;
	  case VK_RIGHT:        
	    return SPK_Right;
	  case VK_DOWN:         
	    return SPK_Down;
	  case VK_MENU:         
	    return SPK_Alt;
	  case VK_PRIOR:        
	    return SPK_Prior;
	  case VK_NEXT:         
	    return SPK_Next;
	  case VK_END:          
	    return SPK_End;
	  case VK_SELECT:       
	    return SPK_Select;
	  case VK_PRINT:        
	    return SPK_Print;
	  case VK_EXECUTE:      
	    return SPK_Execute;
	  case VK_INSERT:       
	    return SPK_Insert;
	  case VK_CANCEL:         
	    return SPK_Cancel;
	  case VK_HELP:         
	    return SPK_Help;
	  case VK_NUMLOCK:      
	    return SPK_NumLock;
	    
	  case VK_F1:           
	    return SPK_F1;
	  case VK_F2:           
	    return SPK_F2;
	  case VK_F3:           
	    return SPK_F3;
	  case VK_F4:           
	    return SPK_F4;
	  case VK_F5:           
	    return SPK_F5;
	  case VK_F6:           
	    return SPK_F6;
	  case VK_F7:           
	    return SPK_F7;
	  case VK_F8:           
	    return SPK_F8;
	  case VK_F9:           
	    return SPK_F9;
	  case VK_F10:          
	    return SPK_F10;
	  case VK_F11:          
	    return SPK_F11;
	  case VK_F12:         
	    return SPK_F12;
	  case VK_F13:          
	    return SPK_F13;
	  case VK_F14:          
	    return SPK_F14;
	  case VK_F15:          
	    return SPK_F15;
	  case VK_F16:          
	    return SPK_F16;
	  case VK_F17:          
	    return SPK_F17;
	  case VK_F18:          
	    return SPK_F18;
	  case VK_F19:          
	    return SPK_F19;
	  case VK_F20:          
	    return SPK_F20;
	  case VK_F21:          
	    return SPK_F21;
	  case VK_F22:          
	    return SPK_F22;
	  case VK_F23:          
	    return SPK_F23;
	  case VK_F24:          
	    return SPK_F24;
	  default:
	    break;
	}
    }

    return SPK_Unknown;
}

spBool spPrimitiveGetCallbackKeySymArch(spComponent component, spKeySym *key_sym)
{
    switch (SpPrimitiveArch(component).message) {
      case WM_KEYDOWN:
	*key_sym = convertKeySym((int)SpPrimitiveArch(component).wParam);
	spDebug(100, "spPrimitiveGetCallbackKeySymArch", "key_sym = %d\n", *key_sym);
	return SP_TRUE;
	
      case WM_CHAR:
      case WM_IME_CHAR:
	*key_sym = SPK_Character;
	return SP_TRUE;
	
      default:
	break;
    }
    
    return SP_FALSE;
}

int spPrimitiveGetCallbackKeyStringArch(spComponent component,
					char *buf, int buf_size, spBool *overflow)
{
    int len;
    unsigned char c1, c2;
    char string[4];
    
    switch (SpPrimitiveArch(component).message) {
      case WM_IME_CHAR:
      case WM_CHAR:
	if (SpPrimitiveArch(component).message == WM_IME_CHAR) {
	    c1 = (unsigned char)(0xff &
				((WORD)SpPrimitiveArch(component).wParam >> 8));
	    c2 = (unsigned char)(0xff & SpPrimitiveArch(component).wParam);

	    if (c1 != NUL && c1 > 0x7f) {
		sprintf(string, "%c%c", c1, c2);
	    } else {
		sprintf(string, "%c", c2);
	    }
	} else {
	    sprintf(string, "%c", (unsigned char)SpPrimitiveArch(component).wParam);
	}
	if ((int)strlen(string) >= buf_size) {
	    if (overflow != NULL) {
		*overflow = SP_TRUE;
	    }
	    len = buf_size - 1;
	    strncpy(buf, string, len);
	} else {
	    if (overflow != NULL) {
		*overflow = SP_FALSE;
	    }
	    strcpy(buf, string);
	    len = strlen(string);
	}
	return len;
      default:
	break;
    }
    
    return -1;
}

void spPrimitivePartInitArch(spComponent component)
{
    if (component != NULL) {
	SpPrimitiveArch(component).hwnd = NULL;
	SpPrimitiveArch(component).hmenu = NULL;
	SpPrimitiveArch(component).hdc = NULL;
	SpPrimitiveArch(component).memdc = NULL;
	SpPrimitiveArch(component).hbitmap = NULL;
	SpPrimitiveArch(component).hcursor = NULL;
	SpPrimitiveArch(component).message = WM_NULL;
	SpPrimitiveArch(component).wParam = 0;
	SpPrimitiveArch(component).lParam = 0;

	SpPrimitiveArch(component).num_accel = 0;
	SpPrimitiveArch(component).num_accel_buffer = 0;
	SpPrimitiveArch(component).accels = NULL;
	SpPrimitiveArch(component).haccel = NULL;
	
	SpPrimitiveArch(component).realize_flag = SP_FALSE;
	SpPrimitiveArch(component).htooltip = NULL;
    }
    
    return;
}

static void freeDC(spComponent component)
{
    spComponent child;
    
    if (spIsPrimitive(component) == SP_FALSE) return;

    child = SpGetChild(component);
    while (child != NULL) {
	freeDC(child);
	child = SpGetNextComponent(child);
    }

    if (SpPrimitiveArch(component).memdc != NULL) {
	DeleteDC(SpPrimitiveArch(component).memdc);
	SpPrimitiveArch(component).memdc = NULL;
    }
    if (SpPrimitiveArch(component).hbitmap != NULL) {
	DeleteObject(SpPrimitiveArch(component).hbitmap);
	SpPrimitiveArch(component).hbitmap = NULL;
    }

    if (SpPrimitiveArch(component).accels != NULL) {
	xfree(SpPrimitiveArch(component).accels);
	SpPrimitiveArch(component).accels = NULL;
	SpPrimitiveArch(component).num_accel = 0;
	SpPrimitiveArch(component).num_accel_buffer = 0;
    }

    if (SpPrimitiveArch(component).haccel != NULL) {
	DestroyAcceleratorTable(SpPrimitiveArch(component).haccel);
	SpPrimitiveArch(component).haccel = NULL;
    }

    return;
}

void spPrimitiveDestroyArch(spComponent component)
{
    spDebug(10, "spPrimitiveDestroyArch", "in\n");

    removeAllCallback(component);
    
    freeDC(component);
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE) {
	spQuit(0);
    } else {
	if (spIsSubClass(component, SpMenuItem) == SP_TRUE
	    && spIsPrimitive(SpGetParent(component)) == SP_TRUE
	    && SpParentPrimitiveArch(component).hmenu != NULL) {
	    spDebug(10, "spPrimitiveDestroyArch", "menu destroy\n");
	    DeleteMenu(SpParentPrimitiveArch(component).hmenu,
		       SpComponentPart(component).component_id,
		       MF_BYCOMMAND);
	    DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
	} else if (spIsSubClass(component, SpMenu) == SP_TRUE
		   && SpPrimitiveArch(component).hmenu != NULL) {
	    DestroyMenu(SpPrimitiveArch(component).hmenu);
	} else {
	    if (SpPrimitiveArch(component).message != WM_DESTROY) {
		if (SpPrimitiveArch(component).hwnd != NULL) {
		    DestroyWindow(SpPrimitiveArch(component).hwnd);
		}
	    }
	
	}
	SpPrimitiveArch(component).hwnd = NULL;
	SpPrimitiveArch(component).hmenu = NULL;
	
	spDebug(30, "spPrimitiveDestroyArch", "done\n");
    }
    
    return;
}

void spPrimitiveMapArch(spComponent component)
{
    if (spIsSubClass(component, SpMenuItem) == SP_TRUE
	&& spIsPrimitive(SpGetParent(component)) == SP_TRUE
	&& SpParentPrimitiveArch(component).hmenu != NULL) {
#if 0
	EnableMenuItem(SpParentPrimitiveArch(component).hmenu,
		       SpComponentPart(component).component_id,
		       MF_BYCOMMAND | MF_ENABLED);
#else
	spCreateMenuItemWin(component);
#endif
	DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
    } else if (SpPrimitiveArch(component).hwnd != NULL) {
	ShowWindow(SpPrimitiveArch(component).hwnd, SW_RESTORE);
    }
    
    return;
}

void spPrimitiveUnmapArch(spComponent component)
{
    if (spIsSubClass(component, SpMenuItem) == SP_TRUE
	&& spIsPrimitive(SpGetParent(component)) == SP_TRUE
	&& SpParentPrimitiveArch(component).hmenu != NULL) {
#if 0
	EnableMenuItem(SpParentPrimitiveArch(component).hmenu,
		       SpComponentPart(component).component_id,
		       MF_BYCOMMAND | MF_GRAYED);
#else
	DeleteMenu(SpParentPrimitiveArch(component).hmenu,
		   SpComponentPart(component).component_id,
		   MF_BYCOMMAND);
#endif
	DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
    } else if (SpPrimitiveArch(component).hwnd != NULL) {
	ShowWindow(SpPrimitiveArch(component).hwnd, SW_HIDE);
    }
    
    return;
}

spBool spPrimitiveSetSizeArch(spComponent component, int width, int height)
{
    RECT rect;
    int hoffset = 0;
    int x, y;
    int window_width, window_height;
    
    if (SpPrimitiveArch(component).hwnd != NULL) {
	if (spIsFrame(component) == SP_TRUE) {
	    if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		int h;
		if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		    height += h;
		}
	    }
	    
	    /* get current window size */
	    GetWindowRect(SpPrimitiveArch(component).hwnd, &rect);
	    window_width = rect.right - rect.left;
	    window_height = rect.bottom - rect.top;

	    /* set exact window width */
	    GetClientRect(SpPrimitiveArch(component).hwnd, &rect);
	    window_width = width + window_width - (rect.right - rect.left);
	    window_height = height + window_height - (rect.bottom - rect.top);
	    MoveWindow(SpPrimitiveArch(component).hwnd,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       window_width, window_height, TRUE);

	    if (spIsVisible(component) == SP_TRUE
		&& SpPrimitiveArch(component).realize_flag == SP_TRUE) {
		InvalidateRect(SpPrimitiveArch(component).hwnd, NULL, TRUE);
	    }
	    spDebug(50, "spPritimiveSetSizeArch", "width = %d, height = %d\n",
		    window_width, window_height);
	} else {
	    if (spIsSubClass(component, SpContainer) == SP_TRUE
		&& spIsVisible(component) == SP_TRUE
		&& SpPrimitiveArch(SpGetWindow(component)).realize_flag == SP_TRUE) {
		spDrawContainerWin(component, SP_TRUE);
	    }
	    if (spEqClass(component, SpLabel) == SP_TRUE) {
		hoffset = 4;
	    }
	    if (spIsSubClass(component, SpContainer) == SP_TRUE
		       && SpContainerPart(component).title_offset > 0) {
		hoffset = -SpContainerPart(component).title_offset;
	    }
	    if (spIsSubClass(SpGetParent(component), SpContainer) == SP_TRUE
		       && SpContainerPart(SpGetParent(component)).title_offset > 0) {
		hoffset = SpContainerPart(SpGetParent(component)).title_offset;
		height += SpContainerPart(SpGetParent(component)).title_offset;
	    }
	    
	    if (spIsTabBox(SpGetParent(component)) == SP_TRUE) {
		x = SpComponentPart(component).x
		    + SpParentComponentPart(component).x;
		y = SpComponentPart(component).y + hoffset
		    + SpParentComponentPart(component).y;
	    } else {
		x = SpComponentPart(component).x;
		y = SpComponentPart(component).y + hoffset;
	    }
	    
	    if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
		/* get current window size */
		GetWindowRect(SpPrimitiveArch(component).hwnd, &rect);
		window_width = rect.right - rect.left;
		window_height = rect.bottom - rect.top;
		
		MoveWindow(SpPrimitiveArch(component).hwnd,
			   x, y, width, window_height, TRUE);
	    } else {
		/* set window size */
		MoveWindow(SpPrimitiveArch(component).hwnd,
			   x, y, width, height - hoffset, TRUE);
	    }

	    if (spIsVisible(component) == SP_TRUE
		&& SpPrimitiveArch(SpGetWindow(component)).realize_flag == SP_TRUE) {
		spDebug(10, "spPrimitiveSetSizeArch", "refresh canvas\n");
		
		if (spIsCanvas(component) == SP_TRUE) {
		    spGetClientSize(component, NULL, NULL);
		    spRedrawCanvas(component);
		} else if (spIsSubClass(component, SpContainer) == SP_TRUE) {
		    spGetClientSize(component, NULL, NULL);
		    spDrawContainerWin(component, SP_FALSE);
		} else if (spIsStatusBar(component) == SP_TRUE) {
		    InvalidateRect(SpPrimitiveArch(component).hwnd, NULL, TRUE);
		}
	    }
	}
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetSizeArch(spComponent component, int *width, int *height)
{
    RECT rect;
    
    if (SpPrimitiveArch(component).hwnd != NULL) {
	GetWindowRect(SpPrimitiveArch(component).hwnd, &rect);
	*width = rect.right - rect.left;
	if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
	    *height = SP_DEFAULT_TEXT_HEIGHT;
	} else {
	    *height = rect.bottom - rect.top;

	    if (spIsWindow(component) == SP_TRUE) {
		int h;

		if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		    if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
			*height -= h;
		    }
		}
	    } else if (spIsSubClass(component, SpContainer) == SP_TRUE
		       && SpComponentPart(component).top_offset > 0) {
		*height -= SpComponentPart(component).top_offset;
	    }
	}
    
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetClientSizeArch(spComponent component, int *width, int *height)
{
    RECT rect;
    
    if (SpPrimitiveArch(component).hwnd != NULL) {
	GetClientRect(SpPrimitiveArch(component).hwnd, &rect);
	*width = rect.right - rect.left;
	*height = rect.bottom - rect.top;

	if (spIsWindow(component) == SP_TRUE) {
	    int h;
	    if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		    *height -= h;
		}
	    }
	} else if (spIsSubClass(component, SpContainer) == SP_TRUE
		   && SpComponentPart(component).top_offset > 0) {
	    *height -= SpComponentPart(component).top_offset;
	}
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

static void setContainerSensitive(spComponent component, spBool flag)
{
    spComponent next;

    next = SpGetChild(component);
    while (next != NULL) {
	if (spIsCreated(next) == SP_TRUE
	    && spIsPrimitive(next) == SP_TRUE) {
	    if (flag == SP_FALSE) {
		spPrimitiveSetSensitiveArch(next, SP_FALSE);
	    } else {
		spPrimitiveSetSensitiveArch(next, spIsSensitive(next));
	    }

	}
	next = SpGetNextComponent(next);
    }

    return;
}

spBool spPrimitiveSetSensitiveArch(spComponent component, spBool flag)
{
    if (spIsSubClass(component, SpMenuItem) == SP_TRUE) {
	if (spIsCreated(SpGetParent(component)) == SP_TRUE
	    && SpParentPrimitiveArch(component).hmenu != NULL) {
	    EnableMenuItem(SpParentPrimitiveArch(component).hmenu,
			   SpComponentPart(component).component_id,
			   MF_BYCOMMAND | (flag == SP_TRUE ? MF_ENABLED : MF_GRAYED));
#if 0 /* 1999/6/16 */
	    if (SpPrimitiveArch(SpGetWindow(component)).realize_flag == SP_TRUE) {
		DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
	    }
#endif
	    return SP_TRUE;
	}
    } else if (spIsSubClass(component, SpToolItem) == SP_TRUE) {
	if (SpParentPrimitiveArch(component).hwnd != NULL) {
	    SendMessage(SpParentPrimitiveArch(component).hwnd, TB_ENABLEBUTTON,
			(WPARAM)SpComponentPart(component).component_id,
			(LPARAM)MAKELONG((flag == SP_TRUE ? TRUE : FALSE), 0));
	    return SP_TRUE;
	}
    } else {
	if (spIsSubClass(component, SpBox) == SP_TRUE) {
	    setContainerSensitive(component, flag);
	}
	
	if (SpPrimitiveArch(component).hwnd != NULL) {
	    EnableWindow(SpPrimitiveArch(component).hwnd, (flag == SP_TRUE ? TRUE : FALSE));
	    if (spIsSlider(component) == SP_TRUE && flag == SP_TRUE) {
		spSetSliderValueArch(component);
	    }
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

static spBool processCallback(spComponent window)
{
    long k;
    long component_id;
    long num_callback;
    spCallback *callbacks;
    spBool flag = SP_FALSE;
    spBool need_capture = SP_FALSE;
    spComponent parent_window;
    spComponent scroll_bar = NULL;
    RECT rect;
    POINT point;
    UINT message;
    UINT sub_message = 0;
    WPARAM wParam;
    LPARAM lParam;
    static spComponent capture_window = NULL;
    static int capture_dx = -1, capture_dy = -1;

    if (window == NULL) return SP_FALSE;

    message = SpPrimitiveArch(window).message;
    wParam = SpPrimitiveArch(window).wParam;
    lParam = SpPrimitiveArch(window).lParam;
    
    spDebug(100, "processCallback", "message = %d\n", message);
    
    if (message == WM_SIZE) {
	spDebug(80, "processCallback", "WM_SIZE: %s\n", SpGetClassName(window));
	if (SpPrimitiveArch(window).hwnd == SpPrimitiveArch(SpGetWindow(window)).hwnd) {
	    spAdjustComponentSize(window);
	    return SP_FALSE;
	}
    } else if (message == WM_DESTROY) {
	if (SpPrimitiveArch(SpGetWindow(window)).hwnd == NULL) {
	    return SP_TRUE;
	}
	spDebug(10, "processCallback", "destroy window\n");
	SpPrimitiveArch(SpGetWindow(window)).hwnd = NULL;
    } else if (message == WM_CLOSE && spIsFrame(window) == SP_TRUE) {
	spDebug(10, "processCallback", "close window\n");
	if (SpFramePart(window).close_style == SP_NO_CLOSE) {
	    return SP_TRUE;
	}
    } else if (message == WM_TASKTRAY) {
	if (lParam != WM_LBUTTONDOWN && lParam != WM_RBUTTONDOWN
	    && lParam != WM_MBUTTONDOWN) {
	    return SP_TRUE;
	}
    } else if (message == WM_MENUSELECT) {
	spComponent menu;

	menu = getCurrentMenu(window, (HMENU)lParam, LOWORD(wParam), HIWORD(wParam));
	
	if (menu != NULL && SpGetDescription(menu) != NULL) {
	    spSetHelpStatusText(window, SpGetDescription(menu));
	} else {
	    spSetHelpStatusText(window, "");
	}
	
	return SP_TRUE;
    } else if (message == WM_SYSCOLORCHANGE) {
	spDebug(10, "processCallback", "WM_SYSCOLORCHANGE\n");
	if (spIsCanvas(window) == SP_FALSE) {
	    HWND hnext;
	    spComponent canvas;
	    
	    spUpdateSystemGraphics();

	    hnext = FindWindowEx(SpPrimitiveArch(window).hwnd, NULL, SP_CANVAS_CLASS_NAME, NULL);
	    while (hnext != NULL) {
		canvas = getCurrentComponent(window, hnext);
		if (spIsCanvas(canvas) == SP_TRUE) {
		    spRedrawCanvas(canvas);
		}
		hnext = FindWindowEx(SpPrimitiveArch(window).hwnd, hnext, SP_CANVAS_CLASS_NAME, NULL);
	    }
	}
	return SP_FALSE;
    } else if (message == WM_SETFOCUS || message == WM_KILLFOCUS) {
	if (spIsCanvas(window) == SP_TRUE
	    && SpCanvasPart(window).focusable == SP_TRUE) {
	    spDebug(10, "processCallback", "canvas focus changed\n");
	    spRedrawCanvas(window);
	    flag = SP_TRUE;
	}
    } else if (message == WM_CHAR) {
	unsigned char c = (unsigned char)wParam;
	spDebug(10, "processCallback", "WM_CHAR: %c\n", c);
	
	if (c == '\r' || c == '\b' || c == '\n'
	    || c == '\t' || c == 0x01b/*ESC*/) {
	    return SP_TRUE;
	}
    } else if (message == WM_KEYDOWN) {
	spKeySym key_sym;
	
	if (spPrimitiveGetCallbackKeySym(window, &key_sym) == SP_TRUE
	    && key_sym == SPK_Character) {
	    spDebug(10, "processCallback", "WM_KEYDOWN: character\n");
	    return SP_FALSE;
	} else {
	    spDebug(10, "processCallback", "WM_KEYDOWN: wParam = %ld\n", wParam);
	    switch ((int)wParam) {
	      case VK_MENU:
	      case VK_CONTROL:
	      case VK_SHIFT:
	      case VK_ESCAPE:
	      case VK_CAPITAL:
		spDebug(10, "processCallback", "WM_KEYDOWN: num repeat = %d\n",
			LOWORD(lParam));
		if (LOWORD(lParam) > 1) {
		    return SP_TRUE;
		}
		break;
	      case VK_APPS:
		if (GetCursorPos(&point) && ScreenToClient(SpPrimitiveArch(window).hwnd, &point)) {
		    SetFocus(SpPrimitiveArch(window).hwnd);
		    PostMessage(SpPrimitiveArch(window).hwnd,
				WM_RBUTTONDOWN, (WPARAM)MK_RBUTTON, MAKELPARAM(point.x, point.y));
		    return SP_TRUE;
		}
	      default:
		break;
	    }
	}
    } else if (message == WM_KEYUP) {
	if (spIsPrimitive(window) == SP_TRUE) {
	    switch ((int)wParam) {
	      case VK_APPS:
		if (GetCursorPos(&point) && ScreenToClient(SpPrimitiveArch(window).hwnd, &point)) {
		    PostMessage(SpPrimitiveArch(window).hwnd,
				WM_RBUTTONUP, (WPARAM)MK_RBUTTON, MAKELPARAM(point.x, point.y));
		    return SP_TRUE;
		}
	      default:
		break;
	    }
	} else {
	    return SP_TRUE;
	}
    } else if (message == WM_DROPFILES) {
	if (spIsFrame(window) == SP_TRUE && SpFrameArch(window).drop_call_func != NULL) {
	    int i;
	    int argc;
	    char **argv;
	    HDROP hdrop;
	
	    SetForegroundWindow(SpPrimitiveArch(window).hwnd);
	    
            hdrop = (HDROP)wParam;
	    argc = DragQueryFile(hdrop, 0xFFFFFFFF, NULL, 0);
	    argv = xalloc(argc, char *);
	    for (i = 0; i < argc; i++) {
		argv[i] = xalloc(SP_MAX_PATHNAME, char);
                DragQueryFile(hdrop, i, argv[i], SP_MAX_PATHNAME);
	    }
	    
	    SpFrameArch(window).drop_call_func(window, SpFrameArch(window).drop_call_data,
					       argc, argv);

	    for (i = 0; i < argc; i++) xfree(argv[i]);
	    xfree(argv);
	    DragFinish(hdrop);
	}
	return SP_TRUE;
    } else if (message == WM_NOTIFY) {
	int index;
	spComponent component;
	NMHDR *hdr = (NMHDR *)lParam;

	component = getCurrentComponent(window, hdr->hwndFrom);

	if (spIsTabBox(component) == SP_TRUE) {
	    spDebug(80, "processCallback", "WM_NOTIFY: tab, code = %d\n",
		    hdr->code);
	    if (hdr->code == (UINT)TCN_SELCHANGE) {
		index = spGetSelectedTabIndex(component);
		spMapTabItem(component, index);
	    }
	    flag = SP_TRUE;
	} else if (hdr->code == (UINT)TTN_NEEDTEXT
		   && spIsFrame(window) == SP_TRUE
		   && SpFramePart(window).tool_bar != NULL) {
	    spComponent child;
	    LPTOOLTIPTEXT ttext = (LPTOOLTIPTEXT)lParam;
	    
	    child = SpGetChild(SpFramePart(window).tool_bar);
	    
	    while (child != NULL) {
		if (ttext->hdr.idFrom == (UINT)SpComponentPart(child).component_id) {
		    if (!strnone(SpGetDescription(child))) {
			ttext->lpszText = SpGetDescription(child);
		    }
		    break;
		}
		child = SpGetNextComponent(child);
	    }
	    flag = SP_TRUE;
	}
    } else if (message == WM_LBUTTONDOWN || message == WM_RBUTTONDOWN ||
	       message == WM_MBUTTONDOWN) {
	capture_window = window;
	point.x = LOWORD(lParam); point.y = HIWORD(lParam);
	spDebug(50, "processCallback", "BUTTONDOWN: x = %d, y = %d\n", point.x, point.y);
	
	ClientToScreen(SpPrimitiveArch(window).hwnd, &point);
	capture_dx = point.x; capture_dy = point.y;
	
	GetWindowRect(SpPrimitiveArch(SpGetWindow(window)).hwnd, &rect);
	point.x = rect.left; point.y = rect.top;
	capture_dx -= point.x; capture_dy -= point.y;

	SetFocus(SpPrimitiveArch(window).hwnd);
	SetCapture(SpPrimitiveArch(window).hwnd);
	spDebug(10, "processCallback", "capture started\n");
	need_capture = SP_TRUE;
	flag = SP_TRUE;
    } else if (message == WM_MOUSEMOVE &&
	       (wParam & (MK_LBUTTON | MK_RBUTTON | MK_MBUTTON))) {
	if (window != capture_window) {
	    return SP_FALSE;
	}
	if (spIsCanvas(window) == SP_TRUE
	    && SpCanvasPart(window).capture_flag == SP_TRUE) {
	    point.x = LOWORD(lParam); point.y = HIWORD(lParam);
	    ClientToScreen(SpPrimitiveArch(window).hwnd, &point);
	    point.x -= capture_dx;
	    point.y -= capture_dy;
	    
	    GetWindowRect(SpPrimitiveArch(SpGetWindow(window)).hwnd, &rect);
	    SpComponentPart(SpGetWindow(window)).x = point.x;
	    SpComponentPart(SpGetWindow(window)).y = point.y;
	    MoveWindow(SpPrimitiveArch(SpGetWindow(window)).hwnd,
		       SpComponentPart(SpGetWindow(window)).x,
		       SpComponentPart(SpGetWindow(window)).y,
		       rect.right - rect.left, rect.bottom - rect.top, TRUE);
	    
	    flag = SP_TRUE;
	}
    } else if (message == WM_LBUTTONUP || message == WM_RBUTTONUP ||
	       message == WM_MBUTTONUP) {
	capture_dx = -1; capture_dy = -1;
	ReleaseCapture();
	flag = SP_TRUE;
	if (window != capture_window) {
	    capture_window = NULL;
	    return SP_FALSE;
	} else {
	    capture_window = NULL;
	}
    } else if (message == WM_PAINT) {
	spDebug(50, "processCallback", "WM_PAINT: %s\n", SpGetClassName(window));
	if (SpPrimitiveArch(SpGetWindow(window)).realize_flag == SP_FALSE) {
	    spDebug(50, "processCallback", "WM_PAINT before realization\n");
	    return SP_FALSE;
	}
    } else if (message == WM_SETCURSOR) {
#if 0
	if (SpPrimitiveArch(window).hcursor != NULL) {
	    SetCursor(SpPrimitiveArch(window).hcursor);
	} else {
	    SetCursor(LoadCursor(NULL, IDC_ARROW));
	}
	return SP_TRUE;
#else
	if (SpPrimitiveArch(window).hcursor != NULL) {
	    SetCursor(SpPrimitiveArch(window).hcursor);
	    return SP_TRUE;
	} else {
	    return SP_FALSE;
	}
#endif
    } else if (message == WM_COMMAND) {
	sub_message = HIWORD(wParam);
	if (sub_message == EN_SETFOCUS) {
	    spDebug(50, "processCallback", "EN_SETFOCUS\n");
	    SpFrameArch(SpGetWindow(window)).hfocus_text = (HWND)lParam;
	} else if (sub_message == EN_KILLFOCUS) {
	    spDebug(50, "processCallback", "EN_KILLFOCUS\n");
	    SpFrameArch(SpGetWindow(window)).hfocus_text = NULL;
	}
    } else if (message == WM_VSCROLL || message == WM_HSCROLL) {
	if ((scroll_bar = getCurrentComponent(window, (HWND)lParam)) == NULL) {
	    scroll_bar = window;
	}
	SpPrimitiveArch(scroll_bar).message = message;
	if (spIsSubClass(scroll_bar, SpTrackBar) == SP_TRUE) {
	    if (SpPrimitiveArch(scroll_bar).message == WM_HSCROLL) {
		sub_message = LOWORD(wParam);
		switch (sub_message) {
		  case TB_LINEUP:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).increment;
		    break;
		  case TB_LINEDOWN:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).increment;
		    break;
		  case TB_PAGEUP:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case TB_PAGEDOWN:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case TB_THUMBPOSITION:
		  case TB_THUMBTRACK:
		    if (sub_message == TB_THUMBTRACK
			&& SpSliderPart(scroll_bar).track_call_on == SP_FALSE) {
			return SP_TRUE;
		    }

		    /* get current value */
		    SpSliderPart(scroll_bar).value =
			SendMessage(SpPrimitiveArch(scroll_bar).hwnd,
				    TBM_GETPOS, (WPARAM)0, (LPARAM)0) * SpSliderPart(scroll_bar).scroll_coef;
		    break;
		  case TB_TOP:
		    SpSliderPart(scroll_bar).value = SpSliderPart(scroll_bar).minimum;
		    break;
		  case TB_BOTTOM:
		    SpSliderPart(scroll_bar).value = SpSliderPart(scroll_bar).maximum;
		    break;
		  default:
		    return SP_TRUE;
		}
	    } else {
		sub_message = LOWORD(wParam);
		switch (sub_message) {
		  case TB_LINEUP:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).increment;
		    break;
		  case TB_LINEDOWN:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).increment;
		    break;
		  case TB_PAGEUP:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case TB_PAGEDOWN:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case TB_THUMBPOSITION:
		  case TB_THUMBTRACK:
		    if (sub_message == TB_THUMBTRACK
			&& SpSliderPart(scroll_bar).track_call_on == SP_FALSE) {
			return SP_TRUE;
		    }

		    /* get current value */
		    SpSliderPart(scroll_bar).value =
			SendMessage(SpPrimitiveArch(scroll_bar).hwnd,
				    TBM_GETPOS, (WPARAM)0, (LPARAM)0) * SpSliderPart(scroll_bar).scroll_coef;
		    break;
		  case TB_TOP:
		    SpSliderPart(scroll_bar).value = SpSliderPart(scroll_bar).minimum;
		    break;
		  case TB_BOTTOM:
		    SpSliderPart(scroll_bar).value = SpSliderPart(scroll_bar).maximum;
		    break;
		  default:
		    return SP_TRUE;
		}
	    }
	    spUpdateTrackBar(scroll_bar);
	} else {
	    if (SpPrimitiveArch(scroll_bar).message == WM_HSCROLL) {
		sub_message = LOWORD(wParam);
		switch (sub_message) {
		  case SB_LINELEFT:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).increment;
		    break;
		  case SB_LINERIGHT:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).increment;
		    break;
		  case SB_PAGELEFT:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case SB_PAGERIGHT:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case SB_THUMBPOSITION:
		  case SB_THUMBTRACK:
		    if (sub_message == SB_THUMBTRACK
			&& SpSliderPart(scroll_bar).track_call_on == SP_FALSE) {
			return SP_TRUE;
		    }

		    /* get current value */
		    SpSliderPart(scroll_bar).value =
			(int)HIWORD(wParam) * SpSliderPart(scroll_bar).scroll_coef;
		    break;
		  default:
		    return SP_TRUE;
		}
	    } else {
		sub_message = LOWORD(wParam);
		switch (sub_message) {
		  case SB_LINEUP:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).increment;
		    break;
		  case SB_LINEDOWN:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).increment;
		    break;
		  case SB_PAGEUP:
		    SpSliderPart(scroll_bar).value
			+= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case SB_PAGEDOWN:
		    SpSliderPart(scroll_bar).value
			-= SpSliderPart(scroll_bar).page_increment;
		    break;
		  case SB_THUMBPOSITION:
		  case SB_THUMBTRACK:
		    if (sub_message == SB_THUMBTRACK
			&& SpSliderPart(scroll_bar).track_call_on == SP_FALSE) {
			return SP_TRUE;
		    }

		    /* get current value */
		    SpSliderPart(scroll_bar).value =
			(int)HIWORD(wParam) * SpSliderPart(scroll_bar).scroll_coef;
		    break;
		  default:
		    return SP_TRUE;
		}
	    }
	    spUpdateSlider(scroll_bar);
	}
	flag = SP_TRUE;
    }

    component_id = SpGetComponentId(window);
    if (SpGetWindow(window) != NULL) {
	parent_window = SpGetWindow(window);
    } else {
	parent_window = window;
    }
    num_callback = SpPrimitivePart(parent_window).num_callback;
		
    if (SpPrimitivePart(parent_window).callbacks != NULL) {
	for (k = 0; k < num_callback; k++) {
	    callbacks = SpPrimitivePart(parent_window).callbacks;

	    if (callbacks[k].component == NULL
		|| (spIsCanvas(callbacks[k].component) == SP_TRUE
		    && SpPrimitiveArch(window).hwnd != SpPrimitiveArch(callbacks[k].component).hwnd)) {
		spDebug(80, "processCallback", "continue\n");
		continue;
	    }
	    
	    if (callbacks[k].message == WM_COMMAND &&
		(message == WM_COMMAND || message == WM_CUT || message == WM_PASTE ||
		 message == WM_COPY || message == WM_CLEAR || message == WM_UNDO)) {
		if (callbacks[k].component_id == LOWORD(wParam)) {
		    if (spIsSubClass(callbacks[k].component, SpText)) {
			sub_message = HIWORD(wParam);
			if (spIsSubClass(callbacks[k].component, SpComboBox) == SP_TRUE) {
			    spDebug(80, "processCallback",
				    "SpComboBox sub_message: %d\n", sub_message);
			    if (sub_message != CBN_EDITCHANGE &&
				sub_message != CBN_SELCHANGE) {
				continue;
			    }
			} else {
			    if (message == WM_COMMAND && sub_message != EN_CHANGE) {
				continue;
			    }
			}
		    }
		    SpPrimitiveArch(callbacks[k].component).message = message;
		    SpPrimitiveArch(callbacks[k].component).wParam = wParam;
		    SpPrimitiveArch(callbacks[k].component).lParam = lParam;
		    spComponentCallbackFunc(&callbacks[k]);
		    flag = SP_TRUE;
		}
	    } else if (callbacks[k].message == message) {
		spDebug(100, "processCallback", "message = %d\n", message);
		if ((message == WM_VSCROLL || message == WM_HSCROLL) &&
		    scroll_bar == callbacks[k].component) {
		    if (1	/*(sub_message != SB_THUMBTRACK && sub_message != TB_THUMBTRACK)
				  || callbacks[k].command_id == SB_THUMBTRACK*/) {
			SpPrimitiveArch(callbacks[k].component).message = message;
			SpPrimitiveArch(callbacks[k].component).wParam = wParam;
			SpPrimitiveArch(callbacks[k].component).lParam = lParam;
			spComponentCallbackFunc(&callbacks[k]);
			spDebug(80, "processCallback", "scroll callback: %d\n",
				(int)sub_message);
			flag = SP_TRUE;
		    }
		} else if (message == WM_PAINT &&
			   SpPrimitiveArch(window).hwnd != SpPrimitiveArch(callbacks[k].component).hwnd) {
		    continue;
		} else if (message == WM_MOUSEMOVE && callbacks[k].command_id != 0 &&
			   !(wParam & callbacks[k].command_id)) {
		    continue;
		} else {
		    switch (message) {
		      case WM_KEYDOWN:
			if (spIsSubClass(callbacks[k].component, SpTextField) == SP_TRUE
			    && ((int)wParam != VK_RETURN
				|| SpPrimitiveArch(callbacks[k].component).hwnd != GetFocus())) {
			    continue;
			}
		      case WM_CHAR:
		      case WM_IME_CHAR:
		      case WM_KEYUP:
		      case WM_LBUTTONDOWN:
		      case WM_RBUTTONDOWN:
		      case WM_MBUTTONDOWN:
		      case WM_LBUTTONUP:
		      case WM_RBUTTONUP:
		      case WM_MBUTTONUP:
		      case WM_MOUSEMOVE:
			if (SpComponentPart(callbacks[k].component).sensitive_flag == SP_FALSE) {
			    continue;
			}
		      case WM_PAINT:
		      case WM_SIZE:
		      case WM_TASKTRAY:
		      case WM_CLOSE:
		      case WM_DESTROY:
			SpPrimitiveArch(callbacks[k].component).message = message;
			SpPrimitiveArch(callbacks[k].component).wParam = wParam;
			SpPrimitiveArch(callbacks[k].component).lParam = lParam;

			spComponentCallbackFunc(&callbacks[k]);
			flag = SP_TRUE;
			break;
		      default:
			break;
		    }

		    if (message == WM_DESTROY
			|| (message == WM_CLOSE &&
			    SpFramePart(window).close_style == SP_DESTROY_CLOSE)) {
			flag = SP_FALSE;
		    }
		}
	    }
    
	    if (message != WM_DESTROY
		&& component_id == spGetDestroyedComponentId()) {
		flag = SP_TRUE;
		break;
	    }
	}
    }

    if (component_id != spGetDestroyedComponentId()) {
	if (message == WM_CLOSE && SpFramePart(window).close_style == SP_UNMAP_CLOSE) {
	    spPopdownWindow(window);
	    flag = SP_TRUE;
	}
	if (need_capture == SP_TRUE) {
	    /* cursor change doesn't work before capturing */
	    if (spIsCanvas(window) == SP_TRUE
		&& SpPrimitiveArch(window).hcursor != NULL) {
		SetCursor(SpPrimitiveArch(window).hcursor);
	    }
	}
    }
    spDebug(100, "processCallback", "done: message = %d, flag = %d\n",
	    message, flag);
    
    return flag;
}

LRESULT CALLBACK spWindowFunc(HWND hwnd, UINT message,
			      WPARAM wParam, LPARAM lParam)
{
    spComponent window = NULL;

    if ((window = getCurrentWindow(hwnd, message, wParam, lParam)) != NULL) {
	if (processCallback(window) == SP_TRUE) {
	    return 0;
	} else if (message == WM_DESTROY) {
	    spDebug(10, "spWindowFunc", "destroy window\n");
	    spDestroyWindow(window);
	    return 0;
	}
    }

    return DefWindowProc(hwnd, message, wParam, lParam);
}

BOOL CALLBACK spDialogFunc(HWND hwnd, UINT message,
			   WPARAM wParam, LPARAM lParam)
{
    spComponent window;
    
    window = getCurrentWindow(hwnd, message, wParam, lParam);
    if (processCallback(window) == SP_TRUE) {
	return 1;
    } else {
	return 0;
    }
}

int spTranslateAllAcceleratorWin(MSG *msg)
{
    spComponent window;
    HWND hwnd;
    HWND hfocus;
    char class_name[128];

    spDebug(80, "spTranslateAllAcceleratorWin", "in\n");
    
    hwnd = GetActiveWindow();
    window = getCurrentComponent(NULL, hwnd);
    
    if (spIsPrimitive(window) == SP_TRUE) {
	if (msg->message == WM_KEYDOWN && spIsFrame(window) == SP_TRUE
	    && (msg->wParam == VK_ESCAPE || msg->wParam == VK_RETURN)) {
	    spDebug(80, "spTranslateAllAcceleratorWin", "escape or return key pressed\n");
	    if (msg->wParam == VK_ESCAPE
		&& spIsButton(SpFramePart(window).cancel_button) == SP_TRUE) {
		PostMessage(SpPrimitiveArch(SpFramePart(window).cancel_button).hwnd,
			    BM_CLICK, 0, 0);
		return 1;
	    } else if (msg->wParam == VK_RETURN) {
		spBool edit_control = SP_FALSE;
		spBool multi_line = SP_FALSE;

		strcpy(class_name, "");
		if ((hfocus = msg->hwnd) != NULL
		    && GetClassName(hfocus, class_name, sizeof(class_name))) {
		    if (strcaseeq(class_name, "LISTBOX")) {
			PostMessage(hwnd, WM_COMMAND,
				    MAKELONG(GetWindowLong(hfocus, GWL_ID),
					     LBN_DBLCLK), (LPARAM)hfocus);
			return 1;
		    } else if (strcaseeq(class_name, "EDIT")) {
			edit_control = SP_TRUE;
			if ((GetWindowLong(hfocus, GWL_STYLE) & ES_MULTILINE)) {
			    multi_line = SP_TRUE;
			}
		    }
		}

		if (multi_line == SP_FALSE) {
		    if (hfocus == NULL || !strcaseeq(class_name, "BUTTON")) {
			if (spIsButton(SpFramePart(window).default_button) == SP_TRUE) {
			    hfocus = SpPrimitiveArch(SpFramePart(window).default_button).hwnd;
			}
		    }

		    if (hfocus != NULL && (GetWindowLong(hfocus, GWL_STYLE) & BS_DEFPUSHBUTTON)) {
			PostMessage(hfocus, BM_CLICK, 0, 0);
			return 1;
		    }
		}
		
		if (SpFramePart(window).window_type != SP_DIALOG_WINDOW
		    && edit_control == SP_TRUE && multi_line == SP_FALSE) {
		    /* VK_RETURN in single line text */
		    spDebug(60, "spTranslateAllAcceleratorWin", "VK_RETURN in text field\n");
		    PostMessage(hwnd, msg->message, msg->wParam, msg->lParam);
		    return 1;
		}

	    }
	} else if (msg->message == WM_KEYDOWN && msg->wParam == VK_TAB) {
	    spDebug(50, "spTranslateAllAcceleratorWin", "tab key pressed\n");
	    if ((hfocus = msg->hwnd) != NULL
		&& GetClassName(hfocus, class_name, sizeof(class_name))
		&& strcaseeq(class_name, "EDIT")
		&& (GetWindowLong(hfocus, GWL_STYLE) & ES_MULTILINE)) {
		spDebug(50, "spTranslateAllAcceleratorWin", "EM_REPLACESEL\n");
		if (0x8000 & GetKeyState(VK_SHIFT)) {
		    SetFocus(GetNextDlgTabItem(hwnd, hfocus, TRUE));
		} else {
		    PostMessage(hfocus, WM_CHAR, '\t', 0L);
		}
		return 1;
	    } else if (IsWindow(hwnd) && IsDialogMessage(hwnd, msg)) {
		return 1;
	    }
	} else if (msg->message == 0x020A/*WM_MOUSEWHEEL*/) {
	    int key_sym;
	    short delta;
	    spComponent canvas;

	    hfocus = msg->hwnd;
	    canvas = getCurrentComponent(NULL, hfocus);
	    
	    if (spIsCanvas(canvas) == SP_TRUE) {
		delta = (short)HIWORD(msg->wParam);
		spDebug(80, "spTranslateAllAcceleratorWin",
			"WM_MOUSEWHEEL: delta = %d\n", delta);
		if (delta > 0) {
		    key_sym = VK_PRIOR;
		} else {
		    key_sym = VK_NEXT;
		}
		PostMessage(hfocus, WM_KEYDOWN, key_sym, 0L);
		PostMessage(hfocus, WM_KEYUP, key_sym, 0L);
		return 1;
	    }
	} else if (SpPrimitiveArch(window).haccel != NULL) {
	    if (TranslateAccelerator(hwnd, SpPrimitiveArch(window).haccel, msg)) {
		spDebug(50, "spTranslateAllAcceleratorWin", "accelerated\n");
		return 1;
	    }
	}
    }
    spDebug(80, "spTranslateAllAcceleratorWin", "done\n");
    
    return 0;
}

spBool spShowToolTipArch(spComponent component)
{
    TOOLINFO ti;
    spComponent window;

    if (SpPrimitiveArch(component).hwnd == NULL) return SP_FALSE;
    
    spDebug(30, "spShowToolTipArch", "description = %s\n",
	    SpComponentPart(component).description);
    
    window = SpGetWindow(component);
    
    if (SpPrimitiveArch(window).htooltip == NULL) {
	SpPrimitiveArch(window).htooltip =
	    CreateWindowEx(WS_EX_TOOLWINDOW, TOOLTIPS_CLASS, (LPSTR)NULL,
			   TTS_ALWAYSTIP,
			   CW_USEDEFAULT, CW_USEDEFAULT,
			   CW_USEDEFAULT, CW_USEDEFAULT, 
			   SpPrimitiveArch(window).hwnd, (HMENU)NULL,
			   SpTopLevelArch(sp_toplevel).hThisInst, NULL);
    }
 
    ti.cbSize = sizeof(TOOLINFO); 
    ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
    ti.hwnd = SpPrimitiveArch(window).hwnd;
    ti.hinst = SpTopLevelArch(sp_toplevel).hThisInst;
    ti.uId = (UINT)SpPrimitiveArch(component).hwnd;
    ti.lpszText = (LPSTR)SpComponentPart(component).description;
    ti.rect.left = 0; 	ti.rect.top = 0;
    ti.rect.right = 0; 	ti.rect.bottom = 0;
    
    if (!SendMessage(SpPrimitiveArch(window).htooltip, TTM_ADDTOOL,
		     0, (LPARAM)(LPTOOLINFO)&ti)) {
	spDebug(30, "spShowToolTipArch", "TTM_ADDTOOL error\n");
    }
		
    return SP_TRUE;
}
