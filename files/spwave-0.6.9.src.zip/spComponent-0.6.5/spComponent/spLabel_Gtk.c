/*
 *	spLabel_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLabelP.h>

void spLabelCreateArch(spComponent component)
{
    char *title = NULL;

    if (!strnone(SpComponentPart(component).title)) {
	title = SpComponentPart(component).title;
    } else {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    SpPrimitiveArch(component).widget = gtk_label_new(title);

#if GTK_CHECK_VERSION(1,2,0)
    if (SpLabelPart(component).alignment == SP_ALIGNMENT_BEGINNING) {
	gtk_misc_set_alignment(GTK_MISC(SpPrimitiveArch(component).widget), 0.0, 0.5);
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
	gtk_misc_set_alignment(GTK_MISC(SpPrimitiveArch(component).widget), 0.5, 0.5);
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
	gtk_misc_set_alignment(GTK_MISC(SpPrimitiveArch(component).widget), 1.0, 0.5);
    }
#else
    if (SpLabelPart(component).alignment == SP_ALIGNMENT_BEGINNING) {
	gtk_label_set_justify(GTK_LABEL(SpPrimitiveArch(component).widget),
			      GTK_JUSTIFY_LEFT);
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
	gtk_label_set_justify(GTK_LABEL(SpPrimitiveArch(component).widget),
			      GTK_JUSTIFY_CENTER);
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
	gtk_label_set_justify(GTK_LABEL(SpPrimitiveArch(component).widget),
			      GTK_JUSTIFY_RIGHT);
    }
#endif

    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    return;
}

void spLabelSetParamsArch(spComponent component)
{
    char *title = NULL;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;
	
	if (!strnone(title)) {
	    gtk_label_set(GTK_LABEL(SpPrimitiveArch(component).widget), title);
	}
    }

    return;
}
