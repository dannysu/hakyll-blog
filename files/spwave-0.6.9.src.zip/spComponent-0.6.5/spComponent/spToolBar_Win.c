/*
 *	spToolBar_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spToolBarP.h>

extern spTopLevel sp_toplevel;

void spToolBarPartInitArch(spComponent component)
{
    SpToolBarArch(component).hbitmap = NULL;
    return;
}

void spToolBarPartFreeArch(spComponent component)
{
    return;
}

void spToolBarCreateArch(spComponent component)
{
    TBADDBITMAP tbab;
    static char pathname[SP_MAX_PATHNAME] = "";
    static char filename[SP_MAX_PATHNAME] = "";
    
    if (!strnone(SpGetName(component))) {
	SpToolBarArch(component).hbitmap =
	    (HBITMAP)LoadImage(SpTopLevelArch(sp_toplevel).hThisInst,
			       SpGetName(component), IMAGE_BITMAP, 0, 0,
			       LR_LOADTRANSPARENT | LR_LOADMAP3DCOLORS);
	    
	if (SpToolBarArch(component).hbitmap == NULL) {
	    if (GetModuleFileName(NULL, pathname, sizeof(pathname))) {
		spDebug(10, "spToolBarCreateArch", "pathname = %s\n", pathname);
		spGetDirName(pathname);
		if (spIsDir(pathname) == SP_FALSE) {
		    strcpy(pathname, ".");
		}
	    } else {
		strcpy(pathname, ".");
	    }
	    spDebug(10, "spToolBarCreateArch", "pathname = %s\n", pathname);
		
	    sprintf(filename, "%s%c%s.bmp", pathname,
		    SP_DIR_SEPARATOR, SpGetName(component));
	    SpToolBarArch(component).hbitmap =
		(HBITMAP)LoadImage(NULL, filename, IMAGE_BITMAP, 0, 0,
				   LR_LOADTRANSPARENT | LR_LOADMAP3DCOLORS
				   | LR_LOADFROMFILE);
	    spDebug(10, "spToolBarCreateArch", "filename = %s\n", filename);
	}
	    
	if (SpToolBarArch(component).hbitmap == NULL) return;
	    
	/* create tool bar */
	SpPrimitiveArch(component).hwnd =
	    CreateWindowEx(0, TOOLBARCLASSNAME, NULL,
			   WS_CHILD | WS_VISIBLE | TBSTYLE_TOOLTIPS,
			   0, 0, 0, 0,
			   SpParentPrimitiveArch(component).hwnd,
			   (HMENU)SpComponentPart(component).component_id,
			   SpTopLevelArch(sp_toplevel).hThisInst,
			   NULL);
	SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		    (WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));
	    
	SendMessage(SpPrimitiveArch(component).hwnd, TB_BUTTONSTRUCTSIZE, 
		    (WPARAM)sizeof(TBBUTTON), 0);
	    
	SendMessage(SpPrimitiveArch(component).hwnd, TB_SETBITMAPSIZE, 0,
		    (LPARAM)MAKELONG(SpToolBarPart(component).bitmap_width,
				     SpToolBarPart(component).bitmap_height));
	    
	tbab.hInst = NULL; 
	tbab.nID = (UINT)SpToolBarArch(component).hbitmap;
	SendMessage(SpPrimitiveArch(component).hwnd, TB_ADDBITMAP,
		    (WPARAM)SpToolBarPart(component).num_bitmap, (WPARAM)&tbab); 
    }
    
    return;
}

void spToolBarSetParamsArch(spComponent component)
{
    return;
}
    
void spToolBarDestroyArch(spComponent component)
{
    if (SpToolBarArch(component).hbitmap != NULL) {
	DeleteObject(SpToolBarArch(component).hbitmap);
    }
    
    return;
}
