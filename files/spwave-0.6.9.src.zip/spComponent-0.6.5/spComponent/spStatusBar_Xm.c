/*
 *	spStatusBar_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spStatusBarP.h>

void spStatusBarPartInitArch(spComponent component)
{
    SpStatusBarArch(component).num_label = 0;
    SpStatusBarArch(component).labels = NULL;
    
    return;
}

void spStatusBarPartFreeArch(spComponent component)
{
    return;
}

void spStatusBarCreateArch(spComponent component, int *num_item)
{
    int i;
    int num_label = 0;
    int item_sizes[SP_MAX_STATUS_ITEM];
    int narg = 0;
    Arg args[10];
    Widget frame;
    Widget prev_frame;
    int pos;
    
    SpPrimitiveArch(component).widget = 
	XtVaCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
				xmFormWidgetClass, 
				SpParentPrimitiveArch(component).widget,
				XmNheight, SP_DEFAULT_STATUS_BAR_HEIGHT,
				XmNresizePolicy, XmRESIZE_NONE,
				NULL);
    
    if (SpStatusBarPart(component).item_sizes != NULL) {
	for (i = 0; i < SP_MAX_STATUS_ITEM; i++) {
	    if (SpStatusBarPart(component).item_sizes[i] <= 0) {
		if (SpStatusBarPart(component).use_last_item == SP_TRUE
		    || i <= 0) {
		    SpStatusBarPart(component).use_last_item = SP_TRUE;
		    num_label = i + 1;
		} else {
		    num_label = i;
		}
		item_sizes[i] = SpStatusBarPart(component).item_sizes[i];
		break;
	    } else {
		item_sizes[i] = SpStatusBarPart(component).item_sizes[i];
	    }
	}
    } else {
	item_sizes[0] = 0;
	num_label = 1;
    }
    
    SpStatusBarArch(component).num_label = num_label;
    SpStatusBarArch(component).labels = xalloc(SpStatusBarArch(component).num_label, Widget);
    
    pos = 0;
    prev_frame = NULL;
    for (i = 0; i < SpStatusBarArch(component).num_label; i++) {
	narg = 0;
	XtSetArg(args[narg], XmNtopAttachment, XmATTACH_FORM); narg++;
	XtSetArg(args[narg], XmNbottomAttachment,XmATTACH_FORM); narg++;
	if (prev_frame == NULL) {
	    XtSetArg(args[narg], XmNleftAttachment, XmATTACH_FORM); narg++;
	    XtSetArg(args[narg], XmNleftOffset, 0); narg++;
	    if (item_sizes[i] <= 0) {
		XtSetArg(args[narg], XmNrightAttachment, XmATTACH_FORM); narg++;
		XtSetArg(args[narg], XmNrightOffset, 0); narg++;
	    } else {
		pos += item_sizes[i];
		XtSetArg(args[narg], XmNrightAttachment, XmATTACH_OPPOSITE_FORM); narg++;
		XtSetArg(args[narg], XmNrightOffset, -item_sizes[i]); narg++;
	    }
	} else {
	    XtSetArg(args[narg], XmNleftAttachment, XmATTACH_WIDGET); narg++;
	    XtSetArg(args[narg], XmNleftWidget, prev_frame); narg++;
	    XtSetArg(args[narg], XmNleftOffset, 0); narg++;
	    if (item_sizes[i] <= 0) {
		XtSetArg(args[narg], XmNrightAttachment, XmATTACH_FORM); narg++;
		XtSetArg(args[narg], XmNrightOffset, 0); narg++;
	    } else {
		pos += item_sizes[i];
		XtSetArg(args[narg], XmNrightAttachment, XmATTACH_OPPOSITE_WIDGET); narg++;
		XtSetArg(args[narg], XmNrightWidget, prev_frame); narg++;
		XtSetArg(args[narg], XmNrightOffset, -item_sizes[i]); narg++;
	    }
	}

	XtSetArg(args[narg], XmNshadowType, XmSHADOW_IN); narg++;
	XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
	XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
	frame =  XtCreateManagedWidget("",
				       xmFrameWidgetClass,
				       SpPrimitiveArch(component).widget,
				       args, narg);
	    
	narg = 0;
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_BEGINNING); narg++;
	SpStatusBarArch(component).labels[i] =
	    XtCreateManagedWidget("",
				  xmLabelWidgetClass, frame,
				  args, narg);

	prev_frame = frame;
    }
    
    *num_item = SpStatusBarArch(component).num_label;

    return;
}

void spStatusBarSetParamsArch(spComponent component)
{
    return;
}

void spStatusBarDestroyArch(spComponent component)
{
    if (SpStatusBarArch(component).labels != NULL) {
	xfree(SpStatusBarArch(component).labels);
	SpStatusBarArch(component).labels = NULL;
    }
    
    return;
}

spBool spSetStatusTextArch(spComponent component, int index, char *string)
{
    short w, h;
    XmString xmstr;

    /* get current size to keep component size */
    XtVaGetValues(SpStatusBarArch(component).labels[index],
		  XmNwidth, &w, XmNheight, &h,
		  NULL);
    
    xmstr = XmStringCreate(string, XmFONTLIST_DEFAULT_TAG);
    XtVaSetValues(SpStatusBarArch(component).labels[index],
		  XmNlabelString, xmstr,
		  NULL);
    XmStringFree(xmstr);
	    
    /* set previous size */
    XtVaSetValues(SpStatusBarArch(component).labels[index],
		  XmNwidth, w, XmNheight, h,
		  NULL);

    return SP_TRUE;
}
