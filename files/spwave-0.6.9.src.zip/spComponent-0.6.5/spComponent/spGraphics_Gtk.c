/*
 *	spGraphics_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDraw.h>

#include <sp/spTopLevelP.h>
#include <sp/spPrimitiveP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

spBool spEqColorGtk(GdkColor *color1, GdkColor *color2)
{
    if (color1->red == color2->red
	&& color1->green == color2->green
	&& color1->blue == color2->blue) {
	return SP_TRUE;
    }

    return SP_FALSE;
}

void spGetColorValue(char *color_name, GdkColor *color)
{
    spDebug(80, "spGetColorValue", "in: color_name = %s\n", color_name);

    if (strcaseeq(color_name, "max")) {
	color->red = 65535;
	color->green = 65535;
	color->blue = 65535;
    } else if (strcaseeq(color_name, "min")) {
	color->red = 0;
	color->green = 0;
	color->blue = 0;
    } else {
	gdk_color_parse(color_name, color);
    }
    gdk_color_alloc(SpTopLevelArch(sp_toplevel).colormap, color);
    spDebug(10, "spGetColorValue", "r = %d, g = %d, b = %d\n", color->red, color->green, color->blue);
    
    return;
}

spPixel spGetColorPixel(char *color_name)
{
    spPixel pixel = 0L;
    GdkColor color;

    if (strnone(color_name)) return 0L;
    
    spGetColorValue(color_name, &color);
    pixel = spRGB(color.red/256, color.green/256, color.blue/256);
    
    return pixel;
}

spBool spGetCursorArch(spCursor cursor)
{
    guint shape;
    spCursorType cursor_type = cursor->type;
    
    switch (cursor_type) {
      case SP_CURSOR_TEXT:
	shape = GDK_XTERM;
	break;
      case SP_CURSOR_WAIT:
	shape = GDK_WATCH;
	break;
      case SP_CURSOR_CROSS:
	shape = GDK_CROSSHAIR;
	break;
      case SP_CURSOR_HAND:
	shape = GDK_HAND2;
	break;
      case SP_CURSOR_MOVE:
	shape = GDK_FLEUR;
	break;
      case SP_CURSOR_SIZE:
	shape = GDK_SIZING;
	break;
      case SP_CURSOR_SW_RESIZE:
	shape = GDK_TOP_LEFT_CORNER;
	break;
      case SP_CURSOR_SE_RESIZE:
	shape = GDK_TOP_RIGHT_CORNER;
	break;
      case SP_CURSOR_NW_RESIZE:
	shape = GDK_BOTTOM_LEFT_CORNER;
	break;
      case SP_CURSOR_NE_RESIZE:
	shape = GDK_BOTTOM_RIGHT_CORNER;
	break;
      case SP_CURSOR_N_RESIZE:
	shape = GDK_TOP_SIDE;
	break;
      case SP_CURSOR_S_RESIZE:
	shape = GDK_BOTTOM_SIDE;
	break;
      case SP_CURSOR_W_RESIZE:
	shape = GDK_LEFT_SIDE;
	break;
      case SP_CURSOR_E_RESIZE:
	shape = GDK_RIGHT_SIDE;
	break;
      default:
	shape = GDK_TOP_LEFT_ARROW;
	break;
    }

    if ((SpCursorArch(cursor).cursor = gdk_cursor_new(shape)) == NULL) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

void spDestroyCursorArch(spCursor cursor)
{
    gdk_cursor_destroy(SpCursorArch(cursor).cursor);
    return;
}

#if !GTK_CHECK_VERSION(1,2,0)
#include <gdk/gdkprivate.h>
#endif

void spSetGraphicsModeArch(spGraphics graphics, spGraphicsMode mode)
{
    GdkFunction function = GDK_COPY;

    if (graphics == NULL) return;
    
    switch (mode) {
      case SP_GM_COPY:
	function = GDK_COPY;
	break;
      case SP_GM_XOR:
	function = GDK_XOR;
	break;
      case SP_GM_INVERT:
	function = GDK_INVERT;
	break;
#if GTK_CHECK_VERSION(1,2,0)
      case SP_GM_AND:
	function = GDK_AND;
	break;
      case SP_GM_OR:
	function = GDK_OR;
	break;
#else
      case SP_GM_AND:
	{
	    GdkGCPrivate *private = (GdkGCPrivate*)SpGraphicsArch(graphics).gc;
	    XSetFunction (private->xdisplay, private->xgc, GXand);
	}
	return;
      case SP_GM_OR:
	{
	    GdkGCPrivate *private = (GdkGCPrivate*)SpGraphicsArch(graphics).gc;
	    XSetFunction (private->xdisplay, private->xgc, GXor);
	}
	return;
#endif
      default:
	break;
    }

    gdk_gc_set_function(SpGraphicsArch(graphics).gc, function);
    
    return;
}

void spGraphicsPartInitArch(spGraphics graphics)
{
    GdkGCValues gc_values;
    GdkGCValuesMask gc_values_mask;

    SpGraphicsArch(graphics).font = NULL;
    
    spGetColorValue("black", &gc_values.foreground);
    spGetColorValue("white", &gc_values.background);
    gc_values_mask = GDK_GC_FOREGROUND | GDK_GC_BACKGROUND;
    SpGraphicsArch(graphics).gc = gdk_gc_new_with_values(SpTopLevelArch(sp_toplevel).pixmap,
							 &gc_values,
							 gc_values_mask);
    
    return;
}

void spGraphicsPartFreeArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).font != NULL) {
	gdk_font_unref(SpGraphicsArch(graphics).font);
	SpGraphicsArch(graphics).font = NULL;
    }
    if (SpGraphicsArch(graphics).gc != NULL) {
	gdk_gc_unref(SpGraphicsArch(graphics).gc);
	SpGraphicsArch(graphics).gc = NULL;
    }
    
    return;
}

static GdkLineStyle getLineType(spGraphics graphics, char **dash_list, int *ndash)
{
    int n = 0;
    GdkLineStyle style = GDK_LINE_SOLID;
    char *list = NULL;
    static char dash_line[] = {9, 3};
    static char dot_line[] = {2, 4};
    static char dash_dot_line[] = {9, 3, 2, 3};
    static char dash_dot_dot_line[] = {9, 3, 2, 3, 2, 3};

    if (graphics == NULL) return style;

    switch (SpGraphicsPart(graphics).line_type) {
      case SP_LINE_DASH:
	style = GDK_LINE_ON_OFF_DASH;
	list = dash_line;
	n = 2;
	break;
      case SP_LINE_DOT:
	style = GDK_LINE_ON_OFF_DASH;
	list = dot_line;
	n = 2;
	break;
      case SP_LINE_DASH_DOT:
	style = GDK_LINE_ON_OFF_DASH;
	list = dash_dot_line;
	n = 4;
	break;
      case SP_LINE_DASH_DOT_DOT:
	style = GDK_LINE_ON_OFF_DASH;
	list = dash_dot_dot_line;
	n = 6;
	break;
      default:
	style = GDK_LINE_SOLID;
	list = NULL;
	n = 0;
	break;
    }

    if (dash_list != NULL) *dash_list = list;
    if (ndash != NULL) *ndash = n;

    return style;
}

void spGraphicsCreateArch(spGraphics graphics)
{
    GdkLineStyle line_style;
    int ndash;
    char *dash_list = NULL;
    
    line_style = getLineType(graphics, &dash_list, &ndash);
    
    gdk_gc_set_line_attributes(SpGraphicsArch(graphics).gc,
			       SpGraphicsPart(graphics).line_width,
			       line_style,
			       GDK_CAP_BUTT,
			       GDK_JOIN_MITER);

    if (line_style != GDK_LINE_SOLID && dash_list != NULL) {
#if GTK_CHECK_VERSION(1,2,0)
	gdk_gc_set_dashes(SpGraphicsArch(graphics).gc, 0, dash_list, ndash);
#else
	GdkGCPrivate *private = (GdkGCPrivate*)SpGraphicsArch(graphics).gc;
	
	XSetDashes(private->xdisplay, private->xgc, 0, dash_list, ndash);
#endif
    }
    
    spSetGraphicsModeArch(graphics, SpGraphicsPart(graphics).mode);
    
    spSetForegroundPixelArch(graphics);
    spSetBackgroundPixelArch(graphics);
    
    return;
}

void spSetFontArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).font != NULL) {
	gdk_font_unref(SpGraphicsArch(graphics).font);
    }

    if (!strnone(SpGraphicsPart(graphics).font_name)) {
	spDebug(10, "spSetFontArch", "font = %s\n",
		SpGraphicsPart(graphics).font_name);

	if ((SpGraphicsArch(graphics).font =
	     gdk_fontset_load(SpGraphicsPart(graphics).font_name)) == NULL) {
	    SpGraphicsArch(graphics).font =
		gdk_font_load(SpGraphicsPart(graphics).font_name);
	}
    } else {
	SpGraphicsArch(graphics).font =
	    gdk_fontset_load("-*-*-medium-r-normal--14-*-*-*-*-*-*-*");
    }
    
    if (SpGraphicsArch(graphics).font == NULL) {
	SpGraphicsArch(graphics).font =
	    gdk_fontset_load("-*-*-*-*-*--*-*-*-*-*-*-*-*");
    }
    
    return;
}

spBool spGetSystemColorPixelArch(spSystemColorType type, spPixel *pixel)
{
#if GTK_CHECK_VERSION(1,2,0)
    spComponent window;
    
    if ((window = spGetChild(NULL)) != NULL) {
	GdkColor color;

	switch (type) {
	  case SP_SYSTEM_COLOR_BACKGROUND:
	  case SP_SYSTEM_COLOR_TAB_BACKGROUND:
	    color = SpPrimitiveArch(window).widget->style->bg[GTK_STATE_NORMAL];
	    break;
	  case SP_SYSTEM_COLOR_TOP_SHADOW:
	    color = SpPrimitiveArch(window).widget->style->light[GTK_STATE_NORMAL];
	    break;
	  case SP_SYSTEM_COLOR_BOTTOM_SHADOW:
	    color = SpPrimitiveArch(window).widget->style->dark[GTK_STATE_NORMAL];
	    break;
	  case SP_SYSTEM_COLOR_HIGHLIGHT:
	    color = SpPrimitiveArch(window).widget->style->light[GTK_STATE_NORMAL];
	    break;
	  case SP_SYSTEM_COLOR_DARK_SHADOW:
	    color = SpPrimitiveArch(window).widget->style->black;
	    break;
	  case SP_SYSTEM_COLOR_BLACK:
	    color = SpPrimitiveArch(window).widget->style->black;
	    break;
	  case SP_SYSTEM_COLOR_WHITE:
	    color = SpPrimitiveArch(window).widget->style->white;
	    break;
	  case SP_SYSTEM_COLOR_FOCUS:
	    color = SpPrimitiveArch(window).widget->style->black;
	    break;
	  default:
	    return SP_FALSE;
	}
	
	gdk_color_alloc(SpTopLevelArch(sp_toplevel).colormap, &color);
	*pixel = spRGB(color.red/256, color.green/256, color.blue/256);
	
	return SP_TRUE;
    }
#endif
    
    return spGetSystemColorPixelNormal(type, pixel);
}

static spBool spPixelToGdkColor(spPixel pixel, GdkColor *color)
{
    color->red = 256 * (unsigned short)spGetRValue(pixel);
    color->green = 256 * (unsigned short)spGetGValue(pixel);
    color->blue = 256 * (unsigned short)spGetBValue(pixel);
    if (!gdk_color_alloc(SpTopLevelArch(sp_toplevel).colormap, color)) {
	spDebug(80, "spPixelToGdkColor", "gdk_color_alloc failed\n");
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spSetForegroundPixelArch(spGraphics graphics)
{
    GdkColor color;

    if (spPixelToGdkColor(SpGraphicsPart(graphics).fg_pixel, &color) == SP_TRUE) {
	gdk_gc_set_foreground(SpGraphicsArch(graphics).gc, &color);
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spSetBackgroundPixelArch(spGraphics graphics)
{
    GdkColor color;

    if (spPixelToGdkColor(SpGraphicsPart(graphics).bg_pixel, &color) == SP_TRUE) {
	gdk_gc_set_background(SpGraphicsArch(graphics).gc, &color);
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

char **spGetFontFamilyListArch(void)
{
    return spGetFontFamilyListX11(GDK_DISPLAY());
}

spBool spIsFontSizeSupportedArch(int family, unsigned long style, int size)
{
    return spIsFontSizeSupportedX11(GDK_DISPLAY(), family, style, size);
}
