/*
 *	spText_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spList.h>
#include <sp/spDialog.h>

#include <sp/spComboBoxP.h>
#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spTextP.h>

void spSetControlFontMac(spComponent component, char *font_name)
{
    if (strnone(font_name)
	|| spGetAppearanceVersionMac() < 0x00000101) return;
    
    if (SpPrimitiveArch(component).control != NULL) {
	ControlFontStyleRec fsrec;

	fsrec.flags = kControlUseFontMask | kControlUseFaceMask | kControlUseSizeMask;
	spFontNameToFontIdMac(font_name,
			      &fsrec.font, &fsrec.style, &fsrec.size);
	    
	SetControlFontStyle(SpPrimitiveArch(component).control, &fsrec);
    }

    return;
}

void spTEFromScrapMac(void)
{
    TEFromScrap();
    return;
}

void spTEToScrapMac(void)
{
#if !TARGET_API_MAC_CARBON
    ZeroScrap();
#else
    ClearCurrentScrap();
#endif
    TEToScrap();
    return;
}

void spGetTextFrameRectMac(spComponent text, Rect *prect)
{
    Rect rect;
    
    if (SpPrimitiveArch(text).control != NULL) {
	rect = SpPrimitiveArch(text).rect;
	if (spIsComboBox(text) == SP_TRUE) {
	    rect.right -= (SP_COMBO_BOX_SPACING + SP_COMBO_BOX_BUTTON_SIZE);
	}
    } else {
	rect = (*SpTextArch(text).text)->viewRect;
	InsetRect(&rect, -SP_TEXT_MARGIN, -SP_TEXT_MARGIN);
    }
    
    *prect = rect;

    return;
}

spBool spActivateTextMac(spComponent text, spBool foreground)
{
    Rect rect;
    GrafPtr save_port;
    
    if (spIsText(text) == SP_TRUE) {
	if (SpTextArch(text).activated == SP_FALSE) {
	    spDebug(50, "spActivateTextMac", "activate: %ld\n",
		    SpGetComponentId(text));

	    if (SpPrimitiveArch(text).control != NULL) {
		SetKeyboardFocus(SpPrimitiveArch(SpGetWindow(text)).window,
				 SpPrimitiveArch(text).control,
				 kControlEditTextPart);
		if (foreground == SP_TRUE) {
		    ActivateControl(SpPrimitiveArch(text).control);
		} else {
		    Draw1Control(SpPrimitiveArch(text).control);
		}
	    } else {
		spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    
		spGetTextFrameRectMac(text, &rect);
		spDrawTextFrameMac(rect, SP_TRUE, SP_TRUE);
	    
		spGetOriginalRGBMac();
		spSetNormalRGBMac();
	    
		TEActivate(SpTextArch(text).text);
	    
		spSetOriginalRGBMac();
	
		spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	    }
	    SpTextArch(text).activated = SP_TRUE;
	    
	    spDebug(50, "spActivateTextMac", "done\n");
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

spBool spDeactivateTextMac(spComponent text, spBool foreground)
{
    Rect rect;
    GrafPtr save_port;
	    
    if (spIsText(text) == SP_TRUE) {
	spDebug(50, "spDeactivateTextMac", "deactivate: %ld, activated = %d\n",
		SpGetComponentId(text), SpTextArch(text).activated);

	if (SpTextArch(text).activated == SP_TRUE) {
	    if (SpPrimitiveArch(text).control != NULL) {
		SetKeyboardFocus(SpPrimitiveArch(SpGetWindow(text)).window,
				 SpPrimitiveArch(text).control,
				 kControlFocusNoPart);
		if (foreground == SP_FALSE) {
		    DeactivateControl(SpPrimitiveArch(text).control);
		} else {
		    Draw1Control(SpPrimitiveArch(text).control);
		}
	    } else {
		spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	
		spGetTextFrameRectMac(text, &rect);
		if (foreground == SP_FALSE) {
		    spDrawTextFrameMac(rect, SP_FALSE, SP_FALSE);
		} else {
		    spDrawTextFrameMac(rect, SpPrimitiveArch(text).sensitive_flag, SP_FALSE);
		}
	    
		spGetOriginalRGBMac();
		spSetNormalRGBMac();
	    
		TEDeactivate(SpTextArch(text).text);
	    
		spSetOriginalRGBMac();
	    
		spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	    }
	    SpTextArch(text).activated = SP_FALSE;
	    
	    spDebug(50, "spDeactivateTextMac", "done\n");
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

void spDrawTextFrameMac(Rect frame_rect, spBool sensitive_flag, spBool focus_flag)
{
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	if (sensitive_flag == SP_FALSE || focus_flag == SP_FALSE) {
	    DrawThemeFocusRect(&frame_rect, false);
        }
    }
    if (sensitive_flag == SP_FALSE) {
	spGetOriginalRGBMac();
	spSetDeactivateRGBMac();
    }
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	spDebug(80, "spDrawTextFrameMac", "top = %d, sensitive: %d, focus: %d\n",
		frame_rect.top, sensitive_flag, focus_flag);
	if (sensitive_flag == SP_TRUE && focus_flag == SP_TRUE) {
	    DrawThemeEditTextFrame(&frame_rect, kThemeStateActive);
	    DrawThemeFocusRect(&frame_rect, true);
	} else {
	    if (sensitive_flag == SP_TRUE) {
		DrawThemeEditTextFrame(&frame_rect, kThemeStateActive);
	    } else {
		DrawThemeEditTextFrame(&frame_rect, kThemeStateInactive);
	    }
	}
    } else {
	FrameRect(&frame_rect);
    }

    if (sensitive_flag == SP_FALSE) {
	spSetOriginalRGBMac();
    }
    
    return;
}

static void eraseUpdateText(spComponent text, Rect *frame_rect)
{
    Rect rect;
    
    if (SpPrimitiveArch(text).control == NULL) {
	spGetTextFrameRectMac(text, &rect);
	if (frame_rect != NULL) {
	    *frame_rect = rect;
	}
	
	/* erase rect */
	InsetRect(&rect, 1, 1);
	EraseRect(&rect);
	
	/* update text edit */
	rect = (*SpTextArch(text).text)->viewRect;
	TEUpdate(&rect, SpTextArch(text).text);
    }

    return;
}

void spDrawTextMac(spComponent text, spBool update)
{
    GrafPtr save_port;
    
    if (spIsVisible(text) == SP_TRUE
	&& SpPrimitiveArch(text).map_flag == SP_TRUE) {
	if (spIsComboBox(text) == SP_TRUE) {
	    spDrawControlMac(text);
	    
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    spDrawComboBoxMac(text);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	}

	if (SpPrimitiveArch(text).control != NULL) {
	    spDrawControlInWindowPortMac(SpPrimitiveArch(text).control,
					 SpPrimitiveArch(SpGetWindow(text)).window);
	} else {
	    Rect frame_rect;
	    spBool sensitive_flag = SP_TRUE;
	    
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    spGetOriginalRGBMac();
	    
	    if (SpPrimitiveArch(text).sensitive_flag == SP_FALSE
		|| SpFrameArch(SpGetWindow(text)).activate_flag == SP_FALSE) {
		sensitive_flag = SP_FALSE;
		spSetDeactivateRGBMac();
	    } else {
		spSetNormalRGBMac();
	    }
	    
	    /* update text */
	    eraseUpdateText(text, &frame_rect);
	    
	    spSetOriginalRGBMac();
	    
	    if (SpFrameArch(SpGetWindow(text)).key_send_component == text) {
		spDrawTextFrameMac(frame_rect, sensitive_flag, SP_TRUE);
	    } else {
		spDrawTextFrameMac(frame_rect, sensitive_flag, SP_FALSE);
	    }
	    
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	}
    }

    return;
}

void spUpdateTextMac(spComponent component)
{
    spComponent text;
    
    if (SpFrameArch(component).text != NULL) {
	text = SpFrameArch(component).text;

	while (text != NULL) {
	    spDrawTextMac(text, SP_TRUE);
	    text = SpTextArch(text).next_text;
	}
    }

    return;
}

spBool spHandleTextMouseDownMac(WindowPtr window, EventModifiers modifiers, Point point)
{
    Rect rect;
    spComponent component;
    spComponent text;
    
    if ((component = spGetWindowReferenceMac(window)) == NULL
	|| spIsFrame(component) == SP_FALSE || SpFrameArch(component).text == NULL) {
	return SP_FALSE;
    }

    spSetCurrentWindowMac(component);
    spDebug(50, "spHandleTextMouseDownMac", "x = %d, y = %d\n", point.h, point.v);

    text = SpFrameArch(component).text;

    while (text != NULL) {
	spGetTextFrameRectMac(text, &rect);
	
	if (spIsVisible(text) == SP_TRUE
	    && SpPrimitiveArch(text).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(text).map_flag == SP_TRUE) {
	    if (PtInRect(point, &rect)) {
		spFocusComponentMac(component, text);
		
		if (SpTextPart(text).editable == SP_TRUE || spIsComboBox(text) == SP_TRUE) {
		    if (SpPrimitiveArch(text).control != NULL) {
			ControlPartCode part;
			
			part = HandleControlClick(SpPrimitiveArch(text).control,
						  point, modifiers, (ControlActionUPP)-1);
		    } else {
			spGetOriginalRGBMac();
			spSetNormalRGBMac();
		
			spDebug(50, "spHandleTextMouseDownMac", "click text edit\n");
			TEClick(point, (modifiers & shiftKey) != 0, SpTextArch(text).text);
		    
			spSetOriginalRGBMac();
		    }
		    
		    spChangeEditMenuStateMac(component);
		}
	    
		return SP_TRUE;
	    } else if (spHandleComboBoxMouseDownMac(text, point, rect) == SP_TRUE) {
		return SP_TRUE;
	    }
	}
	
	text = SpTextArch(text).next_text;
    }

    return SP_FALSE;
}

spBool spHandleTextActivateKeyDownMac(spComponent component, char key)
{
    spBool flag = SP_FALSE;
    
    if (spIsText(component) == SP_FALSE) {
	return SP_FALSE;
    }
    
    if (spIsSubClass(component, SpTextArea) == SP_FALSE
	&& (key == '\r' || key == '\n' || key == kEnterCharCode)) {
	spDebug(50, "spHandleTextActivateKeyDownMac", "text activate\n");
	if (SpTextPart(component).editable == SP_TRUE) {
	    /*flag = spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);*/
	    spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
	}
	flag = SP_TRUE;
    }

    return flag;
}

spBool spIsTextCursorMoveKeyMac(char key)
{
    if (key == kLeftArrowCharCode || key == kRightArrowCharCode
	|| key == kUpArrowCharCode || key == kDownArrowCharCode
	|| key == kPageUpCharCode || key == kPageDownCharCode
	|| key == kHomeCharCode || key == kEndCharCode) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spHandleTextKeyDownMac(spComponent component, EventModifiers modifiers, int keycode, char key)
{
    spBool flag = SP_FALSE;

    if (spIsText(component) == SP_FALSE) {
	return SP_FALSE;
    }
    
    if (spIsVisible(component) == SP_TRUE
	&& SpPrimitiveArch(component).sensitive_flag == SP_TRUE
	&& SpPrimitiveArch(component).map_flag == SP_TRUE) {
	if (spHandleTextActivateKeyDownMac(component, key) == SP_TRUE) {
	    flag = SP_TRUE;
	} else {
	    if (SpTextPart(component).editable == SP_TRUE) {
		spBool exceeded = SP_FALSE;
		TEHandle te = SpTextArch(component).text;
			
		if ((exceeded = spHandleExceedTextMac(component, key, 1)) == SP_FALSE) {
			
		    if (SpPrimitiveArch(component).control != NULL) {
			HandleControlKey(SpPrimitiveArch(component).control, keycode, key, modifiers);
		    } else {
			spGetOriginalRGBMac(); spSetNormalRGBMac();
			TEKey(key, te);
			spSetOriginalRGBMac();
		    }

		    if (spIsTextCursorMoveKeyMac(key) == SP_FALSE) {
			spChangeEditMenuStateMac(SpGetWindow(component));
			    
			flag = spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK,
						SP_CR_VALUE_CHANGED);
		    }
		}

		if (exceeded == SP_TRUE) flag = SP_TRUE;
	    }
	}
    }
	
    return flag;
}

spBool spHandleExceedTextMac(spComponent component, char key, long input_len)
{
    TEHandle te;

    if (spIsText(component) == SP_FALSE
	|| key == kDeleteCharCode || key == kBackspaceCharCode
	/*|| key == kLeftArrowCharCode || key == kUpArrowCharCode
	  || key == kPageUpCharCode || key == kHomeCharCode*/
	|| spIsTextCursorMoveKeyMac(key) == SP_TRUE
	|| SpTextPart(component).editable == SP_FALSE) return SP_FALSE;

    te = SpTextArch(component).text;

    if (input_len + ((*te)->teLength - ((*te)->selEnd - (*te)->selStart)) >= kMaxTELength) {
	spDisplayError(/*spGetCurrentWindowMac()*/SpGetWindow(component), NULL,
		       "Cannot exceed %d characters.", kMaxTELength);
	return SP_TRUE;
    }

    return SP_FALSE;
}

void spTextPartInitArch(spComponent component)
{
    SpTextArch(component).text = NULL;
    SpTextArch(component).vscroll = NULL;
    SpTextArch(component).hscroll = NULL;
    SpTextArch(component).next_text = NULL;
    SpTextArch(component).prev_text = NULL;
    SpTextArch(component).activated = SP_FALSE;
    
    return;
}

void spTextPartFreeArch(spComponent component)
{
    spDebug(60, "spTextPartFreeArch", "in\n");
    
    if (SpTextArch(component).prev_text != NULL) {
	SpTextArch(SpTextArch(component).prev_text).next_text
	    = SpTextArch(component).next_text;
    }
    if (SpTextArch(component).next_text != NULL) {
	SpTextArch(SpTextArch(component).next_text).prev_text
	    = SpTextArch(component).prev_text;
    }

    if (!(spGetAppearanceVersionMac() >= 0x00000101)) {
	if (SpTextArch(component).text != NULL) {
	    TEDispose(SpTextArch(component).text);
	}
    }
    if (SpTextArch(component).vscroll != NULL) {
	DisposeControl(SpTextArch(component).vscroll);
    }
    if (SpTextArch(component).hscroll != NULL) {
	DisposeControl(SpTextArch(component).hscroll);
    }
    
    spDebug(60, "spTextPartFreeArch", "done\n");
    
    return;
}

static void setLastText(spComponent component)
{
    spComponent window;
    spComponent text;
    
    window = SpGetWindow(component);
    if (spIsFrame(window) == SP_FALSE) {
	return;
    }
    
    if (SpFrameArch(window).text != NULL) {
	text = SpFrameArch(window).text;
	while (1) {
	    if (SpTextArch(text).next_text == NULL) {
		SpTextArch(text).next_text = component;
		SpTextArch(component).prev_text = text;
		break;
	    }
	    text = SpTextArch(text).next_text;
	}
    } else {
	SpFrameArch(window).text = component;
    }

    return;
}

void spTextCreateArch(spComponent component)
{
    spComponent window;
    Rect dest_rect, view_rect;
    GrafPtr save_port;

    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    
    window = SpGetWindow(component);
    spLockWindowPort(SpPrimitiveArch(window).window, &save_port);

    view_rect = SpPrimitiveArch(component).rect;
    dest_rect = view_rect;
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	Size actualSize;
	
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &dest_rect, "\p", spIsVisibleMac(component), 0, 0, 0,
		       (spGetAppearanceVersionMac() >= 0x00000110
			? kControlEditTextInlineInputProc : kControlEditTextProc),
		       0);
	GetControlData(SpPrimitiveArch(component).control,
		       kControlEntireControl, kControlEditTextTEHandleTag,
		       sizeof(SpTextArch(component).text), (Ptr)&SpTextArch(component).text,
		       &actualSize);
	spSetReferenceMac(component);
	spSetNeedUpdateMac(component);

	spSetControlFontMac(component, SpTextPart(component).font_name);
    } else {
	SpTextArch(component).text = TENew(&dest_rect, &view_rect);
    }

    if (SpTextPart(component).editable == SP_TRUE) {
	TEFeatureFlag(teFOutlineHilite, teBitSet, SpTextArch(component).text);
    } else {
	TEFeatureFlag(teFOutlineHilite, teBitClear, SpTextArch(component).text);
    }
    TEFeatureFlag(teFAutoScroll, teBitSet, SpTextArch(component).text);
#if 0
    TEFeatureFlag(teFTextBuffering, teBitSet, SpTextArch(component).text);
#endif
    TEAutoView(true, SpTextArch(component).text);

#if 0
    SpTextArch(component).vscroll =
	NewControl(SpPrimitiveArch(window).window,
		   &rect, pstr, spIsVisibleMac(component), 128, 0, 256, scrollBarProc, 0L);
    SpTextArch(component).hscroll =
	NewControl(SpPrimitiveArch(window).window,
		   &rect, pstr, spIsVisibleMac(component), 128, 0, 256, scrollBarProc, 0L);
#endif

    spUnlockWindowPort(SpPrimitiveArch(window).window, save_port);
    
    setLastText(component);
    spSetNeedMoveCallMac(component);
    spSetKeySendComponentMac(component, SP_FALSE);
    
    return;
}

void spTextSetParamsArch(spComponent component)
{
    spBool flag = SP_FALSE;
    GrafPtr save_port;
    
    if (!streq(SpTextPart(SpOldObject(component)).font_name, SpTextPart(component).font_name)) {
	spSetControlFontMac(component, SpTextPart(component).font_name);
	flag = SP_TRUE;
    }
    
    if (SpTextPart(SpOldObject(component)).editable != SpTextPart(component).editable) {
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
	if (1 || SpPrimitiveArch(component).control == NULL) {
	    spGetOriginalRGBMac(); spSetNormalRGBMac();
	}
	
	if (SpTextPart(component).editable == SP_TRUE) {
	    TEFeatureFlag(teFOutlineHilite, teBitSet, SpTextArch(component).text);
	} else {
	    (*SpTextArch(component).text)->selStart = (*SpTextArch(component).text)->selEnd;
	    TEFeatureFlag(teFOutlineHilite, teBitClear, SpTextArch(component).text);

	    eraseUpdateText(component, NULL);
	}
	if (1 || SpPrimitiveArch(component).control == NULL) {
	    spSetOriginalRGBMac();
	}
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);

	if (SpPrimitiveArch(component).control != NULL) {
	    spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
					 SpPrimitiveArch(SpGetWindow(component)).window);
	}
	
	spChangeEditMenuStateMac(SpGetWindow(component));
	flag = SP_TRUE;
    }

    if (flag == SP_TRUE) {
	spDrawTextMac(component, SP_TRUE);
    }
    
    return;
}

void spSetTextStringMac(spComponent component, char *string)
{
    int len;
    GrafPtr save_port;
    
    if (spIsText(component) == SP_FALSE) return;

    spDebug(50, "spSetTextStringMac", "string = %s\n", string);
    
    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    }
	
    len = strlen(string);
    if (len <= 0) {
	TESetSelect(0, (*SpTextArch(component).text)->teLength, SpTextArch(component).text);
	TEDelete(SpTextArch(component).text);
    } else {
	if (spIsAquaMac() == SP_TRUE) {
	    int i;
	    char *converted;
	
	    converted = strclone(string);
	    for (i = 0; i < len; i++) {
		if (converted[i] == '\n') {
		    converted[i] = '\r';
		}
	    }
	    TESetText(converted, len, SpTextArch(component).text);
	    xfree(converted);
	} else {
	    TESetText(string, len, SpTextArch(component).text);
	}
    }
    
    TESetSelect(len, len, SpTextArch(component).text);

    if (SpPrimitiveArch(component).map_flag == SP_TRUE) {
	eraseUpdateText(component, NULL);
    }
	
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spSetOriginalRGBMac();
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    if (SpPrimitiveArch(component).control != NULL) {
	spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
				     SpPrimitiveArch(SpGetWindow(component)).window);
    }
    
    spDebug(50, "spSetTextStringMac", "done\n");
    
    return;
}

void spSetTextStringArch(spComponent component)
{
    spSetTextStringMac(component, SpTextPart(component).string);
    return;
}

void spGetTextStringArch(spComponent component)
{
    int len;
    CharsHandle hchars;
    GrafPtr save_port;

    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    }
	
    hchars = TEGetText(SpTextArch(component).text);
    HLock((Handle)hchars);
    
    len = (*SpTextArch(component).text)->teLength;
    SpTextPart(component).string = xalloc(len + 1, char);
    strncpy(SpTextPart(component).string, *hchars, len);
    
    if (spIsAquaMac() == SP_TRUE) {
	int i;
	
	for (i = 0; i < len; i++) {
	    if (SpTextPart(component).string[i] == '\r') {
		SpTextPart(component).string[i] = '\n';
	    }
	}
    }
    SpTextPart(component).string[len] = NUL;
    
    HUnlock((Handle)hchars);
    
    spDebug(50, "spGetTextStringArch", "len = %d, string = %s\n", len,
	    SpTextPart(component).string);
    
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spSetOriginalRGBMac();
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return;
}

spBool spSetTextSelectionArch(spComponent component, long start, long end)
{
    GrafPtr save_port;
    
    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    }
    
    if (start == -1) {
	TESetSelect(0, 0, SpTextArch(component).text);
    } else {
	if (end == -1) end = (*SpTextArch(component).text)->teLength;
    
	TESetSelect(start, end, SpTextArch(component).text);
    }
    
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spSetOriginalRGBMac();
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return SP_TRUE;
}

spBool spGetTextSelectionArch(spComponent component, long *start, long *end)
{
    if ((*SpTextArch(component).text)->selStart == (*SpTextArch(component).text)->selEnd) {
	return SP_FALSE;
    } else {
	*start = (*SpTextArch(component).text)->selStart;
	*end = (*SpTextArch(component).text)->selEnd;
    }
    return SP_TRUE;
}

spBool spSetTextPositionArch(spComponent component, long position)
{
    GrafPtr save_port;

    if (position == -1) position = (*SpTextArch(component).text)->teLength;
    
    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spGetOriginalRGBMac();
	spSetNormalRGBMac();
    }
    
    TESetSelect(position, position, SpTextArch(component).text);

    if (1 || SpPrimitiveArch(component).control == NULL) {
	spSetOriginalRGBMac();
    }
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return SP_TRUE;
}

spBool spGetTextPositionArch(spComponent component, long *position)
{
    Point point = (*SpTextArch(component).text)->selPoint;
    
    *position = TEGetOffset(point, SpTextArch(component).text);
    
    return SP_TRUE;
}

#define SP_COPY_TEXT 0
#define SP_CUT_TEXT 1
#define SP_CLEAR_TEXT 2
#define SP_PASTE_TEXT 3

static spBool spHandleClipboardMac(spComponent component, int type)
{
    GrafPtr save_port;
    
    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spGetOriginalRGBMac(); spSetNormalRGBMac();
    }

    switch (type) {
      case SP_COPY_TEXT:
	TECopy(SpTextArch(component).text);
	break;
      case SP_CUT_TEXT:
	TECut(SpTextArch(component).text);
	break;
      case SP_CLEAR_TEXT:
	TEDelete(SpTextArch(component).text);
	break;
      case SP_PASTE_TEXT:
	TEPaste(SpTextArch(component).text);
	break;
      default:
	break;
    }
    
    if (1 || SpPrimitiveArch(component).control == NULL) {
	spSetOriginalRGBMac();
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return SP_TRUE;
}

spBool spCutTextArch(spComponent component)
{
    return spHandleClipboardMac(component, SP_CUT_TEXT);
}

spBool spCopyTextArch(spComponent component)
{
    return spHandleClipboardMac(component, SP_COPY_TEXT);
}

spBool spPasteTextArch(spComponent component)
{
    return spHandleClipboardMac(component, SP_PASTE_TEXT);
}

spBool spClearTextArch(spComponent component)
{
    return spHandleClipboardMac(component, SP_CLEAR_TEXT);
}
