/*
 *	spTabBox.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spList.h>

#include <sp/spContainerP.h>
#include <sp/spTabBoxP.h>

static spParamTable sp_tab_box_param_tables[] = {
    {SppSelectedTabIndex, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTabBox, tab_box.selected_index), "0"},
    {SppSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spTabBox, tab_box.size), "0"},
};

spTabBoxClassRec SpTabBoxClassRec = {
    /* spObjectClassPart */
    {
	SpTabBox,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spTabBoxRec),
	spArraySize(sp_tab_box_param_tables),
	sp_tab_box_param_tables,
	spTabBoxPartInit,
	spTabBoxPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spTabBoxCreate,
	spTabBoxDestroy,
	spTabBoxSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spTabBoxClassPart */
    {
	0,
    },
};

spComponentClass SpTabBoxClass = (spComponentClass)&SpTabBoxClassRec;

void spTabBoxPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    spTabBoxPartInitArch(component);
    
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;
    
    SpTabBoxPart(component).num_item = 0;

    return;
}

void spTabBoxPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spTabBoxPartFreeArch(component);
    return;
}

void spTabBoxCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spTabBoxSetDefaultSize(component);
    spTabBoxCreateArch(component);
	
    return;
}

void spTabBoxSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spTabBoxSetParamsArch(component);
	
    return;
}

void spTabBoxDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spTabBoxDestroyArch(component);
    spPrimitiveDestroyArch(component);
    
    return;
}

void spTabBoxSetDefaultSize(spComponent component)
{
    if (spIsTabBox(component) == SP_FALSE) return;
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    SpComponentPart(component).width = 0;
    /*SpComponentPart(component).height = SpTabBoxPart(component).size + SP_DEFAULT_TAB_HEIGHT;*/
    SpComponentPart(component).height = SpTabBoxPart(component).size;
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;

    return;
}

spBool spIsTabBox(spComponent component)
{
    return spIsSubClass(component, SpTabBox);
}

spComponent spCreateTabBox(spComponent parent, char *name, int size, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, size);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetArg(args[num_arg], SppSize, size); num_arg++;

    return spCreateComponentArg(SpTabBoxClass, NULL, name, parent, args, num_arg);
}

int spMapTabItem(spComponent component, int index)
{
    spComponent child;
    spComponent selected_tab = NULL;
    
    if (spIsTabBox(component) == SP_FALSE || index < 0
	|| spIsCreated(component) == SP_FALSE) return -1;

    child = SpGetChild(component);

    while (child != NULL) {
	if (SpPrimitivePart(child).index == index) {
	    selected_tab = child;

	    child = SpGetChild(component);
	    while (child != NULL) {
		SpComponentPart(child).geometry_flag = SP_TRUE;
		if (child != selected_tab) {
		    spUnmapComponent(child);
		} else {
		    SpComponentPart(child).visible_flag = SP_TRUE;
		}
		SpComponentPart(child).geometry_flag = SP_FALSE;
		
		child = SpGetNextComponent(child);
	    }

	    /*spAdjustComponentSize(SpGetWindow(component));*/
	    spAdjustComponentSize(component);
	    SpComponentPart(selected_tab).visible_flag = SP_FALSE;
	    
	    SpComponentPart(selected_tab).geometry_flag = SP_TRUE;
	    spMapComponent(selected_tab);
	    SpComponentPart(selected_tab).geometry_flag = SP_FALSE;
	    
	    spDebug(30, "spMapTabItem", "index = %d\n", index);
	    return index;
	}

	child = SpGetNextComponent(child);
    }
    
    return -1;
}

int spGetSelectedTabIndex(spComponent component)
{
    if (spIsTabBox(component) == SP_FALSE) return -1;

    if (spIsCreated(component) == SP_TRUE) {
	SpTabBoxPart(component).selected_index = spGetSelectedTabIndexArch(component);
    }
    
    spDebug(10, "spGetSelectedTabIndex", "index = %d\n",
	    SpTabBoxPart(component).selected_index);
    
    return SpTabBoxPart(component).selected_index;
}

spComponent spGetSelectedTabItem(spComponent component)
{
    int index;
    spComponent child;
    
    if (spIsTabBox(component) == SP_FALSE 
	|| spIsCreated(component) == SP_FALSE) return NULL;

    if ((index = spGetSelectedTabIndex(component)) >= 0) {
	child = SpGetChild(component);
	
	while (child != NULL) {
	    if (SpPrimitivePart(child).index == index) {
		return child;
	    }

	    child = SpGetNextComponent(child);
	}
    }
    
    return NULL;
}

spComponent spAddTabItem(spComponent parent, char *name, int index, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    spComponent component;
    spComponent child;
    
    if (spIsCreated(parent) == SP_FALSE || spIsTabBox(parent) == SP_FALSE
	|| index > SpTabBoxPart(parent).num_item)
	return NULL;

    va_start(argp, index);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    if (index < 0) {
	index = SpTabBoxPart(parent).num_item;
    }
    SpTabBoxPart(parent).num_item++;
    
    if (SpTabBoxPart(parent).selected_index != index) {
	spSetArg(args[num_arg], SppVisible, SP_FALSE); num_arg++;
    }

    /*spSetArg(args[num_arg], SppSpacingOn, SP_TRUE); num_arg++;*/
    component = spCreateComponentArg(SpContainerClass, SpBox, name, parent, args, num_arg);

    child = SpGetChild(parent);
    while (child != NULL) {
	if (child == component) {
	    SpPrimitivePart(child).index = index;
	} else if (SpPrimitivePart(child).index >= index) {
	    SpPrimitivePart(child).index++;
	}

	child = SpGetNextComponent(child);
    }
    
    spAddTabItemArch(component, index);
    
    return component;
}
