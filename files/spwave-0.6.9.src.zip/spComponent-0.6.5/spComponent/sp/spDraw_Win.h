/*
 *	spDraw_Win.h
 */

#ifndef __SPDRAW_WIN_H
#define __SPDRAW_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAW_WIN_H */
