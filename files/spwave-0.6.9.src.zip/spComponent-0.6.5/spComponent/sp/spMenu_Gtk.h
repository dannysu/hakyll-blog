/*
 *	spMenu_Gtk.h
 */

#ifndef __SPMENU_GTK_H
#define __SPMENU_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int spGetMnemonic(char *label, char *text);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENU_GTK_H */
