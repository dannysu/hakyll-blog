/*
 *	spToolBar_Win.h
 */

#ifndef __SPTOOLBAR_WIN_H
#define __SPTOOLBAR_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolBarArchPart {
    HBITMAP hbitmap;
} spToolBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLBAR_WIN_H */
