/*
 *	spText_Xm.h
 */

#ifndef __SPTEXT_XM_H
#define __SPTEXT_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#if defined(MOTIF_USE_CS_TEXT) && (XmVersion == 2000)
#include <Xm/CSText.h>
#else
#undef MOTIF_USE_CS_TEXT
#endif
    
#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTextArchPart {
    int dummy;
} spTextArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXT_XM_H */
