/*
 *	spFrame_Mac.h
 */

#ifndef __SPFRAME_MAC_H
#define __SPFRAME_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spFrameArchPart {
    spBool realize_flag;
    spBool activate_flag;
    spComponent text;
    spComponent key_send_component;
    spComponent quit_menu_item;
    
    spDropCallbackFunc drop_call_func;
    void *drop_call_data;
    
    spDrawFunc draw_func;
    spMouseFunc mouse_func;
    spKeyFunc key_func;
    spForegroundFunc foreground_func;
    spBackgroundFunc background_func;
    void *data;
} spFrameArchPart;

extern void spInvalWindowMac(WindowPtr window, ControlRef control);
extern void spAddFrameCallbackMac(spComponent component, spDrawFunc draw_func,
				  spMouseFunc mouse_func, spKeyFunc key_func,
				  spForegroundFunc foreground_func, spBackgroundFunc background_func, 
				  void *data);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAME_MAC_H */
