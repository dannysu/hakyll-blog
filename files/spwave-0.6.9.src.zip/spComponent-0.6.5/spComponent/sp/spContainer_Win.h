/*
 *	spContainer_Win.h
 */

#ifndef __SPCONTAINER_WIN_H
#define __SPCONTAINER_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_CONTAINER_TITLE_OFFSET 5

extern void spDrawContainerWin(spComponent component, spBool null_flag);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCONTAINER_WIN_H */
