/*
 *	spTabBox_Xm.h
 */

#ifndef __SPTABBOX_XM_H
#define __SPTABBOX_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif
    
#define SP_TAB_CORNER_SIZE 5
#define SP_TAB_ITEM_BUFFER 4

typedef struct _spTabBoxArchPart {
    int num_label_buffer;
    Widget *labels;
    spBool focus_flag;
    spBool need_map;
} spTabBoxArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOX_XM_H */
