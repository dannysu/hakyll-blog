/*
 *	spLabel_Mac.h
 */

#ifndef __SPLABEL_MAC_H
#define __SPLABEL_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spDrawLabelMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLABEL_MAC_H */
