/*
 *	spFrame_Xm.h
 */

#ifndef __SPFRAME_XM_H
#define __SPFRAME_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spFrameArchPart {
    unsigned char delete_response;
} spFrameArchPart;

extern long spPostMessageXm(spComponent component, String call_name,
			    XtPointer xt_call_data, EventMask event_mask);
extern spComponent spAddGrabXm(spComponent window);
extern void spRemoveGrabXm(spComponent window);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAME_XM_H */
