/*
 *	spMenuItem_Win.h
 */

#ifndef __SPMENUITEM_WIN_H
#define __SPMENUITEM_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_MENU_ITEM_LABEL 512
    
extern void spCreateMenuItemWin(spComponent component);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUITEM_WIN_H */
