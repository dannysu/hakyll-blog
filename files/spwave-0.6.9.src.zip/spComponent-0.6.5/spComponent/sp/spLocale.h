/*
 *	spLocale.h
 */

#ifndef __SPLOCALE_H
#define __SPLOCALE_H

#include <sp/spStringDefs.h>
#include <sp/spObject.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern char *spSetLanguage(char *lang);
extern char *spGetLanguage(void);
extern char *spSetInternalLanguage(char *lang);
extern char *spGetInternalLanguage(void);
extern void spSetStringTable(char *lang, spStringTable *string_table);
extern void spUpdateStringTable(void);
extern spBool spSupportLocale(char *lang);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLOCALE_H */
