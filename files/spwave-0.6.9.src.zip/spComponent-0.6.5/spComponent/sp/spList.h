/*
 *	spList.h
 */

#ifndef __SPLIST_H
#define __SPLIST_H

#include <sp/spPrimitive.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpList "List"
    
#define SppListStrings "LListStrings" /* CSG */
#define SppSelectedListIndex "iSelectedListIndex" /* CSG */
    
typedef struct _spListRec *spList;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpListClass;
    
extern spBool spIsList(spComponent component);
extern spComponent spCreateList(spComponent parent, char *name, ...);
extern int spAddListItem(spComponent component, char *item);
extern int spAddListIndex(spComponent component, char *item, int index);
extern int spDeleteListItem(spComponent component, char *item);
extern int spDeleteListIndex(spComponent component, int index);
extern int spFindListItem(spComponent component, char *item);
extern int spSelectListItem(spComponent component, char *item);
extern int spSelectListIndex(spComponent component, int index);
extern char *xspGetSelectedListItem(spComponent component);
extern int spGetSelectedListIndex(spComponent component);
extern spComponent spCreateComboBox(spComponent parent, char *name, ...);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIST_H */
