/*
 *	spToolBar_Xm.h
 */

#ifndef __SPTOOLBAR_XM_H
#define __SPTOOLBAR_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolBarArchPart {
    int dummy;
} spToolBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLBAR_XM_H */
