/*
 *	spToolItemP.h
 */

#ifndef __SPTOOLITEMP_H
#define __SPTOOLITEMP_H

#include <sp/spPrimitiveP.h>
#include <sp/spToolItem.h>
#if defined(GTK)
#include <sp/spToolItem_Gtk.h>
#elif defined(_WIN32)
#include <sp/spToolItem_Win.h>
#elif defined(MACOS)
#include <sp/spToolItem_Mac.h>
#elif defined(BEOS)
#include <sp/spToolItem_Be.h>
#else
#include <sp/spToolItem_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolItemPart {
    spToolItemArchPart arch_part;
    
    spBool set;
} spToolItemPart;

typedef struct _spToolItemRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spToolItemPart tool_item;
} spToolItemRec;

typedef struct _spToolItemClassPart {
    int dummy;
} spToolItemClassPart;

typedef struct _spToolItemClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spToolItemClassPart tool_item;
} spToolItemClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spToolItemClassRec SpToolItemClassRec;

extern void spToolItemPartInit(spObject object);
extern void spToolItemPartInitArch(spComponent component);
extern void spToolItemPartFree(spObject object);
extern void spToolItemPartFreeArch(spComponent component);
extern void spToolItemCreate(spObject object);
extern void spToolItemCreateArch(spComponent component);
extern void spToolItemSetParams(spObject object);
extern void spToolItemSetParamsArch(spComponent component);
extern void spToolItemDestroy(spObject object);
extern void spToolItemDestroyArch(spComponent component);
extern void spSetToolItemToggleStateArch(spComponent component);
extern void spGetToolItemToggleStateArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#define SpToolItemPart(comp) (((spToolItem)comp)->tool_item)
#define SpToolItemArch(comp) (((spToolItem)comp)->tool_item.arch_part)
#define SpParentToolItemPart(comp) (((spToolItem)SpGetParent(comp))->tool_item)
#define SpParentToolItemArch(comp) (SpParentToolItemPart(comp).arch_part)
#define SpGetToolItemClass(comp) ((spToolItemClass)((comp)->object.object_class))

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLITEMP_H */
