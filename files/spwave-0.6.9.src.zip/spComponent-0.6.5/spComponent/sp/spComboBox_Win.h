/*
 *	spComboBox_Win.h
 */

#ifndef __SPCOMBOBOX_WIN_H
#define __SPCOMBOBOX_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spComboBoxArchPart {
    int dummy;
} spComboBoxArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOX_WIN_H */
