/*
 *	spTopLevel_Xm.h
 */

#ifndef __SPTOPLEVEL_XM_H
#define __SPTOPLEVEL_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#include <sp/spComponent_Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTopLevelArchPart {
    XtAppContext app_context;
    Widget widget;
    Display *display;
    Screen *screen;
    Colormap colormap;
    /*Font font;*/
    XFontSet font_set;
    GC fg_gc;
    GC bg_gc;
    char **resources;
} spTopLevelArchPart;

extern void spMainQuitXm(void);
extern int spMainLoopXm(spTopLevel toplevel);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVEL_XM_H */
