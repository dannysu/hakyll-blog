/*
 *	spPrimitive_Mac.h
 */

#ifndef __SPPRIMITIVE_MAC_H
#define __SPPRIMITIVE_MAC_H

#if defined(MACOSX)
#include <Carbon/Carbon.h>
#else
#include <Gestalt.h>
#include <MacTypes.h>
#include <MacWindows.h>
#include <Quickdraw.h>
#include <QDOffscreen.h>
#include <Dialogs.h>
#include <Menus.h>
#include <Controls.h>
#include <ControlDefinitions.h>
#include <Devices.h>
#include <ToolUtils.h>
#include <Scrap.h>
#include <Fonts.h>
#include <Sound.h>
#include <Balloons.h>
#include <MixedMode.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if !TARGET_API_MAC_CARBON
#define DisableMenuItem DisableItem
#define EnableMenuItem EnableItem
#endif
    
#define spGetRectWidthMac(r) ((r.right) - (r.left))
#define spGetRectHeightMac(r) ((r.bottom) - (r.top))
    
#define spRectTopLeft(r)  (((Point *)&(r))[0])
#define spRectBotRight(r) (((Point *)&(r))[1])

struct _spCallback {
    spComponent component;
    spCallbackFunc call_func;
    void *call_data;
    spBool propagate;
    
    spCallbackType call_type;
};

typedef struct _spCallbackTable {
    spCallbackType call_type;
    spComponentType component_type;
} spCallbackTable;

typedef struct _spPrimitiveArchPart {
    WindowRef window;
    ControlRef control;
    ControlRef sub_control;
    GWorldPtr gworld;
    MenuHandle menu;
    EventRecord event;
    Rect rect;
    RgnHandle region;
#if TARGET_API_MAC_CARBON
    EventHandlerUPP eventHandler;
#endif
    
    int menu_id;
    spCallbackReason reason;
    spBool map_flag;
    spBool sensitive_flag;
    spCursorType cursor_type;
    spComponent popup_menu;
    spComponent next_need_update;
    spComponent prev_need_update;
    spComponent next_need_move_call;
    spComponent prev_need_move_call;    
    spComponent next_key_send;
    spComponent prev_key_send;    
} spPrimitiveArchPart;
    
#if defined(MACOS)
#pragma import on
#endif

extern void spLockWindowPort(WindowPtr window, GrafPtr *save_port);
extern void spUnlockWindowPort(WindowPtr window, GrafPtr save_port);
extern void spLockDialogPort(DialogPtr dialog, GrafPtr *save_port);
extern void spUnlockDialogPort(DialogPtr dialog, GrafPtr save_port);
extern RgnHandle spGetVisibleRegionMac(WindowPtr window);
extern RgnHandle spGetContentRegionMac(WindowPtr window);
extern BitMap *spGetPortBitMapMac(WindowPtr window);
extern void spGetPortRectMac(WindowPtr window, Rect *rect);
extern void spGetControlRectMac(ControlRef control, Rect *rect);
extern void spGetScreenBoundsMac(Rect *rect);
extern void spGetRegionBoundsMac(RgnHandle region, Rect *rect);
extern void spValidRectMac(WindowRef window, Rect *rect);
extern void spInvalRectMac(WindowRef window, Rect *rect);
extern void spHiliteControlMac(ControlRef control, spBool flag);
extern Boolean spIsVisibleMac(spComponent component);
extern void spMapComponentFirstMac(spComponent component);

extern spBool spGetComponentGeometryMac(spComponent component, int *x, int *y);
extern void spSetComponentRectMac(spComponent component, int width, int height);
extern spComponent spGetWindowReferenceMac(WindowPtr window);
extern spComponent spGetControlReferenceMac(ControlRef control);
extern void spSetReferenceMac(spComponent component);
extern void spSetNeedUpdateMac(spComponent component);
extern void spSetNeedMoveCallMac(spComponent component);
extern void spSetKeySendComponentMac(spComponent component, spBool set_current);
extern spComponent spSearchWindowMac(WindowRef window);
extern int spUseCurrentMenuIdMac(void);
extern spBool spPostMessageMac(spComponent component, spCallbackType call_type,
			       spCallbackReason reason);
extern void spSetCurrentWindowMac(spComponent window);
extern spComponent spGetCurrentWindowMac(void);
extern spComponent spGetCurrentTextMac(void);
extern spComponent spGetCurrentMenuBarMac(void);
extern spBool spIsSuspendedMac(void);
extern void spSetSuspendStateMac(spBool suspended);
extern void spInsertAllMenuMac(spComponent parent);
extern int spGetNumHelpMenuItemMac(void);
extern void spChangeEditMenuStateMac(spComponent component);
extern spComponent spSelectMenuBarMac(spComponent component, spComponent avoid);
extern void spDrawGrowIconMac(WindowPtr window);
extern void spDrawControlInWindowPortMac(ControlRef control, WindowRef window);
extern void spDrawControlMac(spComponent component);
extern void spActivateComponentMac(spComponent component, spBool need_update);
extern void spDeactivateComponentMac(spComponent component, spBool need_update);
extern spBool spFocusComponentMac(spComponent window, spComponent component);
extern void spDragWindowMac(WindowPtr window, Point point);
extern spBool spHandleActivateEventMac(EventRecord *event);
extern spBool spHandleUpdateEventMac(EventRecord *event);
extern spBool spHandleIdleMac(EventRecord *event);
extern spBool spHandleEventMac(EventRecord *event);

#if TARGET_API_MAC_CARBON
extern EventHandlerUPP spNewAppEventHandlerUPP(void);
extern EventHandlerUPP spNewWindowEventHandlerUPP(void);
extern EventHandlerUPP spNewControlEventHandlerUPP(void);
#endif

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVE_MAC_H */
