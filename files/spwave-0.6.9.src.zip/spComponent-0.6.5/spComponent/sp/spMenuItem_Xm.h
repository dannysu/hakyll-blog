/*
 *	spMenuItem_Xm.h
 */

#ifndef __SPMENUITEM_XM_H
#define __SPMENUITEM_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#include <sp/spMenu_Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void spShowMenuHelpCB(Widget widget, XtPointer client_data, XEvent *event);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUITEM_XM_H */
