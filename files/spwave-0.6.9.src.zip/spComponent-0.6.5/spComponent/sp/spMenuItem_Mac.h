/*
 *	spMenuItem_Mac.h
 */

#ifndef __SPMENUITEM_MAC_H
#define __SPMENUITEM_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_MENU_ITEM_LABEL 512
    
#if defined(MACOS)
#pragma import on
#endif

extern void spMapMenuItemMac(spComponent component);
extern void spUnmapMenuItemMac(spComponent component);
extern int spGetMenuItemIdMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUITEM_MAC_H */
