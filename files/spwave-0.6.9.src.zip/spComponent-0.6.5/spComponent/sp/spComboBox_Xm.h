/*
 *	spComboBox_Xm.h
 */

#ifndef __SPCOMBOBOX_XM_H
#define __SPCOMBOBOX_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spComboBoxArchPart {
    int dummy;
} spComboBoxArchPart;

extern spBool spGetScreenGeometry(Widget widget, int *x, int *y, int *width, int *height);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOX_XM_H */
