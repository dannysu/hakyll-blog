/*
 *	spLabelP.h
 */

#ifndef __SPLABELP_H
#define __SPLABELP_H

#include <sp/spPrimitiveP.h>
#include <sp/spLabel.h>
#if defined(GTK)
#include <sp/spLabel_Gtk.h>
#elif defined(_WIN32)
#include <sp/spLabel_Win.h>
#elif defined(MACOS)
#include <sp/spLabel_Mac.h>
#elif defined(BEOS)
#include <sp/spLabel_Be.h>
#else
#include <sp/spLabel_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spLabelPart {
    spAlignment alignment;		/* component alignment */
} spLabelPart;

typedef struct _spLabelRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spLabelPart label;
} spLabelRec;

typedef struct _spLabelClassPart {
    int dummy;
} spLabelClassPart;

typedef struct _spLabelClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spLabelClassPart label;
} spLabelClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spLabelClassRec SpLabelClassRec;

#define SpLabelPart(comp) (((spLabel)comp)->label)
#define SpParentLabelPart(comp) (((spLabel)SpGetParent(comp))->label)
#define SpGetLabelClass(comp) ((spLabelClass)((comp)->object.object_class))

extern void spLabelPartInit(spObject object);
extern void spLabelPartFree(spObject object);
extern void spLabelCreate(spObject object);
extern void spLabelCreateArch(spComponent component);
extern void spLabelSetParams(spObject object);
extern void spLabelSetParamsArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLABELP_H */
