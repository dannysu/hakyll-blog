/*
 *	spLabel_Gtk.h
 */

#ifndef __SPLABEL_GTK_H
#define __SPLABEL_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLABEL_GTK_H */
