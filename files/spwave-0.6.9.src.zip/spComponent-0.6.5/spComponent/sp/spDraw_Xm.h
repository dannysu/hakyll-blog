/*
 *	spDraw_Xm.h
 */

#ifndef __SPDRAW_XM_H
#define __SPDRAW_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void spGetDisplayInfo(spComponent component);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAW_XM_H */
