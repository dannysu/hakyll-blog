/*
 *	spDrawP.h
 */

#ifndef __SPDRAWP_H
#define __SPDRAWP_H

#include <sp/spPrimitiveP.h>
#include <sp/spDraw.h>
#if defined(GTK)
#include <sp/spDraw_Gtk.h>
#elif defined(_WIN32)
#include <sp/spDraw_Win.h>
#elif defined(MACOS)
#include <sp/spDraw_Mac.h>
#elif defined(BEOS)
#include <sp/spDraw_Be.h>
#else
#include <sp/spDraw_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spImageCreate(spComponent component);
extern void spImageCreateArch(spComponent component);
extern void spDrawImageArch(spComponent component);
extern void spRedrawImageArch(spComponent component);
extern void spCopyImageArch(spComponent src, spComponent dest,
			    int src_x, int src_y, int width, int height,
			    int dest_x, int dest_y);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAWP_H */
