/*
 *	spMenu_Mac.h
 */

#ifndef __SPMENU_MAC_H
#define __SPMENU_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern spBool spGetMenuLabelMac(spComponent component, Str255 plabel);
extern void spAddSubMenuMac(spComponent component, Str255 plabel);
extern void spSetMenuItemTextMac(MenuHandle menu, int index, Str255 pstr);
extern void spGetMenuItemTextMac(MenuHandle menu, int index, Str255 pstr);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENU_MAC_H */
