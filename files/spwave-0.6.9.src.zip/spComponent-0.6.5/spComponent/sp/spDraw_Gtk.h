/*
 *	spDraw_Gtk.h
 */

#ifndef __SPDRAW_GTK_H
#define __SPDRAW_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAW_GTK_H */
