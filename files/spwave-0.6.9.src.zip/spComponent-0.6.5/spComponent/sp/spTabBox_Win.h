/*
 *	spTabBox_Win.h
 */

#ifndef __SPTABBOX_WIN_H
#define __SPTABBOX_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_DEFAULT_TAB_HEIGHT 25

typedef struct _spTabBoxArchPart {
    int dummy;
} spTabBoxArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOX_WIN_H */
