/*
 *	spText_Mac.h
 */

#ifndef __SPTEXT_MAC_H
#define __SPTEXT_MAC_H

#if !defined(MACOSX)
#include <TextEdit.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTextArchPart {
    TEHandle text;
    ControlRef vscroll;
    ControlRef hscroll;
    spComponent next_text;
    spComponent prev_text;
    spBool activated;
} spTextArchPart;

#if defined(MACOS)
#pragma import on
#endif

extern void spSetControlFontMac(spComponent component, char *font_name);
extern void spTEFromScrapMac(void);
extern void spTEToScrapMac(void);
extern void spGetTextFrameRectMac(spComponent text, Rect *prect);
extern spBool spActivateTextMac(spComponent text, spBool foreground);
extern spBool spDeactivateTextMac(spComponent text, spBool foreground);
extern void spDrawTextFrameMac(Rect frame_rect, spBool sensitive_flag, spBool focus_flag);
extern void spDrawTextMac(spComponent text, spBool update);
extern void spUpdateTextMac(spComponent component);
extern spBool spHandleTextMouseDownMac(WindowPtr window, EventModifiers modifiers, Point point);
extern spBool spHandleTextActivateKeyDownMac(spComponent component, char key);
extern spBool spIsTextCursorMoveKeyMac(char key);
extern spBool spHandleTextKeyDownMac(spComponent component, EventModifiers modifiers, int keycode, char key);
extern spBool spHandleExceedTextMac(spComponent component, char key, long input_len);
extern void spSetTextStringMac(spComponent component, char *string);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXT_MAC_H */
