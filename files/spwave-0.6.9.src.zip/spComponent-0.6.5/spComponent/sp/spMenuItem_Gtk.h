/*
 *	spMenuItem_Gtk.h
 */

#ifndef __SPMENUITEM_GTK_H
#define __SPMENUITEM_GTK_H

#include <gtk/gtk.h>

#include <sp/spMenu_Gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void spShowMenuHelpCB(GtkWidget *widget, GdkEvent *event, gpointer data);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUITEM_GTK_H */
