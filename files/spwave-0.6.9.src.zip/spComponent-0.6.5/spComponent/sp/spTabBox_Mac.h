/*
 *	spTabBox_Mac.h
 */

#ifndef __SPTABBOX_MAC_H
#define __SPTABBOX_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#define SP_DEFAULT_TAB_HEIGHT 25

typedef struct _spTabBoxArchPart {
    ControlRef root_control;
} spTabBoxArchPart;

#if defined(MACOS)
#pragma import on
#endif

extern spBool spSelectTabItemMac(spComponent component, ControlPartCode part);
extern spBool spSelectTabBoxMac(spComponent component, Point point);
extern void spDrawTabBoxMac(spComponent component, spBool erase_flag);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOX_MAC_H */
