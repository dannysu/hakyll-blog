/*
 *	spGraphics_Gtk.h
 */

#ifndef __SPGRAPHICS_GTK_H
#define __SPGRAPHICS_GTK_H

#include <gdk/gdk.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_SYSTEM_COLOR_BACKGROUND_PIXEL spRGB(215,215,215)
#define SP_SYSTEM_COLOR_TOP_SHADOW_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_BOTTOM_SHADOW_PIXEL spRGB(150,150,150)
#define SP_SYSTEM_COLOR_HIGHLIGHT_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_DARK_SHADOW_PIXEL 0L
#define SP_SYSTEM_COLOR_BLACK_PIXEL 0L
#define SP_SYSTEM_COLOR_WHITE_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_FOCUS_PIXEL 0L
#define SP_SYSTEM_COLOR_TAB_BACKGROUND_PIXEL SP_SYSTEM_COLOR_BACKGROUND_PIXEL

typedef struct _spCursorArchPart {
    GdkCursor *cursor;
} spCursorArchPart;

typedef struct _spGraphicsArchPart {
    GdkFont *font;
    GdkGC *gc;
} spGraphicsArchPart;

extern void spGetColorValue(char *color_name, GdkColor *color);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPGRAPHICS_GTK_H */
