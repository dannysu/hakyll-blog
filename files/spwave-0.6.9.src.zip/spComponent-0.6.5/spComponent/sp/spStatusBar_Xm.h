/*
 *	spStatusBar_Xm.h
 */

#ifndef __SPSTATUSBAR_XM_H
#define __SPSTATUSBAR_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spStatusBarArchPart {
    int num_label;
    Widget *labels;
} spStatusBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSTATUSBAR_XM_H */
