/*
 *	spComponentMain.h
 */

#ifndef __SPMAIN_H
#define __SPMAIN_H

#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
#if defined(USE_CONSOLE) && !defined(__CYGWIN32__)
#include <io.h>
#include <fcntl.h>
#endif
#endif

#include <sp/spBase.h>
#include <sp/spComponentDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
extern int spWinMainInitialize(HINSTANCE hThisInst, HINSTANCE hPrevInst, int nWinMode);
extern char **spGetArgv(LPSTR lpszArgs, int *argc);
extern void spFreeArgv(int argc, char **argv);

int spMain(int argc, char *argv[]);

int WINAPI WinMain(HINSTANCE hThisInst, HINSTANCE hPrevInst, 
		   LPSTR lpszArgs, int nWinMode)
{
    int flag;
    int argc;
    char **argv;

    if (spWinMainInitialize(hThisInst, hPrevInst, nWinMode) == FALSE) {
	return FALSE;
    }
    argv = spGetArgv(lpszArgs, &argc);
    
#if defined(USE_CONSOLE) && !defined(__CYGWIN32__)
    {
	/* Don't use this code except for debug */
	int hcrt;
	FILE *hf;
	
	AllocConsole();
	hcrt = _open_osfhandle((long)GetStdHandle(STD_ERROR_HANDLE), _O_TEXT);
	hf = _fdopen(hcrt, "w");
	*stderr = *hf;
	setvbuf(stderr, NULL, _IONBF, 0);
    }
#endif
    
    flag = spMain(argc, argv);
    spFreeArgv(argc, argv);

    return flag;
}

#elif defined(MACOS)

#pragma import on
int spMain(int argc, char *argv[]);
#pragma import off

#if defined(HIGH_LEVEL_EVENT)

#pragma import on

extern spBool spInitializeMac(int argc, char **argv, spMainFunc func);
extern void spWaitHighLevelEventMac(void);

#pragma import off

int main(int argc, char *argv[])
{
#if !TARGET_API_MAC_CARBON
    MaxApplZone();
#endif
    if (spInitializeMac(argc, argv, spMain) == SP_FALSE) {
	return spMain(argc, argv);
    } else {
	spWaitHighLevelEventMac();
    }
    
    return 0;
}

#else  /* defined(HIGH_LEVEL_EVENT) */

int main(int argc, char *argv[])
{
#if !TARGET_API_MAC_CARBON
    MaxApplZone();
#endif
    return spMain(argc, argv);
}

#endif /* defined(HIGH_LEVEL_EVENT) */

#else
#define spMain main
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMAIN_H */
