/*
 *	spObject.h
 */

#ifndef __SPOBJECT_H
#define __SPOBJECT_H

#include <sp/spBase.h>
#include <sp/spComponentDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SppName "SName"		/* CSG */
    
typedef struct _spObjectRec *spObject;
typedef struct _spObjectClassRec *spObjectClass;

typedef void *(*spAllocateFunc)(char *class_name, char *object_name);
typedef void (*spFreeFunc)(void *object);

#if defined(MACOS)
#pragma import on
#endif

extern spBool spNoParam(spParam param);
extern spBool spEqParam(spParam param1, spParam param2);
extern spParamType spGetParamType(spParam param);
extern spBool spIsObjectCreated(spObject object);
extern void spSetObjectParamsArg(spObject object, spArg *args, int num_arg);
extern void spSetObjectParams(spObject object, ...);
extern void spGetObjectParamsArg(spObject object, spArg *args, int num_arg);
extern void spGetObjectParams(spObject object, ...);
extern void spDestroyObject(spObject object);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPOBJECT_H */
