/*
 *	spToolBar_Gtk.h
 */

#ifndef __SPTOOLBAR_GTK_H
#define __SPTOOLBAR_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolBarArchPart {
    GdkBitmap *bitmap;
} spToolBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLBAR_GTK_H */
