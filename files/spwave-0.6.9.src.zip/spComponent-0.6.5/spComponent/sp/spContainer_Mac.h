/*
 *	spContainer_Mac.h
 */

#ifndef __SPCONTAINER_MAC_H
#define __SPCONTAINER_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#define SP_CONTAINER_TITLE_OFFSET 5

#if defined(MACOS)
#pragma import on
#endif

extern void spMapContainerMac(spComponent component);
extern void spUnmapContainerMac(spComponent component);
extern void spDrawContainerMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCONTAINER_MAC_H */
