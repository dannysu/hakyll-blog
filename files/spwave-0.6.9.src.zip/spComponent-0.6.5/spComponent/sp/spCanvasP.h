/*
 *	spCanvasP.h
 */

#ifndef __SPCANVASP_H
#define __SPCANVASP_H

#include <sp/spPrimitiveP.h>
#include <sp/spCanvas.h>
#if defined(GTK)
#include <sp/spCanvas_Gtk.h>
#elif defined(_WIN32)
#include <sp/spCanvas_Win.h>
#elif defined(MACOS)
#include <sp/spCanvas_Mac.h>
#elif defined(BEOS)
#include <sp/spCanvas_Be.h>
#else
#include <sp/spCanvas_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spCanvasPart {
    int prev_width;
    int prev_height;
    spBool capture_flag;

    spBool border_on;
    spBool focusable;
    spBool draw_background;
    spBool use_tab_key;
    spBool use_arrow_key;
    int size;
} spCanvasPart;

typedef struct _spCanvasRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spCanvasPart canvas;
} spCanvasRec;
    
typedef struct _spCanvasClassPart {
    int dummy;
} spCanvasClassPart;

typedef struct _spCanvasClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spCanvasClassPart canvas;
} spCanvasClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spCanvasClassRec SpCanvasClassRec;

#define SpCanvasPart(comp) (((spCanvas)comp)->canvas)
#define SpParentCanvasPart(comp) (((spCanvas)SpGetParent(comp))->canvas)
#define SpGetCanvasClass(comp) ((spCanvasClass)((comp)->object.object_class))

extern void spCanvasPartInit(spObject object);
extern void spCanvasPartFree(spObject object);
extern void spCanvasCreate(spObject object);
extern void spCanvasCreateArch(spComponent component);
extern void spCanvasSetParams(spObject object);
extern void spCanvasSetParamsArch(spComponent component);
extern void spCanvasDestroy(spObject object);
extern void spCanvasDestroyArch(spComponent component);
extern spBool spIsCanvasExposed(spComponent component);
extern spBool spIsCanvasExposedArch(spComponent component);
extern void spExposeCanvasCB(spComponent component, void *data);
extern void spResizeCanvasCB(spComponent component, void *data);
extern void spExposeCanvasCBArch(spComponent component);
extern void spCanvasSetDefaultSize(spComponent component);
extern void spRefreshCanvasArch(spComponent component);
extern void spRedrawCanvasArch(spComponent component);
extern spBool spSetCanvasCaptureArch(spComponent window);
extern spBool spSetCanvasCursorArch(spComponent component, spCursor cursor);
extern spBool spUnsetCanvasCursorArch(spComponent component);
extern spBool spIsCanvasFocusedArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCANVASP_H */
