/*
 *	spListP.h
 */

#ifndef __SPLISTP_H
#define __SPLISTP_H

#include <sp/spPrimitiveP.h>
#include <sp/spList.h>
#if defined(GTK)
#include <sp/spList_Gtk.h>
#elif defined(_WIN32)
#include <sp/spList_Win.h>
#elif defined(MACOS)
#include <sp/spList_Mac.h>
#elif defined(BEOS)
#include <sp/spList_Be.h>
#else
#include <sp/spList_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spListPart {
    spListArchPart arch_part;
    char **strings;
} spListPart;

typedef struct _spListRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spListPart list;
} spListRec;
    
typedef struct _spListClassPart {
    int dummy;
} spListClassPart;

typedef struct _spListClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spListClassPart list;
} spListClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spListClassRec SpListClassRec;

#define SpListPart(comp) (((spList)comp)->list)
#define SpListArch(comp) (((spList)(comp))->list.arch_part)
#define SpParentListPart(comp) (((spList)SpGetParent(comp))->list)
#define SpGetListClass(comp) ((spListClass)((comp)->object.object_class))

extern void spListPartInit(spObject object);
extern void spListPartFree(spObject object);
extern void spListCreate(spObject object);
extern void spListCreateArch(spComponent component);
extern void spListSetParams(spObject object);
extern void spListSetParamsArch(spComponent component);
extern void spListGetParams(spObject object);
extern void spListGetParamsArch(spComponent component);

extern int spAddListItemArch(spComponent component, char *item);
extern int spAddListIndexArch(spComponent component, char *item, int index);
extern int spDeleteListItemArch(spComponent component, char *item);
extern int spDeleteListIndexArch(spComponent component, int index);
extern int spFindListItemArch(spComponent component, char *item);
extern int spSelectListItemArch(spComponent component, char *item);
extern int spSelectListIndexArch(spComponent component, int index);
extern char *xspGetSelectedListItemArch(spComponent component);
extern int spGetSelectedListIndexArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLISTP_H */
