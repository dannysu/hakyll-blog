/*
 *	spStatusBar_Win.h
 */

#ifndef __SPSTATUSBAR_WIN_H
#define __SPSTATUSBAR_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spStatusBarArchPart {
    int dummy;
} spStatusBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSTATUSBAR_WIN_H */
