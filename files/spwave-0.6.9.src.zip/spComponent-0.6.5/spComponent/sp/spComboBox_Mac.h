/*
 *	spComboBox_Mac.h
 */

#ifndef __SPCOMBOBOX_MAC_H
#define __SPCOMBOBOX_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spComboBoxArchPart {
    ControlRef button;
} spComboBoxArchPart;

#if defined(MACOS)
#pragma import on
#endif

extern spBool spUseBevelButtonForComboButtonMac(void);
extern void spGetComboBoxButtonRectMac(spComponent component, Rect *prect);
extern void spDrawComboBoxMac(spComponent component);
extern spBool spHandleComboBoxMouseDownMac(spComponent text, Point mouse_point, Rect text_rect);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOX_MAC_H */
