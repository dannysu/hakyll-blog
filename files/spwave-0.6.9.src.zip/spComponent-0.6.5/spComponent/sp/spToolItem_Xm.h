/*
 *	spToolItem_Xm.h
 */

#ifndef __SPTOOLITEM_XM_H
#define __SPTOOLITEM_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolItemArchPart {
    Pixmap insens_pixmap;
} spToolItemArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLITEM_XM_H */
