/*
 *	spList_Mac.h
 */

#ifndef __SPLIST_MAC_H
#define __SPLIST_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spListArchPart {
    ListHandle list;
} spListArchPart;

extern void spGetListFrameRectMac(spComponent list, Rect *prect);
extern spBool spActivateListMac(spComponent list, spBool activate, spBool foreground);
extern void spDrawListMac(spComponent component, spBool update);
extern spBool spHandleListValueChangedMac(spComponent list, ControlPartCode part);
extern spBool spHandleListMouseMac(spComponent list, Point point, EventModifiers modifiers);
extern void spScrollListMac(spComponent list, int increment);
extern spBool spHandleListKeyDownMac(spComponent component, EventModifiers modifiers, int keycode, char key);
extern int spGetListNumItemMac(spComponent component);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIST_MAC_H */
