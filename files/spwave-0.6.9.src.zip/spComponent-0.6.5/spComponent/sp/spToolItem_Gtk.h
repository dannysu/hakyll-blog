/*
 *	spToolItem_Gtk.h
 */

#ifndef __SPTOOLITEM_GTK_H
#define __SPTOOLITEM_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolItemArchPart {
    GdkBitmap *bitmap;
    GdkPixmap *insens_pixmap;
} spToolItemArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLITEM_GTK_H */
