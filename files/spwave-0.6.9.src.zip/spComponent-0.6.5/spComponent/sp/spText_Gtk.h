/*
 *	spText_Gtk.h
 */

#ifndef __SPTEXT_GTK_H
#define __SPTEXT_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTextArchPart {
    GtkWidget *vscroll_bar;
    GtkWidget *hscroll_bar;
    GdkFont *font;
} spTextArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXT_GTK_H */
