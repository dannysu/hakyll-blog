/*
 *	spFrameP.h
 */

#ifndef __SPFRAMEP_H
#define __SPFRAMEP_H

#include <sp/spPrimitiveP.h>
#include <sp/spFrame.h>
#if defined(GTK)
#include <sp/spFrame_Gtk.h>
#elif defined(_WIN32)
#include <sp/spFrame_Win.h>
#elif defined(MACOS)
#include <sp/spFrame_Mac.h>
#elif defined(BEOS)
#include <sp/spFrame_Be.h>
#else
#include <sp/spFrame_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spFramePart {
    spFrameArchPart arch_part;
    spComponent menu_bar;
    spComponent tool_bar;
    spComponent status_bar;
    spComponent task_tray_menu;
    spComponent default_button;
    spComponent cancel_button;
    
    char *icon_name;			/* icon name */
    char *task_tray_icon;		/* icon name for task tray */
    char *task_tray_tip;		/* tips for task tray */
    spWindowType window_type;		/* window type */
    spPopupStyle popup_style;		/* window popup style */
    spCloseStyle close_style;		/* window close style */
    spBool resize_flag;
    spBool iconfy_flag;
    spBool task_tray_visible;		/* is task tray visible? */
    spBool internal_flag;
    spBool simplify_flag;
    spComponent parent_window;		/* if not null, the window is sub-window */
} spFramePart;

typedef struct _spFrameRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spFramePart frame;
} spFrameRec;
    
typedef struct _spFrameClassPart {
    int dummy;
} spFrameClassPart;

typedef struct _spFrameClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spFrameClassPart frame;
} spFrameClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spFrameClassRec SpFrameClassRec;

#define SpFramePart(comp) (((spFrame)(comp))->frame)
#define SpFrameArch(comp) (((spFrame)(comp))->frame.arch_part)
#define SpParentFramePart(comp) (((spFrame)SpGetParent(comp))->frame)
#define SpParentFrameArch(comp) (SpParentFramePart(comp).arch_part)
#define SpGetFrameClass(comp) ((spFrameClass)((comp)->object.object_class))

extern void spFramePartInit(spObject object);
extern void spFramePartInitArch(spComponent component);
extern void spFramePartFree(spObject object);
extern void spFramePartFreeArch(spComponent component);
extern void spFrameCreate(spObject object);
extern void spFrameDestroy(spObject object);
extern void spFrameSetParams(spObject object);
extern void spFrameCreateArch(spComponent component);
extern void spFrameDestroyArch(spComponent component);
extern void spFrameSetParamsArch(spComponent component);
extern void *spGetArchFrame(spComponent component);
extern spBool spShowTaskTrayArch(spComponent window, spBool flag);
extern void spPopupFrameArch(spComponent frame, spBool move_cursor);
extern void spPopdownFrameArch(spComponent frame);
extern void spRaiseFrameArch(spComponent window);
extern void spLowerFrameArch(spComponent window);
extern spBool spSetFramePositionArch(spComponent window, int x, int y);
extern spBool spGetFramePositionArch(spComponent window, int *x, int *y);
extern spBool spGetFrameModifierKeyMaskArch(spComponent window, spModifierMask *mask);
extern spBool spAddDropCallbackArch(spComponent component, spDropCallbackFunc call_func,
				    void *call_data);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAMEP_H */
