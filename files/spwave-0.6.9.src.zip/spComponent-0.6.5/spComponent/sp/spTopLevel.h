/*
 *	spTopLevel.h
 */

#ifndef __SPTOPLEVEL_H
#define __SPTOPLEVEL_H

#include <sp/spObject.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpTopLevel "TopLevel"
    
#define SppLanguage "SLanguage"		/* CG */
#define SppIconName "SIconName"		/* CG */
#define SppInformation "SInformation"	/* CSG */
#define SppAltCtrlSwap "bAltCtrlSwap"	/* CSG */
#define SppExitPrompt "bExitPrompt"	/* CSG */
#define SppThreadSafe "bThreadSafe"	/* CG */
#define SppResources "LResources"	/* CG; internal use only */    

/* version 0.6.5+ */    
#define SppUseWindowMenu "bUseWindowMenu"	/* CG; use "window" menu on supported OSs */

/* not supported yet */    
#define SppClosePrompt "bClosePrompt" 	/* CSG */
#define SppModifiedClosePrompt "bModifiedClosePrompt" /* CSG */
    
typedef struct _spTopLevelRec *spTopLevel;
typedef struct _spTopLevelClassRec *spTopLevelClass;

#if defined(MACOS)
#pragma import on
#endif

extern void spQuit(int status);
extern int spWaitEvent(spTopLevel toplevel);
extern int spDispatchEvent(spTopLevel toplevel);
extern int spMainLoop(spTopLevel toplevel);
extern spTopLevel spInitializeArg(int *argcp, char ***argvp, spArg *args, int num_arg);
extern spTopLevel spInitialize(int *argcp, char ***argvp, ...);
extern void spSetTopLevelParamsArg(spTopLevel toplevel, spArg *args, int num_arg);
extern void spGetTopLevelParamsArg(spTopLevel toplevel, spArg *args, int num_arg);
extern void spSetTopLevelParams(spTopLevel toplevel, ...);
extern void spGetTopLevelParams(spTopLevel toplevel, ...);
extern spBool spIsTopLevelCreated(void);
extern spBool spIsThreadSafe(void);
extern void spThreadEnter(void);
extern void spThreadLeave(void);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVEL_H */
