/*
 *	spToolItem_Mac.h
 */

#ifndef __SPTOOLITEM_MAC_H
#define __SPTOOLITEM_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolItemArchPart {
    CIconHandle cicon;
} spToolItemArchPart;

extern spBool spSetToolTipMac(spComponent component);	/* need SetPort */
extern spBool spShowToolTipMac(spComponent component, Point point, unsigned long dsec);
extern spBool spHideToolTipMac(EventRecord *event);

extern spBool spUseBevelButtonForToolItemMac(void);
extern void spDrawToolItemMac(spComponent component, spBool sensitive);
extern spBool spHandleToolItemMouseDownMac(spComponent component, Point point);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLITEM_MAC_H */
