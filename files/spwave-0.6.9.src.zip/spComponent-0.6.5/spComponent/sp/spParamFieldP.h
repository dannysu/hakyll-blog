/*
 *	spParamFieldP.h
 */

#ifndef __SPPARAMFIELDP_H
#define __SPPARAMFIELDP_H

#include <sp/spComponentP.h>
#include <sp/spParamField.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spParamFieldPart {
    /* private */
    spComponent box;
    spComponent title_label;
    spComponent field;
    spComponent dim_label;
    
    /* parameters */
    spFieldType field_type;
    spBool set;
    spBool border_on;
    spBool editable;
    spBool use_check_box;
    int size;
    int field_offset;
    int field_size;
    int dim_size;
    char *string;
    char **strings;
    char *dim_string;
    
    char **file_filters;
    char **file_types;
    int *filter_index;
    char *initial_dir;

    char *initial_font;
    char *initial_color;
} spParamFieldPart;

typedef struct _spParamFieldRec {
    spObjectPart object;
    spComponentPart component;
    spParamFieldPart param_field;
} spParamFieldRec;
    
typedef struct _spParamFieldClassPart {
    int dummy;
} spParamFieldClassPart;

typedef struct _spParamFieldClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spParamFieldClassPart param_field;
} spParamFieldClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spParamFieldClassRec SpParamFieldClassRec;

#define SpParamFieldPart(comp) (((spParamField)comp)->param_field)
#define SpParentParamFieldPart(comp) (((spParamField)SpGetParent(comp))->param_field)
#define SpGetParamFieldClass(comp) ((spParamFieldClass)((comp)->object.object_class))

extern void spParamFieldPartInit(spObject object);
extern void spParamFieldPartFree(spObject object);
extern void spParamFieldCreate(spObject object);
extern void spParamFieldDestroy(spObject object);
extern void spParamFieldSetParams(spObject object);
extern void spParamFieldMap(spComponent component);
extern void spParamFieldUnmap(spComponent component);
extern spBool spParamFieldSetSize(spComponent component, int width, int height);
extern spBool spParamFieldGetSize(spComponent component, int *width, int *height);
extern spBool spParamFieldGetClientSize(spComponent component, int *width, int *height);
extern spBool spParamFieldSetSensitive(spComponent component, spBool flag);
extern spBool spParamFieldIsComponentType(spComponent component, char *class_name);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPARAMFIELDP_H */
