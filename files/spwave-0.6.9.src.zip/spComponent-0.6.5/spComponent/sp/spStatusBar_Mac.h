/*
 *	spStatusBar_Mac.h
 */

#ifndef __SPSTATUSBAR_MAC_H
#define __SPSTATUSBAR_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spStatusBarArchPart {
    char **labels;
} spStatusBarArchPart;

#if defined(MACOS)
#pragma import on
#endif

extern void spDrawStatusBarMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSTATUSBAR_MAC_H */
