/*
 *	spButtonP.h
 */

#ifndef __SPBUTTONP_H
#define __SPBUTTONP_H

#include <sp/spLabelP.h>
#include <sp/spButton.h>
#if defined(GTK)
#include <sp/spButton_Gtk.h>
#elif defined(_WIN32)
#include <sp/spButton_Win.h>
#elif defined(MACOS)
#include <sp/spButton_Mac.h>
#elif defined(BEOS)
#include <sp/spButton_Be.h>
#else
#include <sp/spButton_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_BUTTON_LABEL 512

typedef struct _spButtonPart {
    spBool set;				/* is toggle button set? */
    spBool default_flag;		/* is default button? */
    spBool cancel_flag;			/* is cancel button? */
    spBool radio_end;			/* is end of radio button? */
} spButtonPart;

typedef struct _spButtonRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spLabelPart label;
    spButtonPart button;
} spButtonRec;

typedef struct _spButtonClassPart {
    int dummy;
} spButtonClassPart;

typedef struct _spButtonClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spLabelClassPart label;
    spButtonClassPart button;
} spButtonClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spButtonClassRec SpButtonClassRec;

#define SpButtonPart(comp) (((spButton)comp)->button)
#define SpParentButtonPart(comp) (((spButton)SpGetParent(comp))->button)
#define SpGetButtonClass(comp) ((spButtonClass)((comp)->object.object_class))

extern int spGetMnemonic(char *label, char *text);
extern void spButtonPartInit(spObject object);
extern void spButtonPartFree(spObject object);
extern void spButtonCreate(spObject object);
extern void spButtonCreateArch(spComponent component);
extern void spButtonSetParams(spObject object);
extern void spButtonSetParamsArch(spComponent component);
extern void spButtonGetParams(spObject object);
extern void spSetToggleStateArch(spComponent component);
extern void spGetToggleStateArch(spComponent component);
extern void spAddRadioGroup(spComponent component, spBool radio_end);
extern void spCheckRadioButton(spComponent component, spComponent first,
			       spComponent last);
extern void spCheckRadioButtonCB(spComponent component, void *data);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPBUTTONP_H */
