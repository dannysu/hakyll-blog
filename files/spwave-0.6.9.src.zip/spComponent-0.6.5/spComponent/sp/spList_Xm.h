/*
 *	spList_Xm.h
 */

#ifndef __SPLIST_XM_H
#define __SPLIST_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spListArchPart {
    int dummy;
} spListArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIST_XM_H */
