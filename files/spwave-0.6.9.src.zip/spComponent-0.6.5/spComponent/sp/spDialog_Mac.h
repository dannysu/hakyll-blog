/*
 *	spDialog_Mac.h
 */

#ifndef __SPDIALOG_MAC_H
#define __SPDIALOG_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spDialogArchPart {
    int dummy;
} spDialogArchPart;

extern DialogPtr spGetCurrentSheetDialogMacX(void);
extern spBool spQuitCurrentSheetDialogMacX(void);
extern spBool spSetDialogResponseMacX(UInt32 commandID);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALOG_MAC_H */
