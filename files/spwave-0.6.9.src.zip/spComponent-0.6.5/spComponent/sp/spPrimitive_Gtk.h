/*
 *	spPrimitive_Gtk.h
 */

#ifndef __SPPRIMITIVE_GTK_H
#define __SPPRIMITIVE_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

struct _spCallback {
    spComponent component;
    spCallbackFunc call_func;
    void *call_data;
    spBool propagate;
    
    gchar *call_name;
    gint func_id;
    gint event_mask;
};

typedef struct _spCallbackTable {
    spCallbackType call_type;
    spComponentType component_type;
    gchar *call_name;
    gint event_mask;
} spCallbackTable;

typedef struct _spPrimitiveArchPart {
    GtkWidget *widget;			/* main widget */
    GtkWidget *top_widget;		/* top widget in component */
    GtkWidget *sub_widget;		/* sub widget */
    GtkObject *adjustment;		/* adjustment widget */
    GdkPixmap *pixmap;			/* pixmap for drawable */
    gchar *call_name;
    GdkEvent *event;
    gint event_mask;
} spPrimitiveArchPart;
    
extern void spSetStyleGtk(spComponent component, GtkWidget *widget);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVE_GTK_H */
