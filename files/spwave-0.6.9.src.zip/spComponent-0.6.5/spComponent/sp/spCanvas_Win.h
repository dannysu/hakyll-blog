/*
 *	spCanvas_Win.h
 */

#ifndef __SPCANVAS_WIN_H
#define __SPCANVAS_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCANVAS_WIN_H */
