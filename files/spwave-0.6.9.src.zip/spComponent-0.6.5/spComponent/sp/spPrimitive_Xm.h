/*
 *	spPrimitive_Xm.h
 */

#ifndef __SPPRIMITIVE_XM_H
#define __SPPRIMITIVE_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_USE_BULLETIN_BOARD_FOR_WINDOW
    
#define SP_CLOSE_CALLBACK_ID 1L
#define SP_DESTROY_CALLBACK_ID 2L
    
struct _spCallback {
    spComponent component;
    spCallbackFunc call_func;
    void *call_data;
    spBool propagate;
    
    String call_name;
    EventMask event_mask;
};

typedef struct _spCallbackTable {
    spCallbackType call_type;
    spComponentType component_type;
    String call_name;
    EventMask event_mask;
} spCallbackTable;

typedef struct _spPrimitiveArchPart {
    Widget toplevel;			/* toplevel widget */
    Widget widget;			/* main widget */
    Widget top_widget;			/* top widget in component */
    Widget sub_widget;			/* sub widget */
    Pixmap pixmap;			/* pixmap for drawable */
    Window drawable;			/* drawable area */
    Display *display;			/* display of component */
    Screen *screen;			/* screen of component */
    void *xt_call_data;			/* callback data for Xt */
    EventMask event_mask;		/* event mask for event hander */
    int num_xmstring;			/* number of XmStrings */
    int num_xmstring_buffer;		/* size of XmStrings buffer */
    XmString *xmstrings;		/* XmString list for list component */
} spPrimitiveArchPart;
    
extern void spPopdownToolTipXm(spComponent component);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVE_XM_H */
