/*
 *	spDraw.h
 */

#ifndef __SPDRAW_H
#define __SPDRAW_H

#include <sp/spComponent.h>
#include <sp/spGraphics.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpImage "Image"
    
#define SP_DEFAULT_IMAGE_WIDTH 256
#define SP_DEFAULT_IMAGE_HEIGHT 256

#if defined(MACOS)
#pragma import on
#endif

extern spComponent spCreateImage(spComponent parent, char *name,
				 int width, int height, ...);
extern spBool spIsDrawable(spComponent component);
extern void spDrawImage(spComponent component);
extern void spRedrawImage(spComponent component, int width, int height);
extern void spResizeImage(spComponent component, int width, int height);
extern void spCopyImage(spComponent src, spComponent dest,
			int src_x, int src_y, int width, int height,
			int dest_x, int dest_y);
extern void spFillRectangle(spComponent component, spGraphics graphics,
			    int x, int y, int width, int height);
extern void spDrawRectangle(spComponent component, spGraphics graphics,
			    int x, int y, int width, int height);
extern void spFillArc(spComponent component, spGraphics graphics,
		      int x, int y, int width, int height, int angle1, int angle2);
extern void spDrawArc(spComponent component, spGraphics graphics,
		      int x, int y, int width, int height, int angle1, int angle2);
extern void spDrawLine(spComponent component, spGraphics graphics,
		       int x1, int y1, int x2, int y2);
extern void spDrawPoint(spComponent component, spGraphics graphics,
			int x, int y);
extern void spDrawString(spComponent component, spGraphics graphics,
			 int x, int y, char *string);
extern spBool spGetStringExtent(spGraphics graphics, char *string,
				int *x, int *y, int *width, int *height);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAW_H */
