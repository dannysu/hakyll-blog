/*
 *	spObjectP.h
 */

#ifndef __SPOBJECTP_H
#define __SPOBJECTP_H

#include <sp/spObject.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spObjectPart {
    spObjectClass object_class;		/* object class */
    char *class_name;			/* sub class name */
    char *name;				/* object name */
    spBool create_flag;			/* is object created? */
    spObject old_object;
} spObjectPart;

typedef struct _spObjectRec {
    spObjectPart object;
} spObjectRec;
    
typedef struct _spObjectClassPart {
    char *class_name;
    spObjectClass super_class;
    int object_size;
    int num_param_table;
    spParamTable *param_tables;
    void (*object_part_init) __P((spObject object));
    void (*object_part_free) __P((spObject object));
    spBool class_part_inited;
    void (*class_part_init) __P((spObjectClass object_class));
    void (*class_part_free) __P((spObjectClass object_class));
    void (*create) __P((spObject object));
    void (*destroy) __P((spObject object));
    void (*set_params) __P((spObject object));
    void (*get_params) __P((spObject object));
} spObjectClassPart;

typedef struct _spObjectClassRec {
    spObjectClassPart object;
} spObjectClassRec;

#define SpOldObject(obj) (((spObject)obj)->object.old_object)

#define SpObjectPart(obj) (((spObject)obj)->object)
#define SpGetName(obj) (((spObject)obj)->object.name)
#define SpGetObjectClass(obj) (((spObject)obj)->object.object_class)
#define SpGetClassName(obj) (spStrNone(SpObjectPart(obj).class_name) ? SpGetObjectClass(obj)->object.class_name : SpObjectPart(obj).class_name)

#if defined(MACOS)
#pragma import on
#endif

extern spObject spAllocObject(spObjectClass object_class, char *class_name, char *name);
extern void spFreeObject(spObject object);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPOBJECTP_H */
