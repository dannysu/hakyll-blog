/*
 *	spTopLevel_Win.h
 */

#ifndef __SPTOPLEVEL_WIN_H
#define __SPTOPLEVEL_WIN_H

#include <sp/spComponent_Win.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_WINDOW_CLASS_NAME "spWindow"
#define SP_CANVAS_CLASS_NAME "spCanvas"

#define SP_ACCEL_BUFFER 16

typedef struct _spTopLevelArchPart {
    HINSTANCE hThisInst;
    HINSTANCE hPrevInst;
    int nWinMode;
    MSG msg;
    HFONT sys_font;
    HPEN null_pen;
    HBRUSH null_brush;
    HBRUSH bg_brush;
    HCURSOR hcursor;
} spTopLevelArchPart;

/*extern void spQuit(int status);*/

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVEL_WIN_H */
