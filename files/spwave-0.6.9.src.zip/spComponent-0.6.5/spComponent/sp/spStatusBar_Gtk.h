/*
 *	spStatusBar_Gtk.h
 */

#ifndef __SPSTATUSBAR_GTK_H
#define __SPSTATUSBAR_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spStatusBarArchPart {
    int total_size;
    GtkWidget *last_frame;
} spStatusBarArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSTATUSBAR_GTK_H */
