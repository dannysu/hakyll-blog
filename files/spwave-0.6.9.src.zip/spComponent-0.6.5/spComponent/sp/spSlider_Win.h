/*
 *	spSlider_Win.h
 */

#ifndef __SPSLIDER_WIN_H
#define __SPSLIDER_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void spUpdateSlider(spComponent component);
extern void spDrawTrackBarValue(spComponent component);
extern void spUpdateTrackBar(spComponent component);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSLIDER_WIN_H */
