/*
 *	spButton_Win.h
 */

#ifndef __SPBUTTON_WIN_H
#define __SPBUTTON_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPBUTTON_WIN_H */
