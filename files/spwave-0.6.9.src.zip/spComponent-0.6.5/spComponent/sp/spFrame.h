/*
 *	spFrame.h
 */

#ifndef __SPFRAME_H
#define __SPFRAME_H

#include <sp/spPrimitive.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpFrame "Frame"
#define SpMainFrame "MainFrame"
    
#define SppIconName "SIconName"	/* CSG */
#define SppPopupStyle "ePopupStyle" /* CG */
#define SppCloseStyle "eCloseStyle" /* CG */
#define SppWindowType "eWindowType" /* CG */
#define SppResizable "bResizable" /* CG */
#define SppIconfiable "bIconfiable" /* CG */
#define SppSimplifiable "bSimplifiable" /* CG */
#define SppInternalWindow "bInternalWindow" /* CG */
#define SppParentWindow "PParentWindow" /* CG */
#define SppTaskTrayVisible "bTaskTrayVisible" /* CSG */
#define SppTaskTrayIcon "STaskTrayIcon" /* CSG */
#define SppTaskTrayTip "STaskTrayTip" /* CSG */

typedef enum {
    SP_MODELESS_POPUP = 0,
    SP_MODAL_POPUP = 1,
    SP_SYSTEM_MODAL_POPUP = 2,
} spPopupStyle;

#define SP_MODELESS_POPUP_STRING "0"
#define SP_MODAL_POPUP_STRING "1"
#define SP_SYSTEM_MODAL_POPUP_STRING "2"

typedef enum {
    SP_NO_CLOSE = 0,
    SP_UNMAP_CLOSE = 1,
    SP_DESTROY_CLOSE = 2,
    SP_CALLBACK_CLOSE = 3,
} spCloseStyle;
    
#define SP_NO_CLOSE_STRING "0"
#define SP_UNMAP_CLOSE_STRING "1"
#define SP_DESTROY_CLOSE_STRING "2"
#define SP_CALLBACK_CLOSE_STRING "3"

typedef enum {
    SP_NORMAL_WINDOW = 0,
    SP_DIALOG_WINDOW = 1,
    SP_TRANSIENT_WINDOW = 2,
} spWindowType;

#define SP_NORMAL_WINDOW_STRING "0"
#define SP_DIALOG_WINDOW_STRING "1"
#define SP_TRANSIENT_WINDOW_STRING "2"

    
typedef struct _spFrameRec *spFrame;

typedef void (*spDrawFunc)(void *call_data, int x, int y, int width, int height);
typedef void (*spMouseFunc)(void *call_data, int x, int y);
typedef void (*spKeyFunc)(void *call_data, long keycode);
typedef void (*spForegroundFunc)(void *call_data);
typedef void (*spBackgroundFunc)(void *call_data);

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpFrameClass;

extern spBool spIsFrame(spComponent component);
extern spComponent spCreateFrame(char *name, ...);
extern spComponent spCreateMainFrame(char *name, ...);
extern spBool spIsTaskTraySupported(void);
extern spBool spAddDropCallback(spComponent component, spDropCallbackFunc call_func, void *call_data);

extern void spAddFrameCallback(spComponent component, spDrawFunc draw_func,
			       spMouseFunc mouse_func, spKeyFunc key_func,
			       spForegroundFunc foreground_func, spBackgroundFunc background_func, 
			       void *data);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAME_H */
