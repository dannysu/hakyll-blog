/*
 *	spContainer_Xm.h
 */

#ifndef __SPCONTAINER_XM_H
#define __SPCONTAINER_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_CONTAINER_TITLE_OFFSET 5

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCONTAINER_XM_H */
