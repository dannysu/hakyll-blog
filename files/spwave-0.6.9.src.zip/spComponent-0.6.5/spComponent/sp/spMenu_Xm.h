/*
 *	spMenu_Xm.h
 */

#ifndef __SPMENU_XM_H
#define __SPMENU_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

#if 0
#if defined(linux) &&  (XmVersion <= 2000)
#define MNEMONIC_LOWER
#endif
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENU_XM_H */
