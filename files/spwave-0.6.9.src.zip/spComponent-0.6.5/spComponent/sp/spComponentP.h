/*
 *	spComponentP.h
 */

#ifndef __SPCOMPONENTP_H
#define __SPCOMPONENTP_H

#include <sp/spObjectP.h>
#include <sp/spTopLevelP.h>
#include <sp/spComponent.h>
#if defined(GTK)
#include <sp/spComponent_Gtk.h>
#elif defined(_WIN32)
#include <sp/spComponent_Win.h>
#elif defined(MACOS)
#include <sp/spComponent_Mac.h>
#elif defined(BEOS)
#include <sp/spComponent_Be.h>
#else
#include <sp/spComponent_Xm.h>
#endif

#include <sp/spStringDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_INIT_SENSE_LEVEL (-1)
#define SP_INIT_SENSE_LEVEL_STRING "-1"
   
#define SP_COMPONENT_BUFFER 16
#define SP_WINDOW_BUFFER 16

#define SP_RADIO_GROUP_START 1
#define SP_RADIO_GROUP_END 2
#define SP_RADIO_GROUP_MEMBER 0

typedef struct _spComponents *spComponents;
struct _spComponents {
    spBool sense_level_init;
    long current_component_id;
    long destroy_component_id;
    spComponent child;
    spComponent last_child;
};

typedef struct _spComponentPart {
    /* private */
    long component_id;			/* component ID */
    long current_sense_level;		/* current sense level */
    spComponent component;		/* component self */
    spComponent window;			/* parent window */
    spComponent parent;			/* parent component */
    spComponent child;			/* first child component */
    spComponent last_child;		/* last child component */
    spComponent next_component;		/* next component */
    spComponent prev_component;		/* previous component */
    spComponent propagate_component;	/* event propagates this component */
    int x, y;				/* component position */
    int current_width, current_height; 	/* current size */
    int prev_width, prev_height; 	/* previous size */
    int require_width, require_height; 	/* required size */
    int client_width, client_height; 	/* size of client area */
    int border_width;			/* border width */
    int top_offset;			/* top offset */
    int bottom_offset;			/* bottom offset */
    int left_offset;			/* left offset */
    int right_offset;			/* right offset */
    int margin_bottom; 			/* bottom margin */
    spBool geometry_flag;		/* flag to prevent from redundant callback */
    spBool spacing_flag;		/* true if component spaced */
    spBool visible_flag;		/* is component visible? */
    spBool sensitive_flag;		/* is component sensitive? */
    spBool focus_flag;			/* is component focused? */
    spCallbackReason call_reason; 	/* callback reason */

    /* parameters */
    char *title;			/* title of component */
    char *description;			/* description of component */
    long sense_level;			/* sense level */
    long group_id;			/* group ID */
    void *user_data;			/* user specific data */
    spOrientation orientation;		/* component orientation */
    int width, height;			/* component size */
    int margin_width, margin_height; 	/* size of margin */
    int spacing;			/* size between components */
    spCallbackFunc call_func;		/* function pointer */
    void *call_data;			/* data for callback */
} spComponentPart;
    
typedef struct _spComponentRec {
    spObjectPart object;
    spComponentPart component;
} spComponentRec;
    
typedef struct _spComponentClassPart {
    spBool resize_flag;
    spBool window_flag;
    spBool container_flag;
    void (*map) __P((spComponent component));
    void (*unmap) __P((spComponent component));
    spBool (*set_size) __P((spComponent component, int width, int height));
    spBool (*get_size) __P((spComponent component, int *width, int *height));
    spBool (*get_client_size) __P((spComponent component, int *width, int *height));
    spBool (*set_sensitive) __P((spComponent component, spBool flag));
    spBool (*is_component_type) __P((spComponent component, char *class_name));
    spBool (*add_callback) __P((spComponent component, spBool propagate, spCallbackType call_type,
				spCallbackFunc call_func, void *call_data));
    spBool (*remove_callback) __P((spComponent component, spCallbackType call_type,
				   spCallbackFunc call_func, void *call_data));
    spCallbackReason (*callback_func) __P((spComponent component));
    spBool (*get_callback_mouse_position) __P((spComponent component, int *x, int *y));
    spBool (*get_callback_key_sym) __P((spComponent component, spKeySym *key_sym));
    spBool (*get_callback_key_string) __P((spComponent component,
					   char *buf, int buf_size, spBool *overflow));
} spComponentClassPart;

typedef struct _spComponentClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
} spComponentClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClassRec SpComponentClassRec;

#define SpGetComponentId(comp) (((spComponent)comp)->component.component_id)
#define SpGetTitle(comp) (((spComponent)comp)->component.title)
#define SpGetDescription(comp) (((spComponent)comp)->component.description)
#define SpGetWindow(comp) (((spComponent)comp)->component.window)
#define SpGetParent(comp) (((spComponent)comp)->component.parent)
#define SpGetChild(comp) (((spComponent)comp)->component.child)
#define SpGetLastChild(comp) (((spComponent)comp)->component.last_child)
#define SpGetNextComponent(comp) (((spComponent)comp)->component.next_component)
#define SpGetPrevComponent(comp) (((spComponent)comp)->component.prev_component)
#define SpGetPropagateComponent(comp) (((spComponent)comp)->component.propagate_component)
#define SpGetComponentClass(comp) ((spComponentClass)((comp)->object.object_class))

#define SpComponentPart(comp) (((spComponent)comp)->component)
#define SpParentComponentPart(comp) SpComponentPart(SpGetParent(comp))

extern spComponent spCreateComponentArg(spComponentClass component_class, char *class_name,
					char *name, spComponent parent, 
					spArg *args, int num_arg);
extern void spSetInitSenseLevel(void);
extern void spFreeComponent(spComponent component);
extern void spComponentCallbackFunc(spCallback *callback);
extern long spGetDestroyedComponentId(void);
extern void spComponentPartInit(spObject object);
extern void spComponentPartFree(spObject object);
extern void spAdjustComponentSize(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMPONENTP_H */
