/*
 *	spLabel_Win.h
 */

#ifndef __SPLABEL_WIN_H
#define __SPLABEL_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLABEL_WIN_H */
