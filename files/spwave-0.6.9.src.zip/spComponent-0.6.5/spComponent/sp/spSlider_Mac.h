/*
 *	spSlider_Mac.h
 */

#ifndef __SPSLIDER_MAC_H
#define __SPSLIDER_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spSliderActionMac(ControlHandle control, short part);
extern void spCreateActionProcMac(void);
extern void spDestroyActionProcMac(void);
extern spBool spHandleSliderActionMac(WindowPtr window, ControlRef control,
				      Point point, ControlPartCode part);
extern void spDrawSliderValueMac(spComponent component);
extern void spDrawSliderMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSLIDER_MAC_H */
