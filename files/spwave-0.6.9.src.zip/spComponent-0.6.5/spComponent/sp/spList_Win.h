/*
 *	spList_Win.h
 */

#ifndef __SPLIST_WIN_H
#define __SPLIST_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spListArchPart {
    int dummy;
} spListArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIST_WIN_H */
