/*
 *	spCanvas_Gtk.h
 */

#ifndef __SPCANVAS_GTK_H
#define __SPCANVAS_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCANVAS_GTK_H */
