/*
 *	spTabBox_Gtk.h
 */

#ifndef __SPTABBOX_GTK_H
#define __SPTABBOX_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spTabBoxArchPart {
    int dummy;
} spTabBoxArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOX_GTK_H */
