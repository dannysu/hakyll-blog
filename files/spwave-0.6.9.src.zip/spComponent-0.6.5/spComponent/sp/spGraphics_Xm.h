/*
 *	spGraphics_Xm.h
 */

#ifndef __SPGRAPHICS_XM_H
#define __SPGRAPHICS_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_SYSTEM_COLOR_BACKGROUND_PIXEL spRGB(192,192,192)
#define SP_SYSTEM_COLOR_TOP_SHADOW_PIXEL spRGB(231,231,231)
#define SP_SYSTEM_COLOR_BOTTOM_SHADOW_PIXEL spRGB(105,105,105)
#define SP_SYSTEM_COLOR_HIGHLIGHT_PIXEL spRGB(231,231,231)
#define SP_SYSTEM_COLOR_DARK_SHADOW_PIXEL spRGB(105,105,105)
#define SP_SYSTEM_COLOR_BLACK_PIXEL 0L
#define SP_SYSTEM_COLOR_WHITE_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_FOCUS_PIXEL 0L
#define SP_SYSTEM_COLOR_TAB_BACKGROUND_PIXEL SP_SYSTEM_COLOR_BACKGROUND_PIXEL
    
typedef struct _spCursorArchPart {
    Cursor cursor;
} spCursorArchPart;

typedef struct _spGraphicsArchPart {
    XFontSet font_set;
    GC gc;
} spGraphicsArchPart;
    
extern Pixel spGetColorPixelXm(char *color_name);
extern spBool spSetCursorXm(Widget widget, spCursor cursor);
extern spBool spUnsetCursorXm(Widget widget);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPGRAPHICS_XM_H */
