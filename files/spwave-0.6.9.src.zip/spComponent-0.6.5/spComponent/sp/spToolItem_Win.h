/*
 *	spToolItem_Win.h
 */

#ifndef __SPTOOLITEM_WIN_H
#define __SPTOOLITEM_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolItemArchPart {
    TBBUTTON tbbutton;
} spToolItemArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLITEM_WIN_H */
