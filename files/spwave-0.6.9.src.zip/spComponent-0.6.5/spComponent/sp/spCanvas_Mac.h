/*
 *	spCanvas_Mac.h
 */

#ifndef __SPCANVAS_MAC_H
#define __SPCANVAS_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spDrawCanvasMac(spComponent component);
extern spMouseButton spGetPressedMouseButtonMac(short modifiers);
extern spBool spHandleCanvasMouseMac(spComponent component, int button_id, Point point,
				     short modifiers, spBool pressed);
extern spBool spHandleCanvasKeyDownMac(spComponent component, EventRecord *event);
extern void spSetCanvasCursorMac(spComponent component);
extern void spUnsetCanvasCursorMac(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCANVAS_MAC_H */
