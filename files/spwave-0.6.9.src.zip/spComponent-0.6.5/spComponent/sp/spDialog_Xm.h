/*
 *	spDialog_Xm.h
 */

#ifndef __SPDIALOG_XM_H
#define __SPDIALOG_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spDialogArchPart {
    spComponent file_type_field;
} spDialogArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALOG_XM_H */
