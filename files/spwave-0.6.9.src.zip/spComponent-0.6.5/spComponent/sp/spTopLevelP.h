/*
 *	spTopLevelP.h
 */

#ifndef __SPTOPLEVELP_H
#define __SPTOPLEVELP_H

#include <sp/spObjectP.h>
#include <sp/spGraphics.h>
#include <sp/spTopLevel.h>
#if defined(GTK)
#include <sp/spTopLevel_Gtk.h>
#elif defined(_WIN32)
#include <sp/spTopLevel_Win.h>
#elif defined(MACOS)
#include <sp/spTopLevel_Mac.h>
#elif defined(BEOS)
#include <sp/spTopLevel_Be.h>
#else
#include <sp/spTopLevel_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTopLevelPart {
    spTopLevelArchPart arch_part;	/* architecture dependent part */
    int *argcp;
    char ***argvp;
    spOptions options;
    spGraphics graphics;
    spGraphics last_graphics;
    
    spBool alt_ctrl_swap;
    spBool exit_prompt;
    spBool close_prompt;
    spBool modify_prompt;
    spBool thread_safe;
    spBool use_window_menu;
    char *language;
    char *icon_name;
    char *information;
} spTopLevelPart;

typedef struct _spTopLevelRec {
    spObjectPart object;
    spTopLevelPart toplevel;
} spTopLevelRec;
    
typedef struct _spTopLevelClassPart {
    int dummy;
} spTopLevelClassPart;

typedef struct _spTopLevelClassRec {
    spObjectClassPart object;
    spTopLevelClassPart toplevel;
} spTopLevelClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spTopLevelClassRec SpTopLevelClassRec;

#define SpTopLevelPart(obj) (((spTopLevel)obj)->toplevel)
#define SpTopLevelArch(obj) (((spTopLevel)obj)->toplevel.arch_part)
#define SpGetTopLevelClass(obj) ((spTopLevelClass)((obj)->object.object_class))

extern void spTopLevelPartInit(spObject object);
extern void spTopLevelPartInitArch(spTopLevel toplevel);
extern void spTopLevelPartFree(spObject object);
extern void spTopLevelPartFreeArch(spTopLevel toplevel);
extern void spTopLevelCreate(spObject object);
extern void spTopLevelCreateArch(spTopLevel toplevel);
extern void spTopLevelSetParams(spObject object);
extern void spTopLevelSetParamsArch(spTopLevel toplevel);
extern void spTopLevelDestroy(spObject object);
extern void spTopLevelDestroyArch(spTopLevel toplevel);
extern int spWaitEventArch(spTopLevel toplevel);
extern int spDispatchEventArch(spTopLevel toplevel);
extern int spMainLoopArch(spTopLevel toplevel);
extern void spQuitArch(int status);
extern spBool spThreadEnterArch(spTopLevel toplevel);
extern spBool spThreadLeaveArch(spTopLevel toplevel);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVELP_H */
