/*
 *	spText.h
 */

#ifndef __SPTEXT_H
#define __SPTEXT_H

#include <sp/spPrimitive.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpText "Text"
#define SpTextArea "TextArea"
#define SpTextField "TextField"
    
#define SppTextString "STextString" /* CSG */
#define SppEditable "bEditable"	/* CSG */
#define SppColumns "iColumns"	/* CG */
#define SppRows "iRows"		/* CG */
    
typedef struct _spTextRec *spText;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpTextClass;

extern spBool spIsText(spComponent component);
extern spBool spIsEditable(spComponent component);
extern spComponent spCreateTextField(spComponent parent, char *name, ...);
extern spComponent spCreateTextArea(spComponent parent, char *name, ...);
extern spBool spSetTextString(spComponent component, char *string);
extern char *spGetTextString(spComponent component);
extern char *xspGetTextString(spComponent component);

/* Version 0.6.5+ */
/* if start == -1, a selection is deselected (end is ignored).
   if end == -1, remaining text is selected. */
extern spBool spSetTextSelection(spComponent component, long start, long end);
/* if no selection, this returns SP_FALSE. */
extern spBool spGetTextSelection(spComponent component, long *start, long *end);
/* selection will be cleared by this function */
extern spBool spSetTextPosition(spComponent component, long position);
extern spBool spGetTextPosition(spComponent component, long *position);

extern spBool spCutText(spComponent component);
extern spBool spCopyText(spComponent component);
extern spBool spPasteText(spComponent component);
extern spBool spClearText(spComponent component);
extern spBool spSelectAllText(spComponent component);

extern void spCutTextCB(spComponent component, void *data);
extern void spCopyTextCB(spComponent component, void *data);
extern void spPasteTextCB(spComponent component, void *data);
extern void spClearTextCB(spComponent component, void *data);
extern void spSelectAllTextCB(spComponent component, void *data);
extern void spSelectAllTextCB(spComponent component, void *data);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXT_H */
