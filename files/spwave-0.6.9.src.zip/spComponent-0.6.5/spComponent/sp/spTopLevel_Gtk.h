/*
 *	spTopLevel_Gtk.h
 */

#ifndef __SPTOPLEVEL_GTK_H
#define __SPTOPLEVEL_GTK_H

#include <gtk/gtk.h>

#include <sp/spComponent_Gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTopLevelArchPart {
    GdkPixmap *pixmap;
    GdkColormap *colormap;
    GdkColor black;
    GdkColor white;
    GdkColor gray;
    GdkFont *font;
    GdkGC *fg_gc;
    GdkGC *bg_gc;
} spTopLevelArchPart;

extern void spMainQuitGtk(void);
extern void spMainLoopGtk(void);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVEL_GTK_H */
