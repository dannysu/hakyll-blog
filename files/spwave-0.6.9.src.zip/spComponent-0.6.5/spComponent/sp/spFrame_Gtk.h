/*
 *	spFrame_Gtk.h
 */

#ifndef __SPFRAME_GTK_H
#define __SPFRAME_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spFrameArchPart {
    GtkWidget *toplevel;
#if GTK_CHECK_VERSION(1,2,0)
    GtkAccelGroup *accel_group;
#else
    GtkAcceleratorTable *accel_group;
#endif
    GtkTooltips *tooltips;
    gint16 prev_width;
    gint16 prev_height;

    guint drop_func_id;
    spDropCallbackFunc drop_call_func;
    void *drop_call_data;
} spFrameArchPart;

extern GtkWidget *spAddGrabGtk(GtkWidget *widget);
extern void spRemoveGrabGtk(GtkWidget *widget);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAME_GTK_H */
