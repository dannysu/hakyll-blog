/*
 *	spTabBox.h
 */

#ifndef __SPTABBOX_H
#define __SPTABBOX_H

#include <sp/spText.h>
#include <sp/spList.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpTabBox "TabBox"
    
#define SppSelectedTabIndex "iSelectedTabIndex"
    
typedef struct _spTabBoxRec *spTabBox;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpTabBoxClass;
    
extern spBool spIsTabBox(spComponent component);
extern spComponent spCreateTabBox(spComponent parent, char *name, int size, ...);
extern int spGetSelectedTabIndex(spComponent component);
extern spComponent spGetSelectedTabItem(spComponent component);
extern spComponent spAddTabItem(spComponent parent, char *name, int index, ...);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOX_H */
