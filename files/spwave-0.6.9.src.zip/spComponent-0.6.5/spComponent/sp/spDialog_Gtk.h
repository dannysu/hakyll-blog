/*
 *	spDialog_Gtk.h
 */

#ifndef __SPDIALOG_GTK_H
#define __SPDIALOG_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spDialogArchPart {
    spComponent file_type_field;
} spDialogArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALOG_GTK_H */
