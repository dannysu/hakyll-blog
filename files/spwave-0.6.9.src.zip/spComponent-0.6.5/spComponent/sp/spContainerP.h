/*
 *	spContainerP.h
 */

#ifndef __SPCONTAINERP_H
#define __SPCONTAINERP_H

#include <sp/spPrimitiveP.h>
#include <sp/spContainer.h>
#if defined(GTK)
#include <sp/spContainer_Gtk.h>
#elif defined(_WIN32)
#include <sp/spContainer_Win.h>
#elif defined(MACOS)
#include <sp/spContainer_Mac.h>
#elif defined(BEOS)
#include <sp/spContainer_Be.h>
#else
#include <sp/spContainer_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spContainerPart {
    int title_offset;
    
    spBool border_on;
    spBool title_on;
    spBool use_text_height;
    int size;
} spContainerPart;

typedef struct _spContainerRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spContainerPart container;
} spContainerRec;
    
typedef struct _spContainerClassPart {
    int dummy;
} spContainerClassPart;

typedef struct _spContainerClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spContainerClassPart container;
} spContainerClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spContainerClassRec SpContainerClassRec;

#define SpContainerPart(comp) (((spContainer)comp)->container)
#define SpParentContainerPart(comp) (((spContainer)SpGetParent(comp))->container)
#define SpGetContainerClass(comp) ((spContainerClass)((comp)->object.object_class))

extern void spContainerPartInit(spObject object);
extern void spContainerPartFree(spObject object);
extern void spContainerCreate(spObject object);
extern void spContainerCreateArch(spComponent component);
extern void spContainerSetParams(spObject object);
extern void spContainerSetParamsArch(spComponent component);
extern void spContainerSetDefaultSize(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCONTAINERP_H */
