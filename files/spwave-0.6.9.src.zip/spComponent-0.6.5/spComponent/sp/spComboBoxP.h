/*
 *	spComboBoxP.h
 */

#ifndef __SPCOMBOBOXP_H
#define __SPCOMBOBOXP_H

#include <sp/spTextP.h>
#include <sp/spComboBox.h>
#if defined(GTK)
#include <sp/spComboBox_Gtk.h>
#elif defined(_WIN32)
#include <sp/spComboBox_Win.h>
#elif defined(MACOS)
#include <sp/spComboBox_Mac.h>
#elif defined(BEOS)
#include <sp/spComboBox_Be.h>
#else
#include <sp/spComboBox_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spComboBoxPart {
    spComboBoxArchPart arch_part;
    char **strings;
    int size;
} spComboBoxPart;

typedef struct _spComboBoxRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spTextPart text;
    spComboBoxPart combo_box;
} spComboBoxRec;
    
typedef struct _spComboBoxClassPart {
    int dummy;
} spComboBoxClassPart;

typedef struct _spComboBoxClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spTextClassPart text;
    spComboBoxClassPart combo_box;
} spComboBoxClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spComboBoxClassRec SpComboBoxClassRec;

extern void spComboBoxPartInit(spObject object);
extern void spComboBoxPartFree(spObject object);
extern void spComboBoxCreate(spObject object);
extern void spComboBoxCreateArch(spComponent component);
extern void spComboBoxSetParams(spObject object);
extern void spComboBoxSetParamsArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#define SpComboBoxPart(comp) (((spComboBox)comp)->combo_box)
#define SpComboBoxArch(comp) (((spComboBox)(comp))->combo_box.arch_part)
#define SpParentComboBoxPart(comp) (((spComboBox)SpGetParent(comp))->combo_box)
#define SpParentComboBoxArch(comp) (SpParentComboBoxPart(comp).arch_part)
#define SpGetComboBoxClass(comp) ((spComboBoxClass)((comp)->object.object_class))

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOXP_H */
