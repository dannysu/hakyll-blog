/*
 *	spTextP.h
 */

#ifndef __SPTEXTP_H
#define __SPTEXTP_H

#include <sp/spPrimitiveP.h>
#include <sp/spText.h>
#if defined(GTK)
#include <sp/spText_Gtk.h>
#elif defined(_WIN32)
#include <sp/spText_Win.h>
#elif defined(MACOS)
#include <sp/spText_Mac.h>
#elif defined(BEOS)
#include <sp/spText_Be.h>
#else
#include <sp/spText_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTextPart {
    spTextArchPart arch_part;

    char *string;
    spBool editable;
    char *font_name;
    int rows;
    int columns;
} spTextPart;

typedef struct _spTextRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spTextPart text;
} spTextRec;
    
typedef struct _spTextClassPart {
    spBool (*set_text_string) __P((spComponent component, char *string));
    char *(*get_text_string) __P((spComponent component));
} spTextClassPart;

typedef struct _spTextClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spTextClassPart text;
} spTextClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spTextClassRec SpTextClassRec;

#define SpTextPart(comp) (((spText)comp)->text)
#define SpTextArch(comp) (((spText)(comp))->text.arch_part)
#define SpParentTextPart(comp) (((spText)SpGetParent(comp))->text)
#define SpGetTextClass(comp) ((spTextClass)((comp)->object.object_class))

extern void spTextPartInit(spObject object);
extern void spTextPartInitArch(spComponent component);
extern void spTextPartFree(spObject object);
extern void spTextPartFreeArch(spComponent component);
extern void spTextCreate(spObject object);
extern void spTextCreateArch(spComponent component);
extern void spTextSetParams(spObject object);
extern void spTextSetParamsArch(spComponent component);
extern void spTextGetParams(spObject object);
extern void spSetTextStringArch(spComponent component);
extern void spGetTextStringArch(spComponent component);

extern spBool spSetTextSelectionArch(spComponent component, long start, long end);
extern spBool spGetTextSelectionArch(spComponent component, long *start, long *end);
extern spBool spSetTextPositionArch(spComponent component, long position);
extern spBool spGetTextPositionArch(spComponent component, long *position);

extern spBool spCopyTextArch(spComponent component);
extern spBool spCutTextArch(spComponent component);
extern spBool spClearTextArch(spComponent component);
extern spBool spPasteTextArch(spComponent component);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXTP_H */
