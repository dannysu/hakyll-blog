/*
 *	spPrimitive_Win.h
 */

#ifndef __SPPRIMITIVE_WIN_H
#define __SPPRIMITIVE_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

struct _spCallback {
    spComponent component;
    spCallbackFunc call_func;
    void *call_data;
    spBool propagate;
    
    long component_id;
    UINT message;
    UINT command_id;
};

typedef struct _spCallbackTable {
    spCallbackType call_type;
    spComponentType component_type;
    UINT message;
    UINT command_id;
} spCallbackTable;

typedef struct _spPrimitiveArchPart {
    HWND hwnd;
    HMENU hmenu;
    HDC hdc;
    HDC memdc;
    HBITMAP hbitmap;
    HCURSOR hcursor;
    UINT message;
    WPARAM wParam;
    LPARAM lParam;

    int num_accel;
    int num_accel_buffer;
    ACCEL *accels;
    HACCEL haccel;
    spBool realize_flag;
    HWND htooltip;
} spPrimitiveArchPart;
    
extern LRESULT CALLBACK spWindowFunc(HWND hwnd, UINT message,
				     WPARAM wParam, LPARAM lParam);
extern BOOL CALLBACK spDialogFunc(HWND hwnd, UINT message,
				  WPARAM wParam, LPARAM lParam);
extern int spTranslateAllAcceleratorWin(MSG *msg);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVE_WIN_H */
