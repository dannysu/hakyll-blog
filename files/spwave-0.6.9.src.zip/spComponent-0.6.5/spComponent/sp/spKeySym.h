/*
 *	spKeySym.h
 */

#ifndef __SPKEYSYM_H
#define __SPKEYSYM_H

#ifdef __cplusplus
extern "C" {
#endif

#define SPK_Unknown		0xFF00
#define SPK_Character		0x020
    
#define SPK_BackSpace		0xFF08
#define SPK_Tab			0xFF09
#define SPK_Linefeed		0xFF0A
#define SPK_Clear		0xFF0B
#define SPK_Return		0xFF0D
#define SPK_Pause		0xFF13
#define SPK_ScrollLock		0xFF14
/*#define SPK_SysReq		0xFF15*/
#define SPK_Escape		0xFF1B
#define SPK_Delete		0xFFFF

#define SPK_Shift		0xFFE1
#define SPK_Control		0xFFE3
#define SPK_CapsLock		0xFFE5
/*#define SPK_Shift_Lock	0xFFE6*/
/*#define SPK_Menu		0xFF67*/
#define SPK_Alt			0xFFE9

#define SPK_Home		0xFF50
#define SPK_Left		0xFF51
#define SPK_Up			0xFF52
#define SPK_Right		0xFF53
#define SPK_Down		0xFF54
#define SPK_Prior		0xFF55
/*#define SPK_PageUp		0xFF55*/
#define SPK_Next		0xFF56
/*#define SPK_PageDown		0xFF56*/
#define SPK_End			0xFF57
/*#define SPK_Begin		0xFF58*/
#define SPK_Select		0xFF60
#define SPK_Print		0xFF61
#define SPK_Execute		0xFF62
#define SPK_Insert		0xFF63
#define SPK_Cancel		0xFF69
#define SPK_Help		0xFF6A
#define SPK_NumLock		0xFF7F

#define SPK_F1			0xFFBE
#define SPK_F2			0xFFBF
#define SPK_F3			0xFFC0
#define SPK_F4			0xFFC1
#define SPK_F5			0xFFC2
#define SPK_F6			0xFFC3
#define SPK_F7			0xFFC4
#define SPK_F8			0xFFC5
#define SPK_F9			0xFFC6
#define SPK_F10			0xFFC7
#define SPK_F11			0xFFC8
#define SPK_F12			0xFFC9
#define SPK_F13			0xFFCA
#define SPK_F14			0xFFCB
#define SPK_F15			0xFFCC
#define SPK_F16			0xFFCD
#define SPK_F17			0xFFCE
#define SPK_F18			0xFFCF
#define SPK_F19			0xFFD0
#define SPK_F20			0xFFD1
#define SPK_F21			0xFFD2
#define SPK_F22			0xFFD3
#define SPK_F23			0xFFD4
#define SPK_F24			0xFFD5

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPKEYSYM_H */
