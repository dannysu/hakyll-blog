/*
 *	spText_Win.h
 */

#ifndef __SPTEXT_WIN_H
#define __SPTEXT_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTextArchPart {
    HFONT font;
} spTextArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTEXT_WIN_H */
