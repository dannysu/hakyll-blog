/*
 *	spToolBar_Mac.h
 */

#ifndef __SPTOOLBAR_MAC_H
#define __SPTOOLBAR_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spToolBarArchPart {
    int dummy;
} spToolBarArchPart;

extern void spDrawToolBarMac(spComponent component, spBool map_flag);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLBAR_MAC_H */
