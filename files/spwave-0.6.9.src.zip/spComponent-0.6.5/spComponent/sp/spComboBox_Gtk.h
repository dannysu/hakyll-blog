/*
 *	spComboBox_Gtk.h
 */

#ifndef __SPCOMBOBOX_GTK_H
#define __SPCOMBOBOX_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spComboBoxArchPart {
    int dummy;
} spComboBoxArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOX_GTK_H */
