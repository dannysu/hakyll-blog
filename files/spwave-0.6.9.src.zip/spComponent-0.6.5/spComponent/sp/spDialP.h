/*
 *	spDialP.h
 */

#ifndef __SPDIALP_H
#define __SPDIALP_H

#include <sp/spComponentP.h>
#include <sp/spDial.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_DIAL_TICK_LENGTH 4
#define SP_DIAL_INDICATOR_SIZE 10
#define SP_DIAL_INDICATOR_OFFSET 8
#define SP_DIAL_SHADOW_WIDTH 4
    
#define SP_DIAL_LINE_SHADOW_ANGLE 5

#define SP_DEFAULT_DIAL_WIDTH 60
#define SP_DEFAULT_DIAL_HEIGHT 60
    
typedef struct _spDialPart {
    spComponent canvas;
    int radius;
    int cx, cy;			/* center position */
    int angle;
    spBool button_down;

    spBool show_scale;
    int value;
    int minimum;
    int maximum;
    int minimum_angle;
    int maximum_angle;
    int increment;
    int shadow_width;
    int indicator_size;
    spDialIndicatorType indicator_type;
} spDialPart;

typedef struct _spDialRec {
    spObjectPart object;
    spComponentPart component;
    spDialPart dial;
} spDialRec;
    
typedef struct _spDialClassPart {
    int dummy;
} spDialClassPart;

typedef struct _spDialClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spDialClassPart dial;
} spDialClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spDialClassRec SpDialClassRec;

#define SpDialPart(comp) (((spDial)comp)->dial)
#define SpParentDialPart(comp) (((spDial)SpGetParent(comp))->dial)
#define SpGetDialClass(comp) ((spDialClass)((comp)->object.object_class))

extern void spDialPartInit(spObject object);
extern void spDialPartFree(spObject object);
extern void spDialCreate(spObject object);
extern void spDialDestroy(spObject object);
extern void spDialSetParams(spObject object);
extern void spDialGetParams(spObject object);
extern void spDialMap(spComponent component);
extern void spDialUnmap(spComponent component);
extern spBool spDialSetSize(spComponent component, int width, int height);
extern spBool spDialGetSize(spComponent component, int *width, int *height);
extern spBool spDialGetClientSize(spComponent component, int *width, int *height);
extern spBool spDialSetSensitive(spComponent component, spBool flag);
extern spBool spDialIsComponentType(spComponent component, char *class_name);
extern spBool spDialAddCallback(spComponent component, spBool propagate, spCallbackType call_type,
				spCallbackFunc call_func, void *call_data);
extern spBool spDialRemoveCallback(spComponent component, spCallbackType call_type,
				   spCallbackFunc call_func, void *call_data);
extern spCallbackReason spDialCallbackFunc(spComponent component);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALP_H */
