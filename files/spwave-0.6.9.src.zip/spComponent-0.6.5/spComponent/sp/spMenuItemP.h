/*
 *	spMenuItemP.h
 */

#ifndef __SPMENUITEMP_H
#define __SPMENUITEMP_H

#include <sp/spPrimitiveP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItem.h>
#if defined(GTK)
#include <sp/spMenuItem_Gtk.h>
#elif defined(_WIN32)
#include <sp/spMenuItem_Win.h>
#elif defined(MACOS)
#include <sp/spMenuItem_Mac.h>
#elif defined(BEOS)
#include <sp/spMenuItem_Be.h>
#else
#include <sp/spMenuItem_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spMenuItemPart {
    char *shortcut;
} spMenuItemPart;

typedef struct _spMenuItemRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spLabelPart label;
    spButtonPart button;
    spMenuItemPart menu_item;
} spMenuItemRec;

typedef struct _spMenuItemClassPart {
    int dummy;
} spMenuItemClassPart;

typedef struct _spMenuItemClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spLabelClassPart label;
    spButtonClassPart button;
    spMenuItemClassPart menu_item;
} spMenuItemClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spMenuItemClassRec SpMenuItemClassRec;

#define SpMenuItemPart(comp) (((spMenuItem)comp)->menu_item)
#define SpParentMenuItemPart(comp) (((spMenuItem)SpGetParent(comp))->menu_item)
#define SpGetMenuItemClass(comp) ((spMenuItemClass)((comp)->object.object_class))

extern void spMenuItemPartInit(spObject object);
extern void spMenuItemPartFree(spObject object);
extern void spMenuItemCreate(spObject object);
extern void spMenuItemCreateArch(spComponent component);
extern void spMenuItemSetParams(spObject object);
extern void spMenuItemSetParamsArch(spComponent component);
extern void spMenuSeparatorCreate(spComponent component);
extern void spMenuSeparatorCreateArch(spComponent component);
extern spBool spAddShortcutArch(spComponent component, char *shortcut);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUITEMP_H */
