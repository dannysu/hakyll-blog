/*
 *	spSlider.h
 */

#ifndef __SPSLIDER_H
#define __SPSLIDER_H

#include <sp/spPrimitive.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpSlider "Slider"
#define SpScrollBar "ScrollBar"
#define SpTrackBar "TrackBar"
#define SpUpDownButton "UpDownButton"
    
#define SppMinimum "iMinimum"	/* CSG */
#define SppMaximum "iMaximum"	/* CSG */
#define SppValue "iValue"	/* CSG */
#define SppIncrement "iIncrement" /* CSG */
#define SppPageIncrement "iPageIncrement" /* CSG */
#define SppPageSize "iPageSize"	/* CSG */
#define SppSliderSize "iPageSize" /* same as SppPageSize */
#define SppTrackCallbackOn "bTrackCallbackOn" /* CSG */
#define SppShowScale "bShowScale" /* C */
#define SppShowValue "bShowValue" /* C */
#define SppDecimalPoints "iDecimalPoints" /* C */
    
typedef struct _spSliderRec *spSlider;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpSliderClass;

extern spBool spIsSlider(spComponent component);
extern spComponent spCreateScrollBar(spComponent parent, char *name, ...);
extern spComponent spCreateSlider(spComponent parent, char *name, ...);
extern spComponent spCreateTrackBar(spComponent parent, char *name, ...);
extern spBool spSetSliderValue(spComponent component, int value);
extern spBool spGetSliderValue(spComponent component, int *value);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSLIDER_H */
