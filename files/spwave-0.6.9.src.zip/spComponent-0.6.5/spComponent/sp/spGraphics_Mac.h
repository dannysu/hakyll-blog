/*
 *	spGraphics_Mac.h
 */

#ifndef __SPGRAPHICS_MAC_H
#define __SPGRAPHICS_MAC_H

#include <sp/spPrimitiveP.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_CURSOR_HAND_ID 136
#define SP_CURSOR_MOVE_ID 133
#define SP_CURSOR_SIZE_ID 133
#define SP_CURSOR_NESW_RESIZE_ID 128
#define SP_CURSOR_NWSE_RESIZE_ID 129
#define SP_CURSOR_NS_RESIZE_ID 130
#define SP_CURSOR_WE_RESIZE_ID 131
    
#define SP_DEFAULT_FONT_ID applFont
#define SP_DEFAULT_FONT_STYLE normal
#define SP_DEFAULT_FONT_SIZE 14
    
    
#define SP_SYSTEM_COLOR_BACKGROUND_PIXEL spRGB(221,221,221)
#define SP_SYSTEM_COLOR_TOP_SHADOW_PIXEL spRGB(238,238,238)
#define SP_SYSTEM_COLOR_BOTTOM_SHADOW_PIXEL spRGB(170,170,170)
#define SP_SYSTEM_COLOR_HIGHLIGHT_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_DARK_SHADOW_PIXEL spRGB(119,119,119)
#define SP_SYSTEM_COLOR_BLACK_PIXEL 0L
#define SP_SYSTEM_COLOR_WHITE_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_FOCUS_PIXEL 0L
#define SP_SYSTEM_COLOR_TAB_BACKGROUND_PIXEL SP_SYSTEM_COLOR_BACKGROUND_PIXEL
    
typedef struct _spCursorArchPart {
    int dummy;
} spCursorArchPart;

typedef struct _spGraphicsArchPart {
    RGBColor fg_rgb;
    RGBColor bg_rgb;

    short mode;

    short font_id;		/* systemFont, applFont, ... */
    short font_style;		/* plain, bold, italic, ... */
    short font_size;
} spGraphicsArchPart;

#define spGetPixelMac(rgb) spRGB((rgb).red / 256, (rgb).green / 256, (rgb).blue / 256)

extern RGBColor spGetRGBMac(char *color_name);
extern CursHandle spGetCursorMac(spCursorType cursor_type);
extern void spFontNameToFontIdMac(char *font_name, short *pfont_id, short *pstyle, short *psize);
extern spBool spPixelToRGBColorMac(spPixel pixel, RGBColor *color);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPGRAPHICS_MAC_H */
