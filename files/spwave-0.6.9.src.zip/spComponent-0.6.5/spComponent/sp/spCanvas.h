/*
 *	spCanvas.h
 */

#ifndef __SPCANVAS_H
#define __SPCANVAS_H

#include <sp/spPrimitive.h>
#include <sp/spGraphics.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpCanvas "Canvas"
    
#define SppFocusable "bFocusable"	/* CG */
#define SppDrawBackground "bDrawBackground"	/* CG */
#define SppUseTabKey "bUseTabKey"	/* CG */
#define SppUseArrowKey "bUseArrowKey"	/* CG */

typedef struct _spCanvasRec *spCanvas;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpCanvasClass;
    
extern spBool spIsCanvas(spComponent component);
extern spComponent spCreateCanvas(spComponent parent, char *name,
				  int canvas_width, int canvas_height, ...);
extern void spRefreshCanvas(spComponent component);
extern void spRedrawCanvas(spComponent component);
extern spBool spSetCanvasCapture(spComponent component, spBool flag);
extern spBool spSetCanvasCursor(spComponent component, spCursor cursor);
extern spBool spUnsetCanvasCursor(spComponent component);
extern spBool spIsCanvasFocused(spComponent component);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCANVAS_H */
