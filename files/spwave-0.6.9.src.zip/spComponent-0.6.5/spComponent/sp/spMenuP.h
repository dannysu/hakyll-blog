/*
 *	spMenuP.h
 */

#ifndef __SPMENUP_H
#define __SPMENUP_H

#include <sp/spPrimitiveP.h>
#include <sp/spButtonP.h>
#include <sp/spMenu.h>
#if defined(GTK)
#include <sp/spMenu_Gtk.h>
#elif defined(_WIN32)
#include <sp/spMenu_Win.h>
#elif defined(MACOS)
#include <sp/spMenu_Mac.h>
#elif defined(BEOS)
#include <sp/spMenu_Be.h>
#else
#include <sp/spMenu_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_MENU_LABEL SP_MAX_BUTTON_LABEL

typedef struct _spMenuPart {
    spMouseButton popup_button;
    spBool tearoff_flag;
    spBool help_flag;
} spMenuPart;

typedef struct _spMenuRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spMenuPart menu;
} spMenuRec;

typedef struct _spMenuClassPart {
    int dummy;
} spMenuClassPart;

typedef struct _spMenuClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spMenuClassPart menu;
} spMenuClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spMenuClassRec SpMenuClassRec;

#define SpMenuPart(comp) (((spMenu)comp)->menu)
#define SpParentMenuPart(comp) (((spMenu)SpGetParent(comp))->menu)
#define SpGetMenuClass(comp) ((spMenuClass)((comp)->object.object_class))

extern void spMenuPartInit(spObject object);
extern void spMenuPartFree(spObject object);
extern void spMenuCreate(spObject object);
extern void spMenuSetParams(spObject object);
extern void spPulldownMenuCreate(spComponent component);
extern void spPulldownMenuCreateArch(spComponent component);
extern void spPulldownMenuSetParams(spComponent component);
extern void spPulldownMenuSetParamsArch(spComponent component);
extern void spPopupMenuCreate(spComponent component);
extern void spPopupMenuCreateArch(spComponent component);
extern void spPopupMenuSetParams(spComponent component);
extern void spPopupMenuSetParamsArch(spComponent component);
extern void spMenuBarCreate(spComponent component);
extern void spMenuBarCreateArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENUP_H */
