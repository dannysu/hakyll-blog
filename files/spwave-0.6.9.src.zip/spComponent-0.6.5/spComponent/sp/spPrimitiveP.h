/*
 *	spPrimitiveP.h
 */

#ifndef __SPPRIMITIVEP_H
#define __SPPRIMITIVEP_H

#include <sp/spComponentP.h>
#include <sp/spPrimitive.h>
#if defined(GTK)
#include <sp/spPrimitive_Gtk.h>
#elif defined(_WIN32)
#include <sp/spPrimitive_Win.h>
#elif defined(MACOS)
#include <sp/spPrimitive_Mac.h>
#elif defined(BEOS)
#include <sp/spPrimitive_Be.h>
#else
#include <sp/spPrimitive_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spPrimitivePart {
    /* private */
    spPrimitiveArchPart arch_part;	/* architecture dependent part */
    int index;				/* index used for some component */
    spCallbackFunc draw_func;		/* function pointer for drawable */
    void *draw_data;			/* data for drawable's callback */
    long num_callback;			/* number of callback functions */
    long num_callback_buffer;		/* size of callback buffer */
    spCallback *callbacks;		/* callback functions */
} spPrimitivePart;
    
typedef struct _spPrimitiveRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
} spPrimitiveRec;
    
typedef struct _spPrimitiveClassPart {
    int dummy;
} spPrimitiveClassPart;

typedef struct _spPrimitiveClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
} spPrimitiveClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spPrimitiveClassRec SpPrimitiveClassRec;

#define SpPrimitivePart(comp) (((spPrimitive)(comp))->primitive)
#define SpPrimitiveArch(comp) (((spPrimitive)(comp))->primitive.arch_part)
#define SpParentPrimitivePart(comp) (((spPrimitive)SpGetParent(comp))->primitive)
#define SpParentPrimitiveArch(comp) (SpParentPrimitivePart(comp).arch_part)
#define SpGetPrimitiveClass(comp) ((spPrimitiveClass)((comp)->object.object_class))

extern void spInitCallbackArch(spCallback *callback);
extern void spPrimitivePartInitArch(spComponent component);
extern void spPrimitiveDestroyArch(spComponent component);
extern void spPrimitiveMapArch(spComponent component);
extern void spPrimitiveUnmapArch(spComponent component);
extern spBool spPrimitiveSetSizeArch(spComponent component, int width, int height);
extern spBool spPrimitiveGetSizeArch(spComponent component, int *width, int *height);
extern spBool spPrimitiveGetClientSizeArch(spComponent component, int *width, int *height);
extern spBool spPrimitiveSetSensitiveArch(spComponent component, spBool flag);
extern spBool spPrimitiveAddCallbackArch(spComponent component, spBool propagate, spCallbackType call_type,
					 spCallbackFunc call_func, void *call_data);
extern spBool spPrimitiveRemoveCallbackArch(spComponent component, spCallbackType call_type,
					    spCallbackFunc call_func, void *call_data);
extern spCallbackReason spPrimitiveGetCallbackReasonArch(spComponent component);
extern spBool spPrimitiveGetCallbackMousePositionArch(spComponent component, int *x, int *y);
extern spBool spPrimitiveGetCallbackKeySymArch(spComponent component, spKeySym *key_sym);
extern int spPrimitiveGetCallbackKeyStringArch(spComponent component,
					       char *buf, int buf_size, spBool *overflow);

extern void spAllocCallbacks(spComponent component);
extern void spFreeCallbacks(spComponent component);
extern void spPrimitivePartInit(spObject object);
extern void spPrimitivePartFree(spObject object);
extern void spPrimitiveCreate(spObject object);
extern void spPrimitiveDestroy(spObject object);
extern void spPrimitiveMap(spComponent component);
extern void spPrimitiveUnmap(spComponent component);
extern spBool spPrimitiveSetSize(spComponent component, int width, int height);
extern spBool spPrimitiveGetSize(spComponent component, int *width, int *height);
extern spBool spPrimitiveGetClientSize(spComponent component, int *width, int *height);
extern spBool spPrimitiveSetSensitive(spComponent component, spBool flag);
extern spBool spPrimitiveAddCallback(spComponent component, spBool propagate, spCallbackType call_type,
				     spCallbackFunc call_func, void *call_data);
extern spBool spPrimitiveRemoveCallback(spComponent component, spCallbackType call_type,
					spCallbackFunc call_func, void *call_data);
extern spCallbackReason spPrimitiveCallbackFunc(spComponent component);
extern spBool spPrimitiveGetCallbackMousePosition(spComponent component, int *x, int *y);
extern spBool spPrimitiveGetCallbackKeySym(spComponent component, spKeySym *key_sym);
extern int spPrimitiveGetCallbackKeyString(spComponent component,
					   char *buf, int buf_size, spBool *overflow);
extern void spPrimitiveSetDefaultSize(spComponent component);
extern spBool spShowToolTipArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVEP_H */
