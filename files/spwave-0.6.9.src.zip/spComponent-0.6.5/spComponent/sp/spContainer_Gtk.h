/*
 *	spContainer_Gtk.h
 */

#ifndef __SPCONTAINER_GTK_H
#define __SPCONTAINER_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_CONTAINER_TITLE_OFFSET 5

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCONTAINER_GTK_H */
