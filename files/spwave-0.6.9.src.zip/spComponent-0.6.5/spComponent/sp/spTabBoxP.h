/*
 *	spTabBoxP.h
 */

#ifndef __SPTABBOXP_H
#define __SPTABBOXP_H

#include <sp/spPrimitiveP.h>
#include <sp/spTabBox.h>
#if defined(GTK)
#include <sp/spTabBox_Gtk.h>
#elif defined(_WIN32)
#include <sp/spTabBox_Win.h>
#elif defined(MACOS)
#include <sp/spTabBox_Mac.h>
#elif defined(BEOS)
#include <sp/spTabBox_Be.h>
#else
#include <sp/spTabBox_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spTabBoxPart {
    spTabBoxArchPart arch_part;
    int size;
    int selected_index;
    int num_item;
} spTabBoxPart;

typedef struct _spTabBoxRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spTabBoxPart tab_box;
} spTabBoxRec;
    
typedef struct _spTabBoxClassPart {
    int dummy;
} spTabBoxClassPart;

typedef struct _spTabBoxClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spTabBoxClassPart tab_box;
} spTabBoxClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spTabBoxClassRec SpTabBoxClassRec;

extern void spTabBoxPartInit(spObject object);
extern void spTabBoxPartInitArch(spComponent component);
extern void spTabBoxPartFree(spObject object);
extern void spTabBoxPartFreeArch(spComponent component);
extern void spTabBoxCreate(spObject object);
extern void spTabBoxCreateArch(spComponent component);
extern void spTabBoxSetParams(spObject object);
extern void spTabBoxSetParamsArch(spComponent component);
extern void spTabBoxDestroy(spObject object);
extern void spTabBoxDestroyArch(spComponent component);
extern void spTabBoxSetDefaultSize(spComponent component);
extern int spMapTabItem(spComponent component, int index);
extern int spGetSelectedTabIndexArch(spComponent component);
extern void spAddTabItemArch(spComponent component, int index);

#if defined(MACOS)
#pragma import off
#endif

#define SpTabBoxPart(comp) (((spTabBox)comp)->tab_box)
#define SpTabBoxArch(comp) (((spTabBox)comp)->tab_box.arch_part)
#define SpParentTabBoxPart(comp) (((spTabBox)SpGetParent(comp))->tab_box)
#define SpParentTabBoxArch(comp) (SpParentTabBoxPart(comp).arch_part)
#define SpGetTabBoxClass(comp) ((spTabBoxClass)((comp)->object.object_class))

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTABBOXP_H */
