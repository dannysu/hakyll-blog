/*
 *	spSlider_Gtk.h
 */

#ifndef __SPSLIDER_GTK_H
#define __SPSLIDER_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSLIDER_GTK_H */
