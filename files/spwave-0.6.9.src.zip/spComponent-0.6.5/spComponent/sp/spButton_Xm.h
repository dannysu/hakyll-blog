/*
 *	spButton_Xm.h
 */

#ifndef __SPBUTTON_XM_H
#define __SPBUTTON_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

#if XmVersion < 2000
typedef Bool XmSet;
#define XmSET True
#define XmUNSET False
#else
typedef unsigned char XmSet;
#endif
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPBUTTON_XM_H */
