/*
 *	spSliderP.h
 */

#ifndef __SPSLIDERP_H
#define __SPSLIDERP_H

#include <sp/spPrimitiveP.h>
#include <sp/spSlider.h>
#if defined(GTK)
#include <sp/spSlider_Gtk.h>
#elif defined(_WIN32)
#include <sp/spSlider_Win.h>
#elif defined(MACOS)
#include <sp/spSlider_Mac.h>
#elif defined(BEOS)
#include <sp/spSlider_Be.h>
#else
#include <sp/spSlider_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spSliderPart {
    spBool show_scale;
    spBool show_value;
    spBool track_call_on;
    int value;
    int minimum;
    int maximum;
    int page_size;
    int increment;
    int page_increment;
    int decimal_points;
    int scroll_coef;
} spSliderPart;

typedef struct _spSliderRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spSliderPart slider;
} spSliderRec;
    
typedef struct _spSliderClassPart {
    int dummy;
} spSliderClassPart;

typedef struct _spSliderClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spSliderClassPart slider;
} spSliderClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spSliderClassRec SpSliderClassRec;

#define SpSliderPart(comp) (((spSlider)comp)->slider)
#define SpParentSliderPart(comp) (((spSlider)SpGetParent(comp))->slider)
#define SpGetSliderClass(comp) ((spSliderClass)((comp)->object.object_class))

extern void spSliderPartInit(spObject object);
extern void spSliderPartFree(spObject object);
extern void spSliderCreate(spObject object);
extern void spSliderCreateArch(spComponent component);
extern void spSliderSetParams(spObject object);
extern void spSliderSetParamsArch(spComponent component);
extern void spSliderGetParams(spObject object);
extern void spTrackBarCreateArch(spComponent component);
extern void spTrackBarSetParamsArch(spComponent component);
extern void spSetSliderValueArch(spComponent component);
extern int spGetSliderValueArch(spComponent component);
extern void spSliderSetDefaultSize(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSLIDERP_H */
