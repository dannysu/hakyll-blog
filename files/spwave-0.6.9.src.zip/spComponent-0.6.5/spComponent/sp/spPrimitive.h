/*
 *	spPrimitive.h
 */

#ifndef __SPPRIMITIVE_H
#define __SPPRIMITIVE_H

#include <sp/spComponent.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpPrimitive "Primitive"
    
typedef struct _spPrimitiveRec *spPrimitive;
typedef struct _spPrimitiveClassRec *spPrimitiveClass;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpPrimitiveClass;
    
extern spBool spIsPrimitive(spComponent component);
extern spBool spShowToolTip(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPPRIMITIVE_H */
