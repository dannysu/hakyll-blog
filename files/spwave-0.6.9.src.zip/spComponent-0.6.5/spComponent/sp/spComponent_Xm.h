/*
 *	spComponent_Xm.h
 */

#ifndef __SPCOMPONENT_XM_H
#define __SPCOMPONENT_XM_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>

#include <sp/spComponentDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_SUPPORT_MNEMONIC
    
#if defined(LesstifVersion) && LesstifVersion < 87
#define LESSTIF_FRAME_BUG
#else
#undef LESSTIF_FRAME_BUG
#endif

#if XmVersion >= 1002
#define SP_USE_LOCALE_MOTIFIERS
#define SP_USE_TEAROFF_MENU
#else
#undef SP_USE_LOCALE_MOTIFIERS
#undef SP_USE_TEAROFF_MENU
#define XmFONTLIST_DEFAULT_TAG XmSTRING_DEFAULT_CHARSET
#endif
    
#define SP_DEFAULT_SPACING 10
#define SP_DEFAULT_MARGIN 10
#define SP_DEFAULT_DIALOG_MARGIN 5
#define SP_DEFAULT_DIALOG_BUTTON_MARGIN 10
#define SP_DEFAULT_DIALOG_BUTTON_SPACING 10
#define SP_DEFAULT_BUTTON_WIDTH 100
#define SP_DEFAULT_BUTTON_HEIGHT 30
#define SP_DEFAULT_LABEL_WIDTH 100
#define SP_DEFAULT_LABEL_HEIGHT 34
#define SP_DEFAULT_TEXT_WIDTH 120
#define SP_DEFAULT_TEXT_HEIGHT 34
#define SP_DEFAULT_TEXT_AREA_WIDTH 200
#define SP_DEFAULT_TEXT_AREA_HEIGHT 200
#define SP_DEFAULT_LIST_WIDTH 120
#define SP_DEFAULT_LIST_HEIGHT 120
#define SP_DEFAULT_SLIDER_LENGTH 200
#define SP_DEFAULT_SLIDER_WIDTH 15
#define SP_DEFAULT_TRACKBAR_LENGTH SP_DEFAULT_SLIDER_LENGTH
#define SP_DEFAULT_HORIZONTAL_TRACKBAR_WIDTH 40
#define SP_DEFAULT_VERTICAL_TRACKBAR_WIDTH 40
#define SP_DEFAULT_MENU_BAR_HEIGHT 30
#define SP_DEFAULT_TOOL_ITEM_MARGIN 2
#define SP_DEFAULT_TOOL_ITEM_SPACING 0
#define SP_DEFAULT_TOOL_SEPARATOR_WIDTH 5
#define SP_DEFAULT_STATUS_BAR_HEIGHT 30
#define SP_DEFAULT_TAB_HEIGHT 35
    
#define SP_CALLBACK_BUFFER 16

typedef struct _spArgTable {
    spParam param;
    String arg_name;
} spArgTable;

extern String spGetArgName(spParam param);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMPONENT_XM_H */
