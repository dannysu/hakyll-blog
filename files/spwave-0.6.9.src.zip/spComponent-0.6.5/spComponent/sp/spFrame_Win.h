/*
 *	spFrame_Win.h
 */

#ifndef __SPFRAME_WIN_H
#define __SPFRAME_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NIM_ADD

#define NIM_ADD         0x00000000
#define NIM_MODIFY      0x00000001
#define NIM_DELETE      0x00000002

#define NIF_MESSAGE     0x00000001
#define NIF_ICON        0x00000002
#define NIF_TIP         0x00000004

#define WINSHELLAPI

#ifndef UNICODE_ONLY
typedef struct _NOTIFYICONDATAA {
    DWORD cbSize;
    HWND hWnd;
    UINT uID;
    UINT uFlags;
    UINT uCallbackMessage;
    HICON hIcon;
    CHAR szTip[64];
} NOTIFYICONDATAA, *PNOTIFYICONDATAA;
WINSHELLAPI BOOL WINAPI Shell_NotifyIconA(DWORD dwMessage, PNOTIFYICONDATAA lpData);
#endif
#ifndef ANSI_ONLY
typedef struct _NOTIFYICONDATAW {
    DWORD cbSize;
    HWND hWnd;
    UINT uID;
    UINT uFlags;
    UINT uCallbackMessage;
    HICON hIcon;
    WCHAR szTip[64];
} NOTIFYICONDATAW, *PNOTIFYICONDATAW;
WINSHELLAPI BOOL WINAPI Shell_NotifyIconW(DWORD dwMessage, PNOTIFYICONDATAW lpData);
#endif
#ifdef UNICODE
typedef NOTIFYICONDATAW NOTIFYICONDATA;
typedef PNOTIFYICONDATAW PNOTIFYICONDATA;
#define Shell_NotifyIcon  Shell_NotifyIconW
#else
typedef NOTIFYICONDATAA NOTIFYICONDATA;
typedef PNOTIFYICONDATAA PNOTIFYICONDATA;
#define Shell_NotifyIcon  Shell_NotifyIconA
#endif

#endif	/* defined(__CYGWIN32__) */

#define WM_TASKTRAY (WM_APP+100)
    
typedef struct _spFrameArchPart {
    spBool task_tray_added;
    NOTIFYICONDATA nicon;
    HWND hfocus_text;
    spDropCallbackFunc drop_call_func;
    void *drop_call_data;
} spFrameArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPFRAME_WIN_H */
