/*
 *	spList_Gtk.h
 */

#ifndef __SPLIST_GTK_H
#define __SPLIST_GTK_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct _spListArchPart {
    int dummy;
} spListArchPart;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLIST_GTK_H */
