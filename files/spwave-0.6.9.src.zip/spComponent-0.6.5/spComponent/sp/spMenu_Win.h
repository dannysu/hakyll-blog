/*
 *	spMenu_Win.h
 */

#ifndef __SPMENU_WIN_H
#define __SPMENU_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TPM_TOPALIGN
#define TPM_TOPALIGN 0x0000L
#define TPM_VCENTERALIGN 0x0010L
#define TPM_BOTTOMALIGN 0x0020L
#endif

extern void spPopupMenuWinCB(spComponent component, spComponent menu);
    
#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPMENU_WIN_H */
