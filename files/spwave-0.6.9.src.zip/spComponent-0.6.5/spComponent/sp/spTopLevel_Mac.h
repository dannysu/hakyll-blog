/*
 *	spTopLevel_Mac.h
 */

#ifndef __SPTOPLEVEL_MAC_H
#define __SPTOPLEVEL_MAC_H

#if defined(MACOSX)
#include <Carbon/Carbon.h>
#else
#include <MacTypes.h>
#include <Menus.h>
#include <Quickdraw.h>
#include <QDOffscreen.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_DUMMY_GWORLD_WIDTH 5
#define SP_DUMMY_GWORLD_HEIGHT 5
    
typedef struct _spTopLevelArchPart {
    Handle menu_bar;
    MenuHandle apple_menu;
    MenuHandle file_menu;
    MenuHandle edit_menu;
    MenuHandle help_menu;
    MenuHandle window_menu;
    int num_help_menu;
} spTopLevelArchPart;

#if defined(MACOS)
#pragma import on
#endif

extern spBool spSetDummyGWorldMac(void);
extern long spGetSystemVersionMac(void);
extern long spGetAppearanceVersionMac(void);
extern long spGetCarbonVersionMac(void);
extern spBool spIsCarbonEventAvailableMac(void);
extern spBool spIsAquaMac(void);
extern int spGetPixelDepthMac(Boolean *is_color);
extern void spSetCursorMac(CursHandle cursor);
extern void spUnsetCursorMac(void);
extern spBool spIsInPThreadMac(void);
extern void spLockMainMutexMac(void);
extern void spUnlockMainMutexMac(void);
extern void spLockMainMutexForMainMac(void);
extern void spUnlockMainMutexForMainMac(void);
extern void spLockMainMutexForThreadMac(void);
extern void spUnlockMainMutexForThreadMac(void);
extern void spLockPortMutexMac(void);
extern void spUnlockPortMutexMac(void);
extern void spLockDrawMutexMac(void);
extern void spUnlockDrawMutexMac(void);
extern void spLockControlMutexMac(void);
extern void spUnlockControlMutexMac(void);
extern void spLockMenuMutexMac(void);
extern void spUnlockMenuMutexMac(void);
extern UInt32 spGetLastEventModifiersMac(void);
extern int spDispatchEventMac(spTopLevel toplevel, unsigned long sleep);
extern int spDispatchEventEffectiveMac(spTopLevel toplevel);
extern GrafPtr spThreadEnterMac(GrafPtr new_port);
extern GrafPtr spThreadLeaveMac(GrafPtr new_port);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOPLEVEL_MAC_H */
