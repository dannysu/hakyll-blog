/*
 *	spGraphicsP.h
 */

#ifndef __SPGRAPHICSP_H
#define __SPGRAPHICSP_H

#include <sp/spObjectP.h>
#include <sp/spGraphics.h>
#if defined(GTK)
#include <gdk/gdkx.h>
#include <sp/spGraphics_Gtk.h>
#elif defined(_WIN32)
#include <sp/spGraphics_Win.h>
#elif defined(MACOS)
#include <sp/spGraphics_Mac.h>
#elif defined(BEOS)
#include <sp/spGraphics_Be.h>
#else
#include <sp/spGraphics_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_SYSTEM_COLOR_BACKGROUND_ID "spBackgroundGraphics"    
#define SP_SYSTEM_COLOR_TOP_SHADOW_ID "spTopShadowGraphics"
#define SP_SYSTEM_COLOR_BOTTOM_SHADOW_ID "spBottomShadowGraphics"
#define SP_SYSTEM_COLOR_HIGHLIGHT_ID "spHighlightGraphics"
#define SP_SYSTEM_COLOR_DARK_SHADOW_ID "spDarkShadowGraphics"
#define SP_SYSTEM_COLOR_BLACK_ID "spBlackGraphics"
#define SP_SYSTEM_COLOR_WHITE_ID "spWhiteGraphics"
#define SP_SYSTEM_COLOR_FOCUS_ID "spFocusGraphics"
#define SP_SYSTEM_COLOR_TAB_BACKGROUND_ID "spTabBackgroundGraphics"
    
struct _spCursor {
    spCursorArchPart arch_part;
    spCursorType type;
    char *name;
};

typedef struct _spGraphicsPart {
    spGraphicsArchPart arch_part;
    spGraphics next_graphics;
    spGraphics prev_graphics;

    char *font_name;
    char *foreground;
    char *background;
    spPixel fg_pixel;
    spPixel bg_pixel;
    spLineType line_type;
    int line_width;
    spGraphicsMode mode;
} spGraphicsPart;

typedef struct _spGraphicsRec {
    spObjectPart object;
    spGraphicsPart graphics;
} spGraphicsRec;

typedef struct _spGraphicsClassPart {
    int dummy;
} spGraphicsClassPart;
    
typedef struct _spGraphicsClassRec {
    spObjectClassPart object;
    spGraphicsClassPart graphics;
} spGraphicsClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spGraphicsClassRec SpGraphicsClassRec;

#define SpGraphicsPart(obj) (((spGraphics)obj)->graphics)
#define SpGraphicsArch(obj) (((spGraphics)obj)->graphics.arch_part)
#define SpGetGraphicsClass(obj) ((spGraphicsClass)((obj)->object.object_class))
#define SpGetNextGraphics(obj) (((spGraphics)obj)->graphics.next_graphics)
#define SpGetPrevGraphics(obj) (((spGraphics)obj)->graphics.prev_graphics)

#define SpCursorArch(obj) (((spCursor)obj)->arch_part)

extern void spGraphicsPartInit(spObject object);
extern void spGraphicsPartInitArch(spGraphics graphics);
extern void spGraphicsPartFree(spObject object);
extern void spGraphicsPartFreeArch(spGraphics graphics);
extern void spGraphicsCreate(spObject object);
extern void spGraphicsCreateArch(spGraphics graphics);
extern void spSetGraphicsModeArch(spGraphics graphics, spGraphicsMode mode);
extern void spSetFontArch(spGraphics graphics);
extern spBool spGetCursorArch(spCursor cursor);
extern void spDestroyCursorArch(spCursor cursor);
extern spBool spGetSystemColorPixelNormal(spSystemColorType type, spPixel *pixel);
extern spBool spGetSystemColorPixelArch(spSystemColorType type, spPixel *pixel);
extern void spUpdateSystemGraphics(void);

extern spBool spSetForegroundPixelArch(spGraphics graphics);
extern spBool spSetBackgroundPixelArch(spGraphics graphics);

extern spPixel spGetColorPixelNormal(char *color_name);
extern spBool spGetColorNameNormal(spPixel pixel, char *color_name);

extern char **spGetFontFamilyListArch(void);
extern spBool spIsFontSizeSupportedArch(int family, unsigned long style, int size);

#if defined(GTK) || defined(XmVersion)
extern char **spGetFontFamilyListX11(Display *display);
extern spBool spIsFontSizeSupportedX11(Display *display, int family, unsigned long style, int size);
#endif
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPGRAPHICSP_H */
