/*
 *	spDialogP.h
 */

#ifndef __SPDIALOGP_H
#define __SPDIALOGP_H

#include <sp/spPrimitiveP.h>
#include <sp/spDialog.h>
#if defined(GTK)
#include <sp/spDialog_Gtk.h>
#elif defined(_WIN32)
#include <sp/spDialog_Win.h>
#elif defined(MACOS)
#include <sp/spDialog_Mac.h>
#elif defined(BEOS)
#include <sp/spDialog_Be.h>
#else
#include <sp/spDialog_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SP_FD_TYPE_UNKNOWN = -1,
    SP_FD_TYPE_OPEN = 0,
    SP_FD_TYPE_SAVE = 1,
    SP_FD_TYPE_DIR = 2,
} spFileDialogType;

typedef struct _spDialogPart {
    /* private */
    spDialogArchPart arch_part;		/* architecture dependent part */
    
    /* parameter */
    int dialog_type;
    int button_type;
    
    char **file_filters;
    char **file_types;
    int *filter_index;
    char *initial_dir;
    char *initial_file_name;
    spBool path_must_exist;
    spBool file_must_exist;
    spBool overwrite_prompt;

    char *initial_font;
    char *initial_color;
    
    spComponent parent_window;
} spDialogPart;

typedef struct _spDialogRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spDialogPart dialog;
} spDialogRec;
    
typedef struct _spDialogClassPart {
    int dummy;
} spDialogClassPart;

typedef struct _spDialogClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spDialogClassPart dialog;
} spDialogClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spDialogClassRec SpDialogClassRec;

#define SpDialogPart(comp) (((spDialog)comp)->dialog)
#define SpDialogArch(comp) (((spDialog)comp)->dialog.arch_part)
#define SpParentDialogPart(comp) (((spDialog)SpGetParent(comp))->dialog)
#define SpGetDialogClass(comp) ((spDialogClass)((comp)->object.object_class))

extern void spDialogPartInit(spObject object);
extern void spDialogPartInitArch(spComponent component);
extern void spDialogPartFree(spObject object);
    
extern char *spGetMessageBoxTitle(spComponent component);
    
extern spDialogResponse spPopupMessageBox(spComponent component, char *message);
extern spBool spAddCurrentFilterSuffix(spComponent component, int filter_index, char *buf);
extern char *xspPopupFileSelectionBoxArg(spComponent parent, char *name,
					 spFileDialogType dialog_type,
					 spArg *args, int num_arg);
extern char *xspChooseFontArch(spComponent component);
extern char *xspChooseColorArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALOGP_H */
