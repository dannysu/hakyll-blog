/*
 *	spToolBarP.h
 */

#ifndef __SPTOOLBARP_H
#define __SPTOOLBARP_H

#include <sp/spPrimitiveP.h>
#include <sp/spToolBar.h>
#if defined(GTK)
#include <sp/spToolBar_Gtk.h>
#elif defined(_WIN32)
#include <sp/spToolBar_Win.h>
#elif defined(MACOS)
#include <sp/spToolBar_Mac.h>
#elif defined(BEOS)
#include <sp/spToolBar_Be.h>
#else
#include <sp/spToolBar_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_TOOL_ITEM 16
    
typedef struct _spToolBarPart {
    spToolBarArchPart arch_part;
    int current_index;
    
    int num_bitmap;
    int bitmap_width;
    int bitmap_height;
    char *bitmap_path_env;
    char **bitmap_data;
} spToolBarPart;

typedef struct _spToolBarRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spToolBarPart tool_bar;
} spToolBarRec;
    
typedef struct _spToolBarClassPart {
    int dummy;
} spToolBarClassPart;

typedef struct _spToolBarClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spToolBarClassPart tool_bar;
} spToolBarClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spToolBarClassRec SpToolBarClassRec;

extern void spToolBarPartInit(spObject object);
extern void spToolBarPartInitArch(spComponent component);
extern void spToolBarPartFree(spObject object);
extern void spToolBarPartFreeArch(spComponent component);
extern void spToolBarCreate(spObject object);
extern void spToolBarCreateArch(spComponent component);
extern void spToolBarSetParams(spObject object);
extern void spToolBarSetParamsArch(spComponent component);
extern void spToolBarDestroy(spObject object);
extern void spToolBarDestroyArch(spComponent component);

#if defined(MACOS)
#pragma import off
#endif

#define SpToolBarPart(comp) (((spToolBar)comp)->tool_bar)
#define SpToolBarArch(comp) (((spToolBar)comp)->tool_bar.arch_part)
#define SpParentToolBarPart(comp) (((spToolBar)SpGetParent(comp))->tool_bar)
#define SpParentToolBarArch(comp) (SpParentToolBarPart(comp).arch_part)
#define SpGetToolBarClass(comp) ((spToolBarClass)((comp)->object.object_class))

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPTOOLBARP_H */
