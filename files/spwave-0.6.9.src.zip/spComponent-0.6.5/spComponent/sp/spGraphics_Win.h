/*
 *	spGraphics_Win.h
 */

#ifndef __SPGRAPHICS_WIN_H
#define __SPGRAPHICS_WIN_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_SYSTEM_COLOR_BACKGROUND_PIXEL spRGB(192,192,192)
#define SP_SYSTEM_COLOR_TOP_SHADOW_PIXEL spRGB(231,231,231)
#define SP_SYSTEM_COLOR_BOTTOM_SHADOW_PIXEL spRGB(105,105,105)
#define SP_SYSTEM_COLOR_HIGHLIGHT_PIXEL spRGB(231,231,231)
#define SP_SYSTEM_COLOR_DARK_SHADOW_PIXEL 0L
#define SP_SYSTEM_COLOR_BLACK_PIXEL 0L
#define SP_SYSTEM_COLOR_WHITE_PIXEL spRGB(255,255,255)
#define SP_SYSTEM_COLOR_FOCUS_PIXEL 0L
#define SP_SYSTEM_COLOR_TAB_BACKGROUND_PIXEL SP_SYSTEM_COLOR_BACKGROUND_PIXEL
    
typedef enum {
    SP_GRAPHICS_NONE = -1,
    SP_GRAPHICS_PEN,
    SP_GRAPHICS_BRUSH,
    SP_GRAPHICS_SOLID_BRUSH,
    SP_GRAPHICS_PATTERN_BRUSH,
    SP_GRAPHICS_HATCH_BRUSH,
} spGraphicsType;

typedef struct _spCursorArchPart {
    HCURSOR hcursor;
} spCursorArchPart;

typedef struct _spGraphicsArchPart {
    HFONT font;
    HDC hdc;
    HPEN pen;
    HBRUSH brush;
    HBRUSH bg_brush;
    int mode;
} spGraphicsArchPart;

extern void spLOGFONTToFontName(LOGFONT *lf, char *font_name);
extern void spFontNameToLOGFONT(char *font_name, LOGFONT *lf);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPGRAPHICS_WIN_H */
