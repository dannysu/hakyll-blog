/*
 *	spStatusBarP.h
 */

#ifndef __SPSTATUSBARP_H
#define __SPSTATUSBARP_H

#include <sp/spPrimitiveP.h>
#include <sp/spStatusBar.h>
#if defined(GTK)
#include <sp/spStatusBar_Gtk.h>
#elif defined(_WIN32)
#include <sp/spStatusBar_Win.h>
#elif defined(MACOS)
#include <sp/spStatusBar_Mac.h>
#elif defined(BEOS)
#include <sp/spStatusBar_Be.h>
#else
#include <sp/spStatusBar_Xm.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SP_MAX_STATUS_ITEM 16
    
typedef struct _spStatusBarPart {
    spStatusBarArchPart arch_part;
    int num_item;

    spBool use_last_item;
    int *item_sizes;
    int default_item_index;
    int help_item_index;
} spStatusBarPart;

typedef struct _spStatusBarRec {
    spObjectPart object;
    spComponentPart component;
    spPrimitivePart primitive;
    spStatusBarPart status_bar;
} spStatusBarRec;
    
typedef struct _spStatusBarClassPart {
    int dummy;
} spStatusBarClassPart;

typedef struct _spStatusBarClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spPrimitiveClassPart primitive;
    spStatusBarClassPart status_bar;
} spStatusBarClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spStatusBarClassRec SpStatusBarClassRec;

extern void spStatusBarPartInit(spObject object);
extern void spStatusBarPartInitArch(spComponent component);
extern void spStatusBarPartFree(spObject object);
extern void spStatusBarPartFreeArch(spComponent component);
extern void spStatusBarCreate(spObject object);
extern void spStatusBarCreateArch(spComponent component, int *num_item);
extern void spStatusBarSetParams(spObject object);
extern void spStatusBarSetParamsArch(spComponent component);
extern void spStatusBarDestroy(spObject object);
extern void spStatusBarDestroyArch(spComponent component);
extern spBool spSetStatusTextArch(spComponent component, int index, char *string);
extern int spGetStatusItemSize(spComponent component, int index);

#if defined(MACOS)
#pragma import off
#endif

#define SpStatusBarPart(comp) (((spStatusBar)comp)->status_bar)
#define SpStatusBarArch(comp) (((spStatusBar)comp)->status_bar.arch_part)
#define SpParentStatusBarPart(comp) (((spStatusBar)SpGetParent(comp))->status_bar)
#define SpParentStatusBarArch(comp) (SpParentStatusBarPart(comp).arch_part)
#define SpGetStatusBarClass(comp) ((spStatusBarClass)((comp)->object.object_class))

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPSTATUSBARP_H */
