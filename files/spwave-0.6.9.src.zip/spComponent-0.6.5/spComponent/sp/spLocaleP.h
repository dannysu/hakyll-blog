/*
 *	spLocaleP.h
 */

#ifndef __SPLOCALEP_H
#define __SPLOCALEP_H

#include <sp/spObjectP.h>
#include <sp/spLocale.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void spSetLanguageArch(char *lang, char *o_lang);
extern void spInitStringTable(void);
extern void spFreeStringTable(void);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPLOCALEP_H */

