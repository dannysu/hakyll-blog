/*
 *	spDialogBoxP.h
 */

#ifndef __SPDIALOGBOXP_H
#define __SPDIALOGBOXP_H

#include <sp/spComponentP.h>
#include <sp/spDialogBox.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#define SP_DIALOG_OK_BUTTON_ORDER 2
#define SP_DIALOG_CANCEL_BUTTON_ORDER 1
#define SP_DIALOG_APPLY_BUTTON_ORDER 0
#else
#define SP_DIALOG_OK_BUTTON_ORDER 0
#define SP_DIALOG_CANCEL_BUTTON_ORDER 1
#define SP_DIALOG_APPLY_BUTTON_ORDER 2
#endif

#define SP_DIALOG_BUTTON_RIGHT_ALIGN 1
    
typedef struct _spDialogBoxPart {
    /* private */
    spComponent window;
    spComponent box;
    spComponent separator;
    spComponent button_box;
    spComponent ok_button;
    spComponent cancel_button;
    spComponent apply_button;
    
    /* parameters */
    spPopupStyle popup_style;			/* window popup style */
    spCloseStyle close_style;			/* window close style */
    int button_type;
    spBool resize_flag;
    spBool iconfy_flag;
    spBool simplify_flag;
    spComponent parent_window;
} spDialogBoxPart;

typedef struct _spDialogBoxRec {
    spObjectPart object;
    spComponentPart component;
    spDialogBoxPart dialog_box;
} spDialogBoxRec;
    
typedef struct _spDialogBoxClassPart {
    int dummy;
} spDialogBoxClassPart;

typedef struct _spDialogBoxClassRec {
    spObjectClassPart object;
    spComponentClassPart component;
    spDialogBoxClassPart dialog_box;
} spDialogBoxClassRec;

#if defined(MACOS)
#pragma import on
#endif

extern spDialogBoxClassRec SpDialogBoxClassRec;

#define SpDialogBoxPart(comp) (((spDialogBox)comp)->dialog_box)
#define SpParentDialogBoxPart(comp) (((spDialogBox)SpGetParent(comp))->dialog_box)
#define SpGetDialogBoxClass(comp) ((spDialogBoxClass)((comp)->object.object_class))

extern void spDialogBoxPartInit(spObject object);
extern void spDialogBoxPartFree(spObject object);
extern void spDialogBoxCreate(spObject object);
extern void spDialogBoxDestroy(spObject object);
extern void spDialogBoxSetParams(spObject object);
extern void spDialogBoxMap(spComponent component);
extern void spDialogBoxUnmap(spComponent component);
extern spBool spDialogBoxSetSize(spComponent component, int width, int height);
extern spBool spDialogBoxGetSize(spComponent component, int *width, int *height);
extern spBool spDialogBoxGetClientSize(spComponent component, int *width, int *height);
extern spBool spDialogBoxSetSensitive(spComponent component, spBool flag);
extern spBool spDialogBoxIsComponentType(spComponent component, char *class_name);

extern char *xspChooseFontDefault(spComponent component);
extern char *xspChooseColorDefault(spComponent component);
    
#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDIALOGBOXP_H */
