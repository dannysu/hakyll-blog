/*
 *	spDraw_Mac.h
 */

#ifndef __SPDRAW_MAC_H
#define __SPDRAW_MAC_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern PixMapHandle spGetLockedPixmapMac(spComponent component);
extern void spUnlockPixmapMac(spComponent component, PixMapHandle pixmap);
extern void spGetOriginalRGBMac(void);
extern void spSetOriginalRGBMac(void);
extern void spSetNormalRGBMac(void);
extern void spSetBackgroundRGBMac(void);
extern void spSetDeactivateRGBMac(void);
extern void spSetFontIdMac(short font_id, int style, int size);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPDRAW_MAC_H */
