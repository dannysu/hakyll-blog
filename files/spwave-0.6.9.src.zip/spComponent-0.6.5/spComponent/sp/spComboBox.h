/*
 *	spComboBox.h
 */

#ifndef __SPCOMBOBOX_H
#define __SPCOMBOBOX_H

#include <sp/spText.h>
#include <sp/spList.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SpComboBox "ComboBox"
    
typedef struct _spComboBoxRec *spComboBox;

#if defined(MACOS)
#pragma import on
#endif

extern spComponentClass SpComboBoxClass;
    
extern spBool spIsComboBox(spComponent component);
extern spComponent spCreateComboBox(spComponent parent, char *name, ...);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SPCOMBOBOX_H */
