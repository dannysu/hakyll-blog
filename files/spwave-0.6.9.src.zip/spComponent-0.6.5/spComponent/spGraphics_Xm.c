/*
 *	spGraphics_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/cursorfont.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDraw.h>

#include <sp/spTopLevelP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

Pixel spGetColorPixelXm(char *color_name)
{
    Pixel pixel;
    XColor color, exact;

    if (strcaseeq(color_name, "max")) {
	Pixel white, black;
	black = BlackPixelOfScreen(SpTopLevelArch(sp_toplevel).screen);
	white = WhitePixelOfScreen(SpTopLevelArch(sp_toplevel).screen);
	pixel = MAX(black, white);
    } else if (strcaseeq(color_name, "min")) {
	pixel = 0L;
    } else {
	XAllocNamedColor(SpTopLevelArch(sp_toplevel).display,
			 SpTopLevelArch(sp_toplevel).colormap,
			 color_name, &color, &exact);
#if 0
	pixel = exact.pixel;
#else
	pixel = color.pixel;
#endif
    }

    return pixel;
}

spPixel spGetColorPixel(char *color_name)
{
    XColor color;

    if (strnone(color_name)) return 0L;
    
    color.pixel = spGetColorPixelXm(color_name);
    
    XQueryColor(SpTopLevelArch(sp_toplevel).display,
		SpTopLevelArch(sp_toplevel).colormap,
		&color);

    return spRGB(color.red/256, color.green/256, color.blue/256);
}

spBool spGetCursorArch(spCursor cursor)
{
    unsigned int shape;
    spCursorType cursor_type = cursor->type;
    
    switch (cursor_type) {
      case SP_CURSOR_TEXT:
	shape = XC_xterm;
	break;
      case SP_CURSOR_WAIT:
	shape = XC_watch;
	break;
      case SP_CURSOR_CROSS:
	shape = XC_crosshair;
	break;
      case SP_CURSOR_HAND:
	shape = XC_hand2;
	break;
      case SP_CURSOR_MOVE:
	shape = XC_fleur;
	break;
      case SP_CURSOR_SIZE:
	shape = XC_sizing;
	break;
      case SP_CURSOR_SW_RESIZE:
	shape = XC_top_left_corner;
	break;
      case SP_CURSOR_SE_RESIZE:
	shape = XC_top_right_corner;
	break;
      case SP_CURSOR_NW_RESIZE:
	shape = XC_bottom_left_corner;
	break;
      case SP_CURSOR_NE_RESIZE:
	shape = XC_bottom_right_corner;
	break;
      case SP_CURSOR_N_RESIZE:
	shape = XC_top_side;
	break;
      case SP_CURSOR_S_RESIZE:
	shape = XC_bottom_side;
	break;
      case SP_CURSOR_W_RESIZE:
	shape = XC_left_side;
	break;
      case SP_CURSOR_E_RESIZE:
	shape = XC_right_side;
	break;
      default:
	shape = XC_top_left_arrow;
	break;
    }

    if ((SpCursorArch(cursor).cursor = XCreateFontCursor(SpTopLevelArch(sp_toplevel).display,
							 shape)) == None) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spSetCursorXm(Widget widget, spCursor cursor)
{
    XDefineCursor(SpTopLevelArch(sp_toplevel).display,
		  XtWindow(widget), SpCursorArch(cursor).cursor);
    XFlush(SpTopLevelArch(sp_toplevel).display);
    
    return SP_TRUE;
}

spBool spUnsetCursorXm(Widget widget)
{
    XUndefineCursor(SpTopLevelArch(sp_toplevel).display, XtWindow(widget));
    XFlush(SpTopLevelArch(sp_toplevel).display);
    
    return SP_TRUE;
}

void spDestroyCursorArch(spCursor cursor)
{
    XFreeCursor(SpTopLevelArch(sp_toplevel).display, SpCursorArch(cursor).cursor);
    return;
}

void spSetGraphicsModeArch(spGraphics graphics, spGraphicsMode mode)
{
    int function = GXcopy;

    if (graphics == NULL) return;
    
    switch (mode) {
      case SP_GM_COPY:
	function = GXcopy;
	break;
      case SP_GM_XOR:
	function = GXxor;
	break;
      case SP_GM_INVERT:
	function = GXinvert;
	break;
      case SP_GM_AND:
	function = GXand;
	break;
      case SP_GM_OR:
	function = GXor;
	break;
      default:
	break;
    }

    XSetFunction(SpTopLevelArch(sp_toplevel).display,
		 SpGraphicsArch(graphics).gc, function);
    
    return;
}

void spGraphicsPartInitArch(spGraphics graphics)
{
    SpGraphicsArch(graphics).font_set = NULL;
    
    SpGraphicsArch(graphics).gc =
	XCreateGC(SpTopLevelArch(sp_toplevel).display,
		  RootWindowOfScreen(SpTopLevelArch(sp_toplevel).screen),
		  0, NULL);

    return;
}

void spGraphicsPartFreeArch(spGraphics graphics)
{
    if (SpGraphicsArch(graphics).font_set != NULL) {
	XFreeFontSet(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).font_set);
    }
    XFreeGC(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).gc);

    return;
}

static int getLineType(spGraphics graphics, char **dash_list, int *ndash)
{
    int n = 0;
    int style = LineSolid;
    char *list = NULL;
    static char dash_line[] = {9, 3};
    static char dot_line[] = {2, 4};
    static char dash_dot_line[] = {9, 3, 2, 3};
    static char dash_dot_dot_line[] = {9, 3, 2, 3, 2, 3};

    if (graphics == NULL) return style;

    switch (SpGraphicsPart(graphics).line_type) {
      case SP_LINE_DASH:
	style = LineOnOffDash;
	list = dash_line;
	n = 2;
	break;
      case SP_LINE_DOT:
	style = LineOnOffDash;
	list = dot_line;
	n = 2;
	break;
      case SP_LINE_DASH_DOT:
	style = LineOnOffDash;
	list = dash_dot_line;
	n = 4;
	break;
      case SP_LINE_DASH_DOT_DOT:
	style = LineOnOffDash;
	list = dash_dot_dot_line;
	n = 6;
	break;
      default:
	style = LineSolid;
	list = NULL;
	n = 0;
	break;
    }

    if (dash_list != NULL) *dash_list = list;
    if (ndash != NULL) *ndash = n;

    return style;
}

void spGraphicsCreateArch(spGraphics graphics)
{
    int line_style;
    int ndash;
    char *dash_list = NULL;

    line_style = getLineType(graphics, &dash_list, &ndash);
    
    XSetLineAttributes(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).gc,
		       SpGraphicsPart(graphics).line_width, line_style, CapButt, JoinMiter);
    
    if (line_style != LineSolid && dash_list != NULL) {
	XSetDashes(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).gc,
		   0, dash_list, ndash);
    }

    spSetGraphicsModeArch(graphics, SpGraphicsPart(graphics).mode);
    
    spSetForegroundPixelArch(graphics);
    spSetBackgroundPixelArch(graphics);
    
    return;
}

void spSetFontArch(spGraphics graphics)
{
    char **miss, *def;
    int n_miss;
    
    if (SpGraphicsArch(graphics).font_set != NULL) {
	XFreeFontSet(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).font_set);
    }

    if (!strnone(SpGraphicsPart(graphics).font_name)) {
	SpGraphicsArch(graphics).font_set =
	    XCreateFontSet(SpTopLevelArch(sp_toplevel).display,
			   SpGraphicsPart(graphics).font_name,
			   &miss, &n_miss, &def);
    } else {
	SpGraphicsArch(graphics).font_set =
	    XCreateFontSet(SpTopLevelArch(sp_toplevel).display,
			   "-*-fixed-medium-r-normal--14-*",
			   &miss, &n_miss, &def);
    }
    if (SpGraphicsArch(graphics).font_set == NULL) {
	SpGraphicsArch(graphics).font_set =
	    XCreateFontSet(SpTopLevelArch(sp_toplevel).display,
			   "-*-*-*-*-*--*-*",
			   &miss, &n_miss, &def);
    }
    
    return;
}

spBool spGetSystemColorPixelArch(spSystemColorType type, spPixel *pixel)
{
    return spGetSystemColorPixelNormal(type, pixel);
}

static spBool spPixelToXColor(spPixel pixel, XColor *color)
{
    color->red = 256 * (unsigned short)spGetRValue(pixel);
    color->green = 256 * (unsigned short)spGetGValue(pixel);
    color->blue = 256 * (unsigned short)spGetBValue(pixel);
    color->flags = DoRed|DoGreen|DoBlue;
    if (!XAllocColor(SpTopLevelArch(sp_toplevel).display, SpTopLevelArch(sp_toplevel).colormap, color)) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spSetForegroundPixelArch(spGraphics graphics)
{
    XColor color;
    
    if (spPixelToXColor(SpGraphicsPart(graphics).fg_pixel, &color) == SP_TRUE) {
	XSetForeground(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).gc,
		       color.pixel);
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spSetBackgroundPixelArch(spGraphics graphics)
{
    XColor color;
    
    if (spPixelToXColor(SpGraphicsPart(graphics).bg_pixel, &color) == SP_TRUE) {
	XSetBackground(SpTopLevelArch(sp_toplevel).display, SpGraphicsArch(graphics).gc,
		       color.pixel);
	return SP_TRUE;
    }

    return SP_FALSE;
}

char **spGetFontFamilyListArch(void)
{
    return spGetFontFamilyListX11(SpTopLevelArch(sp_toplevel).display);
}

spBool spIsFontSizeSupportedArch(int family, unsigned long style, int size)
{
    return spIsFontSizeSupportedX11(SpTopLevelArch(sp_toplevel).display, family, style, size);
}
