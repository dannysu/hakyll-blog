/*
 *	spList.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spComboBox.h>

#include <sp/spListP.h>

static spParamTable sp_list_param_tables[] = {
    {SppListStrings, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spList, list.strings), NULL},
    {SppSelectedListIndex, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spList, primitive.index), "-1"},
};

spListClassRec SpListClassRec = {
    /* spObjectClassPart */
    {
	SpList,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spListRec),
	spArraySize(sp_list_param_tables),
	sp_list_param_tables,
	spListPartInit,
	spListPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spListCreate,
	NULL,
	spListSetParams,
	spListGetParams,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spListClassPart */
    {
	0,
    },
};

spComponentClass SpListClass = (spComponentClass)&SpListClassRec;

void spListPartInit(spObject object)
{
    spComponent component = (spComponent)object;

    SpComponentPart(component).spacing_flag = SP_TRUE;

    return;
}

void spListPartFree(spObject object)
{
    return;
}

void spListCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spPrimitiveSetDefaultSize(component);
    spListCreateArch(component);
    
    spShowToolTip(component);
    
    if (SpListPart(component).strings != NULL) {
	int i;
	
	for (i = 0;; i++) {
	    if (SpListPart(component).strings[i] == NULL) {
		break;
	    }
	    
	    spAddListItem(component, SpListPart(component).strings[i]);
	}

	spDebug(100, "spListCreate", "add strings done: i = %d\n", i);
	    
	if (SpPrimitivePart(component).index >= 0) {
	    spSelectListIndex(component, SpPrimitivePart(component).index);
	}
    }
	
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_ACTIVATE_CALLBACK | SP_VALUE_CHANGED_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    
    return;
}

void spListSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spListSetParamsArch(component);
	
    return;
}

void spListGetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spListGetParamsArch(component);
	
    return;
}

int spAddListItem(spComponent component, char *item)
{
#if 1
    if (item == NULL) return -1;
    
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE || item == NULL) return -1;
#endif

    spDebug(80, "spAddListItem", "item = %s\n", item);
    
    return spAddListItemArch(component, item);
}

int spAddListIndex(spComponent component, char *item, int index)
{
#if 1
    if (item == NULL || index < 0) return -1;

    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE || item == NULL || index < 0) return -1;
#endif
    
    return spAddListIndexArch(component, item, index);
}

int spDeleteListItem(spComponent component, char *item)
{
#if 1
    if (item == NULL) return -1;
    
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE || item == NULL) return -1;
#endif

    return spDeleteListItemArch(component, item);
}

int spDeleteListIndex(spComponent component, int index)
{
#if 1
    if (index < 0) return -1;
    
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE	|| index < 0) return -1;
#endif
    
    return spDeleteListIndexArch(component, index);
}

#if 1
int spFindListItem(spComponent component, char *item)
{
#if 1
    if (item == NULL) return -1;
    
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE || item == NULL) return -1;
#endif

    return spFindListItemArch(component, item);
}
#endif

int spSelectListItem(spComponent component, char *item)
{
#if 1
    if (item == NULL) return -1;

    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE || item == NULL) return -1;
#endif

    return spSelectListItemArch(component, item);
}

int spSelectListIndex(spComponent component, int index)
{
#if 1
    if (index < 0) return -1;

    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE	|| index < 0) return -1;
#endif

    return spSelectListIndexArch(component, index);
}

char *xspGetSelectedListItem(spComponent component)
{
#if 1
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return NULL;
	}
    }
#else
    if (spIsList(component) == SP_FALSE) return NULL;
#endif

    return xspGetSelectedListItemArch(component);
}

int spGetSelectedListIndex(spComponent component)
{
#if 1
    if (spIsList(component) == SP_FALSE) {
	if (spIsList(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return -1;
	}
    }
#else
    if (spIsList(component) == SP_FALSE) return NULL;
#endif

    SpPrimitivePart(component).index = spGetSelectedListIndexArch(component);
    
    return SpPrimitivePart(component).index;
}

spBool spIsList(spComponent component)
{
    if (spIsSubClass(component, SpList) == SP_TRUE
	|| spIsSubClass(component, SpComboBox) == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spComponent spCreateList(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpListClass, NULL, name, parent, args, num_arg);
}
