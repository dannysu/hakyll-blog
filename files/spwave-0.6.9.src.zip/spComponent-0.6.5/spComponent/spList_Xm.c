/*
 *	spList_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/MenuShell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/BulletinB.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/DrawnB.h>
#include <Xm/ArrowB.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/List.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spText.h>
#include <sp/spComboBox.h>

#include <sp/spListP.h>

#define SP_XMSTRING_BUFFER 4

extern spTopLevel sp_toplevel;

/*
 *	allocate XmString buffer
 */
static void reallocXmStrings(spComponent component)
{
    int i;
    
    if (component == NULL ||
	SpPrimitiveArch(component).num_xmstring < SpPrimitiveArch(component).num_xmstring_buffer) return;

    if (SpPrimitiveArch(component).xmstrings == NULL) {
	SpPrimitiveArch(component).num_xmstring_buffer = SP_XMSTRING_BUFFER;
	SpPrimitiveArch(component).xmstrings =
	    xalloc(SpPrimitiveArch(component).num_xmstring_buffer, XmString);
	SpPrimitiveArch(component).num_xmstring = 0;
    } else {
	SpPrimitiveArch(component).num_xmstring_buffer += SP_XMSTRING_BUFFER;
	SpPrimitiveArch(component).xmstrings =
	    xrealloc(SpPrimitiveArch(component).xmstrings,
		     SpPrimitiveArch(component).num_xmstring_buffer, XmString);
    }
    
    for (i = SpPrimitiveArch(component).num_xmstring; i < SpPrimitiveArch(component).num_xmstring_buffer; i++) {
	SpPrimitiveArch(component).xmstrings[i] = NULL;
    }

    return;
}

int spAddXmStringIndex(spComponent component, char *item, int index)
{
    int i;
    
    if (component == NULL || item == NULL) return -1;

    if (index < 0 || index > SpPrimitiveArch(component).num_xmstring) {
	index = SpPrimitiveArch(component).num_xmstring;
    }
    
    /* allocate buffer for XmString */
    reallocXmStrings(component);
    SpPrimitiveArch(component).num_xmstring++;

    for (i = SpPrimitiveArch(component).num_xmstring - 1; i > index; i--) {
	SpPrimitiveArch(component).xmstrings[i] = SpPrimitiveArch(component).xmstrings[i - 1];
    }
    
    /* create XmString */
    SpPrimitiveArch(component).xmstrings[index] = XmStringCreate(item, XmFONTLIST_DEFAULT_TAG);

    return index;
}
    
int spAddXmString(spComponent component, char *item)
{
    return spAddXmStringIndex(component, item, -1);
}

XmString spGetXmString(spComponent component, int index)
{
    if (component == NULL ||
	(index < 0 || index >= SpPrimitiveArch(component).num_xmstring)) return NULL;
    
    return SpPrimitiveArch(component).xmstrings[index];
}
    
int spGetXmStringIndex(spComponent component, char *item)
{
    int i;
    int index = -1;
    char *string;

    if (component == NULL || item == NULL) return -1;

    for (i = 0; i < SpPrimitiveArch(component).num_xmstring; i++) {
	/* get string from XmString */
	if (XmStringGetLtoR(SpPrimitiveArch(component).xmstrings[i], XmSTRING_DEFAULT_CHARSET, &string)) {
	    if (streq(string, item)) {
		index = i;
		XtFree(string);
		break;
	    }
	    XtFree(string);
	}
    }

    return index;
}

int spDeleteXmStringIndex(spComponent component, int index)
{
    int i;

    if (component == NULL) return -1;

    if (index < 0 || index >= SpPrimitiveArch(component).num_xmstring) {
	return -1;
    }
    
    /* free XmString */
    XmStringFree(SpPrimitiveArch(component).xmstrings[index]);
    SpPrimitiveArch(component).num_xmstring--;
    
    for (i = index; i < SpPrimitiveArch(component).num_xmstring; i++) {
	SpPrimitiveArch(component).xmstrings[i] = SpPrimitiveArch(component).xmstrings[i + 1];
    }
    
    return index;
}

int spDeleteXmString(spComponent component, char *item)
{
    int index;

    if (component == NULL || item == NULL) return -1;

    /* get item index */
    index = spGetXmStringIndex(component, item);

    /* delete item from list */
    spDeleteXmStringIndex(component, index);

    return index;
}

static void selectListCB(Widget widget, XtPointer client_data, XmListCallbackStruct *cbs)
{
    spComponent component = (spComponent)client_data;

    if (spIsCreated(component) == SP_FALSE) return;

    SpPrimitivePart(component).index = cbs->item_position - 1;
    spDebug(30, "selectListCB", "index = %d\n", SpPrimitivePart(component).index);

    return;
}

void spListCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];

    XtSetArg(args[narg], XmNselectionPolicy, XmBROWSE_SELECT); narg++;
    /*XtSetArg(args[narg], XmNlistSizePolicy, XmVARIABLE); narg++;*/
    XtSetArg(args[narg], XmNlistSizePolicy, XmCONSTANT); narg++;
    XtSetArg(args[narg], XmNscrollBarDisplayPolicy, XmSTATIC); narg++;
    SpPrimitiveArch(component).widget =
	XmCreateScrolledList(SpParentPrimitiveArch(component).widget,
			     (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			     args, narg);
    XtManageChild(SpPrimitiveArch(component).widget);
    SpPrimitiveArch(component).top_widget = XtParent(SpPrimitiveArch(component).widget);
    
    XtAddCallback(SpPrimitiveArch(component).widget, XmNbrowseSelectionCallback,
		  (XtCallbackProc)selectListCB, (XtPointer)component);

    return;
}

void spListSetParamsArch(spComponent component)
{
    return;
}

void spListGetParamsArch(spComponent component)
{
    return;
}

int spAddListItemArch(spComponent component, char *item)
{
    int index;
    Widget widget;

    /* add item to list */
    index = spAddXmString(component, item);
    spDebug(30, "spAddListItem", "add item to list: %d\n", index);
    
    if (index >= 0) {
	if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
	    widget = SpPrimitiveArch(component).sub_widget;
	} else {
	    widget = SpPrimitiveArch(component).widget;
	}
	
	/* add item to list widget */
	if (SpPrimitivePart(component).index < 0) {
	    XmListAddItemUnselected(widget, spGetXmString(component, index), 0);
	} else {
	    XmListAddItem(widget, spGetXmString(component, index), 0);
	}
    }

    return index;
}

int spAddListIndexArch(spComponent component, char *item, int index)
{
    Widget widget;
    
    /* add item to list */
    index = spAddXmStringIndex(component, item, index);
    
    if (index >= 0) {
	if (SpPrimitivePart(component).index >= index) {
	    SpPrimitivePart(component).index++;
	}
	if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
	    widget = SpPrimitiveArch(component).sub_widget;
	} else {
	    widget = SpPrimitiveArch(component).widget;
	}
	
	/* add item to list widget */
	if (SpPrimitivePart(component).index < 0) {
	    XmListAddItemUnselected(widget, spGetXmString(component, index), index + 1);
	} else {
	    XmListAddItem(widget, spGetXmString(component, index), index + 1);
	}
    }
    
    return index;
}

int spDeleteListItemArch(spComponent component, char *item)
{
    int index;

    /* get item index */
    index = spGetXmStringIndex(component, item);

    if (index >= 0) {
	index = spDeleteListIndexArch(component, index);
    }

    return index;
}

int spDeleteListIndexArch(spComponent component, int index)
{
    Widget widget;
    
    if (index >= SpPrimitiveArch(component).num_xmstring) return -1;

    if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
	widget = SpPrimitiveArch(component).sub_widget;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }
    
    spDebug(30, "spDeleteListIndexArch", "index = %d, original index = %d\n",
	    index, SpPrimitivePart(component).index);
    
    if (SpPrimitivePart(component).index == index) {
	XmListDeselectPos(widget, index + 1);
	SpPrimitivePart(component).index = -1;
    } else if (SpPrimitivePart(component).index > index) {
	SpPrimitivePart(component).index--;
    }
    spDebug(30, "spDeleteListIndexArch", "new index = %d\n",
	    SpPrimitivePart(component).index);
    
    /* delete item from list widget */
    XmListDeletePos(widget, index + 1);
    
    /* delete item from list */
    spDeleteXmStringIndex(component, index);

    return index;
}

int spFindListItemArch(spComponent component, char *item)
{
    return spGetXmStringIndex(component, item);
}

int spSelectListItemArch(spComponent component, char *item)
{
    int index;
    
    /* get item index */
    index = spGetXmStringIndex(component, item);

    if (index >= 0) {
	index = spSelectListIndexArch(component, index);
    }

    return index;
}

int spSelectListIndexArch(spComponent component, int index)
{
    char *string;
    
    if (index >= SpPrimitiveArch(component).num_xmstring) return -1;

    SpPrimitivePart(component).index = index;
    
    if (spIsSubClass(component, SpComboBox) == SP_TRUE) {
	/* select item from list widget */
	XmListSelectPos(SpPrimitiveArch(component).sub_widget, index + 1, /*True*/False);
	
	if ((string = xspGetSelectedListItem(component)) != NULL) {
	    spSetTextString(component, string);
	    xfree(string);
	}
    } else {
	/* select item from list widget */
	XmListSelectPos(SpPrimitiveArch(component).widget, index + 1, /*True*/False);
    }

    return index;
}

char *xspGetSelectedListItemArch(spComponent component)
{
    XmString xmstr;
    char *string;
    char *item = NULL;
    
    if ((xmstr = spGetXmString(component, SpPrimitivePart(component).index)) != NULL) {
	if (XmStringGetLtoR(xmstr, XmSTRING_DEFAULT_CHARSET, &string)) {
	    item = strclone(string);
	    XtFree(string);
	}
    }
    
    return item; 
}

int spGetSelectedListIndexArch(spComponent component)
{
    spDebug(30, "spGetSelectedListIndexArch", "index = %d\n", SpPrimitivePart(component).index);
    return SpPrimitivePart(component).index; 
}

#if 0
/**/
/**/int spAddListIndex(spComponent component, char *item, int index){}
/**/int spDeleteListIndex(spComponent component, int index){}
/**/int spSelectListIndex(spComponent component, int index){}
int spUnselectListItem(spComponent component, char *item){}
int spUnselectListIndex(spComponent component, int index){}
int spGetSelectedListIndex(spComponent component){}
#endif
