/*
 *	spComponent.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevel.h>
#include <sp/spFrame.h>
#include <sp/spDialog.h>
#include <sp/spContainer.h>
#include <sp/spToolBar.h>
#include <sp/spStatusBar.h>
#include <sp/spCanvas.h>
#include <sp/spDraw.h>

#include <sp/spTopLevelP.h>
#include <sp/spComponentP.h>
#include <sp/spFrameP.h>

#if defined(MACOS)
#pragma import on
#endif
extern spTopLevel sp_toplevel;
#if defined(MACOS)
#pragma import off
#endif

static spComponents sp_components = NULL;

static spParamTable sp_component_param_tables[] = {
    {SppTitle, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.title), ""},
    {SppDescription, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.description), ""},
    {SppSenseLevel, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.sense_level), SP_INIT_SENSE_LEVEL_STRING},
    {SppGroupId, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.group_id), SP_INIT_GROUP_ID_STRING},
    {SppUserData, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.user_data), NULL},
    {SppOrientation, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.orientation), SP_VERTICAL_STRING},
    {SppSpacingOn, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.spacing_flag), NULL},
    {SppVisible, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.visible_flag), SP_TRUE_STRING},
    {SppWidth, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.width), "0"},
    {SppHeight, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.height), "0"},
    {SppInitialWidth, SP_CREATE_ACCESS,
	 spOffset(spComponent, component.require_width), "0"},
    {SppInitialHeight, SP_CREATE_ACCESS,
	 spOffset(spComponent, component.require_height), "0"},
    {SppMarginWidth, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.margin_width), "0"},
    {SppMarginHeight, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.margin_height), "0"},
    {SppSpacing, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.spacing), "0"},
#if 0
    {SppCallbackFunc, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.call_func), NULL},
    {SppCallbackData, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComponent, component.call_data), NULL},
#else
    {SppCallbackFunc, SP_CREATE_ACCESS,
	 spOffset(spComponent, component.call_func), NULL},
    {SppCallbackData, SP_CREATE_ACCESS,
	 spOffset(spComponent, component.call_data), NULL},
#endif
};

spComponentClassRec SpComponentClassRec = {
    /* spObjectClassPart */
    {
	SpComponent,
	NULL,
	sizeof(spComponentRec),
	spArraySize(sp_component_param_tables),
	sp_component_param_tables,
	spComponentPartInit,
	spComponentPartFree,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
};

spComponentClass SpComponentClass = &SpComponentClassRec;

void spSetParamsArg(spComponent component, spArg *args, int num_arg)
{
    spSetObjectParamsArg((spObject)component, args, num_arg);
    return;
}

void spGetParamsArg(spComponent component, spArg *args, int num_arg)
{
    spGetObjectParamsArg((spObject)component, args, num_arg);
    return;
}
    
void spSetParams(spComponent component, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (component == NULL) return;
    
    va_start(argp, component);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetParamsArg(component, args, num_arg);

    return;
}
    
void spGetParams(spComponent component, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (component == NULL) return;
    
    va_start(argp, component);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spGetParamsArg(component, args, num_arg);

    return;
}

static void spComponentsAlloc(void)
{
    if (sp_components == NULL) {
	sp_components = xalloc(1, struct _spComponents);
	
	sp_components->sense_level_init = SP_FALSE;
	/*sp_components->current_component_id = 0;*/
	sp_components->current_component_id = 1;
	sp_components->destroy_component_id = -1;
	sp_components->child = NULL;
	sp_components->last_child = NULL;
    }

    return;
}

static long spUseCurrentComponentId(void)
{
    long component_id;
    
    component_id = sp_components->current_component_id;
    sp_components->current_component_id++;
    
    return component_id;
}

spComponent spCreateComponentArg(spComponentClass component_class, char *class_name,
				 char *name, spComponent parent, 
				 spArg *args, int num_arg)
{
    spComponent component;

    if (component_class == NULL)
	return NULL;
    
    spDebug(100, "spCreateComponentArg", "in\n");
    
    if ((component = (spComponent)spAllocObject((spObjectClass)component_class,
						class_name, name)) == NULL) {
	return NULL;
    }

    spDebug(100, "spCreateComponentArg", "spAllocObject done\n");
    
    spComponentsAlloc();
    if (parent != NULL) {
	SpComponentPart(component).window = SpComponentPart(parent).window;
	if (SpComponentPart(parent).component != NULL) {
	    SpComponentPart(component).parent = SpComponentPart(parent).component;
	} else {
	    SpComponentPart(component).parent = parent;
	}
	SpComponentPart(component).prev_component = SpParentComponentPart(component).last_child;
	if (SpComponentPart(component).prev_component != NULL) 
	    SpGetNextComponent(SpComponentPart(component).prev_component) = component;
	if (SpParentComponentPart(component).child == NULL)
	    SpParentComponentPart(component).child = component;
	SpParentComponentPart(component).last_child = component;
    } else {
	SpComponentPart(component).window = NULL;
	SpComponentPart(component).parent = NULL;
	SpComponentPart(component).prev_component = NULL;
    }
    if (spIsWindow(component) == SP_TRUE && spIsPrimitive(component) == SP_TRUE) {
	spDebug(80, "spCreateComponentArg", "setting for window\n");
	SpComponentPart(component).window = component;
	if (parent == NULL) {
	    SpComponentPart(component).prev_component = sp_components->last_child;
	    if (SpComponentPart(component).prev_component != NULL)
		SpGetNextComponent(SpComponentPart(component).prev_component) = component;
	    if (sp_components->child == NULL)
		sp_components->child = component;
	    sp_components->last_child = component;
	}
    }
    SpComponentPart(component).component = NULL;
    SpComponentPart(component).component_id = spUseCurrentComponentId();
    SpComponentPart(component).group_id = SP_INIT_GROUP_ID;
    SpComponentPart(component).sense_level = SP_INIT_SENSE_LEVEL;

    spDebug(100, "spCreateComponentArg", "original: width = %d, height = %d\n",
	    SpComponentPart(component).width, SpComponentPart(component).height);
    
    spSetParamsArg(component, args, num_arg);

    spDebug(100, "spCreateComponentArg", "original: width = %d, height = %d\n",
	    SpComponentPart(component).width, SpComponentPart(component).height);
    spDebug(80, "spCreateComponentArg", "spSetParamsArg done: class_name = %s\n",
	    SpGetObjectClass(component)->object.class_name);
    
    return component;
}

void spFreeComponent(spComponent component)
{
    spFreeObject((spObject)component);
    return;
}

void spDestroyComponent(spComponent component)
{
    if (spIsCreated(component) == SP_FALSE
	|| spGetDestroyedComponentId() == SpGetComponentId(component)) {
	return;
    }
    
    sp_components->destroy_component_id = SpGetComponentId(component);
    
    if (spIsWindow(component) == SP_TRUE) {
	spPopdownWindow(component);
    }
    if (spIsFrame(component) == SP_TRUE
	&& spIsTaskTrayVisible(component) == SP_TRUE) {
	spShowTaskTray(component, SP_FALSE);
    }

    spDestroyObject((spObject)component);
    
    spDebug(30, "spDestroyComponent", "done\n");
    
    return;
}

void spMapComponent(spComponent component)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.map != NULL) {
	    spDebug(40, "spMapComponent", "in\n");
	    SpComponentPart(component).visible_flag = SP_TRUE;
	    component_class->component.map(component);
	    
	    if (SpComponentPart(component).geometry_flag == SP_FALSE
		&& (SpGetComponentClass(component)->component.resize_flag == SP_TRUE
		    || spIsStatusBar(component) == SP_TRUE
		    || spIsToolBar(component) == SP_TRUE)) {
		/*spAdjustComponentSize(SpGetWindow(component));*/
		spAdjustComponentSize(SpGetParent(component));
	    }
	    
	    break;
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return;
}

void spUnmapComponent(spComponent component)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.unmap != NULL) {
	    spDebug(40, "spUnmapComponent", "in\n");
	    SpComponentPart(component).visible_flag = SP_FALSE;
	    SpComponentPart(component).prev_width = -1;
	    SpComponentPart(component).prev_height = -1;
	    SpComponentPart(component).current_width = -1;
	    SpComponentPart(component).current_height = -1;
	    SpComponentPart(component).client_width = -1;
	    SpComponentPart(component).client_height = -1;
	    component_class->component.unmap(component);
	    if (SpComponentPart(component).geometry_flag == SP_FALSE
		&& (SpGetComponentClass(component)->component.resize_flag == SP_TRUE
		    || spIsStatusBar(component) == SP_TRUE
		    || spIsToolBar(component) == SP_TRUE)) {
		/*spAdjustComponentSize(SpGetWindow(component));*/
		spAdjustComponentSize(SpGetParent(component));
	    }
    
	    break;
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }
    
    return;
}

void spComponentCallbackFunc(spCallback *callback)
{
    spComponent component;
    spComponentClass component_class;
    
    if (callback == NULL || callback->component == NULL) return;

    component = callback->component;

    while (1) {
	SpComponentPart(component).call_reason = SP_CR_NONE;
	
	component_class = SpGetComponentClass(component);
	while (component_class != NULL) {
	    if (component_class->component.callback_func != NULL) {
		if ((SpComponentPart(component).call_reason =
		     component_class->component.callback_func(component)) == SP_CR_NONE) {
		    return;
		} else {
		    break;
		}
	    }

	    component_class = (spComponentClass)component_class->object.super_class;
	}

	if (SpGetPropagateComponent(component) != NULL
	    && callback->propagate == SP_TRUE) {
	    component = SpGetPropagateComponent(component);
	} else {
	    break;
	}
    }

    callback->call_func(component, callback->call_data);
    spDebug(80, "spComponentCallbackFunc", "done\n");
    
    return;
}

spCallbackReason spGetCallbackReason(spComponent component)
{
    if (component == NULL) return SP_CR_NONE;
    
    return SpComponentPart(component).call_reason;
}

spBool spAddCallback(spComponent component, spCallbackType call_type,
		     spCallbackFunc call_func, void *call_data)
{
    spComponentClass component_class;
    
    if (component == NULL) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.add_callback != NULL) {
	    return component_class->component.add_callback(component, SP_FALSE, call_type,
							   call_func, call_data);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

spBool spAddPropagateCallback(spComponent component, spCallbackType call_type,
			      spCallbackFunc call_func, void *call_data)
{
    spComponentClass component_class;
    
    if (component == NULL) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.add_callback != NULL) {
	    return component_class->component.add_callback(component, SP_TRUE, call_type,
							   call_func, call_data);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

spBool spRemoveCallback(spComponent component, spCallbackType call_type,
			spCallbackFunc call_func, void *call_data)
{
    spComponentClass component_class;
    
    if (component == NULL) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.remove_callback != NULL) {
	    return component_class->component.remove_callback(component, call_type,
							      call_func, call_data);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

spBool spGetCallbackMousePosition(spComponent component, int *x, int *y)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.get_callback_mouse_position != NULL) {
	    return component_class->component.get_callback_mouse_position(component, x, y);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

spBool spGetCallbackKeySym(spComponent component, spKeySym *key_sym)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE
	|| key_sym == NULL) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.get_callback_key_sym != NULL) {
	    return component_class->component.get_callback_key_sym(component, key_sym);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

int spGetCallbackKeyString(spComponent component,
			      char *buf, int buf_size, spBool *overflow)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE
	|| buf == NULL || buf_size <= 0) return -1;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.get_callback_key_string != NULL) {
	    return component_class->component.get_callback_key_string(component, buf,
								      buf_size, overflow);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return -1;
}

spBool spGetModifierKeyMask(spComponent component, spModifierMask *mask)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE || mask == NULL) return SP_FALSE;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return SP_FALSE;
    
    if (spIsVisible(window) == SP_TRUE) {
	if (spGetFrameModifierKeyMaskArch(window, mask) == SP_TRUE) {
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

spBool spOverwritePrompt(spComponent component, char *filename)
{
    static char buf[SP_MAX_MESSAGE];
    
    sprintf(buf, SP_OVERWRITE_PROMPT_MESSAGE, filename);
    
    if (spCreateMessageBox(component,
			   SP_OVERWRITE_PROMPT_TITLE,
			   buf,
			   SppDialogType, /*SP_QUESTION_DIALOG,*/SP_WARNING_DIALOG,
			   SppMessageBoxButtonType, SP_MB_YES_NO,
			   NULL) == SP_DR_YES) {
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spQuitPrompt(spComponent component)
{
	/*
    spBool flag = SP_TRUE;

    spDebug(60, "spQuitPrompt", "exit_prompt = %d\n",
	    SpTopLevelPart(sp_toplevel).exit_prompt);
    
    if (SpTopLevelPart(sp_toplevel).exit_prompt == SP_TRUE) {
	if (spCreateMessageBox(NULL, SP_QUIT_QUESTION_TITLE,
			       SP_QUIT_QUESTION_MESSAGE,
			       SppDialogType, SP_QUESTION_DIALOG,
			       SppMessageBoxButtonType, SP_MB_YES_NO,
			       NULL) == SP_DR_YES) {
	    flag = SP_TRUE;
	} else {
	    flag = SP_FALSE;
	}
    }

    return flag;
	*/
	return SP_TRUE;
}

void spQuitCB(spComponent component, void *data)
{
    spDebug(60, "spQuitCB", "in\n");
    
    if (spQuitPrompt(component) == SP_TRUE) {
	spDestroyWindow(component);
	spQuit(0);
    }
    
    return;
}

spBool spSetComponentSize(spComponent component, int width, int height)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    if (width <= 0 && height <= 0) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.set_size != NULL) {
	    if (width <= 0) {
		width = SpComponentPart(component).current_width;
	    }
	    if (height <= 0) {
		height = SpComponentPart(component).current_height;
	    }
	    SpComponentPart(component).client_width = -1;
	    SpComponentPart(component).client_height = -1;
	    if (component_class->component.set_size(component, width, height) == SP_TRUE) {
		SpComponentPart(component).prev_width = SpComponentPart(component).current_width;
		SpComponentPart(component).prev_height = SpComponentPart(component).current_height;
		SpComponentPart(component).current_width = width;
		SpComponentPart(component).current_height = height;

		if (spIsFrame(component) == SP_TRUE) {
		    spAdjustComponentSize(component);
		} else if (spIsCanvas(component) == SP_TRUE
			   || spIsContainer(component) == SP_FALSE) {
		    SpComponentPart(component).require_width = width;
		    SpComponentPart(component).require_height = height;
		}
		return SP_TRUE;
	    }
	    break;
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }
    
    return SP_FALSE;
}

spBool spSetSize(spComponent component, int width, int height)
{
    return spSetComponentSize(component, width, height);
}

spBool spGetComponentSize(spComponent component, int *width, int *height)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    spDebug(30, "spGetComponentSize", "width = %d, height = %d\n",
	    SpComponentPart(component).current_width, SpComponentPart(component).current_height);
    
    if (SpComponentPart(component).current_width >= 0
	&& SpComponentPart(component).current_height >= 0) {
	if (width != NULL) *width = SpComponentPart(component).current_width;
	if (height != NULL) *height = SpComponentPart(component).current_height;
	return SP_TRUE;
    }
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.get_size != NULL) {
	    if (component_class->component.get_size(component,
						    &SpComponentPart(component).current_width,
						    &SpComponentPart(component).current_height) == SP_TRUE) {
		if (width != NULL) *width = SpComponentPart(component).current_width;
		if (height != NULL) *height = SpComponentPart(component).current_height;
		return SP_TRUE;
	    }
	    break;
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }
    
    return SP_FALSE;
}

spBool spGetClientSize(spComponent component, int *width, int *height)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    spDebug(30, "spGetClientSize", "%s: width = %d, height = %d\n",
	    SpGetClassName(component),
	    SpComponentPart(component).client_width,
	    SpComponentPart(component).client_height);
    
    if (SpComponentPart(component).client_width >= 0
	&& SpComponentPart(component).client_height >= 0) {
	if (width != NULL) *width = SpComponentPart(component).client_width;
	if (height != NULL) *height = SpComponentPart(component).client_height;
	return SP_TRUE;
    }
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.get_client_size != NULL) {
	    if (component_class->component.get_client_size(component,
							   &SpComponentPart(component).client_width,
							   &SpComponentPart(component).client_height) == SP_TRUE) {
		if (spIsWindow(component) == SP_TRUE) {
		    SpComponentPart(component).current_width = SpComponentPart(component).client_width;
		    SpComponentPart(component).current_height = SpComponentPart(component).client_height;
		}
		
		if (width != NULL) *width = SpComponentPart(component).client_width;
		if (height != NULL) *height = SpComponentPart(component).client_height;
		return SP_TRUE;
	    }
	    break;
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }
    
    return SP_FALSE;
}

spBool spGetSize(spComponent component, int *width, int *height)
{
    spDebug(80, "spGetSize", "in\n");
    
    if (spIsContainer(component) == SP_TRUE || spIsDrawable(component) == SP_TRUE) {
	return spGetClientSize(component, width, height);
    } else {
	return spGetComponentSize(component, width, height);
    }
}

spBool spSetSensitive(spComponent component, spBool flag)
{
    spComponentClass component_class;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;
    
    component_class = SpGetComponentClass(component);
    
    while (component_class != NULL) {
	if (component_class->component.set_sensitive != NULL) {
	    SpComponentPart(component).sensitive_flag = flag;
	    return component_class->component.set_sensitive(component, flag);
	}

	component_class = (spComponentClass)component_class->object.super_class;
    }

    return SP_FALSE;
}

static spBool setCurrentSenseLevel(long group_id, long level, spBool init_flag)
{
    spComponent next;
    
    if (sp_components == NULL)
	return SP_FALSE;

    spDebug(80, "setCurrentSenseLevel", "group = %ld, level = %ld\n", group_id, level);
    
    next = sp_components->child;
    while (next != NULL) {
	if (init_flag == SP_FALSE || SpComponentPart(next).current_sense_level < 0) {
	    spSetWindowSenseLevel(next, group_id, level);
	}
	    
	next = SpGetNextComponent(next);
    }
    if (init_flag == SP_TRUE) {
	sp_components->sense_level_init = SP_TRUE;
    }

    spDebug(80, "setCurrentSenseLevel", "done\n");
    
    return SP_TRUE;
}

spBool spSetCurrentSenseLevel(long group_id, long level)
{
    return setCurrentSenseLevel(group_id, level, SP_FALSE);
}

static void setSenseLevel(spComponent component, long group_id, long level)
{
    spComponent next;

    if (spIsCreated(component) == SP_FALSE) return;

    if ((group_id < 0 && SpComponentPart(component).group_id >= 0)
	|| SpComponentPart(component).group_id == group_id) {
	SpComponentPart(component).current_sense_level = level;
	if (SpComponentPart(component).sense_level <= level) {
	    spSetSensitive(component, SP_TRUE);
	} else {
	    spSetSensitive(component, SP_FALSE);
	}
    }
    
    next = SpGetChild(component);
    while (next != NULL) {
	/* set child sense level */
	setSenseLevel(next, group_id, level);
	next = SpGetNextComponent(next);
    }
	
    return;
}

spBool spSetWindowSenseLevel(spComponent component, long group_id, long level)
{
    if (spIsCreated(component) == SP_FALSE) {
	return SP_FALSE;
    }

    level = MAX(0, level);

    setSenseLevel(SpGetWindow(component), group_id, level);
    
    return SP_TRUE;
}

static spBool getSenseLevel(spComponent component, long group_id, long *level)
{
    spComponent next;

    if (spIsCreated(component) == SP_FALSE) {
	return SP_FALSE;
    }

    if (SpComponentPart(component).group_id == group_id) {
	*level = SpComponentPart(component).current_sense_level;
	return SP_TRUE;
    }
	
    next = SpGetChild(component);
    while (next != NULL) {
	/* get child sense level */
	if (getSenseLevel(SpComponentPart(next).child, group_id, level) == SP_TRUE) {
	    return SP_TRUE;
	}
	next = SpGetNextComponent(next);
    }

    return SP_FALSE;
}

spBool spGetWindowSenseLevel(spComponent component, long group_id, long *level)
{
    if (spIsCreated(component) == SP_FALSE || level == NULL) {
	return SP_FALSE;
    }

    return getSenseLevel(SpGetWindow(component), group_id, level);
}

spBool spSetSenseLevel(spComponent component, long level)
{
    if (component != NULL) {
	SpComponentPart(component).sense_level = level;
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spGetSenseLevel(spComponent component, long *level)
{
    if (component != NULL && level != NULL) {
	*level = SpComponentPart(component).sense_level;
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spSetInitSenseLevel(void)
{
    if (sp_components != NULL) {
	setCurrentSenseLevel(-1, 0, SP_TRUE);
	spDebug(80, "spSetInitSenseLevel", "done\n");
    }

    return;
}

spBool spSetUserData(spComponent component, void *data)
{
    if (component != NULL) {
	SpComponentPart(component).user_data = data;
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void *spGetUserData(spComponent component)
{
    if (component != NULL) {
	return SpComponentPart(component).user_data;
    } else {
	return NULL;
    }
}

char *spGetName(spComponent component)
{
    if (component != NULL) {
	return SpGetName(component);
    } else {
	return NULL;
    }
}

char *spGetTitle(spComponent component)
{
    char *title;
    static char *default_title = "";
    
    if (component != NULL) {
	title = SpGetTitle(component);
	if (strnone(title)) {
	    title = SpGetName(component);
	    if (strnone(title)) {
		title = default_title;
	    }
	}
    } else {
	title = NULL;
    }

    return title;
}

long spGetComponentId(spComponent component)
{
    if (component != NULL) {
	return SpGetComponentId(component);
    } else {
	return -1;
    }
}

spComponent spGetComponent(spComponent component)
{
    if (component != NULL) {
	return SpComponentPart(component).component;
    } else {
	return NULL;
    }
}

spComponent spGetParent(spComponent component)
{
    if (component != NULL) {
	return SpGetParent(component);
    } else {
	return NULL;
    }
}

spComponent spGetChild(spComponent component)
{
    if (component != NULL) {
	return SpGetChild(component);
    } else {
	return sp_components->child;
    }
}

spComponent spGetLastChild(spComponent component)
{
    if (component != NULL) {
	return SpGetLastChild(component);
    } else {
	return sp_components->last_child;
    }
}

spComponent spGetNextComponent(spComponent component)
{
    if (component != NULL) {
	return SpGetNextComponent(component);
    } else {
	return NULL;
    }
}

spComponent spGetPrevComponent(spComponent component)
{
    if (component != NULL) {
	return SpGetPrevComponent(component);
    } else {
	return NULL;
    }
}

spComponent spGetWindow(spComponent component)
{
    if (component != NULL) {
	return SpGetWindow(component);
    } else {
	return NULL;
    }
}

void *spGetArchWindow(spComponent component)
{
    spComponent window;

    if (component == NULL) return NULL;

    window = SpGetWindow(component);
    
    if (spIsFrame(window) == SP_TRUE) {
	return spGetArchFrame(window);
    } else {
	return NULL;
    }
}

long spGetDestroyedComponentId(void)
{
    return sp_components->destroy_component_id;
}

spBool spIsCreated(spComponent component)
{
    return spIsObjectCreated((spObject)component);
}

spBool spIsVisible(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    return SpComponentPart(component).visible_flag;
}

spBool spIsSensitive(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    return SpComponentPart(component).sensitive_flag;
}

spBool spIsResizable(spComponent component)
{
    if (component == NULL) return SP_FALSE;

    if (SpGetComponentClass(component)->component.resize_flag == SP_TRUE
	&& SpComponentPart(component).visible_flag == SP_TRUE) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spIsSpacingOn(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    return SpComponentPart(component).spacing_flag;
}

spBool spEqClass(spComponent component, char *class_name)
{
    spBool flag = SP_FALSE;

    if (component == NULL) return SP_FALSE;

    if (!strnone(SpObjectPart(component).class_name)) {
	if (streq(SpObjectPart(component).class_name, class_name)) {
	    flag = SP_TRUE;
	}
    } else {
	if (streq(SpGetComponentClass(component)->object.class_name, class_name)) {
	    flag = SP_TRUE;
	}
    }
    
    return flag;
}

spBool spIsSubClass(spComponent component, char *class_name)
{
    spBool flag = SP_FALSE;
    spComponentClass component_class;
    
    if (component == NULL) return SP_FALSE;

    if (streq(SpObjectPart(component).class_name, class_name)) {
	flag = SP_TRUE;
    } else if (streq(SpGetComponentClass(component)->object.class_name, class_name)) {
	flag = SP_TRUE;
    }

    if (flag == SP_FALSE) {
	component_class = SpGetComponentClass(component);
    
	while (component_class != NULL) {
	    if (streq(component_class->object.class_name, class_name)) {
		flag = SP_TRUE;
		break;
	    }
	    
	    component_class = (spComponentClass)component_class->object.super_class;
	}
    }

    return flag;
}

spBool spIsComponentType(spComponent component, char *class_name)
{
    spBool flag = SP_FALSE;
    spComponentClass component_class;
    
    if (component == NULL) return SP_FALSE;

    flag = spIsSubClass(component, class_name);

    if (flag == SP_FALSE) {
	component_class = SpGetComponentClass(component);
    
	while (component_class != NULL) {
	    if (component_class->component.is_component_type != NULL) {
		flag = component_class->component.is_component_type(component, class_name);
	    }
	    
	    if (flag == SP_TRUE) {
		break;
	    }
	    
	    component_class = (spComponentClass)component_class->object.super_class;
	}
    }

    return flag;
}

void spComponentPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).component_id = 0;
    SpComponentPart(component).current_sense_level = -1;
    SpComponentPart(component).component = NULL;
    SpComponentPart(component).window = NULL;
    SpComponentPart(component).parent = NULL;
    SpComponentPart(component).child = NULL;
    SpComponentPart(component).last_child = NULL;
    SpComponentPart(component).next_component = NULL;
    SpComponentPart(component).prev_component = NULL;
    SpComponentPart(component).propagate_component = NULL;
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    SpComponentPart(component).current_width = -1;
    SpComponentPart(component).current_height = -1;
    SpComponentPart(component).prev_width = -1;
    SpComponentPart(component).prev_height = -1;
    SpComponentPart(component).require_width = 0;
    SpComponentPart(component).require_height = 0;
    SpComponentPart(component).client_width = -1;
    SpComponentPart(component).client_height = -1;
    SpComponentPart(component).border_width = 0;
    SpComponentPart(component).top_offset = 0;
    SpComponentPart(component).bottom_offset = 0;
    SpComponentPart(component).left_offset = 0;
    SpComponentPart(component).right_offset = 0;
    SpComponentPart(component).margin_bottom = 0;
    SpComponentPart(component).geometry_flag = SP_FALSE;
    SpComponentPart(component).spacing_flag = SP_FALSE;
    SpComponentPart(component).visible_flag = SP_TRUE;
    SpComponentPart(component).sensitive_flag = SP_TRUE;
    SpComponentPart(component).focus_flag = SP_FALSE;
    SpComponentPart(component).call_reason = SP_CR_NONE;
    
    SpComponentPart(component).title = NULL;
    SpComponentPart(component).description = NULL;
    SpComponentPart(component).sense_level = SP_INIT_SENSE_LEVEL;
    SpComponentPart(component).group_id = SP_INIT_GROUP_ID;
    SpComponentPart(component).user_data = NULL;
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).width = 0;
    SpComponentPart(component).height = 0;
    SpComponentPart(component).margin_width = 0;
    SpComponentPart(component).margin_height = 0;
    SpComponentPart(component).spacing = 0;
    SpComponentPart(component).call_func = NULL;
    SpComponentPart(component).call_data = NULL;

    return;
}

void spComponentPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    spComponent child, next_child;

    child = SpComponentPart(component).child;
    while (child != NULL) {
	next_child = SpGetNextComponent(child);
	if (next_child != NULL) SpGetPrevComponent(next_child) = NULL;
	spFreeComponent(child);
	child = next_child;
    }
    spDebug(60, "spComponentPartFree", "free children done\n");
    
    if (SpComponentPart(component).parent != NULL
	&& SpParentComponentPart(component).child == component) {
	SpParentComponentPart(component).child = SpGetNextComponent(component);
    } else if (sp_components->child == component) {
	sp_components->child = SpGetNextComponent(component);
    }
    if (SpComponentPart(component).parent != NULL
	&& SpParentComponentPart(component).last_child == component) {
	SpParentComponentPart(component).last_child = SpGetPrevComponent(component);
    } else if (sp_components->last_child == component) {
	sp_components->last_child = SpGetPrevComponent(component);
    }
    if (SpGetPrevComponent(component) != NULL) {
	SpGetNextComponent(SpGetPrevComponent(component)) = SpGetNextComponent(component);
    }
    if (SpGetNextComponent(component) != NULL) {
	SpGetPrevComponent(SpGetNextComponent(component)) = SpGetPrevComponent(component);
    }
    
    if (SpComponentPart(component).title != NULL) {
	xfree(SpComponentPart(component).title);
	SpComponentPart(component).title = NULL;
    }
    if (SpComponentPart(component).description != NULL) {
	xfree(SpComponentPart(component).description);
	SpComponentPart(component).description = NULL;
    }
    
    spDebug(80, "spComponentPartFree", "done\n");
	
    return;
}

static void setComponentsSize(spComponent component)
{
    spComponent child;
    
    if (spIsCreated(component) == SP_FALSE
	|| (spIsResizable(component) == SP_FALSE && spIsStatusBar(component) == SP_FALSE)
	|| SpComponentPart(component).geometry_flag == SP_TRUE) return;

    SpComponentPart(component).geometry_flag = SP_TRUE;
    SpComponentPart(component).client_width = -1;
    SpComponentPart(component).client_height = -1;
    
    spDebug(60, "setComponentsSize", "%s, width = %d, height = %d\n",
	    SpGetClassName(component),
	    SpComponentPart(component).width, SpComponentPart(component).height);
    spDebug(50, "setComponentsSize", "%s, current_width = %d, current_height = %d\n",
	    SpGetClassName(component),
	    SpComponentPart(component).current_width, SpComponentPart(component).current_height);

    if (spIsWindow(component) == SP_FALSE
	|| (SpComponentPart(component).prev_width < 0
	    && SpComponentPart(component).prev_height < 0)) {
	spSetSize(component, SpComponentPart(component).current_width,
		  SpComponentPart(component).current_height);
    }
    
    child = SpComponentPart(component).child;
    while (child != NULL) {
	setComponentsSize(child);
	child = SpGetNextComponent(child);
    }
    
    SpComponentPart(component).geometry_flag = SP_FALSE;

    spDebug(80, "setComponentsSize", "done\n");
    
    return;
}

static int getOptimumHeight(spComponent component)
{
    int flag;
    int h, hc;
    int height = 0;
    int total_height = -1;
    spComponent child = NULL, prev_child = NULL;

    if (spIsResizable(component) == SP_FALSE) return 0;
    
    child = SpGetChild(component);
    
    if (child != NULL) {
	if (SpComponentPart(component).orientation == SP_VERTICAL) {
	    flag = 0;
	    while (1) {
		if (spIsResizable(child) == SP_TRUE) {
		    if (spIsToolBar(child) == SP_FALSE && flag == 0) {
			height += SpComponentPart(component).border_width;
			
			if (spIsSpacingOn(child) == SP_TRUE) {
			    height += MAX(SpComponentPart(component).margin_height,
					  SpComponentPart(child).top_offset);
			} else if (SpComponentPart(child).top_offset > 0) {
			    height += SpComponentPart(child).top_offset;
			}
			flag = 1;
		    }

		    SpComponentPart(child).y = height;
		    
		    if (SpComponentPart(child).height <= 0) {
			if (total_height > 0) {
			    SpComponentPart(child).current_height
				= total_height - SpComponentPart(child).y + SpComponentPart(child).height;
			    
			    SpComponentPart(child).current_height -= SpComponentPart(component).border_width;
			    SpComponentPart(child).current_height -= SpComponentPart(component).margin_bottom;

			    if (SpGetNextComponent(child) == NULL) {
				if (spIsSpacingOn(child) == SP_TRUE) {
				    SpComponentPart(child).current_height
					-= MAX(SpComponentPart(component).margin_height,
					       SpComponentPart(child).bottom_offset);
				} else if (spIsCreated(child) == SP_TRUE
					   && SpComponentPart(child).bottom_offset > 0) {
				    SpComponentPart(child).current_height
					-= SpComponentPart(child).bottom_offset;
				}
			    }
			    
			    height += SpComponentPart(child).current_height;

			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				getOptimumHeight(child);
			    }
			} else {
			    hc = SpComponentPart(component).current_height
				- SpComponentPart(child).y + SpComponentPart(child).height;

			    hc -= SpComponentPart(component).border_width;
			    hc -= SpComponentPart(component).margin_bottom;
			    
			    if (SpGetNextComponent(child) == NULL) {
				if (spIsSpacingOn(child) == SP_TRUE) {
				    hc -= MAX(SpComponentPart(component).margin_height,
					      SpComponentPart(child).bottom_offset);
				} else if (spIsCreated(child) == SP_TRUE
					   && SpComponentPart(child).bottom_offset > 0) {
				    hc -= SpComponentPart(child).bottom_offset;
				}
			    }
			    
			    if (SpComponentPart(component).prev_height >= 0
				|| (SpGetParent(component) != NULL
				    && SpComponentPart(SpGetParent(component)).prev_height >= 0)) {
				SpComponentPart(child).current_height = hc;

				if (spIsContainer(child) == SP_TRUE
				    && spIsCanvas(child) == SP_FALSE) {
				    getOptimumHeight(child);
				}
			    } else {
				if (spIsContainer(child) == SP_TRUE
				    && spIsCanvas(child) == SP_FALSE) {
				    SpComponentPart(child).current_height
					= MAX(hc, getOptimumHeight(child));
				} else {
				    SpComponentPart(child).current_height
					= MAX(hc, SpComponentPart(child).require_height);
				}
			    }

			    height += SpComponentPart(child).current_height;
			    total_height = height - SpComponentPart(child).height;
			}
		    } else {
			SpComponentPart(child).current_height = SpComponentPart(child).height; 

			if (spIsContainer(child) == SP_TRUE
			    && spIsCanvas(child) == SP_FALSE) {
			    h = getOptimumHeight(child);
			    if (h > SpComponentPart(child).current_height) {
				SpComponentPart(child).current_height = h;
			    }
			}
			
			height += SpComponentPart(child).current_height;
		    }
		    spDebug(50, "getOptimumHeight",
			    "y = %d\n", SpComponentPart(child).y);
		    prev_child = child;
		}

		child = SpGetNextComponent(child);
	    
		if (child == NULL) {
		    if (spIsSpacingOn(prev_child) == SP_TRUE) {
			height += MAX(SpComponentPart(component).margin_height,
				      SpComponentPart(prev_child).bottom_offset);
		    } else if (spIsCreated(prev_child) == SP_TRUE
			       && SpComponentPart(prev_child).bottom_offset > 0) {
			height += SpComponentPart(prev_child).bottom_offset;
		    }
		    height += SpComponentPart(component).margin_bottom;
		    height += SpComponentPart(component).border_width;
		    
		    break;
		} else if (spIsResizable(child) == SP_TRUE && flag == 1) {
		    if (spIsSpacingOn(prev_child) == SP_TRUE
			|| spIsSpacingOn(child) == SP_TRUE) {
			height += MAX(SpComponentPart(component).spacing,
				      SpComponentPart(child).top_offset);
		    } else if (SpComponentPart(child).top_offset > 0) {
			height += SpComponentPart(child).top_offset;
		    }
		}
	    }
	} else if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	    if (spIsFrame(component) == SP_TRUE
		&& spIsVisible(SpFramePart(component).tool_bar) == SP_TRUE) {
		SpComponentPart(SpFramePart(component).tool_bar).current_height
		    = getOptimumHeight(SpFramePart(component).tool_bar);
		spDebug(80, "getOptimumHeight", "tool bar height = %d\n",
			SpComponentPart(SpFramePart(component).tool_bar).current_height);
	    }
	    while (child != NULL) {
		if (spIsResizable(child) == SP_TRUE && spIsToolBar(child) == SP_FALSE) {
		    if (spIsFrame(component) == SP_TRUE
			&& spIsVisible(SpFramePart(component).tool_bar) == SP_TRUE) {
			h = SpComponentPart(SpFramePart(component).tool_bar).height;
			spDebug(50, "getOptimumHeight", "%s: tool bar height = %d\n",
				spGetTitle(child), h);
		    } else {
			h = 0;
		    }

		    SpComponentPart(child).y = h;
		    if (spIsSpacingOn(child) == SP_TRUE) {
			SpComponentPart(child).y += MAX(SpComponentPart(component).margin_height,
						       SpComponentPart(child).top_offset);
		    } else if (SpComponentPart(child).top_offset > 0) {
			SpComponentPart(child).y += SpComponentPart(child).top_offset;
		    }
		    SpComponentPart(child).y += SpComponentPart(component).border_width;
		    h = SpComponentPart(child).y;
		    
		    if (SpComponentPart(child).height <= 0) {
			hc = SpComponentPart(component).current_height
			    - SpComponentPart(child).y + SpComponentPart(child).height;
			spDebug(80, "getOptimumHeight", "%s: hc = %d, parent current height = %d\n",
				spGetTitle(child), hc, SpComponentPart(component).current_height);

			hc -= SpComponentPart(component).border_width;
			
			if (spIsSpacingOn(child) == SP_TRUE) {
			    hc -= MAX(SpComponentPart(component).margin_height,
				      SpComponentPart(child).bottom_offset);
			} else {
			    if (SpComponentPart(child).bottom_offset > 0) {
				hc -= SpComponentPart(child).bottom_offset;
			    }
			}
			hc -= SpComponentPart(component).margin_bottom;
		    
			if (SpComponentPart(component).prev_height >= 0
			    || (SpGetParent(component) != NULL
				&& SpComponentPart(SpGetParent(component)).prev_height >= 0)) {
			    SpComponentPart(child).current_height = MAX(hc, 0);

			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				getOptimumHeight(child);
			    }
			} else {
			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				SpComponentPart(child).current_height
				    = MAX(hc, getOptimumHeight(child));
			    } else {
				SpComponentPart(child).current_height
				    = MAX(hc, SpComponentPart(child).require_height);
			    }
			}
		    } else {
			SpComponentPart(child).current_height = SpComponentPart(child).height;

			if (spIsContainer(child) == SP_TRUE
			    && spIsCanvas(child) == SP_FALSE) {
			    getOptimumHeight(child);
			}
		    }
		    h += SpComponentPart(child).current_height;
		    spDebug(80, "getOptimumHeight", "%s: h = %d, current height = %d\n",
			    spGetTitle(child), h,
			    SpComponentPart(child).current_height);
		    
		    if (spIsSpacingOn(child) == SP_TRUE) {
			h += MAX(SpComponentPart(component).margin_height,
				 SpComponentPart(child).bottom_offset);
		    } else if (SpComponentPart(child).bottom_offset > 0) {
			h += SpComponentPart(child).bottom_offset;
		    }
		    h += SpComponentPart(component).margin_bottom;
		    h += SpComponentPart(component).border_width;
		    
		    height = MAX(height, h);
		    spDebug(80, "getOptimumHeight", "%s: computed height = %d\n",
			    spGetTitle(child), height);
		}
		
		prev_child = child;
		child = SpGetNextComponent(child);
	    }
	}
    } else {
	if (SpComponentPart(component).prev_height >= 0) {
	    height = SpComponentPart(component).height;
	} else {
	    spDebug(50, "getOptimumHeight",
		    "height = %d, require_height = %d\n",
		    SpComponentPart(component).height,
		    SpComponentPart(component).require_height);
	    height = MAX(SpComponentPart(component).height,
			 SpComponentPart(component).require_height);
	}
    }

    if (total_height < 0) {
	total_height = height;
    }

    spDebug(50, "getOptimumHeight", "done: %s, total_height = %d\n",
	    spGetTitle(component), total_height);
    
    return total_height;
}

static int getOptimumWidth(spComponent component)
{
    int flag;
    int w, wc;
    int width = 0;
    int total_width = -1;
    spComponent child = NULL, prev_child = NULL;

    if (spIsResizable(component) == SP_FALSE) return 0;
    
    child = SpGetChild(component);

    if (child != NULL) {
	if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	    flag = 0;
	    while (1) {
		if (spIsToolBar(child) == SP_TRUE) {
		    SpComponentPart(child).x = 0;
		    SpComponentPart(child).current_width = SpComponentPart(component).current_width;
		    getOptimumWidth(child);
		} else if (spIsResizable(child) == SP_TRUE) {
		    if (flag == 0) {
			width += SpComponentPart(component).border_width;
			
			if (spIsSpacingOn(child) == SP_TRUE) {
			    width += MAX(SpComponentPart(component).margin_width,
					 SpComponentPart(child).left_offset);
			} else if (SpComponentPart(child).left_offset > 0) {
			    width += SpComponentPart(child).left_offset;
			}
			flag = 1;
		    }
	    
		    SpComponentPart(child).x = width;
		    
		    if (SpComponentPart(child).width <= 0) {
			if (total_width > 0) {
			    SpComponentPart(child).current_width
				= total_width - SpComponentPart(child).x + SpComponentPart(child).width;
			
			    SpComponentPart(child).current_width -= SpComponentPart(component).border_width;
			
			    if (SpGetNextComponent(child) == NULL) {
				if (spIsSpacingOn(child) == SP_TRUE) {
				    SpComponentPart(child).current_width
					-= MAX(SpComponentPart(component).margin_width,
					       SpComponentPart(child).right_offset);
				} else if (spIsCreated(child) == SP_TRUE
					   && SpComponentPart(child).right_offset > 0) {
				    SpComponentPart(child).current_width
					-= SpComponentPart(child).right_offset;
				}
			    }
			    
			    width += SpComponentPart(child).current_width;

			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				getOptimumWidth(child);
			    }
			} else {
			    wc = SpComponentPart(component).current_width
				- SpComponentPart(child).x + SpComponentPart(child).width;
			
			    wc -= SpComponentPart(component).border_width;
			    
			    if (SpGetNextComponent(child) == NULL) {
				if (spIsSpacingOn(child) == SP_TRUE) {
				    wc -= MAX(SpComponentPart(component).margin_width,
					      SpComponentPart(child).right_offset);
				} else if (spIsCreated(child) == SP_TRUE
					   && SpComponentPart(child).right_offset > 0) {
				    wc -= SpComponentPart(child).right_offset;
				}
			    }
			    
			    if (SpComponentPart(component).prev_width >= 0
				|| (SpGetParent(component) != NULL
				    && SpComponentPart(SpGetParent(component)).prev_width >= 0)) {
				SpComponentPart(child).current_width = wc;
			    
				if (spIsContainer(child) == SP_TRUE
				    && spIsCanvas(child) == SP_FALSE) {
				    getOptimumWidth(child);
				}
			    } else {
				if (spIsContainer(child) == SP_TRUE
				    && spIsCanvas(child) == SP_FALSE) {
				    SpComponentPart(child).current_width
					= MAX(wc, getOptimumWidth(child));
				} else {
				    SpComponentPart(child).current_width
					= MAX(wc, SpComponentPart(child).require_width);
				}
			    }

			    width += SpComponentPart(child).current_width;
			    total_width = width - SpComponentPart(child).width;
			}
		    } else {
			SpComponentPart(child).current_width = SpComponentPart(child).width; 

			if (spIsContainer(child) == SP_TRUE
			    && spIsCanvas(child) == SP_FALSE) {
			    w = getOptimumWidth(child);
			    if (w > SpComponentPart(child).current_width) {
				SpComponentPart(child).current_width = w;
			    }
			}
			
			width += SpComponentPart(child).current_width;
		    }
		    spDebug(50, "getOptimumWidth",
			    "x = %d\n", SpComponentPart(child).x);
		    prev_child = child;
		}

		child = SpGetNextComponent(child);
	    
		if (child == NULL) {
		    if (spIsSpacingOn(prev_child) == SP_TRUE) {
			width += MAX(SpComponentPart(component).margin_width,
				     SpComponentPart(prev_child).right_offset);
		    } else if (spIsCreated(prev_child) == SP_TRUE
			       && SpComponentPart(prev_child).right_offset > 0) {
			width += SpComponentPart(prev_child).right_offset;
		    }
		    width += SpComponentPart(component).border_width;
		    
		    break;
		} else if (spIsResizable(child) == SP_TRUE && flag == 1) {
		    if (spIsSpacingOn(prev_child) == SP_TRUE
			|| spIsSpacingOn(child) == SP_TRUE) {
			width += MAX(SpComponentPart(component).spacing,
				     SpComponentPart(child).left_offset);
		    } else if (SpComponentPart(child).left_offset > 0) {
			width += SpComponentPart(child).left_offset;
		    }
		}
	    }
	} else if (SpComponentPart(component).orientation == SP_VERTICAL) {
	    width = 0;
	    while (child != NULL) {
		if (spIsResizable(child) == SP_TRUE) {
		    w = 0;
		    if (spIsSpacingOn(child) == SP_TRUE) {
			SpComponentPart(child).x = MAX(SpComponentPart(component).margin_width,
						       SpComponentPart(child).left_offset);
		    } else if (SpComponentPart(child).left_offset > 0) {
			SpComponentPart(child).x = SpComponentPart(child).left_offset;
		    } else {
			SpComponentPart(child).x = 0;
		    }
		    SpComponentPart(child).x += SpComponentPart(component).border_width;
		    w += SpComponentPart(child).x;
		    
		    if (SpComponentPart(child).width <= 0) {
			wc = SpComponentPart(component).current_width
			    - SpComponentPart(child).x + SpComponentPart(child).width;

			wc -= SpComponentPart(component).border_width;
			
			if (spIsSpacingOn(child) == SP_TRUE) {
			    wc -= MAX(SpComponentPart(component).margin_width,
				      SpComponentPart(child).right_offset);
			} else {
			    if (SpComponentPart(child).right_offset > 0) {
				wc -= SpComponentPart(child).right_offset;
			    }
			}
		    
			if (SpComponentPart(component).prev_width >= 0
			    || (SpGetParent(component) != NULL
				&& SpComponentPart(SpGetParent(component)).prev_width >= 0)) {
			    SpComponentPart(child).current_width = MAX(wc, 0);

			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				getOptimumWidth(child);
			    }
			} else {
			    if (spIsContainer(child) == SP_TRUE
				&& spIsCanvas(child) == SP_FALSE) {
				SpComponentPart(child).current_width
				    = MAX(wc, getOptimumWidth(child));
			    } else {
				SpComponentPart(child).current_width
				    = MAX(wc, SpComponentPart(child).require_width);
			    }
			}
		    } else {
			SpComponentPart(child).current_width = SpComponentPart(child).width; 

			if (spIsContainer(child) == SP_TRUE
			    && spIsCanvas(child) == SP_FALSE) {
			    getOptimumWidth(child);
			}
		    }
		    w += SpComponentPart(child).current_width;
		    
		    if (spIsSpacingOn(child) == SP_TRUE) {
			w += MAX(SpComponentPart(component).margin_width,
				 SpComponentPart(child).right_offset);
		    } else if (SpComponentPart(child).right_offset > 0) {
			w += SpComponentPart(child).right_offset;
		    }
		    w += SpComponentPart(component).border_width;
		    
		    width = MAX(width, w);
		}
		
		prev_child = child;
		child = SpGetNextComponent(child);
	    }
	}
    } else {
	if (SpComponentPart(component).prev_width >= 0) {
	    width = SpComponentPart(component).width;
	} else {
	    width = MAX(SpComponentPart(component).width,
			SpComponentPart(component).require_width);
	}
    }

    if (total_width < 0) {
	total_width = width;
    }

    return total_width;
}

static spBool getOptimumSize(spComponent component)
{
    int i;
    
    if (spIsResizable(component) == SP_FALSE) return SP_TRUE;

    spDebug(50, "getOptimumSize", "prev_width = %d, prev_height = %d\n",
	    SpComponentPart(component).prev_width,
	    SpComponentPart(component).prev_height);
    
    if (SpComponentPart(component).prev_width >= 0 || SpComponentPart(component).prev_height >= 0) {
	if (spIsWindow(component) == SP_TRUE) {
	    SpComponentPart(component).prev_width = SpComponentPart(component).current_width;
	    SpComponentPart(component).prev_height = SpComponentPart(component).current_height;
	    SpComponentPart(component).current_width = -1;
	    SpComponentPart(component).current_height = -1;
	    SpComponentPart(component).client_width = -1;
	    SpComponentPart(component).client_height = -1;
	    spGetSize(component, NULL, NULL);
	}

	for (i = 0; i < /*3*/4; i++) {
	    getOptimumWidth(component);
	    getOptimumHeight(component);
	}
    } else {
	for (i = 0; i < /*3*/4; i++) {
	    SpComponentPart(component).current_width = getOptimumWidth(component);
	    SpComponentPart(component).current_height = getOptimumHeight(component);
	    spDebug(100, "getOptimumSize", "loop %d: width = %d, height = %d\n",
		    i, SpComponentPart(component).current_width,
		    SpComponentPart(component).current_height);
	}
	spDebug(50, "getOptimumSize", "width = %d, height = %d\n",
                SpComponentPart(component).current_width,
		SpComponentPart(component).current_height);
    }

    if (spIsWindow(component) == SP_TRUE) {
	if (spIsVisible(SpFramePart(component).menu_bar) == SP_TRUE) {
	    SpComponentPart(SpFramePart(component).menu_bar).x = 0;
	    SpComponentPart(SpFramePart(component).menu_bar).y = 0;
	    SpComponentPart(SpFramePart(component).menu_bar).current_width
		= SpComponentPart(component).current_width;
	    SpComponentPart(SpFramePart(component).menu_bar).current_height
		= SP_DEFAULT_MENU_BAR_HEIGHT;
	    spDebug(50, "getOptimumSize", "menu_bar: width = %d\n",
		    SpComponentPart(component).current_width);
	}
	
	if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
	    SpComponentPart(SpFramePart(component).status_bar).x = 0;
	    SpComponentPart(SpFramePart(component).status_bar).y =
		SpComponentPart(component).current_height;
	    SpComponentPart(SpFramePart(component).status_bar).current_width
		= SpComponentPart(component).current_width;
	    SpComponentPart(SpFramePart(component).status_bar).current_height
		= SP_DEFAULT_STATUS_BAR_HEIGHT;
	}

#if 0
	if (spIsVisible(SpFramePart(component).tool_bar) == SP_TRUE) {
	    SpComponentPart(SpFramePart(component).tool_bar).x = 0;
	    SpComponentPart(SpFramePart(component).tool_bar).y = 0;
	    SpComponentPart(SpFramePart(component).tool_bar).current_width
		= SpComponentPart(component).current_width;
	}
#endif
    }

    return SP_TRUE;
}

void spAdjustComponentSize(spComponent component)
{
    if (spIsCreated(component) == SP_TRUE
	&& SpComponentPart(component).geometry_flag == SP_FALSE) {
	getOptimumSize(component);
	setComponentsSize(component);
    }

    spDebug(80, "spAdjustComponentSize", "done\n");
    
    return;
}

spBool spIsWindow(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    return SpGetComponentClass(component)->component.window_flag;
}

void spDestroyWindow(spComponent component)
{
    if (component == NULL) return;
    spDestroyComponent(SpGetWindow(component));
    return;
}

void spDestroyAllWindow(void)
{
    spComponent window, next_window;

    spDebug(80, "spDestroyAllWindow", "in\n");
    
    window = spGetWindow(spGetChild(NULL));
    
    while (window != NULL) {
	next_window = spGetNextWindow(window, SP_TRUE);
	if (next_window == window) {
	    next_window = NULL;
	}
	spDebug(80, "spDestroyAllWindow", "title = %s\n", spGetTitle(window));
	spDestroyWindow(window);
	window = next_window;
    }
    
    spDebug(80, "spDestroyAllWindow", "done\n");
    
    return;
}

void spCloseWindow(spComponent component)
{
    spBool flag = SP_TRUE;
    spCallbackReason reason = SP_CR_NONE;
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);
    
    if (spIsLastWindow(window) == SP_TRUE
	|| spIsSubClass(window, SpMainFrame) == SP_TRUE) { /* 2000/7/20 added */
	reason = spGetCallbackReason(component);
	if (reason == SP_CR_ACTIVATE) {
	    spDebug(30, "spCloseWindow", "exit_prompt = %d\n",
		    SpTopLevelPart(sp_toplevel).exit_prompt);
	    if (SpTopLevelPart(sp_toplevel).exit_prompt == SP_TRUE) {
		if (spCreateMessageBox(/*window*/NULL, SP_QUIT_QUESTION_TITLE,
				       SP_QUIT_QUESTION_MESSAGE,
				       SppDialogType, SP_QUESTION_DIALOG,
				       SppMessageBoxButtonType, SP_MB_YES_NO,
				       NULL) != SP_DR_YES) {
		    flag = SP_FALSE;
		}
	    }
	}

	if (flag == SP_TRUE) {
	    /*SpComponentPart(window).visible_flag = SP_FALSE;*/
	    spDebug(50, "spCloseWindow", "quit program\n");
	    spDestroyComponent(window);
	    spQuit(0);
	}
    } else {
	reason = spGetCallbackReason(component);
	if (reason == SP_CR_ACTIVATE) {
	    spDebug(50, "spCloseWindow", "close_prompt = %d\n",
		    SpTopLevelPart(sp_toplevel).close_prompt);
	    if (SpTopLevelPart(sp_toplevel).close_prompt == SP_TRUE) {
		if (spCreateMessageBox(window, SP_CLOSE_QUESTION_TITLE,
				       SP_CLOSE_QUESTION_MESSAGE,
				       SppDialogType, SP_QUESTION_DIALOG,
				       SppMessageBoxButtonType, SP_MB_YES_NO,
				       NULL) == SP_DR_YES) {
		    flag = SP_TRUE;
		} else {
		    flag = SP_FALSE;
		}
	    }
	}
	
	if (flag == SP_TRUE) {
	    /*SpComponentPart(window).visible_flag = SP_FALSE;*/
	    spDestroyComponent(window);
	}
    }
    
    return;
}

static void popupWindow(spComponent component, spBool move_cursor)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return;
    
    SpComponentPart(window).visible_flag = SP_TRUE;
    spPopupFrameArch(window, move_cursor);
    
    return;
}

void spPopupWindow(spComponent component)
{
    popupWindow(component, SP_TRUE);
    return;
}

void spPopdownWindow(spComponent component)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);
    
    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE
	|| spIsVisible(window) == SP_FALSE) return;

    /*SpComponentPart(window).visible_flag = SP_FALSE;*/
    spPopdownFrameArch(window);
    SpComponentPart(window).visible_flag = SP_FALSE;
    
    return;
}

void spMapWindow(spComponent component)
{
    popupWindow(component, SP_FALSE);
    return;
}

void spUnmapWindow(spComponent component)
{
    spPopdownWindow(component);
    return;
}

void spRaiseWindow(spComponent component)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE
	|| SpComponentPart(window).visible_flag == SP_FALSE) return;
    
    spRaiseFrameArch(window);
    
    return;
}

void spLowerWindow(spComponent component)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE
	|| SpComponentPart(window).visible_flag == SP_FALSE) return;
    
    spLowerFrameArch(window);
    
    return;
}

spBool spIsTaskTrayVisible(spComponent component)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return SP_FALSE;

    return SpFramePart(window).task_tray_visible;
}

spBool spShowTaskTray(spComponent component, spBool flag)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return SP_FALSE;

    if (spShowTaskTrayArch(window, flag) == SP_TRUE) {
	SpFramePart(window).task_tray_visible = flag;
	return SP_TRUE;
    }

    return SP_FALSE;
}

static void clearPrevSize(spComponent component)
{
    spComponent next;

    if (component == NULL) {
	return;
    }

    next = SpGetChild(component);
    while (next != NULL) {
	clearPrevSize(next);
	next = SpGetNextComponent(next);
    }

    SpComponentPart(component).geometry_flag = SP_FALSE;
    
    SpComponentPart(component).prev_width = -1;
    SpComponentPart(component).prev_height = -1;
    SpComponentPart(component).current_width = -1;
    SpComponentPart(component).current_height = -1;

    return;
}

void spAdjustWindowSize(spComponent component)
{
    spComponent window;
    
    spDebug(80, "spAdjustWindowSize", "in\n");
    
    if (spIsCreated(component) == SP_FALSE) return;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE) return;

#if 0
    clearPrevSize(window);
#endif
    spAdjustComponentSize(window);

    return;
}

spBool spAllocateSize(spComponent component, int width, int height)
{
    spComponent window;
    
    spDebug(80, "spAllocateSize", "in\n");
    
    if (spIsCreated(component) == SP_FALSE || (width <= 0 && height <= 0)) {
	return SP_FALSE;
    }

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE) return SP_FALSE;

    SpComponentPart(component).client_width = -1;
    SpComponentPart(component).client_height = -1;
    if (width > 0) {
	SpComponentPart(component).prev_width = SpComponentPart(component).current_width;
	SpComponentPart(component).current_width = width;
	if (spIsCanvas(component) == SP_TRUE
	    || spIsContainer(component) == SP_FALSE) {
	    SpComponentPart(component).require_width = width;
	}
    }
    if (height > 0) {
	SpComponentPart(component).prev_height = SpComponentPart(component).current_height;
	SpComponentPart(component).current_height = height;
	if (spIsCanvas(component) == SP_TRUE
	    || spIsContainer(component) == SP_FALSE) {
	    SpComponentPart(component).require_height = height;
	}
    }

    clearPrevSize(window);
    spAdjustComponentSize(window);

    return SP_TRUE;
}

spBool spSetWindowPosition(spComponent component, int x, int y)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return SP_FALSE;

    SpComponentPart(window).x = x;
    SpComponentPart(window).y = y;
    if (spIsVisible(window) == SP_TRUE) {
	return spSetFramePositionArch(window, x, y);
    }
    
    return SP_TRUE;
}

spBool spGetWindowPosition(spComponent component, int *x, int *y)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    window = SpGetWindow(component);

    if (spIsCreated(window) == SP_FALSE
	|| spIsFrame(window) == SP_FALSE) return SP_FALSE;
    
    if (spIsVisible(window) == SP_TRUE) {
	if (spGetFramePositionArch(window,
				   &SpComponentPart(window).x,
				   &SpComponentPart(window).y) == SP_TRUE) {
	    if (x != NULL) *x = SpComponentPart(window).x;
	    if (y != NULL) *y = SpComponentPart(window).y;
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

void spDestroyWindowCB(spComponent component, void *data)
{
    spDestroyWindow(component);
    return;
}

void spCloseWindowCB(spComponent component, void *data)
{
    spDebug(80, "spCloseWindowCB", "in\n");
    spCloseWindow(component);
    return;
}

void spPopupWindowCB(spComponent component, void *data)
{
    spPopupWindow(component);
    return;
}

void spPopdownWindowCB(spComponent component, void *data)
{
    spPopdownWindow(component);
    return;
}

spComponent spGetNextWindow(spComponent component, spBool dialog_flag)
{
    spComponent current, next;

    if (sp_components == NULL
	|| spIsWindow(component) == SP_FALSE) return NULL;

    next = NULL;
    current = component;
    while (1) {
	if ((next = SpGetNextComponent(current)) == NULL) {
	    if (SpGetParent(current) != NULL) {
		next = SpGetChild(SpGetParent(current));
	    } else {
		next = sp_components->child;
	    }
	}
	
	if (!(spIsFrame(next) == SP_TRUE && SpFramePart(next).internal_flag == SP_TRUE)) {
	    if (next == NULL
		|| (dialog_flag == SP_TRUE && spIsWindow(next) == SP_TRUE)
		|| (spIsDialog(next) == SP_FALSE && spIsWindow(next) == SP_TRUE)) {
		break;
	    }
	} 
	current = next;
    }
    
    return next;
}

spComponent spGetPrevWindow(spComponent component, spBool dialog_flag)
{
    spComponent current, prev;

    if (sp_components == NULL
	|| spIsWindow(component) == SP_FALSE) return NULL;

    prev = NULL;
    current = component;
    while (1) {
	if ((prev = SpGetPrevComponent(current)) == NULL) {
	    if (SpGetParent(current) != NULL) {
		prev = SpGetLastChild(SpGetParent(current));
	    } else {
		prev = sp_components->last_child;
	    }
	}

	if (!(spIsFrame(prev) == SP_TRUE && SpFramePart(prev).internal_flag == SP_TRUE)) {
	    if (prev == NULL
		|| (dialog_flag == SP_TRUE && spIsWindow(prev) == SP_TRUE)
		|| (spIsDialog(prev) == SP_FALSE && spIsWindow(prev) == SP_TRUE)) {
		break;
	    }
	} 
	current = prev;
    }
    
    return prev;
}

void spPopupNextWindow(spComponent component, spBool dialog_flag)
{
    spComponent next = NULL;
    
    next = spGetNextWindow(SpGetWindow(component), dialog_flag);
    if (next != NULL) spPopupWindow(next);
    
    return;
}

void spPopupPrevWindow(spComponent component, spBool dialog_flag)
{
    spComponent prev = NULL;
    
    prev = spGetPrevWindow(SpGetWindow(component), dialog_flag);
    if (prev != NULL) spPopupWindow(prev);
    
    return;
}

spBool spIsLastWindow(spComponent component)
{
    int flag = 0;
    long num_window = 0;
    long num_dialog = 0;
    spComponent child;

    if (sp_components == NULL || spIsCreated(component) == SP_FALSE)
	return SP_FALSE;

    if (spIsWindow(component) == SP_FALSE) {
	component = SpGetWindow(component);
	if (spIsCreated(component) == SP_FALSE)
	    return SP_FALSE;
    }

    child = sp_components->child;
    while (child != NULL) {
	if (!(spIsFrame(child) == SP_TRUE && SpFramePart(child).internal_flag == SP_TRUE)
	    && spIsCreated(child) == SP_TRUE) {
	    if (child == component) {
		flag = 1;
	    }
	    ++num_window;
	    if (spIsDialog(child) == SP_TRUE) {
		++num_dialog;
	    }
	}
	child = SpGetNextComponent(child);
    }

    spDebug(50, "spIsLastWindow", "flag = %d, num_window = %ld, num_dialog = %ld\n",
	    flag, num_window, num_dialog);

    if (flag && num_window - num_dialog <= 1)
	return SP_TRUE;
    else
	return SP_FALSE;
}
