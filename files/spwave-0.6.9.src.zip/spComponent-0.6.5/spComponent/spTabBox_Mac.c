/*
 *	spTabBox_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spDrawP.h>
#include <sp/spFrameP.h>
#include <sp/spListP.h>
#include <sp/spComboBoxP.h>
#include <sp/spTabBoxP.h>

spBool spTabSelectionLoopMac(spComponent component)
{
    Point point;
    EventRecord event;
    WindowPtr window;
    GrafPtr save_port;
    spBool flag = SP_FALSE;

    if (SpPrimitiveArch(component).region == NULL) return SP_FALSE;
    
    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    InvertRgn(SpPrimitiveArch(component).region);
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    while (1) {
	if (WaitNextEvent(everyEvent, &event, 1L, 0L)) {
	    if (event.what == mouseUp) {
		spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
		InvertRgn(SpPrimitiveArch(component).region);
		spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
		
		if (FindWindow(event.where, &window) == inContent) {
		    point = event.where;
		    spLockWindowPort(window, &save_port);
		    GlobalToLocal(&point);
		    
		    if (PtInRgn(point, SpPrimitiveArch(component).region)) {
			flag = SP_TRUE;
		    }
		    
		    spUnlockWindowPort(window, save_port);
		}
		break;
	    }
	}
    }
    
    return flag;
}

static int mapTabItem(spComponent component, int index)
{
    spComponent child;
    spComponent selected_tab = NULL;
    RgnHandle orig_rgn;
    GrafPtr save_port;
    Rect null_rect = {0, 0, 0, 0};
    
    if (spIsTabBox(component) == SP_FALSE || index < 0
	|| spIsCreated(component) == SP_FALSE) return -1;

    child = SpGetChild(component);

    while (child != NULL) {
	if (SpPrimitivePart(child).index == index) {
	    selected_tab = child;

#if 1
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	    orig_rgn = NewRgn();
	    GetClip(orig_rgn);
	    ClipRect(&null_rect);
	    
	    if (1 || spIsAquaMac() == SP_TRUE) {
		spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	    }
#endif

	    child = SpGetChild(component);
	    while (child != NULL) {
		SpComponentPart(child).geometry_flag = SP_TRUE;
		if (child != selected_tab) {
		    spUnmapComponent(child);
		} else {
		    SpComponentPart(child).visible_flag = SP_TRUE;
		}
		SpComponentPart(child).geometry_flag = SP_FALSE;
		
		child = SpGetNextComponent(child);
	    }

	    /*spAdjustComponentSize(SpGetWindow(component));*/
	    spAdjustComponentSize(component);
	    SpComponentPart(selected_tab).visible_flag = SP_FALSE;
	    
	    SpComponentPart(selected_tab).geometry_flag = SP_TRUE;
	    spMapComponent(selected_tab);
	    SpComponentPart(selected_tab).geometry_flag = SP_FALSE;

#if 1
	    if (1 || spIsAquaMac() == SP_TRUE) {
		spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	    }
	    SetClip(orig_rgn);
	    DisposeRgn(orig_rgn);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
#endif
	    
	    spDebug(30, "mapTabItem", "index = %d\n", index);
	    return index;
	}

	child = SpGetNextComponent(child);
    }
    
    return -1;
}

spBool spSelectTabItemMac(spComponent component, ControlPartCode part)
{
    int i;
    Rect rect;
    ControlRef control;
    spComponent child;
    spBool flag = SP_FALSE;

    if ((control = SpPrimitiveArch(component).control) == NULL) return SP_FALSE;
    
    child = SpGetChild(component);
    
    for (i = 1; child != NULL; i++) {
	if (i == part) {
	    
	    SpTabBoxPart(component).selected_index = i - 1;
	    spDebug(30, "spSelectTabItemMac", "selected_index = %d\n", SpTabBoxPart(component).selected_index);
	    mapTabItem(component, SpTabBoxPart(component).selected_index);

	    spInvalWindowMac(SpPrimitiveArch(SpGetWindow(component)).window, NULL);
    
	    spGetControlRectMac(control, &rect);
	    rect.bottom = rect.top + 22; /* originally 21 pixels */
	    spDebug(30, "spSelectTabItemMac", "rect.bottom = %d\n", rect.bottom);
	    
	    spValidRectMac(SpPrimitiveArch(SpGetWindow(component)).window, &rect);
	    
	    flag = SP_TRUE;
	    
	    break;
	}

	child = SpGetNextComponent(child);
    }

    return flag;
}

spBool spSelectTabBoxMac(spComponent component, Point point)
{
    int i;
    spBool flag = SP_FALSE;
    ControlPartCode part;
    spComponent window;
    spComponent child;
    
    if (spIsTabBox(component) == SP_FALSE) {
	return SP_FALSE;
    }

    if (SpPrimitiveArch(component).control != NULL) {
	ControlRef control;
	GrafPtr old_port;
	
	window = SpGetWindow(component);
	part = FindControl(point, SpPrimitiveArch(window).window, &control);
	spDebug(50, "spSelectTabBoxMac", "found part = %d\n", part);
	
	if (part != kControlNoPart
	    && control == SpPrimitiveArch(component).control) {
	    old_port = spThreadLeaveMac(nil);
	    part = TrackControl(control, point, (ControlActionUPP)-1);
	    spThreadEnterMac(old_port);
	    spDebug(50, "spSelectTabBoxMac", "track part = %d\n", part);

	    if (spSelectTabItemMac(component, part) == SP_TRUE) {
		flag = SP_TRUE;
	    }
	}
    } else {
	child = SpGetChild(component);
	
	for (i = 0; child != NULL; i++) {
	    if (SpPrimitiveArch(child).region != NULL
		&& PtInRgn(point, SpPrimitiveArch(child).region)) {
		if (i != SpTabBoxPart(component).selected_index) {
		    if (spTabSelectionLoopMac(child) == SP_TRUE) {
			SpTabBoxPart(component).selected_index = i;
			mapTabItem(component, SpTabBoxPart(component).selected_index);

			spInvalWindowMac(SpPrimitiveArch(SpGetWindow(component)).window, NULL);
			
			flag = SP_TRUE;
		    }
		}
		break;
	    }

	    child = SpGetNextComponent(child);
	}
    }
    
    return flag;
}

static int drawTab(int x, int y, int xoffset, int yoffset, 
		   char *label, spBool draw_label,
		   spBool draw_left, spBool draw_right, spBool draw_bottom)
{
    int tx;
    int taper;
    int corner;
    int lwidth;
    int lmargin;

    taper = SP_TAB_TAPER;
    lmargin = SP_TAB_LABEL_MARGIN;
    corner = SP_TAB_CORNER_SIZE;

    lwidth = TextWidth(label, 0, strlen(label)) + 2 * lmargin;
    
    tx = xoffset;
    
    /* draw left bound */
    if (draw_left == SP_TRUE) {
	MoveTo(tx, y + yoffset);
    } else {
	MoveTo(tx + taper / 2, y + yoffset / 2);
    }
    LineTo(tx + taper - corner, y + 2 * corner);
    LineTo(tx + taper + corner, y);
    tx += taper;

    /* draw top bound */
    LineTo(tx + lwidth - corner, y);

    /* draw label */
    if (draw_label == SP_TRUE) {
	MoveTo(tx + lmargin, y + yoffset - SP_TAB_LABEL_BOTTOM_OFFSET);
	DrawText(label, 0, strlen(label));
	spDebug(50, "drawTab", "label = %s\n", label);
    }

    /* draw bottom bound */
    if (draw_bottom == SP_TRUE) {
	if (draw_left == SP_TRUE) {
	    MoveTo(xoffset, y + yoffset);
	} else {
	    MoveTo(tx, y + yoffset);
	}
	if (draw_right == SP_TRUE) {
	    LineTo(tx + lwidth + taper, y + yoffset);
	} else {
	    LineTo(tx + lwidth, y + yoffset);
	}
    }
    tx += lwidth;

    /* draw right bound */
    MoveTo(tx - corner, y);
    LineTo(tx + corner, y + 2 * corner);
    if (draw_right == SP_TRUE) {
	LineTo(tx + taper, y + yoffset);
    } else {
	LineTo(tx + taper / 2, y + yoffset / 2);
    }

    return tx;
}

static void embedControls(spComponent tab_item, spComponent parent)
{
    spComponent child;

    child = SpGetChild(parent);
    while (child != NULL) {
	if (spIsPrimitive(child) == SP_TRUE) {
	    if (SpPrimitiveArch(child).control != NULL) {
		EmbedControl(SpPrimitiveArch(child).control,
			     SpPrimitiveArch(SpGetParent(tab_item)).control);
	    }
	    if (spIsComboBox(child) == SP_TRUE
		&& SpComboBoxArch(child).button != NULL) {
		EmbedControl(SpComboBoxArch(child).button,
			     SpPrimitiveArch(SpGetParent(tab_item)).control);
	    }
	}
	embedControls(tab_item, child);
	child = SpGetNextComponent(child);
    }
    
    return;
}

void spDrawTabBoxMac(spComponent component, spBool erase_flag)
{
    GrafPtr save_port;
    
    spDebug(50, "spDrawTabBoxMac", "in\n");
	
    if (SpPrimitiveArch(component).control != NULL) {
	int i;
	char *title;
	spComponent window, child;
	Rect rect;
	ControlTabInfoRec tabinfo;
	RgnHandle orig_rgn;
	Rect null_rect = {0, 0, 0, 0};
	    
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);

	if (GetControlMaximum(SpPrimitiveArch(component).control) <= 0) {
	    rect = SpPrimitiveArch(component).rect;
	    EraseRect(&rect);

	    orig_rgn = NewRgn();
	    GetClip(orig_rgn);
	    ClipRect(&null_rect);

	    SetControlMaximum(SpPrimitiveArch(component).control,
			      SpTabBoxPart(component).num_item);
	    
	    spDebug(50, "spDrawTabBoxMac", "set tab info: num_item = %d\n",
		    SpTabBoxPart(component).num_item);
	    
	    window = SpGetWindow(component);
	    child = SpGetChild(component);
	    for (i = 1; i <= SpTabBoxPart(component).num_item; i++) {
		if (child == NULL) break;

		embedControls(child, child);
		
		title = spGetTitle(child);
		spDebug(50, "spDrawTabBoxMac", "title = %s\n", title);
		
		tabinfo.version = 0;
		tabinfo.iconSuiteID = 0;
		spStrCToP(title, tabinfo.name);
		SetControlData(SpPrimitiveArch(component).control,
			       i, kControlTabInfoTag,
			       sizeof(ControlTabInfoRec), (Ptr)&tabinfo);
	    
		child = SpGetNextComponent(child);
	    }
    
	    SetClip(orig_rgn);
	    DisposeRgn(orig_rgn);
	} else {
	    if (erase_flag == SP_TRUE) {
		rect = SpPrimitiveArch(component).rect;
		EraseRect(&rect);
	    }
	}
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	
	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	    spHiliteControlMac(SpPrimitiveArch(component).control, SP_FALSE);
	} else {
	    spHiliteControlMac(SpPrimitiveArch(component).control, SP_TRUE);
	}
	
	spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
				     SpPrimitiveArch(SpGetWindow(component)).window);
    } else {
	char *title;
	int i;
	int border_width;
	int x, y;
	int width, height;
	int xoffset, yoffset;
	spBool sensitive_flag = SP_TRUE;
	spBool draw_left, draw_right, draw_bottom;
	spComponent child;
	
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    
	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	    sensitive_flag = SP_FALSE;
	}
	
	border_width = SpComponentPart(component).border_width - 1;
	x = SpPrimitiveArch(component).rect.left + border_width;
	y = SpPrimitiveArch(component).rect.top + border_width;
	width = SpComponentPart(component).current_width - 2 * border_width;
	height = SpComponentPart(component).current_height - 2 * border_width;
	yoffset = SP_DEFAULT_TAB_HEIGHT - border_width;
	spDebug(50, "spDrawTabBoxMac", "x = %d, y = %d, width = %d, height = %d\n",
		x, y, width, height);
	
	if (erase_flag == SP_TRUE) {
	    EraseRect(&SpPrimitiveArch(component).rect);
	}
	
	if (sensitive_flag == SP_FALSE) {
	    spGetOriginalRGBMac();
	    spSetDeactivateRGBMac();
	}
	
	/* draw main frame */
	MoveTo(x, y + yoffset);
	LineTo(x, y + height);
	LineTo(x + width, y + height);
	LineTo(x + width, y + yoffset);
	
	/* draw tab */
	child = SpGetChild(component);
	xoffset = x;
	for (i = 0; child != NULL; i++) {
	    title = spGetTitle(child);
	    if (i == 0 || i == SpTabBoxPart(component).selected_index) {
		draw_left = SP_TRUE;
	    } else {
		draw_left = SP_FALSE;
	    }
	    if (i == SpTabBoxPart(component).selected_index) {
		draw_bottom = SP_FALSE;
	    } else {
		draw_bottom = SP_TRUE;
	    }
	    if (i + 1 == SpTabBoxPart(component).selected_index) {
		draw_right = SP_FALSE;
	    } else {
		draw_right = SP_TRUE;
	    }
	    if (SpPrimitiveArch(child).region == NULL) {
		SpPrimitiveArch(child).region = NewRgn();
	    }
	    OpenRgn();
	    drawTab(x, y, xoffset, yoffset, title, SP_FALSE,
		    SP_TRUE, SP_TRUE, SP_TRUE);
	    CloseRgn(SpPrimitiveArch(child).region);
	    xoffset = drawTab(x, y, xoffset, yoffset, title, SP_TRUE,
			      draw_left, draw_right, draw_bottom);

	    child = SpGetNextComponent(child);
	}
	
	MoveTo(x + xoffset + SP_TAB_TAPER - 1, y + yoffset);
	LineTo(x + width, y + yoffset);
	
	if (sensitive_flag == SP_FALSE) {
	    spSetOriginalRGBMac();
	}
    
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    }
    
    spDebug(50, "spDrawTabBoxMac", "done\n");
    
    return;
}

void spTabBoxPartInitArch(spComponent component)
{
    SpTabBoxArch(component).root_control = NULL;
    
    return;
}

void spTabBoxPartFreeArch(spComponent component)
{
    return;
}

void spTabBoxCreateArch(spComponent component)
{
    SpComponentPart(component).border_width = 4;
    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);

    if (spGetAppearanceVersionMac() >= 0x00000101) {
	spComponent window;
	Rect rect;
	OSErr err;

	if (spIsAquaMac() == SP_TRUE) {
	    SpComponentPart(component).border_width = 10;
	}
	
	window = SpGetWindow(component);

	rect = SpPrimitiveArch(component).rect;
	
	if ((err = GetRootControl(SpPrimitiveArch(window).window,
				  &SpTabBoxArch(component).root_control)) != noErr) {
	    SpTabBoxArch(component).root_control = NULL;
	    spDebug(50, "spTabBoxCreateArch", "err = %d\n", err);
	}

	rect = SpPrimitiveArch(component).rect;
	
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(window).window,
		       &rect, "\p", spIsVisibleMac(component),
		       0, 0, 0, kControlTabLargeProc, 0);
    }

    if (SpPrimitiveArch(component).control != NULL) {
	spSetReferenceMac(component);
    }
    
    spSetNeedUpdateMac(component);
    
    return;
}

void spTabBoxSetParamsArch(spComponent component)
{
    return;
}

void spTabBoxDestroyArch(spComponent component)
{
    return;
}

int spGetSelectedTabIndexArch(spComponent component)
{
    return SpTabBoxPart(component).selected_index;
}

void spAddTabItemArch(spComponent component, int index)
{
    SpComponentPart(component).top_offset += SP_DEFAULT_TAB_HEIGHT;
    SpComponentPart(component).top_offset += SpParentComponentPart(component).border_width;

    return;
}
