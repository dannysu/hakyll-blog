/*
 *	spTopLevel.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>
#include <sp/spTopLevelP.h>
#include <sp/spComponentP.h>

spTopLevel sp_toplevel = NULL;

static spParamTable sp_toplevel_param_tables[] = {
    {SppLanguage, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.language), NULL},
    {SppIconName, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.icon_name), NULL},
    {SppInformation, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.information), NULL},
    {SppAltCtrlSwap, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.alt_ctrl_swap), NULL},
    {SppExitPrompt, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.exit_prompt), NULL},
    {SppClosePrompt, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.close_prompt), NULL},
    {SppModifiedClosePrompt, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.modify_prompt), NULL},
    {SppThreadSafe, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.thread_safe), NULL},
    {SppUseWindowMenu, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spTopLevel, toplevel.use_window_menu), NULL},
};

spTopLevelClassRec SpTopLevelClassRec = {
    /* spObjectClassPart */
    {
	SpTopLevel,
	NULL,
	sizeof(spTopLevelRec),
	spArraySize(sp_toplevel_param_tables),
	sp_toplevel_param_tables,
	spTopLevelPartInit,
	spTopLevelPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spTopLevelCreate,
	spTopLevelDestroy,
	spTopLevelSetParams,
	NULL,
    },
    /* spTopLevelClassPart */
    {
	0,
    },
};

spObjectClass SpTopLevelClass = (spObjectClass)&SpTopLevelClassRec;

void spTopLevelPartInit(spObject object)
{
    spTopLevel toplevel = (spTopLevel)object;
    
    spDebug(60, "spTopLevelPartInit", "in\n");
    SpTopLevelPart(toplevel).argcp = NULL;
    SpTopLevelPart(toplevel).argvp = NULL;
    SpTopLevelPart(toplevel).graphics = NULL;
    SpTopLevelPart(toplevel).last_graphics = NULL;

    SpTopLevelPart(toplevel).alt_ctrl_swap = SP_FALSE;
    SpTopLevelPart(toplevel).exit_prompt = SP_TRUE;
    SpTopLevelPart(toplevel).close_prompt = SP_FALSE;
    SpTopLevelPart(toplevel).modify_prompt = SP_TRUE;
    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
    SpTopLevelPart(toplevel).use_window_menu = SP_FALSE;
    SpTopLevelPart(toplevel).language = NULL;
    SpTopLevelPart(toplevel).icon_name = NULL;
    SpTopLevelPart(toplevel).information = NULL;
    
    spTopLevelPartInitArch(toplevel);

    return;
}

void spTopLevelPartFree(spObject object)
{
    spTopLevel toplevel = (spTopLevel)object;
    
    spTopLevelPartFreeArch(toplevel);

    return;
}

void spTopLevelCreate(spObject object)
{
    spTopLevel toplevel = (spTopLevel)object;

    spDebug(50, "spTopLevelCreate", "in\n");
    
    if (toplevel != NULL && spIsObjectCreated(object) == SP_FALSE) {
	spSetMessageFlag(0);
	spSetLanguage(SpTopLevelPart(toplevel).language);
	spTopLevelCreateArch(toplevel);
    }

    return;
}

void spTopLevelSetParams(spObject object)
{
    spTopLevel toplevel = (spTopLevel)object;

    if (toplevel != NULL) {
	spTopLevelSetParamsArch(toplevel);
    }

    return;
}

void spTopLevelDestroy(spObject object)
{
    spTopLevel toplevel = (spTopLevel)object;

    if (toplevel != NULL) {
	spTopLevelDestroyArch(toplevel);
    }

    return;
}

int spWaitEvent(spTopLevel toplevel)
{
    if (toplevel == NULL) return 0;

    return spWaitEventArch(toplevel);
}

int spDispatchEvent(spTopLevel toplevel)
{
    if (toplevel == NULL) return 0;

    return spDispatchEventArch(toplevel);
}

int spMainLoop(spTopLevel toplevel)
{
    if (toplevel == NULL) spError(1, "You should call spInitialize.\n");

    spDebug(80, "spMainLoop", "in\n");
    
    spSetInitSenseLevel();
    
    return spMainLoopArch(toplevel);
}

static char sp_default_name[SP_MAX_LINE] = "Application";

spTopLevel spInitializeArg(int *argcp, char ***argvp, spArg *args, int num_arg)
{
    char **argv;
    char *progname;

    if (argcp == NULL || argvp == NULL) {
	progname = sp_default_name;
    } else {
	argv = *argvp;
	progname = spGetBaseName(argv[0]);
    }

    if ((sp_toplevel = (spTopLevel)spAllocObject((spObjectClass)SpTopLevelClass,
						 NULL, progname)) == NULL) {
	return NULL;
    }

    spDebug(60, "spInitializeArg", "spAllocObject done\n");
    
    SpTopLevelPart(sp_toplevel).argcp = argcp;
    SpTopLevelPart(sp_toplevel).argvp = argvp;

    spSetObjectParamsArg((spObject)sp_toplevel, args, num_arg);

    return sp_toplevel;
}

spTopLevel spInitialize(int *argcp, char ***argvp, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    va_start(argp, argvp);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spInitializeArg(argcp, argvp, args, num_arg);
}

void spSetTopLevelParamsArg(spTopLevel toplevel, spArg *args, int num_arg)
{
    spSetObjectParamsArg((spObject)toplevel, args, num_arg);
    return;
}

void spGetTopLevelParamsArg(spTopLevel toplevel, spArg *args, int num_arg)
{
    spGetObjectParamsArg((spObject)toplevel, args, num_arg);
    return;
}
    
void spSetTopLevelParams(spTopLevel toplevel, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (toplevel == NULL) return;
    
    va_start(argp, toplevel);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spSetTopLevelParamsArg(toplevel, args, num_arg);

    return;
}
    
void spGetTopLevelParams(spTopLevel toplevel, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (toplevel == NULL) return;
    
    va_start(argp, toplevel);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spGetTopLevelParamsArg(toplevel, args, num_arg);

    return;
}

void spQuit(int status)
{
    spDestroyAllWindow();
    spQuitArch(status);
    spFreeStringTable();
    spExit(status);
    return;
}

spBool spIsTopLevelCreated(void)
{
    if (sp_toplevel == NULL) {
	return SP_FALSE;
    }
    
    return spIsObjectCreated((spObject)sp_toplevel);
}

spBool spIsThreadSafe(void)
{
    if (sp_toplevel == NULL) return SP_FALSE;
    
    return SpTopLevelPart(sp_toplevel).thread_safe;
}

void spThreadEnter(void)
{
    if (sp_toplevel == NULL) return;
    
    if (SpTopLevelPart(sp_toplevel).thread_safe == SP_TRUE) {
	spThreadEnterArch(sp_toplevel);
    }
    return;
}

void spThreadLeave(void)
{
    if (sp_toplevel == NULL) return;
    
    if (SpTopLevelPart(sp_toplevel).thread_safe == SP_TRUE) {
	spThreadLeaveArch(sp_toplevel);
    }
    return;
}
