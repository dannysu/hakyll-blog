/*
 *	spDraw.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spCanvasP.h>
#include <sp/spDrawP.h>

void spImageCreate(spComponent component)
{
    if (component == NULL) return;

    if (spIsCreated(component) == SP_FALSE) {
	spImageCreateArch(component);
	SpObjectPart(component).create_flag = SP_TRUE;
    }
    
    if (SpComponentPart(component).call_func != NULL) {
	SpPrimitivePart(component).draw_func = SpComponentPart(component).call_func;
	SpPrimitivePart(component).draw_data = SpComponentPart(component).call_data;
    }
    spRedrawImage(component, SpComponentPart(component).width, SpComponentPart(component).height);

    return;
}

spComponent spCreateImage(spComponent parent, char *name,
			  int width, int height, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    spSetArg(args[num_arg], SppWidth, width); num_arg++;
    spSetArg(args[num_arg], SppHeight, height); num_arg++;

    va_start(argp, height);
    spGetArgs(argp, args, num_arg);
    va_end(argp);
    
    return spCreateComponentArg(SpPrimitiveClass, SpImage, name, parent, args, num_arg);
}

void spDrawImage(spComponent component)
{
    if (spIsDrawable(component) == SP_FALSE) return;
    
    spDebug(30, "spDrawImage", "in\n");

    if (!(spIsCanvas(component) == SP_TRUE && SpCanvasPart(component).draw_background == SP_FALSE)) {
	spDrawImageArch(component);
    }
    
    if (SpPrimitivePart(component).draw_func != NULL) {
	spDebug(30, "spDrawImage", "call draw_func\n");
	SpPrimitivePart(component).draw_func(component, SpPrimitivePart(component).draw_data);
    }
    
    spDebug(30, "spDrawImage", "done\n");
    
    return;
}

void spRedrawImage(spComponent component, int width, int height)
{
    if (component == NULL) return;
    
    if ((SpComponentPart(component).client_width != width && width > 0) ||
	(SpComponentPart(component).client_height != height && height > 0)) {
	SpComponentPart(component).client_width = width;
	SpComponentPart(component).client_height = height;

	spRedrawImageArch(component);
    }
    
    spDrawImage(component);
    
    return;
}

void spResizeImage(spComponent component, int width, int height)
{
    if (component == NULL) return;
    
    if (SpComponentPart(component).client_width != width
	|| SpComponentPart(component).client_height != height) {
	spRedrawImage(component, width, height);
    }
    
    return;
}

void spCopyImage(spComponent src, spComponent dest,
		 int src_x, int src_y, int width, int height,
		 int dest_x, int dest_y)
{
    if (spIsDrawable(src) == SP_FALSE ||
	spIsDrawable(dest) == SP_FALSE) return;

    spCopyImageArch(src, dest, src_x, src_y, width, height, dest_x, dest_y);

    return;
}

