/*
 *	spText_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spList.h>
#include <sp/spComboBox.h>

#include <sp/spGraphicsP.h>
#include <sp/spTextP.h>

extern spTopLevel sp_toplevel;

void spTextPartInitArch(spComponent component)
{
    SpTextArch(component).font = NULL;
    
    return;
}

void spTextPartFreeArch(spComponent component)
{
    if (SpTextArch(component).font != NULL) {
	DeleteObject(SpTextArch(component).font);
    }
    
    return;
}

/* convert from \n to \r\n */
char *xspGetNativeString(char *string)
{
    int i, j;
    int len;
    int num_br;
    char *native;

    if (string == NULL) return NULL;
    
    len = strlen(string);
    
    num_br = 0;
    for (i = 0; i < len; i++) {
	if (string[i] == '\n') {
	    num_br++;
	}
    }

    len = len + num_br;
    native = xalloc(len + 1, char);

    for (i = 0, j = 0; i < len; i++, j++) {
	if (string[j] == '\n') {
	    native[i] = '\r';
	    i++;
	}
	native[i] = string[j];
    }
    native[i] = '\0';

    return native;
}

/* convert from \r\n to \n */
char *xspGetNormalString(char *string)
{
    int i, j;
    int len;
    int num_br;
    char *normal;

    if (string == NULL) return NULL;
    
    len = strlen(string) - 1;
    
    num_br = 0;
    for (i = 0; i < len; i++) {
	if (string[i] == '\r' && string[i + 1] == '\n') {
	    num_br++;
	    i++;
	}
    }

    len = len - num_br + 1;
    normal = xalloc(len + 1, char);

    for (i = 0, j = 0; i < len; i++, j++) {
	if (string[j] == '\r' && string[j + 1] == '\n') {
	    normal[i] = '\n';
	    j++;
	} else {
	    normal[i] = string[j];
	}
    }
    normal[i] = '\0';

    return normal;
}

static void setTextFont(spComponent component)
{
    LOGFONT lf;
    HFONT font = NULL;
    
    if (!strnone(SpTextPart(component).font_name)) {
	if (SpTextArch(component).font != NULL) DeleteObject(SpTextArch(component).font);

	spFontNameToLOGFONT(SpTextPart(component).font_name, &lf);
	SpTextArch(component).font = CreateFontIndirect(&lf);
	
	font = SpTextArch(component).font;
    }
    if (font == NULL) {
	font = SpTopLevelArch(sp_toplevel).sys_font;
    }
    
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)font, MAKELPARAM(TRUE, 0));
    
    return;
}

void spTextCreateArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	/* create text field */
	SpPrimitiveArch(component).hwnd =
	    CreateWindowEx(WS_EX_CLIENTEDGE,
			   "EDIT",
			   NULL,
			   WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | WS_TABSTOP,
			   SpComponentPart(component).x, SpComponentPart(component).y,
			   SpComponentPart(component).current_width,
			   SpComponentPart(component).current_height,
			   SpParentPrimitiveArch(component).hwnd,
			   (HMENU)SpComponentPart(component).component_id,
			   SpTopLevelArch(sp_toplevel).hThisInst,
			   NULL);
    } else {
	/* create text area */
	SpPrimitiveArch(component).hwnd =
	    CreateWindowEx(WS_EX_CLIENTEDGE,
			   "EDIT",
			   NULL,
			   WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL |
			   ES_MULTILINE | ES_WANTRETURN | ES_AUTOHSCROLL | ES_AUTOVSCROLL,
			   SpComponentPart(component).x, SpComponentPart(component).y,
			   SpComponentPart(component).current_width,
			   SpComponentPart(component).current_height,
			   SpParentPrimitiveArch(component).hwnd,
			   (HMENU)SpComponentPart(component).component_id,
			   SpTopLevelArch(sp_toplevel).hThisInst,
			   NULL);
    }
    
    SendMessage(SpPrimitiveArch(component).hwnd, EM_SETREADONLY,
		(WPARAM)(BOOL)(SpTextPart(component).editable == SP_FALSE ? TRUE : FALSE), 0);

    setTextFont(component);

    return;
}

void spTextSetParamsArch(spComponent component)
{
    if (SpTextPart(SpOldObject(component)).editable != SpTextPart(component).editable) {
	SendMessage(SpPrimitiveArch(component).hwnd, EM_SETREADONLY,
		    (WPARAM)(BOOL)(SpTextPart(component).editable == SP_FALSE ? TRUE : FALSE), 0);
    }
    
    if (!streq(SpTextPart(SpOldObject(component)).font_name, SpTextPart(component).font_name)) {
	setTextFont(component);
    }
    
    return;
}

void spSetTextStringArch(spComponent component)
{
    int len;
    char *native;

    /* convert from \n to \r\n */
    native = xspGetNativeString(SpTextPart(component).string);
	
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
		(WPARAM)0, (LPARAM)(LPCTSTR)native);

    len = strlen(native);
    SendMessage(SpPrimitiveArch(component).hwnd, EM_SETSEL,
		(WPARAM)len, (LPARAM)len);
    
    xfree(native);
    
    if (spIsSubClass(component, SpTextArea) == SP_TRUE) {
	SendMessage(SpPrimitiveArch(component).hwnd, EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
    }
    
    return;
}

void spGetTextStringArch(spComponent component)
{
    int length;
    char *string;

    if (spIsSubClass(component, SpComboBox) == SP_TRUE
	&& HIWORD(SpPrimitiveArch(component).wParam) == CBN_SELCHANGE) {
	SpTextPart(component).string = xspGetSelectedListItem(component);
	spDebug(50, "spGetTextStringArch", "CBN_SELCHANGE: string = %s\n",
		SpTextPart(component).string);
    } else {
	if ((length = SendMessage(SpPrimitiveArch(component).hwnd, WM_GETTEXTLENGTH,
				  (WPARAM)0, (LPARAM)0)) < 0) {
	    SpTextPart(component).string = NULL;
	} else {
	    if (spIsSubClass(component, SpTextArea) == SP_TRUE) {
		string = xalloc(length + 1, char);
		SendMessage(SpPrimitiveArch(component).hwnd, WM_GETTEXT,
			    (WPARAM)(length + 1), (LPARAM)string);
		SpTextPart(component).string = xspGetNormalString(string);
		xfree(string);
	    } else {
		SpTextPart(component).string = xalloc(length + 1, char);
		SendMessage(SpPrimitiveArch(component).hwnd, WM_GETTEXT,
			    (WPARAM)(length + 1), (LPARAM)SpTextPart(component).string);
	    }
	}
    }

    spDebug(80, "spGetTextStringArch", "done\n");
    
    return;
}

spBool spSetTextSelectionArch(spComponent component, long start, long end)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, EM_SETSEL,
		(WPARAM)(INT)start, (LPARAM)(INT)end);
    if (spIsSubClass(component, SpTextArea) == SP_TRUE) {
	SendMessage(SpPrimitiveArch(component).hwnd, EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
    }
    
    return SP_TRUE;
}

spBool spGetTextSelectionArch(spComponent component, long *start, long *end)
{
    DWORD dwStart, dwEnd;
    
    if (SendMessage(SpPrimitiveArch(component).hwnd, EM_GETSEL,
		    (WPARAM)(LPDWORD)&dwStart, (LPARAM)(LPDWORD)&dwEnd) < 0
	|| dwStart >= dwEnd) {
	return SP_FALSE;
    }
    *start = dwStart;
    *end = dwEnd;
    
    return SP_TRUE;
}

spBool spSetTextPositionArch(spComponent component, long position)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, EM_SETSEL,
		(WPARAM)(INT)position, (LPARAM)(INT)position);
    if (spIsSubClass(component, SpTextArea) == SP_TRUE) {
	SendMessage(SpPrimitiveArch(component).hwnd, EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
    }
    
    return SP_TRUE;
}

spBool spGetTextPositionArch(spComponent component, long *position)
{
    DWORD dwStart, dwEnd;
    
    if (SendMessage(SpPrimitiveArch(component).hwnd, EM_GETSEL,
		    (WPARAM)(LPDWORD)&dwStart, (LPARAM)(LPDWORD)&dwEnd) < 0) {
	return SP_FALSE;
    }
    *position = dwEnd;
    
    return SP_TRUE;
}

spBool spCutTextArch(spComponent component)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_CUT, (WPARAM)0, (LPARAM)0);
    return SP_TRUE;
}

spBool spCopyTextArch(spComponent component)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_COPY, (WPARAM)0, (LPARAM)0);
    return SP_TRUE;
}

spBool spPasteTextArch(spComponent component)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_PASTE, (WPARAM)0, (LPARAM)0);
    return SP_TRUE;
}

spBool spClearTextArch(spComponent component)
{
    SetFocus(SpPrimitiveArch(component).hwnd);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_CLEAR, (WPARAM)0, (LPARAM)0);
    return SP_TRUE;
}
