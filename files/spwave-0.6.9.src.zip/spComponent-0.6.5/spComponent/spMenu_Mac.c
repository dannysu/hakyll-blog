/*
 *	spMenu_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spMenuItemP.h>
#include <sp/spMenuP.h>

void spSetMenuItemTextMac(MenuHandle menu, int index, Str255 pstr)
{
    int i;
    
    if (pstr[0] <= 0) {
	pstr[0] = 1; pstr[1] = NUL;
    } else if (pstr[1] == '-') {
	for (i = pstr[0] + 1; i >= 2; i--) {
	    pstr[i] = pstr[i - 1];
	}
	pstr[1] = NUL;
	pstr[0] += 1;
    }

    SetMenuItemText(menu, index, pstr);

    return;
}

void spGetMenuItemTextMac(MenuHandle menu, int index, Str255 pstr)
{
    int i;
    
    GetMenuItemText(menu, index, pstr);
    if (pstr[0] > 1 && pstr[1] == NUL) {
	for (i = 1; i < pstr[0]; i++) {
	    pstr[i] = pstr[i + 1];
	}
	pstr[0] -= 1;
    }
    
    return;
}

spBool spGetMenuLabelMac(spComponent component, Str255 plabel)
{
    spBool flag;
    char label[SP_MAX_MENU_LABEL];

    if (component == NULL) return SP_FALSE;
    
    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	spGetMnemonic(SpComponentPart(component).title, label);
    }
    if (strnone(label)) {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
	flag = SP_FALSE;
    } else {
	flag = SP_TRUE;
    }
    spStrCToP(label, plabel);
    
    return flag;
}

void spAddSubMenuMac(spComponent component, Str255 plabel)
{
    int menu_id;
    Str255 pstr;
    char buf[SP_MAX_LINE];

    sprintf(buf, " !%c/%c", (char)SpPrimitiveArch(component).menu_id,
	    '\033');	/* ESC */
    spStrCToP(buf, pstr);
    
    menu_id = spGetMenuItemIdMac(component);
    InsertMenuItem(SpParentPrimitiveArch(component).menu, pstr, menu_id);
    
    /* prevent from disable of menu including '(' */
    spSetMenuItemTextMac(SpParentPrimitiveArch(component).menu, menu_id, plabel);

    return;
}

void spPulldownMenuCreateArch(spComponent component)
{
    Str255 pstr;

    spGetMenuLabelMac(component, pstr);

    SpPrimitiveArch(component).menu_id = spUseCurrentMenuIdMac();
    
    if (spIsSubClass(SpGetParent(component), SpMenuBar) == SP_FALSE) {
	SpPrimitiveArch(component).menu =
	    NewMenu(SpPrimitiveArch(component).menu_id, pstr);

	if (spIsSubClass(component, SpPopupMenu) == SP_TRUE) {
	    SpParentPrimitiveArch(component).popup_menu = component;
	} else {
	    if (SpParentMenuPart(component).help_flag == SP_FALSE) {
		spAddSubMenuMac(component, pstr);
	    }
	}
	InsertMenu(SpPrimitiveArch(component).menu, -1);
    } else {
	if (SpMenuPart(component).help_flag == SP_TRUE) {
	    SpPrimitiveArch(component).menu_id = kHMHelpMenuID;
#if !TARGET_API_MAC_CARBON
	    HMGetHelpMenuHandle(&SpPrimitiveArch(component).menu);
#else
	    HMGetHelpMenu(&SpPrimitiveArch(component).menu, NULL);
#endif
	} else {
	    SpPrimitiveArch(component).menu =
		NewMenu(SpPrimitiveArch(component).menu_id, pstr);
	}
    }
    
    return;
}

void spPulldownMenuSetParamsArch(spComponent component)
{
    Str255 pstr;

    if (spIsSubClass(SpGetParent(component), SpMenuBar) == SP_FALSE) {
	if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	    if (spGetMenuLabelMac(component, pstr) == SP_TRUE) {
		spSetMenuItemTextMac(SpParentPrimitiveArch(component).menu,
				     SpPrimitiveArch(component).menu_id, pstr);
		DrawMenuBar();
	    }
	}
    }
    
    return;
}

void spPopupMenuCreateArch(spComponent component)
{
    spPulldownMenuCreateArch(component);
    return;
}

void spPopupMenuSetParamsArch(spComponent component)
{
    spPulldownMenuSetParamsArch(component);
    return;
}

void spMenuBarCreateArch(spComponent component)
{
    return;
}
