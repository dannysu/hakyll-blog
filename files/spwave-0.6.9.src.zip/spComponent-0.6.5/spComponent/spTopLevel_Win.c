/*
 *	spTopLevel_Win.c
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spGraphicsP.h>
#include <sp/spComponentP.h>
#include <sp/spPrimitiveP.h>
#include <sp/spTopLevelP.h>

extern spTopLevel sp_toplevel;

static HINSTANCE sp_hThisInst;
static HINSTANCE sp_hPrevInst;
static int sp_nWinMode;
static char *sp_args_buffer = NULL;
static char sp_program_name[SP_MAX_PATHNAME];

static CRITICAL_SECTION sp_critical_section; 

int spWinMainInitialize(HINSTANCE hThisInst, HINSTANCE hPrevInst, int nWinMode)
{
    sp_hThisInst = hThisInst;
    sp_hPrevInst = hPrevInst;
    sp_nWinMode = nWinMode;
    
    GetModuleFileName(sp_hThisInst, sp_program_name,
		      SP_MAX_PATHNAME - 1);
    
    return TRUE;
}

static char *xgetlongname(char *name)
{
    char path[SP_MAX_PATHNAME];
    WIN32_FIND_DATA finddata;
    HANDLE hfind;
        
    if ((hfind = FindFirstFile(name, &finddata)) == INVALID_HANDLE_VALUE) {
	return NULL;
    }
        
#if !defined(__CYGWIN32__)
    {
	char drive[SP_MAX_PATHNAME];
	char dir[SP_MAX_PATHNAME];
	
	strcpy(path, name);
	_splitpath(path, drive, dir, NULL, NULL);
	sprintf(path, "%s%s%s", drive, dir, finddata.cFileName);
    }
#else
    strcpy(path, name);
    if (spGetDirName(path) != NULL) {
	spAddDirSeparator(path);
	strcat(path, finddata.cFileName);
    }
#endif

    FindClose(hfind); 
        
    return strclone(path);
}

#define SP_NUM_ARGV_BUFFER 64

char **spGetArgv(LPSTR lpszArgs, int *argcp)
{
    char *p, *name;
    char *string = NULL;
    static int count = 0;
    static int num_argv_buffer = 0;
    static char **argv = NULL;

    if (sp_args_buffer == NULL) {
	sp_args_buffer = strclone((char *)lpszArgs);
    }

    if (argv == NULL) {
	num_argv_buffer = SP_NUM_ARGV_BUFFER;
	argv = xalloc(num_argv_buffer, char *);
	
	argv[count++] = strclone(sp_program_name);

	name = NULL;
	string = sp_args_buffer;
	while (*string) {
	    while (*string) {
		if (*string != ' ' && *string != '\t') {
		    break;
		}
		string++;
	    }
	    if (*string == '"') {
		string++;
		name = string;
		while (*string && *string != '"') string++;
	    } else if (*string) {
		name = string;
		while (*string) {
		    if (*string == ' ' || *string == '\t') {
			break;
		    }
		    string++;
		}
	    }
	    if (*string) *string++ = NUL;

	    if ((p = xgetlongname(name)) == NULL) {
		p = strclone(name);
	    }
	    argv[count++] = p;

	    if (count >= num_argv_buffer) {
		num_argv_buffer += SP_NUM_ARGV_BUFFER;
		argv = xrealloc(argv, num_argv_buffer, char *);
	    }
	}
	argv[count] = NULL;
    }

    if (argcp != NULL) *argcp = count;
    
    return argv;
}

void spFreeArgv(int argc, char **argv)
{
    int i;
    
    if (argv != NULL) {
	for (i = 0; i < argc; i++) {
	    if (argv[i] == NULL) break;
	    xfree(argv[i]);
	}
	xfree(argv);
    }
}

void spTopLevelPartInitArch(spTopLevel toplevel)
{
    return;
}

void spTopLevelPartFreeArch(spTopLevel toplevel)
{
    return;
}

void spTopLevelCreateArch(spTopLevel toplevel)
{
    WNDCLASSEX wcl;
    
    spDebug(30, "spTopLevelCreateArch", "in\n");
    
    InitializeCriticalSection(&sp_critical_section);
    
    SpTopLevelArch(toplevel).hThisInst = sp_hThisInst;
    SpTopLevelArch(toplevel).hPrevInst = sp_hPrevInst;
    SpTopLevelArch(toplevel).nWinMode = sp_nWinMode;
    SpTopLevelArch(toplevel).sys_font = GetStockObject(DEFAULT_GUI_FONT);
    SpTopLevelArch(toplevel).null_pen = GetStockObject(NULL_PEN);
    SpTopLevelArch(toplevel).null_brush = GetStockObject(HOLLOW_BRUSH);
    SpTopLevelArch(toplevel).bg_brush = GetSysColorBrush(COLOR_BTNFACE);
    SpTopLevelArch(toplevel).hcursor = NULL;
    spCreateGraphics("spTopLevelGraphics",
		     SppForegroundPixel, SP_SYSTEM_COLOR_BLACK_PIXEL,
		     NULL);
    
    spDebug(30, "spTopLevelCreateArch", "spCreateGraphics done\n");

    wcl.hInstance = sp_hThisInst;
    wcl.lpszClassName = SP_WINDOW_CLASS_NAME;
    wcl.lpfnWndProc = spWindowFunc;
    wcl.style = /*CS_HREDRAW | CS_VREDRAW*/0;
    wcl.cbSize = sizeof(WNDCLASSEX);
    wcl.hIcon = NULL; wcl.hIconSm = NULL;
    if (!strnone(SpTopLevelPart(toplevel).icon_name)) {
	wcl.hIcon = LoadIcon(sp_hThisInst, SpTopLevelPart(toplevel).icon_name);
#ifndef _WINE
	if (wcl.hIcon != NULL) {
	    wcl.hIconSm = LoadIcon(sp_hThisInst, SpTopLevelPart(toplevel).icon_name);
	}
#endif
    }
    if (wcl.hIcon == NULL) {
	wcl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
#ifndef _WINE
	wcl.hIconSm = LoadIcon(NULL, IDI_WINLOGO);
#endif
    }
    wcl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcl.lpszMenuName = NULL;
    wcl.cbClsExtra = 0;
    wcl.cbWndExtra = 0;
    wcl.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    RegisterClassEx(&wcl);

    spDebug(30, "spTopLevelCreateArch", "register window class done\n");
    
    wcl.hInstance = sp_hThisInst;
    wcl.lpszClassName = SP_CANVAS_CLASS_NAME;
    wcl.lpfnWndProc = spWindowFunc;
    wcl.style = 0;
    wcl.cbSize = sizeof(WNDCLASSEX);
    wcl.hIcon = NULL; wcl.hIconSm = NULL;
    if (!strnone(SpTopLevelPart(toplevel).icon_name)) {
	wcl.hIcon = LoadIcon(sp_hThisInst, SpTopLevelPart(toplevel).icon_name);
#ifndef _WINE
	if (wcl.hIcon != NULL) {
	    wcl.hIconSm = LoadIcon(sp_hThisInst, SpTopLevelPart(toplevel).icon_name);
	}
#endif
    }
    if (wcl.hIcon == NULL) {
	wcl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
#ifndef _WINE
	wcl.hIconSm = LoadIcon(NULL, IDI_WINLOGO);
#endif
    }
    wcl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcl.lpszMenuName = NULL;
    wcl.cbClsExtra = 0;
    wcl.cbWndExtra = 0;
    wcl.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    RegisterClassEx(&wcl);

    spDebug(30, "spTopLevelCreateArch", "register canvas class done\n");

    InitCommonControls();

    spDebug(30, "spTopLevelCreateArch", "InitCommonControls done\n");
    
    return;
}

void spTopLevelSetParamsArch(spTopLevel toplevel)
{
    return;
}
    
void spTopLevelDestroyArch(spTopLevel toplevel)
{
    spGraphics graphics, next_graphics;
    spComponent window;
    
    if (toplevel != NULL) {
	spDebug(30, "spTopLevelDestroyArch", "in\n");
	
	/* destroy graphics */
	graphics = SpTopLevelPart(toplevel).graphics;
	while (graphics != NULL) {
	    next_graphics = SpGraphicsPart(graphics).next_graphics;
	    spFreeGraphics(graphics);
	    graphics = next_graphics;
	}

	/* destroy accelerator */
	window = spGetChild(NULL);
	while (window != NULL) {
	    spShowTaskTray(window, SP_FALSE);
	    if (SpPrimitiveArch(window).haccel != NULL) {
		DestroyAcceleratorTable(SpPrimitiveArch(window).haccel);
		SpPrimitiveArch(window).haccel = NULL;
	    }
	    window = SpGetNextComponent(window);
	}
	
	DeleteCriticalSection(&sp_critical_section);
	
	spDebug(30, "spTopLevelDestroyArch", "done\n");
    }

    return;
}

void spQuitArch(int status)
{
    spDebug(30, "spQuitArch", "in\n");
    spDestroyObject((spObject)sp_toplevel);
    return;
}

static int getMessage(spTopLevel toplevel)
{
    if (GetMessage(&SpTopLevelArch(toplevel).msg, NULL, 0, 0)) {
	if (!spTranslateAllAcceleratorWin(&SpTopLevelArch(toplevel).msg)) {
	    TranslateMessage(&SpTopLevelArch(toplevel).msg);
	    DispatchMessage(&SpTopLevelArch(toplevel).msg);
	}

	return 1;
    }
    
    return 0;
}

int spWaitEventArch(spTopLevel toplevel)
{
    return getMessage(toplevel);
}
    
int spDispatchEventArch(spTopLevel toplevel)
{
    if (PeekMessage(&SpTopLevelArch(toplevel).msg, NULL, 0, 0, PM_NOREMOVE)) {
	return getMessage(toplevel);
    } else {
	return 0;
    }
}
    
int spMainLoopArch(spTopLevel toplevel)
{
    while (getMessage(toplevel)) {}
    
    return SpTopLevelArch(toplevel).msg.wParam;
}

spBool spThreadEnterArch(spTopLevel toplevel)
{
    return SP_TRUE;
}

spBool spThreadLeaveArch(spTopLevel toplevel)
{
    
    return SP_TRUE;
}

void spEnterCriticalSectionWin(void)
{
    EnterCriticalSection(&sp_critical_section);
    return;
}

void spLeaveCriticalSectionWin(void)
{
    LeaveCriticalSection(&sp_critical_section);
    return;
}
    
