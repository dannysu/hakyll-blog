/*
 *	spDialog_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/CascadeBG.h>
#include <Xm/PushBG.h>
#include <Xm/LabelG.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/DialogS.h>
#include <Xm/MessageB.h>
#include <Xm/FileSB.h>
#include <Xm/SelectioB.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <stdarg.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spParamField.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spGraphicsP.h>
#include <sp/spDialogBoxP.h>
#include <sp/spDialogP.h>

extern spTopLevel sp_toplevel;

static spMessageBoxButtonType sp_md_button_type = SP_MB_OK;
static spDialogResponse sp_md_response = SP_DR_NONE;

static char sp_fd_filename[SP_MAX_PATHNAME] = "";

static void getFileMask(char *pathname, char *mask)
{
    if (pathname == NULL) return;

    spAddDirSeparator(pathname);
    
    if (strnone(mask)) {
	strcat(pathname, "*");
    } else {
	strcat(pathname, mask);
    }
    
    return;
}

char *xspGetFileMask(char *dirname, char *mask)
{
    struct stat status;
    char *filemask;
    char *exactname;
    char *string;
    static char buf[SP_MAX_PATHNAME] = "";

    if ((exactname = xspGetExactName(dirname)) == NULL) {
	getFileMask(buf, mask);
    } else {	/* check if directory exists */
	strcpy(buf, exactname);
	xfree(exactname);
	
	if (stat(buf, &status) != 0) {	/* not found such file or directory */
	    if ((string = strrchr(buf, '/')) != NULL)
		*string = NUL;
	
	    if (stat(buf, &status) != 0 || !S_ISDIR(status.st_mode)) {
		/* not found such directory */
		return NULL;
	    }
	} else if (!S_ISDIR(status.st_mode)) {
	    /* name is file name */
	    if ((string = strrchr(buf, '/')) != NULL)
		*string = NUL;
	}
	getFileMask(buf, mask);
	
	spDebug(20, "xspGetFileMask", "buf = %s\n", buf);
    }
    
    /* set return value */
    filemask = strclone(buf);

    return filemask;
}

void spDialogPartInitArch(spComponent component)
{
    SpDialogArch(component).file_type_field = NULL;

    return;
}

static void popupDialog(spComponent component)
{
    spComponent prev_grabbed;
    
    if (component == NULL) return;

    if (SpPrimitiveArch(component).widget != NULL) {
	if (XtIsManaged(SpPrimitiveArch(component).widget) == False) {
	    XtManageChild(SpPrimitiveArch(component).widget);
	} else {
	    XtMapWidget(SpPrimitiveArch(component).widget);
	}
    }
    
    prev_grabbed = spAddGrabXm(component);
    spDebug(50, "popupDialog", "add grab done: %ld\n", (long)prev_grabbed);
    
    /* main loop */
    for (;;) {
	spWaitEvent(sp_toplevel);
	
	if (XtIsManaged(SpPrimitiveArch(component).widget) == False) {
	    break;
	}
    }

    spAddGrabXm(prev_grabbed);
    
    spDebug(50, "popupDialog", "loop done\n");
    
    return;
}

static void popdownDialog(spComponent component)
{
    if (component == NULL) return;

    spRemoveGrabXm(component);
    
    if (SpPrimitiveArch(component).widget != NULL) {
	if (XtIsManaged(SpPrimitiveArch(component).widget) == True) {
	    XtUnmanageChild(SpPrimitiveArch(component).widget);
	}
    }

    return;
}

static void messageBoxCB(Widget widget, XtPointer client_data,
			 XtPointer call_data)
{
    spComponent component;
    XmAnyCallbackStruct *cbs;

    component = (spComponent)client_data;
    cbs = (XmAnyCallbackStruct *)call_data;
	
    if (cbs->reason == XmCR_OK) {
	if (sp_md_button_type == SP_MB_YES_NO ||
	    sp_md_button_type == SP_MB_YES_NO_CANCEL) {
	    sp_md_response = SP_DR_YES;
	} else if (sp_md_button_type == SP_MB_RETRY_CANCEL) {
	    sp_md_response = SP_DR_RETRY;
	} else {
	    sp_md_response = SP_DR_OK;
	}
    } else if (cbs->reason == XmCR_CANCEL) {
	if (sp_md_button_type == SP_MB_YES_NO ||
	    sp_md_button_type == SP_MB_YES_NO_CANCEL) {
	    sp_md_response = SP_DR_NO;
	} else {
	    sp_md_response = SP_DR_CANCEL;
	}
    } else if (cbs->reason == XmCR_HELP) {
	if (sp_md_button_type == SP_MB_YES_NO_CANCEL) {
	    sp_md_response = SP_DR_CANCEL;
	}
    }

    popdownDialog(component);
    
    spDebug(30, "messageBoxCB", "done\n");
    
    return;
}

static void createMessageDialog(spComponent component, char *message)
{
    XmString xmstr;
    int narg = 0;
    Arg args[10];
    char *title;
    Widget widget = NULL;

    spDebug(30, "createMessageDialog", "in\n");
    
    if (spIsCreated(SpGetParent(component)) == SP_TRUE
	&& SpPrimitiveArch(SpGetParent(component)).widget != NULL) {
	widget = SpPrimitiveArch(SpGetParent(component)).widget;
	while (!XtIsWidget(widget)) {
	    widget = XtParent(widget);
	}
    } else {
	widget = SpTopLevelArch(sp_toplevel).widget;
    }
    
    spDebug(30, "createMessageDialog", "get widget done\n");
    
    XtSetArg(args[narg], XmNautoUnmanage, False); narg++;
    XtSetArg(args[narg], XmNdeleteResponse, XmDO_NOTHING); narg++;
    XtSetArg(args[narg], XmNdialogStyle, XmDIALOG_APPLICATION_MODAL); narg++;
    
    title = spGetMessageBoxTitle(component);

    if (SpDialogPart(component).dialog_type == SP_INFORMATION_DIALOG) {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_INFORMATION); narg++;
    } else if (SpDialogPart(component).dialog_type == SP_QUESTION_DIALOG) {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_QUESTION); narg++;
    } else if (SpDialogPart(component).dialog_type == SP_WARNING_DIALOG) {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_WARNING); narg++;
    } else if (SpDialogPart(component).dialog_type == SP_ERROR_DIALOG) {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_ERROR); narg++;
    } else if (SpDialogPart(component).dialog_type == SP_WORKING_DIALOG) {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_WORKING); narg++;
    } else {
	XtSetArg(args[narg], XmNdialogType, XmDIALOG_MESSAGE); narg++;
    }
    
    SpPrimitiveArch(component).top_widget = XmCreateDialogShell(widget, "", NULL, 0);
    SpPrimitiveArch(component).widget = XmCreateMessageBox(SpPrimitiveArch(component).top_widget,
							   (!strnone(SpGetName(component))
							    ? SpGetName(component) : "messageBox"),
							   args, narg);
    
    if (SpDialogPart(component).button_type == SP_MB_OK) {
	xmstr = XmStringCreate(SP_OK_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	widget = XmMessageBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_CANCEL_BUTTON);
	XtUnmanageChild(widget);
	widget = XmMessageBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_HELP_BUTTON);
	XtUnmanageChild(widget);
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	xmstr = XmStringCreate(SP_OK_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_CANCEL_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNcancelLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	widget = XmMessageBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_HELP_BUTTON);
	XtUnmanageChild(widget);
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	xmstr = XmStringCreate(SP_YES_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_NO_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNcancelLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	widget = XmMessageBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_HELP_BUTTON);
	XtUnmanageChild(widget);
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	xmstr = XmStringCreate(SP_YES_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_NO_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNcancelLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_CANCEL_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNhelpLabelString, xmstr, NULL);
	XmStringFree(xmstr);
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	xmstr = XmStringCreate(SP_RETRY_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_CANCEL_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNcancelLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	widget = XmMessageBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_HELP_BUTTON);
	XtUnmanageChild(widget);
    }
    sp_md_button_type = SpDialogPart(component).button_type;

    if (!strnone(title)) {
	spDebug(30, "createMessageDialog", "title = %s\n", title);
	xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNdialogTitle, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    if (!strnone(message)) {
	spDebug(30, "createMessageDialog", "message = %s\n", message);
	xmstr = XmStringCreateLtoR(message, XmSTRING_DEFAULT_CHARSET);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNmessageString, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    /* add callbacks */
    XtAddCallback(SpPrimitiveArch(component).widget, XmNokCallback,
		  (XtCallbackProc)messageBoxCB, (XtPointer)component);
    XtAddCallback(SpPrimitiveArch(component).widget, XmNcancelCallback,
		  (XtCallbackProc)messageBoxCB, (XtPointer)component);
    XtAddCallback(SpPrimitiveArch(component).widget, XmNhelpCallback,
		  (XtCallbackProc)messageBoxCB, (XtPointer)component);
    
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_OK_CALLBACK | SP_CANCEL_CALLBACK | SP_HELP_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    SpObjectPart(component).create_flag = SP_TRUE;

    return;
}

spDialogResponse spPopupMessageBox(spComponent component, char *message)
{
    createMessageDialog(component, message);
    sp_md_response = SP_DR_NONE;

    /* popup dialog */
    popupDialog(component);

    spDebug(30, "spPopupMessageBox", "response = %d\n", sp_md_response);
    
    return sp_md_response;
}

static char *sp_default_file_filters[] =
{
    "*",
    NULL,
};

static void setFileMask(spComponent component, int index)
{
    XmString xmstr = NULL;
    char *string;
    char **file_filters;
    char *file_mask = NULL;
    char *initial_file_name = NULL;
    static char **prev_file_filters = NULL;
    static int prev_index = -1;

    if (component == NULL) return;

    if (index < 0) return;
    
    if (SpDialogPart(component).filter_index != NULL) {
	*(SpDialogPart(component).filter_index) = index;
    }
    SpPrimitivePart(component).index = index;
    
    if (SpDialogPart(component).file_filters != NULL) {
	file_filters = SpDialogPart(component).file_filters;
    } else {
	file_filters = sp_default_file_filters;
    }

    if (file_filters == prev_file_filters && index == prev_index
	&& SpDialogPart(component).initial_dir == NULL
	&& SpDialogPart(component).initial_file_name == NULL)
	return;
    
    if (!strnone(SpDialogPart(component).initial_file_name)) {
	initial_file_name = xspGetBaseName(SpDialogPart(component).initial_file_name);
	xfree(SpDialogPart(component).initial_file_name);
	SpDialogPart(component).initial_file_name = NULL;
    }

    if (!strnone(SpDialogPart(component).initial_dir)) {
	file_mask = xspGetFileMask(SpDialogPart(component).initial_dir, file_filters[index]);

	xfree(SpDialogPart(component).initial_dir);
	SpDialogPart(component).initial_dir = NULL;
    }

    /* get current directory name */
    XtVaGetValues(SpPrimitiveArch(component).widget,
		  XmNdirSpec, &xmstr,
		  NULL);
    
    /* get file mask */
    if (xmstr == NULL || !XmStringGetLtoR(xmstr, XmSTRING_DEFAULT_CHARSET, &string)) {
	if (file_mask == NULL) {
	    string = xspGetCurrentDir();
	    file_mask = xspGetFileMask(string, file_filters[index]);
	    xfree(string);
	}
    } else {
	if (initial_file_name == NULL && spIsDir(string) == SP_FALSE
	    && SpDialogPart(component).dialog_type == SP_SAVE_FILE_DIALOG) {
	    char *p;
	    if ((p = spGetBaseName(string)) != NULL) {
		initial_file_name = strclone(p);
	    }
	}
	if (file_mask == NULL) {
	    file_mask = xspGetFileMask(string, file_filters[index]);
	}
	XtFree(string);
    }
    if (xmstr != NULL) XmStringFree(xmstr);
    
    spDebug(10, "setFileMask", "file_mask = %s\n", file_mask);
	
    /* create XmString */
    xmstr = XmStringCreate(file_mask, XmFONTLIST_DEFAULT_TAG);
    
    /* search directory */
    XmFileSelectionDoSearch(SpPrimitiveArch(component).widget, xmstr);
    XmStringFree(xmstr);

    if (initial_file_name != NULL) {
	XmString xmstr_dir_name = NULL;
	XmString xmstr_file_name = NULL;
	
	spDebug(10, "setFileMask", "initial_file_name = %s\n", initial_file_name);
	
	XtVaGetValues(SpPrimitiveArch(component).widget,
		      XmNdirSpec, &xmstr_dir_name,
		      NULL);
	xmstr_file_name = XmStringCreate(initial_file_name, XmFONTLIST_DEFAULT_TAG);
	xmstr = XmStringConcat(xmstr_dir_name, xmstr_file_name);
	
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNdirSpec, xmstr,
		      NULL);
	
	if (xmstr_dir_name != NULL) XmStringFree(xmstr_dir_name);
	if (xmstr_file_name != NULL) XmStringFree(xmstr_file_name);
	if (xmstr != NULL) XmStringFree(xmstr);
	xfree(initial_file_name);
    }

    /* memory free */
    xfree(file_mask);

    prev_index = index;
    prev_file_filters = file_filters;
    
    return;
}

static void selectFileTypeCB(spComponent component, void *data)
{
    int index;
    spComponent dialog = (spComponent)data;

    /* get selected index of combo box */
    index = spGetSelectedListIndex(component);

    setFileMask(dialog, index);
    
    return;
}

static void setFileTypes(spComponent component)
{
    int i;
    char **file_types;

    if (SpDialogPart(component).file_types != NULL) {
	file_types = SpDialogPart(component).file_types;
    } else if (SpDialogPart(component).file_filters != NULL) {
	file_types = SpDialogPart(component).file_filters;
    } else {
	file_types = sp_default_file_filters;
    }
    
    if (SpDialogArch(component).file_type_field == NULL) {
	SpObjectPart(component).create_flag = SP_TRUE;
	SpDialogArch(component).file_type_field =
	    spCreateParamField(component, "fileTypeField", 70,
			       SppTitle, SP_FILE_TYPE_LABEL,
			       SppEditable, SP_FALSE,
			       SppFieldOffset, 80,
			       SppFieldSize, 80,
			       SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
			       SppFieldStrings, file_types,
			       SppCallbackFunc, selectFileTypeCB,
			       SppCallbackData, component,
			       NULL);
    } else {
	while (spDeleteListIndex(SpDialogArch(component).file_type_field, 0) >= 0);
	
	for (i = 0; file_types[i] != NULL; i++) {
	    spAddListItem(SpDialogArch(component).file_type_field, file_types[i]);
	}
    }

    if (SpDialogPart(component).filter_index != NULL) {
	SpPrimitivePart(component).index = MAX(*(SpDialogPart(component).filter_index), 0);
    } else {
	SpPrimitivePart(component).index = MAX(SpPrimitivePart(component).index, 0);
    }
    
    /* select index of list */
    spSelectListIndex(SpDialogArch(component).file_type_field, SpPrimitivePart(component).index);

    /* set file mask */
    setFileMask(component, SpPrimitivePart(component).index);

    return;
}

static void createFileDialog(spComponent component, spFileDialogType dialog_type)
{
    char *title = NULL;
    XmString xmstr;
    int narg = 0;
    Arg args[10];
    Widget widget = NULL;

    spDebug(30, "createFileDialog", "in\n");
    
    title = SpComponentPart(component).title;

    if (spIsCreated(component) == SP_FALSE) {
	if (title == NULL) {
	    if (!strnone(SpGetName(component))) {
		title = SpGetName(component);
	    } else {
		if (dialog_type == SP_FD_TYPE_SAVE) {
		    title = SP_SAVE_TITLE;
		} else if (dialog_type == SP_FD_TYPE_DIR) {
		    title = SP_DIR_SELECTION_TITLE;
		} else {
		    title = SP_OPEN_TITLE;
		}
	    }
	}

	widget = SpTopLevelArch(sp_toplevel).widget;

	XtSetArg(args[narg], XmNautoUnmanage, False); narg++;
	XtSetArg(args[narg], XmNdialogStyle, XmDIALOG_APPLICATION_MODAL); narg++;
#ifdef XmFILE_DIRECTORY
	if (dialog_type == SP_FD_TYPE_DIR) {
	    XtSetArg(args[narg], XmNfileTypeMask, XmFILE_DIRECTORY); narg++;
	}
#endif
	
	SpPrimitiveArch(component).top_widget = XmCreateDialogShell(widget, "", NULL, 0);
	SpPrimitiveArch(component).widget =
	    XmCreateFileSelectionBox(SpPrimitiveArch(component).top_widget,
				     (!strnone(SpGetName(component)) ?
				      SpGetName(component) : "fileDialog"),
				     args, narg);

	xmstr = XmStringCreate(SP_DIR_LIST_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNdirListLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_FILE_LIST_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNfileListLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_FILTER_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNfilterLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_FILE_NAME_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNselectionLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    xmstr = XmStringCreate(SP_SAVE_LABEL, XmFONTLIST_DEFAULT_TAG);
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    xmstr = XmStringCreate(SP_OK_LABEL, XmFONTLIST_DEFAULT_TAG);
	} else {
	    xmstr = XmStringCreate(SP_OPEN_LABEL, XmFONTLIST_DEFAULT_TAG);
	}
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNokLabelString, xmstr, NULL);
	XmStringFree(xmstr);

	xmstr = XmStringCreate(SP_CANCEL_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNcancelLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	xmstr = XmStringCreate(SP_FILTER_LABEL, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget, XmNapplyLabelString, xmstr, NULL);
	XmStringFree(xmstr);
	
	widget = XmFileSelectionBoxGetChild(SpPrimitiveArch(component).widget, XmDIALOG_HELP_BUTTON);
	XtUnmanageChild(widget);
    }

    setFileTypes(component);

    if (title != NULL) {
	spDebug(30, "createFileDialog", "title = %s\n", title);
	xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNdialogTitle, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_OK_CALLBACK | SP_CANCEL_CALLBACK | SP_HELP_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }

    spDebug(30, "createFileDialog", "done\n");
    
    return;
}

static spComponent sp_file_selection_box = NULL;

static void fileSelectionBoxCB(spComponent component, void *data)
{
    char *string = NULL;
    XmFileSelectionBoxCallbackStruct *cbs;

    if (component == NULL || sp_file_selection_box == NULL) return;
    
    cbs = (XmFileSelectionBoxCallbackStruct *)(SpPrimitiveArch(component).xt_call_data);

    spDebug(10, "fileSelectionBoxCB", "path_must_exist: %d\n",
	    SpDialogPart(sp_file_selection_box).file_must_exist);
    
    if (cbs->reason == XmCR_OK) {
	/* get filename */
	if (!XmStringGetLtoR(cbs->value, XmSTRING_DEFAULT_CHARSET, &string)) {
	    strcpy(sp_fd_filename, "");
	    return;
	} else {
	    struct stat status;
	    char buf[SP_MAX_PATHNAME];
	    
	    strcpy(sp_fd_filename, string);
	    XtFree(string);

	    spDebug(10, "fileSelectionBoxCB", "sp_fd_filename: %s\n",
		    sp_fd_filename);
    
	    if (stat(sp_fd_filename, &status) == 0) {
		if (S_ISDIR(status.st_mode)) {	/* name is directory name */
		    if (SpDialogPart(sp_file_selection_box).dialog_type
			!= SP_DIR_SELECTION_DIALOG) {
			SpDialogPart(sp_file_selection_box).initial_dir = strclone(sp_fd_filename);
			setFileMask(sp_file_selection_box, SpPrimitivePart(component).index);
			strcpy(sp_fd_filename, "");
			return;
		    }
		} else if (SpDialogPart(sp_file_selection_box).dialog_type
			   == SP_DIR_SELECTION_DIALOG) {
		    spDisplayError(sp_file_selection_box, NULL, SP_NOT_DIR_MESSAGE);
		    strcpy(sp_fd_filename, "");
		    return;
		} else if (SpDialogPart(sp_file_selection_box).overwrite_prompt == SP_TRUE) {
		    if (spOverwritePrompt(sp_file_selection_box, sp_fd_filename) == SP_FALSE) {
			strcpy(sp_fd_filename, "");
			return;
		    }
		}
	    } else if (SpDialogPart(sp_file_selection_box).dialog_type
		       == SP_DIR_SELECTION_DIALOG) {
		/* not found such directory */
		spDisplayError(sp_file_selection_box, NULL,
			       SP_NOT_FOUND_PATH_MESSAGE);
		strcpy(sp_fd_filename, "");
		return;
	    } else if (SpDialogPart(sp_file_selection_box).file_must_exist == SP_TRUE) {
		spDisplayError(sp_file_selection_box, NULL,
			       SP_NOT_FOUND_FILE_MESSAGE);
		strcpy(sp_fd_filename, "");
		return;
	    } else if (SpDialogPart(sp_file_selection_box).path_must_exist == SP_TRUE) {
		strcpy(buf, sp_fd_filename);
		spGetDirName(buf);

		if (stat(buf, &status) != 0 || !S_ISDIR(status.st_mode)) {
		    /* not found such directory */
		    spDisplayError(sp_file_selection_box, NULL,
				   SP_NOT_FOUND_PATH_MESSAGE);
		    strcpy(sp_fd_filename, "");
		    return;
		}
	    }
	}
    } else {
	strcpy(sp_fd_filename, "");
    }

    popdownDialog(sp_file_selection_box);
    sp_file_selection_box = NULL;
	
    return;
}

char *xspPopupFileSelectionBoxArg(spComponent parent, char *name,
				  spFileDialogType dialog_type,
				  spArg *args, int num_arg)
{
    char *filename = NULL;
    spComponent component = NULL;
    static spComponent sp_open_dialog = NULL;
    static spComponent sp_save_dialog = NULL;
    static spComponent sp_dir_dialog = NULL;

    if ((dialog_type == SP_FD_TYPE_SAVE && sp_save_dialog == NULL) ||
	(dialog_type == SP_FD_TYPE_OPEN && sp_open_dialog == NULL) ||
	(dialog_type == SP_FD_TYPE_DIR && sp_dir_dialog == NULL)) {
	component = spCreateComponentArg(SpDialogClass, SpFileDialog,
					 name, NULL, args, num_arg);
	SpObjectPart(component).create_flag = SP_FALSE;
	createFileDialog(component, dialog_type);

	/* add callbacks */
	spAddCallback(component, SP_OK_CALLBACK | SP_CANCEL_CALLBACK,
		      (spCallbackFunc)fileSelectionBoxCB, NULL);
	SpObjectPart(component).create_flag = SP_TRUE;
	
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    SpDialogPart(component).dialog_type = SP_SAVE_FILE_DIALOG;
	    sp_save_dialog = component;
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    SpDialogPart(component).dialog_type = SP_DIR_SELECTION_DIALOG;
	    sp_dir_dialog = component;
	} else {
	    SpDialogPart(component).dialog_type = SP_OPEN_FILE_DIALOG;
	    sp_open_dialog = component;
	}
    } else {
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    component = sp_save_dialog;
	} else if (dialog_type == SP_FD_TYPE_DIR) {
	    component = sp_dir_dialog;
	} else {
	    component = sp_open_dialog;
	}
	spSetParamsArg(component, args, num_arg);
	createFileDialog(component, dialog_type);
    }
    
    sp_file_selection_box = component;
    strcpy(sp_fd_filename, "");
    
    /* popup dialog */
    popupDialog(component);
    sp_file_selection_box = NULL;
    
    spDebug(30, "xspPopupFileSelectionBoxArg", "filename = %s\n", sp_fd_filename);

    if (!strnone(sp_fd_filename)) {
	filename = strclone(sp_fd_filename);
    }
    
    return filename;
}

char *xspChooseFontArch(spComponent component)
{
    return xspChooseFontDefault(component);
}

char *xspChooseColorArch(spComponent component)
{
    return xspChooseColorDefault(component);
}
