/*
 *	spTabBox_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spTabBoxP.h>

extern spTopLevel sp_toplevel;

void spTabBoxPartInitArch(spComponent component)
{
    return;
}

void spTabBoxPartFreeArch(spComponent component)
{
    return;
}

static void switchTabItemCB(GtkNotebook *widget, GtkNotebookPage *page, gint page_num)
{
    int index;
    spComponent component;
    spComponent child;

    component = (spComponent)gtk_object_get_data(GTK_OBJECT(widget), "spComponent");
    
    if (GTK_WIDGET_MAPPED(widget)
	&& component != NULL) {
	index = page_num;

	spDebug(10, "switchTabItemCB", "index = %d\n", index);
	child = SpGetChild(component);
	
	while (child != NULL) {
	    if (SpPrimitivePart(child).index == index) {
		SpComponentPart(child).visible_flag = SP_TRUE;
	    } else {
		SpComponentPart(child).visible_flag = SP_FALSE;
	    }

	    child = SpGetNextComponent(child);
	}
	
	spAdjustComponentSize(component);
    }
    
    return;
}

void spTabBoxCreateArch(spComponent component)
{
    SpComponentPart(component).border_width = 3;
    
    SpPrimitiveArch(component).widget =	gtk_notebook_new();
    
    gtk_notebook_set_tab_pos(GTK_NOTEBOOK(SpPrimitiveArch(component).widget), GTK_POS_TOP);
    gtk_object_set_data(GTK_OBJECT(SpPrimitiveArch(component).widget),
			"spComponent", (gpointer)component);

    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "switch_page", GTK_SIGNAL_FUNC(switchTabItemCB),
		       NULL);
    
    return;
}

void spTabBoxSetParamsArch(spComponent component)
{
    return;
}

void spTabBoxDestroyArch(spComponent component)
{
    return;
}

int spGetSelectedTabIndexArch(spComponent component)
{
    return gtk_notebook_current_page(GTK_NOTEBOOK(SpPrimitiveArch(component).widget));
}

void spAddTabItemArch(spComponent component, int index)
{
    SpComponentPart(component).top_offset += SP_DEFAULT_TAB_HEIGHT;

    SpPrimitiveArch(component).sub_widget = gtk_label_new(spGetTitle(component));
    gtk_notebook_append_page(GTK_NOTEBOOK(SpParentPrimitiveArch(component).widget),
			     SpPrimitiveArch(component).widget,
			     SpPrimitiveArch(component).sub_widget);
    
    return;
}
