/*
 *	spStatusBar_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spStatusBarP.h>

void spStatusBarPartInitArch(spComponent component)
{
    SpStatusBarArch(component).total_size = 0;
    SpStatusBarArch(component).last_frame = NULL;
    return;
}

void spStatusBarPartFreeArch(spComponent component)
{
    return;
}

void spStatusBarCreateArch(spComponent component, int *num_item)
{
    int i;
    int num_label = 0;
    GtkWidget *frame, *label;
    
    SpPrimitiveArch(component).widget = gtk_hbox_new(FALSE, 0);
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);

    SpStatusBarArch(component).total_size = 0;
    
    for (i = 0; i < SP_MAX_STATUS_ITEM; i++) {
	if (SpStatusBarPart(component).item_sizes == NULL
	    || SpStatusBarPart(component).item_sizes[i] <= 0) {
	    if (SpStatusBarPart(component).use_last_item == SP_TRUE
		|| i <= 0) {
		SpStatusBarPart(component).use_last_item = SP_TRUE;
		num_label = i + 1;
		    
		frame = gtk_frame_new(NULL);
		gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
		gtk_box_pack_start(GTK_BOX(SpPrimitiveArch(component).widget),
				   frame, TRUE, TRUE, 0);
		gtk_widget_show(frame);
		    
		label = gtk_label_new("");
#if GTK_CHECK_VERSION(1,2,0)
		gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
#else
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
#endif
		gtk_container_add(GTK_CONTAINER(frame), label);
		gtk_widget_show(label);

		SpStatusBarArch(component).last_frame = frame;
	    } else {
		num_label = i;
	    }
	    break;
	} else {
	    SpStatusBarArch(component).total_size += SpStatusBarPart(component).item_sizes[i];
		
	    frame = gtk_frame_new(NULL);
	    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
	    gtk_widget_set_usize(frame,
				 SpStatusBarPart(component).item_sizes[i], -1);
	    gtk_box_pack_start(GTK_BOX(SpPrimitiveArch(component).widget),
			       frame, FALSE, FALSE, 0);
	    gtk_widget_show(frame);
		
	    label = gtk_label_new("");
#if GTK_CHECK_VERSION(1,2,0)
	    gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
#else
	    gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
#endif
	    gtk_container_add(GTK_CONTAINER(frame), label);
	    gtk_widget_show(label);
	}
    }

    *num_item = num_label;

    return;
}

void spStatusBarSetParamsArch(spComponent component)
{
    return;
}

void spStatusBarDestroyArch(spComponent component)
{
    return;
}

spBool spSetStatusTextArch(spComponent component, int index, char *string)
{
    int i;
    GList *children;
    
    children = gtk_container_children(GTK_CONTAINER(SpPrimitiveArch(component).widget));
    
    for (i = 0; children != NULL; i++) {
	if (i == index) {
	    if (children->data != NULL) {
		children = gtk_container_children(GTK_CONTAINER(children->data));

		while (children != NULL) {
		    if (GTK_IS_LABEL(children->data) == TRUE) {
			gtk_label_set(GTK_LABEL(children->data), string);
			return SP_TRUE;
		    }
		    children = children->next;
		}
	    }
	    break;
	}

	children = children->next;
    }
    
    return SP_FALSE;
}
