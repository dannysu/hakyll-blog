/*
 *	spMenu_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spBase.h>
#include <sp/spOption.h>

#include <sp/spCanvas.h>

#include <sp/spFrameP.h>
#include <sp/spMenuItemP.h>
#include <sp/spMenuP.h>

void spPulldownMenuCreateArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    
    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }

    if (strnone(label)) {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
    }
    
    SpPrimitiveArch(component).widget = gtk_menu_new();

    SpPrimitiveArch(component).sub_widget = gtk_menu_item_new_with_label(label);
    gtk_widget_show(SpPrimitiveArch(component).sub_widget);

    gtk_menu_item_set_submenu(GTK_MENU_ITEM(SpPrimitiveArch(component).sub_widget),
			      SpPrimitiveArch(component).widget);

    if (spIsSubClass(SpGetParent(component), SpMenuBar) == SP_TRUE) {
	gtk_menu_bar_append(GTK_MENU_BAR(SpParentPrimitiveArch(component).widget),
			    SpPrimitiveArch(component).sub_widget);
    } else if (spIsSubClass(SpGetParent(component), SpMenu) == SP_TRUE) {
	gtk_menu_append(GTK_MENU(SpParentPrimitiveArch(component).widget),
			SpPrimitiveArch(component).sub_widget);
    }
    
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).sub_widget),
		       "enter_notify_event", GTK_SIGNAL_FUNC(spShowMenuHelpCB),
		       (gpointer)component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).sub_widget),
		       "leave_notify_event", GTK_SIGNAL_FUNC(spShowMenuHelpCB),
		       (gpointer)component);

    spDebug(30, "spPulldownMenuCreateArch", "done\n");

    return;
}

void spPulldownMenuSetParamsArch(spComponent component)
{
    
    spDebug(40, "spPulldownMenuSetParamsArch", "done\n");

    return;
}

static void canvasButtonPress(spComponent component, GdkEvent *event)
{
    long k;
    long component_id;
    spComponent canvas;
    spCallback *callback;
    
    canvas = SpGetParent(component);
    
    if (spIsCanvas(canvas) == SP_TRUE) {
	for (k = 0; k < SpPrimitivePart(canvas).num_callback; k++) {
	    if (streq(SpPrimitivePart(canvas).callbacks[k].call_name,
		      "button_press_event")) {
		callback = &SpPrimitivePart(canvas).callbacks[k];
			
		component_id = SpGetComponentId(callback->component);
		SpPrimitiveArch(callback->component).call_name = callback->call_name;
		SpPrimitiveArch(callback->component).event = event;
			
		spComponentCallbackFunc(callback);
			
		if (component_id != spGetDestroyedComponentId()
		    && callback != NULL && callback->component != NULL) {
		    SpPrimitiveArch(callback->component).call_name = NULL;
		    SpPrimitiveArch(callback->component).event = NULL;
		}
	    }
	}
    }

    return;
}

static gint popupMenuCB(GtkWidget *widget, GdkEvent *event)
{
    spComponent component;
    guint popup_button = 3;
    
     if (event->type == GDK_BUTTON_PRESS) {
        GdkEventButton *bevent = (GdkEventButton *)event;

	if ((component = (spComponent)gtk_object_get_data(GTK_OBJECT(widget),
							  "value")) != NULL) {
	    if (SpMenuPart(component).popup_button == SP_LBUTTON) {
		popup_button = 1;
	    } else if (SpMenuPart(component).popup_button == SP_RBUTTON) {
		popup_button = 3;
	    } else if (SpMenuPart(component).popup_button == SP_MBUTTON) {
		popup_button = 2;
	    }
	}

	if (bevent->button != popup_button) return FALSE;

	/* call canvas callback because signal is stopped by menu popup */
	canvasButtonPress(component, event);
	
        gtk_menu_popup(GTK_MENU(widget), NULL, NULL, NULL, NULL,
		       bevent->button, bevent->time);

        return TRUE;
    }

    return FALSE;
}

void spPopupMenuCreateArch(spComponent component)
{
    spPulldownMenuCreateArch(component);

    if (SpParentPrimitiveArch(component).widget != NULL) {
	gtk_object_set_data(GTK_OBJECT(SpPrimitiveArch(component).widget),
			    "value", (gpointer)component);
	gtk_signal_connect_object(GTK_OBJECT(SpParentPrimitiveArch(component).widget),
				  "event", GTK_SIGNAL_FUNC(popupMenuCB),
				  GTK_OBJECT(SpPrimitiveArch(component).widget));
    }
 
    return;
}

void spPopupMenuSetParamsArch(spComponent component)
{
    spPulldownMenuSetParamsArch(component);
    return;
}

void spMenuBarCreateArch(spComponent component)
{
    if (spIsCreated(component) == SP_FALSE
	&& spIsWindow(SpGetParent(component)) == SP_TRUE) {
	/* create menu bar */
	SpPrimitiveArch(component).widget = gtk_menu_bar_new();
	gtk_box_pack_start(GTK_BOX(SpParentPrimitiveArch(component).top_widget),
			   SpPrimitiveArch(component).widget, FALSE, FALSE, 0);
	gtk_widget_show(SpPrimitiveArch(component).widget);
	
	spDebug(30, "spMenuBarCreateArch", "created\n");
    }

    return;
}
