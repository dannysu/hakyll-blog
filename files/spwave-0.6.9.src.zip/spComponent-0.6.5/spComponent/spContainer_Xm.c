/*
 *	spContainer_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/BulletinB.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/DrawingA.h>
#include <Xm/ScrolledW.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spDialog.h>

#include <sp/spContainerP.h>

#define SP_DEFAULT_CONTAINER_MARGIN_BOTTOM 21

void spContainerCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];

    if (SpContainerPart(component).border_on == SP_TRUE) {
#ifndef LESSTIF_FRAME_BUG
	SpComponentPart(component).border_width = 2;

	if (SpContainerPart(component).title_on == SP_TRUE) {
	    SpComponentPart(component).margin_bottom = SP_DEFAULT_CONTAINER_MARGIN_BOTTOM;
	    SpPrimitiveArch(component).top_widget =
		XtVaCreateWidget("",
				 xmFrameWidgetClass, SpParentPrimitiveArch(component).widget,
				 XmNshadowType, XmSHADOW_ETCHED_IN,
				 XmNshadowThickness, 2,
				 XmNmarginWidth, 0,
				 XmNmarginHeight, 0,
				 NULL);
	    SpPrimitiveArch(component).sub_widget = 
		XtVaCreateManagedWidget(spGetTitle(component),
					xmLabelWidgetClass,
					SpPrimitiveArch(component).top_widget,
					XmNchildType, XmFRAME_TITLE_CHILD,
					NULL);
	} else {
	    SpPrimitiveArch(component).top_widget =
		XtVaCreateWidget("",
				 xmFrameWidgetClass, SpParentPrimitiveArch(component).widget,
				 XmNshadowType, XmSHADOW_IN,
				 XmNshadowThickness, 2,
				 XmNmarginWidth, 0,
				 XmNmarginHeight, 0,
				 NULL);
	}
	
	XtSetArg(args[narg], XmNchildType, XmFRAME_WORKAREA_CHILD); narg++;
#endif
    }
    
    if (spIsSubClass(SpGetParent(component), SpFileDialog) == SP_TRUE) {
	XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
	XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
	XtSetArg(args[narg], XmNentryAlignment, XmALIGNMENT_CENTER); narg++;
	XtSetArg(args[narg], XmNorientation, XmHORIZONTAL); narg++;
	SpPrimitiveArch(component).widget =
	    XtCreateWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			   xmRowColumnWidgetClass, 
			   (SpPrimitiveArch(component).top_widget != NULL ?
			    SpPrimitiveArch(component).top_widget :
			    SpParentPrimitiveArch(component).widget),
			   args, narg);
    } else {
	XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
	XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
	XtSetArg(args[narg], XmNresizePolicy, XmRESIZE_NONE); narg++;
	SpPrimitiveArch(component).widget =
	    XtCreateWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			   xmDrawingAreaWidgetClass, 
			   (SpPrimitiveArch(component).top_widget != NULL ?
			    SpPrimitiveArch(component).top_widget :
			    SpParentPrimitiveArch(component).widget),
			   args, narg);
    }
    
    if (SpPrimitiveArch(component).top_widget != NULL) {
	if (spIsVisible(component) == SP_TRUE) {
	    XtManageChild(SpPrimitiveArch(component).top_widget);
	}
	XtManageChild(SpPrimitiveArch(component).widget);
    } else {
	if (spIsVisible(component) == SP_TRUE) {
	    XtManageChild(SpPrimitiveArch(component).widget);
	}
    }
    
    return;
}

void spContainerSetParamsArch(spComponent component)
{
    return;
}
