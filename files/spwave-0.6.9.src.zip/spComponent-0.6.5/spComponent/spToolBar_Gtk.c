/*
 *	spToolBar_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spGraphicsP.h>
#include <sp/spToolBarP.h>

extern spTopLevel sp_toplevel;

void spToolBarPartInitArch(spComponent component)
{
    SpToolBarArch(component).bitmap = NULL;
    return;
}

void spToolBarPartFreeArch(spComponent component)
{
    return;
}

static void toolBarRealizeCB(GtkWidget *widget, spComponent component)
{
    if (SpToolBarPart(component).bitmap_data != NULL) {
	GdkColor color;

	spGetColorValue("#c0c0c0", &color);
	
	SpPrimitiveArch(component).pixmap = 
	    gdk_pixmap_create_from_xpm_d(SpPrimitiveArch(component).widget->window,
					 &SpToolBarArch(component).bitmap, &color,
					 SpToolBarPart(component).bitmap_data);
    }
    
    return;
}

void spToolBarCreateArch(spComponent component)
{
    SpPrimitiveArch(component).widget =
	gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,
			GTK_TOOLBAR_ICONS);
    gtk_container_border_width(GTK_CONTAINER(SpPrimitiveArch(component).widget) ,0);
    gtk_toolbar_set_space_size(GTK_TOOLBAR(SpPrimitiveArch(component).widget), 0);
#if 1
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
#else
    gtk_box_pack_start(GTK_BOX(SpParentPrimitiveArch(component).top_widget),
		       SpPrimitiveArch(component).widget, FALSE, FALSE, 0);
#endif
    
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "realize", GTK_SIGNAL_FUNC(toolBarRealizeCB),
		       (gpointer)component);
    
    if (spIsVisible(component) == SP_TRUE) {
	gtk_widget_show(SpPrimitiveArch(component).widget);
    }
    
    spDebug(30, "spToolBarCreateArch", "create done\n");

    return;
}

void spToolBarSetParamsArch(spComponent component)
{
    return;
}
    
void spToolBarDestroyArch(spComponent component)
{
    if (SpToolBarArch(component).bitmap != NULL) {
	gdk_bitmap_unref(SpToolBarArch(component).bitmap);
    }
    
    return;
}
