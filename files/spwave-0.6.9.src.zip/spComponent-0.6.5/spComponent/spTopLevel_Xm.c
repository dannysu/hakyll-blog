/*
 *	spTopLevel_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>
#include <sp/spComponentP.h>
#include <sp/spTopLevelP.h>
#include <sp/spGraphicsP.h>

static char *sp_def_resources[] = {
    "*XmText.translations: #override \
        Ctrl<Key>f: forward-character()\\n \
        Ctrl<Key>b: backward-character()\\n \
        Ctrl<Key>a: beginning-of-line()\\n \
        Ctrl<Key>e: end-of-line()\\n \
        Ctrl<Key>n: next-line()\\n \
        Ctrl<Key>p: previous-line()\\n \
        Ctrl<Key>k: delete-to-end-of-line()\\n \
        Ctrl<Key>h: delete-previous-character()\\n \
        Ctrl<Key>d: delete-next-character()",
    "*XmTextField.translations: #override \
        Ctrl<Key>f: forward-character()\\n \
        Ctrl<Key>b: backward-character()\\n \
        Ctrl<Key>a: beginning-of-line()\\n \
        Ctrl<Key>e: end-of-line()\\n \
        Ctrl<Key>k: delete-to-end-of-line()\\n \
        Ctrl<Key>h: delete-previous-character()\\n \
        Ctrl<Key>d: delete-next-character()",
    "*XmCSText.translations: #override \
        Ctrl<Key>f: forward-character()\\n \
        Ctrl<Key>b: backward-character()\\n \
        Ctrl<Key>a: beginning-of-line()\\n \
        Ctrl<Key>e: end-of-line()\\n \
        Ctrl<Key>n: next-line()\\n \
        Ctrl<Key>p: previous-line()\\n \
        Ctrl<Key>k: delete-to-end-of-line()\\n \
        Ctrl<Key>h: delete-previous-character()\\n \
        Ctrl<Key>d: delete-next-character()",
    "*ComboPopup*XmList.translations: #override <Btn2Down>:",
    "*XmText.background: #ffffff",
    "*XmTextField.background: #ffffff",
    "*XmCSText.background: #ffffff",
    "*XmScrolledWindow.background: #c0c0c0",
    "*XmList.background: #ffffff",
    "*background: #c0c0c0",
    "*selectionName.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmLabelGadget.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmLabel.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmCascadeButtonGadget.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmCascadeButton.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmPushButtonGadget.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmPushButton.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmToggleButtonGadget.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*XmToggleButton.fontList: -*-helvetica-medium-r-normal--14-*-iso8859-1;-*-fixed-medium-r-normal--14-*:",
    "*fontList: -*-fixed-medium-r-normal--14-*:",
    "*XmScrollBar*minimum: 0",
    "*XmScrollBar*maximum: 100",
    "*XmScrollBar*sliderSize: 100",
    /* if kinput2 version is old, uncomment following part */
#ifdef USE_OLD_KINPUT2
#if defined(linux) && defined(MOTIF_STATIC)
    "*preeditType: none",
#endif
#endif
    NULL,
};

static char *sp_topname = NULL;
static char **sp_resources = NULL;
static long sp_num_resource = 0;

static void setResources(char **resources)
{
    long i;
    long num;
    long offset;

    if (resources == NULL) return;
    
    for (num = 0;; num++) {
	if (resources[num] == NULL) {
	    break;
	}
    }
    offset = sp_num_resource;
    sp_num_resource += num;
    
    sp_resources = xrealloc(sp_resources, sp_num_resource + 1, char *);
    
    for (i = 0; i <= num; i++) {
	sp_resources[i + offset] = resources[i];
    }
    
    spDebug(50, "setResources", "done\n");
    
    return;
}

void spSetResources(char **resources)
{
    if (sp_resources == NULL) {
	setResources(sp_def_resources);
    }
    setResources(resources);
    
    return;
}

void spTopLevelPartInitArch(spTopLevel toplevel)
{
    SpTopLevelArch(toplevel).widget = NULL;
    SpTopLevelArch(toplevel).display = NULL;
    SpTopLevelArch(toplevel).screen = NULL;
    SpTopLevelArch(toplevel).resources = NULL;
    return;
}

void spTopLevelPartFreeArch(spTopLevel toplevel)
{
    return;
}

void spTopLevelCreateArch(spTopLevel toplevel)
{
    XGCValues values;
    char **miss, *def;
    int n_miss;

#if 1
#if defined(HAVE_PTHREAD) && XmVersion >= 2001
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	if (!XtToolkitThreadInitialize()) {
	    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
	}
    }
#else
    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
#endif
#else
    /* The main loop in a thread seems not to work correctly,
       so I decided not to support threads for Motif. */
    SpTopLevelPart(toplevel).thread_safe = SP_FALSE;
#endif
    
    spSetResources(SpTopLevelArch(toplevel).resources);
    
    /* initialize XToolkit */
    SpTopLevelArch(toplevel).widget =
	XtAppInitialize(&(SpTopLevelArch(toplevel).app_context), sp_topname,
			NULL, 0,
			SpTopLevelPart(toplevel).argcp,
			*(SpTopLevelPart(toplevel).argvp),
			sp_resources,
			NULL, 0);
    SpTopLevelArch(toplevel).display = XtDisplay(SpTopLevelArch(toplevel).widget);
    SpTopLevelArch(toplevel).screen = XtScreen(SpTopLevelArch(toplevel).widget);
    SpTopLevelArch(toplevel).colormap =
	DefaultColormapOfScreen(SpTopLevelArch(toplevel).screen);
    
    spDebug(50, "spTopLevelCreateArch", "initialize done\n");
    
    SpTopLevelArch(toplevel).font_set =
	XCreateFontSet(SpTopLevelArch(toplevel).display,
		       "-*-fixed-medium-r-normal--14-*",
		       &miss, &n_miss, &def);
    if (SpTopLevelArch(toplevel).font_set == NULL) {
	SpTopLevelArch(toplevel).font_set =
	    XCreateFontSet(SpTopLevelArch(toplevel).display,
			   "-*-*-*-*-*--*-*",
			   &miss, &n_miss, &def);
    }
    spDebug(50, "spTopLevelCreateArch", "create font done\n");
    
    values.foreground = BlackPixelOfScreen(SpTopLevelArch(toplevel).screen);
    values.background = WhitePixelOfScreen(SpTopLevelArch(toplevel).screen);
    SpTopLevelArch(toplevel).fg_gc =
	XCreateGC(SpTopLevelArch(toplevel).display,
		  RootWindowOfScreen(SpTopLevelArch(toplevel).screen),
		  GCForeground | GCBackground, &values);
    /*values.foreground = WhitePixelOfScreen(SpTopLevelArch(toplevel).screen);*/
    values.foreground = spGetColorPixelXm("#c0c0c0");
    values.background = BlackPixelOfScreen(SpTopLevelArch(toplevel).screen);
    SpTopLevelArch(toplevel).bg_gc =
	XCreateGC(SpTopLevelArch(toplevel).display,
		  RootWindowOfScreen(SpTopLevelArch(toplevel).screen),
		  GCForeground | GCBackground, &values);
    spDebug(50, "spTopLevelCreateArch", "setup gc done\n");

    return;
}

void spTopLevelSetParamsArch(spTopLevel toplevel)
{
    return;
}
    
void spTopLevelDestroyArch(spTopLevel toplevel)
{
    return;
}

void spQuitArch(int status)
{
    return;
}

int spWaitEventArch(spTopLevel toplevel)
{
    XEvent event;
    
    XtAppNextEvent(SpTopLevelArch(toplevel).app_context, &event);
    XtDispatchEvent(&event);
    
    return 1;
}

int spDispatchEventArch(spTopLevel toplevel)
{
    int flag = 0;
    
    while (XtAppPending(SpTopLevelArch(toplevel).app_context)) {
	spWaitEventArch(toplevel);
	flag = 1;
    }
    
    return flag;
}

int spMainLoopArch(spTopLevel toplevel)
{
    spThreadEnter();
    XtAppMainLoop(SpTopLevelArch(toplevel).app_context);
    spThreadLeave();
    
    return 0;
}

spBool spThreadEnterArch(spTopLevel toplevel)
{
#if defined(HAVE_PTHREAD) && XmVersion >= 2001
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	XtAppLock(SpTopLevelArch(toplevel).app_context);
	return SP_TRUE;
    }
#endif
    
    return SP_FALSE;
}

spBool spThreadLeaveArch(spTopLevel toplevel)
{
#if defined(HAVE_PTHREAD) && XmVersion >= 2001
    if (SpTopLevelPart(toplevel).thread_safe == SP_TRUE) {
	XFlush(SpTopLevelArch(toplevel).display);
	/*XSync(SpTopLevelArch(toplevel).display, False);*/
	XtAppUnlock(SpTopLevelArch(toplevel).app_context);
	return SP_TRUE;
    }
#endif
    
    return SP_FALSE;
}
