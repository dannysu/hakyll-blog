/*
 *	spMenu_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/RowColumn.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/Separator.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>

#include <sp/spBase.h>
#include <sp/spOption.h>

#include <sp/spMenuItemP.h>
#include <sp/spMenuP.h>

void spPulldownMenuCreateArch(spComponent component)
{
    XmString xmstr;
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    int narg = 0, narg2 = 0;
    Arg args[10], args2[10];

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }
    
#ifdef SP_USE_TEAROFF_MENU
    if (SpMenuPart(component).tearoff_flag == SP_TRUE) {
	XtSetArg(args2[narg2], XmNtearOffModel, XmTEAR_OFF_ENABLED); narg2++;
    }
#endif
    
    SpPrimitiveArch(component).sub_widget =
	XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			      xmCascadeButtonWidgetClass,
			      SpParentPrimitiveArch(component).widget,
			      args, narg);
    
    SpPrimitiveArch(component).widget =
	XmCreatePulldownMenu(SpParentPrimitiveArch(component).widget, "", args2, narg2);
    XtVaSetValues(SpPrimitiveArch(component).sub_widget,
		  XmNsubMenuId, SpPrimitiveArch(component).widget,
		  NULL);
    
    if (SpMenuPart(component).help_flag == SP_TRUE) {
	XtVaSetValues(SpParentPrimitiveArch(component).widget,
		      XmNmenuHelpWidget, SpPrimitiveArch(component).sub_widget,
		      NULL);
    }
    
    XtAddEventHandler(SpPrimitiveArch(component).sub_widget, EnterWindowMask, False,
		      (XtEventHandler)spShowMenuHelpCB, (XtPointer)component);
    XtAddEventHandler(SpPrimitiveArch(component).sub_widget, LeaveWindowMask, False,
		      (XtEventHandler)spShowMenuHelpCB, (XtPointer)component);
    
    if (!strnone(label)) {
	xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).sub_widget,
		      XmNmnemonic, mnemonic,
		      XmNlabelString, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }
    
    spDebug(40, "spPulldownMenuCreateArch", "done\n");

    return;
}

void spPulldownMenuSetParamsArch(spComponent component)
{
    XmString xmstr;
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	    XtVaSetValues(SpPrimitiveArch(component).sub_widget,
			  XmNmnemonic, mnemonic,
			  XmNlabelString, xmstr,
			  NULL);
	    XmStringFree(xmstr);
	}
    }
    
    spDebug(40, "spPulldownMenuSetParamsArch", "done\n");

    return;
}

static void popupMenuCB(Widget widget, spComponent component, XButtonEvent *event)
{
    unsigned int popup_button = Button3;
    
    if (component == NULL) return;

    if (SpMenuPart(component).popup_button == SP_LBUTTON) {
	popup_button = Button1;
    } else if (SpMenuPart(component).popup_button == SP_RBUTTON) {
	popup_button = Button3;
    } else if (SpMenuPart(component).popup_button == SP_MBUTTON) {
	popup_button = Button2;
    }
    
    if (event->button != popup_button) return;

    XmMenuPosition(SpPrimitiveArch(component).widget, event);
    XtManageChild(SpPrimitiveArch(component).widget);
    
    return;
}

void spPopupMenuCreateArch(spComponent component)
{
    XmString xmstr;
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    Widget widget;
    int narg = 0;
    Arg args[10];
    
    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }
    
#ifdef SP_USE_TEAROFF_MENU
    if (SpMenuPart(component).tearoff_flag == SP_TRUE) {
	XtSetArg(args[narg], XmNtearOffModel, XmTEAR_OFF_ENABLED); narg++;
    }
#endif
    
    SpPrimitiveArch(component).widget =
	XmCreatePopupMenu(SpParentPrimitiveArch(component).widget, "", args, narg);
    
    if (!strnone(label)) {
	/* create label widget */
	SpPrimitiveArch(component).sub_widget =
	    XtCreateManagedWidget("",
				  xmLabelWidgetClass, SpPrimitiveArch(component).widget,
				  NULL, 0);
	    
	/* set label */
	xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).sub_widget,
		      XmNmnemonic, mnemonic,
		      XmNlabelString, xmstr,
		      NULL);
	XmStringFree(xmstr);
	    
	/* create separator widget */
	widget = XtCreateManagedWidget("",
				       xmSeparatorWidgetClass,
				       SpPrimitiveArch(component).widget,
				       NULL, 0);
    }
    
    XtAddEventHandler(SpParentPrimitiveArch(component).widget, ButtonPressMask, False,
		      (XtEventHandler)popupMenuCB, (XtPointer)component);

    spDebug(40, "spPopupMenuCreateArch", "done\n");

    return;
}

void spPopupMenuSetParamsArch(spComponent component)
{
    XmString xmstr;
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label) && SpPrimitiveArch(component).sub_widget != NULL) {
	    /* set label */
	    xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	    XtVaSetValues(SpPrimitiveArch(component).sub_widget,
			  XmNmnemonic, mnemonic,
			  XmNlabelString, xmstr,
			  NULL);
	    XmStringFree(xmstr);
	}
    }

    spDebug(40, "spPopupMenuSetParamsArch", "done\n");

    return;
}

void spMenuBarCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];

    if (spIsCreated(component) == SP_FALSE) {
	/* create menu bar */
	XtSetArg(args[narg], XmNpopupEnabled, True); narg++;
	SpPrimitiveArch(component).widget =
	    XmCreateMenuBar((SpParentPrimitiveArch(component).top_widget != NULL ?
			     SpParentPrimitiveArch(component).top_widget :
			     SpParentPrimitiveArch(component).widget),
			    (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
			    args, narg);
	XtManageChild(SpPrimitiveArch(component).widget);
    }

    return;
}
