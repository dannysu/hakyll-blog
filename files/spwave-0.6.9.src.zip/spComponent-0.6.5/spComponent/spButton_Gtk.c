/*
 *	spButton_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItemP.h>
#include <sp/spButtonP.h>

static void createRadioButton(spComponent component, char *label)
{
    static GSList *group = NULL;

    if (group == NULL) {
	SpPrimitiveArch(component).widget =
	    gtk_radio_button_new_with_label(NULL, label);
	group = gtk_radio_button_group(GTK_RADIO_BUTTON(SpPrimitiveArch(component).widget));
	
	SpPrimitivePart(component).index = SP_RADIO_GROUP_START;
    } else {
	SpPrimitiveArch(component).widget =
	    gtk_radio_button_new_with_label(group, label);
	group = gtk_radio_button_group(GTK_RADIO_BUTTON(SpPrimitiveArch(component).widget));
	
	if (SpButtonPart(component).radio_end == SP_TRUE) {
	    group = NULL;
	    SpPrimitivePart(component).index = SP_RADIO_GROUP_END;
	} else {
	    SpPrimitivePart(component).index = SP_RADIO_GROUP_MEMBER;
	}
    }
    
    return;
}

void spButtonCreateArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_BUTTON_LABEL] = "";

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    } else {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
    }
    
    if (spIsSubClass(component, SpCheckBox)) {
	SpPrimitiveArch(component).widget = gtk_check_button_new_with_label(label);
    } else if (spIsSubClass(component, SpRadioButton)) {
	createRadioButton(component, label);
    } else {
	SpPrimitiveArch(component).widget = gtk_button_new_with_label(label);
	if (SpButtonPart(component).default_flag == SP_TRUE) {
	    GTK_WIDGET_SET_FLAGS(SpPrimitiveArch(component).widget, GTK_CAN_DEFAULT);
	    gtk_window_set_default(GTK_WINDOW(SpFrameArch(SpGetWindow(component)).toplevel),
				   SpPrimitiveArch(component).widget);
	}
    }

    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    return;
}

void spButtonSetParamsArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_BUTTON_LABEL] = "";

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    GList *children;

	    children = gtk_container_children(GTK_CONTAINER(SpPrimitiveArch(component).widget));

	    while (children != NULL) {
		if (children->data != NULL && GTK_IS_LABEL(children->data) == TRUE) {
		    gtk_label_set(GTK_LABEL(children->data), label);
		    break;
		}

		children = children->next;
	    }
	}
    }

    return;
}

void spSetToggleStateArch(spComponent component)
{
    if (spIsSubClass(component, SpMenuItem) == SP_TRUE) {
	gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(SpPrimitiveArch(component).widget),
				      (SpButtonPart(component).set == SP_ON ? TRUE : FALSE));
    } else if (SpPrimitiveArch(component).widget != NULL) {
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(SpPrimitiveArch(component).widget),
				    (SpButtonPart(component).set == SP_ON ? TRUE : FALSE));
    }
    
    return;
}

void spGetToggleStateArch(spComponent component)
{
    spDebug(30, "spGetToggleStateArch", "in\n");
    
    if (spIsSubClass(component, SpMenuItem) == SP_TRUE) {
	if (GTK_CHECK_MENU_ITEM(SpPrimitiveArch(component).widget)->active) {
	    SpButtonPart(component).set = SP_TRUE;
	} else {
	    SpButtonPart(component).set = SP_FALSE;
	}
    } else if (SpPrimitiveArch(component).widget != NULL) {
	if (GTK_TOGGLE_BUTTON(SpPrimitiveArch(component).widget)->active) {
	    SpButtonPart(component).set = SP_TRUE;
	} else {
	    SpButtonPart(component).set = SP_FALSE;
	}
    }

    return;
}
