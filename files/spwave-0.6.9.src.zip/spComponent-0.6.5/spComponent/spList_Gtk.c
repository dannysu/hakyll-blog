/*
 *	spList_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spText.h>
#include <sp/spComboBox.h>

#include <sp/spListP.h>

void spListCreateArch(spComponent component)
{
    SpPrimitiveArch(component).top_widget = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (SpPrimitiveArch(component).top_widget),
				    GTK_POLICY_AUTOMATIC, 
				    GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).top_widget);
    gtk_widget_show(SpPrimitiveArch(component).top_widget);

    SpPrimitiveArch(component).widget = gtk_list_new();
    gtk_list_set_selection_mode(GTK_LIST(SpPrimitiveArch(component).widget), GTK_SELECTION_BROWSE);
    gtk_widget_set_events(SpPrimitiveArch(component).widget, GDK_BUTTON_PRESS_MASK);
#if GTK_CHECK_VERSION(1,2,0)
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(SpPrimitiveArch(component).top_widget),
		      SpPrimitiveArch(component).widget);
#else
    gtk_container_add(GTK_CONTAINER(SpPrimitiveArch(component).top_widget),
		      SpPrimitiveArch(component).widget);
#endif
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    return;
}

void spListSetParamsArch(spComponent component)
{
    return;
}

void spListGetParamsArch(spComponent component)
{
    return;
}

static char *getListString(GtkWidget *list_item)
{
    GList *children;
    GtkWidget *label;
    char *string = NULL;

    children = gtk_container_children(GTK_CONTAINER(list_item));
    label = (GtkWidget *)g_list_nth_data(children, 0);
    gtk_label_get(GTK_LABEL(label), &string);
    
    return string;
}

int spAddListIndexArch(spComponent component, char *item, int index)
{
    GtkWidget *widget;
    GtkWidget *list_item;
    GList *dlist = NULL;

    spDebug(50, "spAddListIndexArch", "in: index = %d\n", index);
    
    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    list_item = gtk_list_item_new_with_label(item);
    dlist = g_list_prepend(dlist, list_item);
    gtk_widget_show(list_item);

    if (index < 0) {
	index = g_list_length(GTK_LIST(widget)->children);
	gtk_list_append_items(GTK_LIST(widget), dlist);
    } else {
	gtk_list_insert_items(GTK_LIST(widget), dlist, index);
    }

    spDebug(50, "spAddListIndexArch", "done\n");
    
    return index;
}

int spAddListItemArch(spComponent component, char *item)
{
    return spAddListIndexArch(component, item, -1);
}

static GtkWidget *findListItem(GtkWidget *widget, char *item, int *index)
{
    int i;
    char *string;
    GtkWidget *list_item;
    GList *children;

    children = GTK_LIST(widget)->children;

    for (i = 0; children != NULL; i++) {
	if (children->data == NULL) {
	    break;
	}
	
	list_item = GTK_WIDGET(children->data);
	
	if ((string = getListString(list_item)) != NULL) {
	    spDebug(10, "findListItem", "index = %d, item = %s, string = %s\n",
		    i, item, string);
	    
	    if (streq(item, string)) {
		if (index != NULL) *index = i;
	    
		return list_item;
	    }
	}

	children = children->next;
    }

    return NULL;
}

static int findListIndex(GtkWidget *widget, char *item)
{
    int index;

    if (findListItem(widget, item, &index) != NULL) {
	return index;
    } else {
	return -1;
    }
}

static GtkWidget *getListItem(GtkWidget *widget, int index)
{
    int i;
    GtkWidget *list_item;
    GList *children;

    children = GTK_LIST(widget)->children;

    for (i = 0; children != NULL; i++) {
	if (children->data == NULL) {
	    break;
	}
	
	if (i == index) {
	    list_item = GTK_WIDGET(children->data);
	    return list_item;
	}

	children = children->next;
    }

    return NULL;
}

int spDeleteListItemArch(spComponent component, char *item)
{
    int index = -1;
    GtkWidget *widget;
    GtkWidget *list_item;
    GList *dlist = NULL;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    if ((list_item = findListItem(widget, item, &index)) != NULL) {
	dlist = g_list_prepend(dlist, list_item);
	gtk_list_remove_items(GTK_LIST(widget), dlist);
	g_list_free(dlist);
    }

    return index;
}

int spDeleteListIndexArch(spComponent component, int index)
{
    GtkWidget *widget;
    GtkWidget *list_item;
    GList *dlist = NULL;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    if ((list_item = getListItem(widget, index)) != NULL) {
	dlist = g_list_prepend(dlist, list_item);
	gtk_list_remove_items(GTK_LIST(widget), dlist);
	g_list_free(dlist);

	return index;
    }

    return -1;
}

int spFindListItemArch(spComponent component, char *item)
{
    GtkWidget *widget;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    return findListIndex(widget, item);
}

int spSelectListItemArch(spComponent component, char *item)
{
    int index = -1;
    GtkWidget *widget;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    if ((index = findListIndex(widget, item)) >= 0) {
	gtk_list_select_item(GTK_LIST(widget), index);
    }
    spDebug(1, "spSelectListItemArch", "item = %s, index = %d\n", item, index);

    return index;
}

int spSelectListIndexArch(spComponent component, int index)
{
    GtkWidget *widget;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    gtk_list_select_item(GTK_LIST(widget), index);
    
    return index;
}

char *xspGetSelectedListItemArch(spComponent component)
{
    char *item = NULL;
    GtkWidget *widget;
    GtkWidget *list_item;
    GList *selection;
    
    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    selection = GTK_LIST(widget)->selection;

    if (selection != NULL) {
	list_item = GTK_WIDGET(selection->data);
	spDebug(50, "xspGetSelectedListItemArch", "selection found\n");

	if ((item = getListString(list_item)) != NULL) {
	    return strclone(item);
	}
    }
    
    return NULL; 
}

int spGetSelectedListIndexArch(spComponent component)
{
    int i;
    GtkWidget *widget;
    GtkWidget *list_item;
    GList *selection;
    GList *children;

    if (spIsComboBox(component) == SP_TRUE) {
	widget = GTK_COMBO(SpPrimitiveArch(component).widget)->list;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    selection = GTK_LIST(widget)->selection;

    if (selection != NULL) {
	list_item = GTK_WIDGET(selection->data);
	spDebug(50, "spGetSelectedListIndexArch", "selection found\n");

	children = GTK_LIST(widget)->children;

	for (i = 0; children != NULL; i++) {
	    if (children->data == NULL) {
		break;
	    }
	
	    if (list_item == GTK_WIDGET(children->data)) {
		return i;
	    }
	    children = children->next;
	}
    }

    return -1; 
}
