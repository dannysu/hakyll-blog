/*
 *	spTabBox_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spTabBoxP.h>

extern spTopLevel sp_toplevel;

void spTabBoxPartInitArch(spComponent component)
{
    return;
}

void spTabBoxPartFreeArch(spComponent component)
{
    return;
}

void spTabBoxCreateArch(spComponent component)
{
    SpComponentPart(component).border_width = 4;

    /* create tab control */
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(/*WS_EX_CONTROLPARENT*/0, WC_TABCONTROL,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN
		       | WS_TABSTOP | WS_GROUP | TCS_TABS,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComponentPart(component).current_height,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));

    return;
}

void spTabBoxSetParamsArch(spComponent component)
{
    return;
}

void spTabBoxDestroyArch(spComponent component)
{
    return;
}

int spGetSelectedTabIndexArch(spComponent component)
{
    return TabCtrl_GetCurSel(SpPrimitiveArch(component).hwnd);
}

void spAddTabItemArch(spComponent component, int index)
{
    TC_ITEM titem;
    spComponent parent;

    parent = SpGetParent(component);
    SpComponentPart(component).top_offset += SP_DEFAULT_TAB_HEIGHT;
    
    titem.mask = TCIF_TEXT | TCIF_IMAGE;
    titem.iImage = -1; 
    titem.pszText = spGetTitle(component); 

    TabCtrl_InsertItem(SpPrimitiveArch(parent).hwnd, index, &titem);

    return;
}
