/*
 *	spContainer_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTabBox.h>
#include <sp/spDialog.h>

#include <sp/spFrameP.h>
#include <sp/spContainerP.h>

#define SP_DEFAULT_CONTAINER_MARGIN_BOTTOM 17

void spContainerCreateArch(spComponent component)
{
    if (SpContainerPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).border_width = 2;
	
	if (SpContainerPart(component).title_on == SP_TRUE) {
	    SpComponentPart(component).margin_bottom = SP_DEFAULT_CONTAINER_MARGIN_BOTTOM;
	    SpPrimitiveArch(component).top_widget =
		gtk_frame_new(spGetTitle(component));
	    gtk_frame_set_shadow_type(GTK_FRAME(SpPrimitiveArch(component).top_widget),
				      GTK_SHADOW_ETCHED_IN);
	} else {
	    SpPrimitiveArch(component).top_widget = gtk_frame_new(NULL);
	    gtk_frame_set_shadow_type(GTK_FRAME(SpPrimitiveArch(component).top_widget),
				      GTK_SHADOW_IN);
	}
	gtk_container_border_width(GTK_CONTAINER(SpPrimitiveArch(component).top_widget),
				   SpComponentPart(component).border_width);
	
	if (spIsSubClass(SpGetParent(component), SpFileDialog) == SP_TRUE) {
	    gtk_box_pack_end(GTK_BOX(GTK_FILE_SELECTION(SpParentPrimitiveArch(component).widget)->main_vbox),
			     SpPrimitiveArch(component).top_widget, TRUE, TRUE, 5);
	} else if (spIsSubClass(SpGetParent(component), SpTabBox) == SP_FALSE) {
	    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			      SpPrimitiveArch(component).top_widget);
	}
	gtk_widget_show(SpPrimitiveArch(component).top_widget);
    }

    SpPrimitiveArch(component).widget =	gtk_fixed_new();
    spSetStyleGtk(component, SpPrimitiveArch(component).widget);

    if (SpPrimitiveArch(component).top_widget != NULL) {
	gtk_container_add(GTK_CONTAINER(SpPrimitiveArch(component).top_widget),
			  SpPrimitiveArch(component).widget);
    } else {
	if (spIsSubClass(SpGetParent(component), SpFileDialog) == SP_TRUE) {
	    spDebug(30, "spContainerCreateArch", "parent is SpFileDialog\n");
	    gtk_box_pack_start(GTK_BOX(GTK_FILE_SELECTION(SpParentPrimitiveArch(component).widget)->main_vbox),
			     SpPrimitiveArch(component).widget, TRUE, TRUE, 0);
	} else if (spIsSubClass(SpGetParent(component), SpTabBox) == SP_FALSE) {
	    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			      SpPrimitiveArch(component).widget);
	}
    }
    
    if (spIsVisible(component) == SP_TRUE
	||spIsSubClass(SpGetParent(component), SpTabBox) == SP_TRUE) {
	gtk_widget_show(SpPrimitiveArch(component).widget);
    }
    
    return;
}

void spContainerSetParamsArch(spComponent component)
{
    return;
}
