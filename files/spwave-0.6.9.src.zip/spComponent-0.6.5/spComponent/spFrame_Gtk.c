/*
 *	spFrame_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDialog.h>
#include <sp/spContainer.h>

#include <sp/spFrameP.h>
#include <sp/spStatusBarP.h>

#include <gdk/gdkkeysyms.h>

spBool sp_grabbed_loop = SP_FALSE;
static GtkWidget *sp_grabbed_widget = NULL;

static void postMessage(spComponent component, char *call_name)
{
    long k;
    long component_id;
    long num_callback;
    
    if ((component_id = SpGetComponentId(component)) == spGetDestroyedComponentId()) {
	/* now destroying */
	component_id = 0;
    }
    num_callback = SpPrimitivePart(component).num_callback;
    
    for (k = 0; k < num_callback; k++) {
	if (streq(SpPrimitivePart(component).callbacks[k].call_name, call_name)
	    && SpPrimitivePart(component).callbacks[k].component != NULL) {
	    SpPrimitiveArch(SpPrimitivePart(component).callbacks[k].component).call_name = call_name;
	    spComponentCallbackFunc(&SpPrimitivePart(component).callbacks[k]);

	    if (component_id == spGetDestroyedComponentId()) {
		break;
	    }
	}
    }

    return;
}

void spFramePartInitArch(spComponent component)
{
    SpFrameArch(component).toplevel = NULL;
    SpFrameArch(component).accel_group = NULL;
    SpFrameArch(component).tooltips = NULL;
    SpFrameArch(component).prev_width = 0;
    SpFrameArch(component).prev_height = 0;

    SpFrameArch(component).drop_func_id = 0;
    SpFrameArch(component).drop_call_func = NULL;
    SpFrameArch(component).drop_call_data = NULL;
    
    return;
}

void spFramePartFreeArch(spComponent component)
{
    if (SpFrameArch(component).accel_group != NULL) {
#if GTK_CHECK_VERSION(1,2,0)
	if (SpFrameArch(component).toplevel != NULL) {
	    gtk_window_remove_accel_group(GTK_WINDOW(SpFrameArch(component).toplevel),
					  SpFrameArch(component).accel_group);
	}
	gtk_accel_group_unref(SpFrameArch(component).accel_group);
#else
	if (SpFrameArch(component).toplevel != NULL) {
	    gtk_window_remove_accelerator_table(GTK_WINDOW(SpFrameArch(component).toplevel),
						SpFrameArch(component).accel_group);
	}
	gtk_accelerator_table_unref(SpFrameArch(component).accel_group);
#endif
	SpFrameArch(component).accel_group = NULL;
    }
	
    if (SpFrameArch(component).tooltips != NULL) {
	gtk_object_destroy(GTK_OBJECT(SpFrameArch(component).tooltips));
	SpFrameArch(component).tooltips = NULL;
    }
    
    return;
}

static void adjustComponentSizeCB(GtkWidget *widget, GdkEventConfigure *event,
				  spComponent component)
{
    if (event->width != SpFrameArch(component).prev_width
	|| event->height != SpFrameArch(component).prev_height) {
	gtk_widget_set_usize(SpFrameArch(component).toplevel, event->width, event->height);
	SpFrameArch(component).toplevel->allocation.width = event->width;
	SpFrameArch(component).toplevel->allocation.height = event->height;

	spDebug(30, "adjustComponentSizeCB", "event: (%d, %d), window: (%d, %d)\n",
		event->width, event->height,
		SpFrameArch(component).prev_width, SpFrameArch(component).prev_height);
	SpFrameArch(component).prev_width = event->width;
	SpFrameArch(component).prev_height = event->height;
	
	spAdjustComponentSize(component);
    }
    
    return;
}

static gint deleteEventCB(GtkWidget *widget, GdkEvent *event,
			  spComponent component)
{
    gint flag = TRUE;

    if (sp_grabbed_widget != NULL && sp_grabbed_widget != widget) {
	/* do nothing, if a grabbed widget exists. */
	return TRUE;
    }

    if (component != NULL && SpFrameArch(component).toplevel != NULL) {
	if (SpFramePart(component).close_style == SP_DESTROY_CLOSE) {
	    spDebug(30, "deleteEventCB", "destroy window\n");
	    
	    if (spIsSubClass(component, SpMainFrame) == SP_TRUE) {
		spQuit(0);
		flag = TRUE;
	    } else {
		long component_id;
		
		component_id = SpGetComponentId(component);
		SpFrameArch(component).toplevel = NULL;
		SpPrimitiveArch(component).top_widget = NULL;
		SpPrimitiveArch(component).widget = NULL;
	    
		gtk_widget_destroy(widget);

		if (component_id != spGetDestroyedComponentId()) {
		    spDestroyComponent(component);
		}
		
		flag = TRUE;
	    }
	} else if (SpFramePart(component).close_style == SP_CALLBACK_CLOSE) {
	    postMessage(component, SppCloseCallback);
	    flag = TRUE;
	} else if (SpFramePart(component).close_style == SP_UNMAP_CLOSE) {
	    spPopdownWindow(component);
	    postMessage(component, SppCloseCallback);
	    flag = TRUE;
	}
    }
    
    return flag;
}

static gint keyPressEventCB(GtkWidget *widget, GdkEvent *event,
			    spComponent component)
{
    gint flag = FALSE;
    
    if (event->type == GDK_KEY_PRESS) {
	if (event->key.keyval == GDK_Escape
	    && SpFramePart(component).cancel_button != NULL) {
	    gtk_widget_activate(SpPrimitiveArch(SpFramePart(component).cancel_button).widget);  
	}
    }

    return flag;
}

static spBool sp_main_frame_created = SP_FALSE;

void spFrameCreateArch(spComponent component)
{
    char *title = NULL, *icon_name = NULL;
    
    if (!strnone(SpFramePart(component).icon_name)) {
	icon_name = SpFramePart(component).icon_name;
    }
    if (strnone(icon_name)) {
	icon_name = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    if (!strnone(SpComponentPart(component).title)) {
	title = SpComponentPart(component).title;
    }
    if (strnone(title)) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }

    if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	SpFrameArch(component).toplevel = gtk_window_new(GTK_WINDOW_POPUP);
    } else {
	SpFrameArch(component).toplevel = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    }
    gtk_window_set_title(GTK_WINDOW(SpFrameArch(component).toplevel), title);
    if (SpFramePart(component).resize_flag == SP_FALSE) {
	gtk_window_set_policy(GTK_WINDOW(SpFrameArch(component).toplevel),
			      FALSE, FALSE, FALSE);
    } else {
	gtk_window_set_policy(GTK_WINDOW(SpFrameArch(component).toplevel),
			      TRUE, TRUE, FALSE);
    }

    gtk_signal_connect(GTK_OBJECT(SpFrameArch(component).toplevel),
		       "configure_event", GTK_SIGNAL_FUNC(adjustComponentSizeCB),
		       component);
    gtk_signal_connect(GTK_OBJECT(SpFrameArch(component).toplevel), "delete_event",
		       GTK_SIGNAL_FUNC(deleteEventCB), (gpointer)component);
    gtk_signal_connect(GTK_OBJECT(SpFrameArch(component).toplevel), "key_press_event",
		       GTK_SIGNAL_FUNC(keyPressEventCB), (gpointer)component);
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE
	&& sp_main_frame_created == SP_FALSE) {
	sp_main_frame_created = SP_TRUE;
    }

    SpPrimitiveArch(component).top_widget = gtk_vbox_new(FALSE, 0);
    gtk_container_add(GTK_CONTAINER(SpFrameArch(component).toplevel),
		      SpPrimitiveArch(component).top_widget);
    gtk_widget_show(SpPrimitiveArch(component).top_widget);

    SpPrimitiveArch(component).widget = gtk_fixed_new();
    spSetStyleGtk(component, SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);

    return;
}

void spFrameDestroyArch(spComponent component)
{
    postMessage(component, SppDestroyCallback);
    return;
}
    
void spFrameSetParamsArch(spComponent component)
{
    if (SpFramePart(SpOldObject(component)).icon_name != SpFramePart(component).icon_name) {
	/* do nothing */
    }

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {
	gtk_window_set_title(GTK_WINDOW(SpFrameArch(component).toplevel),
			     SpComponentPart(component).title);
    }
	
    return;
}

void *spGetArchFrame(spComponent component)
{
    return (void *)SpFrameArch(component).toplevel;
}

spBool spIsTaskTraySupported(void)
{
    return SP_FALSE;
}

spBool spShowTaskTrayArch(spComponent window, spBool flag)
{
    return SP_FALSE;
}
    
GtkWidget *spAddGrabGtk(GtkWidget *widget)
{
    GtkWidget *prev = NULL;

    if (sp_grabbed_widget != NULL) {
	if (GTK_WIDGET_HAS_GRAB(sp_grabbed_widget)) {
	    gtk_grab_remove(sp_grabbed_widget);
	}
	prev = sp_grabbed_widget;
    }

    if (widget != NULL) {
	sp_grabbed_widget = widget;
	if (!GTK_WIDGET_HAS_GRAB(sp_grabbed_widget)) {
	    gtk_grab_add(sp_grabbed_widget);
	}
    }
    
    spDebug(20, "spAddGrabGtk", "done\n");
    
    return prev;
}

void spRemoveGrabGtk(GtkWidget *widget)
{
    if (sp_grabbed_widget != NULL
	&& (widget == NULL || sp_grabbed_widget == widget)) {
	if (GTK_WIDGET_HAS_GRAB(sp_grabbed_widget)) {
	    gtk_grab_remove(sp_grabbed_widget);
	}
	sp_grabbed_widget = NULL;
    }
    
    spDebug(20, "spRemoveGrabGtk", "done\n");
    
    return;
}

#include <gdk/gdkprivate.h>

void spPopupFrameArch(spComponent window, spBool move_cursor)
{
    GtkWidget *widget;

    widget = SpFrameArch(window).toplevel;
    
    if (!GTK_WIDGET_MAPPED(widget)) {
	if (!GTK_WIDGET_REALIZED(widget)) {
	    spDebug(30, "spPopupFrameArch", "1st map\n");
	    gtk_box_pack_start(GTK_BOX(SpPrimitiveArch(window).top_widget),
			       SpPrimitiveArch(window).widget, TRUE, TRUE, 0);
	    
	    spAdjustComponentSize(window);
	}
    
	gtk_widget_show(widget);
    } else {
	gdk_window_raise(widget->window);
	
	if (move_cursor == SP_TRUE) {
	    GdkWindowPrivate *private = (GdkWindowPrivate *)widget->window;
	    if (!private->destroyed) {
		/* move pointer */
		XWarpPointer(private->xdisplay, None, private->xwindow,
			     0, 0, 0, 0, 0, 0);
	    }
	}
    }

    if (SpFramePart(window).popup_style == SP_MODAL_POPUP) {
	spBool prev_loop;
	GtkWidget *prev_grabbed;
	
	prev_grabbed = spAddGrabGtk(widget);
	prev_loop = sp_grabbed_loop;
	sp_grabbed_loop = SP_TRUE;
	
	spMainLoopGtk();

	spAddGrabGtk(prev_grabbed);
	sp_grabbed_loop = prev_loop;
    }
    
    return;
}

void spPopdownFrameArch(spComponent window)
{
    GtkWidget *widget;

    widget = SpFrameArch(window).toplevel;
    
    if (sp_grabbed_widget != NULL) {
	spRemoveGrabGtk(sp_grabbed_widget);
	if (sp_grabbed_loop == SP_TRUE) {
	    spMainQuitGtk();
	}
    }

    if (widget != NULL) {
	gtk_widget_hide(widget);
    }
    
    return;
}

void spRaiseFrameArch(spComponent window)
{
    gdk_window_raise(SpFrameArch(window).toplevel->window);
    return;
}

void spLowerFrameArch(spComponent window)
{
    gdk_window_lower(SpFrameArch(window).toplevel->window);
    return;
}

spBool spSetFramePositionArch(spComponent window, int x, int y)
{
    gdk_window_move(SpFrameArch(window).toplevel->window, x, y);
    
    return SP_TRUE;
}

spBool spGetFramePositionArch(spComponent window, int *x, int *y)
{
    int lx, ly;

    gdk_window_get_position(SpFrameArch(window).toplevel->window, &lx, &ly);
    spDebug(30, "spGetFramePositionArch", "x = %d, y = %d\n", lx, ly);
    
    *x = lx;
    *y = ly;
    
    return SP_TRUE;
}

spBool spGetFrameModifierKeyMaskArch(spComponent window, spModifierMask *mask)
{
    int x, y;
    GdkModifierType gdkmask;
    
    if (gdk_window_get_pointer (SpFrameArch(window).toplevel->window,
				&x, &y, &gdkmask) == NULL) {
	return SP_FALSE;
    }

    *mask = gdkmask;
    
    return SP_TRUE;
}

#if GTK_CHECK_VERSION(1,2,0)
void windowDragDataReceived(GtkWidget *widget, GdkDragContext *context,
			    gint x, gint y, GtkSelectionData *selection_data,
			    guint info, guint time, gpointer data)
{
    int i;
    int len;
    int num_line;
    int argc;
    char **argv;
    char *string, *p;
    char *path;
    spComponent component = (spComponent)data;
    
    if (selection_data->length > 0 && selection_data->format == 8) {
	spDebug(10, "windowDragDataReceived", "received \"%s\"\n", (char *)selection_data->data);
	
	if (spIsFrame(component) == SP_TRUE) {
	    /* count number of lines */
	    string = (char *)selection_data->data;
	    num_line = 0;
	    while (1) {
		if ((string = strchr(string, '\n')) == NULL)
		    break;

		string++;
		num_line++;
	    }
	    argv = xalloc(num_line, char *);

	    /* get file paths */
	    string = (char *)selection_data->data;
	    argc = 0;
	    while (1) {
		if ((p = strchr(string, '\n')) == NULL)
		    break;

		if ((path = strchr(string, ':')) != NULL) {
		    path++;
		    len = p - path - 1;
		    if (len >= 3
			&& path[0] == '/' && path[1] == '/' && path[2] == '/') {
			path += 2;
			len -= 2;
		    }

		    if (len > 0) {
			argv[argc] = xalloc(len + 1, char);
			strncpy(argv[argc], path, len);
			argv[argc][len] = NUL;
			
			spDebug(10, "windowDragDataReceived",
				"len = %d, file = %s\n", len, argv[argc]);
			
			argc++;
		    }
		}

		string = p + 1;
	    }

	    SpFrameArch(component).drop_call_func(component, SpFrameArch(component).drop_call_data,
						  argc, argv);

	    for (i = 0; i < argc; i++) {
		xfree(argv[i]);
	    }
	    xfree(argv);
	}
	gtk_drag_finish(context, TRUE, FALSE, time);
    } else {
	gtk_drag_finish(context, FALSE, FALSE, time);
    }

    return;
}
#endif

spBool spAddDropCallbackArch(spComponent component, spDropCallbackFunc call_func, void *call_data)
{
#if GTK_CHECK_VERSION(1,2,0)
    static GtkTargetEntry target_table[] = {
	{"text/uri-list", 0, 0},
    };

    if (call_func == NULL) {
	if (SpFrameArch(component).drop_func_id > 0) {
	    gtk_drag_dest_unset(SpFrameArch(component).toplevel);
	    gtk_signal_disconnect(GTK_OBJECT(SpFrameArch(component).toplevel),
				  SpFrameArch(component).drop_func_id);
	    return SP_TRUE;
	}
    } else {
	SpFrameArch(component).drop_call_func = call_func;
	SpFrameArch(component).drop_call_data = call_data;

	gtk_drag_dest_set(SpFrameArch(component).toplevel, GTK_DEST_DEFAULT_ALL,
			  target_table, 1, GDK_ACTION_COPY | GDK_ACTION_MOVE);
	
	SpFrameArch(component).drop_func_id = 
	    gtk_signal_connect(GTK_OBJECT(SpFrameArch(component).toplevel), "drag_data_received",
			       GTK_SIGNAL_FUNC(windowDragDataReceived), (void *)component);
	return SP_TRUE;
    }
#endif
    
    return SP_FALSE;
}
