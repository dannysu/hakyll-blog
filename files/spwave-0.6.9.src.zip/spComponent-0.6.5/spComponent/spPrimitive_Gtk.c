/*
 *	spPrimitive_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <gdk/gdkkeysyms.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spFrame.h>
#include <sp/spDialog.h>
#include <sp/spContainer.h>
#include <sp/spButton.h>
#include <sp/spMenuItem.h>
#include <sp/spCanvas.h>
#include <sp/spSlider.h>
#include <sp/spMenu.h>
#include <sp/spToolBar.h>
#include <sp/spTabBox.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spComboBoxP.h>
#include <sp/spGraphicsP.h>
#include <sp/spPrimitiveP.h>
#include <sp/spToolBarP.h>
#include <sp/spToolItemP.h>
#include <sp/spStatusBarP.h>

static spCallbackTable sp_callback_tables[] = {
    {SP_NO_CALLBACK, NULL, NULL, 0},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, "key_press_event", GDK_KEY_PRESS_MASK},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, "button_press_event", GDK_KEY_PRESS_MASK},
    {SP_KEY_RELEASE_CALLBACK, SpCanvas, "key_release_event", GDK_KEY_RELEASE_MASK},
    {SP_BUTTON_PRESS_CALLBACK, SpPrimitive, "button_press_event", GDK_BUTTON_PRESS_MASK},
    {SP_BUTTON_RELEASE_CALLBACK, SpPrimitive, "button_release_event", GDK_BUTTON_RELEASE_MASK},
    {SP_POINTER_MOTION_CALLBACK, SpCanvas, "motion_notify_event", GDK_POINTER_MOTION_MASK},
    {SP_BUTTON_MOTION_CALLBACK, SpCanvas, "motion_notify_event", GDK_BUTTON_MOTION_MASK},
#if 0
    {SP_ENTER_WINDOW_CALLBACK, SpPrimitive, "enter_notify_event", GDK_ENTER_NOTIFY_MASK},
    {SP_LEAVE_WINDOW_CALLBACK, SpPrimitive, "leave_notify_event", GDK_LEAVE_NOTIFY_MASK},
#endif
    /**/
    {SP_DESTROY_CALLBACK, SpFrame, SppDestroyCallback, 0},
    {SP_CLOSE_CALLBACK, SpFrame, SppCloseCallback, 0},
    {SP_CLOSE_CALLBACK, SpFrame, "destroy", 0},
    {SP_ACTIVATE_CALLBACK, SpPushButton, "clicked", 0},
    {SP_ACTIVATE_CALLBACK, SpMenuItem, "activate", 0},
    {SP_ACTIVATE_CALLBACK, SpToolItem, "clicked", 0},
    {SP_ACTIVATE_CALLBACK, SpTextField, "activate", 0},
    {SP_ACTIVATE_CALLBACK, SpList, "button_press_event", GDK_BUTTON_PRESS_MASK},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBox, "toggled", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButton, "toggled", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBoxMenuItem, "toggled", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButtonMenuItem, "toggled", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckToolItem, "toggled", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpText, "changed", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpSlider, "value_changed", 0},
    {SP_VALUE_CHANGED_CALLBACK, SpList, "selection_changed", 0},
#if 0
    {SP_MAP_CALLBACK, SpPrimitive, "map", 0},
    {SP_UNMAP_CALLBACK, SpPrimitive, "unmap", 0},
#endif
    {SP_EXPOSE_CALLBACK, SpCanvas, "expose_event", GDK_EXPOSURE_MASK},
    {SP_RESIZE_CALLBACK, SpCanvas, "configure_event", GDK_STRUCTURE_MASK},
    {SP_RESIZE_CALLBACK, SpFrame, "configure_event", GDK_STRUCTURE_MASK},
    /**/
    {SP_OK_CALLBACK, SpPushButton, "clicked", 0},
    {SP_CANCEL_CALLBACK, SpPushButton, "clicked", 0},
    {SP_HELP_CALLBACK, SpPushButton, "clicked", 0},
#if 0
    {SP_APPLY_CALLBACK, SpPushButton, "clicked", 0},
#endif
};
static int sp_num_callback_table = 0;

static void callbackFunc(GtkWidget *widget, gpointer data)
{
    long component_id;
    spCallback *callback = (spCallback *)data;

    if (callback != NULL && callback->call_func != NULL
	&& callback->component != NULL && callback->call_name != NULL) {
	spDebug(50, "callbackFunc", "callbacked: %s\n", callback->call_name);

	if (streq(callback->call_name, "destroy")
	    && spIsCreated(callback->component) == SP_FALSE) {
	    /* not closing window, but destroying window */
	    return;
	}
	if (streq(callback->call_name, "activate")
	    && spIsMenuItem(callback->component) == SP_TRUE && spIsSensitive(callback->component) == SP_FALSE) {
	    /* sometimes gtk send messages to insensitive widgets through shortcuts */
	    return;
	}
	
	component_id = SpGetComponentId(callback->component);
	SpPrimitiveArch(callback->component).call_name = callback->call_name;
	
	spComponentCallbackFunc(callback);
	
	if (component_id != spGetDestroyedComponentId()
	    && callback != NULL && callback->component != NULL) {
	    SpPrimitiveArch(callback->component).call_name = NULL;
	}
	spDebug(50, "callbackFunc", "done\n");
    }
    
    return;
}

static gint eventFunc(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    long component_id;
    spCallback *callback = (spCallback *)data;

     if (callback != NULL && callback->call_func != NULL
	&& callback->component != NULL && callback->call_name != NULL) {
	spDebug(50, "callbackFunc", "callbacked: %s %s, event->type = %d\n",
		SpGetClassName(callback->component), callback->call_name, event->type);
	if (streq(callback->call_name, "motion_notify_event")
	    && callback->event_mask == GDK_BUTTON_MOTION_MASK
	    && !event->motion.state) {
	    return FALSE;
	} else if (streq(callback->call_name, "button_press_event")
		   && callback->event_mask == GDK_KEY_PRESS_MASK
		   && !(event->button.button == 4 || event->button.button == 5)) {
	    return FALSE;
	}
	
	if (spIsSubClass(callback->component, SpList) == SP_FALSE
	    || (streq(callback->call_name, "button_press_event") && event->type == GDK_2BUTTON_PRESS)) {
	    component_id = SpGetComponentId(callback->component);
	    SpPrimitiveArch(callback->component).call_name = callback->call_name;
	    SpPrimitiveArch(callback->component).event = event;
	    
	    spComponentCallbackFunc(callback);
	    
	    if (component_id != spGetDestroyedComponentId()
		&& callback != NULL && callback->component != NULL) {
		SpPrimitiveArch(callback->component).call_name = NULL;
		SpPrimitiveArch(callback->component).event = NULL;
	    }
	}
    }
    
    return FALSE;
}

static gchar *getCallbackName(spComponent component, spCallbackType call_type,
			      gint *event_mask, int *count)
{
    int i;
    gchar *call_name = NULL;

    if (sp_num_callback_table <= 0) {
	sp_num_callback_table = spArraySize(sp_callback_tables);
    }
    
    if (call_type == SP_NO_CALLBACK) return NULL;

    if (*count < sp_num_callback_table) {
	for (i = *count; i < sp_num_callback_table; i++) {
	    if (sp_callback_tables[i].component_type == NULL
		|| spIsSubClass(component, sp_callback_tables[i].component_type) == SP_TRUE) {
		if (call_type & sp_callback_tables[i].call_type &&
		    sp_callback_tables[i].call_name != NULL) {
		    call_name = sp_callback_tables[i].call_name;
		    *event_mask = sp_callback_tables[i].event_mask;
    
		    *count = i + 1;
		    
		    break;
		}
	    }
	}
	if (i >= sp_num_callback_table) {
	    *count = sp_num_callback_table;
	}
    }

    return call_name;
}

static void addToolItemCallback(GtkWidget *widget, spCallback *callback)
{
    spDebug(50, "addToolItemCallback", "add\n");
    
    if (callback != NULL
	&& callback->component != NULL
	&& SpPrimitiveArch(callback->component).widget != NULL) {
	callback->func_id =
	    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(callback->component).widget),
			       callback->call_name, GTK_SIGNAL_FUNC(callbackFunc),
			       (gpointer)callback);
    }

    return;
}

static spBool addCallback(spComponent component, spBool propagate, gchar *call_name,
			  gint event_mask, spCallbackFunc call_func, void *call_data)
{
    long k;
    GtkWidget *widget = NULL;

    if (call_name != NULL && call_func != NULL) {
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_name == call_name &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data &&
		SpPrimitivePart(component).callbacks[k].event_mask == event_mask) {
		return SP_FALSE;
	    } else if (SpPrimitivePart(component).callbacks[k].call_func == NULL) {
		break;
	    }
	}
	if (k >= SpPrimitivePart(component).num_callback) {
	    spAllocCallbacks(component);
	    SpPrimitivePart(component).num_callback++;
	}
	SpPrimitivePart(component).callbacks[k].component = component;
	SpPrimitivePart(component).callbacks[k].call_name = call_name;
	SpPrimitivePart(component).callbacks[k].call_func = call_func;
	SpPrimitivePart(component).callbacks[k].call_data = call_data;
	SpPrimitivePart(component).callbacks[k].event_mask = event_mask;
	SpPrimitivePart(component).callbacks[k].propagate = propagate;
	
	spDebug(40, "addCallback", "k = %ld, call_name = %s\n",
		k, SpPrimitivePart(component).callbacks[k].call_name);

	if (!streq(SpPrimitivePart(component).callbacks[k].call_name, SppDestroyCallback)
	    && !streq(SpPrimitivePart(component).callbacks[k].call_name, SppCloseCallback)) {
	    if (spIsFrame(component) == SP_TRUE
		&& SpFrameArch(component).toplevel != NULL
		&& streq(call_name, "destroy")) {
		widget = SpFrameArch(component).toplevel;
		spDebug(30, "addCallback", "add destroy callback\n");
	    } else if (spIsToolItem(component) == SP_TRUE) {
		gtk_signal_connect(GTK_OBJECT(SpParentPrimitiveArch(component).widget),
				   "realize", GTK_SIGNAL_FUNC(addToolItemCallback),
				   (gpointer)&(SpPrimitivePart(component).callbacks[k]));
		
		return SP_TRUE;
	    } else if (spIsSlider(component) == SP_TRUE
		       && streq(call_name, "value_changed")) {
		widget = (GtkWidget *)SpPrimitiveArch(component).adjustment;
	    } else if (spIsComboBox(component) == SP_TRUE
		       && streq(call_name, "changed")) {
		widget = (GtkWidget *)GTK_COMBO(SpPrimitiveArch(component).widget)->entry;
	    } else if (SpPrimitiveArch(component).widget != NULL) {
		widget = SpPrimitiveArch(component).widget;
	    }
	    
	    if (widget != NULL) {
		if (event_mask) {
		    SpPrimitivePart(component).callbacks[k].func_id =
			gtk_signal_connect(GTK_OBJECT(widget),
					   call_name, GTK_SIGNAL_FUNC(eventFunc),
					   (gpointer)&(SpPrimitivePart(component).callbacks[k]));
		} else {
		    SpPrimitivePart(component).callbacks[k].func_id =
			gtk_signal_connect(GTK_OBJECT(widget),
					   call_name, GTK_SIGNAL_FUNC(callbackFunc),
					   (gpointer)&(SpPrimitivePart(component).callbacks[k]));
		}
		spDebug(30, "addCallback", "call_name = %s\n", call_name);
	    }
	}
	
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool removeCallback(spComponent component, gchar *call_name, gint event_mask,
			     spCallbackFunc call_func, void *call_data)
{
    long k;
    GtkWidget *widget = NULL;
    
    if (call_name != NULL && call_func != NULL) {
	spDebug(30, "removeCallback", "call_name = %s\n", call_name);
		
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    spDebug(30, "removeCallback", "k = %ld\n",
		    k, SpPrimitivePart(component).callbacks[k].call_name);
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_name == call_name &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data &&
		SpPrimitivePart(component).callbacks[k].event_mask == event_mask) {
		if (!streq(SpPrimitivePart(component).callbacks[k].call_name, SppDestroyCallback)
		    && !streq(SpPrimitivePart(component).callbacks[k].call_name, SppCloseCallback)) {
		    if (spIsFrame(component) == SP_TRUE
			&& SpFrameArch(component).toplevel != NULL
			&& streq(call_name, "destroy") == SP_TRUE) {
			widget = SpFrameArch(component).toplevel;
			/*SpFramePart(component).close_style = SP_DESTROY_CLOSE;*/
		    } else if (spIsSlider(component) == SP_TRUE
			       && streq(call_name, "value_changed")) {
			widget = (GtkWidget *)SpPrimitiveArch(component).adjustment;
		    } else if (SpPrimitiveArch(component).widget != NULL) {
			widget = SpPrimitiveArch(component).widget;
		    }
		    
		    if (widget != NULL) {
			gtk_signal_disconnect(GTK_OBJECT(widget),
					      SpPrimitivePart(component).callbacks[k].func_id);
		    }
		}
		    
		SpPrimitivePart(component).callbacks[k].component = NULL;
		SpPrimitivePart(component).callbacks[k].call_name = NULL;
		SpPrimitivePart(component).callbacks[k].call_func = NULL;
		SpPrimitivePart(component).callbacks[k].call_data = NULL;
		SpPrimitivePart(component).callbacks[k].func_id = -1;
		SpPrimitivePart(component).callbacks[k].event_mask = 0;
		SpPrimitivePart(component).callbacks[k].propagate = SP_FALSE;
		    
		return SP_TRUE;
	    }
	}
    }

    return SP_FALSE;
}

spBool spPrimitiveAddCallbackArch(spComponent component, spBool propagate, spCallbackType call_type,
				  spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    gint event_mask = 0;
    spBool flag = SP_FALSE;
    gchar *call_name = NULL;
    
    while ((call_name = getCallbackName(component, call_type, &event_mask, &count)) != NULL) {
	spDebug(40, "spPrimitiveAddCallbackArch", "call_name = %s\n", call_name);
	if (addCallback(component, propagate, call_name,
			event_mask, call_func, call_data) == SP_TRUE) {
	    flag = SP_TRUE;
	}
    }

    spDebug(50, "spPrimitiveAddCallbackArch", "done: flag = %d\n", flag);
    
    return flag;
}

spBool spPrimitiveRemoveCallbackArch(spComponent component, spCallbackType call_type,
				     spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    gint event_mask = 0;
    spBool flag = SP_FALSE;
    gchar *call_name = NULL;
    
    while ((call_name = getCallbackName(component, call_type, &event_mask, &count)) != NULL) {
	if (removeCallback(component, call_name, event_mask,
			   call_func, call_data) == SP_TRUE) {
	    flag = SP_TRUE;
	}
    }

    spDebug(50, "spRemoveCallback", "done: flag = %d\n", flag);
    
    return flag;
}

void spInitCallbackArch(spCallback *callback)
{
    callback->component = NULL;
    callback->call_func = NULL;
    callback->call_data = NULL;
    callback->propagate = SP_FALSE;
    
    callback->call_name = NULL;
    /*callback->event = NULL;*/
    callback->event_mask = 0;
    callback->func_id = -1;
    
    return;
}

spCallbackReason spPrimitiveGetCallbackReasonArch(spComponent component)
{
    spCallbackReason call_reason = SP_CR_NONE;
    GdkEvent *event;

    if (SpPrimitiveArch(component).event != NULL) {
	event = SpPrimitiveArch(component).event;
	switch (event->type) {
	  case GDK_KEY_PRESS:
	    call_reason = SP_CR_KEY_PRESS;
	    break;
	  case GDK_KEY_RELEASE:
	    call_reason = SP_CR_KEY_RELEASE;
	    break;
	  case GDK_2BUTTON_PRESS:
	    if (spIsSubClass(component, SpList) == SP_TRUE) {
		call_reason = SP_CR_ACTIVATE;
	    } else {
		call_reason = SP_CR_UNKNOWN;
	    }
	    break;
	  case GDK_BUTTON_PRESS:
	    spDebug(50, "spPrimitiveGetCallbackReasonArch",
		    "button press: event->button.button = %d\n", event->button.button);
	    if (event->button.button == 1) {
		call_reason = SP_CR_LBUTTON_PRESS;
	    } else if (event->button.button == 3) {
		call_reason = SP_CR_RBUTTON_PRESS;
	    } else if (event->button.button == 2) {
		call_reason = SP_CR_MBUTTON_PRESS;
	    } else if (event->button.button == 4) {
		call_reason = SP_CR_KEY_PRESS;
	    } else if (event->button.button == 5) {
		call_reason = SP_CR_KEY_PRESS;
	    }
	    break;
	  case GDK_BUTTON_RELEASE:
	    if (event->button.button == 1) {
		call_reason = SP_CR_LBUTTON_RELEASE;
	    } else if (event->button.button == 3) {
		call_reason = SP_CR_RBUTTON_RELEASE;
	    } else if (event->button.button == 2) {
		call_reason = SP_CR_MBUTTON_RELEASE;
	    }
	    break;
	  case GDK_MOTION_NOTIFY:
	    if (event->motion.state & GDK_BUTTON1_MASK) {
		call_reason = SP_CR_LBUTTON_MOTION;
	    } else if (event->motion.state & GDK_BUTTON3_MASK) {
		call_reason = SP_CR_RBUTTON_MOTION;
	    } else if (event->motion.state & GDK_BUTTON2_MASK) {
		call_reason = SP_CR_MBUTTON_MOTION;
	    } else {
		call_reason = SP_CR_POINTER_MOTION;
	    }
	    break;
	  default:
	    call_reason = SP_CR_UNKNOWN;
	    break;
	}
    } else if (!strnone(SpPrimitiveArch(component).call_name)) {
	if (streq(SpPrimitiveArch(component).call_name, "clicked")
	    || streq(SpPrimitiveArch(component).call_name, "activate")) {
	    if (spIsToggleButton(component) == SP_TRUE) {
		call_reason = SP_CR_VALUE_CHANGED;
	    } else {
		call_reason = SP_CR_ACTIVATE;
	    }
	} else if (streq(SpPrimitiveArch(component).call_name, SppDestroyCallback)) {
	    call_reason = SP_CR_DESTROY;
	} else if (streq(SpPrimitiveArch(component).call_name, SppCloseCallback)) {
	    call_reason = SP_CR_CLOSE;
	} else if (streq(SpPrimitiveArch(component).call_name, "destroy")) {
	    call_reason = SP_CR_CLOSE;
	} else if (streq(SpPrimitiveArch(component).call_name, "value_changed")
		   || streq(SpPrimitiveArch(component).call_name, "selection_changed")) {
	    call_reason = SP_CR_VALUE_CHANGED;
	} else if (streq(SpPrimitiveArch(component).call_name, "toggled")) {
	    if (spIsRadioButton(component) == SP_TRUE) {
		spBool set;
		if (spGetToggleState(component, &set) == SP_TRUE
		    && set == SP_FALSE) {
		    spDebug(50, "spPrimitiveGetCallbackReasonArch", "return CR_NONE\n");
		    return SP_CR_NONE;
		}
	    }
	    call_reason = SP_CR_VALUE_CHANGED;
	} else if (streq(SpPrimitiveArch(component).call_name, "changed")) {
	    call_reason = SP_CR_VALUE_CHANGED;
	} else if (streq(SpPrimitiveArch(component).call_name, "pressed")) {
	    call_reason = SP_CR_BUTTON_PRESS;
	} else if (streq(SpPrimitiveArch(component).call_name, "released")) {
	    call_reason = SP_CR_BUTTON_RELEASE;
	} else if (streq(SpPrimitiveArch(component).call_name, "map")) {
	    call_reason = SP_CR_MAP;
	} else if (streq(SpPrimitiveArch(component).call_name, "unmap")) {
	    call_reason = SP_CR_UNMAP;
	} else {
	    call_reason = SP_CR_UNKNOWN;
	}
    }
    
    return call_reason;
}

spBool spPrimitiveGetCallbackMousePositionArch(spComponent component, int *x, int *y)
{
    int lx = 0, ly = 0;
    GdkEvent *event;
    
    if (SpPrimitiveArch(component).event != NULL) {
	event = SpPrimitiveArch(component).event;
	switch (event->type) {
	  case GDK_BUTTON_PRESS:
	  case GDK_2BUTTON_PRESS:
	  case GDK_3BUTTON_PRESS:
	  case GDK_BUTTON_RELEASE:
	    lx = event->button.x;
	    ly = event->button.y;
	    break;
	  case GDK_MOTION_NOTIFY:
	    spDebug(60, "spPrimitiveGetCallbackMousePositionArch",
		    "button motion: %f, %f\n", event->motion.x, event->motion.y);
	    
	    lx = event->motion.x;
	    ly = event->motion.y;
	    break;
	  default:
	    return SP_FALSE;
	}
	if (x != NULL) *x = lx;
	if (y != NULL) *y = ly;
	
	spDebug(60, "spPrimitiveGetCallbackMousePositionArch",
		"x = %d, y = %d\n", lx, ly);
	
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spKeySym convertKeySym(int key_sym)
{
    if (key_sym >= 0x020 && key_sym <= 0x0ff) {
	return SPK_Character;
    } else {
	switch (key_sym) {
	  case SPK_BackSpace:		
	  case SPK_Tab:			
	  case SPK_Clear:		
	  case SPK_Return:		
	  case SPK_Pause:		
	  case SPK_ScrollLock:		
	  case SPK_Escape:		
	  case SPK_Delete:		
	  case SPK_Shift:		
	  case SPK_Control:		
	  case SPK_CapsLock:		
	  case SPK_Home:		
	  case SPK_Left:		
	  case SPK_Up:			
	  case SPK_Right:		
	  case SPK_Down:		
	  case SPK_Prior:		
	  case SPK_Next:		
	  case SPK_End:			
	  case SPK_Select:		
	  case SPK_Print:		
	  case SPK_Execute:		
	  case SPK_Insert:		
	  case SPK_Cancel:		
	  case SPK_Help:		
	  case SPK_NumLock:		

	  case SPK_F1:			
	  case SPK_F2:			
	  case SPK_F3:			
	  case SPK_F4:		
	  case SPK_F5:			
	  case SPK_F6:			
	  case SPK_F7:			
	  case SPK_F8:			
	  case SPK_F9:			
	  case SPK_F10:			
	  case SPK_F11:			
	  case SPK_F12:		
	  case SPK_F13:			
	  case SPK_F14:			
	  case SPK_F15:			
	  case SPK_F16:			
	  case SPK_F17:			
	  case SPK_F18:			
	  case SPK_F19:			
	  case SPK_F20:			
	  case SPK_F21:			
	  case SPK_F22:			
	  case SPK_F23:			
	  case SPK_F24:			
	  case SPK_Alt:			
	    return key_sym;
	  case GDK_Shift_R:		
	  case GDK_Control_R:		
	  case GDK_Alt_R:		
	    return (key_sym - 0x01);
	  case GDK_Menu:		
	  case GDK_Meta_L:		
	  case GDK_Meta_R:		
	    return SPK_Alt;
	  default:
	    break;
	}
    }

    return SPK_Unknown;
}

spBool spPrimitiveGetCallbackKeySymArch(spComponent component, spKeySym *key_sym)
{
    GdkEvent *event;
    spKeySym ks;
    
    if (SpPrimitiveArch(component).event != NULL) {
	event = SpPrimitiveArch(component).event;
	switch (event->type) {
	  case GDK_KEY_PRESS:
	  case GDK_KEY_RELEASE:
	    ks = convertKeySym(event->key.keyval);
	    spDebug(60, "spPrimitiveGetCallbackKeySymArch", "ks = %ld\n", ks);
	    if (ks != SPK_Unknown /*&& ks != SPK_Character*/) {
		*key_sym = ks;
		return SP_TRUE;
	    }
	    break;
	    
	  case GDK_BUTTON_PRESS:
	    spDebug(60, "spPrimitiveGetCallbackKeySymArch", "button = %d\n", event->button.button);
	    if (event->button.button == 4) {
		*key_sym = SPK_Prior;
		return SP_TRUE;
	    } else if (event->button.button == 5) {
		*key_sym = SPK_Next;
		return SP_TRUE;
	    }
	    break;
	    
	  default:
	    break;
	}
    }
    
    return SP_FALSE;
}

int spPrimitiveGetCallbackKeyStringArch(spComponent component,
					char *buf, int buf_size, spBool *overflow)
{
    int len;
    GdkEvent *event;
    spKeySym ks;
    
    if (SpPrimitiveArch(component).event != NULL) {
	event = SpPrimitiveArch(component).event;
	switch (event->type) {
	  case GDK_KEY_PRESS:
	  case GDK_KEY_RELEASE:
	    ks = convertKeySym(event->key.keyval);
	    spDebug(60, "spPrimitiveGetCallbackKeyStringArch", "ks = %ld\n", ks);
	    if (ks == SPK_Character && event->key.length >= 0) {
		if (event->key.length >= buf_size) {
		    if (overflow != NULL) {
			*overflow = SP_TRUE;
		    }
		    len = buf_size - 1;
		    strncpy(buf, event->key.string, len);
		} else {
		    if (overflow != NULL) {
			*overflow = SP_FALSE;
		    }
		    len = event->key.length;
		    strcpy(buf, event->key.string);
		}
		return len;
	    }
	  default:
	    break;
	}
    }

    return -1;
}

void spPrimitivePartInitArch(spComponent component)
{
    SpPrimitiveArch(component).widget = NULL;
    SpPrimitiveArch(component).top_widget = NULL;
    SpPrimitiveArch(component).sub_widget = NULL;
    SpPrimitiveArch(component).adjustment = NULL;
    SpPrimitiveArch(component).pixmap = NULL;
    SpPrimitiveArch(component).call_name = NULL;
    SpPrimitiveArch(component).event = NULL;
    SpPrimitiveArch(component).event_mask = 0;
    
    return;
}

void spPrimitiveDestroyArch(spComponent component)
{
    GtkWidget *widget = NULL;
    GdkPixmap *pixmap = NULL;
    
    if (SpPrimitiveArch(component).pixmap != NULL) {
	pixmap = SpPrimitiveArch(component).pixmap;
	SpPrimitiveArch(component).pixmap = NULL;
	gdk_pixmap_unref(pixmap);
    }

    if (spIsFrame(component) == SP_TRUE
	&& SpFrameArch(component).toplevel != NULL) {
	widget = SpFrameArch(component).toplevel;
	SpFrameArch(component).toplevel = NULL;
	gtk_widget_destroy(widget);
    } else {
	if (SpPrimitiveArch(component).top_widget != NULL) {
	    widget = SpPrimitiveArch(component).top_widget;
	    SpPrimitiveArch(component).top_widget = NULL;
	    gtk_widget_destroy(widget);
	} else {
	    if (SpPrimitiveArch(component).sub_widget != NULL) {
		widget = SpPrimitiveArch(component).sub_widget;
		SpPrimitiveArch(component).sub_widget = NULL;
		gtk_widget_destroy(widget);
	    }
	    if (SpPrimitiveArch(component).widget != NULL) {
		widget = SpPrimitiveArch(component).widget;
		SpPrimitiveArch(component).widget = NULL;
		gtk_widget_destroy(widget);
	    }
	}
    }
    
    return;
}

void spPrimitiveMapArch(spComponent component)
{
    if (SpPrimitiveArch(component).top_widget != NULL) {
	gtk_widget_show(SpPrimitiveArch(component).top_widget);
    } else if (SpPrimitiveArch(component).widget != NULL) {
	if (SpPrimitiveArch(component).sub_widget != NULL) {
	    gtk_widget_show(SpPrimitiveArch(component).sub_widget);
	}
	gtk_widget_show(SpPrimitiveArch(component).widget);
    }
    
    return;
}

void spPrimitiveUnmapArch(spComponent component)
{
    if (SpPrimitiveArch(component).top_widget != NULL) {
	gtk_widget_hide(SpPrimitiveArch(component).top_widget);
    } else if (SpPrimitiveArch(component).widget != NULL) {
	if (SpPrimitiveArch(component).sub_widget != NULL) {
	    gtk_widget_hide(SpPrimitiveArch(component).sub_widget);
	}
	gtk_widget_hide(SpPrimitiveArch(component).widget);
    }
    
    return;
}

spBool spPrimitiveSetSizeArch(spComponent component, int width, int height)
{
    int h;
    GtkWidget *widget = NULL;

    spDebug(100, "spPrimitiveSetSizeArch", "%s: width = %d, height = %d\n",
	    SpGetClassName(component), width, height);

    if (spIsFrame(component) == SP_TRUE) {
	if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		height += h;
	    }
	}
#if 0
	if (spIsVisible(SpFramePart(component).tool_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).tool_bar, NULL, &h) == SP_TRUE) {
		height += h;
	    }
	}
#endif
	
	spDebug(30, "spPrimitiveSetSizeArch",
		"Frame: x = %d, y = %d, width = %d, height = %d\n",
		SpComponentPart(component).x, SpComponentPart(component).y,
		width, height);
	
	if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	    if (GTK_WIDGET_MAPPED(SpFrameArch(component).toplevel)) {
		gdk_window_resize(SpFrameArch(component).toplevel->window, width, height);
	    }
	} else if (SpPrimitiveArch(component).widget != NULL) {
	    gtk_widget_set_usize(SpPrimitiveArch(component).widget, width, height);
	}
	
	if (SpComponentPart(component).x != 0 && SpComponentPart(component).y != 0) {
	    gtk_widget_set_uposition(SpFrameArch(component).toplevel,
				     SpComponentPart(component).x,
				     SpComponentPart(component).y);
	}
	
	return SP_TRUE;
    } else if (SpPrimitiveArch(component).widget != NULL) {
	if (SpPrimitiveArch(component).top_widget != NULL) {
	    widget = SpPrimitiveArch(component).top_widget;
	} else {
	    widget = SpPrimitiveArch(component).widget;
	}

	if (spIsSubClass(component, SpBox) == SP_TRUE
	    && spIsSubClass(SpGetParent(component), SpTabBox) == SP_TRUE) {
	    spDebug(10, "spPrimitiveSetSizeArch",
		    "tab child: height = %d\n", height);
	} else if (spIsSubClass(component, SpBox) == SP_TRUE
		   && spIsSubClass(SpGetParent(component), SpFileDialog) == SP_TRUE) {
	    gtk_widget_set_usize(widget, width, height);
	} else {
	    int hoffset = 0, voffset = 0;
#if !GTK_CHECK_VERSION(1,2,0)
	    if (spEqClass(component, SpLabel) == SP_TRUE) {
		voffset = 5;
	    }
#endif

	    if (spEqClass(component, SpPushButton) == SP_TRUE
		&& GTK_WIDGET_CAN_DEFAULT(SpPrimitiveArch(component).widget)) {
		int hspace, vspace;

#if GTK_CHECK_VERSION(1,2,0)
		hspace = GTK_WIDGET(SpPrimitiveArch(component).widget)->style->klass->xthickness + 3;
		vspace = GTK_WIDGET(SpPrimitiveArch(component).widget)->style->klass->ythickness + 3;
#else
		hspace = 5; vspace = 5;
#endif
		hoffset = -hspace; voffset = -vspace;
		width += 2 * hspace; height += 2 * vspace;
	    }
	    
	    gtk_widget_set_uposition(widget,
				     SpComponentPart(component).x + hoffset,
				     SpComponentPart(component).y + voffset);
	    gtk_widget_set_usize(widget, width, height);

	    if (spIsComboBox(component) == SP_TRUE) {
		/* set size of combo box children */
		gtk_widget_set_usize(GTK_COMBO(SpPrimitiveArch(component).widget)->entry,
				     width
				     - GTK_COMBO(SpPrimitiveArch(component).widget)->button->allocation.width - 1,
				     height);
		gtk_widget_set_usize(GTK_COMBO(SpPrimitiveArch(component).widget)->button,
				     -1, height);
	    } else if (spIsCanvas(component) == SP_TRUE) {
		/* to prevent mistaken size on exposure */
		SpPrimitiveArch(component).widget->allocation.width
		    = width - 2 * SpComponentPart(component).border_width;
		SpPrimitiveArch(component).widget->allocation.height
		    = height - 2 * SpComponentPart(component).border_width;
	    } else if (spIsSubClass(component, SpStatusBar) == SP_TRUE) {
		if (SpStatusBarArch(component).last_frame != NULL) {
		    gtk_widget_set_usize(SpStatusBarArch(component).last_frame,
					 width - SpStatusBarArch(component).total_size,
					 -1);
		}
	    }
	}

	spDebug(30, "spPrimitiveSetSizeArch",
		"x = %d, y = %d, width = %d, height = %d\n",
		SpComponentPart(component).x, SpComponentPart(component).y, width, height);
	
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

static spBool windowGetSize(spComponent component, int *width, int *height)
{
    int h;
    
    if (SpFrameArch(component).toplevel != NULL) {
	*width = (SpFrameArch(component).toplevel)->allocation.width;
	*height = (SpFrameArch(component).toplevel)->allocation.height;

	if (spIsVisible(SpFramePart(component).menu_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).menu_bar, NULL, &h) == SP_TRUE) {
		spDebug(10, "windowGetSize", "menu_bar: height = %d\n", h);

		*height -= h;
	    }
	}

	if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		spDebug(10, "windowGetSize", "status_bar: height = %d\n", h);
		*height -= h;
	    }
	}
	
	spDebug(10, "windowGetSize",
		"width = %d, height = %d\n", *width, *height);

	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spPrimitiveGetSizeArch(spComponent component, int *width, int *height)
{
    GtkWidget *widget;
    
    spDebug(30, "spPrimitiveGetSizeArch", "in\n");
    
    if (spIsFrame(component) == SP_TRUE) {
	return windowGetSize(component, width, height);
    }

    if (spIsSubClass(component, SpFileDialog) == SP_TRUE) {
	spDebug(10, "spPrimitiveGetClientSizeArch", "component is SpFileDialog\n");
	widget = GTK_FILE_SELECTION(SpPrimitiveArch(component).widget)->main_vbox;
    } else {
	widget = (SpPrimitiveArch(component).top_widget != NULL ?
		  SpPrimitiveArch(component).top_widget : SpPrimitiveArch(component).widget);
    }
    
    if (widget != NULL) {
	*width = widget->allocation.width;
	*height = widget->allocation.height;
	    
	spDebug(30, "spPrimitiveGetSizeArch",
		"width = %d, height = %d\n", *width, *height);
	    
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spPrimitiveGetClientSizeArch(spComponent component, int *width, int *height)
{
    GtkWidget *widget;
    
    spDebug(30, "spPrimitiveGetClientSizeArch", "in\n");

    if (spIsFrame(component) == SP_TRUE) {
	return windowGetSize(component, width, height);
    }
	
    if (spIsSubClass(component, SpFileDialog) == SP_TRUE) {
	spDebug(10, "spPrimitiveGetClientSizeArch", "component is SpFileDialog\n");
	widget = GTK_FILE_SELECTION(SpPrimitiveArch(component).widget)->main_vbox;
    } else {
	widget = SpPrimitiveArch(component).widget;
    }

    if (widget != NULL) {
	*width = widget->allocation.width;
	*height = widget->allocation.height;
	    
	spDebug(30, "spPrimitiveGetClientSizeArch",
		"width = %d, height = %d\n", *width, *height);
	
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spPrimitiveSetSensitiveArch(spComponent component, spBool flag)
{
    if (SpPrimitiveArch(component).widget != NULL) {
	gtk_widget_set_sensitive(GTK_WIDGET(SpPrimitiveArch(component).widget),
				 (flag == SP_TRUE ? TRUE : FALSE));

#if !GTK_CHECK_VERSION(1,2,0)
	if (spIsToolItem(component) == SP_TRUE
	    && SpPrimitiveArch(component).sub_widget != NULL
	    && SpToolItemArch(component).insens_pixmap != NULL) {
	    GdkBitmap *bitmap = NULL;

	    if (SpParentToolBarArch(component).bitmap != NULL) {
		bitmap = SpToolBarArch(component).bitmap;
	    }
	    
	    if (flag == SP_TRUE) {
		gtk_pixmap_set(GTK_PIXMAP(SpPrimitiveArch(component).sub_widget),
			       SpPrimitiveArch(component).pixmap, bitmap);
	    } else {
		gtk_pixmap_set(GTK_PIXMAP(SpPrimitiveArch(component).sub_widget),
			       SpToolItemArch(component).insens_pixmap, bitmap);
	    }
	}
#endif

	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spShowToolTipArch(spComponent component)
{
    spComponent window;

    if (SpPrimitiveArch(component).widget == NULL) return SP_FALSE;
    
    window = SpGetWindow(component);

    if (SpFrameArch(window).tooltips == NULL) {
	SpFrameArch(window).tooltips = gtk_tooltips_new();
    }

    gtk_tooltips_set_tip(SpFrameArch(window).tooltips,
			 SpPrimitiveArch(component).widget,
			 SpComponentPart(component).description, NULL);
    
    return SP_TRUE;
}

#if GTK_CHECK_VERSION(1,2,0)
static void changeGraphics(void)
{
    spUpdateSystemGraphics();
    return;
}

static void setPixmap(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    if (widget->window != NULL) {
	spDebug(80, "setPixmap", "in\n");
	gdk_window_set_back_pixmap(widget->window, NULL, TRUE);
    }
    return;
}

static void drawBackground(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    if (widget->window != NULL) {
	GtkWidget *parent;
	
	spDebug(80, "drawBackground", "in\n");
	
	gdk_window_set_back_pixmap(widget->window, NULL, TRUE);

	parent = gtk_widget_get_toplevel(widget);
	gtk_paint_flat_box(parent->style,
			   widget->window,
			   GTK_WIDGET_STATE (widget),
			   GTK_SHADOW_NONE,
			   NULL, widget, "background",
			   0, 0, -1, -1);
	
	if (spIsCanvas(component) == SP_TRUE) {
	    changeGraphics();
	    spRedrawCanvas(component);
	}
    }
    return;
}

/* because GktFixed's paint function always paints the area with gray */
static void fixedDraw(GtkWidget *widget, GdkRectangle *area)
{
    GtkWidget *parent;
    GtkFixedChild *child;
    GdkRectangle child_area;
    GList *children;

    g_return_if_fail(widget != NULL);

    if (GTK_WIDGET_DRAWABLE(widget))
    {
	spDebug(80, "fixedDraw", "in\n");
	parent = gtk_widget_get_toplevel(widget);
	gtk_paint_flat_box(parent->style,
			   widget->window,
			   GTK_WIDGET_STATE(widget),
			   GTK_SHADOW_NONE,
			   area, widget, "background",
			   0, 0, -1, -1);
	
	if (GTK_IS_FIXED(widget)) {
	    children = GTK_FIXED(widget)->children;
	} else {
	    children = NULL;
	}
	
	while (children)
	{
	    child = children->data;
	    children = children->next;

	    if (GTK_WIDGET_DRAWABLE(child->widget)
		&& gtk_widget_intersect (child->widget, area, &child_area)) {
		gtk_widget_draw (child->widget, &child_area);
	    }
	}
    }

    return;
}
#endif

void spSetStyleGtk(spComponent component, GtkWidget *widget)
{
#if GTK_CHECK_VERSION(1,2,0)
    GtkWidgetClass *klass;

    gtk_signal_connect(GTK_OBJECT(widget),
		       "realize", GTK_SIGNAL_FUNC(setPixmap),
		       (gpointer)component);
    gtk_signal_connect(GTK_OBJECT(widget),
		       "style_set", GTK_SIGNAL_FUNC(drawBackground),
		       (gpointer)component);
    
    if (GTK_IS_FIXED(widget)) {
	klass = GTK_WIDGET_CLASS(GTK_OBJECT(widget)->klass);
	klass->draw = fixedDraw;
    }
#endif

    return;
}
