/*
 *	spToolItem_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spToolItemP.h>

extern spTopLevel sp_toplevel;

void spToolItemPartInitArch(spComponent component)
{
    return;
}

void spToolItemPartFreeArch(spComponent component)
{
    return;
}

void spToolItemCreateArch(spComponent component)
{
    char *title;

    title = SpComponentPart(component).title;
    
    if (spIsSubClass(component, SpToolSeparator)) {
	SpToolItemArch(component).tbbutton.fsState = TBSTATE_ENABLED;
	SpToolItemArch(component).tbbutton.fsStyle = TBSTYLE_SEP;
	SpToolItemArch(component).tbbutton.iBitmap = 0;
	SpToolItemArch(component).tbbutton.idCommand = 0;
    } else if (spIsSubClass(component, SpCheckToolItem)) {
	SpToolItemArch(component).tbbutton.fsState = TBSTATE_ENABLED;
	SpToolItemArch(component).tbbutton.fsStyle = TBSTYLE_CHECK;
	SpToolItemArch(component).tbbutton.iBitmap
	    = SpPrimitivePart(component).index;
	SpToolItemArch(component).tbbutton.idCommand
	    = SpComponentPart(component).component_id;
    } else {
	SpToolItemArch(component).tbbutton.fsState = TBSTATE_ENABLED;
	SpToolItemArch(component).tbbutton.fsStyle = TBSTYLE_BUTTON;
	SpToolItemArch(component).tbbutton.iBitmap
	    = SpPrimitivePart(component).index;
	SpToolItemArch(component).tbbutton.idCommand
	    = SpComponentPart(component).component_id;
    }
    
    SpToolItemArch(component).tbbutton.dwData = 0L;
    SpToolItemArch(component).tbbutton.iString = 0;
    
    SendMessage(SpParentPrimitiveArch(component).hwnd, TB_ADDBUTTONS,
		(WPARAM)1, (LPARAM)(LPTBBUTTON)&SpToolItemArch(component).tbbutton); 

    spDebug(60, "spToolItemCreateArch", "done\n");
    
    return;
}

void spToolItemSetParamsArch(spComponent component)
{
    return;
}

void spToolItemDestroyArch(spComponent component)
{
    return;
}

void spSetToolItemToggleStateArch(spComponent component)
{
    SendMessage(SpParentPrimitiveArch(component).hwnd, TB_CHECKBUTTON,
		(WPARAM)SpComponentPart(component).component_id,
		(LPARAM)MAKELONG((SpToolItemPart(component).set == SP_TRUE
				  ? TRUE : FALSE), 0));
    
    return;
}

void spGetToolItemToggleStateArch(spComponent component)
{
    if (SendMessage(SpParentPrimitiveArch(component).hwnd, TB_ISBUTTONCHECKED,
		    (WPARAM)SpComponentPart(component).component_id, 0)) {
	SpToolItemPart(component).set = SP_TRUE;
    } else {
	SpToolItemPart(component).set = SP_FALSE;
    }
    
    return;
}
