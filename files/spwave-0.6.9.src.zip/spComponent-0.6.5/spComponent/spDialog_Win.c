/*
 *	spDialog_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdarg.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDialogP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

void spDialogPartInitArch(spComponent component)
{
    return;
}

spDialogResponse spPopupMessageBox(spComponent component, char *message)
{
    char *title;
    UINT wMBType = 0;
    spDialogResponse response;
    HWND prev_window;

    title = spGetMessageBoxTitle(component);

    if (SpDialogPart(component).dialog_type == SP_INFORMATION_DIALOG) {
	wMBType |= MB_ICONINFORMATION;
    } else if (SpDialogPart(component).dialog_type == SP_QUESTION_DIALOG) {
	wMBType |= MB_ICONQUESTION;
    } else if (SpDialogPart(component).dialog_type == SP_WARNING_DIALOG) {
	wMBType |= MB_ICONEXCLAMATION;
    } else if (SpDialogPart(component).dialog_type == SP_ERROR_DIALOG) {
	wMBType |= MB_ICONSTOP;
    } else if (SpDialogPart(component).dialog_type == SP_WORKING_DIALOG) {
	wMBType |= MB_ICONHAND;
    }
    
    if (SpDialogPart(component).button_type == SP_MB_OK) {
	wMBType |= MB_OK;
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	wMBType |= MB_OKCANCEL;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	wMBType |= MB_YESNO;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	wMBType |= MB_YESNOCANCEL;
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	wMBType |= MB_RETRYCANCEL;
    }

    prev_window = GetForegroundWindow();

    response = MessageBox(NULL, message, title, wMBType | MB_TASKMODAL | MB_SETFOREGROUND);

    if (prev_window != NULL) {
	SetForegroundWindow(prev_window);
    }

    switch (response) {
      case IDCANCEL:
	return SP_DR_CANCEL;
      case IDYES:
	return SP_DR_YES;
      case IDNO:
	return SP_DR_NO;
      case IDRETRY:
	return SP_DR_RETRY;
      default:
	return SP_DR_OK;
    }
}

static char sp_fd_pathname[SP_MAX_PATHNAME];
static char sp_fd_filename[SP_MAX_LINE];

#if defined(_WIN32) && !defined(__CYGWIN32__)
#include <shlobj.h>
#endif

char *xspPopupFileSelectionBoxArg(spComponent parent, char *name,
				  spFileDialogType dialog_type,
				  spArg *args, int num_arg)
{
    int i, j, n;
    int len;
    int filter_size;
    OPENFILENAME fname;
    spComponent component;
    char *filename = NULL;
    char *title = NULL;
    char *file_filter = NULL;

    component = spCreateComponentArg(SpDialogClass, SpFileDialog,
				     name, parent, args, num_arg);
    title = SpComponentPart(component).title;

    spDebug(60, "xspPopupFileSelectionBoxArg", "create component done\n");
    
    sp_fd_pathname[0] = NUL;
    sp_fd_filename[0] = NUL;

    if (dialog_type == SP_FD_TYPE_DIR) {
	BROWSEINFO bi;
	ITEMIDLIST *pidl;
	LPMALLOC pmalloc;

	if (SHGetMalloc(&pmalloc) == NOERROR) {
	    ZeroMemory(&bi, sizeof(BROWSEINFO));
	    bi.hwndOwner = NULL;
	    bi.pszDisplayName = sp_fd_filename;
	    bi.lpszTitle = title;
	    bi.ulFlags = BIF_RETURNONLYFSDIRS;
	    bi.pidlRoot = NULL;
	    
	    if ((pidl = SHBrowseForFolder(&bi)) != NULL) {
		if (SHGetPathFromIDList(pidl, sp_fd_pathname) != FALSE) {
		    filename = strclone(sp_fd_pathname);
		}
		pmalloc->lpVtbl->Free(pmalloc, pidl);
	    }
	    pmalloc->lpVtbl->Release(pmalloc);
	}
    } else {
	ZeroMemory(&fname, sizeof(OPENFILENAME));
	fname.lStructSize = sizeof(OPENFILENAME);
	if (parent != NULL) {
	    fname.hwndOwner = (SpParentPrimitiveArch(component).hwnd != NULL ?
			       SpParentPrimitiveArch(component).hwnd :
			       SpPrimitiveArch(SpGetWindow(SpGetParent(component))).hwnd);
	} else {
	    fname.hwndOwner = NULL;
	}
	
	if (SpDialogPart(component).file_filters != NULL) {
	    filter_size = 0;
	    for (i = 0; SpDialogPart(component).file_filters[i] != NULL; i++) {
		spDebug(50, "xspPopupFileSelectionBoxArg", "i = %d\n", i);
		if (SpDialogPart(component).file_types != NULL) {
		    len = strlen(SpDialogPart(component).file_types[i]);
		} else {
		    len = strlen(SpDialogPart(component).file_filters[i]);
		}
		filter_size += len + 1;
		
		len = strlen(SpDialogPart(component).file_filters[i]);
		filter_size += len + 1;
	    }
	    filter_size++;

	    file_filter = xalloc(filter_size, char);
	    
	    n = 0;
	    for (i = 0; SpDialogPart(component).file_filters[i] != NULL; i++) {
		spDebug(50, "xspPopupFileSelectionBoxArg", "i = %d\n", i);
		if (SpDialogPart(component).file_types != NULL) {
		    len = strlen(SpDialogPart(component).file_types[i]);
		    for (j = 0; j < len; j++) {
			file_filter[n] = SpDialogPart(component).file_types[i][j];
			n++;
		    }
		} else {
		    len = strlen(SpDialogPart(component).file_filters[i]);
		    for (j = 0; j < len; j++) {
			file_filter[n] = SpDialogPart(component).file_filters[i][j];
			n++;
		    }
		}
	    
		file_filter[n] = NUL;
		n++;
	    
		len = strlen(SpDialogPart(component).file_filters[i]);
		for (j = 0; j < len; j++) {
		    file_filter[n] = SpDialogPart(component).file_filters[i][j];
		    n++;
		}
	    
		file_filter[n] = NUL;
		n++;
	    }
	    
	    file_filter[n] = NUL;
	    n++;

	    spDebug(50, "xspPopupFileSelectionBoxArg", "n = %d (max = %d)\n", n,
		    filter_size);
	    
	    fname.lpstrFilter = file_filter;
	    if (SpDialogPart(component).filter_index != NULL) {
		fname.nFilterIndex = MAX(*(SpDialogPart(component).filter_index) + 1, 1);
	    } else {
		fname.nFilterIndex = 1;
	    }
	} else {
	    fname.lpstrFilter = NULL;
	    fname.nFilterIndex = 1;
	}
	spDebug(50, "xspPopupFileSelectionBoxArg", "filter index = %d\n",
		fname.nFilterIndex);

	if (SpDialogPart(component).initial_file_name != NULL) {
	    char *p;
	    if ((p = spGetBaseName(SpDialogPart(component).initial_file_name)) != NULL) {
		strcpy(sp_fd_pathname, p);
	    }
	}
	fname.lpstrFile = sp_fd_pathname;
	fname.nMaxFile = sizeof(sp_fd_pathname);
	fname.lpstrFileTitle = sp_fd_filename;
	fname.nMaxFileTitle = sizeof(sp_fd_filename) - 1;
	if (!strnone(SpDialogPart(component).initial_dir)) {
	    fname.lpstrInitialDir = SpDialogPart(component).initial_dir;
	}
	fname.lpstrTitle = (title != NULL ? title : (!strnone(name) ? name : NULL));
	fname.Flags = OFN_HIDEREADONLY;
	
	if (SpDialogPart(component).path_must_exist == SP_TRUE) {
	    fname.Flags |= OFN_PATHMUSTEXIST;
	}
	if (SpDialogPart(component).file_must_exist == SP_TRUE) {
	    fname.Flags |= OFN_FILEMUSTEXIST;
	}
	if (SpDialogPart(component).overwrite_prompt == SP_TRUE) {
	    fname.Flags |= OFN_OVERWRITEPROMPT;
	}
	
	if (dialog_type == SP_FD_TYPE_SAVE) {
	    while (GetSaveFileName(&fname)) {
		if (SpDialogPart(component).file_filters != NULL) {
		    char *filter;
		    
		    filter = SpDialogPart(component).file_filters[fname.nFilterIndex - 1];

		    if (spGetSuffix(spGetBaseName(sp_fd_pathname)) == NULL) {
			spReplaceSuffix(sp_fd_pathname, filter);
			
			if (SpDialogPart(component).overwrite_prompt == SP_TRUE
			    & spIsExist(sp_fd_pathname) == SP_TRUE
			    && spOverwritePrompt(parent, sp_fd_pathname) == SP_FALSE) {
			    continue;
			}
		    }
		}
		
		filename = strclone(sp_fd_pathname);
		break;		/* just for overwrite prompt */
	    }
	} else {
	    if (GetOpenFileName(&fname)) {
		filename = strclone(sp_fd_pathname);
	    }
	}
	
	if (SpDialogPart(component).filter_index != NULL) {
	    *(SpDialogPart(component).filter_index) = fname.nFilterIndex - 1;
	}
	
	spDebug(50, "xspPopupFileSelectionBoxArg", "filter_index = %d\n",
		fname.nFilterIndex);

	if (file_filter != NULL) xfree(file_filter);
    }

    spFreeComponent(component);
    
    return filename;
}

char *xspChooseFontArch(spComponent component)
{
    static spBool first = SP_TRUE;
    static LOGFONT lf;
    static int unit = 0;
    CHOOSEFONT cf;
    HDC hdc;

    if (first == SP_TRUE || !strnone(SpDialogPart(component).initial_font)) {
	if (unit <= 0) {
	    hdc = GetDC(NULL);
	    unit = GetDeviceCaps(hdc, LOGPIXELSY);
	    ReleaseDC(NULL, hdc);
	}
    
	spFontNameToLOGFONT(SpDialogPart(component).initial_font, &lf);
	lf.lfHeight = MulDiv(lf.lfHeight, unit, 72);
	
	spDebug(50, "xspChooseFontArch", "unit = %d, face name = %s, height = %ld",
		unit, lf.lfFaceName, lf.lfHeight);
	
	first = SP_FALSE;
    }
    
    ZeroMemory(&cf, sizeof(CHOOSEFONT));
    cf.lStructSize = sizeof(CHOOSEFONT);
    cf.hwndOwner = (SpParentPrimitiveArch(component).hwnd != NULL
		    ? SpParentPrimitiveArch(component).hwnd
		    : SpPrimitiveArch(SpGetWindow(SpGetParent(component))).hwnd);
    cf.Flags = CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT;
    cf.nFontType = SCREEN_FONTTYPE; 
    cf.lpLogFont = (LPLOGFONT)&lf;
    
    if (ChooseFont(&cf)) {
	char font_name[SP_MAX_LINE];

	spDebug(50, "xspChooseFontArch", "after ChooseFont: face name = %s, height = %ld",
		lf.lfFaceName, lf.lfHeight);
	
	lf.lfHeight = MulDiv(lf.lfHeight, 72, unit);
	spLOGFONTToFontName(&lf, font_name);
	
	return strclone(font_name);
    }
    
    return NULL;
}

char *xspChooseColorArch(spComponent component)
{
    static int num_cust_color = 0;
    static CHOOSECOLOR cc;
    static DWORD cust_colors[16];
    
    if (num_cust_color <= 0) {
	for (num_cust_color = 0; num_cust_color < 16; num_cust_color++) {
	    cust_colors[num_cust_color] = RGB(255,255,255);
	}

	ZeroMemory(&cc, sizeof(CHOOSECOLOR));
	
	cc.lStructSize = sizeof(CHOOSECOLOR);
	cc.lpCustColors = (LPDWORD)cust_colors;
	cc.Flags = CC_RGBINIT;
    }

    if (!strnone(SpDialogPart(component).initial_color)) {
	cc.rgbResult = spGetColorPixel(SpDialogPart(component).initial_color);
    }
    cc.hwndOwner = (SpParentPrimitiveArch(component).hwnd != NULL
		    ? SpParentPrimitiveArch(component).hwnd
		    : SpPrimitiveArch(SpGetWindow(SpGetParent(component))).hwnd);

    if (ChooseColor(&cc)) {
	char color_name[SP_MAX_LINE];
	
	spGetColorName(cc.rgbResult, color_name);
	return strclone(color_name);
    }
      
    return NULL;
}
