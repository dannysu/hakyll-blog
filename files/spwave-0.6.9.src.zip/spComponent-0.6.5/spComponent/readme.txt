
	spComponent - Multi-platform GUI toolkit

			Last modified: <2002-04-01 12:54:28 hideki>


Introduction
------------

spComponent is a multi-platform GUI toolkit written in C. While this
library used to be developed for speech signal processing, you can use
it for other purpose. Using this library, you can create excellent GUI
easily on Windows, Mac OS and UNIX without source code modification. If
you need to create program working on these environments, this library
is very useful.


Features 
--------

We developed a library for signal processing called spLib, we used it for our
research and creating demonstration of the research. The library did not
provide functions to create GUI, so we used Motif or Tcl/Tk for creating GUI. 
However, developing demonstration was not very easy, because Motif is
low-level toolkit. Tcl/Tk does not have enough speed to run real-time
application, and there are some limitations in it. While there are other GUI
toolkits, almost all of them is written in C++. In our speech signal
processing field, C++ is not very popular. For these reason, I started in
developing high-level library toward Motif. The developed library existed on
Motif toolkit, so Motif was required necessarily and Motif functions must be
called directly, if needed. At the same time, Windows95 became popular in the
PC field, thus the developed demonstration had better work on UNIX and
Windows. In consideration of this situation, we began to develop new
high-level toolkit working on Motif and Windows. I first did not know Windows
programming at all, so the development of the toolkit was very difficult for
me. As a consequence of the work, the library now seems to be worked well.
This is how spComponent library was developed. Thus, this library has
the following features.

 * Easy to create GUI.
 * Written in C.
   + People who don't know language except C can use it (it's me :-)
   + Not very slow (faster than BASIC or Java).
 * Working on multiple platforms.
 * Based on user interface guideline on each environment.

However, there are some functional limitations, because this library is
designed to support various environments and to ease your program
development. Also, the basic toolkit (Motif or gtk+ on UNIX, Windows API on
Windows95/98) is required to use this library.


Requirements
------------

spBase library version 0.8.8 or higher is required to compile spComponent
library. UNIX version also needs Motif or gtk+ (gtk version works on both
version 1.0.X and version 1.2.X of gtk+), and XPM library to support tool
bar.  If you don't have Motif, LessTif (http://www.lesstif.org/) is available
instead of Motif (I tested with version 0.88).


Install
-------

To compile this library on UNIX (including Linux or Cygwin), go to the
spComponent top directory, and make a symbolic link from `include' directory
and `lib' directory of spBase (e.g. /usr/local/include and /usr/local/lib)
like this:

 % cd spComponent-X.X.X
 % ln -s /usr/local/include
 % ln -s /usr/local/lib

If your platform is supported by the configuration file of spBase, you can
build the library by typing in the source directory:

 % cd spComponent
 % make

To install this library to your system directory (e.g /usr/local), login as
root and type:

 # make SPDESTROOT=/usr/local install
 # make SPDESTROOT=/usr/local install.hdr

If you don't want to make a symbolic link from spBase directory, you can
compile and install by adding TOP=/usr/local option (/usr/local is top
directory of spBase) to the above command line of `make' such as:
 
 % cd spComponent-X.X.X
 % cd spComponent
 % make TOP=/usr/local
 % su
 # make TOP=/usr/local SPDESTROOT=/usr/local install
 # make TOP=/usr/local SPDESTROOT=/usr/local install.hdr

By default, the gtk version is selected forcedly on Linux, so compiling the
Motif version on Linux requires USE_MOTIF=y option against `make' command.


Supported Platforms
-------------------

spComponent is known to work at least on Linux (Redhat 6.2, Vine 2.1),
Microsoft Windows98/2000/XP, Cygwin and Mac OS 8.1/9.2/10.1. I think that you
can compile spComponent by modifying Makefile slightly.


BUGS
----

Please see BUGS.txt.


TODO
----

Please see TODO.txt. This library is still beta version, so there may be some
API changes in the future release (I'm going to avoid dramatic API changes if
possible).


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

License
-------

Please see LICENSE.txt.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
