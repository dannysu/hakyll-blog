/*
 *	spDraw_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spPrimitiveP.h>
#include <sp/spCanvasP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spTopLevelP.h>

PixMapHandle spGetLockedPixmapMac(spComponent component)
{
    PixMapHandle pixmap;
    
#if TARGET_API_MAC_CARBON
    LockPortBits(SpPrimitiveArch(component).gworld);
#endif
    pixmap = GetGWorldPixMap(SpPrimitiveArch(component).gworld);
    LockPixels(pixmap);

    return pixmap;
}

void spUnlockPixmapMac(spComponent component, PixMapHandle pixmap)
{
    UnlockPixels(pixmap);
    
#if TARGET_API_MAC_CARBON
    UnlockPortBits(SpPrimitiveArch(component).gworld);
#endif

    return;
}

static RGBColor sp_original_fg_rgb;
static RGBColor sp_original_bg_rgb;

void spGetOriginalRGBMac(void)
{
    GetForeColor(&sp_original_fg_rgb);
    GetBackColor(&sp_original_bg_rgb);
    return;
}

void spSetOriginalRGBMac(void)
{
    RGBForeColor(&sp_original_fg_rgb);
    RGBBackColor(&sp_original_bg_rgb);

    return;
}

void spSetNormalRGBMac(void)
{
    RGBColor black_rgb = {0, 0, 0};
    RGBColor white_rgb = {65535, 65535, 65535};
    
    RGBForeColor(&black_rgb);
    RGBBackColor(&white_rgb);

    return;
}

void spSetBackgroundRGBMac(void)
{
    RGBColor white_rgb = {65535, 65535, 65535};
    RGBColor gray_rgb = {56576, 56576, 56576};

    if (spGetAppearanceVersionMac() < 0x00000101 || spIsAquaMac() == SP_TRUE) {
	RGBBackColor(&white_rgb);
    } else {
	RGBBackColor(&gray_rgb);
    }

    return;
}

void spSetDeactivateRGBMac(void)
{
    RGBColor rgb = {32768, 32768, 32768};
    RGBColor white_rgb = {65535, 65535, 65535};
    
    RGBForeColor(&rgb);
    RGBBackColor(&white_rgb);

    return;
}

spBool spBeginDrawMac(spComponent component, spGraphics graphics,
		      PixMapHandle *current_pixmap, GWorldPtr *save_gwp, GDHandle *save_gdh)
{
    
    if (spIsDrawable(component) == SP_FALSE) return SP_FALSE;

    spLockDrawMutexMac();

    GetGWorld(save_gwp, save_gdh);
    spGetOriginalRGBMac();
    
    SetGWorld(SpPrimitiveArch(component).gworld, NULL);

    *current_pixmap = spGetLockedPixmapMac(component);

    if (graphics != NULL) {
	PenSize(SpGraphicsPart(graphics).line_width,
		SpGraphicsPart(graphics).line_width);
	PenMode(SpGraphicsArch(graphics).mode);
	
	RGBForeColor(&SpGraphicsArch(graphics).fg_rgb);
	RGBBackColor(&SpGraphicsArch(graphics).bg_rgb);
    }
    
    return SP_TRUE;
}

spBool spEndDrawMac(spComponent component, spGraphics graphics,
		    PixMapHandle current_pixmap, GWorldPtr save_gwp, GDHandle save_gdh)
{
    PenNormal();
    
    spUnlockPixmapMac(component, current_pixmap);
    
    SetGWorld(save_gwp, save_gdh);
    spSetOriginalRGBMac();
    
    spUnlockDrawMutexMac();
    
    return SP_TRUE;
}

void spImageCreateArch(spComponent component)
{
    return;
}

spBool spIsDrawable(spComponent component)
{
    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).gworld != NULL) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spDrawImageArch(spComponent component)
{
    Rect rect;
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    /* erase */
    if (spBeginDrawMac(component, NULL, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
#if 1
	if (spGetAppearanceVersionMac() >= 0x00000101) {
	    int depth;
	
#if TARGET_API_MAC_CARBON
	    depth = GetPixDepth(current_pixmap);
#else
	    depth = (*current_pixmap)->pixelSize;
#endif
	    SetThemeBackground(kThemeBrushDialogBackgroundActive, depth, true);
	}
#endif
	
	SetRect(&rect, 0, 0, SpComponentPart(component).client_width,
		SpComponentPart(component).client_height);
	EraseRect(&rect);
	
	spEndDrawMac(component, NULL, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spRedrawImageArch(spComponent component)
{
    Rect rect;
#if TARGET_API_MAC_CARBON
    GWorldFlags flags = 0;
#else
    GWorldFlags flags = useTempMem;
#endif
    
    spLockDrawMutexMac();

    if (SpPrimitiveArch(component).gworld != NULL) {
	DisposeGWorld(SpPrimitiveArch(component).gworld);
    }

    SetRect(&rect, 0, 0, SpComponentPart(component).client_width,
	    SpComponentPart(component).client_height);

    if (noErr != NewGWorld(&SpPrimitiveArch(component).gworld,
			   0, &rect, NULL, NULL, flags)) {
	spDebug(10, "spRedrawImageArch", "NewGWorld error\n");
	SpPrimitiveArch(component).gworld = NULL;
    }
    
    spUnlockDrawMutexMac();
    
    return;
}

void spCopyImageArch(spComponent src, spComponent dest,
		     int src_x, int src_y, int width, int height,
		     int dest_x, int dest_y)
{
    Rect src_rect;
    Rect dest_rect;
    PixMapHandle src_pixmap;
    PixMapHandle dest_pixmap;

    spLockDrawMutexMac();
    
    SetRect(&src_rect, src_x, src_y, src_x + width, src_y + height);
    SetRect(&dest_rect, dest_x, dest_y, dest_x + width, dest_y + height);
    
    /* get pixmap */
    src_pixmap = spGetLockedPixmapMac(src);
    dest_pixmap = spGetLockedPixmapMac(dest);
    
    /* set normal RGB */
    spGetOriginalRGBMac();
    spSetNormalRGBMac();
    
    /* copy pixmap */
    CopyBits((BitMap *)*src_pixmap, (BitMap *)*dest_pixmap,
	     &src_rect, &dest_rect, srcCopy, NULL);

    spUnlockPixmapMac(src, src_pixmap);
    spUnlockPixmapMac(dest, dest_pixmap);
    
    /* restore RGB */
    spSetOriginalRGBMac();
    
    spUnlockDrawMutexMac();
    
    return;
}

static char *getDash(spLineType type, int *num_dashp)
{
    static char dash_line[] = {9, 4};
    static char dot_line[] = {2, 4};
    static char dash_dot_line[] = {9, 4, 2, 4};
    static char dash_dot_dot_line[] = {9, 4, 2, 4, 2, 4};
    char *dash;
    int num_dash;

    switch (type) {
      case SP_LINE_DASH:
	dash = dash_line;
	num_dash = spArraySize(dash_line);
	break;
      case SP_LINE_DOT:
	dash = dot_line;
	num_dash = spArraySize(dot_line);
	break;
      case SP_LINE_DASH_DOT:
	dash = dash_dot_line;
	num_dash = spArraySize(dash_dot_line);
	break;
      case SP_LINE_DASH_DOT_DOT:
	dash = dash_dot_dot_line;
	num_dash = spArraySize(dash_dot_dot_line);
	break;
      default:
	return NULL;
    }

    if (num_dashp != NULL) {
	*num_dashp = num_dash;
    }
    
    return dash;
}

static int drawDashLine(RGBColor rgb, spLineType type, int doffset,
			int x1, int y1, int x2, int y2)
{
    double theta;
    int num_dash;
    int px, py;
    int cx, cy;
    int distance;
    int sumdash;
    int prev_sumdash;
    int dindex;
    char *dash;

    if (x1 == x2 && y1 == y2) {
	SetCPixel(x1, y1, &rgb);
	return 0;
    }
    if ((dash = getDash(type, &num_dash)) == NULL) {
	return 0;
    }

    distance = sqrt(SQUARE(x2 - x1) + SQUARE(y2 - y1));
    theta = atan2((double)(y2 - y1), (double)(x2 - x1));

    px = x1; py = y1;

    dindex = doffset;
    sumdash = 0;
    prev_sumdash = 0;
    for (;;) {
	sumdash += dash[dindex];
	if (sumdash > distance) {
	    if (prev_sumdash < distance) {
		sumdash = distance;
	    } else {
		break;
	    }
	}
	
	cx = (int)spRound((double)sumdash * cos(theta)) + x1;
	cy = (int)spRound((double)sumdash * sin(theta)) + y1;

	if (dindex % 2 == 0) {
	    MoveTo(px, py);
	    LineTo(cx, cy);
	}

	px = cx; py = cy;
	prev_sumdash = sumdash;
	
	++dindex;
	if (dindex >= num_dash) dindex = 0;
    }

    return dindex;
}

static void drawDashRectangle(RGBColor rgb, spLineType type, 
			      int x, int y, int width, int height)
{
    int doffset;

    doffset = drawDashLine(rgb, type, 0, x, y, x + width, y);
    doffset = drawDashLine(rgb, type, doffset, x + width, y, x + width, y + height);
    doffset = drawDashLine(rgb, type, doffset, x + width, y + height, x, y + height);
    doffset = drawDashLine(rgb, type, doffset, x, y + height, x, y);
    
    return;
}

void spFillRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    Rect rect;
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	SetRect(&rect, x, y, x + width, y + height);
	PaintRect(&rect);
	
	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spDrawRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    Rect rect;
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	if (graphics == NULL || SpGraphicsPart(graphics).line_type == SP_LINE_SOLID) {
	    SetRect(&rect, x, y, x + width, y + height);
	    FrameRect(&rect);
	} else {
	    drawDashRectangle(SpGraphicsArch(graphics).fg_rgb,
			      SpGraphicsPart(graphics).line_type, 
			      x, y, width, height);
	}
	
	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

static void drawArc(int x, int y, int width, int height, int angle1, int angle2)
{
    Rect rect;
    
    SetRect(&rect, x, y, x + width, y + height);
    FrameArc(&rect, -angle1 + 90, -angle2);
    
    return;
}

static int drawDashArc(spLineType type, int doffset,
		       int x, int y, int width, int height, int angle1, int angle2)
{
    int num_dash;
    int dindex;
    int total_angle;
    int current_angle;
    int angle_size;
    char *dash;

    if ((dash = getDash(type, &num_dash)) == NULL) {
	return 0;
    }

    total_angle = angle1 + angle2;

    dindex = doffset;
    current_angle = angle1;
    for (;;) {
	if (current_angle >= total_angle) {
	    break;
	}
	
	angle_size = (int)spRound(360.0 * (double)dash[dindex] / (double)width / PI);
	if (current_angle + angle_size > total_angle) {
	    angle_size = total_angle - current_angle;
	}

	if (dindex % 2 == 0) {
	    drawArc(x, y, width, height, current_angle, angle_size);
	}

	current_angle += angle_size;

	++dindex;
	if (dindex >= num_dash) dindex = 0;
    }

    return dindex;
}

void spFillArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    Rect rect;
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	SetRect(&rect, x, y, x + width, y + height);
	PaintArc(&rect, -angle1 + 90, -angle2);

	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spDrawArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	if (graphics == NULL || SpGraphicsPart(graphics).line_type == SP_LINE_SOLID) {
	    drawArc(x, y, width, height, angle1, angle2);
	} else {
	    drawDashArc(SpGraphicsPart(graphics).line_type, 0,
			x, y, width, height, angle1, angle2);
	}

	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spDrawLine(spComponent component, spGraphics graphics,
		int x1, int y1, int x2, int y2)
{
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	if (graphics == NULL || SpGraphicsPart(graphics).line_type == SP_LINE_SOLID) {
	    MoveTo(x1, y1);
	    LineTo(x2, y2);
	} else {
	    drawDashLine(SpGraphicsArch(graphics).fg_rgb,
			 SpGraphicsPart(graphics).line_type, 0,
			 x1, y1, x2, y2);
	}

	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spDrawPoint(spComponent component, spGraphics graphics,
		 int x, int y)
{
    RGBColor rgb;
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	if (graphics != NULL) {
	    rgb = SpGraphicsArch(graphics).fg_rgb;
	} else {
	    rgb.red = 0; rgb.green = 0; rgb.blue = 0;
	}
	SetCPixel(x, y, &rgb);

	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

void spSetFontIdMac(short font_id, int style, int size)
{
    TextFont(font_id);
    TextFace(style);
    TextSize(size);
    return;
}

static void setFont(spGraphics graphics)
{
    if (graphics != NULL) {
	spDebug(50, "setFont", "font_id = %d, font_style = %d, font_size = %d\n",
		SpGraphicsArch(graphics).font_id,
		SpGraphicsArch(graphics).font_style,
		SpGraphicsArch(graphics).font_size);
	
	spSetFontIdMac(SpGraphicsArch(graphics).font_id,
		       SpGraphicsArch(graphics).font_style,
		       SpGraphicsArch(graphics).font_size);
    }
    return;
}

void spDrawString(spComponent component, spGraphics graphics,
		  int x, int y, char *string)
{
    PixMapHandle current_pixmap;
    GWorldPtr save_gwp;
    GDHandle save_gdh;
    
    if (spBeginDrawMac(component, graphics, &current_pixmap, &save_gwp, &save_gdh) == SP_TRUE) {
	setFont(graphics);
	MoveTo(x, y);
	DrawText(string, 0, strlen(string));

	spEndDrawMac(component, graphics, current_pixmap, save_gwp, save_gdh);
    }
    
    return;
}

spBool spGetStringExtent(spGraphics graphics, char *string,
			 int *x, int *y, int *width, int *height)
{
    FontInfo font_info;
    GWorldPtr save_gwp;
    GDHandle save_gdh;

    spLockDrawMutexMac();
    
    GetGWorld(&save_gwp, &save_gdh);
    spSetDummyGWorldMac();

    setFont(graphics);

    GetFontInfo(&font_info);
    
    if (x != NULL) {
	*x = -1;
    }
    if (y != NULL) {
	*y = -font_info.ascent - 1;
    }
    if (width != NULL) {
	*width = TextWidth(string, 0, strlen(string)) + 2;
    }
    if (height != NULL) {
	*height = font_info.ascent + font_info.descent + 2;
    }
    
    SetGWorld(save_gwp, save_gdh);
    
    spUnlockDrawMutexMac();
    
    return SP_TRUE;
}
