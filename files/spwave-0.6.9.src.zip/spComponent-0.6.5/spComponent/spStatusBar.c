/*
 *	spStatusBar.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spList.h>

#include <sp/spFrameP.h>
#include <sp/spContainerP.h>
#include <sp/spStatusBarP.h>

static spParamTable sp_status_bar_param_tables[] = {
    {SppUseLastItem, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spStatusBar, status_bar.use_last_item), SP_TRUE_STRING},
    {SppItemSizes, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spStatusBar, status_bar.item_sizes), NULL},
    {SppDefaultItemIndex, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spStatusBar, status_bar.default_item_index), "0"},
    {SppHelpItemIndex, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spStatusBar, status_bar.help_item_index), "0"},
};

spStatusBarClassRec SpStatusBarClassRec = {
    /* spObjectClassPart */
    {
	SpStatusBar,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spStatusBarRec),
	spArraySize(sp_status_bar_param_tables),
	sp_status_bar_param_tables,
	spStatusBarPartInit,
	spStatusBarPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spStatusBarCreate,
	spStatusBarDestroy,
	spStatusBarSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spStatusBarClassPart */
    {
	0,
    },
};

spComponentClass SpStatusBarClass = (spComponentClass)&SpStatusBarClassRec;

void spStatusBarPartInit(spObject object)
{
    spComponent component = (spComponent)object;

    spStatusBarPartInitArch(component);
    
    SpStatusBarPart(component).num_item = 0;
    SpStatusBarPart(component).item_sizes = NULL;

    return;
}

void spStatusBarPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spStatusBarPartFreeArch(component);
    return;
}

void spStatusBarCreate(spObject object)
{
    spComponent component = (spComponent)object;
    spComponent window;
    
    if (component == NULL) return;

    spStatusBarCreateArch(component, &(SpStatusBarPart(component).num_item));
    
    if ((window = SpGetWindow(component)) != NULL && spIsFrame(window) == SP_TRUE) {
	SpFramePart(window).status_bar = component;
    }
	
    return;
}

void spStatusBarSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spStatusBarSetParamsArch(component);
    
    return;
}

void spStatusBarDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spStatusBarDestroyArch(component);
    spPrimitiveDestroyArch(component);
    return;
}

spBool spIsStatusBar(spComponent component)
{
    return spIsSubClass(component, SpStatusBar);
}

spComponent spCreateStatusBar(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsWindow(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpStatusBarClass, NULL, name, parent, args, num_arg);
}

spBool spSetStatusText(spComponent component, int index, char *string)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_FALSE) return SP_FALSE;

    if ((window = SpGetWindow(component)) != NULL
	&& SpFramePart(window).status_bar != NULL) {
	if (index <= -2) {
	    index = SpStatusBarPart(SpFramePart(window).status_bar).help_item_index;
	    spDebug(50, "spSetStatusText", "help_index = %d\n",
		    SpStatusBarPart(SpFramePart(window).status_bar).help_item_index);
	} else if (index < 0) {
	    index = SpStatusBarPart(SpFramePart(window).status_bar).default_item_index;
	    spDebug(50, "spSetStatusText", "default_index = %d\n",
		    SpStatusBarPart(SpFramePart(window).status_bar).default_item_index);
	}
	
	index = MIN(index, SpStatusBarPart(SpFramePart(window).status_bar).num_item - 1);
	index = MAX(index, 0);

	if (string == NULL) string = "";
    
	return spSetStatusTextArch(SpFramePart(window).status_bar, index, string);
    } else {
	return SP_FALSE;
    }
}

void spSetHelpStatusText(spComponent component, char *string)
{
    spSetStatusText(component, -2, string);
    return;
}

void spSetDefaultStatusText(spComponent component, char *string)
{
    spSetStatusText(component, -1, string);
    return;
}

void spSetStatusTextCB(spComponent component, char *string)
{
    spSetStatusText(component, -1, string);
    return;
}

int spGetStatusItemSize(spComponent component, int index)
{
    int item_size = 0;

    if (spIsStatusBar(component) == SP_FALSE
	|| index < 0) return -1;
    
    if (SpStatusBarPart(component).item_sizes != NULL) {
	if (index > 0 && SpStatusBarPart(component).item_sizes[index - 1] <= 0) {
	    return -1;
	} else if (SpStatusBarPart(component).item_sizes[index] <= 0) {
	    if (index <= 0) {
		SpStatusBarPart(component).use_last_item = SP_TRUE;
	    }
	    if (SpStatusBarPart(component).use_last_item == SP_FALSE) {
		return -1;
	    }
	}
	item_size = MAX(SpStatusBarPart(component).item_sizes[index], 0);
    } else {
	if (index != 0) {
	    return -1;
	}
	item_size = 0;
    }
    
    return item_size;
}
