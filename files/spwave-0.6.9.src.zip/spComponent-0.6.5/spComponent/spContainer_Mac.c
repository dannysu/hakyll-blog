/*
 *	spContainer_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDrawP.h>
#include <sp/spFrameP.h>
#include <sp/spContainerP.h>

void spMapContainerMac(spComponent component)
{
    spComponent child;

    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).map_flag == SP_TRUE) {
	return;
    }
    spDebug(80, "spMapContainerMac", "in\n");

    child = SpGetChild(component);

    while (child != NULL) {
	if (spIsVisible(child) == SP_TRUE) {
	    if (spIsPrimitive(child) == SP_TRUE) {
		spPrimitiveMapArch(child);
	    } else if (spIsContainer(child) == SP_TRUE) {
		spMapContainerMac(child);
	    }
	}
	child = SpGetNextComponent(child);
    }
    
    if (spIsPrimitive(component) == SP_TRUE) {
	SpPrimitiveArch(component).map_flag = SP_TRUE;
    }
    
    spDebug(80, "spMapContainerMac", "done\n");
    
    return;
}

void spUnmapContainerMac(spComponent component)
{
    spComponent child;

    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).map_flag == SP_FALSE) {
	return;
    }
    spDebug(80, "spMapContainerMac", "in\n");

    child = SpGetChild(component);

    while (child != NULL) {
	if (spIsPrimitive(child) == SP_TRUE) {
	    spPrimitiveUnmapArch(child);
	} else if (spIsContainer(child) == SP_TRUE) {
	    spUnmapContainerMac(child);  
	}
	child = SpGetNextComponent(child);
    }

    if (spIsPrimitive(component) == SP_TRUE) {
	SpPrimitiveArch(component).map_flag = SP_FALSE;
    }
    
    spDebug(80, "spUnmapContainerMac", "done\n");
    
    return;
}

void spDrawContainerMac(spComponent component)
{
    char *title;
    int x, y;
    int width, height;
    int border_width;
    spBool sensitive_flag = SP_TRUE;
    Rect rect;
    Rect border_rect, title_rect;
    RgnHandle orig_rgn = NULL, dest_rgn = NULL;
    RgnHandle rgn1, rgn2;
    GrafPtr save_port;

    if (SpContainerPart(component).title_on == SP_FALSE
	&& SpContainerPart(component).border_on == SP_FALSE) {
	return;
    }

    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);

    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	sensitive_flag = SP_FALSE;
    }

    border_width = SpComponentPart(component).border_width;
    x = SpPrimitiveArch(component).rect.left + border_width;
    y = SpPrimitiveArch(component).rect.top + border_width;
    width = SpComponentPart(component).current_width - 2 * border_width;
    height = SpComponentPart(component).current_height - 2 * border_width;
    if (SpContainerPart(component).title_on == SP_TRUE) {
	y -= SP_CONTAINER_TITLE_TOP_OFFSET;
	height += SP_CONTAINER_TITLE_TOP_OFFSET;
    }
    SetRect(&border_rect, x, y, x + width, y + height);

    if (SpContainerPart(component).title_on == SP_TRUE) {
	title = spGetTitle(component);
	if (!strnone(title)) {
	    x += SP_CONTAINER_TITLE_LEFT_OFFSET;
	    y -= SP_CONTAINER_TITLE_TOP_OFFSET;
	    width = TextWidth(title, 0, strlen(title)) + 2 * SP_CONTAINER_TITLE_MARGIN;
	    height = SP_DEFAULT_LABEL_HEIGHT;
	    SetRect(&title_rect, x, y, x + width, y + height);
	    
	    spDebug(50, "spDrawContainerMac", "title = %s, x = %d, y = %d\n",
		    title, x, y);
    
	    y += SP_CONTAINER_TITLE_TOP_OFFSET + SP_CONTAINER_TITLE_MARGIN;
	    MoveTo(x + SP_CONTAINER_TITLE_MARGIN, y);
	    
	    if (sensitive_flag == SP_FALSE) {
		spGetOriginalRGBMac();
		spSetDeactivateRGBMac();
	    }

	    if (spIsAquaMac() == SP_TRUE) {
		/* to use outline font */
		TETextBox(title, strlen(title), &title_rect, teJustCenter);
	    } else {
		DrawText(title, 0, strlen(title));
	    }
	    
	    if (sensitive_flag == SP_FALSE) {
		spSetOriginalRGBMac();
	    }
	}
	
	orig_rgn = NewRgn();
	GetClip(orig_rgn);
	
	rgn1 = NewRgn();
	rgn2 = NewRgn();
	dest_rgn = NewRgn();

	spGetPortRectMac(SpPrimitiveArch(SpGetWindow(component)).window, &rect);
	RectRgn(rgn1, &rect);
	RectRgn(rgn2, &title_rect);
	DiffRgn(rgn1, rgn2, dest_rgn);
	
	DisposeRgn(rgn1);
	DisposeRgn(rgn2);
	
	SetClip(dest_rgn);
    }
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	if (sensitive_flag == SP_FALSE) {
	    DrawThemePrimaryGroup(&border_rect, kThemeStateInactive);
	} else {
	    DrawThemePrimaryGroup(&border_rect, kThemeStateActive);
	}
    } else {
	if (sensitive_flag == SP_FALSE) {
	    spGetOriginalRGBMac();
	    spSetDeactivateRGBMac();
	    FrameRect(&border_rect);
	    spSetOriginalRGBMac();
	} else {
	    FrameRect(&border_rect);
	}
    }

    if (SpContainerPart(component).title_on == SP_TRUE) {
	SetClip(orig_rgn);
	DisposeRgn(orig_rgn);
	DisposeRgn(dest_rgn);
    }
    
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return;
}

void spContainerCreateArch(spComponent component)
{
    spDebug(50, "spContainerCreateArch", "%s: visible_flag = %d, map_flag = %d\n",
	    spGetTitle(component), SpComponentPart(component).visible_flag,
	    SpPrimitiveArch(component).map_flag);

    if (SpContainerPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).border_width = 4;
	if (SpContainerPart(component).title_on == SP_TRUE) {
	    SpComponentPart(component).top_offset += 2 * SP_CONTAINER_TITLE_TOP_OFFSET + 2;
	}
    }
    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    
    spSetNeedUpdateMac(component);

    return;
}

void spContainerSetParamsArch(spComponent component)
{
    return;
}
