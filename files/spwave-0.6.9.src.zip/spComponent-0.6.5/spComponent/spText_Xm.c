/*
 *	spText_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/ScrollBar.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/Scale.h>
#include <Xm/List.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spTextP.h>

void spTextPartInitArch(spComponent component)
{
    return;
}

void spTextPartFreeArch(spComponent component)
{
    return;
}

static void setTextFont(Widget widget, char *font_name)
{	
    short w, h;
    XmFontList new_list;
    XmFontListEntry entry;
    
    if (!strnone(font_name)) {
	XtVaGetValues(widget,
		      XmNwidth, &w, XmNheight, &h,
		      NULL);
	
	entry = XmFontListEntryLoad(XtDisplay(widget),
				    font_name,
				    XmFONT_IS_FONTSET,
				    XmFONTLIST_DEFAULT_TAG);
	new_list = XmFontListAppendEntry(NULL, entry);

	XtVaSetValues(widget,
		      XmNfontList, new_list,
		      NULL);

	XmFontListEntryFree(&entry);
	XmFontListFree(new_list);
	
	XtVaSetValues(widget,
		      XmNwidth, w, XmNheight, h,
		      NULL);
    }
 
    return;
}

static void focusCB(Widget widget, XtPointer client_data, XtPointer call_data)
{
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *)call_data;
    
    if (cbs->reason == XmCR_FOCUS) {
	/* to disable shortcut keys of application */
	XGrabKeyboard(XtDisplay(widget), XtWindow(widget), False,
		      GrabModeAsync, GrabModeAsync, CurrentTime);
    } else if (cbs->reason == XmCR_LOSING_FOCUS) {
	XUngrabKeyboard(XtDisplay(widget), XtLastTimestampProcessed(XtDisplay(widget)));
    }
    
    return;
}

void spTextCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[20];

#if 0
    if (SpTextPart(component).rows >= 1) {
	XtSetArg(args[narg], XmNrows, SpTextPart(component).rows); narg++;
    }
    if (SpTextPart(component).columns >= 1) {
	XtSetArg(args[narg], XmNcolumns, SpTextPart(component).columns); narg++;
    }
#endif
    
    XtSetArg(args[narg], XmNeditable,
	     (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
    XtSetArg(args[narg], XmNcursorPositionVisible,
	     (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
    spDebug(30, "spTextCreateArch", "editable = %d\n", SpTextPart(component).editable);
	
#ifdef MOTIF_USE_CS_TEXT
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XtSetArg(args[narg], XmNrows, 1); narg++;
    } else {
	XtSetArg(args[narg], XmNeditMode, XmMULTI_LINE_EDIT); narg++;
    }
    
    /* create text */
    SpPrimitiveArch(component).widget =
	XmCreateCSText(SpParentPrimitiveArch(component).widget,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       args, narg);
    XtManageChild(SpPrimitiveArch(component).widget);
#else
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	/* create text field */
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
				  xmTextFieldWidgetClass, SpParentPrimitiveArch(component).widget,
				  args, narg);
    } else {
	XtSetArg(args[narg], XmNeditMode, XmMULTI_LINE_EDIT); narg++;
	
	/* create text area */
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
				  xmTextWidgetClass, SpParentPrimitiveArch(component).widget,
				  args, narg);
    }
#endif

    setTextFont(SpPrimitiveArch(component).widget, SpTextPart(component).font_name);
    
    XtAddCallback(SpPrimitiveArch(component).widget, XmNfocusCallback,
		  (XtCallbackProc)focusCB, (XtPointer)component);
    XtAddCallback(SpPrimitiveArch(component).widget, XmNlosingFocusCallback,
		  (XtCallbackProc)focusCB, (XtPointer)component);
    
    if (SpComponentPart(component).call_func != NULL) {
	if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	    spAddCallback(component, SP_ACTIVATE_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	}
    }
    
    return;
}

void spTextSetParamsArch(spComponent component)
{
    int narg = 0;
    Arg args[20];

    if (SpTextPart(SpOldObject(component)).editable != SpTextPart(component).editable) {
	XtSetArg(args[narg], XmNeditable,
		 (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
	XtSetArg(args[narg], XmNcursorPositionVisible,
		 (SpTextPart(component).editable == SP_TRUE ? True : False)); narg++;
	
	XtSetValues(SpPrimitiveArch(component).widget, args, narg);
    }

    if (!streq(SpTextPart(SpOldObject(component)).font_name, SpTextPart(component).font_name)) {
	setTextFont(SpPrimitiveArch(component).widget, SpTextPart(component).font_name);
    }
    
    return;
}

void spSetTextStringArch(spComponent component)
{
#ifdef MOTIF_USE_CS_TEXT
    XmString xmstr;
    
    xmstr = XmStringCreateLtoR(SpTextPart(component).string, XmFONTLIST_DEFAULT_TAG);
    XmCSTextSetString(SpPrimitiveArch(component).widget, xmstr);
    XmStringFree(xmstr);
#else
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XmTextFieldSetString(SpPrimitiveArch(component).widget, SpTextPart(component).string);
    } else {
	XmTextSetString(SpPrimitiveArch(component).widget, SpTextPart(component).string);
    }
#endif
    
    return;
}

void spGetTextStringArch(spComponent component)
{
#ifdef MOTIF_USE_CS_TEXT
    XmString xmstr;
#endif
    char *xtstr;
    
#ifdef MOTIF_USE_CS_TEXT
    if ((xmstr = XmCSTextGetString(SpPrimitiveArch(component).widget)) != NULL) {
	int length;
	XmStringContext context;
	XmStringCharSet charset;
	XmStringDirection direction;
	XmStringComponentType type;
	XmStringComponentType unknown_tag;
	unsigned short unknown_length;
	unsigned char *unknown_value;

	if (XmStringInitContext(&context, xmstr)) {
	    length = 0;
	    
	    xtstr = NULL;
	    charset = NULL;
	    unknown_value = NULL;
	    while ((type = XmStringGetNextComponent(context, &xtstr, &charset, &direction,
						    &unknown_tag, &unknown_length, &unknown_value))
		   != XmSTRING_COMPONENT_END) {
		switch (type) {
		  case XmSTRING_COMPONENT_UNKNOWN:
		    spDebug(50, "spGetTextStringArch", "unknown: type = %d\n", type);
		    if (unknown_value != NULL) {
			XtFree(unknown_value);
		    }
		    break;
		  case XmSTRING_COMPONENT_SEPARATOR:
		    length++;
		    break;
		  case XmSTRING_COMPONENT_LOCALE_TEXT:
		  case XmSTRING_COMPONENT_WIDECHAR_TEXT:
		  case XmSTRING_COMPONENT_TEXT:
		    spDebug(50, "spGetTextStringArch", "text: type = %d\n", type);
		    if (xtstr != NULL) {
			length += strlen(xtstr);
			XtFree(xtstr);
		    }
		    break;
		  case XmSTRING_COMPONENT_TAG:
		    if (charset != NULL) {
			spDebug(50, "spGetTextStringArch", "tag: type = %d, %s\n", type,
				charset);
			XtFree(charset);
		    }
		    break;
		  default:
		    break;
		}
		
		xtstr = NULL;
		charset = NULL;
		unknown_value = NULL;
	    }
	    
	    XmStringFreeContext(context);

	    spDebug(40, "spGetTextStringArch", "length = %d\n", length);
	    
	    SpTextPart(component).string = xalloc(length + 1, char);
	    SpTextPart(component).string[0] = NUL;
	    
	    if (XmStringInitContext(&context, xmstr)) {
		xtstr = NULL;
		charset = NULL;
		unknown_value = NULL;
		while ((type = XmStringGetNextComponent(context, &xtstr, &charset, &direction,
							&unknown_tag, &unknown_length, &unknown_value))
		       != XmSTRING_COMPONENT_END) {
		    switch (type) {
		      case XmSTRING_COMPONENT_UNKNOWN:
			if (unknown_value != NULL) {
			    XtFree(unknown_value);
			}
			break;
		      case XmSTRING_COMPONENT_SEPARATOR:
			strcat(SpTextPart(component).string, "\n");
			break;
		      case XmSTRING_COMPONENT_LOCALE_TEXT:
		      case XmSTRING_COMPONENT_WIDECHAR_TEXT:
		      case XmSTRING_COMPONENT_TEXT:
			if (xtstr != NULL) {
			    spDebug(50, "spGetTextStringArch", "text: string = %s\n",
				    xtstr);
			    strcat(SpTextPart(component).string, xtstr);
			    XtFree(xtstr);
			}
			break;
		      case XmSTRING_COMPONENT_TAG:
			if (charset != NULL) {
			    XtFree(charset);
			}
			break;
		      default:
			break;
		    }
		    
		    xtstr = NULL;
		    charset = NULL;
		    unknown_value = NULL;
		}
		
		XmStringFreeContext(context);
	    }
	} else {
	    SpTextPart(component).string = NULL;
	}
    
	XmStringFree(xmstr);
    }
#else
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	xtstr = XmTextFieldGetString(SpPrimitiveArch(component).widget);
    } else {
	xtstr = XmTextGetString(SpPrimitiveArch(component).widget);
    }
    
    if (xtstr == NULL) {
	SpTextPart(component).string = NULL;
    } else {
	SpTextPart(component).string = strclone(xtstr);
	XtFree(xtstr);
    }
#endif
    if (SpTextPart(component).string != NULL) {
	spDebug(40, "spGetTextStringArch", "string: %s\n", SpTextPart(component).string);
    }
    
    return;
}

spBool spSetTextSelectionArch(spComponent component, long start, long end)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	if (start == -1) {
	    XmTextFieldClearSelection(SpPrimitiveArch(component).widget,
				      XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	} else {
	    if (end == -1) end = XmTextFieldGetLastPosition(SpPrimitiveArch(component).widget);
    
	    XmTextFieldSetSelection(SpPrimitiveArch(component).widget,
				    (XmTextPosition)start, (XmTextPosition)end,
				    XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	}
    } else {
	if (start == -1) {
	    XmTextClearSelection(SpPrimitiveArch(component).widget,
				 XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	} else {
	    if (end == -1) end = XmTextGetLastPosition(SpPrimitiveArch(component).widget);
    
	    XmTextSetSelection(SpPrimitiveArch(component).widget, 
			       (XmTextPosition)start, (XmTextPosition)end,
			       XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	}
    }
    
    return SP_TRUE;
}

spBool spGetTextSelectionArch(spComponent component, long *start, long *end)
{
    XmTextPosition left, right;
    
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	if (!XmTextFieldGetSelectionPosition(SpPrimitiveArch(component).widget, &left, &right)
	    || left == right) {
	    return SP_FALSE;
	}
    } else {
	if (!XmTextGetSelectionPosition(SpPrimitiveArch(component).widget, &left, &right)
	    || left == right) {
	    return SP_FALSE;
	}
    }
    *start = (long)left;
    *end = (long)right;
    
    return SP_TRUE;
}

spBool spSetTextPositionArch(spComponent component, long position)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	if (position == -1) position = XmTextFieldGetLastPosition(SpPrimitiveArch(component).widget);
	
	XmTextFieldClearSelection(SpPrimitiveArch(component).widget,
				  XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	XmTextFieldSetInsertionPosition(SpPrimitiveArch(component).widget, (XmTextPosition)position);
    } else {
	if (position == -1) position = XmTextFieldGetLastPosition(SpPrimitiveArch(component).widget);
    
	XmTextClearSelection(SpPrimitiveArch(component).widget,
			     XtLastTimestampProcessed(XtDisplay(SpPrimitiveArch(component).widget)));
	XmTextSetInsertionPosition(SpPrimitiveArch(component).widget, (XmTextPosition)position);
    }
    
    return SP_TRUE;
}

spBool spGetTextPositionArch(spComponent component, long *position)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	*position = XmTextFieldGetInsertionPosition(SpPrimitiveArch(component).widget);
    } else {
	*position = XmTextGetInsertionPosition(SpPrimitiveArch(component).widget);
    }
    
    return SP_TRUE;
}

spBool spCutTextArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XmTextFieldCut(SpPrimitiveArch(component).widget, CurrentTime);
    } else {
	XmTextCut(SpPrimitiveArch(component).widget, CurrentTime);
    }
    return SP_TRUE;
}

spBool spCopyTextArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XmTextFieldCopy(SpPrimitiveArch(component).widget, CurrentTime);
    } else {
	XmTextCopy(SpPrimitiveArch(component).widget, CurrentTime);
    }
    return SP_TRUE;
}

spBool spPasteTextArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XmTextFieldPaste(SpPrimitiveArch(component).widget);
    } else {
	XmTextPaste(SpPrimitiveArch(component).widget);
    }
    return SP_TRUE;
}

spBool spClearTextArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	XmTextFieldRemove(SpPrimitiveArch(component).widget);
    } else {
	XmTextRemove(SpPrimitiveArch(component).widget);
    }
    return SP_TRUE;
}
