/*
 *	spToolBar_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/xpm.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spToolBarP.h>

void spToolBarPartInitArch(spComponent component)
{
    return;
}

void spToolBarPartFreeArch(spComponent component)
{
    return;
}

void spToolBarCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];
    XWindowAttributes root_attr;
    XpmAttributes xpm_attr;
    XpmColorSymbol xpm_symbols[1];
    Pixel color;
    Pixmap mask_bitmap;
    char filename[SP_MAX_PATHNAME];

    XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
    XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
    XtSetArg(args[narg], XmNresizePolicy, XmRESIZE_NONE); narg++;
    XtSetArg(args[narg], XmNtraversalOn, False); narg++;
    SpPrimitiveArch(component).widget =
	XtCreateWidget((!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       xmDrawingAreaWidgetClass, 
		       SpParentPrimitiveArch(component).widget,
		       args, narg);
    
    SpPrimitiveArch(component).display = XtDisplay(SpPrimitiveArch(component).widget);
    SpPrimitiveArch(component).screen = XtScreen(SpPrimitiveArch(component).widget);

    XGetWindowAttributes(SpPrimitiveArch(component).display,
			 RootWindowOfScreen(SpPrimitiveArch(component).screen),
			 &root_attr);
    xpm_attr.colormap = root_attr.colormap;
    xpm_attr.closeness = 40000;
    xpm_attr.valuemask = XpmSize | XpmReturnPixels | XpmColormap | XpmCloseness;
    
    XtVaGetValues(SpParentPrimitiveArch(component).widget,
		  XmNbackground, &color, NULL);
    xpm_symbols[0].name = NULL;
    xpm_symbols[0].value = "none";
    xpm_symbols[0].pixel = color;
    xpm_attr.colorsymbols = xpm_symbols;
    xpm_attr.numsymbols = 1;
    xpm_attr.valuemask |= XpmColorSymbols;
    
    if (SpToolBarPart(component).bitmap_data != NULL) {
	if (XpmCreatePixmapFromData(SpPrimitiveArch(component).display,
				    RootWindowOfScreen(SpPrimitiveArch(component).screen),
				    SpToolBarPart(component).bitmap_data,
				    &SpPrimitiveArch(component).pixmap, 
				    &mask_bitmap, 
				    &xpm_attr) == XpmSuccess) {
	}
    } else {
	if (!strnone(SpGetName(component))) {
	    sprintf(filename, "%s.xpm", SpGetName(component));
	    
	    if (XpmReadFileToPixmap(SpPrimitiveArch(component).display,
				    RootWindowOfScreen(SpPrimitiveArch(component).screen),
				    filename,
				    &SpPrimitiveArch(component).pixmap, 
				    &mask_bitmap, 
				    &xpm_attr) == XpmSuccess) {
	    }
	    spDebug(30, "spToolBarCreateArch", "pixmap load done: %s\n", filename);
	}
    }
    
    if (spIsVisible(component) == SP_TRUE) {
	XtManageChild(SpPrimitiveArch(component).widget);
    }
    
    spDebug(30, "spToolBarCreateArch", "create done\n");

    return;
}

void spToolBarSetParamsArch(spComponent component)
{
    return;
}
    
void spToolBarDestroyArch(spComponent component)
{
    return;
}
