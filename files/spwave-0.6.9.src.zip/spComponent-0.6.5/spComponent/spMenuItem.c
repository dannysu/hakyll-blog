/*
 *	spMenuItem.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spButtonP.h>
#include <sp/spMenuItemP.h>

#if defined(MACOS)
#pragma import on
#endif

extern spTopLevel sp_toplevel;

#if defined(MACOS)
#pragma import off
#endif

static spParamTable sp_menu_item_param_tables[] = {
    {SppShortcut, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spMenuItem, menu_item.shortcut), ""},
};

spMenuItemClassRec SpMenuItemClassRec = {
    /* spObjectClassPart */
    {
	SpMenuItem,
	(spObjectClass)&SpButtonClassRec,
	sizeof(spMenuItemRec),
	spArraySize(sp_menu_item_param_tables),
	sp_menu_item_param_tables,
	spMenuItemPartInit,
	spMenuItemPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spMenuItemCreate,
	NULL,
	spMenuItemSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spLabelClassPart */
    {
	0,
    },
    /* spButtonClassPart */
    {
	0,
    },
    /* spMenuItemClassPart */
    {
	0,
    },
};

spComponentClass SpMenuItemClass = (spComponentClass)&SpMenuItemClassRec;

void spMenuItemPartInit(spObject object)
{
    return;
}

void spMenuItemPartFree(spObject object)
{
    return;
}


static spBool addShortcut(spComponent component)
{
    char *shortcut;
    char buf[SP_MAX_LINE];
    
    if (strnone(SpMenuItemPart(component).shortcut)) return SP_FALSE;

    shortcut = SpMenuItemPart(component).shortcut;
    
    if (SpTopLevelPart(sp_toplevel).alt_ctrl_swap == SP_TRUE) {
	if (strncaseeq(SpMenuItemPart(component).shortcut, "C-", 2)) {
	    strcpy(buf, SpMenuItemPart(component).shortcut);
	    buf[0] = 'A';
	    shortcut = buf;
	} else if (strncaseeq(SpMenuItemPart(component).shortcut, "A-", 2)) {
	    strcpy(buf, SpMenuItemPart(component).shortcut);
	    buf[0] = 'C';
	    shortcut = buf;
	}
    }
    
    return spAddShortcutArch(component, shortcut);
}
    
void spMenuItemCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spMenuItemCreateArch(component);
    
    addShortcut(component);
    
    if (spIsToggleButton(component) == SP_TRUE) {
	spDebug(50, "spMenuItemCreate", "set: %d\n", SpButtonPart(component).set);
	spSetToggleStateArch(component);
    }

    if (SpComponentPart(component).call_func != NULL) {
	spDebug(40, "spMenuItemCreate", "add callback\n");
	if (spIsToggleButton(component) == SP_TRUE) {
	    spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	} else {
	    spAddCallback(component, SP_ACTIVATE_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	}
    }
    
    return;
}

void spMenuItemSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;
    
    spMenuItemSetParamsArch(component);
    
    if (spIsToggleButton(component) == SP_TRUE) {
	spSetToggleStateArch(component);
    }
    
    if (SpMenuItemPart(SpOldObject(component)).shortcut != SpMenuItemPart(component).shortcut) {
	addShortcut(component);
    }
    
    return;
}

void spMenuSeparatorCreate(spComponent component)
{
    if (spIsCreated(component) == SP_TRUE) return;

    spMenuSeparatorCreateArch(component);
	
    return;
}

spBool spIsMenuItem(spComponent component)
{
    return spIsSubClass(component, SpMenuItem);
}

spBool spIsCheckBoxMenuItem(spComponent component)
{
    return spIsSubClass(component, SpCheckBoxMenuItem);
}

spBool spIsRadioButtonMenuItem(spComponent component)
{
    return spIsSubClass(component, SpRadioButtonMenuItem);
}

spBool spIsMenuSeparator(spComponent component)
{
    return spIsSubClass(component, SpMenuSeparator);
}

spComponent spAddMenuItem(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuItemClass, SpMenuItem, name, parent, args, num_arg);
}

spComponent spAddCheckBoxMenuItem(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuItemClass, SpCheckBoxMenuItem, name, parent, args, num_arg);
}

spComponent spAddRadioButtonMenuItem(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuItemClass, SpRadioButtonMenuItem, name, parent, args, num_arg);
}

spComponent spAddMenuSeparator(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpPrimitiveClass, SpMenuSeparator, name, parent, args, num_arg);
}
