/*
 *	spDialog.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spDialogP.h>

static spParamTable sp_dialog_param_tables[] = {
    {SppDialogType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.dialog_type), SP_MESSAGE_DIALOG_STRING},
    {SppMessageBoxButtonType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.button_type), SP_MB_OK_STRING},
    {SppDialogBoxButtonType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.button_type), SP_DB_OK_STRING},
    {SppFileFilters, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.file_filters), NULL},
    {SppFileTypes, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.file_types), NULL},
    {SppFileFilterIndex, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.filter_index), NULL},
    {SppInitialDir, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.initial_dir), NULL},
    {SppInitialFileName, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.initial_file_name), NULL},
    {SppPathMustExist, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.path_must_exist), SP_TRUE_STRING},
    {SppFileMustExist, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.file_must_exist), SP_FALSE_STRING},
    {SppOverwritePrompt, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.overwrite_prompt), SP_FALSE_STRING},
    {SppInitialFont, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.initial_font), NULL},
    {SppInitialColor, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.initial_color), NULL},
    {SppParentWindow, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialog, dialog.parent_window), NULL},
};

spDialogClassRec SpDialogClassRec = {
    /* spObjectClassPart */
    {
	SpDialog,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spDialogRec),
	spArraySize(sp_dialog_param_tables),
	sp_dialog_param_tables,
	spDialogPartInit,
	spDialogPartFree,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_TRUE,
	SP_TRUE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spDialogClassPart */
    {
	0,
    },
};

spComponentClass SpDialogClass = (spComponentClass)&SpDialogClassRec;

void spDialogPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    spDialogPartInitArch(component);
    
    SpDialogPart(component).file_filters = NULL;
    SpDialogPart(component).file_types = NULL;
    SpDialogPart(component).filter_index = NULL;
    SpDialogPart(component).initial_dir = NULL;
    SpDialogPart(component).initial_file_name = NULL;
    
    SpDialogPart(component).initial_font = NULL;
    SpDialogPart(component).initial_color = NULL;
    
    SpDialogPart(component).parent_window = NULL;
    
    return;
}

void spDialogPartFree(spObject object)
{
    return;
}

char *spGetMessageBoxTitle(spComponent component)
{
    char *title;

    title = SpComponentPart(component).title;
    
    if (SpDialogPart(component).dialog_type == SP_INFORMATION_DIALOG) {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ?
		     SpGetName(component) : SP_INFORMATION_TITLE);
    } else if (SpDialogPart(component).dialog_type == SP_QUESTION_DIALOG) {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ?
		     SpGetName(component) : SP_QUESTION_TITLE);
    } else if (SpDialogPart(component).dialog_type == SP_WARNING_DIALOG) {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ?
		     SpGetName(component) : SP_WARNING_TITLE);
    } else if (SpDialogPart(component).dialog_type == SP_ERROR_DIALOG) {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ?
		     SpGetName(component) : SP_ERROR_TITLE);
    } else if (SpDialogPart(component).dialog_type == SP_WORKING_DIALOG) {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ?
		     SpGetName(component) : SP_WORKING_TITLE);
    } else {
	if (title == NULL)
	    title = (!strnone(SpGetName(component)) ? SpGetName(component) : SP_MESSAGE_TITLE);
    }
    
    return title;
}

spBool spIsDialog(spComponent component)
{
    if (component == NULL) return SP_FALSE;
    
    if (spIsSubClass(component, SpDialog) == SP_TRUE) {
	return SP_TRUE;
    } else if (spIsSubClass(component, SpFrame) == SP_TRUE) {
	if (SpFramePart(component).window_type == SP_DIALOG_WINDOW) {
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

spDialogResponse spCreateMessageBox(spComponent parent, char *name,
				    char *message, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    spComponent component;
    spDialogResponse response;
    
    va_start(argp, message);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    component = spCreateComponentArg(SpDialogClass, SpMessageDialog,
				     name, parent, args, num_arg);
    response = spPopupMessageBox(component, message);
    spDebug(30, "spCreateMessageBox", "response = %d\n", response);
    
    spDestroyComponent(component);
    
    return response;
}

/*
 *	display message
 */
void spDisplayError(spComponent parent, char *title, char *format, ...)
{
    va_list argp;
    char string[SP_MAX_MESSAGE];

    va_start (argp, format);
    vsprintf(string, format, argp);
    va_end (argp);

    if (spIsCreated(parent) == SP_FALSE && spIsTopLevelCreated() == SP_FALSE) {
	fprintf(stderr, string);
    } else {
	spCreateMessageBox(parent, title, string,
			   SppDialogType, SP_ERROR_DIALOG,
			   SppMessageBoxButtonType, SP_MB_OK,
			   NULL); 
    }

    return;
}

void spDisplayWarning(spComponent parent, char *title, char *format, ...)
{
    va_list argp;
    char string[SP_MAX_MESSAGE];

    va_start (argp, format);
    vsprintf(string, format, argp);
    va_end (argp);

    if (spIsCreated(parent) == SP_FALSE && spIsTopLevelCreated() == SP_FALSE) {
	fprintf(stderr, string);
    } else {
	spCreateMessageBox(parent, title, string,
			   SppDialogType, SP_WARNING_DIALOG,
			   SppMessageBoxButtonType, SP_MB_OK,
			   NULL); 
    }

    return;
}

void spDisplayMessage(spComponent parent, char *title, char *format, ...)
{
    va_list argp;
    char string[SP_MAX_MESSAGE];

    va_start (argp, format);
    vsprintf(string, format, argp);
    va_end (argp);

    if (spIsCreated(parent) == SP_FALSE && spIsTopLevelCreated() == SP_FALSE) {
	fprintf(stderr, string);
    } else {
	spCreateMessageBox(parent, title, string,
			   SppDialogType, SP_MESSAGE_DIALOG,
			   SppMessageBoxButtonType, SP_MB_OK,
			   NULL); 
    }

    return;
}

void spDisplayInformation(spComponent parent, char *title, char *format, ...)
{
    va_list argp;
    char string[SP_MAX_MESSAGE];

    va_start (argp, format);
    vsprintf(string, format, argp);
    va_end (argp);

    if (spIsCreated(parent) == SP_FALSE && spIsTopLevelCreated() == SP_FALSE) {
	fprintf(stderr, string);
    } else {
	spCreateMessageBox(parent, title, string,
			   SppDialogType, SP_INFORMATION_DIALOG,
			   SppMessageBoxButtonType, SP_MB_OK,
			   NULL); 
    }

    return;
}

void spDisplayErrorCB(spComponent component, char *message)
{
    spDisplayError(component, NULL, message);
    return;
}

void spDisplayWarningCB(spComponent component, char *message)
{
    spDisplayWarning(component, NULL, message);
    return;
}

void spDisplayMessageCB(spComponent component, char *message)
{
    spDisplayMessage(component, NULL, message);
    return;
}

void spDisplayInformationCB(spComponent component, char *message)
{
    spDisplayInformation(component, NULL, message);
    return;
}

/* You can specify null parent. */
char *xspGetOpenFileName(spComponent parent, char *name, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    char *filename;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    filename = xspPopupFileSelectionBoxArg(parent, name, SP_FD_TYPE_OPEN, args, num_arg);
    spDebug(30, "xspGetOpenFileName", "done\n");
    
    return filename;
}

spBool spAddCurrentFilterSuffix(spComponent component, int filter_index, char *buf)
{
    char *filter;
		    
    if (filter_index >= 0 && SpDialogPart(component).file_filters != NULL) {
	filter = SpDialogPart(component).file_filters[filter_index];

	if (spGetSuffix(spGetBaseName(buf)) == NULL) {
	    spReplaceSuffix(buf, filter);
			
	    if (SpDialogPart(component).overwrite_prompt == SP_TRUE
		&& spIsExist(buf) == SP_TRUE
		&& spOverwritePrompt(SpGetParent(component), buf) == SP_FALSE) {
		return SP_FALSE;
	    }
	}
    }

    return SP_TRUE;
}

char *xspGetSaveFileName(spComponent parent, char *name, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    char *filename;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    filename = xspPopupFileSelectionBoxArg(parent, name, SP_FD_TYPE_SAVE, args, num_arg);
    spDebug(30, "xspGetSaveFileName", "done\n");
    
    return filename;
}

char *xspGetSelectedDirName(spComponent parent, char *name, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    char *filename;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    filename = xspPopupFileSelectionBoxArg(parent, name, SP_FD_TYPE_DIR, args, num_arg);
    spDebug(30, "xspGetSelectedDirName", "done\n");
    
    return filename;
}

char *xspChooseFont(spComponent parent, char *name, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    char *font_name;
    spComponent component;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    component = spCreateComponentArg(SpDialogClass, SpFontDialog,
				     name, parent, args, num_arg);
    font_name = xspChooseFontArch(component);
    spDebug(30, "xspChooseFont", "done\n");
    
    spDestroyComponent(component);
    
    return font_name;
}

char *xspChooseColor(spComponent parent, char *name, ...)
{
    va_list argp;
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    char *colorname;
    spComponent component;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    component = spCreateComponentArg(SpDialogClass, SpColorDialog,
				     name, parent, args, num_arg);
    colorname = xspChooseColorArch(component);
    
    spDestroyComponent(component);
    
    spDebug(30, "xspChooseColor", "done\n");
    
    return colorname;
}
