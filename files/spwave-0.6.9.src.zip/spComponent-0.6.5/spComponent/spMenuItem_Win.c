/*
 *	spMenuItem_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spMenuItemP.h>

extern spTopLevel sp_toplevel;

static void checkMenuItemCB(spComponent component, void *data)
{
    spBool set = SP_FALSE;
    
    if (spIsCreated(component) == SP_FALSE ||
	spIsToggleButton(component) == SP_FALSE) return;

    if (spGetToggleState(component, &set) == SP_TRUE) {
	if (set == SP_TRUE) {
	    spSetToggleState(component, SP_FALSE);
	} else {
	    spSetToggleState(component, SP_TRUE);
	}
    }
    
    return;
}

void spCreateMenuItemWin(spComponent component)
{
    MENUITEMINFO minfo;
    spComponent next_menu_item;
    char *title;

    title = SpComponentPart(component).title;

    if (title == NULL) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
	
    minfo.cbSize = sizeof(minfo);
    minfo.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
    minfo.fType = MFT_STRING;
    if (spIsRadioButton(component) == SP_TRUE) {
	minfo.fType |= MFT_RADIOCHECK;
    }
    minfo.fState = MFS_ENABLED;
    minfo.dwTypeData = title;
    minfo.wID = SpComponentPart(component).component_id;

    next_menu_item = SpGetNextComponent(component);
    while (next_menu_item != NULL) {
	if (spIsMenuItem(next_menu_item) == SP_TRUE) {
	    break;
	}
	next_menu_item = SpGetNextComponent(next_menu_item);
    }
	
    if (next_menu_item == NULL) {
	InsertMenuItem(SpParentPrimitiveArch(component).hmenu,
		       GetMenuItemCount(SpParentPrimitiveArch(component).hmenu),
		       TRUE, &minfo);
    } else {
	InsertMenuItem(SpParentPrimitiveArch(component).hmenu,
		       SpComponentPart(next_menu_item).component_id,
		       FALSE, &minfo);
    }

    return;
}
    
void spMenuItemCreateArch(spComponent component)
{
    spCreateMenuItemWin(component);
    
    if (spIsSubClass(component, SpCheckBoxMenuItem) == SP_TRUE) {
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK, checkMenuItemCB, NULL);
    }

    if (spIsRadioButton(component) == SP_TRUE) {
	spAddRadioGroup(component, SpButtonPart(component).radio_end);
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK, spCheckRadioButtonCB, NULL);
    }
    
    spDebug(60, "spMenuItemCreateArch", "done\n");
    
    return;
}

void spMenuItemSetParamsArch(spComponent component)
{
    char *title;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;
	
	if (title != NULL) {
	    ModifyMenu(SpParentPrimitiveArch(component).hmenu,
		       (UINT)SpComponentPart(component).component_id,
		       MF_BYCOMMAND | MF_STRING,
		       (UINT)SpComponentPart(component).component_id, title);
	    DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
	}
    }

    spDebug(60, "spMenuItemSetParamsArch", "done\n");
    
    return;
}

void spMenuSeparatorCreateArch(spComponent component)
{
    AppendMenu(SpParentPrimitiveArch(component).hmenu, MF_SEPARATOR, 0, "");
    
    return;
}

static spBool convertKeySym(char *keyname, WORD *key, char *keylabel)
{
    int len;
    spBool flag = SP_TRUE;

    if (key == NULL || strnone(keyname)) {
	flag = SP_FALSE;
    } else {
	len = strlen(keyname);
	if (streq(keyname, "RET") ||
	    streq(keyname, "RETURN") || streq(keyname, "Return") ||
	    streq(keyname, "ENTER") || streq(keyname, "Enter")) {
	    *key = VK_RETURN;
	    strcpy(keylabel, "Return");
	} else if (streq(keyname, "ESC") ||
		   streq(keyname, "ESCAPE") || streq(keyname, "Escape")) {
	    *key = VK_ESCAPE;
	    strcpy(keylabel, "Escape");
	} else if (streq(keyname, "SPC") ||
		   streq(keyname, "SPACE") || streq(keyname, "Space")) {
	    *key = VK_SPACE;
	    strcpy(keylabel, "Space");
	} else if (streq(keyname, "DEL") ||
		   streq(keyname, "DELETE") || streq(keyname, "Delete")) {
	    *key = VK_DELETE;
	    strcpy(keylabel, "Delete");
	} else if (streq(keyname, "INS") ||
		   streq(keyname, "INSERT") || streq(keyname, "Insert")) {
	    *key = VK_INSERT;
	    strcpy(keylabel, "Insert");
	} else if (streq(keyname, "TAB") || streq(keyname, "Tab")) {
	    *key = VK_TAB;
	    strcpy(keylabel, "Tab");
	} else if (streq(keyname, "LEFT") || streq(keyname, "Left")) {
	    *key = VK_LEFT;
	    strcpy(keylabel, "Left");
	} else if (streq(keyname, "UP") || streq(keyname, "Up")) {
	    *key = VK_UP;
	    strcpy(keylabel, "Up");
	} else if (streq(keyname, "RIGHT") || streq(keyname, "Right")) {
	    *key = VK_RIGHT;
	    strcpy(keylabel, "Right");
	} else if (streq(keyname, "DOWN") || streq(keyname, "Down")) {
	    *key = VK_DOWN;
	    strcpy(keylabel, "Down");
	} else if (streq(keyname, "HOME") || streq(keyname, "Home")) {
	    *key = VK_HOME;
	    strcpy(keylabel, "Home");
	} else if (streq(keyname, "END") || streq(keyname, "End")) {
	    *key = VK_END;
	    strcpy(keylabel, "End");
	} else if (streq(keyname, "PRIOR") || streq(keyname, "Prior")) {
	    *key = VK_PRIOR;
	    strcpy(keylabel, "Prior");
	} else if (streq(keyname, "NEXT") || streq(keyname, "Next")) {
	    *key = VK_NEXT;
	    strcpy(keylabel, "Next");
	} else if (streq(keyname, "F1")) {
	    *key = VK_F1;
	    strcpy(keylabel, "F1");
	} else if (streq(keyname, "F2")) {
	    *key = VK_F2;
	    strcpy(keylabel, "F2");
	} else if (streq(keyname, "F3")) {
	    *key = VK_F3;
	    strcpy(keylabel, "F3");
	} else if (streq(keyname, "F4")) {
	    *key = VK_F4;
	    strcpy(keylabel, "F4");
	} else if (streq(keyname, "F5")) {
	    *key = VK_F5;
	    strcpy(keylabel, "F5");
	} else if (streq(keyname, "F6")) {
	    *key = VK_F6;
	    strcpy(keylabel, "F6");
	} else if (streq(keyname, "F7")) {
	    *key = VK_F7;
	    strcpy(keylabel, "F7");
	} else if (streq(keyname, "F8")) {
	    *key = VK_F8;
	    strcpy(keylabel, "F8");
	} else if (streq(keyname, "F9")) {
	    *key = VK_F9;
	    strcpy(keylabel, "F9");
	} else if (streq(keyname, "F10")) {
	    *key = VK_F10;
	    strcpy(keylabel, "F10");
	} else if (streq(keyname, "F11")) {
	    *key = VK_F11;
	    strcpy(keylabel, "F11");
	} else if (streq(keyname, "F12")) {
	    *key = VK_F12;
	    strcpy(keylabel, "F12");
	} else if (len == 1) {
	    *key = toupper(keyname[0]);
	    sprintf(keylabel, "%c", toupper(keyname[0]));
	} else {
	    spWarning("unknown key symbol: %s\n", keyname);
	    flag = SP_FALSE;
	}
    }

    spDebug(80, "convertKeySym", "keyname = %s, key = %c, keylabel = %s\n",
	    keyname, *key, keylabel);
    
    return flag;
}

static spBool getShortcutLabel(char *shortcut, BYTE *fVirt, WORD *key,
			       char *label)
{
    spBool flag = SP_TRUE;
    int len;
    char *p = NULL;
    static char modkey[SP_MAX_LINE] = "";
    static char keylabel[SP_MAX_LINE] = "";

    if (fVirt == NULL || key == NULL) return SP_FALSE;

    if (!strnone(shortcut)) {
	len = strlen(shortcut);
	if ((p = strchr(shortcut, '-')) != NULL) {
	    switch (shortcut[0]) {
	      case 'C':
		*fVirt = FALT | FVIRTKEY;
		strcpy(modkey, "Alt");
		break;
	      case 'S':
		*fVirt = FSHIFT | FVIRTKEY;
		strcpy(modkey, "Shift");
		break;
	      case 'M':
		*fVirt = FALT | FVIRTKEY;
		strcpy(modkey, "Alt");
		break;
	      case 'A':
		*fVirt = FCONTROL | FVIRTKEY;
		strcpy(modkey, "Ctrl");
		break;
	      default:
		flag = SP_FALSE;
		break;
	    }
	    if (flag == SP_TRUE &&
		convertKeySym(p + 1, key, keylabel) == SP_TRUE) {
		sprintf(label, "%s+%s", modkey, keylabel);
	    } else {
		spWarning("unknown shortcut: %s\n", shortcut);
		flag = SP_FALSE;
	    }
	} else if (convertKeySym(shortcut, key, keylabel) == SP_TRUE) {
	    *fVirt = FVIRTKEY;
	    sprintf(label, "%s", keylabel);
	} else {
	    flag = SP_FALSE;
	}
    } else {
	flag = SP_FALSE;
    }
    
    spDebug(80, "getShortcutKey", "shortcut = %s, key = %c\n",
	    shortcut, *key);
    
    return flag;
}

static void reallocAccelerator(spComponent component)
{
    long k;
    
    if (component == NULL ||
	SpPrimitiveArch(component).num_accel < SpPrimitiveArch(component).num_accel_buffer) return;

    if (SpPrimitiveArch(component).accels == NULL) {
	SpPrimitiveArch(component).num_accel_buffer = SP_ACCEL_BUFFER;
	SpPrimitiveArch(component).accels =
	    xalloc(SpPrimitiveArch(component).num_accel_buffer, ACCEL);
	SpPrimitiveArch(component).num_accel = 0;
    } else {
	SpPrimitiveArch(component).num_accel_buffer += SP_ACCEL_BUFFER;
	SpPrimitiveArch(component).accels =
	    xrealloc(SpPrimitiveArch(component).accels,
		     SpPrimitiveArch(component).num_accel_buffer, ACCEL);
    }
    
    for (k = SpPrimitiveArch(component).num_accel; k < SpPrimitiveArch(component).num_accel_buffer; k++) {
	SpPrimitiveArch(component).accels[k].fVirt = 0;
	SpPrimitiveArch(component).accels[k].key = NUL;
	SpPrimitiveArch(component).accels[k].cmd = 0;
    }

    return;
}

static void addAccelerator(spComponent component, BYTE fVirt, WORD key, WORD cmd)
{
    long k;

    for (k = 0; k < SpPrimitiveArch(component).num_accel; k++) {
	if (SpPrimitiveArch(component).accels[k].key == NUL) {
	    break;
	}
    }

    if (k >= SpPrimitiveArch(component).num_accel) {
	reallocAccelerator(component);
	SpPrimitiveArch(component).num_accel++;
    }

    SpPrimitiveArch(component).accels[k].fVirt = fVirt;
    SpPrimitiveArch(component).accels[k].key = key;
    SpPrimitiveArch(component).accels[k].cmd = cmd;

    if (SpPrimitiveArch(component).haccel != NULL) {
	DestroyAcceleratorTable(SpPrimitiveArch(component).haccel);
    }
    SpPrimitiveArch(component).haccel = CreateAcceleratorTable(SpPrimitiveArch(component).accels,
					       SpPrimitiveArch(component).num_accel);
    
    spDebug(60, "addAccelerator", "num_accel = %d, key = %c, cmd = %d\n",
	    SpPrimitiveArch(component).num_accel, key, (int)cmd);
    
    return;
}

spBool spAddShortcutArch(spComponent component, char *shortcut)
{
    BYTE fVirt;
    WORD key;
    static char label[SP_MAX_BUTTON_LABEL] = "";
    static char shortcut_label[SP_MAX_BUTTON_LABEL] = "";

    if (component == NULL) return SP_FALSE;
    
    if (getShortcutLabel(shortcut, &fVirt, &key, shortcut_label) == SP_TRUE) {
	if (SpPrimitiveArch(component).hwnd != NULL) {
	    /* get component label */
	    SendMessage(SpPrimitiveArch(component).hwnd, WM_GETTEXT,
			(WPARAM)SP_MAX_BUTTON_LABEL, (LPARAM)(LPCTSTR)label);
	    
	    /* set shortcut label */
	    strcat(label, "\t");
	    strcat(label, shortcut_label);
	    
	    /* set component label */
	    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETTEXT,
			(WPARAM)0, (LPARAM)(LPCTSTR)label);
	} else if (spIsSubClass(component, SpMenuItem) == SP_TRUE) {
	    if (!strnone(SpComponentPart(component).title)) {
		/* set shortcut label */
		strcpy(label, SpComponentPart(component).title);
		strcat(label, "\t");
		strcat(label, shortcut_label);
		
		/* set menu label */
		ModifyMenu(SpParentPrimitiveArch(component).hmenu, (UINT)SpComponentPart(component).component_id,
			   MF_BYCOMMAND | MF_STRING, (UINT)SpComponentPart(component).component_id,
			   label);
		DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
	    }
	}

	addAccelerator(SpGetWindow(component), fVirt, key, (WORD)SpComponentPart(component).component_id);
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}




