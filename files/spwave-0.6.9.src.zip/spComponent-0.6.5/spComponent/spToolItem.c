/*
 *	spToolItem.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spButton.h>

#include <sp/spToolBarP.h>
#include <sp/spToolItemP.h>

static spParamTable sp_tool_item_param_tables[] = {
    {SppBitmapIndex, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolItem, primitive.index), "-1"},
    {SppSet, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spToolItem, tool_item.set), SP_FALSE_STRING},
};

spToolItemClassRec SpToolItemClassRec = {
    /* spObjectClassPart */
    {
	SpToolItem,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spToolItemRec),
	spArraySize(sp_tool_item_param_tables),
	sp_tool_item_param_tables,
	spToolItemPartInit,
	spToolItemPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spToolItemCreate,
	spToolItemDestroy,
	spToolItemSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spToolItemClassPart */
    {
	0,
    },
};

spComponentClass SpToolItemClass = (spComponentClass)&SpToolItemClassRec;

void spToolItemPartInit(spObject object)
{
    spComponent component = (spComponent)object;

    spToolItemPartInitArch(component);

    SpToolItemPart(component).set = SP_FALSE;
    
    return;
}

void spToolItemPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spToolItemPartFreeArch(component);

    return;
}

void spToolItemCreate(spObject object)
{
    spComponent tool_bar;
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    SpComponentPart(component).spacing_flag = SP_TRUE;
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (spIsSubClass(component, SpToolSeparator) == SP_FALSE) {
	SpComponentPart(component).width = SpParentToolBarPart(component).bitmap_width + 8;
    } else {
	SpComponentPart(component).width = SP_DEFAULT_TOOL_SEPARATOR_WIDTH;
    }
    SpComponentPart(component).height = SpParentToolBarPart(component).bitmap_height + 8;
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;
    
    if (spIsSubClass(component, SpToolSeparator) == SP_FALSE) {
	tool_bar = SpGetParent(component);

	if (SpPrimitivePart(component).index < 0) {
	    SpPrimitivePart(component).index = SpToolBarPart(tool_bar).current_index;
	    SpToolBarPart(tool_bar).current_index++;
	} else {
	    SpToolBarPart(tool_bar).current_index =
		MAX(SpPrimitivePart(component).index + 1,
		    SpToolBarPart(tool_bar).current_index);
	}
    }
    
    spToolItemCreateArch(component);
    
    if (spIsSubClass(component, SpCheckToolItem)) {
	spSetToolItemToggleStateArch(component);
    }
    
    if (SpComponentPart(component).call_func != NULL) {
	if (spIsSubClass(component, SpCheckToolItem)) {
	    spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	} else {
	    spAddCallback(component, SP_ACTIVATE_CALLBACK,
			  SpComponentPart(component).call_func,
			  SpComponentPart(component).call_data);
	}
    }
    
    return;
}

void spToolItemSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spToolItemSetParamsArch(component);
    
    return;
}

void spToolItemDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spToolItemDestroyArch(component);
    spPrimitiveDestroyArch(component);
    
    return;
}

spBool spIsToolItem(spComponent component)
{
    return spIsSubClass(component, SpToolItem);
}

spBool spIsCheckToolItem(spComponent component)
{
    return spIsSubClass(component, SpCheckToolItem);
}

spComponent spAddToolItem(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsToolBar(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpToolItemClass, SpToolItem, name, parent, args, num_arg);
}

spComponent spAddCheckToolItem(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsToolBar(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpToolItemClass, SpCheckToolItem, name, parent, args, num_arg);
}

spComponent spAddToolSeparator(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsToolBar(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpToolItemClass, SpToolSeparator, name, parent, args, num_arg);
}

spBool spSetToolItemToggleState(spComponent component, spBool set)
{
    if (spIsCheckToolItem(component) == SP_FALSE) {
	return SP_FALSE;
    }

    SpToolItemPart(component).set = set;
    spSetToolItemToggleStateArch(component);
    
    return SP_TRUE;
}

spBool spGetToolItemToggleState(spComponent component, spBool *set)
{
    if (spIsCheckToolItem(component) == SP_FALSE) {
	return SP_FALSE;
    }

    spGetToolItemToggleStateArch(component);
    if (set != NULL) *set = SpToolItemPart(component).set;
    
    return SP_TRUE;
}
