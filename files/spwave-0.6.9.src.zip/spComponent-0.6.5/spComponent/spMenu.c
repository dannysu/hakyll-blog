/*
 *	spMenu.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrame.h>
#include <sp/spContainer.h>
#include <sp/spMenuItem.h>

#include <sp/spFrameP.h>
#include <sp/spMenuP.h>

static spParamTable sp_menu_param_tables[] = {
    {SppPopupButton, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spMenu, menu.popup_button), SP_RBUTTON_STRING},
    {SppMenuTearOff, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spMenu, menu.tearoff_flag), SP_FALSE_STRING},
    {SppMenuHelp, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spMenu, menu.help_flag), SP_FALSE_STRING},
};

spMenuClassRec SpMenuClassRec = {
    /* spObjectClassPart */
    {
	SpMenu,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spMenuRec),
	spArraySize(sp_menu_param_tables),
	sp_menu_param_tables,
	spMenuPartInit,
	spMenuPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spMenuCreate,
	NULL,
	spMenuSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spMenuClassPart */
    {
	0,
    },
};

spComponentClass SpMenuClass = (spComponentClass)&SpMenuClassRec;

void spMenuPartInit(spObject object)
{
    return;
}

void spMenuPartFree(spObject object)
{
    return;
}

void spMenuCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (spIsSubClass(component, SpPulldownMenu) == SP_TRUE) {
	spPulldownMenuCreate(component);
    } else if (spIsSubClass(component, SpPopupMenu) == SP_TRUE) {
	spPopupMenuCreate(component);
    }
	
    return;
}

void spMenuSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (spIsSubClass(component, SpPulldownMenu) == SP_TRUE) {
	spPulldownMenuSetParams(component);
    } else if (spIsSubClass(component, SpPopupMenu) == SP_TRUE) {
	spPopupMenuSetParams(component);
    }
	
    return;
}

void spPulldownMenuCreate(spComponent component)
{
    if (component == NULL) return;

    spPulldownMenuCreateArch(component);
	
    return;
}

void spPulldownMenuSetParams(spComponent component)
{
    if (component == NULL) return;

    spPulldownMenuSetParamsArch(component);
	
    return;
}

void spPopupMenuCreate(spComponent component)
{
    if (component == NULL) return;

    spPopupMenuCreateArch(component);
	
    return;
}

void spPopupMenuSetParams(spComponent component)
{
    if (component == NULL) return;

    spPopupMenuSetParamsArch(component);
	
    return;
}

void spMenuBarCreate(spComponent component)
{
    spComponent window;
    
    if (spIsCreated(component) == SP_TRUE) return;

    spMenuBarCreateArch(component);
    
    if ((window = SpGetWindow(component)) != NULL && spIsFrame(window) == SP_TRUE) {
	SpFramePart(window).menu_bar = component;
    }
	
    return;
}

spBool spIsMenu(spComponent component)
{
    return spIsSubClass(component, SpMenu);
}

spBool spIsMenuBar(spComponent component)
{
    return spIsSubClass(component, SpMenuBar);
}

spBool spIsSubMenu(spComponent component)
{
    if (spIsSubClass(component, SpPulldownMenu) == SP_TRUE
	&& spIsMenu(SpGetParent(component)) == SP_TRUE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spComponent spCreateMenuBar(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsWindow(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpPrimitiveClass, SpMenuBar, name, parent, args, num_arg);
}

spComponent spCreatePulldownMenu(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuClass, SpPulldownMenu, name, parent, args, num_arg);
}

spComponent spCreatePopupMenu(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuClass, SpPopupMenu, name, parent, args, num_arg);
}

spComponent spCreateTaskTrayPopup(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    spComponent component;
    
    if (spIsTaskTraySupported() == SP_FALSE || spIsCreated(parent) == SP_FALSE
	|| spIsFrame(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    if ((component = spCreateComponentArg(SpMenuClass, SpPopupMenu,
					  name, parent, args, num_arg)) == NULL) {
	return NULL;
    }
    SpFramePart(parent).task_tray_menu = component;
    
    spDebug(10, "spCreateTaskTrayPopup", "done\n");
    
    return component;
}

spComponent spAddSubMenu(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpMenuClass, SpPulldownMenu, name, parent, args, num_arg);
}
