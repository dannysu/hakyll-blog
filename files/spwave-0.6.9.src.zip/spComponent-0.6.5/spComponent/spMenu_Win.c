/*
 *	spMenu_Win.c
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spMenuP.h>

void spPulldownMenuCreateArch(spComponent component)
{
    char *title;

    title = SpComponentPart(component).title;

    if (title == NULL) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    if (spIsSubClass(SpGetParent(component), SpMenuBar) == SP_FALSE) {
	/* create popup menu */
	SpPrimitiveArch(component).hmenu = CreatePopupMenu();
    } else {
	/* create menu */
	SpPrimitiveArch(component).hmenu = CreateMenu();
    }
    if (spIsSubClass(component, SpPopupMenu) == SP_FALSE) {
	AppendMenu(SpParentPrimitiveArch(component).hmenu, MF_POPUP,
		   (UINT)SpPrimitiveArch(component).hmenu, title);
    }

    return;
}

void spPulldownMenuSetParamsArch(spComponent component)
{
    char *title;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	title = SpComponentPart(component).title;
	
	if (title != NULL) {
	    ModifyMenu(SpParentPrimitiveArch(component).hmenu,
		       (UINT)SpPrimitiveArch(component).hmenu,
		       MF_BYCOMMAND | MF_POPUP | MF_STRING,
		       (UINT)SpPrimitiveArch(component).hmenu, title);
	    DrawMenuBar(SpPrimitiveArch(SpGetWindow(component)).hwnd);
	}
    }

    return;
}

void spPopupMenuWinCB(spComponent component, spComponent menu)
{
    int x, y;
    POINT point;
    UINT uFlags;
    spBool task_tray_flag = SP_FALSE;
    spCallbackReason popup_reason;

    if (spIsCreated(component) == SP_FALSE || spIsCreated(menu) == SP_FALSE
	|| SpPrimitiveArch(component).hwnd == NULL || SpPrimitiveArch(menu).hmenu == NULL) return;

    if (SpMenuPart(menu).popup_button == SP_LBUTTON) {
	uFlags = TPM_LEFTALIGN | TPM_LEFTBUTTON;
	popup_reason = SP_CR_LBUTTON_PRESS;
    } else {
	uFlags = TPM_LEFTALIGN | TPM_RIGHTBUTTON;
	popup_reason = SP_CR_RBUTTON_PRESS;
    }

    spDebug(10, "spPopupMenuWinCB", "WM_TASKTRAY = %d, message = %d\n",
	    WM_TASKTRAY, SpPrimitiveArch(component).message);
    
    if (spGetCallbackReason(component) == popup_reason) {
	if (spIsFrame(component) == SP_TRUE
	    && SpFramePart(component).task_tray_menu == menu) {
	    if (SpPrimitiveArch(component).message != WM_TASKTRAY) {
		return;
	    }

	    task_tray_flag = SP_TRUE;
	    
	    spGetCallbackMousePosition(component, &x, &y);
	    point.x = x; point.y = y;
	    
	    uFlags |= TPM_BOTTOMALIGN;
	    SetForegroundWindow(SpPrimitiveArch(component).hwnd);
	} else {
	    spGetCallbackMousePosition(component, &x, &y);
	    point.x = x; point.y = y;
	
	    ClientToScreen(SpPrimitiveArch(component).hwnd, (LPPOINT)&point);
	}
	
	/* draw and track popup menu. */ 
	TrackPopupMenu(SpPrimitiveArch(menu).hmenu, uFlags, 
		       point.x, point.y, 0, SpPrimitiveArch(component).hwnd, NULL);

	if (task_tray_flag == SP_TRUE) {
	    /* because of Windows BUG */
	    PostMessage(SpPrimitiveArch(component).hwnd, WM_NULL, 0, 0);
	}
    }
 
    return;
}

void spPopupMenuCreateArch(spComponent component)
{
    spPulldownMenuCreateArch(component);
    spAddCallback(SpGetParent(component), SP_BUTTON_PRESS_CALLBACK,
		  (spCallbackFunc)spPopupMenuWinCB, (void *)component);
    return;
}

void spPopupMenuSetParamsArch(spComponent component)
{
    spPulldownMenuSetParamsArch(component);
    return;
}

void spMenuBarCreateArch(spComponent component)
{
    if (spIsCreated(component) == SP_FALSE) {
	/* create menu bar */
	SpPrimitiveArch(component).hmenu = CreateMenu();
	SpPrimitiveArch(SpGetWindow(component)).hmenu = SpPrimitiveArch(component).hmenu;
    }

    return;
}

