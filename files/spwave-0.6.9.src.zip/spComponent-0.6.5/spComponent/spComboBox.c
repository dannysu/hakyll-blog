/*
 *	spComboBox.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spList.h>

#include <sp/spComboBoxP.h>

static spParamTable sp_combo_box_param_tables[] = {
    {SppListStrings, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spComboBox, combo_box.strings), NULL},
    {SppSelectedListIndex, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spComboBox, primitive.index), "-1"},
    {SppSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spComboBox, combo_box.size), "120"},
};

spComboBoxClassRec SpComboBoxClassRec = {
    /* spObjectClassPart */
    {
	SpComboBox,
	(spObjectClass)&SpTextClassRec,
	sizeof(spComboBoxRec),
	spArraySize(sp_combo_box_param_tables),
	sp_combo_box_param_tables,
	spComboBoxPartInit,
	spComboBoxPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spComboBoxCreate,
	NULL,
	spComboBoxSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spTextClassPart */
    {
	NULL,
	NULL,
    },
    /* spComboBoxClassPart */
    {
	0,
    },
};

spComponentClass SpComboBoxClass = (spComponentClass)&SpComboBoxClassRec;

void spComboBoxPartInit(spObject object)
{
    return;
}

void spComboBoxPartFree(spObject object)
{
    return;
}

void spComboBoxCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spDebug(60, "spComboBoxCreate", "in\n");
    
    spPrimitiveSetDefaultSize(component);
    spComboBoxCreateArch(component);
	
    spShowToolTip(component);
    
    if (SpComboBoxPart(component).strings != NULL) {
	int i;
	
	for (i = 0;; i++) {
	    if (SpComboBoxPart(component).strings[i] == NULL) {
		break;
	    }
	    
	    spAddListItem(component, SpComboBoxPart(component).strings[i]);
	}
	
	if (SpPrimitivePart(component).index >= 0) {
	    spSelectListIndex(component, SpPrimitivePart(component).index);
	}
    }
    
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
	spAddCallback(component, SP_ACTIVATE_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    
    if (!strnone(SpTextPart(component).string)) {
	spSetTextString(component, SpTextPart(component).string);
    }
    
    spDebug(60, "spComboBoxCreate", "done\n");
    
    return;
}

void spComboBoxSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spComboBoxSetParamsArch(component);
    
    if (!strnone(SpTextPart(component).string)
	&& SpTextPart(SpOldObject(component)).string != SpTextPart(component).string) {
	spSetTextString(component, SpTextPart(component).string);
    }
    
    return;
}

spBool spIsComboBox(spComponent component)
{
    return spIsSubClass(component, SpComboBox);
}

spComponent spCreateComboBox(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpComboBoxClass, NULL, name, parent, args, num_arg);
}
