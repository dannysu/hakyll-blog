/*
 *	spLocale_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocaleP.h>
#include <sp/spComponentP.h>

void spSetLanguageArch(char *lang, char *o_lang)
{
#ifdef SP_USE_LOCALE_MOTIFIERS
    if (strnone(lang)) {
	if (setlocale(LC_ALL, "") == NULL) {
	    XtWarning("locale not supported by C library, locale unchanged");
	}
	    
	if (XSupportsLocale() == False) {
	    XtWarning("locale not supported by Xlib, locale set to C");
	    setlocale(LC_ALL, "C");
	}
	if (XSetLocaleModifiers("") == NULL) {
	    XtWarning("X locale modifiers not supported, using default");
	}
    } else {
	if (setlocale(LC_ALL, lang) == NULL) {
	    XtWarning("locale not supported by C library, locale unchanged");
	}
	
	if (XSupportsLocale() == False) {
	    XtWarning("locale not supported by Xlib, locale set to C");
	    setlocale(LC_ALL, "C");
	}
	if (XSetLocaleModifiers("") == NULL) {
	    XtWarning("X locale modifiers not supported, using default");
	}
    }
#else
    setlocale(LC_ALL, "C");
#endif
    
    sscanf(setlocale(LC_ALL, NULL), "%s", o_lang);
    spDebug(10, NULL, "locale = %s\n", o_lang);
    
    if (strnone(o_lang) || spSupportLocale(o_lang) == SP_FALSE) {
	XtWarning("locale not supported, locale set to C");
	strcpy(o_lang, "C");
    }
    
    return;
}

#ifndef X_LOCALE
char *_Xsetlocale (int c, const char *l)
{
    switch (c) {
      case 0:
	return setlocale(LC_ALL, l);
      case 1:
	return setlocale(LC_COLLATE, l);
      case 2:
	return setlocale(LC_CTYPE, l);
      case 3:
	return setlocale(LC_MONETARY, l);
      case 4:
	return setlocale(LC_NUMERIC, l);
      case 5:
	return setlocale(LC_TIME, l);
      default:
	return setlocale(LC_ALL, l);
    }
}
#endif
