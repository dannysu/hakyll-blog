/*
 *	spDraw_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spPrimitiveP.h>
#include <sp/spCanvasP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

void spImageCreateArch(spComponent component)
{
    SpPrimitiveArch(component).hwnd = SpParentPrimitiveArch(component).hwnd;

    return;
}

spBool spIsDrawable(spComponent component)
{
    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).memdc != NULL) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spDrawImageArch(spComponent component)
{
#if 0
    PatBlt(SpPrimitiveArch(component).memdc, 0, 0,
	   SpComponentPart(component).client_width, SpComponentPart(component).client_height,
	   WHITENESS);
#else
    /* fill background */
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).bg_brush);
    Rectangle(SpPrimitiveArch(component).memdc, -1, -1,
	      SpComponentPart(component).client_width + 1,
	      SpComponentPart(component).client_height + 1);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_brush);
#endif
    
    return;
}

void spRedrawImageArch(spComponent component)
{
    /* delete DC */
    if (SpPrimitiveArch(component).memdc != NULL) {
	DeleteDC(SpPrimitiveArch(component).memdc);
	SpPrimitiveArch(component).memdc = NULL;
    }
    if (SpPrimitiveArch(component).hbitmap != NULL) {
	DeleteObject(SpPrimitiveArch(component).hbitmap);
	SpPrimitiveArch(component).hbitmap = NULL;
    }
    
    /* create memory image */
    SpPrimitiveArch(component).hdc = GetDC(SpPrimitiveArch(component).hwnd);
    SpPrimitiveArch(component).memdc = CreateCompatibleDC(SpPrimitiveArch(component).hdc);
    SpPrimitiveArch(component).hbitmap =
	CreateCompatibleBitmap(SpPrimitiveArch(component).hdc,
			       SpComponentPart(component).client_width,
			       SpComponentPart(component).client_height);
    SelectObject(SpPrimitiveArch(component).memdc, SpPrimitiveArch(component).hbitmap);
    
    /* release DC */
    ReleaseDC(SpPrimitiveArch(component).hwnd, SpPrimitiveArch(component).hdc);
    
    return;
}

void spCopyImageArch(spComponent src, spComponent dest,
		     int src_x, int src_y, int width, int height,
		     int dest_x, int dest_y)
{
    BitBlt(SpPrimitiveArch(dest).memdc, dest_x, dest_y,
	   MIN(SpComponentPart(src).client_width, width),
	   MIN(SpComponentPart(src).client_height, height),
	   SpPrimitiveArch(src).memdc, src_x, src_y, SRCCOPY);

    return;
}

static void drawRectangle(spComponent component, spGraphics graphics,
			  spGraphicsType type, int x, int y, int width, int height)
{
    int prev_mode;
    int ux, uy;
    
    if (spIsDrawable(component) == SP_FALSE) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    if (x <= 0) {
	ux = -1;
    } else {
	ux = x;
    }
    if (y <= 0) {
	uy = -1;
    } else {
	uy = y;
    }
    
    if (type == SP_GRAPHICS_BRUSH) {
	SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
	SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).brush);
    } else {
	SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_brush);
	SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    }
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    SetBkMode(SpPrimitiveArch(component).memdc, TRANSPARENT);
    Rectangle(SpPrimitiveArch(component).memdc, ux, uy, x + width + 1, y + height + 1);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_brush);
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);

    return;
}

void spFillRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    drawRectangle(component, graphics, SP_GRAPHICS_BRUSH, x, y, width, height);
    return;
}

void spDrawRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    drawRectangle(component, graphics, SP_GRAPHICS_PEN, x, y, width, height);
    return;
}

static void drawArc(spComponent component, spGraphics graphics, spGraphicsType type,
		    int x, int y, int width, int height, int angle1, int angle2)
{
    double c;
    double value;
    double t0, t1;
    double w2, h2;
    int sx, sy;
    int ex, ey;
    int prev_mode;
    
    if (spIsDrawable(component) == SP_FALSE) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    width += 1; height += 1;
    angle2 += 1;
    
    w2 = (double)width / 2.0;
    h2 = (double)height / 2.0;

    if (angle2 >= 360) {
	sx = x; sy = y + (int)spRound(h2);
	ex = sx; ey = sy;
    } else {
	c = PI / 180.0;
	t0 = h2 / w2;
    
	value = c * (double)angle1;
	t1 = tan(value);
    
	if (t1 >= t0) {
	    if (cos(value) >= 0.0) {
		sx = x + (int)spRound(w2 + h2 / t1);
		sy = y;
	    } else {
		sx = x + (int)spRound(w2 - h2 / t1);
		sy = y + height;
	    }
	} else {
	    if (cos(value) >= 0.0) {
		sx = x + width;
		sy = y + (int)spRound(h2 - w2 * t1);
	    } else {
		sx = x;
		sy = y + (int)spRound(h2 + w2 * t1);
	    }
	}
    
	value = c * (double)(angle1 + angle2);
	t1 = tan(value);
    
	if (t1 >= t0) {
	    if (cos(value) >= 0.0) {
		ex = x + (int)spRound(w2 + h2 / t1);
		ey = y;
	    } else {
		ex = x + (int)spRound(w2 - h2 / t1);
		ey = y + height;
	    }
	} else {
	    if (cos(value) >= 0.0) {
		ex = x + width;
		ey = y + (int)spRound(h2 - w2 * t1);
	    } else {
		ex = x;
		ey = y + (int)spRound(h2 + w2 * t1);
	    }
	}
    }

    spDebug(60, "drawArc", "sx = %d, sy = %d, ex = %d, ey = %d\n",
	    sx, sy, ex, ey);
    
    if (type == SP_GRAPHICS_BRUSH) {
	SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
	SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).brush);
    } else {
	SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_brush);
	SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    }
    SetBkMode(SpPrimitiveArch(component).memdc, TRANSPARENT);
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    if (type == SP_GRAPHICS_BRUSH) {
	Pie(SpPrimitiveArch(component).memdc, x, y, x + width, y + height, sx, sy, ex, ey);
    } else {
	Arc(SpPrimitiveArch(component).memdc, x, y, x + width, y + height, sx, sy, ex, ey);
    }
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_brush);
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);

    return;
}

void spFillArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    drawArc(component, graphics, SP_GRAPHICS_BRUSH,
	    x, y, width, height, angle1, angle2);
    return;
}

void spDrawArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    drawArc(component, graphics, SP_GRAPHICS_PEN,
	    x, y, width, height, angle1, angle2);
    return;
}

void spDrawLine(spComponent component, spGraphics graphics,
		int x1, int y1, int x2, int y2)
{
    int prev_mode;
    
    if (spIsDrawable(component) == SP_FALSE) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    SetBkMode(SpPrimitiveArch(component).memdc, TRANSPARENT);
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    MoveToEx(SpPrimitiveArch(component).memdc, x1, y1, NULL);
    LineTo(SpPrimitiveArch(component).memdc, x2, y2);
    SetPixel(SpPrimitiveArch(component).memdc, x2, y2, SpGraphicsPart(graphics).fg_pixel);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);
    
    return;
}

void spMoveTo(spComponent component, spGraphics graphics,
	      int x, int y)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    MoveToEx(SpPrimitiveArch(component).memdc, x, y, NULL);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    
    return;
}

void spLineTo(spComponent component, spGraphics graphics,
	      int x, int y)
{
    int prev_mode;
    
    if (spIsDrawable(component) == SP_FALSE) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    SetBkMode(SpPrimitiveArch(component).memdc, TRANSPARENT);
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    LineTo(SpPrimitiveArch(component).memdc, x, y);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);
    
    return;
}

void spDrawPoint(spComponent component, spGraphics graphics,
		 int x, int y)
{
    int prev_mode;
    
    if (spIsDrawable(component) == SP_FALSE) return;

    SelectObject(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).pen);
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    SetPixel(SpPrimitiveArch(component).memdc, x, y, SpGraphicsPart(graphics).fg_pixel);
    SelectObject(SpPrimitiveArch(component).memdc, SpTopLevelArch(sp_toplevel).null_pen);
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);
    
    return;
}

void spDrawString(spComponent component, spGraphics graphics,
		  int x, int y, char *string)
{
    int prev_mode;
    TEXTMETRIC text_metric;
    int text_ascent = 0;
    HFONT prev_font = NULL;
    
    if (spIsDrawable(component) == SP_FALSE || strnone(string)) return;

    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    if (SpGraphicsArch(graphics).font != NULL) {
	prev_font = SelectObject(SpPrimitiveArch(component).memdc,
				 SpGraphicsArch(graphics).font);
    }

    GetTextMetrics(SpPrimitiveArch(component).memdc, &text_metric);
    text_ascent = text_metric.tmAscent;
    
    SetTextColor(SpPrimitiveArch(component).memdc, SpGraphicsPart(graphics).fg_pixel);
    SetBkMode(SpPrimitiveArch(component).memdc, TRANSPARENT);
    prev_mode = SetROP2(SpPrimitiveArch(component).memdc, SpGraphicsArch(graphics).mode);
    TextOut(SpPrimitiveArch(component).memdc, x, y - text_ascent, string, strlen(string));
    SetROP2(SpPrimitiveArch(component).memdc, prev_mode);
    
    if (SpGraphicsArch(graphics).font != NULL) {
	SelectObject(SpPrimitiveArch(component).memdc, prev_font);
    }

    return;
}

spBool spGetStringExtent(spGraphics graphics, char *string,
			 int *x, int *y, int *width, int *height)
{
    HDC hdc;
    HFONT prev_font = NULL;
    SIZE size;
    spComponent component;
    TEXTMETRIC text_metric;

    if (strnone(string)) return SP_FALSE;
    
    if (graphics == NULL) graphics = SpTopLevelPart(sp_toplevel).graphics;

    component = spGetChild(NULL);
    while (component != NULL) {
	if (spIsPrimitive(component) == SP_TRUE
	    && SpPrimitiveArch(component).hwnd != NULL) {
	    hdc = GetDC(SpPrimitiveArch(component).hwnd);
	    
	    if (SpGraphicsArch(graphics).font != NULL) {
		prev_font = SelectObject(hdc, SpGraphicsArch(graphics).font);
	    }

	    GetTextExtentPoint32(hdc, string, strlen(string), &size);

	    if (x != NULL) *x = -1;
	    if (y != NULL) {
		GetTextMetrics(hdc, &text_metric);
		*y = -text_metric.tmAscent - 1;
	    }
	    if (width != NULL) *width = size.cx + 2;
	    if (height != NULL) *height = size.cy + 1;

	    if (SpGraphicsArch(graphics).font != NULL) {
		SelectObject(hdc, prev_font);
	    }
	    ReleaseDC(SpPrimitiveArch(component).hwnd, hdc);

	    return SP_TRUE;
	}
	component = SpGetNextComponent(component);
    }
    
    return SP_FALSE;
}
