/*
 *	spPrimitive.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spPrimitiveP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItemP.h>
#include <sp/spContainerP.h>
#include <sp/spFrameP.h>
#include <sp/spLabelP.h>
#include <sp/spButtonP.h>
#include <sp/spTextP.h>
#include <sp/spComboBoxP.h>
#include <sp/spListP.h>
#include <sp/spSliderP.h>
#include <sp/spDrawP.h>
#include <sp/spCanvasP.h>

spPrimitiveClassRec SpPrimitiveClassRec = {
    /* spObjectClassPart */
    {
	SpPrimitive,
	(spObjectClass)&SpComponentClassRec,
	sizeof(spPrimitiveRec),
	0,
	NULL,
	spPrimitivePartInit,
	spPrimitivePartFree,
	SP_FALSE,
	NULL,
	NULL,
	spPrimitiveCreate,
	spPrimitiveDestroy,
	spPrimitiveCreate,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	spPrimitiveMap,
	spPrimitiveUnmap,
	spPrimitiveSetSize,
	spPrimitiveGetSize,
	spPrimitiveGetClientSize,
	spPrimitiveSetSensitive,
	NULL,

	spPrimitiveAddCallback,
	spPrimitiveRemoveCallback,
	spPrimitiveCallbackFunc,
	spPrimitiveGetCallbackMousePosition,
	spPrimitiveGetCallbackKeySym,
	spPrimitiveGetCallbackKeyString,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
};

spComponentClass SpPrimitiveClass = (spComponentClass)&SpPrimitiveClassRec;

void spAllocCallbacks(spComponent component)
{
    long k;
    
    if (component == NULL ||
	SpPrimitivePart(component).num_callback < SpPrimitivePart(component).num_callback_buffer) return;

    if (SpPrimitivePart(component).callbacks == NULL) {
	SpPrimitivePart(component).num_callback_buffer = SP_CALLBACK_BUFFER;
	SpPrimitivePart(component).callbacks =
	    xalloc(SpPrimitivePart(component).num_callback_buffer, spCallback);
	SpPrimitivePart(component).num_callback = 0;
    } else {
	SpPrimitivePart(component).num_callback_buffer += SP_CALLBACK_BUFFER;
	SpPrimitivePart(component).callbacks =
	    xrealloc(SpPrimitivePart(component).callbacks,
		     SpPrimitivePart(component).num_callback_buffer, spCallback);
    }
    
    for (k = SpPrimitivePart(component).num_callback; k < SpPrimitivePart(component).num_callback_buffer; k++) {
	spInitCallbackArch(&SpPrimitivePart(component).callbacks[k]);
    }

    return;
}

void spFreeCallbacks(spComponent component)
{
    long k;
    
    if (SpPrimitivePart(component).callbacks != NULL) {
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    spInitCallbackArch(&SpPrimitivePart(component).callbacks[k]);
	}
	xfree(SpPrimitivePart(component).callbacks);
	SpPrimitivePart(component).callbacks = NULL;
    }

    return;
}

void spPrimitivePartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    spPrimitivePartInitArch(component);
    SpPrimitivePart(component).index = -1;
    SpPrimitivePart(component).draw_func = NULL;
    SpPrimitivePart(component).draw_data = NULL;
    SpPrimitivePart(component).num_callback = 0;
    SpPrimitivePart(component).num_callback_buffer = 0;
    SpPrimitivePart(component).callbacks = NULL;
    
    spDebug(60, "spPrimitivePartInit", "init done\n");

    return;
}

void spPrimitivePartFree(spObject object)
{
    spComponent component = (spComponent)object;

    spFreeCallbacks(component);
    
    return;
}

void spPrimitiveCreate(spObject object)
{
    spComponent component = (spComponent)object;
	
    if (component == NULL) return;

    if (spIsSubClass(component, SpMenuBar) == SP_TRUE) {
	spMenuBarCreate(component);
    } else if (spIsSubClass(component, SpMenuSeparator) == SP_TRUE) {
	spMenuSeparatorCreate(component);
    } else if (spIsSubClass(component, SpImage) == SP_TRUE) {
	spPrimitiveSetDefaultSize(component);
	spImageCreate(component);
    }

    return;
}

void spPrimitiveDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;
    
    spPrimitiveDestroyArch(component);
    
    return;
}

void spPrimitiveMap(spComponent component)
{
    if (component == NULL) return;

    if (spIsWindow(component) == SP_TRUE) {
	spMapWindow(component);
    } else {
	spPrimitiveMapArch(component);
    }

    return;
}

void spPrimitiveUnmap(spComponent component)
{
    if (component == NULL) return;

    if (spIsWindow(component) == SP_TRUE) {
	spUnmapWindow(component);
    } else {
	spPrimitiveUnmapArch(component);
    }

    return;
}

spBool spPrimitiveSetSize(spComponent component, int width, int height)
{
    if (spIsCreated(component) == SP_TRUE) {
	return spPrimitiveSetSizeArch(component, width, height);
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetSize(spComponent component, int *width, int *height)
{
    if (spIsCreated(component) == SP_TRUE) {
	return spPrimitiveGetSizeArch(component, width, height);
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetClientSize(spComponent component, int *width, int *height)
{
    if (spIsCreated(component) == SP_TRUE) {
	return spPrimitiveGetClientSizeArch(component, width, height);
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveSetSensitive(spComponent component, spBool flag)
{
    if (component == NULL) return SP_FALSE;
    
    return spPrimitiveSetSensitiveArch(component, flag);
}

spBool spPrimitiveAddCallback(spComponent component, spBool propagate, spCallbackType call_type,
			      spCallbackFunc call_func, void *call_data)
{
    if (call_func != NULL && call_type != SP_NO_CALLBACK) {
	return spPrimitiveAddCallbackArch(component, propagate, call_type, call_func, call_data);
    }

    return SP_FALSE;
}

spBool spPrimitiveRemoveCallback(spComponent component, spCallbackType call_type,
				 spCallbackFunc call_func, void *call_data)
{
    if (call_func != NULL && call_type != SP_NO_CALLBACK) {
	return spPrimitiveRemoveCallbackArch(component, call_type, call_func, call_data);
    }

    return SP_FALSE;
}

spCallbackReason spPrimitiveCallbackFunc(spComponent component)
{
    spCallbackReason call_reason = SP_CR_UNKNOWN;

    call_reason = spPrimitiveGetCallbackReasonArch(component);

    if (call_reason == SP_CR_ACTIVATE) {
	if (streq(SpGetName(component), "_OkButton")) {
	    call_reason = SP_CR_OK;
	} else if (streq(SpGetName(component), "_CancelButton")) {
	    call_reason = SP_CR_CANCEL;
	} else if (streq(SpGetName(component), "_ApplyButton")) {
	    call_reason = SP_CR_APPLY;
	} else if (streq(SpGetName(component), "_HelpButton")) {
	    call_reason = SP_CR_HELP;
	} else if (streq(SpGetName(component), "_YesButton")) {
	    call_reason = SP_CR_YES;
	} else if (streq(SpGetName(component), "_NoButton")) {
	    call_reason = SP_CR_NO;
	} else if (streq(SpGetName(component), "_RetryButton")) {
	    call_reason = SP_CR_RETRY;
	}
    }
    
    return call_reason;
}

spBool spPrimitiveGetCallbackMousePosition(spComponent component, int *x, int *y)
{
    if ((x != NULL || y != NULL)) {
	return spPrimitiveGetCallbackMousePositionArch(component, x, y);
    }
    
    return SP_FALSE;
}

spBool spPrimitiveGetCallbackKeySym(spComponent component, spKeySym *key_sym)
{
    return spPrimitiveGetCallbackKeySymArch(component, key_sym);
}

int spPrimitiveGetCallbackKeyString(spComponent component,
				    char *buf, int buf_size, spBool *overflow)
{
    return spPrimitiveGetCallbackKeyStringArch(component, buf, buf_size, overflow);
}

void spPrimitiveSetDefaultSize(spComponent component)
{
    int default_width = 0;
    int default_height = 0;
    
    if (component == NULL
	|| spIsCreated(component) == SP_TRUE) return;

    spDebug(60, "spPrimitiveSetDefaultSize", "in\n");

    if (spIsSubClass(component, SpText) == SP_TRUE) {
	if (spIsSubClass((spComponent)component, SpTextArea)) {
	    default_width = SP_DEFAULT_TEXT_AREA_WIDTH;
	    default_height = SP_DEFAULT_TEXT_AREA_HEIGHT;
	} else {
	    default_width = SP_DEFAULT_TEXT_WIDTH;
	    default_height = SP_DEFAULT_TEXT_HEIGHT;
	}
    } else if (spIsSubClass((spComponent)component, SpList) == SP_TRUE) {
	default_width = SP_DEFAULT_LIST_WIDTH;
	default_height = SP_DEFAULT_LIST_HEIGHT;
    } else if (spIsSubClass((spComponent)component, SpButton) == SP_TRUE) {
	default_width = SP_DEFAULT_BUTTON_WIDTH;
	default_height = SP_DEFAULT_BUTTON_HEIGHT;
    } else if (spIsSubClass((spComponent)component, SpLabel) == SP_TRUE) {
	default_width = SP_DEFAULT_LABEL_WIDTH;
	default_height = SP_DEFAULT_LABEL_HEIGHT;
    } else {
	return;
    }
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (SpComponentPart(component).width == 0
	&& SpParentComponentPart(component).orientation == SP_HORIZONTAL) {
	SpComponentPart(component).width = default_width;
    }
    if (SpComponentPart(component).require_width <= 0) {
	SpComponentPart(component).require_width
	    = MAX(SpComponentPart(component).width, default_width);
    }
    if (SpComponentPart(component).height == 0
	&& SpParentComponentPart(component).orientation == SP_VERTICAL) {
	SpComponentPart(component).height = default_height;
    }
    if (SpComponentPart(component).require_height <= 0) {
	SpComponentPart(component).require_height
	    = MAX(SpComponentPart(component).height, default_height);
    }
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;
    
    return;
}

spBool spIsPrimitive(spComponent component)
{
    return spIsSubClass(component, SpPrimitive);
}

spBool spShowToolTip(spComponent component)
{
    if (spIsPrimitive(component) == SP_FALSE
	|| strnone(SpComponentPart(component).description)) return SP_FALSE;
    
    return spShowToolTipArch(component);
}
