/*
 *	spSlider_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spSliderP.h>

static void setUpdatePolicy(spComponent component)
{
    if (SpSliderPart(component).track_call_on == SP_FALSE) {
	gtk_range_set_update_policy(GTK_RANGE(SpPrimitiveArch(component).widget),
				    GTK_UPDATE_DISCONTINUOUS);
    } else {
	gtk_range_set_update_policy(GTK_RANGE(SpPrimitiveArch(component).widget),
				    GTK_UPDATE_CONTINUOUS);
    }

    return;
}

void spSliderCreateArch(spComponent component)
{
    SpPrimitiveArch(component).adjustment =
	gtk_adjustment_new ((gfloat)SpSliderPart(component).value,
			    (gfloat)SpSliderPart(component).minimum,
			    (gfloat)(SpSliderPart(component).maximum),
			    (gfloat)SpSliderPart(component).increment,
			    (gfloat)SpSliderPart(component).page_increment,
			    (gfloat)SpSliderPart(component).page_size);
    
    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	SpPrimitiveArch(component).widget =
	    gtk_hscrollbar_new(GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment));
    } else {
	SpPrimitiveArch(component).widget =
	    gtk_vscrollbar_new(GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment));
    }
    
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);

    setUpdatePolicy(component);

    return;
}

void spTrackBarCreateArch(spComponent component)
{
    SpPrimitiveArch(component).adjustment =
	gtk_adjustment_new ((gfloat)SpSliderPart(component).value,
			    (gfloat)SpSliderPart(component).minimum,
			    (gfloat)(SpSliderPart(component).maximum + 1),
			    (gfloat)SpSliderPart(component).increment,
			    (gfloat)SpSliderPart(component).page_increment,
			    1.0);
    
    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	SpPrimitiveArch(component).widget =
	    gtk_hscale_new(GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment));
	gtk_scale_set_value_pos (GTK_SCALE(SpPrimitiveArch(component).widget), GTK_POS_TOP);
    } else {
	SpPrimitiveArch(component).widget =
	    gtk_vscale_new(GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment));
	gtk_scale_set_value_pos (GTK_SCALE(SpPrimitiveArch(component).widget), GTK_POS_LEFT);
    }
	
    if (SpSliderPart(component).show_value == SP_TRUE) {
	gtk_scale_set_draw_value (GTK_SCALE(SpPrimitiveArch(component).widget), TRUE);
    } else {
	gtk_scale_set_draw_value (GTK_SCALE(SpPrimitiveArch(component).widget), FALSE);
    }
    gtk_scale_set_digits(GTK_SCALE(SpPrimitiveArch(component).widget),
			 (gint)SpSliderPart(component).decimal_points);
    
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);

    setUpdatePolicy(component);
    
    return;
}

void spSliderSetParamsArch(spComponent component)
{
    GtkAdjustment *adjustment;

    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	if (SpSliderPart(component).show_value == SP_TRUE) {
	    gtk_scale_set_draw_value(GTK_SCALE(SpPrimitiveArch(component).widget), TRUE);
	}
	gtk_scale_set_digits(GTK_SCALE(SpPrimitiveArch(component).widget),
			     (gint)SpSliderPart(component).decimal_points);
    }

    setUpdatePolicy(component);
    
    adjustment = GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment);

    adjustment->lower = (gfloat)SpSliderPart(component).minimum;
    adjustment->upper = (gfloat)(SpSliderPart(component).maximum + 1);
    adjustment->value = (gfloat)SpSliderPart(component).value;
    adjustment->step_increment = (gfloat)SpSliderPart(component).increment;
    adjustment->page_increment = (gfloat)SpSliderPart(component).page_increment;
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	adjustment->page_size = 1.0;
    } else {
	adjustment->page_size = (gfloat)SpSliderPart(component).page_size;
    }
    
    gtk_signal_emit_by_name(GTK_OBJECT(SpPrimitiveArch(component).adjustment), "changed");
    
    return;
}

void spTrackBarSetParamsArch(spComponent component)
{
    spSliderSetParamsArch(component);
    return;
}

void spSetSliderValueArch(spComponent component)
{
    gtk_adjustment_set_value(GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment),
			     (gfloat)SpSliderPart(component).value);
    return;
}

int spGetSliderValueArch(spComponent component)
{
    return (int)GTK_ADJUSTMENT(SpPrimitiveArch(component).adjustment)->value;
}
