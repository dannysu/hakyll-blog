/*
 *	spComboBox_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spListP.h>
#include <sp/spComboBoxP.h>

extern spTopLevel sp_toplevel;

void spComboBoxCreateArch(spComponent component)
{
    /* create combo box */
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(WS_EX_CLIENTEDGE, "COMBOBOX", NULL,
		       (SpTextPart(component).editable == SP_FALSE ?
			CBS_DROPDOWNLIST : CBS_DROPDOWN)
		       | WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_TABSTOP
		       | WS_VSCROLL | CBS_AUTOHSCROLL | CBS_DISABLENOSCROLL
		       | CBS_NOINTEGRALHEIGHT,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComboBoxPart(component).size,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));
    
    return;
}

void spComboBoxSetParamsArch(spComponent component)
{
    return;
}
