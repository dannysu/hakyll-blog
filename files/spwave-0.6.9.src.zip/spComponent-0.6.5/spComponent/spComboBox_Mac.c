/*
 *	spComboBox_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spListP.h>
#include <sp/spComboBoxP.h>

spBool spUseBevelButtonForComboButtonMac(void)
{
    /* Bevel button doesn't work on Mac OS X if you use pthread-based threads. */
    if (0 && spIsAquaMac() == SP_FALSE && spGetAppearanceVersionMac() >= 0x00000101) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spGetComboBoxButtonDrawRectMac(spComponent text, Rect text_rect, Rect *rect)
{
    rect->left = text_rect.right + SP_COMBO_BOX_SPACING;
    rect->right = rect->left + SP_COMBO_BOX_BUTTON_SIZE;
    rect->top = text_rect.top;
    rect->bottom = text_rect.bottom;

    return;
}

void spGetComboBoxButtonRectMac(spComponent component, Rect *prect)
{
    Rect rect;

    if (SpPrimitiveArch(component).control != NULL) {
	rect = SpPrimitiveArch(component).rect;
	rect.right -= (SP_COMBO_BOX_SPACING + SP_COMBO_BOX_BUTTON_SIZE);
    } else {
	rect = (*SpTextArch(component).text)->viewRect;
	InsetRect(&rect, -SP_TEXT_MARGIN, -SP_TEXT_MARGIN);
    }

    prect->left = rect.right + SP_COMBO_BOX_SPACING;
    prect->right = prect->left + SP_COMBO_BOX_BUTTON_SIZE;
    prect->top = rect.top;
    prect->bottom = rect.bottom;

    return;
}

void spDrawComboBoxMac(spComponent component)
{
    int x, y;
    int width, height;
    int yoffset;
    Rect rect;
    PolyHandle hpoly;
    spBool sensitive_flag = SP_TRUE;

    if (spUseBevelButtonForComboButtonMac() == SP_TRUE && SpComboBoxArch(component).button != NULL) {
	return;
    }

    spGetComboBoxButtonRectMac(component, &rect);

    if (SpComboBoxArch(component).button == NULL) {
	FrameRect(&rect);
    }

    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	sensitive_flag = SP_FALSE;
	spGetOriginalRGBMac();
	spSetDeactivateRGBMac();
    }
    
    x = rect.left;
    y = rect.top;
    width = spGetRectWidthMac(rect);
    height = spGetRectHeightMac(rect);
    yoffset = 2;

    hpoly = OpenPoly();
    MoveTo(x + width / 4, y + height / 4 + yoffset);
    LineTo(x + width / 2, y + 3 * height / 4);
    LineTo(x + 3 * width / 4, y + height / 4 + yoffset);
    LineTo(x + width / 4, y + height / 4 + yoffset);
    ClosePoly();

    PaintPoly(hpoly);
    KillPoly(hpoly);
    
    spValidRectMac(SpPrimitiveArch(SpGetWindow(component)).window, &rect);

    if (sensitive_flag == SP_FALSE) {
	spSetOriginalRGBMac();
    }
    
    return;
}

void spShowComboBoxMenuMac(spComponent text, Rect text_rect, Rect button_rect)
{
    Point popup_point;
    GrafPtr save_port;
    GrafPtr old_port;
    long message;
    
    if (CountMenuItems(SpPrimitiveArch(text).menu) >= 1) {
	popup_point.v = text_rect.bottom + 1;
#if 0
	popup_point.h = text_rect.left;
#else
	popup_point.h = button_rect.left;
#endif

	spDebug(50, "spShowComboBoxMenuMac", "x = %d, y = %d\n", popup_point.h, popup_point.v);
		
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	LocalToGlobal(&popup_point);
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	
	InsertMenu(SpPrimitiveArch(text).menu, -1);

	if (SpComboBoxArch(text).button != NULL) {
	    HiliteControl(SpComboBoxArch(text).button, kControlButtonPart);
	    
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    spDrawComboBoxMac(text);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	} else {
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    InvertRect(&button_rect);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	}
	
	/*old_port = spThreadLeaveMac(nil);*/
	message = PopUpMenuSelect(SpPrimitiveArch(text).menu,
				  popup_point.v, popup_point.h,
				  SpPrimitivePart(text).index + 1);
	/*spThreadEnterMac(old_port);*/
		
	spDebug(50, "spShowComboBoxMenuMac", "message = %ld\n", message);
	
	if (SpComboBoxArch(text).button != NULL) {
	    HiliteControl(SpComboBoxArch(text).button, 0);
	    
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    spDrawComboBoxMac(text);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	} else {
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, &save_port);
	    InvertRect(&button_rect);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(text)).window, save_port);
	}
		
	if (message) {
	    spSelectListIndexArch(text, (int)LoWord(message) - 1);
	    spPostMessageMac(text, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
	}
		
	DeleteMenu(SpPrimitiveArch(text).menu_id);
    }
    
    spDebug(80, "spShowComboBoxMenuMac", "done\n");
    
    return;
}

spBool spHandleComboBoxMouseDownMac(spComponent text, Point mouse_point, Rect text_rect)
{
    Rect button_rect;

    if (spIsComboBox(text) == SP_TRUE) {
	if (spUseBevelButtonForComboButtonMac() == SP_TRUE
	    && SpComboBoxArch(text).button != NULL) {
	    SInt16 index = -1;
	    Size realSize;
	    ControlPartCode part;
	    
	    part = TrackControl(SpComboBoxArch(text).button, mouse_point, (ControlActionUPP)-1);

	    switch (part) {
	      case kControlMenuPart:
		if (GetControlData(SpComboBoxArch(text).button, 0, kControlBevelButtonMenuValueTag,
				   sizeof(SInt16), (Ptr)&index, &realSize) == noErr
		    && index >= 1) {
		    spDebug(50, "spHandleComboBoxMouseDownMac", "index = %d\n", index);
		    
		    spSelectListIndexArch(text, index - 1);
		    spPostMessageMac(text, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
		    return SP_TRUE;
		}
		break;
		
	      default:
		break;
	    }
	} else {
	    spGetComboBoxButtonDrawRectMac(text, text_rect, &button_rect);
	
	    if (PtInRect(mouse_point, &button_rect)) {
		spShowComboBoxMenuMac(text, text_rect, button_rect);
		return SP_TRUE;
	    }
	}
    }

    return SP_FALSE;
}

void spComboBoxCreateArch(spComponent component)
{
    Rect rect;

    spTextCreateArch(component);

    SpPrimitiveArch(component).menu_id = spUseCurrentMenuIdMac();
    SpPrimitiveArch(component).menu =
	NewMenu(SpPrimitiveArch(component).menu_id, "\p");

    spGetComboBoxButtonRectMac(component, &rect);
    if (spUseBevelButtonForComboButtonMac() == SP_TRUE) {
	SpComboBoxArch(component).button =
	    NewControl(SpPrimitiveArch(SpGetWindow(component)).window,
		       &rect, "\p", spIsVisibleMac(component), 0, kControlContentTextOnly, 0,
		       /*kControlBevelButtonSmallBevelProc*/kControlBevelButtonNormalBevelProc
		       + kControlBevelButtonMenuOnBottom, 0);
	
	SetControlData(SpComboBoxArch(component).button,
		       kControlEntireControl, kControlBevelButtonMenuHandleTag,
		       sizeof(MenuHandle), (Ptr)&SpPrimitiveArch(component).menu);
	{
	    Boolean flag = true;
	    SetControlData(SpComboBoxArch(component).button,
			   kControlEntireControl, kControlBevelButtonCenterPopupGlyphTag,
			   sizeof(Boolean), (Ptr)&flag);
	}
    } else {
	SpComboBoxArch(component).button =
	    NewControl(SpPrimitiveArch(SpGetWindow(component)).window,
		       &rect, "\p", spIsVisibleMac(component), 0, 0, 1, pushButProc, 0);
    }

    if (SpPrimitiveArch(component).control == NULL) {
	spSetNeedUpdateMac(component);
    }

#if TARGET_API_MAC_CARBON
    if (spIsCarbonEventAvailableMac() == SP_TRUE
	&& SpPrimitiveArch(component).eventHandler != NULL) {
	EventHandlerRef ehref;
	EventTypeSpec list_combo[] = {
	    { kEventClassControl, kEventControlHit },
	    { kEventClassControl, kEventControlDraw },
	    { kEventClassControl, kEventControlClick },
	    { kEventClassControl, kEventControlTrack },
	    { kEventClassControl, kEventControlActivate },
	    { kEventClassControl, kEventControlDeactivate },
	};
	
	InstallEventHandler(GetControlEventTarget(SpComboBoxArch(component).button),
			    SpPrimitiveArch(component).eventHandler,
			    spArraySize(list_combo), list_combo, (void *)component,
			    &ehref);
    }
#endif
    
    spDebug(50, "spComboBoxCreateArch", "menu = %ld\n",
	    SpPrimitiveArch(component).menu);
    
    return;
}

void spComboBoxSetParamsArch(spComponent component)
{
    spTextSetParamsArch(component);
    return;
}
