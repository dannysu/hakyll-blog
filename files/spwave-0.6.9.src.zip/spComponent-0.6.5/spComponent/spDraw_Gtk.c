/*
 *	spDraw_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>

extern spTopLevel sp_toplevel;

void spImageCreateArch(spComponent component)
{
    return;
}

spBool spIsDrawable(spComponent component)
{
    if (spIsPrimitive(component) == SP_TRUE
	&& SpPrimitiveArch(component).pixmap != NULL) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spDrawImageArch(spComponent component)
{
    spDebug(80, "spDrawImageArch", "in\n");
    
#if GTK_CHECK_VERSION(1,2,0)
    if (SpPrimitiveArch(component).widget != NULL) {
#if 1
	gtk_style_apply_default_background(SpPrimitiveArch(component).widget->style,
					   SpPrimitiveArch(component).pixmap,
					   FALSE,
					   GTK_WIDGET_STATE(SpPrimitiveArch(component).widget),
					   NULL, 0, 0,
					   -1, -1);
#else
	/* I gave up the following because frickering may happen. */
	
	/* FIXME: I don't know how to draw theme background in a pixmap */
	/* so, copying the background of a window to the pixmap */
	gdk_window_clear(SpPrimitiveArch(component).widget->window);
	gdk_window_copy_area(SpPrimitiveArch(component).pixmap,
			     SpTopLevelArch(sp_toplevel).fg_gc,
			     0, 0,
			     SpPrimitiveArch(component).widget->window,
			     0, 0,
			     SpComponentPart(component).client_width,
			     SpComponentPart(component).client_height);
#endif
    }
#else
    gdk_draw_rectangle(SpPrimitiveArch(component).pixmap,
		       SpTopLevelArch(sp_toplevel).bg_gc,
		       TRUE,
		       0, 0,
		       SpComponentPart(component).client_width,
		       SpComponentPart(component).client_height);
#endif
    
    return;
}

void spRedrawImageArch(spComponent component)
{
    spDebug(30, "spRedrawImageArch", "width = %d, height = %d\n", 
	    SpComponentPart(component).client_width, 
	    SpComponentPart(component).client_height);

    if (SpPrimitiveArch(component).pixmap != NULL) {
	gdk_pixmap_unref(SpPrimitiveArch(component).pixmap);
	SpPrimitiveArch(component).pixmap = NULL;
    }

    /* create pixmap */
    if ((SpPrimitiveArch(component).pixmap =
	 gdk_pixmap_new(NULL,
			SpComponentPart(component).client_width,
			SpComponentPart(component).client_height,
			gdk_visual_get_best_depth())) == NULL) {
	spError(1, "can't create pixmap\n");
    }
    
    return;
}

void spCopyImageArch(spComponent src, spComponent dest,
		     int src_x, int src_y, int width, int height,
		     int dest_x, int dest_y)
{
    gdk_draw_pixmap(SpPrimitiveArch(dest).pixmap,
		    SpTopLevelArch(sp_toplevel).fg_gc,
		    SpPrimitiveArch(src).pixmap,
		    src_x, src_y,
		    dest_x, dest_y,
		    MIN(SpComponentPart(src).client_width, width),
		    MIN(SpComponentPart(src).client_height, height));

    return;
}

void spFillRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_rectangle(SpPrimitiveArch(component).pixmap,
		       (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
			SpGraphicsArch(graphics).gc), TRUE, 
		       x, y, width, height);

    return;
}

void spDrawRectangle(spComponent component, spGraphics graphics,
		     int x, int y, int width, int height)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_rectangle(SpPrimitiveArch(component).pixmap,
		       (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
			SpGraphicsArch(graphics).gc), FALSE, 
		       x, y, width, height);

    return;
}

void spFillArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_arc(SpPrimitiveArch(component).pixmap,
		 (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		  SpGraphicsArch(graphics).gc), TRUE, 
		 x, y, width, height, angle1 * 64, angle2 * 64);

    return;
}

void spDrawArc(spComponent component, spGraphics graphics,
	       int x, int y, int width, int height, int angle1, int angle2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_arc(SpPrimitiveArch(component).pixmap,
		 (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		  SpGraphicsArch(graphics).gc), FALSE, 
		 x, y, width, height, angle1 * 64, angle2 * 64);

    return;
}

void spDrawLine(spComponent component, spGraphics graphics,
		int x1, int y1, int x2, int y2)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_line(SpPrimitiveArch(component).pixmap,
		  (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		   SpGraphicsArch(graphics).gc),
		  x1, y1, x2, y2);
    gdk_draw_point(SpPrimitiveArch(component).pixmap,
		   (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		    SpGraphicsArch(graphics).gc),
		   x2, y2);

    return;
}

void spDrawPoint(spComponent component, spGraphics graphics,
		 int x, int y)
{
    if (spIsDrawable(component) == SP_FALSE) return;

    gdk_draw_point(SpPrimitiveArch(component).pixmap,
		   (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		    SpGraphicsArch(graphics).gc),
		   x, y);
    
    return;
}

void spDrawString(spComponent component, spGraphics graphics,
		  int x, int y, char *string)
{
    if (spIsDrawable(component) == SP_FALSE || strnone(string)) return;

    gdk_draw_string(SpPrimitiveArch(component).pixmap,
		    (graphics == NULL ? SpTopLevelArch(sp_toplevel).font :
		     SpGraphicsArch(graphics).font),
		    (graphics == NULL ? SpTopLevelArch(sp_toplevel).fg_gc :
		     SpGraphicsArch(graphics).gc),
		    x, y, string);
    
    return;
}

spBool spGetStringExtent(spGraphics graphics, char *string,
			 int *x, int *y, int *width, int *height)
{
    GdkFont *font;

    font = (graphics == NULL ? SpTopLevelArch(sp_toplevel).font :
	    SpGraphicsArch(graphics).font);
    
    if (strnone(string)) return SP_FALSE;
    
    if (x != NULL) *x = -1;
    if (y != NULL) {
	*y = -font->ascent - 1;
    }
    if (width != NULL) {
	gint w;
	w = gdk_string_width(font, string);
	*width = w + 2;
    }
    if (height != NULL) {
	*height = font->ascent + font->descent + 1;
    }

    return SP_TRUE;
}
