/*
 *	spContainer_Win.c
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTabBox.h>

#include <sp/spContainerP.h>

extern spTopLevel sp_toplevel;

static void drawContainer(spComponent container, HDC hdc, spBool null_flag)
{
    char *title;
    RECT rect;
    HGDIOBJ prev_obj;
    HFONT prev_font;
    HPEN prev_pen;
    HBRUSH brush;
    COLORREF bg_color;
    HDC hwdc;

    if (spIsVisible(container) == SP_FALSE
	|| SpPrimitiveArch(SpGetWindow(container)).realize_flag == SP_FALSE) return;
    
    bg_color = GetSysColor(COLOR_BTNFACE);
    brush = GetSysColorBrush(COLOR_BTNFACE);

    prev_obj = SelectObject(hdc, brush);
    prev_pen = SelectObject(hdc, SpTopLevelArch(sp_toplevel).null_pen);

    GetClientRect(SpPrimitiveArch(container).hwnd, &rect);
	
    /* draw container edge */
    if (null_flag == SP_TRUE) {
	FillRect(hdc, &rect, brush);
    } else {
	if (SpContainerPart(container).title_on == SP_TRUE) {
	    rect.top = SP_CONTAINER_TITLE_TOP_OFFSET;
	    DrawEdge(hdc, &rect, EDGE_ETCHED, BF_RECT);
	    
	    /* draw title */
	    title = spGetTitle(container);
	    if (!strnone(title)) {
		prev_font = SelectObject(hdc, GetStockObject(DEFAULT_GUI_FONT));
		SelectObject(hdc, GetStockObject(BLACK_PEN));
		SetBkColor(hdc, bg_color);
		TextOut(hdc, SP_CONTAINER_TITLE_LEFT_OFFSET, 2,
			title, strlen(title));
		SelectObject(hdc, prev_font);
	    }
	}
    }

    SelectObject(hdc, prev_pen);
    SelectObject(hdc, prev_obj);

    return;
}

void spDrawContainerWin(spComponent component, spBool null_flag)
{
    HDC hdc;
    
    hdc = GetDC(SpPrimitiveArch(component).hwnd);
    drawContainer(component, hdc, null_flag);
    ReleaseDC(SpPrimitiveArch(component).hwnd, hdc);
    
    spDebug(80, "spDrawContainer", "done\n");

    return;
}

static void drawContainerCB(spComponent component, void *data)
{
    PAINTSTRUCT paintstruct;
    spComponent container = (spComponent)data;
    
    if (SpPrimitiveArch(component).message == WM_PAINT) {
	SpPrimitiveArch(component).hdc = BeginPaint(SpPrimitiveArch(component).hwnd, &paintstruct);

	drawContainer(container, SpPrimitiveArch(component).hdc, SP_FALSE);
	
	EndPaint(SpPrimitiveArch(component).hwnd, &paintstruct);
    }

    return;
}

void spContainerCreateArch(spComponent component)
{
    DWORD dwStyle = 0;
    DWORD dwExStyle = WS_EX_CONTROLPARENT;
    HWND hparent;
    
    if (SpContainerPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).border_width = 2;
    }

    dwStyle |= WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_GROUP;
    if (spIsVisible(component) == SP_TRUE) {
	dwStyle |= WS_VISIBLE;
    }
    if (spIsTabBox(SpGetParent(component)) == SP_TRUE) {
	hparent = SpParentPrimitiveArch(SpGetParent(component)).hwnd;
    } else {
	hparent = SpParentPrimitiveArch(component).hwnd;
    }

    if (SpContainerPart(component).title_on == SP_TRUE) {
    } else if (SpContainerPart(component).border_on == SP_TRUE) {
	dwExStyle |= WS_EX_CLIENTEDGE;
    }
    
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(dwExStyle,
		       SP_WINDOW_CLASS_NAME,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       dwStyle,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComponentPart(component).current_height,
		       hparent,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    
    if (spIsTabBox(SpGetParent(component)) == SP_TRUE) {
	SetWindowPos(SpParentPrimitiveArch(component).hwnd,
		     SpPrimitiveArch(component).hwnd,
		     0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }

    if (SpContainerPart(component).title_on == SP_TRUE) {
	SpComponentPart(component).border_width = 2;
	SpComponentPart(component).top_offset += 2 * SP_CONTAINER_TITLE_TOP_OFFSET;
	SpContainerPart(component).title_offset = 2 * SP_CONTAINER_TITLE_TOP_OFFSET;
    }
    
    spAddCallback(component, SP_EXPOSE_CALLBACK, drawContainerCB, component);
    
    return;
}

void spContainerSetParamsArch(spComponent component)
{
    return;
}
