/*
 *	spMenuItem_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spPrimitiveP.h>
#include <sp/spFrameP.h>
#include <sp/spMenuP.h>
#include <sp/spMenuItemP.h>

spBool spIsNeedlessMenuItemMac(spComponent component)
{
    if (spIsAquaMac() == SP_TRUE
	&& (strcaseeq(SpGetName(component), SP_QUIT_MENU_ITEM_NAME)
	    || strcaseeq(SpGetName(component), SP_QUIT_MENU_SEPARATOR_NAME))) {
	return SP_TRUE;
    }

    return SP_FALSE;
}

void spMapMenuItemMac(spComponent component)
{
    Str255 pstr;
    spComponent next;

    if (SpPrimitiveArch(component).map_flag == SP_TRUE
	|| spIsNeedlessMenuItemMac(component) == SP_TRUE) {
	return;
    }

    if (spIsMenuSeparator(component) == SP_TRUE) {
	InsertMenuItem(SpParentPrimitiveArch(component).menu, "\p(-",
		       SpPrimitiveArch(component).menu_id);
    } else {
	if (spIsSubMenu(component) == SP_TRUE) {
	    spGetMenuLabelMac(component, pstr);
	    spAddSubMenuMac(component, pstr);
	} else {
	    spGetMenuLabelMac(component, pstr);
	    InsertMenuItem(SpParentPrimitiveArch(component).menu, "\p ",
			   SpPrimitiveArch(component).menu_id);

	    /* prevent from disable of menu including '(' */
	    spSetMenuItemTextMac(SpParentPrimitiveArch(component).menu,
				 SpPrimitiveArch(component).menu_id, pstr);

	    if (spIsRadioButtonMenuItem(component) == SP_TRUE) {
		SetItemMark(SpParentPrimitiveArch(component).menu, SpPrimitiveArch(component).menu_id, '\013');
		spDebug(20, "spMapMenuItemMac", "set item mark to diamond\n");
	    }
	}
    }
    SpPrimitiveArch(component).map_flag = SP_TRUE;
    
    next = spGetNextComponent(component);
    while (next != NULL) {
	if (spIsMenuItem(next) == SP_TRUE) {
	    ++SpPrimitiveArch(next).menu_id;
	}
	next = spGetNextComponent(next);
    }
    
    return;
}

void spUnmapMenuItemMac(spComponent component)
{
    spComponent next;

    if (SpPrimitiveArch(component).map_flag == SP_FALSE
	|| spIsNeedlessMenuItemMac(component) == SP_TRUE) {
	return;
    }

    if (spIsSubMenu(component) == SP_TRUE) {
	DeleteMenuItem(SpParentPrimitiveArch(component).menu,
		       spGetMenuItemIdMac(component));
    } else {
	DeleteMenuItem(SpParentPrimitiveArch(component).menu,
		       SpPrimitiveArch(component).menu_id);
    }
    SpPrimitiveArch(component).map_flag = SP_FALSE;
    
    next = spGetNextComponent(component);
    while (next != NULL) {
	if (spIsMenuItem(next) == SP_TRUE) {
	    --SpPrimitiveArch(next).menu_id;
	}
	next = spGetNextComponent(next);
    }
    
    return;
}

int spGetMenuItemIdMac(spComponent component)
{
    int menu_id = 1;
    int offset;
    spComponent prev;

    offset = 1;
    if (SpParentMenuPart(component).help_flag == SP_TRUE) {
	offset += spGetNumHelpMenuItemMac();
    }
    prev = spGetPrevComponent(component);
    for (;;) {
	if (prev == NULL) {
	    menu_id = offset;
	    break;
	} else if (spIsMenuItem(prev) == SP_TRUE || spIsMenuSeparator(prev) == SP_TRUE) {
	    menu_id = SpPrimitiveArch(prev).menu_id + offset;
	    break;
	} else if (spIsMenu(prev) == SP_TRUE) {
	    offset++;
	}

	prev = spGetPrevComponent(prev);
    }

    return menu_id;
}

void spMenuItemCreateArch(spComponent component)
{
    SpPrimitiveArch(component).menu_id = spGetMenuItemIdMac(component);
    if (strcaseeq(SpGetName(component), SP_QUIT_MENU_ITEM_NAME)) {
	SpFrameArch(SpGetWindow(component)).quit_menu_item = component;
    }

    if (SpParentMenuPart(component).help_flag == SP_FALSE) {
	SpPrimitiveArch(component).map_flag = SP_FALSE;
	spMapMenuItemMac(component);
    }

    return;
}

void spMenuItemSetParamsArch(spComponent component)
{
    Str255 pstr;

    if (SpPrimitiveArch(component).map_flag == SP_FALSE) {
	return;
    }

    if (SpParentMenuPart(component).help_flag == SP_TRUE
	&& SpGetWindow(component) != spGetCurrentWindowMac()) {
	return;
    }
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {
	if (spGetMenuLabelMac(component, pstr) == SP_TRUE) {
	    spSetMenuItemTextMac(SpParentPrimitiveArch(component).menu,
				 SpPrimitiveArch(component).menu_id, pstr);
	    DrawMenuBar();
	}
    }

    return;
}

void spMenuSeparatorCreateArch(spComponent component)
{
    spMenuItemCreateArch(component);
    return;
}

static spBool convertKeySym(char *keyname, int *key, char *keylabel, short *glyph)
{
    int len;
    spBool flag = SP_TRUE;

    *glyph = 0;
    
    if (key == NULL || strnone(keyname)) {
	flag = SP_FALSE;
    } else {
	len = strlen(keyname);
	if (streq(keyname, "RET") ||
	    streq(keyname, "RETURN") || streq(keyname, "Return")) {
	    *key = kReturnCharCode;
	    *glyph = /*kMenuReturnGlyph*/0x0b;
	    strcpy(keylabel, "Return");
	} else if (streq(keyname, "ENTER") || streq(keyname, "Enter")) {
	    *key = kEnterCharCode;
	    *glyph = /*kMenuEnterGlyph*/0x04;
	    strcpy(keylabel, "Enter");
	} else if (streq(keyname, "SPC") ||
		   streq(keyname, "SPACE") || streq(keyname, "Space")) {
	    *key = ' ';
	    *glyph = /*kMenuSpaceGlyph*/0x09;
	    strcpy(keylabel, "Space");
	} else if (streq(keyname, "BACKSPACE") || streq(keyname, "BackSpace")
		   || streq(keyname, "Backspace")) {
	    *key = kDeleteCharCode;
	    *glyph = /*kMenuDeleteRightGlyph*/0x0a;
	} else if (streq(keyname, "DEL") ||
		   streq(keyname, "DELETE") || streq(keyname, "Delete")) {
	    *key = kBackspaceCharCode;
	    *glyph = /*kMenuDeleteLeftGlyph*/0x17;
	    strcpy(keylabel, "Delete");
	} else if (streq(keyname, "TAB") || streq(keyname, "Tab")) {
	    *key = kTabCharCode;
	    *glyph = /*kMenuTabRightGlyph*/0x02;
	    strcpy(keylabel, "Tab");
#if 0	/* not supported on Mac OS */
	} else if (streq(keyname, "ESC") ||
		   streq(keyname, "ESCAPE") || streq(keyname, "Escape")) {
	    *key = kEscapeCharCode;
	    *glyph = /*kMenuEscapeGlyph*/0x1b;
	    strcpy(keylabel, "Escape");
	} else if (streq(keyname, "LEFT") || streq(keyname, "Left")) {
	    *key = kLeftArrowCharCode;
	    *glyph = /*kMenuLeftArrowGlyph*/0x64;
	    strcpy(keylabel, "Left");
	} else if (streq(keyname, "UP") || streq(keyname, "Up")) {
	    *key = kUpArrowCharCode;
	    *glyph = /*kMenuUpArrowGlyph*/0x68;
	    strcpy(keylabel, "Up");
	} else if (streq(keyname, "RIGHT") || streq(keyname, "Right")) {
	    *key = kRightArrowCharCode;
	    *glyph = /*kMenuRightArrowGlyph*/0x65;
	    strcpy(keylabel, "Right");
	} else if (streq(keyname, "DOWN") || streq(keyname, "Down")) {
	    *key = kDownArrowCharCode;
	    *glyph = /*kMenuDownArrowGlyph*/0x6a;
	    strcpy(keylabel, "Down");
#endif
	} else if (streq(keyname, "HOME") || streq(keyname, "Home")) {
	    *key = kHomeCharCode;
	    strcpy(keylabel, "Home");
	} else if (streq(keyname, "END") || streq(keyname, "End")) {
	    *key = kEndCharCode;
	    strcpy(keylabel, "End");
	} else if (streq(keyname, "PRIOR") || streq(keyname, "Prior")) {
	    *key = kPageUpCharCode;
	    *glyph = /*kMenuPageUpGlyph*/0x62;
	    strcpy(keylabel, "Prior");
	} else if (streq(keyname, "NEXT") || streq(keyname, "Next")) {
	    *key = kPageDownCharCode;
	    *glyph = /*kMenuPageDownGlyph*/0x6b;
	    strcpy(keylabel, "Next");
	} else if (len == 1) {
	    *key = toupper(keyname[0]);
	    sprintf(keylabel, "%c", toupper(keyname[0]));
	} else {
	    flag = SP_FALSE;
	}
    }

    spDebug(80, "convertKeySym", "keyname = %s, key = %c, keylabel = %s\n",
	    keyname, *key, keylabel);
    
    return flag;
}

spBool spAddShortcutArch(spComponent component, char *shortcut)
{
    spBool flag = SP_TRUE;
    int len;
    int key;
    char *p = NULL;
    char keylabel[SP_MAX_LINE];
    UInt8 modifier = 0;
    short glyph = 0;
    
    if (SpPrimitiveArch(component).map_flag == SP_FALSE
	|| spIsNeedlessMenuItemMac(component) == SP_TRUE) {
	return SP_FALSE;
    }

    if (!strnone(shortcut)) {
	len = strlen(shortcut);
	if ((p = strchr(shortcut, '-')) != NULL) {
	    switch (shortcut[0]) {
	      case 'C':
		modifier = kMenuControlModifier | kMenuNoCommandModifier;
		break;
	      case 'S':
		modifier = kMenuShiftModifier | kMenuNoCommandModifier;
		break;
	      case 'M':
	      case 'A':
		break;
	      default:
		flag = SP_FALSE;
		break;
	    }
	    if (flag == SP_TRUE && convertKeySym(p + 1, &key, keylabel, &glyph) == SP_TRUE) {
	    } else {
		flag = SP_FALSE;
	    }
	} else if (convertKeySym(shortcut, &key, keylabel, &glyph) == SP_TRUE) {
	    modifier = kMenuNoCommandModifier;
	} else {
	    flag = SP_FALSE;
	}
    } else {
	flag = SP_FALSE;
    }

    if (flag == SP_TRUE) {
	if (modifier == 0) {
	    SetItemCmd(SpParentPrimitiveArch(component).menu,
		       SpPrimitiveArch(component).menu_id, key);
	} else if (spGetAppearanceVersionMac() >= 0x00000101) {
	    SetItemCmd(SpParentPrimitiveArch(component).menu,
		       SpPrimitiveArch(component).menu_id, key);
	    if (glyph != 0) {
		SetMenuItemKeyGlyph(SpParentPrimitiveArch(component).menu,
				    SpPrimitiveArch(component).menu_id, glyph);
	    }
	    SetMenuItemModifiers(SpParentPrimitiveArch(component).menu,
				 SpPrimitiveArch(component).menu_id, modifier);
	} else {
	    flag = SP_FALSE;
	}
    }
    
    return flag;
}




