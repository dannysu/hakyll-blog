/*
 *	spSlider_Win.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spSliderP.h>

extern spTopLevel sp_toplevel;

static int getScrollCoef(spComponent component)
{
    if (SpSliderPart(component).maximum >= 32768) {
	return (int)ceil((double)SpSliderPart(component).maximum / 32768.0);
    } else {
	return 1;
    }
}

void spSliderCreateArch(spComponent component)
{
    SCROLLINFO sinfo;

    SpSliderPart(component).scroll_coef = getScrollCoef(component);

    sinfo.cbSize = sizeof(SCROLLINFO);
    sinfo.fMask = SIF_POS | SIF_RANGE | SIF_PAGE;
    sinfo.nMin = SpSliderPart(component).minimum / SpSliderPart(component).scroll_coef;
    sinfo.nMax = SpSliderPart(component).maximum / SpSliderPart(component).scroll_coef;
    sinfo.nPage = SpSliderPart(component).page_size / SpSliderPart(component).scroll_coef + 1;
    sinfo.nPos = SpSliderPart(component).value / SpSliderPart(component).scroll_coef;
    sinfo.nTrackPos = 0;

    /* create scroll bar */
    SpPrimitiveArch(component).hwnd =
	CreateWindow("SCROLLBAR",
		     (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		     (SpComponentPart(component).orientation == SP_HORIZONTAL ? SBS_HORZ : SBS_VERT)
		     | WS_CHILD | WS_VISIBLE,
		     SpComponentPart(component).x, SpComponentPart(component).y,
		     SpComponentPart(component).current_width,
		     SpComponentPart(component).current_height,
		     SpParentPrimitiveArch(component).hwnd,
		     (HMENU)SpComponentPart(component).component_id,
		     SpTopLevelArch(sp_toplevel).hThisInst,
		     NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));

    SetScrollInfo(SpPrimitiveArch(component).hwnd, SB_CTL, &sinfo, TRUE);
    
    return;
}

void spSliderSetParamsArch(spComponent component)
{
    SCROLLINFO sinfo;

    if (spIsSensitive(component) == SP_FALSE) return;
    
    spDebug(50, "spSliderSetParamsArch", "in\n");

    SpSliderPart(component).scroll_coef = getScrollCoef(component);
    
    sinfo.cbSize = sizeof(SCROLLINFO);
    sinfo.fMask = SIF_POS | SIF_RANGE | SIF_PAGE;
    sinfo.nMin = SpSliderPart(component).minimum / SpSliderPart(component).scroll_coef;
    sinfo.nMax = SpSliderPart(component).maximum / SpSliderPart(component).scroll_coef;
    sinfo.nPage = SpSliderPart(component).page_size / SpSliderPart(component).scroll_coef + 1;
    sinfo.nPos = SpSliderPart(component).value / SpSliderPart(component).scroll_coef;
    sinfo.nTrackPos = 0;

    SetScrollInfo(SpPrimitiveArch(component).hwnd, SB_CTL, &sinfo, TRUE);
    
    spDebug(50, "spSliderSetParamsArch", "done\n");
    
    return;
}

void spUpdateSlider(spComponent component)
{
    SCROLLINFO sinfo;

    if (spIsSensitive(component) == SP_FALSE) return;
    
    sinfo.cbSize = sizeof(SCROLLINFO);
    sinfo.fMask = SIF_POS;
    
    if (spIsSlider(component) == SP_TRUE) {
	SpSliderPart(component).value =
	    MAX(SpSliderPart(component).value, SpSliderPart(component).minimum);
	SpSliderPart(component).value =
	    MIN(SpSliderPart(component).value,
		SpSliderPart(component).maximum - SpSliderPart(component).page_size);
	sinfo.nPos = SpSliderPart(component).value / SpSliderPart(component).scroll_coef;
	
	spDebug(50, "spUpdateSlider","min = %d, max = %d, value = %d\n",
		SpSliderPart(component).minimum, SpSliderPart(component).maximum,
		SpSliderPart(component).value);
	SetScrollInfo(SpPrimitiveArch(component).hwnd, SB_CTL, &sinfo, 1);
    } else {
	SpSliderPart(component).value =
	    MAX(SpSliderPart(component).value, SpSliderPart(component).minimum);
	SpSliderPart(component).value =
	    MIN(SpSliderPart(component).value,
		SpSliderPart(component).maximum - SpSliderPart(component).page_size);
	sinfo.nPos = SpSliderPart(component).value / SpSliderPart(component).scroll_coef;
	if (SpPrimitiveArch(component).message == WM_HSCROLL) {
	    SetScrollInfo(SpPrimitiveArch(component).hwnd, SB_HORZ, &sinfo, 1);
	} else {
	    SetScrollInfo(SpPrimitiveArch(component).hwnd, SB_VERT, &sinfo, 1);
	}
    }
    
    return;
}

void spSetSliderValueArch(spComponent component)
{
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	spUpdateTrackBar(component);
    } else {
	spUpdateSlider(component);
    }
    
    return;
}

int spGetSliderValueArch(spComponent component)
{
    return SpSliderPart(component).value;
}

void spDrawTrackBarValue(spComponent component)
{
    HDC hdc;
    int width, height;
    static char string[SP_MAX_LINE];

    if (SpSliderPart(component).show_value == SP_TRUE) {
	hdc = GetDC(SpPrimitiveArch(component).hwnd);
	SelectObject(hdc, SpTopLevelArch(sp_toplevel).sys_font);
	SetBkColor(hdc, GetSysColor(COLOR_BTNFACE));
	/*SetBkMode(hdc, TRANSPARENT);*/
	SetBkMode(hdc, OPAQUE);

	if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	    sprintf(string, "%3d  ", SpSliderPart(component).value);
	    spGetSize(component, &width, &height);
	    TextOut(hdc, width / 2 - 8, height - 13, string, strlen(string));
	} else {
	    if (SpSliderPart(component).value >= 10) {
		sprintf(string, "%3d", SpSliderPart(component).value);
	    } else {
		sprintf(string, "%3d ", SpSliderPart(component).value);
	    }
	    spGetSize(component, &width, &height);
	    TextOut(hdc, width - 20, height / 2 - 6, string, strlen(string));
	}
	ReleaseDC(SpPrimitiveArch(component).hwnd, hdc);
    }

    return;
}

void spUpdateTrackBar(spComponent component)
{
    SpSliderPart(component).value =
	MAX(SpSliderPart(component).value, SpSliderPart(component).minimum);
    SpSliderPart(component).value =
	MIN(SpSliderPart(component).value, SpSliderPart(component).maximum);
    spDebug(50, "spUpdateTrackBar", "min = %d, max = %d, value = %d\n",
	    SpSliderPart(component).minimum, SpSliderPart(component).maximum,
	    SpSliderPart(component).value);

    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETPOS, (WPARAM)TRUE,
		(LPARAM)(SpSliderPart(component).value / SpSliderPart(component).scroll_coef));
    spDrawTrackBarValue(component);
    
    return;
}

void spTrackBarCreateArch(spComponent component)
{
    SpSliderPart(component).scroll_coef = getScrollCoef(component);
    
    /* create track bar */
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(0,
		       TRACKBAR_CLASS,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       (SpComponentPart(component).orientation == SP_HORIZONTAL ? TBS_HORZ : TBS_VERT)
		       | (SpSliderPart(component).show_scale == SP_TRUE ? TBS_AUTOTICKS : TBS_NOTICKS)
		       | WS_CHILD | WS_VISIBLE | WS_TABSTOP,
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComponentPart(component).current_height,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);
    SendMessage(SpPrimitiveArch(component).hwnd, WM_SETFONT,
		(WPARAM)SpTopLevelArch(sp_toplevel).sys_font, MAKELPARAM(TRUE, 0));

    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETTICFREQ,
		(WPARAM)(SpSliderPart(component).page_increment / SpSliderPart(component).scroll_coef),
		(LPARAM)1);
    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETRANGE,
		(WPARAM)FALSE,
		(LPARAM)MAKELONG((SpSliderPart(component).minimum / SpSliderPart(component).scroll_coef),
				 (SpSliderPart(component).maximum / SpSliderPart(component).scroll_coef)));
    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETPOS, (WPARAM)TRUE,
		(LPARAM)(SpSliderPart(component).value / SpSliderPart(component).scroll_coef));
    
    return;
}

void spTrackBarSetParamsArch(spComponent component)
{
    SpSliderPart(component).scroll_coef = getScrollCoef(component);
    
    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETTICFREQ,
		(WPARAM)(SpSliderPart(component).page_increment / SpSliderPart(component).scroll_coef),
		(LPARAM)1);
    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETRANGE,
		(WPARAM)FALSE,
		(LPARAM)MAKELONG((SpSliderPart(component).minimum / SpSliderPart(component).scroll_coef),
				 (SpSliderPart(component).maximum / SpSliderPart(component).scroll_coef)));
    SendMessage(SpPrimitiveArch(component).hwnd, TBM_SETPOS, (WPARAM)TRUE,
		(LPARAM)(SpSliderPart(component).value / SpSliderPart(component).scroll_coef));
    
    return;
}
