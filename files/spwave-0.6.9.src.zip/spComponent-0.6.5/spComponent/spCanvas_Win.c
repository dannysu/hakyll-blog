/*
 *	spCanvas_Win.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spCanvasP.h>

extern spTopLevel sp_toplevel;

spBool spIsCanvasExposedArch(spComponent component)
{
    if (SpComponentPart(component).client_width >= 0
	&& SpComponentPart(component).client_height >= 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spExposeCanvasCBArch(spComponent component)
{
    return;
}

static void resizeCanvasCB(spComponent component, void *data)
{
    if (SpPrimitiveArch(SpGetWindow(component)).realize_flag == SP_TRUE) {
	spResizeCanvasCB(component, data);
    }
    return;
}

void spCanvasCreateArch(spComponent component)
{
    SpPrimitiveArch(component).hwnd =
	CreateWindowEx(WS_EX_CONTROLPARENT |
		       (SpCanvasPart(component).border_on == SP_TRUE ? WS_EX_CLIENTEDGE : 0),
		       SP_CANVAS_CLASS_NAME,
		       (!strnone(SpGetName(component)) ? SpGetName(component) : ""),
		       WS_CHILD | WS_VISIBLE | /*WS_CLIPCHILDREN |*/
		       (SpCanvasPart(component).focusable == SP_TRUE ? WS_TABSTOP : 0),
		       SpComponentPart(component).x, SpComponentPart(component).y,
		       SpComponentPart(component).current_width,
		       SpComponentPart(component).current_height,
		       SpParentPrimitiveArch(component).hwnd,
		       (HMENU)SpComponentPart(component).component_id,
		       SpTopLevelArch(sp_toplevel).hThisInst,
		       NULL);

    spAddCallback(component, SP_RESIZE_CALLBACK, resizeCanvasCB, NULL);

    return;
}

void spCanvasSetParamsArch(spComponent component)
{
    return;
}
    
void spCanvasDestroyArch(spComponent component)
{
    return;
}
    
void spRefreshCanvasArch(spComponent component)
{
    PAINTSTRUCT paintstruct;

    spDebug(40, "spRefreshCanvas", "width = %d, height = %d\n", 
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);
    
    if (SpPrimitiveArch(component).message == WM_PAINT) {
	spDebug(80, "spRefreshCanvas", "WM_PAINT message\n");
	
	if (GetUpdateRect(SpPrimitiveArch(component).hwnd, NULL, FALSE)) {

	    SpPrimitiveArch(component).hdc = BeginPaint(SpPrimitiveArch(component).hwnd, &paintstruct);
#if 0
	    BitBlt(SpPrimitiveArch(component).hdc, 0, 0,
		   SpComponentPart(component).client_width, SpComponentPart(component).client_height,
		   SpPrimitiveArch(component).memdc, 0, 0, SRCCOPY);
#else
	    spDebug(40, "spRefreshCanvas", "erase = %d, left = %d, right = %d, top = %d, bottom = %d\n",
		    paintstruct.fErase, paintstruct.rcPaint.left, paintstruct.rcPaint.right,
		    paintstruct.rcPaint.top, paintstruct.rcPaint.bottom); 
	    BitBlt(SpPrimitiveArch(component).hdc,
		   paintstruct.rcPaint.left, paintstruct.rcPaint.top,
		   paintstruct.rcPaint.right - paintstruct.rcPaint.left,
		   paintstruct.rcPaint.bottom - paintstruct.rcPaint.top,
		   SpPrimitiveArch(component).memdc, 
		   paintstruct.rcPaint.left, paintstruct.rcPaint.top,
		   SRCCOPY);
#endif
	    EndPaint(SpPrimitiveArch(component).hwnd, &paintstruct);
	} else {
	    InvalidateRect(SpPrimitiveArch(component).hwnd, NULL, FALSE);
	}
    } else {
	SpPrimitiveArch(component).hdc = GetDC(SpPrimitiveArch(component).hwnd);
	BitBlt(SpPrimitiveArch(component).hdc, 0, 0,
	       SpComponentPart(component).client_width, SpComponentPart(component).client_height,
	       SpPrimitiveArch(component).memdc, 0, 0, SRCCOPY);
	ReleaseDC(SpPrimitiveArch(component).hwnd, SpPrimitiveArch(component).hdc);
    }
    
    spDebug(80, "spRefreshCanvas", "done\n");
    
    return;
}

void spRedrawCanvasArch(spComponent component)
{
    spRedrawImageArch(component);
    return;
}

spBool spSetCanvasCaptureArch(spComponent window)
{
    return SP_TRUE;
}

spBool spSetCanvasCursorArch(spComponent component, spCursor cursor)
{
#if 0
    SetClassLong(SpPrimitiveArch(component).hwnd,
		 GCL_HCURSOR,
		 (LONG)SpCursorArch(cursor).hcursor);
    SpTopLevelArch(sp_toplevel).hcursor = SpCursorArch(cursor).hcursor;
    SetCursor(SpTopLevelArch(sp_toplevel).hcursor);
#else
    SpPrimitiveArch(component).hcursor = SpCursorArch(cursor).hcursor;
#endif
    
    return SP_TRUE;
}

spBool spUnsetCanvasCursorArch(spComponent component)
{
#if 0
    SetClassLong(SpPrimitiveArch(component).hwnd,
		 GCL_HCURSOR,
		 (LONG)LoadCursor(NULL, IDC_ARROW));
    SpTopLevelArch(sp_toplevel).hcursor = NULL;
    SetCursor(LoadCursor(NULL, IDC_ARROW));
#else
    SpPrimitiveArch(component).hcursor = NULL;
#endif
    
    return SP_TRUE;
}

spBool spIsCanvasFocusedArch(spComponent component)
{
    if (SpPrimitiveArch(component).hwnd == GetFocus()) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}
