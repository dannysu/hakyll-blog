/*
 *	spFrame_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spContainerP.h>
#include <sp/spComboBoxP.h>
#include <sp/spTextP.h>
#include <sp/spDrawP.h>
#include <sp/spFrameP.h>

#if defined(MACOS)
#pragma import on
#endif
extern spTopLevel sp_toplevel;
#if defined(MACOS)
#pragma import off
#endif

#define ALWAYS_DISPLAY_CLOSE_BOX

void spGetWindowBoundsMac(WindowRef window, Rect *rect)
{
#if TARGET_API_MAC_CARBON
    GetWindowBounds(window, kWindowContentRgn, rect);
#else
    {
	RgnHandle rgn;
	rgn = spGetContentRegionMac(window);
	spGetRegionBoundsMac(rgn, rect);
    }
#endif

    return;
}

void spInvalWindowMac(WindowPtr window, ControlRef control)
{
    Rect rect;
    GrafPtr save_port;
    
    spLockWindowPort(window, &save_port);
    
    spGetPortRectMac(window, &rect);
    spInvalRectMac(window, &rect);
    
    if (control != NULL) {
	spGetControlRectMac(control, &rect);
	spValidRectMac(window, &rect);
    }

    spUnlockWindowPort(window, save_port);
    
    return;
}

static spBool sp_main_frame_created = SP_FALSE;

void spFramePartInitArch(spComponent component)
{
    SpFrameArch(component).realize_flag = SP_FALSE;
    SpFrameArch(component).activate_flag = SP_FALSE;
    SpFrameArch(component).text = NULL;
    SpFrameArch(component).key_send_component = NULL;
    SpFrameArch(component).quit_menu_item = NULL;
    
    SpFrameArch(component).drop_call_func = NULL;
    SpFrameArch(component).drop_call_data = NULL;

    SpFrameArch(component).draw_func = NULL;
    SpFrameArch(component).mouse_func = NULL;
    SpFrameArch(component).key_func = NULL;
    SpFrameArch(component).foreground_func = NULL;
    SpFrameArch(component).background_func = NULL;
    SpFrameArch(component).data = NULL;
    
    return;
}

void spFramePartFreeArch(spComponent component)
{
    return;
}

void spSetFrameBackgroundMac(spComponent component)
{
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	SetThemeWindowBackground(SpPrimitiveArch(component).window,
				 kThemeBrushDialogBackgroundActive, true);
    }

    return;
}

#if TARGET_API_MAC_CARBON
static void setIconNameCarbon(spComponent component, char *icon_name)
{
    if (strnone(icon_name)) {
	spDebug(10, "setIconNameCarbon", "set null icon name\n");
	SetWindowAlternateTitle(SpPrimitiveArch(component).window, NULL);
    } else {
	CFStringRef cfstr;

	spDebug(10, "setIconNameCarbon", "icon_name = %s\n", icon_name);
	
	if ((cfstr = CFStringCreateWithCString(NULL, icon_name, CFStringGetSystemEncoding())) != NULL) {
	    SetWindowAlternateTitle(SpPrimitiveArch(component).window, cfstr);
	    CFRelease(cfstr);
	}
    }

    return;
}

static spBool createNewWindowCarbon(spComponent component, Str255 ptitle)
{
    Rect rect;
    WindowRef window;
    WindowClass wclass = kDocumentWindowClass;
    WindowAttributes wattr = kWindowNoAttributes;
    EventHandlerRef ehref;
    static EventTypeSpec list_osx[] = {
	{ kEventClassKeyboard, kEventRawKeyDown },
	{ kEventClassKeyboard, kEventRawKeyRepeat },
	{ kEventClassKeyboard, kEventRawKeyUp },
	
	{ kEventClassWindow, kEventWindowClose },
	{ kEventClassWindow, kEventWindowDrawContent },
	{ kEventClassWindow, kEventWindowZoom },
	{ kEventClassWindow, kEventWindowActivated },
	{ kEventClassWindow, kEventWindowDeactivated },
	{ kEventClassWindow, kEventWindowBoundsChanging },
	{ kEventClassWindow, kEventWindowBoundsChanged },
#if 0
	{ kEventClassWindow, kEventWindowGetMinimumSize },
	{ kEventClassWindow, kEventWindowGetMaximumSize },
#endif
	
	{ kEventClassWindow, kEventWindowGetClickActivation },
	{ kEventClassWindow, kEventWindowClickDragRgn },
	{ kEventClassWindow, kEventWindowClickResizeRgn },
	{ kEventClassWindow, kEventWindowClickCollapseRgn },
	{ kEventClassWindow, kEventWindowClickCloseRgn },
	{ kEventClassWindow, kEventWindowClickZoomRgn },
	{ kEventClassWindow, kEventWindowClickContentRgn },
	{ kEventClassWindow, kEventWindowClickProxyIconRgn },
	{ kEventClassWindow, kEventWindowClickToolbarButtonRgn },

	{ kEventClassWindow, kEventWindowDrawFrame },
	{ kEventClassWindow, kEventWindowDrawPart },
	{ kEventClassWindow, kEventWindowDrawGrowBox },
	{ kEventClassWindow, kEventWindowPaint },
    };
    static EventTypeSpec list_os9[] = {
	{ kEventClassKeyboard, kEventRawKeyDown },
	{ kEventClassKeyboard, kEventRawKeyRepeat },
	{ kEventClassKeyboard, kEventRawKeyUp },
	
	{ kEventClassWindow, kEventWindowClose },
	{ kEventClassWindow, kEventWindowDrawContent },
	{ kEventClassWindow, kEventWindowZoom },
	{ kEventClassWindow, kEventWindowActivated },
	{ kEventClassWindow, kEventWindowDeactivated },
	{ kEventClassWindow, kEventWindowResizeCompleted },
#if 0
	{ kEventClassWindow, kEventWindowGetMinimumSize },
	{ kEventClassWindow, kEventWindowGetMaximumSize },
#endif
	
	{ kEventClassWindow, kEventWindowGetClickActivation },
	{ kEventClassWindow, kEventWindowClickDragRgn },
	{ kEventClassWindow, kEventWindowClickResizeRgn },
	{ kEventClassWindow, kEventWindowClickCollapseRgn },
	{ kEventClassWindow, kEventWindowClickCloseRgn },
	{ kEventClassWindow, kEventWindowClickZoomRgn },
	{ kEventClassWindow, kEventWindowClickContentRgn },
	{ kEventClassWindow, kEventWindowClickProxyIconRgn },

	{ kEventClassWindow, kEventWindowDrawFrame },
	{ kEventClassWindow, kEventWindowDrawPart },
	{ kEventClassWindow, kEventWindowDrawGrowBox },
	{ kEventClassWindow, kEventWindowPaint },
    };

    spDebug(10, "createNewWindowCarbon", "in\n");
    
    if (spIsAquaMac() == SP_TRUE
	&& SpFramePart(component).window_type != SP_NORMAL_WINDOW
	&& spIsFrame(SpFramePart(component).parent_window) == SP_TRUE) {
	wclass = kSheetWindowClass;
	spDebug(10, "createNewWindowCarbon", "sheet window\n");
    } else if (SpFramePart(component).window_type == SP_DIALOG_WINDOW) {
    } else if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	wclass = kPlainWindowClass;
    } else {
	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    /*SpComponentPart(component).margin_bottom = SP_SIZE_BOX_SIZE;*/
	    wattr |= kWindowFullZoomAttribute | kWindowResizableAttribute;
	}
	if (SpFramePart(component).simplify_flag == SP_TRUE) {
	    wattr |= kWindowToolbarButtonAttribute;
	}
    }

    if (wclass != kSheetWindowClass) {
	if (SpFramePart(component).iconfy_flag == SP_TRUE) {
	    wattr |= kWindowCollapseBoxAttribute;
	    wattr |= kWindowInWindowMenuAttribute;
	}
#ifdef ALWAYS_DISPLAY_CLOSE_BOX
	wattr |= kWindowCloseBoxAttribute;
#else
	if (SpFramePart(component).close_style != SP_NO_CLOSE) {
	    wattr |= kWindowCloseBoxAttribute;
	}
#endif
    }

    if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	spDebug(10, "createNewWindowCarbon", "support carbon event\n");
	wattr |= kWindowStandardHandlerAttribute;
	if (SpFramePart(component).resize_flag == SP_TRUE && spIsAquaMac() == SP_TRUE) {
	    spDebug(10, "createNewWindowCarbon", "support live resizing\n");
	    wattr |= kWindowLiveResizeAttribute;
	}
    }

    spSetComponentRectMac(component,
			  SP_DEFAULT_WINDOW_WIDTH,
			  SP_DEFAULT_WINDOW_HEIGHT);
    rect = SpPrimitiveArch(component).rect;

    if (CreateNewWindow(wclass, wattr, &rect, &window) != noErr) {
	spDebug(10, "createNewWindowCarbon", "can't create window\n");
	return SP_FALSE;
    }
    SetWTitle(window, ptitle);
    setIconNameCarbon(component, SpFramePart(component).icon_name);

    if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	SpPrimitiveArch(component).eventHandler = spNewWindowEventHandlerUPP();
	
	if (spIsAquaMac() == SP_TRUE) {
	    InstallWindowEventHandler(window, SpPrimitiveArch(component).eventHandler,
				      spArraySize(list_osx), list_osx, 0, &ehref);
	} else {
	    InstallWindowEventHandler(window, SpPrimitiveArch(component).eventHandler,
				      spArraySize(list_os9), list_os9, 0, &ehref);
	}
    }
    
    SpPrimitiveArch(component).window = window;
    
    spDebug(10, "createNewWindowCarbon", "done\n");
    
    return SP_TRUE;
}
#else
static spBool createNewWindow(spComponent component, Str255 ptitle)
{
    Boolean close_flag;
    short doc_type;
    Ptr ptr;
    Rect rect;

    spDebug(10, "createNewWindow", "in\n");
    
    if (SpFramePart(component).window_type == SP_DIALOG_WINDOW) {
#if 1
	doc_type = movableDBoxProc;
#else
	if (SpFramePart(component).iconfy_flag == SP_TRUE) {
	    doc_type = movableDBoxProc;
	} else {
	    doc_type = dBoxProc;
	}
#endif
    } else if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	doc_type = plainDBox;
    } else {
	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    /*SpComponentPart(component).margin_bottom = SP_SIZE_BOX_SIZE;*/
	    doc_type = zoomDocProc;
	} else {
	    doc_type = noGrowDocProc;
	}
    }
    
    if (SpFramePart(component).close_style == SP_NO_CLOSE) {
	close_flag = false;
    } else {
	close_flag = true;
    }

    spSetComponentRectMac(component,
			  SP_DEFAULT_WINDOW_WIDTH,
			  SP_DEFAULT_WINDOW_HEIGHT);
    rect = SpPrimitiveArch(component).rect;

#if !TARGET_API_MAC_CARBON
    ptr = NewPtr(sizeof(CWindowRecord));
#else
    ptr = NULL;
#endif
    if ((SpPrimitiveArch(component).window =
	 NewCWindow(ptr, &rect, ptitle, false, doc_type, (WindowPtr)-1, close_flag, 0L)) == NULL) {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}
#endif

static spBool spCreateNewWindowMac(spComponent component, Str255 ptitle)
{
#if TARGET_API_MAC_CARBON
    return createNewWindowCarbon(component, ptitle);
#else
    return createNewWindow(component, ptitle);
#endif
    
}

void spFrameCreateArch(spComponent component)
{
    char *title = NULL;
    char *icon_name = NULL;
    Str255 pstr;

    if (!strnone(SpFramePart(component).icon_name)) {
	icon_name = SpFramePart(component).icon_name;
    }
    
    if (!strnone(SpComponentPart(component).title)) {
	title = SpComponentPart(component).title;
    }

    if (title == NULL) {
	if (icon_name != NULL) {
	    title = icon_name;
	} else {
	    title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
	}
    }
    spStrCToP(title, pstr);
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE
	&& sp_main_frame_created == SP_FALSE) {
	sp_main_frame_created = SP_TRUE;
    }

    spCreateNewWindowMac(component, pstr);
    
    /*SetPortWindowPort(SpPrimitiveArch(component).window);*/
    spSetReferenceMac(component);

    SpPrimitiveArch(component).menu_id = spUseCurrentMenuIdMac();
    SpPrimitiveArch(component).map_flag = SP_FALSE;

    spSetFrameBackgroundMac(component);

    if (spGetAppearanceVersionMac() >= 0x00000101) {
	ControlRef control;
	CreateRootControl(SpPrimitiveArch(component).window, &control);
    }
    
    return;
}

void spFrameDestroyArch(spComponent component)
{
    spPostMessageMac(component, SP_DESTROY_CALLBACK, SP_CR_DESTROY);
    return;
}
    
void spFrameSetParamsArch(spComponent component)
{
    char *title = NULL;
    Str255 pstr;

#if TARGET_API_MAC_CARBON
    if (SpFramePart(SpOldObject(component)).icon_name != SpFramePart(component).icon_name) { 
	if (!strnone(SpFramePart(component).icon_name)) {
	    setIconNameCarbon(component, SpFramePart(component).icon_name);
	}
    }
#endif
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {
	if (!strnone(SpComponentPart(component).title)) {
	    title = SpComponentPart(component).title;
	}
    }

    if (title != NULL) {
	spStrCToP(title, pstr);
	SetWTitle(SpPrimitiveArch(component).window, pstr);
    }
    
#if TARGET_API_MAC_CARBON
#ifndef ALWAYS_DISPLAY_CLOSE_BOX
    if (SpFramePart(SpOldObject(component)).close_style != SpFramePart(component).close_style) {
	if (SpFramePart(component).close_style == SP_NO_CLOSE) {
	    ChangeWindowAttributes(SpPrimitiveArch(component).window, 0, kWindowCloseBoxAttribute);
	} else {
	    ChangeWindowAttributes(SpPrimitiveArch(component).window, kWindowCloseBoxAttribute, 0);
	}
    }
#endif
#endif
	
    return;
}

void *spGetArchFrame(spComponent component)
{
    return (void *)SpPrimitiveArch(component).window;
}

spBool spIsTaskTraySupported(void)
{
    return SP_FALSE;
}

spBool spShowTaskTrayArch(spComponent window, spBool flag)
{
    return SP_FALSE;
}

static void setCurrentWindowPosition(spComponent window)
{
    Rect bounds;
    int x, y;
    int width, height;
    static int prev_x = SP_INIT_WINDOW_X_POS;
    static int prev_y = SP_INIT_WINDOW_Y_POS;

    if (SpComponentPart(window).x == 0
	&& SpComponentPart(window).y == 0) {
	x = prev_x; y = prev_y;
	if (spGetComponentSize(window, &width, &height) == SP_FALSE) {
	    width = SP_DEFAULT_WINDOW_WIDTH;
	    height = SP_DEFAULT_WINDOW_HEIGHT;
	}
	spGetScreenBoundsMac(&bounds);
	spDebug(50, "setCurrentWindowPosition", "screen bounds: left = %d, right = %d, top = %d, bottom = %d\n",
		bounds.left, bounds.right, bounds.top, bounds.bottom);
	if (x >= bounds.right - width || y >= bounds.bottom - height) {
	    x = SP_INIT_WINDOW_X_POS;
	    y = SP_INIT_WINDOW_Y_POS;
	}
	prev_x = x + SP_WINDOW_X_INCR;
	prev_y = y + SP_WINDOW_Y_INCR;
    } else {
	x = SpComponentPart(window).x;
	y = SpComponentPart(window).y;
    }
    
    spSetFramePositionArch(window, x, y);

    return;
}

static spComponent sp_current_modal_window = NULL;

static void showControls(spComponent parent)
{
    spComponent next;
    
    if (SpPrimitiveArch(parent).next_need_update != NULL) {
	next = SpPrimitiveArch(parent).next_need_update;
	while (next != NULL) {
	    spMapComponentFirstMac(next);
	    next = SpPrimitiveArch(next).next_need_update;
	}
    }

    return;
}

void spPopupFrameArch(spComponent window, spBool move_cursor)
{
    spComponent prev_window = NULL;
    
    spDebug(50, "spPopupFrameArch", "in\n");
    
    if (SpFrameArch(window).realize_flag == SP_FALSE) {
	SpFrameArch(window).realize_flag = SP_TRUE;
	spAdjustComponentSize(window);
	setCurrentWindowPosition(window);
	showControls(window);
    }
    spDebug(50, "spPopupFrameArch", "realize done\n");

    if (SpFramePart(window).window_type == SP_NORMAL_WINDOW
	&& !IsWindowVisible(SpPrimitiveArch(window).window)
	&& spGetSystemVersionMac() >= 0x00000850) {
	TransitionWindow(SpPrimitiveArch(window).window,
			 kWindowZoomTransitionEffect,
			 kWindowShowTransitionAction,
			 NULL);
    } else {
#if TARGET_API_MAC_CARBON
	if (spIsAquaMac() == SP_TRUE
	    && SpFramePart(window).window_type != SP_NORMAL_WINDOW
	    && spIsFrame(SpFramePart(window).parent_window) == SP_TRUE) {
	    spDebug(10, "createNewWindowCarbon", "show sheet window\n");
	    ShowSheetWindow(SpPrimitiveArch(window).window,
			    SpPrimitiveArch(SpFramePart(window).parent_window).window);
	} else {
	    ShowWindow(SpPrimitiveArch(window).window);
	}
#else
	ShowWindow(SpPrimitiveArch(window).window);
#endif
    }
    
    SpPrimitiveArch(window).map_flag = SP_TRUE;

    if (SpFramePart(window).internal_flag == SP_FALSE) {
	prev_window = spSelectMenuBarMac(window, NULL);
    }

    if (SpFramePart(window).popup_style == SP_MODAL_POPUP) {
	spDebug(50, "spPopupFrameArch", "enter modal loop\n");
	sp_current_modal_window = window;
	
#if TARGET_API_MAC_CARBON
	RunAppModalLoopForWindow(SpPrimitiveArch(window).window);
#else
	while (1) {
	    spDispatchEventEffectiveMac(sp_toplevel);
	    if (sp_current_modal_window == NULL
		|| spIsCreated(window) == SP_FALSE
		|| SpPrimitiveArch(window).map_flag == SP_FALSE) {
		break;
	    }
	}
#endif
	sp_current_modal_window = NULL;
	
	if (prev_window != NULL) {
	    spDebug(50, "spPopupFrameArch", "select menu bar\n");
	    spSelectMenuBarMac(prev_window, NULL);
	    if (spIsFrame(prev_window) == SP_TRUE
		&& SpFramePart(prev_window).popup_style == SP_MODAL_POPUP) {
		sp_current_modal_window = prev_window;
	    }
	} else {
	    spSelectMenuBarMac(NULL, NULL);
	}
    }
    
    spDebug(50, "spPopupFrameArch", "done\n");
    
    return;
}

void spPopdownFrameArch(spComponent window)
{
    if (window == sp_current_modal_window) {
	sp_current_modal_window = NULL;
    }
    
    SpPrimitiveArch(window).map_flag = SP_FALSE;

    if (spIsText(SpFrameArch(window).key_send_component) == SP_TRUE) {
	spComponent text;
	text = SpFrameArch(window).key_send_component;
	SpFrameArch(window).key_send_component = NULL;
	if (spDeactivateTextMac(text, SP_FALSE) == SP_TRUE) {
	    spTEToScrapMac();
	    spChangeEditMenuStateMac(window);
	}
    }
    
    if (SpFramePart(window).window_type == SP_NORMAL_WINDOW
	&& spGetSystemVersionMac() >= 0x00000850) {
	TransitionWindow(SpPrimitiveArch(window).window,
			 kWindowZoomTransitionEffect,
			 kWindowHideTransitionAction,
			 NULL);
    } else {
#if TARGET_API_MAC_CARBON
	if (spIsAquaMac() == SP_TRUE
	    && SpFramePart(window).window_type != SP_NORMAL_WINDOW
	    && spIsFrame(SpFramePart(window).parent_window) == SP_TRUE) {
	    spDebug(10, "spPopdownFrameArch", "hide sheet window\n");
	    HideSheetWindow(SpPrimitiveArch(window).window);
	} else {
	    HideWindow(SpPrimitiveArch(window).window);
	}
#else
	HideWindow(SpPrimitiveArch(window).window);
#endif
    }

#if 1
    if (SpFramePart(window).internal_flag == SP_FALSE
	&& SpFramePart(window).popup_style != SP_MODAL_POPUP) {
	if (SpFramePart(window).menu_bar == NULL
	    || SpFramePart(window).menu_bar == spGetCurrentMenuBarMac()) {
	    spDebug(50, "spPopdownFrameArch", "select menu bar\n");
	    spSelectMenuBarMac(NULL, window);
	}
    }
#endif
    
#if TARGET_API_MAC_CARBON
    if (SpFramePart(window).popup_style == SP_MODAL_POPUP) {
	QuitAppModalLoopForWindow(SpPrimitiveArch(window).window);
    }
#endif
    
    spDebug(50, "spPopdownFrameArch", "done\n");
    
    return;
}

void spRaiseFrameArch(spComponent window)
{
    BringToFront(SpPrimitiveArch(window).window);
    return;
}

void spLowerFrameArch(spComponent window)
{
    SendBehind(SpPrimitiveArch(window).window, (WindowPtr)0);
    return;
}

spBool spSetFramePositionArch(spComponent window, int x, int y)
{
    spDebug(50, "spSetFramePositionArch", "x = %d, y = %d\n", x, y);
    
    MoveWindow(SpPrimitiveArch(window).window, (short)x, (short)y, false);
    return SP_TRUE;
}

spBool spGetFramePositionArch(spComponent window, int *x, int *y)
{
    Rect rect;

    spGetWindowBoundsMac(SpPrimitiveArch(window).window, &rect);
    spDebug(80, "spGetFramePositionArch", "left = %d, right = %d, top = %d, bottom = %d\n",
	    rect.left, rect.right, rect.top, rect.bottom);
    *x = rect.left;
    *y = rect.top;

    spDebug(50, "spGetFramePositionArch", "x = %d, y = %d\n", *x, *y);
    
    return SP_TRUE;
}

spBool spGetFrameModifierKeyMaskArch(spComponent window, spModifierMask *mask)
{
    UInt32 modifiers = 0;

    *mask = 0;

    modifiers = spGetLastEventModifiersMac();
    spDebug(50, "spGetFrameModifierMaskArch", "modifiers = %lx\n", modifiers);
    
    if (modifiers & cmdKey) {
	*mask |= SP_ALT_MASK;
    }
    if (modifiers & shiftKey) {
	*mask |= SP_SHIFT_MASK;
    }
    if (modifiers & alphaLock) {
	*mask |= SP_LOCK_MASK;
    }
    if (modifiers & optionKey) {
	*mask |= SP_OPTION_MASK;
    }
    if (modifiers & controlKey) {
	*mask |= SP_CONTROL_MASK;
    }
    
    return SP_TRUE;
}

spBool spAddDropCallbackArch(spComponent component, spDropCallbackFunc call_func, void *call_data)
{
    SpFrameArch(component).drop_call_func = call_func;
    SpFrameArch(component).drop_call_data = call_data;
    
    return SP_TRUE;
}

void spAddFrameCallbackMac(spComponent component, spDrawFunc draw_func,
			   spMouseFunc mouse_func, spKeyFunc key_func,
			   spForegroundFunc foreground_func, spBackgroundFunc background_func, 
			   void *data)
{
    SpFrameArch(component).draw_func = draw_func;
    SpFrameArch(component).mouse_func = mouse_func;
    SpFrameArch(component).key_func = key_func;
    SpFrameArch(component).foreground_func = foreground_func;
    SpFrameArch(component).background_func = background_func;
    SpFrameArch(component).data = data;
    
    return;
}
