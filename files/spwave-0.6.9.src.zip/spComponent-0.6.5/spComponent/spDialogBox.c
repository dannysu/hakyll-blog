/*
 *	spDialogBox.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spOption.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spFrame.h>
#include <sp/spContainer.h>
#include <sp/spButton.h>
#include <sp/spText.h>
#include <sp/spParamField.h>
#include <sp/spCanvas.h>
#include <sp/spDraw.h>

#include <sp/spDialogP.h>
#include <sp/spGraphicsP.h>
#include <sp/spDialogBoxP.h>

#if defined(MACOS)
#pragma import on
#endif

extern spTopLevel sp_toplevel;

#if defined(MACOS)
#pragma import off
#endif

static spParamTable sp_dialog_box_param_tables[] = {
    {SppPopupStyle, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.popup_style), SP_MODAL_POPUP_STRING},
    {SppCloseStyle, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.close_style), /*SP_NO_CLOSE_STRING*/NULL},
    {SppDialogBoxButtonType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.button_type), SP_DB_OK_CANCEL_STRING},
    {SppResizable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.resize_flag), SP_FALSE_STRING},
    {SppIconfiable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.iconfy_flag), SP_FALSE_STRING},
    {SppSimplifiable, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.simplify_flag), SP_FALSE_STRING},
    {SppParentWindow, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDialogBox, dialog_box.parent_window), NULL},
};

spDialogBoxClassRec SpDialogBoxClassRec = {
    /* spObjectClassPart */
    {
	SpDialogBox,
	(spObjectClass)&SpComponentClassRec,
	sizeof(spDialogBoxRec),
	spArraySize(sp_dialog_box_param_tables),
	sp_dialog_box_param_tables,
	spDialogBoxPartInit,
	spDialogBoxPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spDialogBoxCreate,
	spDialogBoxDestroy,
	spDialogBoxSetParams,
	NULL,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_TRUE,
	SP_TRUE,
	spDialogBoxMap,
	spDialogBoxUnmap,
	spDialogBoxSetSize,
	spDialogBoxGetSize,
	spDialogBoxGetClientSize,
	spDialogBoxSetSensitive,
	spDialogBoxIsComponentType,
	
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spDialogBoxClassPart */
    {
	0,
    },
};

spComponentClass SpDialogBoxClass = (spComponentClass)&SpDialogBoxClassRec;

void spDialogBoxPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpDialogBoxPart(component).window = NULL;
    SpDialogBoxPart(component).box = NULL;
    SpDialogBoxPart(component).separator = NULL;
    SpDialogBoxPart(component).button_box = NULL;
    SpDialogBoxPart(component).ok_button = NULL;
    SpDialogBoxPart(component).cancel_button = NULL;
    SpDialogBoxPart(component).apply_button = NULL;
    SpDialogBoxPart(component).close_style = SP_NO_CLOSE;
    SpDialogBoxPart(component).parent_window = NULL;
    
    SpComponentPart(component).orientation = SP_VERTICAL;
    SpComponentPart(component).margin_width = SP_DEFAULT_MARGIN;
    SpComponentPart(component).margin_height = SP_DEFAULT_MARGIN;
    SpComponentPart(component).spacing = SP_DEFAULT_SPACING;

    return;
}

void spDialogBoxPartFree(spObject object)
{
    return;
}

void spDialogBoxCreate(spObject object)
{
    int i;
    char *title;
    int box_size;
    int num_button;
    spComponent component = (spComponent)object;

    if (SpComponentPart(component).title == NULL) {
	title = SpGetName(component);
    } else {
	title = SpComponentPart(component).title;
    }

    /* create dialog window */
    SpDialogBoxPart(component).window =
	spCreateFrame("_DialogBox_Window",
		      SppWindowType, SP_DIALOG_WINDOW,
		      SppTitle, title,
		      SppPopupStyle, SpDialogBoxPart(component).popup_style,
		      SppCloseStyle, SpDialogBoxPart(component).close_style,
		      SppResizable, SpDialogBoxPart(component).resize_flag,
		      SppIconfiable, SpDialogBoxPart(component).iconfy_flag,
		      SppSimplifiable, SpDialogBoxPart(component).simplify_flag,
		      SppParentWindow, SpDialogBoxPart(component).parent_window,
		      SppGroupId, SpComponentPart(component).group_id,
		      SppUserData, SpComponentPart(component).user_data,
		      SppMarginWidth, SP_DEFAULT_DIALOG_MARGIN,
		      SppMarginHeight, SP_DEFAULT_DIALOG_MARGIN,
		      SppSpacing, 0,
		      NULL);

    /* create main box */
    box_size = -(SP_DEFAULT_BUTTON_HEIGHT + 2 * SP_DEFAULT_DIALOG_BUTTON_MARGIN);
    SpDialogBoxPart(component).box =
	spCreateBox(SpDialogBoxPart(component).window, "_DialogBox_MainBox", box_size,
		    SppOrientation, SpComponentPart(component).orientation,
		    SppMarginWidth, SpComponentPart(component).margin_width,
		    SppMarginHeight, SpComponentPart(component).margin_height,
		    SppSpacingOn, SpComponentPart(component).spacing_flag,
		    SppSpacing, SpComponentPart(component).spacing,
		    NULL);
	
    /* create box for buttons */
    SpDialogBoxPart(component).button_box =
	spCreateBox(SpDialogBoxPart(component).window, "_DialogBox_ButtonBox", 0,
		    SppOrientation, SP_HORIZONTAL,
		    SppMarginWidth, SP_DEFAULT_DIALOG_BUTTON_MARGIN,
		    SppMarginHeight, SP_DEFAULT_DIALOG_BUTTON_MARGIN,
		    SppSpacing, SP_DEFAULT_DIALOG_BUTTON_SPACING,
		    NULL);

    num_button = 0;
    for (i = 0; i < 3; i++) {
	switch (i) {
	  case SP_DIALOG_OK_BUTTON_ORDER:
	    switch (SpDialogBoxPart(component).button_type) {
	      case SP_DB_YES_NO:
	      case SP_DB_YES_NO_CANCEL:
		/* create yes button */
		SpDialogBoxPart(component).ok_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_YesButton",
				       SppTitle, SP_YES_LABEL,
				       SppDefaultButton, SP_TRUE,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	      case SP_DB_RETRY_CANCEL:
		/* create retry button */
		SpDialogBoxPart(component).ok_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_RetryButton",
				       SppTitle, SP_RETRY_LABEL,
				       SppDefaultButton, SP_TRUE,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	      default:
		/* create OK button */
		SpDialogBoxPart(component).ok_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_OkButton",
				       SppTitle, SP_OK_LABEL,
				       SppDefaultButton, SP_TRUE,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	    }
	    break;
	    
	  case SP_DIALOG_CANCEL_BUTTON_ORDER:
	    switch (SpDialogBoxPart(component).button_type) {
	      case SP_DB_OK_CANCEL:
	      case SP_DB_RETRY_CANCEL:
	      case SP_DB_OK_CANCEL_APPLY:
		/* create cancel button */
		SpDialogBoxPart(component).cancel_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_CancelButton",
				       SppTitle, SP_CANCEL_LABEL,
				       SppCancelButton, SP_TRUE,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	      case SP_DB_YES_NO:
	      case SP_DB_YES_NO_CANCEL:
		/* create no button */
		SpDialogBoxPart(component).cancel_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_NoButton",
				       SppTitle, SP_NO_LABEL,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	    }
	    break;
	    
	  case SP_DIALOG_APPLY_BUTTON_ORDER:
	    switch (SpDialogBoxPart(component).button_type) {
	      case SP_DB_OK_CANCEL_APPLY:
		/* create apply button */
		SpDialogBoxPart(component).apply_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_ApplyButton",
				       SppTitle, SP_APPLY_LABEL,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	      case SP_DB_YES_NO_CANCEL:
		/* create cancel button */
		SpDialogBoxPart(component).apply_button =
		    spCreatePushButton(SpDialogBoxPart(component).button_box, "_CancelButton",
				       SppTitle, SP_CANCEL_LABEL,
				       SppCancelButton, SP_TRUE,
				       SppCallbackFunc, SpComponentPart(component).call_func,
				       SppCallbackData, SpComponentPart(component).call_data,
				       NULL);
		num_button++;
		break;
	    }
	    break;
	}
    }

    SpComponentPart(component).component = SpDialogBoxPart(component).box;
    SpGetWindow(component) = SpDialogBoxPart(component).window;

    return;
}

void spDialogBoxDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    spDestroyWindow(SpGetWindow(component));

    return;
}

void spDialogBoxSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    spSetParams(SpDialogBoxPart(component).window,
		SppTitle, SpComponentPart(component).title,
		NULL);
    
    return;
}

void spDialogBoxMap(spComponent component)
{
    spPopupWindow(SpGetWindow(component));
    
    return;
}

void spDialogBoxUnmap(spComponent component)
{
    spPopdownWindow(SpGetWindow(component));
    
    return;
}

spBool spDialogBoxSetSize(spComponent component, int width, int height)
{
    return spSetSize(SpGetWindow(component), width, height);
}

spBool spDialogBoxGetSize(spComponent component, int *width, int *height)
{
    return spGetSize(SpGetWindow(component), width, height);
}

spBool spDialogBoxGetClientSize(spComponent component, int *width, int *height)
{
    return spGetClientSize(SpGetWindow(component), width, height);
}

spBool spDialogBoxSetSensitive(spComponent component, spBool flag)
{
    return spSetSensitive(SpGetWindow(component), flag);
}

spBool spDialogBoxIsComponentType(spComponent component, char *class_name)
{
    if (streq(class_name, SpDialog)) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spIsDialogBox(spComponent component)
{
    return spIsSubClass(component, SpDialogBox);
}

spComponent spCreateDialogBox(char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (sp_toplevel == NULL) spError(1, "spInitialize should be called.\n");
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    spDebug(60, "spCreateDialogBox", "spGetArgs done\n");
    
    return spCreateComponentArg(SpDialogBoxClass, NULL, name, NULL, args, num_arg);
}

void spGetOptionDialogData(spComponent component)
{
    spBool set;
    char *string;
    spComponent child;
    spOption *option;

    child = spGetWindow(component);
    while ((child = spGetChild(child)) != NULL) {
	if ((option = (spOption *)spGetUserData(child)) != NULL) {
	    break;
	}
    }
    
    while (child != NULL) {
	spDebug(60, "spGetOptionDialogData", "class_name = %s\n", SpGetClassName(child));
    
	if ((option = (spOption *)spGetUserData(child)) != NULL) {
	    if (spEqType(option->type, SP_TYPE_BOOL)) {
		if (spGetToggleState(child, &set) == SP_TRUE) {
		    if (set == SP_TRUE) {
			spConvertOptionValue(option, "True");
		    } else {
			spConvertOptionValue(option, "False");
		    }
		}
	    } else if ((string = xspGetTextString(child)) != NULL) {
		spDebug(60, "spGetOptionDialogData", "string = %s\n", string);
	    
		/* set option value */
		spConvertOptionValue(option, string);
	    
		xfree(string);
	    }
	}

	child = spGetNextComponent(child);
    }
    
    return;
}

void spPopdownOptionDialogCB(spComponent component, void *data)
{
    spCallbackReason reason = SP_CR_NONE;
    
    reason = spGetCallbackReason(component);

    if (reason == SP_CR_OK || reason == SP_CR_APPLY) {
	spGetOptionDialogData(component);
    }
    
    if (reason == SP_CR_OK || reason == SP_CR_CANCEL) {
	spPopdownWindow(component);
    }

    return;
}

spComponent spCreateOptionDialog(char *name, spOptions options, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    int num_option;
    spOption *option_list;
    int i, j;
    char *desc;
    char *string;
    char title[SP_MAX_LINE];
    char dimention[SP_MAX_LINE];
    spBool flag;
    spBool edit_flag;
    int field_height;
    int field_offset, field_size;
    spComponent dialog, component;

    if (sp_toplevel == NULL) spError(1, "spInitialize should be called.\n");
    if (options == NULL) return NULL;

    va_start(argp, options);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    /* create dialog box */
    dialog = spCreateComponentArg(SpDialogBoxClass, NULL, name, NULL, args, num_arg);
    
    num_option = spGetNumOption(options);
    option_list = spGetOptionList(options);
    
    spDebug(80, "spCreateOptionDialog", "num_option = %d\n", num_option);

    field_height = 0;
    for (i = 0; i < num_option; i++) {
	if (spEqType(option_list[i].type, SP_TYPE_EDITABLE)) {
	    edit_flag = SP_TRUE;
	} else {
	    edit_flag = SP_FALSE;
	}

	if ((string = xspGetOptionLabel(&option_list[i], 1)) != NULL) {
	    strcpy(title, string);
	    xfree(string);
	} else {
	    strcpy(title, "");
	}
	if ((string = xspGetOptionLabel(&option_list[i], 4)) != NULL) {
	    strcpy(dimention, string);
	    xfree(string);
	} else {
	    strcpy(dimention, "");
	}

	if ((string = xspGetOptionLabel(&option_list[i], 2)) != NULL) {
	    field_offset = atoi(string);
	    xfree(string);
	} else {
	    field_offset = 0;
	}
	if ((string = xspGetOptionLabel(&option_list[i], 3)) != NULL) {
	    field_size = atoi(string);
	    xfree(string);
	} else {
	    field_size = 0;
	}

	spDebug(60, "spCreateOptionDialog", "title = %s\n", title);

	if (spEqType(option_list[i].type, SP_TYPE_SHOW_TIP)) {
	    desc = option_list[i].desc;
	} else {
	    desc = NULL;
	}
	
	if (spEqType(option_list[i].type, SP_TYPE_BOOL)) {
	    if (option_list[i].def_value == NULL) {
		flag = SP_FALSE;
	    } else {
		flag = spStrToBool(option_list[i].def_value);
	    }
	    
	    /* create check box */
	    component = spCreateCheckBox(dialog, "checkBox",
					 SppTitle, title,
					 SppSet, flag,
					 SppDescription, desc,
					 SppUserData, &option_list[i],
					 NULL);
	} else if (spEqType(option_list[i].type, SP_TYPE_COMBO)
		   || spEqType(option_list[i].type, SP_TYPE_LIST)) {
	    spDebug(60, "spCreateOptionDialog", "field_offset = %d, field_size = %d\n",
		    field_offset, field_size);
	    
	    /* create combo box */
	    component = spCreateParamField(dialog, "comboBox", field_height,
					   SppTitle, title,
					   SppDimention, dimention,
					   SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
					   /*SppFieldType, SP_FIELD_TYPE_TEXT,*/
					   SppEditable, edit_flag,
					   SppFieldOffset, field_offset,
					   SppFieldSize, field_size,
					   SppDescription, desc,
					   SppUserData, &option_list[i],
					   NULL);

	    if (option_list[i].def_value != NULL) {
		spDebug(80, "spCreateOptionDialog", "option_list[%d].def_value = %s\n",
			i, option_list[i].def_value);
	    
		for (j = 0;; j++) {
		    if ((string = xspCutOptionValue(option_list[i].def_value, j)) == NULL) {
			break;
		    }
		    spDebug(100, "spCreateOptionDialog", "j = %d, string = %s\n", j, string);

		    spAddListItem(component, string);
		    xfree(string);
		}
		if ((string = xspCutOptionValue(option_list[i].def_value, -1)) != NULL) {
		    spDebug(1, "spCreateOptionDialog", "default string = %s\n", string);
		    spSelectListItem(component, string);
		    xfree(string);
		} else {
		    spSelectListIndex(component, 0);
		}
	    }
	} else if (spEqType(option_list[i].type, SP_TYPE_STRING)
		   || spEqType(option_list[i].type, SP_TYPE_INT)
		   || spEqType(option_list[i].type, SP_TYPE_SHORT)
		   || spEqType(option_list[i].type, SP_TYPE_LONG)
		   || spEqType(option_list[i].type, SP_TYPE_FLOAT)
		   || spEqType(option_list[i].type, SP_TYPE_DOUBLE)
		   || spEqType(option_list[i].type, SP_TYPE_CHAR)
		   || spEqType(option_list[i].type, SP_TYPE_ENUM)
		   || spEqType(option_list[i].type, SP_TYPE_STRING_A)) {
	    component = spCreateParamField(dialog, "textField", field_height,
					   SppTitle, title,
					   SppDimention, dimention,
					   SppFieldType, SP_FIELD_TYPE_TEXT,
					   SppEditable, SP_TRUE,
					   SppFieldOffset, field_offset,
					   SppFieldSize, field_size,
					   SppDescription, desc,
					   SppUserData, &option_list[i],
					   NULL);
	    if (option_list[i].def_value != NULL) {
		spSetTextString(component, option_list[i].def_value);
	    }
	}
	
	spDebug(80, "spCreateOptionDialog", "done: i = %d\n", i);
    }

    return dialog;
}

typedef struct _spFontSelectionStyleTable {
    char *style_name;
    unsigned long style_mask;
} spFontSelectionStyleTable;
    
typedef struct _spFontSelectionDialog {
    spComponent component;
    spComponent dialog;
    
    spComponent family_field;
    spComponent style_field;
    spComponent size_field;
    
    spGraphics graphics;
    spComponent sample_box;
    spComponent sample_canvas;
    
    int num_style_table;
    spFontSelectionStyleTable *style_table;

    spBool lock;
    
    spCallbackReason reason;
    char font_name[SP_MAX_FONTNAME];
} *spFontSelectionDialog;

static void updateFontName(spFontSelectionDialog dialog, int *pfamily, unsigned long *pstyle, int *psize)
{
    int j;
    int size = 0;
    unsigned long style = 0L;
    char *string;
    char family_string[SP_MAX_FONTNAME];

    if ((string = xspGetTextString(dialog->family_field)) != NULL) {
	strcpy(family_string, string);
	xfree(string);
    } else {
	strcpy(family_string, "*");
    }
	
    if ((string = xspGetTextString(dialog->style_field)) != NULL) {
	for (j = 0; j < dialog->num_style_table; j++) {
	    if (streq(string, dialog->style_table[j].style_name)) {
		style = dialog->style_table[j].style_mask;
		break;
	    }
	}
	xfree(string);
    }
	
    if ((string = xspGetTextString(dialog->size_field)) != NULL) {
	size = atoi(string);
	xfree(string);
    }

    spGetFontName(dialog->font_name, family_string, style, size);

    if (pfamily != NULL) {
	*pfamily = MAX(spGetSelectedListIndex(dialog->family_field), 0);
    }
    if (pstyle != NULL) *pstyle = style;
    if (psize != NULL) *psize = size;
    
    return;
}

static void popdownFontDialogCB(spComponent component, void *data)
{
    spFontSelectionDialog dialog = (spFontSelectionDialog)data;

    dialog->reason = spGetCallbackReason(component);
    spDebug(50, "popdownFontDialogCB", "reason = %d\n", dialog->reason);
    
    if (dialog->reason == SP_CR_OK) {
	updateFontName(dialog, NULL, NULL, NULL);
    } else {
	strcpy(dialog->font_name, "");
    }
    
    spPopdownWindow(component);
    
    spDebug(50, "popdownFontDialogCB", "done\n");
    
    return;
}

static void drawFontSample(spComponent canvas, spFontSelectionDialog dialog)
{
    int width, height;
    int sx, sy, swidth, sheight;
    
    if (dialog->lock == SP_TRUE) return;
    
    if (!strnone(dialog->font_name)) {
	spSetFont(dialog->graphics, dialog->font_name);
	spDebug(50, "drawFontSample", "font_name = %s\n", dialog->font_name);
    }
    if (spGetSize(canvas, &width, &height) == SP_TRUE
	&& spGetStringExtent(dialog->graphics, SP_FONT_SAMPLE_CONTENTS,
			     &sx, &sy, &swidth, &sheight) == SP_TRUE) {
	spDebug(50, "drawFontSample", "width = %d, height = %d, swidth = %d, sheight = %d\n",
		width, height, swidth, sheight);
	spDrawString(canvas, dialog->graphics, 5, 5 + MIN(sheight, height), SP_FONT_SAMPLE_CONTENTS);
    }
    
    return;
}

static void updateFontStyle(spFontSelectionDialog dialog, int family, int size)
{
    int j;
    spBool supported;
    char *selected_item;
    
    selected_item = xspGetSelectedListItem(dialog->style_field);
    
    while (spDeleteListIndex(dialog->style_field, 0) >= 0) ;
    spAddListItem(dialog->style_field, "*");

    for (j = 0; j < dialog->num_style_table; j++) {
	supported = spIsFontSizeSupportedArch(family,
					      dialog->style_table[j].style_mask, size);
	if (supported == SP_TRUE) {
	    spAddListItem(dialog->style_field, dialog->style_table[j].style_name);
	    spDebug(50, "updateFontStyle", "style %s: %d\n",
		    dialog->style_table[j].style_name, supported);
	}
    }

    if (selected_item == NULL
	|| spSelectListItem(dialog->style_field, selected_item) < 0) {
	spSelectListIndex(dialog->style_field, 0);
    } 
	
    if (selected_item != NULL) {
	spDebug(50, "updateFontStyle", "selected_item = %s\n", selected_item);
	xfree(selected_item);
    }

    return;
}

static void updateFontSize(spFontSelectionDialog dialog, int family, unsigned long style)
{
    int j;
    spBool supported;
    char *selected_item;
    char buf[SP_MAX_FONTNAME];
    static int font_sizes[] = {
	8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 56, 64, 72, 96, 144, 288, -1,
    };

    selected_item = xspGetSelectedListItem(dialog->size_field);
    
    while (spDeleteListIndex(dialog->size_field, 0) >= 0) ;
    spAddListItem(dialog->size_field, "*");

    for (j = 0; font_sizes[j] > 0; j++) {
	supported = spIsFontSizeSupportedArch(family, style, font_sizes[j]);
	if (supported == SP_TRUE) {
	    sprintf(buf, "%d", font_sizes[j]);
	    spAddListItem(dialog->size_field, buf);
	}
	spDebug(50, "updateFontSize", "size %d: %d\n", font_sizes[j], supported);
    }
    
    if (selected_item == NULL
	|| spSelectListItem(dialog->size_field, selected_item) < 0) {
	spSelectListIndex(dialog->size_field, 0);
    }
	
    if (selected_item != NULL) {
	spDebug(50, "updateFontSize", "selected_item = %s\n", selected_item);
	xfree(selected_item);
    }
    
    return;
}

static void changeFontStyle(spComponent component, spFontSelectionDialog dialog)
{
    int family = 0, size = 0;
    unsigned long style = 0;

    if (dialog->lock == SP_TRUE) return;
    
    updateFontName(dialog, &family, &style, &size);
    updateFontSize(dialog, family, size);
    spRedrawCanvas(dialog->sample_canvas);

    spDebug(50, "changeFontStyle", "family = %d, size = %d\n", family, size);
    
    return;
}

static void changeFontSize(spComponent component, spFontSelectionDialog dialog)
{
    int family = 0, size = 0;
    unsigned long style = 0;
    
    if (dialog->lock == SP_TRUE) return;
    
    updateFontName(dialog, &family, &style, &size);
    spRedrawCanvas(dialog->sample_canvas);

    return;
}

static void selectFontFamily(spComponent component, spFontSelectionDialog dialog)
{
    int family;
	    
    if ((family = spGetSelectedListIndex(dialog->family_field)) >= 0
	&& spIsCreated(dialog->size_field) == SP_TRUE) {
	spDebug(50, "selectFontFamily", "family = %d\n", family);

	dialog->lock = SP_TRUE;

	updateFontStyle(dialog, family, 0);
	updateFontSize(dialog, family, 0);

	updateFontName(dialog, NULL, NULL, NULL);
	
	dialog->lock = SP_FALSE;
	
	spRedrawCanvas(dialog->sample_canvas);
    }
    
    return;
}

char *xspChooseFontDefault(spComponent component)
{
    char **family_list;
    static spFontSelectionDialog dialog = NULL;

    if (dialog == NULL) {
	dialog = xalloc(1, struct _spFontSelectionDialog);
	dialog->component = component;
	dialog->family_field = NULL;
	dialog->style_field = NULL;
	dialog->size_field = NULL;
	dialog->lock = SP_FALSE;
	
	dialog->num_style_table = 12;
	dialog->style_table = NULL;
	
	dialog->style_table = xalloc(dialog->num_style_table, spFontSelectionStyleTable);
	dialog->style_table[0].style_name = SP_FONT_STYLE_MEDIUM_LABEL;
	dialog->style_table[0].style_mask = SP_FONT_STYLE_MEDIUM;
	dialog->style_table[1].style_name = SP_FONT_STYLE_ITALIC_LABEL;
	dialog->style_table[1].style_mask = SP_FONT_STYLE_ITALIC;
	dialog->style_table[2].style_name = SP_FONT_STYLE_OBLIQUE_LABEL;
	dialog->style_table[2].style_mask = SP_FONT_STYLE_OBLIQUE;
	dialog->style_table[3].style_name = SP_FONT_STYLE_BOLD_LABEL;
	dialog->style_table[3].style_mask = SP_FONT_STYLE_BOLD;
	dialog->style_table[4].style_name = SP_FONT_STYLE_BOLD_ITALIC_LABEL;
	dialog->style_table[4].style_mask = SP_FONT_STYLE_BOLD_ITALIC;
	dialog->style_table[5].style_name = SP_FONT_STYLE_BOLD_OBLIQUE_LABEL;
	dialog->style_table[5].style_mask = SP_FONT_STYLE_BOLD_OBLIQUE;
	dialog->style_table[6].style_name = SP_FONT_STYLE_LIGHT_LABEL;
	dialog->style_table[6].style_mask = SP_FONT_STYLE_LIGHT;
	dialog->style_table[7].style_name = SP_FONT_STYLE_LIGHT_ITALIC_LABEL;
	dialog->style_table[7].style_mask = SP_FONT_STYLE_LIGHT_ITALIC;
	dialog->style_table[8].style_name = SP_FONT_STYLE_LIGHT_OBLIQUE_LABEL;
	dialog->style_table[8].style_mask = SP_FONT_STYLE_LIGHT_OBLIQUE;
	dialog->style_table[9].style_name = SP_FONT_STYLE_BLACK_LABEL;
	dialog->style_table[9].style_mask = SP_FONT_STYLE_BLACK;
	dialog->style_table[10].style_name = SP_FONT_STYLE_BLACK_ITALIC_LABEL;
	dialog->style_table[10].style_mask = SP_FONT_STYLE_BLACK_ITALIC;
	dialog->style_table[11].style_name = SP_FONT_STYLE_BLACK_OBLIQUE_LABEL;
	dialog->style_table[11].style_mask = SP_FONT_STYLE_BLACK_OBLIQUE;
	
	dialog->graphics = spCreateGraphics("_FontSelectionGraphics",
					    SppLineWidth, 1,
					    NULL);
	
	dialog->dialog = spCreateDialogBox("_FontSelectionDialog",
					   SppTitle, SP_FONT_SELECTION_TITLE,
					   SppCloseStyle, SP_UNMAP_CLOSE,
					   SppCallbackFunc, popdownFontDialogCB,
					   SppCallbackData, dialog,
					   NULL);
	
	family_list = spGetFontFamilyListArch();

	dialog->family_field = spCreateParamField(dialog->dialog, "_FontSelectionFamilyField", 0,
						  SppTitle, SP_FONT_FAMILY_LABEL,
						  SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
						  SppFieldOffset, 120,
						  SppFieldSize, 180,
						  SppFieldStrings, family_list,
						  SppEditable, SP_FALSE,
						  SppCallbackFunc, selectFontFamily,
						  SppCallbackData, dialog,
						  NULL);
	spSelectListIndex(dialog->family_field, 0);
	
	dialog->style_field = spCreateParamField(dialog->dialog, "_FontSelectionStyleField", 0,
						 SppTitle, SP_FONT_STYLE_LABEL,
						 SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
						 SppFieldOffset, 120,
						 SppFieldSize, 180,
						 SppEditable, SP_FALSE,
						 SppCallbackFunc, changeFontStyle,
						 SppCallbackData, dialog,
						 NULL);
	dialog->size_field = spCreateParamField(dialog->dialog, "_FontSelectionSizeField", 0,
						SppTitle, SP_FONT_SIZE_LABEL,
						SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
						SppFieldOffset, 120,
						SppFieldSize, 180,
						SppEditable, SP_FALSE,
						SppCallbackFunc, changeFontSize,
						SppCallbackData, dialog,
						NULL);

	dialog->sample_box = spCreateBox(dialog->dialog, "_FontSelectionSampleBox", 80,
					 SppTitle, SP_FONT_SAMPLE_LABEL,
					 SppSpacingOn, SP_TRUE,
					 SppBorderOn, SP_TRUE,
					 SppTitleOn, SP_TRUE,
					 NULL);
	dialog->sample_canvas = spCreateCanvas(dialog->sample_box, "_FontSelectionSampleCanvas",
					       300, 60,
					       SppSpacingOn, SP_TRUE,
					       /*SppBorderOn, SP_TRUE,*/
					       SppCallbackFunc, drawFontSample,
					       SppCallbackData, dialog,
					       SppDrawBackground, SP_TRUE,
					       NULL);

	selectFontFamily(dialog->family_field, dialog);
    }

    dialog->reason = SP_CR_NONE;
    strcpy(dialog->font_name, "");
    
    spPopupWindow(dialog->dialog);

    if (dialog->reason == SP_CR_OK && !strnone(dialog->font_name)) {
	return strclone(dialog->font_name);
    }
    
    return NULL;
}

typedef struct _spColorSelectionDialog {
    spComponent component;
    spComponent dialog;
    
    spGraphics graphics;
    spGraphics cursor_graphics;

    spComponent canvas_box;
    int hs_cursor_x, hs_cursor_y;
    int hs_width, hs_height;
    spComponent hs_canvas;
    int l_cursor_y;
    int l_width, l_height;
    spComponent l_canvas;

    spComponent field_box;
    
    spComponent preview_canvas;
    
    spComponent hsl_box;
    spComponent h_field;
    spComponent s_field;
    spComponent l_field;
    
    spComponent rgb_box;
    spComponent r_field;
    spComponent g_field;
    spComponent b_field;

    spBool lock;
    spPixel pixel;
    spPixel prev_pixel;
    
    spCallbackReason reason;
} *spColorSelectionDialog;

static void popdownColorDialogCB(spComponent component, void *data)
{
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    dialog->reason = spGetCallbackReason(component);
    
    spPopdownWindow(component);
    
    spDebug(50, "popdownColorDialogCB", "done\n");
    
    return;
}

#define convRGBToPixel(r, g, b) spRGB(spRound(2.55 * (r)), spRound(2.55 * (g)), spRound(2.55 * (b)))

static void getRGB(spPixel pixel, double *r, double *g, double *b)
{
    *r = (double)spGetRValue(pixel)/2.55;
    *g = (double)spGetGValue(pixel)/2.55;
    *b = (double)spGetBValue(pixel)/2.55;
    return;
}

static void getHSL(spPixel pixel, double *h, double *s, double *l)
{
    double r, g, b;
    
    getRGB(pixel, &r, &g, &b);
    spRgbToHsl(r/100.0, g/100.0, b/100.0, h, s, l);
    *s *= 100.0; *l *= 100.0;
    
    return;
}

static void convHSLToRGB(double h, double s, double l,
			 double *r, double *g, double *b)
{
    spHslToRgb(h, s/100.0, l/100.0, r, g, b);
    *r *= 100.0; *g *= 100.0; *b *= 100.0;
    
    return;
}

static spPixel convHSLToPixel(double h, double s, double l)
{
    double r, g, b;

    convHSLToRGB(h, s, l, &r, &g, &b);
    
    return convRGBToPixel(r, g, b);
}

static void updateHSL(spColorSelectionDialog dialog, double h, double s, double l)
{
    char buf[SP_MAX_LINE];
    
    sprintf(buf, "%.0f", h); spSetTextString(dialog->h_field, buf);
    sprintf(buf, "%.0f", s); spSetTextString(dialog->s_field, buf);
    sprintf(buf, "%.0f", l); spSetTextString(dialog->l_field, buf);

    return;
}

static void updateRGB(spColorSelectionDialog dialog, double r, double g, double b)
{
    char buf[SP_MAX_LINE];
    
    sprintf(buf, "%.0f", r); spSetTextString(dialog->r_field, buf);
    sprintf(buf, "%.0f", g); spSetTextString(dialog->g_field, buf);
    sprintf(buf, "%.0f", b); spSetTextString(dialog->b_field, buf);

    return;
}

static void drawHSCursor(spColorSelectionDialog dialog, int x, int y)
{
    spDrawLine(dialog->hs_canvas, dialog->cursor_graphics,
	       x-10, y, x-5, y);
    spDrawLine(dialog->hs_canvas, dialog->cursor_graphics,
	       x+5, y, x+10, y);
    spDrawLine(dialog->hs_canvas, dialog->cursor_graphics,
	       x, y-10, x, y-5);
    spDrawLine(dialog->hs_canvas, dialog->cursor_graphics,
	       x, y+5, x, y+10);
    
    return;
}

static void drawLCursor(spColorSelectionDialog dialog, int y)
{
    spDrawLine(dialog->l_canvas, dialog->cursor_graphics,
	       0, y, 5, y);
    spDrawLine(dialog->l_canvas, dialog->cursor_graphics,
	       dialog->l_width, y, dialog->l_width - 5, y);
    
    return;
}

static void updateHSCursor(spColorSelectionDialog dialog, int x, int y)
{
    if (dialog->hs_cursor_x >= 0) {
	drawHSCursor(dialog, dialog->hs_cursor_x, dialog->hs_cursor_y);
    }
	
    dialog->hs_cursor_x = x;
    dialog->hs_cursor_y = y;
    drawHSCursor(dialog, dialog->hs_cursor_x, dialog->hs_cursor_y);
    
    spRefreshCanvas(dialog->hs_canvas);
    
    return;
}

static void updateLCursor(spColorSelectionDialog dialog, int y)
{
    if (dialog->l_cursor_y >= 0) {
	drawLCursor(dialog, dialog->l_cursor_y);
    }
	
    dialog->l_cursor_y = y;
    drawLCursor(dialog, dialog->l_cursor_y);
	
    spRefreshCanvas(dialog->l_canvas);
    
    return;
}

static void updateCursor(spColorSelectionDialog dialog)
{
    int x, y;
    double h, s, l;

    getHSL(dialog->pixel, &h, &s, &l);
    
    x = (int)spRound(h * (double)dialog->hs_width / 360.0);
    y = (int)spRound((100.0 - s) * (double)dialog->hs_height / 100.0);
    updateHSCursor(dialog, x, y);
    
    y = (int)spRound((100.0 - l) * (double)dialog->l_height / 100.0);
    updateLCursor(dialog, y);
    
    return;
}

static void drawHSCanvasCB(spComponent canvas, void *data)
{
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;
    
    if (dialog->lock == SP_TRUE) return;
    
    dialog->lock = SP_TRUE;
    
    spDebug(80, "drawHSCanvasCB", "hs_width = %d, hs_height = %d\n",
	    dialog->hs_width, dialog->hs_height);
    
    if (dialog->hs_width <= 0) {
	int x, y;
	double h, s, l;
	double hf, sf;
	spPixel pixel;
	
	spGetSize(canvas, &dialog->hs_width, &dialog->hs_height);

	l = 50.0;
	hf = 360.0 / (double)dialog->hs_width;
	sf = 100.0 / (double)dialog->hs_height;
	
	for (y = 0; y <= dialog->hs_height; y++) {
	    s = 100.0 - sf * (double)y;
	    
	    for (x = 0; x <= dialog->hs_width; x++) {
		h = hf * (double)x;
		
		pixel = convHSLToPixel(h, s, l);
		spSetForegroundPixel(dialog->graphics, pixel);
		spDrawPoint(canvas, dialog->graphics, x, y);
	    }
	}
	
	getHSL(dialog->pixel, &h, &s, &l);
	dialog->hs_cursor_x = (int)spRound(h * (double)dialog->hs_width / 360.0);
	dialog->hs_cursor_y = (int)spRound((100.0 - s) * (double)dialog->hs_height / 100.0);
    
	if (dialog->hs_cursor_x >= 0) {
	    drawHSCursor(dialog, dialog->hs_cursor_x, dialog->hs_cursor_y);
	}
    }
    
    dialog->lock = SP_FALSE;
	
    return;
}

static void drawLCanvasCB(spComponent canvas, void *data)
{
    int y;
    double h, s, l;
    double lf;
    spPixel pixel;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;
    
    if (dialog->lock == SP_TRUE) return;
    
    dialog->lock = SP_TRUE;
    
    getHSL(dialog->pixel, &h, &s, &l);
    
    if (dialog->l_width <= 0) {
	spGetSize(canvas, &dialog->l_width, &dialog->l_height);
	dialog->l_cursor_y = (int)spRound((100.0 - l) * (double)dialog->l_height / 100.0);
    }

    lf = 100.0 / (double)dialog->l_height;
    
    for (y = 0; y <= dialog->l_height; y++) {
	l = 100.0 - lf * (double)y;
	pixel = convHSLToPixel(h, s, l);
	spSetForegroundPixel(dialog->graphics, pixel);
	spDrawLine(canvas, dialog->graphics, 0, y, dialog->l_width, y);
    }

    if (dialog->l_cursor_y >= 0) {
	drawLCursor(dialog, dialog->l_cursor_y);
    }
    
    dialog->lock = SP_FALSE;
    
    return;
}

static void drawPreviewCanvasCB(spComponent canvas, void *data)
{
    int width, height;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    if (dialog->lock == SP_TRUE) return;

    if (spGetSize(canvas, &width, &height) == SP_TRUE) {
	spSetForegroundPixel(dialog->graphics, dialog->pixel);
	spFillRectangle(canvas, dialog->graphics, 0, 0, width, height/2);

	spSetForegroundPixel(dialog->graphics, dialog->prev_pixel);
	spFillRectangle(canvas, dialog->graphics, 0, height/2, width, height/2);
    }
    
    return;
}

static void changeColorCB(spComponent component, void *data)
{
    double r, g, b;
    double h, s, l;
    char *string;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    if (dialog->lock == SP_TRUE || dialog->hs_width <= 0 || dialog->l_width <= 0) return;

    dialog->lock = SP_TRUE;

    h = s = l = 0.0;
    if ((string = xspGetTextString(dialog->h_field)) != NULL) {
	h = atof(string);
	xfree(string);
    }
    if ((string = xspGetTextString(dialog->s_field)) != NULL) {
	s = atof(string);
	xfree(string);
    }
    if ((string = xspGetTextString(dialog->l_field)) != NULL) {
	l = atof(string);
	xfree(string);
    }

    h = MAX(MIN(h, 360.0), 0.0);
    s = MAX(MIN(s, 100.0), 0.0);
    l = MAX(MIN(l, 100.0), 0.0);
    
    spDebug(50, "changeColorCB", "h = %f, s = %f, l = %f\n", h, s, l);

    spHslToRgb(h, s/100.0, l/100.0, &r, &g, &b);
    r *= 100.0; g *= 100.0; b *= 100.0;
    
    updateRGB(dialog, r, g, b);
    dialog->pixel = convRGBToPixel(r, g, b);
    
    dialog->lock = SP_FALSE;

    updateCursor(dialog);
    
    spRedrawCanvas(dialog->preview_canvas);
    spRedrawCanvas(dialog->l_canvas);
    
    return;
}

static void changeRGBColorCB(spComponent component, void *data)
{
    double r, g, b;
    char *string;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    if (dialog->lock == SP_TRUE || dialog->hs_width <= 0 || dialog->l_width <= 0) return;

    dialog->lock = SP_TRUE;

    r = g = b = 0.0;
    if ((string = xspGetTextString(dialog->r_field)) != NULL) {
	r = atof(string);
	xfree(string);
    }
    if ((string = xspGetTextString(dialog->g_field)) != NULL) {
	g = atof(string);
	xfree(string);
    }
    if ((string = xspGetTextString(dialog->b_field)) != NULL) {
	b = atof(string);
	xfree(string);
    }

    r = MAX(MIN(r, 100.0), 0.0);
    g = MAX(MIN(g, 100.0), 0.0);
    b = MAX(MIN(b, 100.0), 0.0);
    
    spDebug(50, "changeRGBColorCB", "r = %f, g = %f, b = %f\n", r, g, b);

    dialog->pixel = convRGBToPixel(r, g, b);
    
    dialog->lock = SP_FALSE;

    updateCursor(dialog);
    
    spRedrawCanvas(dialog->preview_canvas);
    spRedrawCanvas(dialog->l_canvas);
    
    return;
}

static void HSCanvasMotionCB(spComponent component, void *data)
{
    int x, y;
    double h, s, l;
    double r, g, b;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    if (dialog->lock == SP_TRUE || dialog->hs_width <= 0) return;
    
    if (spGetCallbackMousePosition(component, &x, &y) == SP_TRUE) {
	dialog->lock = SP_TRUE;

	x = MAX(MIN(x, dialog->hs_width), 0);
	y = MAX(MIN(y, dialog->hs_height), 0);

	spDebug(50, "HSCanvasMotionCB", "x = %d, y = %d\n", x, y);
    
	getHSL(dialog->pixel, &h, &s, &l);
	
	h = 360.0 * (double)x / (double)dialog->hs_width;
	s = 100.0 * (1.0 - (double)y / (double)dialog->hs_height);

	updateHSL(dialog, h, s, l);

	convHSLToRGB(h, s, l, &r, &g, &b);
	updateRGB(dialog, r, g, b);
	dialog->pixel = convRGBToPixel(r, g, b);
	
	dialog->lock = SP_FALSE;
	
	spRedrawCanvas(dialog->preview_canvas);
	spRedrawCanvas(dialog->l_canvas);

	updateHSCursor(dialog, x, y);
    }
    
    return;
}

static void LCanvasMotionCB(spComponent component, void *data)
{
    int x, y;
    double h, s, l;
    double r, g, b;
    spColorSelectionDialog dialog = (spColorSelectionDialog)data;

    if (dialog->lock == SP_TRUE || dialog->l_width <= 0) return;
    
    if (spGetCallbackMousePosition(component, &x, &y) == SP_TRUE) {
	dialog->lock = SP_TRUE;

	x = MAX(MIN(x, dialog->l_width), 0);
	y = MAX(MIN(y, dialog->l_height), 0);
	
	getHSL(dialog->pixel, &h, &s, &l);

	l = 100.0 * (1.0 - (double)y / (double)dialog->l_height);
	
	updateHSL(dialog, h, s, l);

	convHSLToRGB(h, s, l, &r, &g, &b);
	updateRGB(dialog, r, g, b);
	dialog->pixel = convRGBToPixel(r, g, b);
	
	dialog->lock = SP_FALSE;
	
	spRedrawCanvas(dialog->preview_canvas);
	updateLCursor(dialog, y);
    }
    
    return;
}

#define SP_HS_CANVAS_WIDTH 280
#define SP_HS_CANVAS_HEIGHT 200
#define SP_L_CANVAS_WIDTH 20

#define SP_PREVIEW_CANVAS_WIDTH 40
#define SP_PREVIEW_CANVAS_HEIGHT 80

char *xspChooseColorDefault(spComponent component)
{
    double r, g, b;
    double h, s, l;
    static spColorSelectionDialog dialog = NULL;

    if (dialog == NULL) {
	dialog = xalloc(1, struct _spColorSelectionDialog);
	dialog->pixel = 0L;
	dialog->prev_pixel = 0L;
	dialog->component = component;
	
	dialog->graphics = spCreateGraphics("_ColorSelectionGraphics",
					    SppLineWidth, 1,
					    NULL);

	dialog->cursor_graphics = spCreateGraphics("_ColorSelectionCursorGraphics",
						   SppForeground, "max",
						   SppGraphicsMode, SP_GM_XOR,
						   SppLineWidth, 3,
						   NULL);
	
	dialog->dialog = spCreateDialogBox("_ColorSelectionDialog",
					   SppTitle, SP_COLOR_SELECTION_TITLE,
					   SppCloseStyle, SP_UNMAP_CLOSE,
					   SppCallbackFunc, popdownColorDialogCB,
					   SppCallbackData, dialog,
					   NULL);
	
	dialog->canvas_box = spCreateBox(dialog->dialog, "_ColorSelectionSampleBox", 210,
					 SppOrientation, SP_HORIZONTAL,
					 NULL);
	dialog->hs_cursor_x = dialog->hs_cursor_y = -1;
	dialog->hs_width = dialog->hs_height = 0;
	dialog->hs_canvas = spCreateCanvas(dialog->canvas_box, "_ColorSelectionHSCanvas",
					   SP_HS_CANVAS_WIDTH, SP_HS_CANVAS_HEIGHT,
					   SppWidth, SP_HS_CANVAS_WIDTH,
					   SppSpacingOn, SP_TRUE,
					   SppBorderOn, SP_TRUE,
					   SppCallbackFunc, drawHSCanvasCB,
					   SppCallbackData, dialog,
					   NULL);
	spAddCallback(dialog->hs_canvas, SP_BUTTON_MOTION_CALLBACK
		      | SP_BUTTON_PRESS_CALLBACK | SP_BUTTON_RELEASE_CALLBACK,
		      HSCanvasMotionCB, dialog);
	
	dialog->l_cursor_y = -1;
	dialog->l_width = dialog->l_height = 0;
	dialog->l_canvas = spCreateCanvas(dialog->canvas_box, "_ColorSelectionLCanvas",
					  SP_L_CANVAS_WIDTH, SP_HS_CANVAS_HEIGHT,
					  SppWidth, SP_L_CANVAS_WIDTH,
					  SppSpacingOn, SP_TRUE,
					  SppBorderOn, SP_TRUE,
					  SppCallbackFunc, drawLCanvasCB,
					  SppCallbackData, dialog,
					  NULL);
	spAddCallback(dialog->l_canvas, SP_BUTTON_MOTION_CALLBACK
		      | SP_BUTTON_PRESS_CALLBACK | SP_BUTTON_RELEASE_CALLBACK,
		      LCanvasMotionCB, dialog);
	
	dialog->field_box = spCreateBox(dialog->dialog, "_ColorSelectionFieldBox", 0,
					SppOrientation, SP_HORIZONTAL,
					NULL);
	dialog->preview_canvas = spCreateCanvas(dialog->field_box, "_ColorSelectionPreviewCanvas",
						SP_PREVIEW_CANVAS_WIDTH, SP_PREVIEW_CANVAS_HEIGHT,
						SppWidth, SP_PREVIEW_CANVAS_WIDTH,
						SppSpacingOn, SP_TRUE,
						SppBorderOn, SP_TRUE,
						SppCallbackFunc, drawPreviewCanvasCB,
						SppCallbackData, dialog,
						NULL);
	
	dialog->hsl_box = spCreateBox(dialog->field_box, "_ColorSelectionHSLox", 130,
				      SppSpacingOn, SP_TRUE,
				      NULL);
	dialog->h_field = spCreateParamField(dialog->hsl_box, "_ColorSelectionHField", 0,
					     SppTitle, "Hue",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeColorCB,
					     SppCallbackData, dialog,
					     NULL);
	dialog->s_field = spCreateParamField(dialog->hsl_box, "_ColorSelectionSField", 0,
					     SppTitle, "Saturation",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeColorCB,
					     SppCallbackData, dialog,
					     NULL);
	dialog->l_field = spCreateParamField(dialog->hsl_box, "_ColorSelectionLField", 0,
					     SppTitle, "Lightness",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeColorCB,
					     SppCallbackData, dialog,
					     NULL);
	
	dialog->rgb_box = spCreateBox(dialog->field_box, "_ColorSelectionHSLBox", 0,
				      SppSpacingOn, SP_TRUE,
				      NULL);
	dialog->r_field = spCreateParamField(dialog->rgb_box, "_ColorSelectionRField", 0,
					     SppTitle, "Red",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeRGBColorCB,
					     SppCallbackData, dialog,
					     NULL);
	dialog->g_field = spCreateParamField(dialog->rgb_box, "_ColorSelectionGField", 0,
					     SppTitle, "Green",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeRGBColorCB,
					     SppCallbackData, dialog,
					     NULL);
	dialog->b_field = spCreateParamField(dialog->rgb_box, "_ColorSelectionBField", 0,
					     SppTitle, "Blue",
					     SppFieldOffset, 70,
					     SppFieldSize, 50,
					     SppSpacingOn, SP_FALSE,
					     SppEditable, SP_TRUE,
					     SppCallbackFunc, changeRGBColorCB,
					     SppCallbackData, dialog,
					     NULL);
    }

    if (!strnone(SpDialogPart(component).initial_color)) {
	dialog->pixel = spGetColorPixel(SpDialogPart(component).initial_color);
    }
    dialog->prev_pixel = dialog->pixel;
    dialog->reason = SP_CR_NONE;

    getRGB(dialog->pixel, &r, &g, &b);
    updateRGB(dialog, r, g, b);
    spDebug(50, "xspChooseColorDefault", "r = %f, g = %f, b = %f\n", r, g, b);

    getHSL(dialog->pixel, &h, &s, &l);
    updateHSL(dialog, h, s, l);
    spDebug(50, "xspChooseColorDefault", "h = %f, s = %f, l = %f\n", h, s, l);

    spPopupWindow(dialog->dialog);

    if (dialog->reason == SP_CR_OK) {
	char buf[SP_MAX_LINE];
	spGetColorName(dialog->pixel, buf);
	return strclone(buf);
    }
    
    return NULL;
}
