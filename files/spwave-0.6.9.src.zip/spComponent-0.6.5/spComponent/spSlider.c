/*
 *	spSlider.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>

#include <sp/spSliderP.h>

static spParamTable sp_slider_param_tables[] = {
    {SppShowScale, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.show_scale), SP_FALSE_STRING},
    {SppShowValue, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.show_value), SP_FALSE_STRING},
    {SppTrackCallbackOn, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.track_call_on), SP_FALSE_STRING},
    {SppValue, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.value), "0"},
    {SppMinimum, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.minimum), "0"},
    {SppMaximum, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.maximum), "100"},
    {SppPageSize, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.page_size), "100"},
    {SppIncrement, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.increment), "10"},
    {SppPageIncrement, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.page_increment), "100"},
    {SppDecimalPoints, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spSlider, slider.decimal_points), "0"},
};

spSliderClassRec SpSliderClassRec = {
    /* spObjectClassPart */
    {
	SpSlider,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spSliderRec),
	spArraySize(sp_slider_param_tables),
	sp_slider_param_tables,
	spSliderPartInit,
	spSliderPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spSliderCreate,
	NULL,
	spSliderSetParams,
	spSliderGetParams,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

    	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spSliderClassPart */
    {
	0,
    },
};

spComponentClass SpSliderClass = (spComponentClass)&SpSliderClassRec;

void spSliderPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).orientation = SP_HORIZONTAL;
    SpSliderPart(component).scroll_coef = 1;
    if (spIsSubClass(component, SpScrollBar) == SP_FALSE) {
	SpComponentPart(component).spacing_flag = SP_TRUE;
	SpSliderPart(component).page_increment = 10;
    }

    return;
}

void spSliderPartFree(spObject object)
{
    return;
}

void spSliderCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spSliderSetDefaultSize(component);
    
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	spTrackBarCreateArch(component);
    } else {
	spSliderCreateArch(component);
    }
	
    spShowToolTip(component);
    
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    
    return;
}

void spSliderSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	spTrackBarSetParamsArch(component);
    } else {
	spSliderSetParamsArch(component);
    }
    
    return;
}

void spSliderGetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spGetSliderValue(component, NULL);
    
    return;
}
    
void spSliderSetDefaultSize(spComponent component)
{
    int default_width = 0;
    int default_length = 0;
    
    if (spIsSubClass(component, SpSlider) == SP_FALSE)
	return;

    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	    default_width = SP_DEFAULT_HORIZONTAL_TRACKBAR_WIDTH;
	} else {
	    default_width = SP_DEFAULT_VERTICAL_TRACKBAR_WIDTH;
	}
	default_length = SP_DEFAULT_TRACKBAR_LENGTH;
    } else {
	default_width = SP_DEFAULT_SLIDER_WIDTH;
	default_length = SP_DEFAULT_SLIDER_LENGTH; 
    }
    spDebug(10, "spSliderSetDefaultSize", "default: width = %d, length = %d\n",
	    default_width, default_length);
    spDebug(10, "spSliderSetDefaultSize", "original: width = %d, height = %d\n",
	    SpComponentPart(component).width, SpComponentPart(component).height);
    
    spDebug(10, "spSliderSetDefaultSize", "orientation = %d, size = %d, %d, %d\n",
	    (int)SpComponentPart(component).orientation,
	    sizeof(SpComponentPart(component).orientation),
	    sizeof(spOrientation), sizeof(SP_HORIZONTAL));
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	if (SpComponentPart(component).width == 0
	    && SpParentComponentPart(component).orientation == SP_HORIZONTAL) {
	    SpComponentPart(component).width = default_length;
	}
	if (SpComponentPart(component).require_width <= 0) {
	    SpComponentPart(component).require_width
		= MAX(SpComponentPart(component).width, default_length);
	}
	if (SpComponentPart(component).height <= 0) {
	    SpComponentPart(component).height = default_width;
	}
    } else {
	if (SpComponentPart(component).width <= 0) {
	    SpComponentPart(component).width = default_width;
	}
	if (SpComponentPart(component).height == 0
	    && SpParentComponentPart(component).orientation == SP_VERTICAL) {
	    SpComponentPart(component).height = default_length;
	}
	if (SpComponentPart(component).require_height <= 0) {
	    SpComponentPart(component).require_height
		= MAX(SpComponentPart(component).height, default_length);
	}
    }
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;
    
    spDebug(10, "spSliderSetDefaultSize", "width = %d, height = %d\n",
	    SpComponentPart(component).current_width, SpComponentPart(component).current_height);
    
    return;
}

spBool spIsSlider(spComponent component)
{
    return spIsSubClass(component, SpSlider);
}

spComponent spCreateScrollBar(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpSliderClass, SpScrollBar, name, parent, args, num_arg);
}

spComponent spCreateTrackBar(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpSliderClass, SpTrackBar, name, parent, args, num_arg);
}

spBool spSetSliderValue(spComponent component, int value)
{
#if 1
    if (spIsSlider(component) == SP_FALSE) {
	if (spIsSlider(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }
#else
    if (spIsSlider(component) == SP_FALSE) return SP_FALSE;
#endif

    SpSliderPart(component).value = value;
    spSetSliderValueArch(component);
    
    return SP_TRUE;
}

spBool spGetSliderValue(spComponent component, int *value)
{
#if 1
    if (spIsSlider(component) == SP_FALSE) {
	if (spIsSlider(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }
#else
    if (spIsSlider(component) == SP_FALSE) return SP_FALSE;
#endif
    
    SpSliderPart(component).value = spGetSliderValueArch(component);
    if (value != NULL)
	*value = SpSliderPart(component).value;
    
    return SP_TRUE;
}
