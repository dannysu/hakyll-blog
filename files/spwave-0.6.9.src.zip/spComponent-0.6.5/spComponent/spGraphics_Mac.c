/*
 *	spGraphics_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLocale.h>

#include <sp/spTopLevelP.h>
#include <sp/spGraphicsP.h>

RGBColor spGetRGBMac(char *color_name)
{
    spPixel pixel;
    RGBColor rgb;
    
    pixel = spGetColorPixelNormal(color_name);    
    rgb.red = (unsigned short)spGetRValue(pixel);
    rgb.green = (unsigned short)spGetGValue(pixel);
    rgb.blue = (unsigned short)spGetBValue(pixel);
    
    return rgb;
}

spPixel spGetColorPixel(char *color_name)
{
    return spGetColorPixelNormal(color_name);
}

CursHandle spGetCursorMac(spCursorType cursor_type)
{
    short cursor_id = 0;
    
    switch (cursor_type) {
      case SP_CURSOR_TEXT:
	cursor_id = iBeamCursor;
	break;
      case SP_CURSOR_WAIT:
	cursor_id = watchCursor;
	break;
      case SP_CURSOR_CROSS:
	cursor_id = crossCursor;
	break;
      case SP_CURSOR_HAND:
	cursor_id = SP_CURSOR_HAND_ID;
	break;
      case SP_CURSOR_MOVE:
	/*cursor_id = plusCursor;*/
	cursor_id = SP_CURSOR_MOVE_ID;
	break;
      case SP_CURSOR_SIZE:
	cursor_id = SP_CURSOR_SIZE_ID;
	break;
      case SP_CURSOR_SW_RESIZE:
      case SP_CURSOR_NE_RESIZE:
	cursor_id = SP_CURSOR_NESW_RESIZE_ID;
	break;
      case SP_CURSOR_SE_RESIZE:
      case SP_CURSOR_NW_RESIZE:
	cursor_id = SP_CURSOR_NWSE_RESIZE_ID;
	break;
      case SP_CURSOR_N_RESIZE:
      case SP_CURSOR_S_RESIZE:
	cursor_id = SP_CURSOR_NS_RESIZE_ID;
	break;
      case SP_CURSOR_W_RESIZE:
      case SP_CURSOR_E_RESIZE:
	cursor_id = SP_CURSOR_WE_RESIZE_ID;
	break;
      default:
	break;
    }
    spDebug(10, "spGetCursorMac", "cursor_type = %d, cursor_id = %d\n", cursor_type, cursor_id);
    
    return GetCursor(cursor_id);
}

spBool spGetCursorArch(spCursor cursor)
{
    return SP_TRUE;
}

void spDestroyCursorArch(spCursor cursor)
{
    return;
}

void spSetGraphicsModeArch(spGraphics graphics, spGraphicsMode mode)
{
    if (graphics == NULL) return;

    switch (mode) {
      case SP_GM_COPY:
	SpGraphicsArch(graphics).mode = srcCopy;
	break;
      case SP_GM_XOR:
	SpGraphicsArch(graphics).mode = srcXor;
	break;
      case SP_GM_INVERT:
	SpGraphicsArch(graphics).mode = notSrcCopy;
	break;
      case SP_GM_AND:
	SpGraphicsArch(graphics).mode = /*notSrcBic*/adMin;
	break;
      case SP_GM_OR:
	SpGraphicsArch(graphics).mode = srcOr;
	break;
      default:
	break;
    }

    return;
}

void spGraphicsPartInitArch(spGraphics graphics)
{
    SpGraphicsArch(graphics).fg_rgb = spGetRGBMac("black");
    SpGraphicsArch(graphics).bg_rgb = spGetRGBMac("white");
    
    SpGraphicsArch(graphics).mode = srcCopy;
    
    SpGraphicsArch(graphics).font_id = SP_DEFAULT_FONT_ID;
    SpGraphicsArch(graphics).font_style = SP_DEFAULT_FONT_STYLE;
    SpGraphicsArch(graphics).font_size = GetDefFontSize();

    return;
}

void spGraphicsPartFreeArch(spGraphics graphics)
{
    return;
}

void spGraphicsCreateArch(spGraphics graphics)
{
    spSetGraphicsModeArch(graphics, SpGraphicsPart(graphics).mode);
    
    spSetForegroundPixelArch(graphics);
    spSetBackgroundPixelArch(graphics);
    
    return;
}

void spFontNameToFontIdMac(char *font_name, short *pfont_id, short *pstyle, short *psize)
{
    int i;
    int size;
    short style;
    short font_id;
    char *p;
    char *string;
    Str255 pname;
    char buf[SP_MAX_LINE];
    char name[SP_MAX_LINE];

    font_id = SP_DEFAULT_FONT_ID;
    style = SP_DEFAULT_FONT_STYLE;
    size = GetDefFontSize();

    if (!strnone(font_name)) {
	string = font_name;
	spDebug(50, "spFontNameToFontIdMac", "font_name = %s\n", string);
	
	strcpy(name, "");
	
	if (string[0] == '-') {
	    string++;
	    i = 1;
	    while ((string = strchr(string, '-')) != NULL) {
		string++;
		spDebug(60, "spFontNameToFontIdMac", "i = %d, string = %s\n", i, string);
		switch (i) {
		  case 1:
		    if (!strveq(string, "*")) {
			strcpy(name, string);
			
			if ((p = strchr(name, '-')) != NULL) {
			    *p = NUL;
			}
		    }
		    break;
		  case 2:
		    if (strveq(string, "black")
			|| strveq(string, "bold")) {
			style |= bold;
		    }
		    break;
		  case 3:
		    if (strveq(string, "i") || strveq(string, "o")) {
			style |= italic;
		    }
		    break;
		  case 6:
		    if (!strveq(string, "*")) {
			sscanf(string, "%d-%s", &size, buf);
		    }
		    break;
		  default:
		    break;
		}
		
		i++;
	    }
	} else {
	    strcpy(name, font_name);
	}

	spDebug(60, "spFontNameToFontIdMac", "size = %d, style = %d, name = %s\n",
		size, style, name);
	
	if (!strnone(name)) {
	    spStrCToP(name, pname);
	    GetFNum(pname, &font_id);
	    spDebug(60, "spFontNameToFontIdMac", "%s: font_id = %d\n", name, font_id);
	
	    if (size <= 0) {
		size = GetDefFontSize();
	    }
    
	    if (!RealFont(font_id, size)) {
		spDebug(60, "spFontNameToFontIdMac", "name = %s, size = %d: not available\n", name, size);
		font_id = SP_DEFAULT_FONT_ID;
		if (!RealFont(font_id, size)) {
		    size = GetDefFontSize();
		}
	    } else {
		spDebug(60, "spFontNameToFontIdMac", "%s: OK\n", name);
	    }
	}
    }

    if (pfont_id != NULL) *pfont_id = font_id;
    if (pstyle != NULL) *pstyle = style;
    if (psize != NULL) *psize = size;
  
    spDebug(100, "spFontNameToFontIdMac", "done: size = %d\n", size);
    
    return;
}

void spSetFontArch(spGraphics graphics)
{
    spFontNameToFontIdMac(SpGraphicsPart(graphics).font_name,
			  &SpGraphicsArch(graphics).font_id,
			  &SpGraphicsArch(graphics).font_style,
			  &SpGraphicsArch(graphics).font_size);
    
    return;
}

spBool spGetSystemColorPixelArch(spSystemColorType type, spPixel *pixel)
{
    return spGetSystemColorPixelNormal(type, pixel);
}

spBool spPixelToRGBColorMac(spPixel pixel, RGBColor *color)
{
    color->red = 256 * (unsigned short)spGetRValue(pixel);
    color->green = 256 * (unsigned short)spGetGValue(pixel);
    color->blue = 256 * (unsigned short)spGetBValue(pixel);
    spDebug(100, "spPixelToRGBColorMac", "pixel = %lx, red = %d, green = %d, blue = %d\n",
	    pixel, color->red, color->green, color->blue);

    return SP_TRUE;
}

spBool spSetForegroundPixelArch(spGraphics graphics)
{
    return spPixelToRGBColorMac(SpGraphicsPart(graphics).fg_pixel,
				&SpGraphicsArch(graphics).fg_rgb);
}

spBool spSetBackgroundPixelArch(spGraphics graphics)
{
    return spPixelToRGBColorMac(SpGraphicsPart(graphics).bg_pixel,
				&SpGraphicsArch(graphics).bg_rgb);
}

#define SP_MAC_NUM_FONT_FAMILY 16

static char **getFontFamilyListOld(void)
{
    short i;
    short size;
    Str255 pname;
    int num_family;
    int family_list_size;
    char buf[256];
    static char **family_list = NULL;

    if (family_list == NULL) {
	family_list_size = SP_MAC_NUM_FONT_FAMILY;
	family_list = xalloc(family_list_size, char *);
	
	size = GetDefFontSize();
	
	family_list[0] = strclone("*");
	num_family = 1;
	
	for (i = 1; i <= 16800; i++) {
	    if (RealFont(i, size)) {
		/* font exists */
		GetFontName(i, pname);
		spStrPToC(pname, buf);

		family_list[num_family] = strclone(buf);
		
		num_family++;
		
		if (num_family >= family_list_size) {
		    family_list_size += SP_MAC_NUM_FONT_FAMILY;
		    family_list = xrealloc(family_list, family_list_size, char *);
		}
	    }
	    if (i == 32) {
		i = 16382;
	    }
	}

	family_list[num_family] = NULL;
    }
    
    return family_list;
}

static char **getFontFamilyList(void)
{
    FMFontFamily family;
    FMFontFamilyIterator iterator;
    Str255 pname;
    int num_family;
    int family_list_size;
    char buf[256];
    static char **family_list = NULL;
    
    if (family_list == NULL) {
	family_list_size = SP_MAC_NUM_FONT_FAMILY;
	family_list = xalloc(family_list_size, char *);
	
	family_list[0] = strclone("*");
	num_family = 1;
	
	if (FMCreateFontFamilyIterator(NULL, NULL, kFMDefaultOptions, &iterator) == noErr) {
	    while (FMGetNextFontFamily(&iterator, &family) == noErr) {
		GetFontName(family, pname);
		spStrPToC(pname, buf);
		family_list[num_family] = strclone(buf);
		
		num_family++;
		
		if (num_family >= family_list_size) {
		    family_list_size += SP_MAC_NUM_FONT_FAMILY;
		    family_list = xrealloc(family_list, family_list_size, char *);
		}
	    }
	    FMDisposeFontFamilyIterator(&iterator);
	}
	
	family_list[num_family] = NULL;
    }

    return family_list;
}

char **spGetFontFamilyListArch(void)
{
    if (spGetSystemVersionMac() < 0x00000900) {
	return getFontFamilyListOld();
    } else {
	return getFontFamilyList();
    }
}

spBool spIsFontSizeSupportedArch(int family, unsigned long style, int size)
{
    char **family_list;
    Str255 pname;
    short font_id = 0;

    if (style & SP_FONT_WEIGHT_LIGHT
	|| style & SP_FONT_WEIGHT_BLACK
	|| style & SP_FONT_SLANT_OBLIQUE) {
	return SP_FALSE;
    }

    family_list = spGetFontFamilyListArch();
    spDebug(100, "spIsFontSizeSupportedArch", "family[%d] = %s, size = %d\n",
	    family, family_list[family], size);

    if (family > 0) {
	spStrCToP(family_list[family], pname);
	GetFNum(pname, &font_id);
    } else {
	font_id = 0;
    }
    spDebug(100, "spIsFontSizeSupportedArch", "font_id = %d\n", font_id);

    if (size <= 0) {
	size = GetDefFontSize();
    }
    
    if (RealFont(font_id, size)) {
	spDebug(100, "spIsFontSizeSupportedArch", "%d: supported\n", font_id);
	return SP_TRUE;
    } else {
	spDebug(100, "spIsFontSizeSupportedArch", "%d: not supported\n", font_id);
	return SP_FALSE;
    }
}
