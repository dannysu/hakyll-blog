/*
 *	spMenuItem_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <gdk/gdkkeysyms.h>

#include <sp/spBase.h>
#include <sp/spOption.h>

#include <sp/spStatusBar.h>

#include <sp/spFrameP.h>
#include <sp/spMenuItemP.h>

void spShowMenuHelpCB(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    spComponent component = (spComponent)data;

    if (component == NULL
	|| (event->type != GDK_ENTER_NOTIFY && event->type != GDK_LEAVE_NOTIFY)) return;
    
    if (event->type == GDK_ENTER_NOTIFY
	&& SpGetDescription(component) != NULL) {
	spSetHelpStatusText(component, SpGetDescription(component));
    } else {
	spSetHelpStatusText(component, "");
    }

    return;
}

static void createRadioButtonMenuItem(spComponent component, char *label)
{
    static GSList *group = NULL;

    if (group == NULL) {
	SpPrimitiveArch(component).widget =
	    gtk_radio_menu_item_new_with_label(NULL, label);
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(SpPrimitiveArch(component).widget));
	
	SpPrimitivePart(component).index = SP_RADIO_GROUP_START;
    } else {
	spComponent temp;
	spBool flag = SP_FALSE;
	
	temp = SpGetPrevComponent(component);
	while (temp != NULL) {
	    if (spIsRadioButton(temp) == TRUE) {
		if (SpPrimitivePart(temp).index != SP_RADIO_GROUP_END) {
		    flag = SP_TRUE;
		}
		break;
	    }
	    temp = SpGetPrevComponent(temp);
	}

	if (flag == SP_TRUE) {
	    SpPrimitiveArch(component).widget =
		gtk_radio_menu_item_new_with_label(group, label);
	    group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(SpPrimitiveArch(component).widget));
	    
	    if (SpButtonPart(component).radio_end == SP_TRUE) {
		group = NULL;
		SpPrimitivePart(component).index = SP_RADIO_GROUP_END;
	    } else {
		SpPrimitivePart(component).index = SP_RADIO_GROUP_MEMBER;
	    }
	} else {
	    SpPrimitiveArch(component).widget =
		gtk_radio_menu_item_new_with_label(NULL, label);
	    group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(SpPrimitiveArch(component).widget));
	
	    SpPrimitivePart(component).index = SP_RADIO_GROUP_START;
	}
    }
    
    return;
}

void spMenuItemCreateArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }
    
    if (strnone(label)) {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
    }

    if (spIsCheckBoxMenuItem(component) == SP_TRUE) {
	SpPrimitiveArch(component).widget = gtk_check_menu_item_new_with_label(label);
    } else if (spIsRadioButtonMenuItem(component) == SP_TRUE) {
	createRadioButtonMenuItem(component, label);
    } else {
	SpPrimitiveArch(component).widget = gtk_menu_item_new_with_label(label);
    }
    gtk_menu_append(GTK_MENU(SpParentPrimitiveArch(component).widget),
		    SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);

    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "enter_notify_event", GTK_SIGNAL_FUNC(spShowMenuHelpCB),
		       (gpointer)component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "leave_notify_event", GTK_SIGNAL_FUNC(spShowMenuHelpCB),
		       (gpointer)component);
    
    spDebug(40, "spMenuItemCreateArch", "done\n");
    
    return;
}

void spMenuItemSetParamsArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_BUTTON_LABEL] = "";

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    GList *children;

	    children = gtk_container_children(GTK_CONTAINER(SpPrimitiveArch(component).widget));

	    while (children != NULL) {
		if (children->data != NULL && GTK_IS_LABEL(children->data) == TRUE) {
		    gtk_label_set(GTK_LABEL(children->data), label);
		    break;
		}

		children = children->next;
	    }
	}
    }

    return;
}

void spMenuSeparatorCreateArch(spComponent component)
{
    SpPrimitiveArch(component).widget = gtk_menu_item_new();
    gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
		      SpPrimitiveArch(component).widget);
    gtk_widget_show(SpPrimitiveArch(component).widget);
    
    return;
}

static spBool convertKeySym(char *keyname, guint *key, char *keylabel)
{
    int len;
    spBool flag = SP_TRUE;

    if (key == NULL || strnone(keyname)) {
	flag = SP_FALSE;
    } else {
	len = strlen(keyname);
	if (streq(keyname, "RET") ||
	    streq(keyname, "RETURN") || streq(keyname, "Return") ||
	    streq(keyname, "ENTER") || streq(keyname, "Enter")) {
	    *key = GDK_Return;
	    strcpy(keylabel, "Return");
	} else if (streq(keyname, "ESC") ||
		   streq(keyname, "ESCAPE") || streq(keyname, "Escape")) {
	    *key = GDK_Escape;
	    strcpy(keylabel, "Escape");
	} else if (streq(keyname, "SPC") ||
		   streq(keyname, "SPACE") || streq(keyname, "Space")) {
	    *key = GDK_space;
	    strcpy(keylabel, "Space");
	} else if (streq(keyname, "DEL") ||
		   streq(keyname, "DELETE") || streq(keyname, "Delete")) {
	    *key = GDK_Delete;
	    strcpy(keylabel, "Delete");
	} else if (streq(keyname, "INS") ||
		   streq(keyname, "INSERT") || streq(keyname, "Insert")) {
	    *key = GDK_Insert;
	    strcpy(keylabel, "Insert");
	} else if (streq(keyname, "TAB") || streq(keyname, "Tab")) {
	    *key = GDK_Tab;
	    strcpy(keylabel, "Tab");
	} else if (streq(keyname, "LEFT") || streq(keyname, "Left")) {
	    *key = GDK_Left;
	    strcpy(keylabel, "Left");
	} else if (streq(keyname, "UP") || streq(keyname, "Up")) {
	    *key = GDK_Up;
	    strcpy(keylabel, "Up");
	} else if (streq(keyname, "RIGHT") || streq(keyname, "Right")) {
	    *key = GDK_Right;
	    strcpy(keylabel, "Right");
	} else if (streq(keyname, "DOWN") || streq(keyname, "Down")) {
	    *key = GDK_Down;
	    strcpy(keylabel, "Down");
	} else if (streq(keyname, "HOME") || streq(keyname, "Home")) {
	    *key = GDK_Home;
	    strcpy(keylabel, "Home");
	} else if (streq(keyname, "END") || streq(keyname, "End")) {
	    *key = GDK_End;
	    strcpy(keylabel, "End");
	} else if (streq(keyname, "PRIOR") || streq(keyname, "Prior")) {
	    *key = GDK_Prior;
	    strcpy(keylabel, "Prior");
	} else if (streq(keyname, "NEXT") || streq(keyname, "Next")) {
	    *key = GDK_Next;
	    strcpy(keylabel, "Next");
	} else if (streq(keyname, "F1")) {
	    *key = GDK_F1;
	    strcpy(keylabel, "F1");
	} else if (streq(keyname, "F2")) {
	    *key = GDK_F2;
	    strcpy(keylabel, "F2");
	} else if (streq(keyname, "F3")) {
	    *key = GDK_F3;
	    strcpy(keylabel, "F3");
	} else if (streq(keyname, "F4")) {
	    *key = GDK_F4;
	    strcpy(keylabel, "F4");
	} else if (streq(keyname, "F5")) {
	    *key = GDK_F5;
	    strcpy(keylabel, "F5");
	} else if (streq(keyname, "F6")) {
	    *key = GDK_F6;
	    strcpy(keylabel, "F6");
	} else if (streq(keyname, "F7")) {
	    *key = GDK_F7;
	    strcpy(keylabel, "F7");
	} else if (streq(keyname, "F8")) {
	    *key = GDK_F8;
	    strcpy(keylabel, "F8");
	} else if (streq(keyname, "F9")) {
	    *key = GDK_F9;
	    strcpy(keylabel, "F9");
	} else if (streq(keyname, "F10")) {
	    *key = GDK_F10;
	    strcpy(keylabel, "F10");
	} else if (streq(keyname, "F11")) {
	    *key = GDK_F11;
	    strcpy(keylabel, "F11");
	} else if (streq(keyname, "F12")) {
	    *key = GDK_F12;
	    strcpy(keylabel, "F12");
	} else if (len == 1) {
	    *key = toupper(keyname[0]);
	    sprintf(keylabel, "%c", toupper(keyname[0]));
	} else {
	    spWarning("unknown key symbol: %s\n", keyname);
	    flag = SP_FALSE;
	}
    }

    spDebug(80, "convertKeySym", "keyname = %s, key = %c, keylabel = %s\n",
	    keyname, *key, keylabel);
    
    return flag;
}

static spBool getAccelKey(char *shortcut, guint *key, GdkModifierType *mods)
{
    spBool flag = SP_TRUE;
    int len;
    char *p = NULL;
    static char keylabel[SP_MAX_LINE] = "";

    if (!strnone(shortcut)) {
	*mods = 0;
	len = strlen(shortcut);
	if ((p = strchr(shortcut, '-')) != NULL) {
	    switch (shortcut[0]) {
	      case 'C':
		*mods = GDK_CONTROL_MASK;
		break;
	      case 'S':
		*mods = GDK_SHIFT_MASK;
		break;
	      case 'M':
		*mods = GDK_MOD1_MASK;
		break;
	      case 'A':
		*mods = GDK_MOD1_MASK;
		break;
	      default:
		flag = SP_FALSE;
		break;
	    }
	    if (flag == SP_TRUE &&
		convertKeySym(p + 1, key, keylabel) == SP_TRUE) {
		flag = SP_TRUE;
	    } else {
		spMessage("unknown shortcut: %s\n", shortcut);
		flag = SP_FALSE;
	    }
	} else if (convertKeySym(shortcut, key, keylabel) == SP_TRUE) {
	    flag = SP_TRUE;
	} else {
	    flag = SP_FALSE;
	}
    } else {
	flag = SP_FALSE;
    }
    
    return flag;
}

spBool spAddShortcutArch(spComponent component, char *shortcut)
{
    spComponent window;

    if (SpPrimitiveArch(component).widget == NULL) return SP_FALSE;
    
    window = SpGetWindow(component);

    if (SpFrameArch(window).accel_group == NULL) {
#if GTK_CHECK_VERSION(1,2,0)
	SpFrameArch(window).accel_group = gtk_accel_group_new();
	gtk_window_add_accel_group(GTK_WINDOW(SpFrameArch(window).toplevel),
				   SpFrameArch(window).accel_group);
#else
	SpFrameArch(window).accel_group = gtk_accelerator_table_new();
	gtk_window_add_accelerator_table(GTK_WINDOW(SpFrameArch(window).toplevel),
					 SpFrameArch(window).accel_group);
#endif
    }

#if 1
    if (1) {
	guint accel_key;
	GdkModifierType accel_mods;
	
	if (getAccelKey(shortcut, &accel_key, &accel_mods) == SP_TRUE) {
#if GTK_CHECK_VERSION(1,2,0)
	    gtk_widget_add_accelerator(SpPrimitiveArch(component).widget,
				       "activate",
				       SpFrameArch(window).accel_group,
				       accel_key,
				       accel_mods,
				       GTK_ACCEL_VISIBLE);
#else
	    gtk_widget_install_accelerator(SpPrimitiveArch(component).widget,
					   SpFrameArch(window).accel_group,
					   "activate",
					   accel_key,
					   accel_mods);
#endif
	    return SP_TRUE;
	}
    }
#endif
    
    return SP_FALSE;
}
