/*
 *	spText.c
 */

#include <stdio.h>
#include <stdlib.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spComboBox.h>

#include <sp/spTextP.h>

static spParamTable sp_text_param_tables[] = {
    {SppTextString, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spText, text.string), NULL},
    {SppEditable, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spText, text.editable), SP_TRUE_STRING},
    {SppFontName, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spText, text.font_name), NULL},
#if 0
    {SppRows, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spText, text.rows), "0"},
    {SppColumns, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spText, text.columns), "0"},
#endif
};

spTextClassRec SpTextClassRec = {
    /* spObjectClassPart */
    {
	SpText,
	(spObjectClass)&SpPrimitiveClassRec,
	sizeof(spTextRec),
	spArraySize(sp_text_param_tables),
	sp_text_param_tables,
	spTextPartInit,
	spTextPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spTextCreate,
	NULL,
	spTextSetParams,
	spTextGetParams,
    },
    /* spComponentClassPart */
    {
	SP_TRUE,
	SP_FALSE,
	SP_FALSE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,

	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
    },
    /* spPrimitiveClassPart */
    {
	0,
    },
    /* spTextClassPart */
    {
	NULL,
	NULL,
    },
};

spComponentClass SpTextClass = (spComponentClass)&SpTextClassRec;

void spTextPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpComponentPart(component).spacing_flag = SP_TRUE;
    
    SpTextPart(component).rows = 0;
    SpTextPart(component).columns = 0;

    spTextPartInitArch(component);
    
    return;
}

void spTextPartFree(spObject object)
{
    spComponent component = (spComponent)object;
    
    spTextPartFreeArch(component);
    return;
}

void spTextCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spPrimitiveSetDefaultSize(component);
    spTextCreateArch(component);
    spShowToolTip(component);
    
    if (!strnone(SpTextPart(component).string)) {
	spSetTextStringArch(component);
    }
    
    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    
    return;
}

void spTextSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spTextSetParamsArch(component);

    if (!strnone(SpTextPart(component).string)
	&& SpTextPart(SpOldObject(component)).string != SpTextPart(component).string) {
	spSetTextStringArch(component);
    }
    
    return;
}

void spTextGetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spGetTextString(component);

    return;
}

spBool spIsText(spComponent component)
{
    return spIsSubClass(component, SpText);
}

spBool spIsEditable(spComponent component)
{
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return SpTextPart(component).editable;
}

spComponent spCreateTextField(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpTextClass, SpTextField, name, parent, args, num_arg);
}

spComponent spCreateTextArea(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;
    
    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpTextClass, SpTextArea, name, parent, args, num_arg);
}

spBool spSetTextString(spComponent component, char *string)
{
#if 1
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }
#else
    if (spIsText(component) == SP_FALSE) return SP_FALSE;
#endif

#if 1
    if (spIsComboBox(component) == SP_TRUE
	&& spIsEditable(component) == SP_FALSE) {
	if (spFindListItem(component, string) < 0) {
	    return SP_FALSE;
	}
    }
#endif
    
    if (string != NULL) {
	if (SpTextPart(component).string != string) {
	    if (SpTextPart(component).string != NULL) {
		xfree(SpTextPart(component).string);
	    }
	    SpTextPart(component).string = strclone(string);
	}
	spSetTextStringArch(component);
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

char *spGetTextString(spComponent component)
{
#if 1
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return NULL;
	}
    }
#else
    if (spIsText(component) == SP_FALSE) return NULL;
#endif
    
    if (SpTextPart(component).string != NULL) {
	xfree(SpTextPart(component).string);
    }

    spGetTextStringArch(component);
    
    return SpTextPart(component).string;
}

char *xspGetTextString(spComponent component)
{
    char *string;
    
    if ((string = spGetTextString(component)) != NULL) {
	return strclone(string);
    } else {
	return NULL;
    }
}

spBool spSetTextSelection(spComponent component, long start, long end)
{
    if (start < -1 || end < -1) return SP_FALSE;
    if (start != -1 && start == end) return spSetTextPosition(component, start);
    
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spSetTextSelectionArch(component, start, end);
}

spBool spGetTextSelection(spComponent component, long *start, long *end)
{
    if (start == NULL || end == NULL) return SP_FALSE;
    
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spGetTextSelectionArch(component, start, end);
}

spBool spSetTextPosition(spComponent component, long position)
{
    if (position < -1) return SP_FALSE;
    
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spSetTextPositionArch(component, position);
}

spBool spGetTextPosition(spComponent component, long *position)
{
    if (position == NULL) return SP_FALSE;
    
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spGetTextPositionArch(component, position);
}

spBool spCutText(spComponent component)
{
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spCutTextArch(component);
}

spBool spCopyText(spComponent component)
{
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spCopyTextArch(component);
}

spBool spPasteText(spComponent component)
{
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spPasteTextArch(component);
}

spBool spClearText(spComponent component)
{
    if (spIsText(component) == SP_FALSE) {
	if (spIsText(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    return spClearTextArch(component);
}

spBool spSelectAllText(spComponent component)
{
    return spSetTextSelection(component, 0, -1);
}

void spCutTextCB(spComponent component, void *data)
{
    if (data != NULL) spCutText((spComponent)data);
    return;
}

void spCopyTextCB(spComponent component, void *data)
{
    if (data != NULL) spCopyText((spComponent)data);
    return;
}

void spPasteTextCB(spComponent component, void *data)
{
    if (data != NULL) spPasteText((spComponent)data);
    return;
}

void spClearTextCB(spComponent component, void *data)
{
    if (data != NULL) spClearText((spComponent)data);
    return;
}

void spSelectAllTextCB(spComponent component, void *data)
{
    if (data != NULL) spSelectAllText((spComponent)data);
    return;
}
