/*
 *	spSlider_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spSliderP.h>

static ControlActionUPP spSliderActionUPP = NULL;
static DragGrayRgnUPP spSliderThumbActionUPP = NULL;

int spSliderValueToControlValueMac(spComponent component, int slider_value)
{
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE
	&& SpComponentPart(component).orientation == SP_VERTICAL) {
	return SpSliderPart(component).minimum + (SpSliderPart(component).maximum - slider_value)
	    / SpSliderPart(component).scroll_coef;
    } else {
	return slider_value / SpSliderPart(component).scroll_coef;
    }
}

int spControlValueToSliderValueMac(spComponent component, int control_value)
{
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE
	&& SpComponentPart(component).orientation == SP_VERTICAL) {
	return SpSliderPart(component).maximum - (control_value - SpSliderPart(component).minimum)
	    * SpSliderPart(component).scroll_coef;
    } else {
	return control_value * SpSliderPart(component).scroll_coef;
    }
}

spBool spPostSliderValueChangeMac(spComponent component, int value)
{
    SpSliderPart(component).value =spControlValueToSliderValueMac(component, value);
    spDrawSliderValueMac(component);

    return spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
}

void spSliderActionMac(ControlHandle control, short part)
{
    int value, min, max;
    spComponent component;
    
    spDebug(50, "spSliderActionMac", "in: part = %d\n", part);
    
    if ((component = spGetControlReferenceMac(control)) == NULL
	|| spIsSlider(component) == SP_FALSE) {
	component = NULL;
    }

    value = GetControlValue(control);
    min = GetControlMinimum(control);
    max = GetControlMaximum(control);
    spDebug(50, "spSliderActionMac", "initial value = %d, min = %d, max = %d\n",
	    value, min, max);
    
    if (component != NULL) {
#if 0
	value *= SpSliderPart(component).scroll_coef;
#else
	value = spControlValueToSliderValueMac(component, value);
#endif
	spDebug(50, "spSliderActionProc", "original slider value = %d\n", value);

	if (!(spGetAppearanceVersionMac() >= 0x00000101
	      && spIsSubClass(component, SpTrackBar) == SP_TRUE)) {
	    switch (part) {
	      case kControlUpButtonPart:
		value -= SpSliderPart(component).increment;
		break;
	      case kControlPageUpPart:
		value -= SpSliderPart(component).page_increment;
		break;
	      case kControlDownButtonPart:
		value += SpSliderPart(component).increment;
		break;
	      case kControlPageDownPart:
		value += SpSliderPart(component).page_increment;
		break;
	    }
	}
	spDebug(50, "spSliderActionProc", "modified value = %d, min = %d, max = %d\n",
		value, min, max);
#if 0
	value /= SpSliderPart(component).scroll_coef;
#else
	value = spSliderValueToControlValueMac(component, value);
#endif
	spDebug(50, "spSliderActionProc", "modified control value = %d\n", value);
    }
    value = MAX(value, min);
    value = MIN(value, max);
    SetControlValue(control, (short)value);
    
    if (component != NULL) {
	spPostSliderValueChangeMac(component, value);
    }

    return;
}

pascal void spSliderActionProc(ControlHandle control, short part)
{
    GrafPtr old_port;

    /*old_port = spThreadEnterMac(nil);*/
    spSliderActionMac(control, part);
    /*spThreadLeaveMac(old_port);*/
    
    return;
}

static short sp_slider_value = 0;
static short sp_slider_value_slop = 0;
static short sp_slider_start_value = 0;
static short sp_slider_view_size = 0;
static short sp_slider_thumb_size = SP_SLIDER_THUMB_SIZE;
static ControlHandle sp_current_slider_control = NULL;
static RgnHandle sp_slider_clip = nil;

spBool spIsVerticalSliderMac(ControlHandle control)
{
    Rect rect;
    
    if (control == NULL) return SP_FALSE;

    spGetControlRectMac(control, &rect);

    if (spGetRectWidthMac(rect) < spGetRectHeightMac(rect)) {
	return SP_TRUE;
    }

    return SP_FALSE;
}

short spCalcValueFromPointMac(ControlHandle control, Point point, spBool limit_range)
{
    short min, max;
    short value, range, dist, pin;
    short resid;
    Rect rect;
    
    spDebug(50, "spCalcValueFromPointMac", "in\n");
    
    spGetControlRectMac(control, &rect);

    min = GetControlMinimum(control);
    max = GetControlMaximum(control);
    range = max - min;
    resid = 2 * SP_SLIDER_ARROW_SIZE + sp_slider_thumb_size;
    spDebug(50, "spCalcValueFromPointMac",
	    "min = %d, max = %d, range = %d, resid = %d, thumb_size = %d\n",
	    min, max, range, resid, sp_slider_thumb_size);

    if (spIsVerticalSliderMac(control) == SP_TRUE) {
	dist = MAX(rect.bottom - rect.top - resid, 1);
	/* vertical slider */
	if (sp_slider_view_size > 0) {
	    pin = rect.top + sp_slider_thumb_size / 2;
	} else {
	    pin = rect.top + resid / 2;
	}
		
	value = min + (short)(((double)(point.v - pin) * (double)range) / (double)dist);
    } else {
	dist = MAX(rect.right - rect.left - resid, 1);
	/* horizontal slider */
	if (sp_slider_view_size > 0) {
	    pin = rect.left + sp_slider_thumb_size / 2;
	} else {
	    pin = rect.left + resid / 2;
	}
	
	value = min + (short)(((double)(point.h - pin) * (double)range) / (double)dist);
	spDebug(50, "spCalcValueFromPointMac",
		"point.h = %d, pin = %d, dist = %d, value = %d\n", point.h, pin, dist, value);
    }
    value += sp_slider_value_slop;

    if (limit_range == SP_TRUE) {
	value = MAX(value, min);
	value = MIN(value, max);
    }

    spDebug(50, "spCalcValueFromPointMac", "value = %d\n", value);
    
    return value;
}

void spEnableDrawingMac(void)
{
    if (sp_slider_clip != nil) {
	SetClip(sp_slider_clip);
    }
    spDebug(50, "spEnableDrawingMac", "done\n");
	
    return;
}

void spDisableDrawingMac(void)
{
    Rect null_rect = {0, 0, 0, 0};

    if (sp_slider_clip != nil) {
	GetClip(sp_slider_clip);
	ClipRect(&null_rect);
    }
    spDebug(50, "spDisableDrawingMac", "done\n");
    
    return;
}

spBool spBeginThumbActionMac(ControlHandle control)
{
    Rect rect;
    Point point;
    spComponent component;

    if (sp_current_slider_control != NULL) {
	return SP_FALSE;
    }
    
    component = spGetControlReferenceMac(control);
    
    if (spIsPrimitive(component) == SP_FALSE
	|| (spIsSlider(component) == SP_TRUE
	    && SpSliderPart(component).track_call_on == SP_FALSE)) {
	return SP_FALSE;
    }
	
    sp_slider_start_value = GetControlValue(control);
    spDebug(50, "spBeginThumbActionMac", "start_value = %d\n", sp_slider_start_value);
    
    sp_slider_view_size = 0;
    sp_slider_thumb_size = SP_SLIDER_THUMB_SIZE;
    if (spGetSystemVersionMac() >= 0x00000850 
	&& spIsSubClass(component, SpTrackBar) == SP_FALSE) {
	double size;
	double range;
	ControlPartCode part;

	/* check if smart scrolling is turned on */
	spGetControlRectMac(control, &rect);
	point.h = rect.left + 8;
	point.v = rect.top + 8;
	part = TestControl(control, point);
	if (part == kControlUpButtonPart || part == kControlDownButtonPart) {
	    sp_slider_view_size = 0;
	} else {
	    sp_slider_view_size = (short)GetControlViewSize(SpPrimitiveArch(component).control);
	}
	
	if (sp_slider_view_size > 0) {
	    range = (double)(GetControlMaximum(control) - GetControlMinimum(control)
			     + sp_slider_view_size);
	    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
		size = (double)spGetRectWidthMac(rect) - 2.0 * SP_SLIDER_ARROW_SIZE;
	    } else {
		size = (double)spGetRectHeightMac(rect) - 2.0 * SP_SLIDER_ARROW_SIZE;
	    }
	    if (range > 0.0) {
		sp_slider_thumb_size = MAX((short)(size * (double)sp_slider_view_size / range),
					   SP_SLIDER_THUMB_SIZE);
	    }
	    spDebug(50, "spBeginThumbActionMac",
		    "size = %f, range = %f, view_size = %d, thumb_size = %d\n",
		    size, range, sp_slider_view_size, sp_slider_thumb_size);
	}
    }
    
    GetMouse(&point);
    sp_slider_value_slop = 0;	/* spCalcValueFromPointMac uses this internally */
    sp_slider_value_slop = sp_slider_start_value
	- spCalcValueFromPointMac(control, point, SP_FALSE);

    sp_slider_clip = NewRgn();
    spDisableDrawingMac();

    sp_current_slider_control = control;
    
    spDebug(50, "spBeginThumbActionMac", "sp_slider_value_slop = %d\n", sp_slider_value_slop);
    
    return SP_TRUE;
}

void spEndThumbActionMac(ControlHandle control)
{
    spEnableDrawingMac();
    
    if (sp_slider_clip != nil) {
	DisposeRgn(sp_slider_clip);
	sp_slider_clip = nil;
    }
    
    SetControlValue(sp_current_slider_control, sp_slider_value);
    sp_current_slider_control = NULL;

    spDebug(50, "spEndThumbActionMac", "done\n");
    
    return;
}

pascal void spSliderThumbActionProc(void)
{
    short value;
    GrafPtr old_port;
    Point point;
    Rect rect;
    ControlHandle control;
    spComponent component;
    
    spDebug(50, "spSliderThumbActionProc", "in\n");
    
    if ((control = sp_current_slider_control) == NULL) return;
    
    /*old_port = spThreadEnterMac(nil);*/
    
#if 1
    spGetControlRectMac(control, &rect);
    if (spIsVerticalSliderMac(control) == SP_TRUE) {
	InsetRect(&rect, -SP_THUMB_TRACK_WIDTH_SLOP, -SP_THUMB_TRACK_LENGTH_SLOP);
    } else {
	InsetRect(&rect, -SP_THUMB_TRACK_LENGTH_SLOP, -SP_THUMB_TRACK_WIDTH_SLOP);
    }
    
    GetMouse (&point);
    if (PtInRect(point, &rect)) {
	value = spCalcValueFromPointMac(control, point, SP_TRUE);
    } else {
	value = sp_slider_start_value;
    }
#else
    GetMouse (&point);
    value = spCalcValueFromPointMac(control, point, SP_TRUE);
#endif
    spDebug(50, "spSliderThumbActionProc", "value = %d\n", value);
    
    if (value != GetControlValue(control)) {
	spDebug(50, "spSliderThumbActionProc", "value changed\n");
	spEnableDrawingMac();
		
	sp_slider_value = value;
	SetControlValue(control, value);

	if ((component = spGetControlReferenceMac(control)) != NULL
	    && spIsSlider(component) == SP_TRUE) {
	    spPostSliderValueChangeMac(component, value);
	}
	
	spDisableDrawingMac();
    }
    spDebug(50, "spSliderThumbActionProc", "done\n");
    
    /*spThreadLeaveMac(old_port);*/
    
    return;
}

void spCreateActionProcMac(void)
{
    if (spSliderActionUPP == NULL) {
	spSliderActionUPP = NewControlActionUPP(spSliderActionProc);
    }
    if (spSliderThumbActionUPP == NULL) {
	/* because DragGrayRgnProc has same prototype as thumb action procedure */
	spSliderThumbActionUPP = NewDragGrayRgnUPP(spSliderThumbActionProc);
    }

    return;
}

void spDestroyActionProcMac(void)
{
    if (spSliderActionUPP != NULL) {
	DisposeControlActionUPP(spSliderActionUPP);
	spSliderActionUPP = NULL;
    }
    if (spSliderThumbActionUPP == NULL) {
	DisposeDragGrayRgnUPP(spSliderThumbActionUPP);
	spSliderThumbActionUPP = NULL;
    }

    return;
}

spBool spHandleThumbTrackMac(WindowPtr window, ControlHandle control, Point point)
{
    spComponent component;
    GrafPtr old_port;

    if (spBeginThumbActionMac(control) == SP_TRUE) {
	/*old_port = spThreadLeaveMac(nil);*/
	TrackControl(control, point, (ControlActionUPP)spSliderThumbActionUPP);
	/*spThreadEnterMac(old_port);*/
	
	spEndThumbActionMac(control);
    } else {
	/*old_port = spThreadLeaveMac(nil);*/
	TrackControl(control, point, (ControlActionUPP)-1);
	/*spThreadEnterMac(old_port);*/
	
	if ((component = spGetControlReferenceMac(control)) != NULL
	    && spIsSlider(component) == SP_TRUE) {
	    spPostSliderValueChangeMac(component, (int)GetControlValue(control));
	}
    }
    return SP_TRUE;
}

spBool spHandleSliderActionMac(WindowPtr window, ControlHandle control,
			       Point point, ControlPartCode part)
{
    GrafPtr old_port;
    
    spDebug(50, "spHandleSliderActionMac", "part = %d\n", part);
    
    switch (part) {
      case kControlUpButtonPart:
      case kControlDownButtonPart:
      case kControlPageUpPart:
      case kControlPageDownPart:
	/*old_port = spThreadLeaveMac(nil);*/
	TrackControl(control, point, spSliderActionUPP);
	/*spThreadEnterMac(old_port);*/
	spDebug(50, "spHandleSliderActionMac", "TrackControl done\n");
	
	return SP_TRUE;
	
      case kControlIndicatorPart:
	if (spGetAppearanceVersionMac() >= 0x00000101) {
	    /*old_port = spThreadLeaveMac(nil);*/
	    TrackControl(control, point, (ControlActionUPP)-1);
	    
	    if (GetControlAction(control) == NULL) {
		spSliderActionProc(control, part);
	    }
	    /*spThreadEnterMac(old_port);*/
	} else {
	    /* thumb of slider */
	    spHandleThumbTrackMac(window, control, point);
	}
	return SP_TRUE;

      default:
	break;
    }
	
    return SP_FALSE;
}

void spDrawSliderValueMac(spComponent component)
{
    Rect rect;
    int x, y;
    int width, height;
    char buf[SP_MAX_LINE];
    GrafPtr save_port;
    
    if (SpSliderPart(component).show_value == SP_TRUE) {
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
	spGetOriginalRGBMac();
	
	if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
	    || SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
	    spSetDeactivateRGBMac();
	} else {
	    spSetNormalRGBMac();
	}
	spSetBackgroundRGBMac();
	
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top;
	spGetComponentSize(component, &width, &height);
	
	if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
	    rect.top = y;
	    rect.bottom = y + SP_SLIDER_VALUE_HEIGHT;
	    rect.left = x + (width - SP_SLIDER_VALUE_WIDTH) / 2 ;
	    rect.right = rect.left + SP_SLIDER_VALUE_WIDTH;
	} else {
	    rect.left = x;
	    rect.right = x + SP_SLIDER_VALUE_WIDTH;
	    rect.top = y + (height - SP_SLIDER_VALUE_HEIGHT) / 2 ;
	    rect.bottom = rect.top + SP_SLIDER_VALUE_HEIGHT;
	}
	sprintf(buf, "%d", SpSliderPart(component).value);
	TETextBox(buf, strlen(buf), &rect, teJustRight);
	spDebug(50, "spDrawSliderValueMac",
		"buf = %s, left = %d, right = %d, top = %d, bottom = %d\n",
		buf, rect.left, rect.right, rect.top, rect.bottom);
	
	spSetOriginalRGBMac();
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    }
    
    return;
}

void spDrawSliderMac(spComponent component)
{
    spDrawControlMac(component);
    spDrawSliderValueMac(component);
    
    return;
}

static int getScrollCoef(spComponent component)
{
    if (SpSliderPart(component).maximum >= 32768) {
	return (int)ceil((double)SpSliderPart(component).maximum / 32768.0);
    } else {
	return 1;
    }
}

void spSliderCreateArch(spComponent component)
{
    static Str255 pstr = "\p";
    Rect rect;

    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    rect = SpPrimitiveArch(component).rect;

    if (spGetAppearanceVersionMac() >= 0x00000101) {
	SInt16 proc_id;
	
	if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	    proc_id = kControlSliderProc + kControlSliderLiveFeedback + kControlSliderNonDirectional;
	} else {
	    proc_id = kControlScrollBarLiveProc;
	}

	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(SpGetWindow(component)).window,
		       &rect, pstr, spIsVisibleMac(component), 0, 0, 256, proc_id, 0L);
    } else {
	SpPrimitiveArch(component).control =
	    NewControl(SpPrimitiveArch(SpGetWindow(component)).window,
		       &rect, pstr, spIsVisibleMac(component), 0, 0, 256, scrollBarProc, 0L);
    }
    spSetReferenceMac(component);
    spSetNeedUpdateMac(component);
    spSetNeedMoveCallMac(component);

    spSliderSetParamsArch(component);
			 
    return;
}

void spSliderSetParamsArch(spComponent component)
{
    int page_size;
    
    SpSliderPart(component).scroll_coef = getScrollCoef(component);
    
    SetControlMinimum(SpPrimitiveArch(component).control,
		      SpSliderPart(component).minimum / SpSliderPart(component).scroll_coef);
    
    if (spIsSubClass(component, SpTrackBar) == SP_TRUE) {
	page_size = 0;
    } else {
	page_size = SpSliderPart(component).page_size  / SpSliderPart(component).scroll_coef;
    }
    SetControlMaximum(SpPrimitiveArch(component).control,
		      SpSliderPart(component).maximum / SpSliderPart(component).scroll_coef
		      - page_size);
    
    SetControlValue(SpPrimitiveArch(component).control,
		    spSliderValueToControlValueMac(component, SpSliderPart(component).value));

    if (spGetSystemVersionMac() >= 0x00000850 
	&& spIsSubClass(component, SpTrackBar) == SP_FALSE) {
	SetControlViewSize(SpPrimitiveArch(component).control, page_size);
    }
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	if (SpSliderPart(component).track_call_on == SP_TRUE) {
	    SetControlAction(SpPrimitiveArch(component).control, spSliderActionUPP);
	} else {
	    SetControlAction(SpPrimitiveArch(component).control, NULL);
	}
    }
    
    return;
}

void spSetSliderValueArch(spComponent component)
{
    SetControlValue(SpPrimitiveArch(component).control,
		    spSliderValueToControlValueMac(component, SpSliderPart(component).value));
    spDrawSliderValueMac(component);
    
    return;
}

int spGetSliderValueArch(spComponent component)
{
    return SpSliderPart(component).value;
}

void spTrackBarCreateArch(spComponent component)
{
    spSliderCreateArch(component);
    return;
}

void spTrackBarSetParamsArch(spComponent component)
{
    spSliderSetParamsArch(component);
    return;
}
