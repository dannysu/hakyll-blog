/*
 *	spPrimitive_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/keysym.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/DrawingA.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spFrame.h>
#include <sp/spDialog.h>
#include <sp/spContainer.h>
#include <sp/spButton.h>
#include <sp/spMenu.h>
#include <sp/spMenuItem.h>
#include <sp/spCanvas.h>
#include <sp/spSlider.h>
#include <sp/spToolBar.h>
#include <sp/spToolItem.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spComboBoxP.h>
#include <sp/spSliderP.h>
#include <sp/spTabBoxP.h>
#include <sp/spGraphicsP.h>
#include <sp/spPrimitiveP.h>

extern spTopLevel sp_toplevel;

static spCallbackTable sp_callback_tables[] = {
    {SP_NO_CALLBACK, NULL, NULL, NoEventMask},
    {SP_KEY_PRESS_CALLBACK, SpCanvas, NULL, KeyPressMask},
    {SP_KEY_RELEASE_CALLBACK, SpCanvas, NULL, KeyReleaseMask},
    {SP_BUTTON_PRESS_CALLBACK, SpPrimitive, NULL, ButtonPressMask},
    {SP_BUTTON_RELEASE_CALLBACK, SpPrimitive, NULL, ButtonReleaseMask},
    {SP_POINTER_MOTION_CALLBACK, SpCanvas, NULL, PointerMotionMask},
    {SP_BUTTON_MOTION_CALLBACK, SpCanvas, NULL,
	 Button1MotionMask | Button3MotionMask | Button2MotionMask},
#if 0
    {SP_ENTER_WINDOW_CALLBACK, SpCanvas, NULL, EnterWindowMask},
    {SP_LEAVE_WINDOW_CALLBACK, SpCanvas, NULL, LeaveWindowMask},
#endif
    /**/
    {SP_DESTROY_CALLBACK, SpFrame, SppDestroyCallback, NoEventMask},
    {SP_CLOSE_CALLBACK, SpFrame, XmNdestroyCallback, NoEventMask},
    {SP_ACTIVATE_CALLBACK, SpPushButton, XmNactivateCallback, NoEventMask},
    {SP_ACTIVATE_CALLBACK, SpMenuItem, XmNactivateCallback, NoEventMask},
    {SP_ACTIVATE_CALLBACK, SpToolItem, XmNactivateCallback, NoEventMask},
    {SP_ACTIVATE_CALLBACK, SpTextField, XmNactivateCallback, NoEventMask},
    {SP_ACTIVATE_CALLBACK, SpList, XmNdefaultActionCallback, NoEventMask},
#if 1
    {SP_BUTTON_PRESS_CALLBACK, SpPushButton, XmNarmCallback, NoEventMask},
    {SP_BUTTON_RELEASE_CALLBACK, SpPushButton, XmNdisarmCallback, NoEventMask},
    {SP_BUTTON_PRESS_CALLBACK, SpToolItem, XmNarmCallback, NoEventMask},
    {SP_BUTTON_RELEASE_CALLBACK, SpToolItem, XmNdisarmCallback, NoEventMask},
#endif
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBox, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButton, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckBoxMenuItem, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpRadioButtonMenuItem, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpCheckToolItem, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpText, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpSlider, XmNvalueChangedCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpSlider, XmNdragCallback, NoEventMask},
    {SP_VALUE_CHANGED_CALLBACK, SpList, XmNbrowseSelectionCallback, NoEventMask},
#if 0
    {SP_MAP_CALLBACK, SpPrimitive, XmNmapCallback, NoEventMask},
    {SP_UNMAP_CALLBACK, SpPrimitive, XmNunmapCallback, NoEventMask},
#endif
    {SP_EXPOSE_CALLBACK, SpCanvas, XmNexposeCallback, NoEventMask},
    {SP_RESIZE_CALLBACK, SpCanvas, XmNresizeCallback, NoEventMask},
    {SP_RESIZE_CALLBACK, SpFrame, XmNresizeCallback, NoEventMask},
    /**/
    {SP_OK_CALLBACK, SpPushButton, XmNokCallback, NoEventMask},
    {SP_OK_CALLBACK, SpDialog, XmNokCallback, NoEventMask},
    {SP_CANCEL_CALLBACK, SpPushButton, XmNcancelCallback, NoEventMask},
    {SP_CANCEL_CALLBACK, SpDialog, XmNcancelCallback, NoEventMask},
    {SP_HELP_CALLBACK, SpPushButton, XmNhelpCallback, NoEventMask},
    {SP_HELP_CALLBACK, SpDialog, XmNhelpCallback, NoEventMask},
#if 0
    {SP_APPLY_CALLBACK, SpPushButton, XmNapplyCallback, NoEventMask},
    {SP_APPLY_CALLBACK, SpDialog, XmNapplyCallback, NoEventMask},
#endif
};
static int sp_num_callback_table = 0;

static void callbackFunc(Widget widget, XtPointer client_data, XtPointer xt_call_data)
{
    long component_id;
    spCallback *callback = (spCallback *)client_data;

    if (callback != NULL && callback->call_func != NULL && callback->component != NULL) {
	component_id = SpGetComponentId(callback->component);

	if (streq(callback->call_name, XmNdestroyCallback)) {
	    SpPrimitiveArch(callback->component).xt_call_data = NULL;
	    SpPrimitiveArch(callback->component).event_mask = SP_CLOSE_CALLBACK_ID;
	} else {
	    SpPrimitiveArch(callback->component).xt_call_data = xt_call_data;
	    SpPrimitiveArch(callback->component).event_mask = callback->event_mask;
	}
	
	spComponentCallbackFunc(callback);
	
	if (component_id != spGetDestroyedComponentId()
	    && callback != NULL && callback->component != NULL) {
	    SpPrimitiveArch(callback->component).xt_call_data = NULL;
	    SpPrimitiveArch(callback->component).event_mask = NoEventMask;
	}
    }
    
    return;
}

static String getCallbackName(spComponent component, spCallbackType call_type, int *count)
{
    int i;
    String call_name = NULL;

    if (sp_num_callback_table <= 0) {
	sp_num_callback_table = spArraySize(sp_callback_tables);
    }
    
    if (call_type == SP_NO_CALLBACK) return NULL;

    if (*count < sp_num_callback_table) {
	for (i = *count; i < sp_num_callback_table; i++) {
	    if (sp_callback_tables[i].component_type == NULL
		|| spIsSubClass(component, sp_callback_tables[i].component_type) == SP_TRUE) {
		if (call_type & sp_callback_tables[i].call_type &&
		    sp_callback_tables[i].call_name != NULL) {
		    call_name = sp_callback_tables[i].call_name;
		    *count = i + 1;
		    break;
		}
	    }
	}
	if (i >= sp_num_callback_table) {
	    *count = sp_num_callback_table;
	}
    }
    
    return call_name;
}

static spBool getEventMask(spComponent component, spCallbackType call_type, EventMask *event_mask)
{
    int i;
    spBool flag = SP_FALSE;
    
    if (event_mask != NULL) {
	if (sp_num_callback_table <= 0) {
	    sp_num_callback_table = spArraySize(sp_callback_tables);
	}

	if (call_type == SP_NO_CALLBACK) return SP_FALSE;
	
	for (i = 0; i < sp_num_callback_table; i++) {
	    if (sp_callback_tables[i].component_type == NULL
		|| spIsSubClass(component, sp_callback_tables[i].component_type) == SP_TRUE) {
		if (call_type & sp_callback_tables[i].call_type &&
		    sp_callback_tables[i].event_mask != NoEventMask) {
		    *event_mask |= sp_callback_tables[i].event_mask;
		    flag = SP_TRUE;
		}
	    }
	}
    }
    
    return flag;
}

void spInitCallbackArch(spCallback *callback)
{
    callback->component = NULL;
    callback->call_func = NULL;
    callback->call_data = NULL;
    callback->propagate = SP_FALSE;
    
    callback->call_name = NULL;
    callback->event_mask = NoEventMask;
    
    return;
}

static spBool addCallback(spComponent component, spBool propagate, String call_name,
			  spCallbackFunc call_func, void *call_data)
{
    long k;

    if (call_name != NULL && call_func != NULL) {
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_name == call_name &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data) {
		return SP_FALSE;
	    } else if (SpPrimitivePart(component).callbacks[k].call_func == NULL) {
		break;
	    }
	}
	if (k >= SpPrimitivePart(component).num_callback) {
	    spAllocCallbacks(component);
	    SpPrimitivePart(component).num_callback++;
	}
	SpPrimitivePart(component).callbacks[k].component = component;
	SpPrimitivePart(component).callbacks[k].call_name = call_name;
	SpPrimitivePart(component).callbacks[k].call_func = call_func;
	SpPrimitivePart(component).callbacks[k].call_data = call_data;
	SpPrimitivePart(component).callbacks[k].event_mask = NoEventMask;
	SpPrimitivePart(component).callbacks[k].propagate = propagate;
	
	spDebug(40, "addCallback", "k = %ld, call_name = %s\n",
		k, SpPrimitivePart(component).callbacks[k].call_name);

	if (!streq(SpPrimitivePart(component).callbacks[k].call_name, SppDestroyCallback)) {
	    if (spIsWindow(component) == SP_TRUE
		&& SpPrimitiveArch(component).toplevel != NULL
		&& streq(call_name, XmNdestroyCallback)) {
	    } else if (SpPrimitiveArch(component).widget != NULL) {
		XtAddCallback(SpPrimitiveArch(component).widget, call_name,
			      (XtCallbackProc)callbackFunc,
			      (XtPointer)&(SpPrimitivePart(component).callbacks[k]));
	    }
	}
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool removeCallback(spComponent component, String call_name,
			     spCallbackFunc call_func, void *call_data)
{
    long k;
    
    if (call_name != NULL && call_func != NULL) {
	spDebug(30, "removeCallback", "call_name = %s\n", call_name);
		
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    spDebug(30, "removeCallback", "k = %ld\n",
		    k, SpPrimitivePart(component).callbacks[k].call_name);
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_name == call_name &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data) {
		if (!streq(SpPrimitivePart(component).callbacks[k].call_name, SppDestroyCallback)) {
		    if (spIsWindow(component) == SP_TRUE
			&& SpPrimitiveArch(component).toplevel != NULL
			&& streq(call_name, XmNdestroyCallback) == SP_TRUE) {
		    } else if (SpPrimitiveArch(component).widget != NULL) {
			XtRemoveCallback(SpPrimitiveArch(component).widget, call_name,
					 (XtCallbackProc)callbackFunc,
					 (XtPointer)&(SpPrimitivePart(component).callbacks[k]));
		    }
		}
		    
		SpPrimitivePart(component).callbacks[k].component = NULL;
		SpPrimitivePart(component).callbacks[k].call_name = NULL;
		SpPrimitivePart(component).callbacks[k].call_func = NULL;
		SpPrimitivePart(component).callbacks[k].call_data = NULL;
		SpPrimitivePart(component).callbacks[k].event_mask = NoEventMask;
		SpPrimitivePart(component).callbacks[k].propagate = SP_FALSE;
		    
		return SP_TRUE;
	    }
	}
    }

    return SP_FALSE;
}

static spBool addEventCallback(spComponent component, spBool propagate, EventMask event_mask,
			       spCallbackFunc call_func, void *call_data)
{
    long k;
    
    if (call_func != NULL) {
	if (event_mask != NoEventMask) {
	    for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
		if (SpPrimitivePart(component).callbacks[k].component == component &&
		    SpPrimitivePart(component).callbacks[k].event_mask == event_mask &&
		    SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		    SpPrimitivePart(component).callbacks[k].call_data == call_data) {
		    return SP_FALSE;
		} else if (SpPrimitivePart(component).callbacks[k].call_func == NULL) {
		    break;
		}
	    }
	    if (k >= SpPrimitivePart(component).num_callback) {
		spAllocCallbacks(component);
		SpPrimitivePart(component).num_callback++;
	    }
	    SpPrimitivePart(component).callbacks[k].component = component;
	    SpPrimitivePart(component).callbacks[k].call_name = NULL;
	    SpPrimitivePart(component).callbacks[k].call_func = call_func;
	    SpPrimitivePart(component).callbacks[k].call_data = call_data;
	    SpPrimitivePart(component).callbacks[k].event_mask = event_mask;
	    SpPrimitivePart(component).callbacks[k].propagate = propagate;
	
	    spDebug(40, "addEventCallback", "num_callback = %ld\n", k);
	    if (SpPrimitiveArch(component).widget != NULL) {
		XtAddEventHandler(SpPrimitiveArch(component).widget,
				  SpPrimitivePart(component).callbacks[k].event_mask, False,
				  (XtEventHandler)callbackFunc,
				  (XtPointer)&(SpPrimitivePart(component).callbacks[k]));
	    }

	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spBool removeEventCallback(spComponent component, EventMask event_mask,
				  spCallbackFunc call_func, void *call_data)
{
    long k;
    
    if (call_func != NULL) {
	if (event_mask != NoEventMask) {
	    for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
		if (SpPrimitivePart(component).callbacks[k].component == component &&
		    SpPrimitivePart(component).callbacks[k].event_mask == event_mask &&
		    SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		    SpPrimitivePart(component).callbacks[k].call_data == call_data) {
		    if (SpPrimitiveArch(component).widget != NULL) {
			XtAddEventHandler(SpPrimitiveArch(component).widget,
					  SpPrimitivePart(component).callbacks[k].event_mask, False,
					  (XtEventHandler)callbackFunc,
					  (XtPointer)&(SpPrimitivePart(component).callbacks[k]));
		    }
		    
		    SpPrimitivePart(component).callbacks[k].component = NULL;
		    SpPrimitivePart(component).callbacks[k].call_name = NULL;
		    SpPrimitivePart(component).callbacks[k].call_func = NULL;
		    SpPrimitivePart(component).callbacks[k].call_data = NULL;
		    SpPrimitivePart(component).callbacks[k].event_mask = NoEventMask;
		    SpPrimitivePart(component).callbacks[k].propagate = SP_FALSE;
		    
		    return SP_TRUE;
		}
	    }
	}
    }

    return SP_FALSE;
}

spBool spPrimitiveAddCallbackArch(spComponent component, spBool propagate, spCallbackType call_type,
				  spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    String call_name = NULL;
    EventMask event_mask = NoEventMask;
    
    while ((call_name = getCallbackName(component, call_type, &count)) != NULL) {
	spDebug(40, "spPrimitiveAddCallbackArch", "call_name = %s\n", call_name);
	flag = addCallback(component, propagate, call_name, call_func, call_data);
    }
    if (getEventMask(component, call_type, &event_mask) == SP_TRUE) {
	flag = addEventCallback(component, propagate, event_mask, call_func, call_data);
    }

    spDebug(50, "spPrimitiveAddCallbackArch", "done: flag = %d\n", flag);
    
    return flag;
}

spBool spPrimitiveRemoveCallbackArch(spComponent component, spCallbackType call_type,
				     spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    String call_name = NULL;
    EventMask event_mask = NoEventMask;
    
    while ((call_name = getCallbackName(component, call_type, &count)) != NULL) {
	flag = removeCallback(component, call_name, call_func, call_data);
    }
    if (getEventMask(component, call_type, &event_mask) == SP_TRUE) {
	flag = removeEventCallback(component, event_mask, call_func, call_data);
    }

    spDebug(50, "spRemoveCallback", "done: flag = %d\n", flag);
    
    return flag;
}

spCallbackReason spPrimitiveGetCallbackReasonArch(spComponent component)
{
    spCallbackReason call_reason = SP_CR_UNKNOWN;
    XEvent *event;
    int reason;
    XmAnyCallbackStruct *cbs;

    spDebug(40, "spPrimitiveGetCallbackReasonArch", "in\n");
    
    if (SpPrimitiveArch(component).xt_call_data != NULL) {
	if (SpPrimitiveArch(component).event_mask != NoEventMask) {
	    event = (XEvent *)SpPrimitiveArch(component).xt_call_data;
	    if (event->type == KeyPress) {
		call_reason = SP_CR_KEY_PRESS;
	    } else if (event->type == KeyRelease) {
		call_reason = SP_CR_KEY_RELEASE;
	    } else if (event->type == ButtonPress) {
		if (event->xbutton.button == Button1) {
		    call_reason = SP_CR_LBUTTON_PRESS;
		} else if (event->xbutton.button == Button3) {
		    call_reason = SP_CR_RBUTTON_PRESS;
		} else if (event->xbutton.button == Button2) {
		    call_reason = SP_CR_MBUTTON_PRESS;
		}
	    } else if (event->type == ButtonRelease) {
		if (event->xbutton.button == Button1) {
		    call_reason = SP_CR_LBUTTON_RELEASE;
		} else if (event->xbutton.button == Button3) {
		    call_reason = SP_CR_RBUTTON_RELEASE;
		} else if (event->xbutton.button == Button2) {
		    call_reason = SP_CR_MBUTTON_RELEASE;
		}
	    } else if (event->type == EnterNotify) {
		call_reason = SP_CR_ENTER_WINDOW;
	    } else if (event->type == LeaveNotify) {
		call_reason = SP_CR_LEAVE_WINDOW;
	    } else if (event->type == MotionNotify) {
		if (event->xmotion.state & Button1Mask) {
		    call_reason = SP_CR_LBUTTON_MOTION;
		} else if (event->xmotion.state & Button3Mask) {
		    call_reason = SP_CR_RBUTTON_MOTION;
		} else if (event->xmotion.state & Button2Mask) {
		    call_reason = SP_CR_MBUTTON_MOTION;
		} else {
		    call_reason = SP_CR_POINTER_MOTION;
		}
	    } else {
		call_reason = SP_CR_UNKNOWN;
	    }
	} else {
	    cbs = (XmAnyCallbackStruct *)SpPrimitiveArch(component).xt_call_data;
	    reason = cbs->reason;
	    spDebug(40, "spPrimitiveGetCallbackReasonArch", "reason = %d\n", reason);
	    switch (reason) {
	      case XmCR_HELP:
		call_reason = SP_CR_HELP;
		break;
	      case XmCR_DRAG:
	      case XmCR_VALUE_CHANGED:
		if (spIsSlider(component) == SP_TRUE) {
		    if (reason == XmCR_DRAG
			&& SpSliderPart(component).track_call_on == SP_FALSE) {
			spDebug(60, "spPrimitiveGetCallbackReasonArch", "track_call_on: FALSE\n");
			return SP_CR_NONE;
		    }
		}
		call_reason = SP_CR_VALUE_CHANGED;
		break;
	      case XmCR_DEFAULT_ACTION:
	      case XmCR_ACTIVATE:
		call_reason = SP_CR_ACTIVATE;
		break;
	      case XmCR_MAP:
		call_reason = SP_CR_MAP;
		break;
	      case XmCR_UNMAP:
		call_reason = SP_CR_UNMAP;
		break;
	      case XmCR_ARM:
		call_reason = SP_CR_BUTTON_PRESS;
		break;
	      case XmCR_DISARM:
		call_reason = SP_CR_BUTTON_RELEASE;
		break;
	      case XmCR_OK:
		call_reason = SP_CR_OK;
		break;
	      case XmCR_CANCEL:
		call_reason = SP_CR_CANCEL;
		break;
	      case XmCR_APPLY:
		call_reason = SP_CR_APPLY;
		break;
	      case XmCR_EXPOSE:
		call_reason = SP_CR_EXPOSE;
		break;
	      case XmCR_RESIZE:
		call_reason = SP_CR_RESIZE;
		break;
	      case XmCR_SINGLE_SELECT:
		call_reason = SP_CR_VALUE_CHANGED;
		break;
#if 0
	      case XmCR_FOCUS:
		call_reason = SP_CR_FOCUS;
		break;
	      case XmCR_LOSING_FOCUS:
		call_reason = SP_CR_LOSING_FOCUS;
		break;
	      case XmCR_INPUT:
		call_reason = SP_CR_INPUT;
		break;
#endif
	      default:
		call_reason = SP_CR_UNKNOWN;
		break;
	    }
	}
    } else {
	spDebug(10, "spPrimitiveGetCallbackReasonArch",
		"event_mask = %ld\n", SpPrimitiveArch(component).event_mask);
	if (SpPrimitiveArch(component).event_mask == SP_CLOSE_CALLBACK_ID) {
	    call_reason = SP_CR_CLOSE;
	} else if (SpPrimitiveArch(component).event_mask == SP_DESTROY_CALLBACK_ID) {
	    call_reason = SP_CR_DESTROY;
	}
    }
    
    spDebug(40, "spPrimitiveGetCallbackReasonArch", "done: call_reason = %d\n", call_reason);
    
    return call_reason;
}

spBool spPrimitiveGetCallbackMousePositionArch(spComponent component, int *x, int *y)
{
    int lx = 0, ly = 0;
    XEvent *event;
    
    if (SpPrimitiveArch(component).xt_call_data != NULL) {
	if (SpPrimitiveArch(component).event_mask != NoEventMask) {
	    event = (XEvent *)SpPrimitiveArch(component).xt_call_data;
	    switch (event->type) {
	      case ButtonPress:
	      case ButtonRelease:
		lx = event->xbutton.x;
		ly = event->xbutton.y;
		break;
	      case MotionNotify:
		lx = event->xmotion.x;
		ly = event->xmotion.y;
		break;
	      default:
		return SP_FALSE;
	    }
	    if (x != NULL) *x = lx;
	    if (y != NULL) *y = ly;
	    
	    return SP_TRUE;
	}
    }
    
    return SP_FALSE;
}

static spKeySym convertKeySym(KeySym key_sym)
{
    if (key_sym >= 0x020 && key_sym <= 0x0ff) {
	return SPK_Character;
    } else {
	switch (key_sym) {
	  case SPK_BackSpace:		
	  case SPK_Tab:			
	  /*case SPK_Linefeed:*/
	  case SPK_Clear:		
	  case SPK_Return:		
	  case SPK_Pause:		
	  case SPK_ScrollLock:		
	  /*case SPK_Sys_Req:*/		
	  case SPK_Escape:		
	  case SPK_Delete:		
	  case SPK_Shift:		
	  case SPK_Control:		
	  case SPK_CapsLock:		
	  /*case SPK_ShiftLock:*/
	  /*case SPK_Menu:*/
	  case SPK_Home:		
	  case SPK_Left:		
	  case SPK_Up:			
	  case SPK_Right:		
	  case SPK_Down:		
	  case SPK_Prior:		
	  /*case SPK_PageUp:*/		
	  case SPK_Next:		
	  /*case SPK_PageDown:*/		
	  case SPK_End:			
	  /*case SPK_Begin:*/		
	  case SPK_Select:		
	  case SPK_Print:		
	  case SPK_Execute:		
	  case SPK_Insert:		
	  case SPK_Cancel:		
	  case SPK_Help:		
	  case SPK_NumLock:		

	  case SPK_F1:			
	  case SPK_F2:			
	  case SPK_F3:			
	  case SPK_F4:		
	  case SPK_F5:			
	  case SPK_F6:			
	  case SPK_F7:			
	  case SPK_F8:			
	  case SPK_F9:			
	  case SPK_F10:			
	  case SPK_F11:			
	  case SPK_F12:		
	  case SPK_F13:			
	  case SPK_F14:			
	  case SPK_F15:			
	  case SPK_F16:			
	  case SPK_F17:			
	  case SPK_F18:			
	  case SPK_F19:			
	  case SPK_F20:			
	  case SPK_F21:			
	  case SPK_F22:			
	  case SPK_F23:			
	  case SPK_F24:			
	  case SPK_Alt:			
	    return key_sym;
	  case XK_Shift_R:		
	  case XK_Control_R:		
	  case XK_Alt_R:		
	    return (key_sym - 0x01);
	  case XK_Menu:		
	  case XK_Meta_L:		
	  case XK_Meta_R:		
	    return SPK_Alt;
	  default:
	    break;
	}
    }

    return SPK_Unknown;
}

spBool spPrimitiveGetCallbackKeySymArch(spComponent component, spKeySym *key_sym)
{
    XEvent *event;
    KeySym xks;
    spKeySym ks;
    int buf_size = 1024;
    char buf[1024];
    
    if (SpPrimitiveArch(component).xt_call_data != NULL) {
	if (SpPrimitiveArch(component).event_mask != NoEventMask) {
	    event = (XEvent *)SpPrimitiveArch(component).xt_call_data;
	    switch (event->type) {
	      case KeyPress:
	      case KeyRelease:
		XLookupString(&event->xkey, buf, buf_size, &xks, NULL);
		ks = convertKeySym(xks);
		if (ks != SPK_Unknown /*&& ks != SPK_Character*/) {
		    *key_sym = ks;
		    return SP_TRUE;
		}
		break;
	      default:
		break;
	    }
	    
	}
    }

    return SP_FALSE;
}

int spPrimitiveGetCallbackKeyStringArch(spComponent component,
					char *buf, int buf_size, spBool *overflow)
{
    int len;
    XEvent *event;
    KeySym xks;
    spKeySym ks;
    
    if (SpPrimitiveArch(component).xt_call_data != NULL) {
	if (SpPrimitiveArch(component).event_mask != NoEventMask) {
	    event = (XEvent *)SpPrimitiveArch(component).xt_call_data;
	    switch (event->type) {
	      case KeyPress:
	      case KeyRelease:
		if (buf_size <= 1) {
		    if (overflow != NULL) {
			*overflow = SP_TRUE;
		    }
		    len = 0;
		} else {
		    len = XLookupString(&event->xkey, buf, buf_size, &xks, NULL);
		    ks = convertKeySym(xks);
		    if (ks != SPK_Character) {
			return -1;
		    }
		    if (overflow != NULL) {
			*overflow = SP_FALSE;
		    }
		}
		return len;
	      default:
		break;
	    }
	    
	}
    }

    return -1;
}

void spPrimitivePartInitArch(spComponent component)
{
    if (component != NULL) {
	SpPrimitiveArch(component).toplevel = NULL;
	SpPrimitiveArch(component).widget = NULL;
	SpPrimitiveArch(component).top_widget = NULL;
	SpPrimitiveArch(component).sub_widget = NULL;
	SpPrimitiveArch(component).pixmap = None;
	SpPrimitiveArch(component).drawable = None;
	SpPrimitiveArch(component).display = NULL;
	SpPrimitiveArch(component).screen = NULL;
	SpPrimitiveArch(component).xt_call_data = NULL;
	SpPrimitiveArch(component).event_mask = NoEventMask;
	SpPrimitiveArch(component).num_xmstring = 0;
	SpPrimitiveArch(component).num_xmstring_buffer = 0;
	SpPrimitiveArch(component).xmstrings = NULL;
    }
    
    return;
}

void spPrimitiveDestroyArch(spComponent component)
{
    int i;
    Widget widget = NULL;
    Pixmap pixmap = None;
    
    spDebug(30, "spDestroyComponent", "in\n");
    
    if (SpPrimitiveArch(component).pixmap != None) {
	pixmap = SpPrimitiveArch(component).pixmap;
	SpPrimitiveArch(component).pixmap = None;
	XFreePixmap(SpPrimitiveArch(component).display, pixmap);
    }

    if (spIsWindow((spComponent)component) == SP_TRUE
	&& SpPrimitiveArch(component).toplevel != NULL) {
	spDebug(30, "spDestroyComponent", "destroy window\n");
	if (SpTopLevelArch(sp_toplevel).widget == SpPrimitiveArch(component).toplevel) {
	    spQuit(0);
	} else {
	    widget = SpPrimitiveArch(component).toplevel;
	    SpPrimitiveArch(component).toplevel = NULL;
	    XtUnrealizeWidget(widget);
	}
    } else if (spIsDialog((spComponent)component) == SP_TRUE) {
	spDebug(30, "spDestroyComponent", "destroy dialog\n");
	widget = SpPrimitiveArch(component).top_widget;
	if (widget != NULL) {
	    SpPrimitiveArch(component).top_widget = NULL;
	    XtUnrealizeWidget(widget);
	}
    } else {
	if (SpPrimitiveArch(component).top_widget != NULL) {
	    widget = SpPrimitiveArch(component).top_widget;
	    SpPrimitiveArch(component).top_widget = NULL;
	    SpPrimitiveArch(component).sub_widget = NULL;
	    SpPrimitiveArch(component).widget = NULL;
	    XtUnrealizeWidget(widget);
	} else {
	    if (SpPrimitiveArch(component).sub_widget != NULL) {
		widget = SpPrimitiveArch(component).sub_widget;
		SpPrimitiveArch(component).sub_widget = NULL;
		XtUnrealizeWidget(widget);
	    }
	    if (SpPrimitiveArch(component).widget != NULL) {
		widget = SpPrimitiveArch(component).widget;
		SpPrimitiveArch(component).widget = NULL;
		XtUnrealizeWidget(widget);
	    }
	}
    }

    if (SpPrimitiveArch(component).num_xmstring >= 1) {
	for (i = 0; i < SpPrimitiveArch(component).num_xmstring; i++) {
	    XmStringFree(SpPrimitiveArch(component).xmstrings[i]);
	}
	xfree(SpPrimitiveArch(component).xmstrings);
    }
    
    spDebug(30, "spDestroyComponent", "done\n");

    return;
}

void spPrimitiveMapArch(spComponent component)
{
    if (SpPrimitiveArch(component).top_widget != NULL) {
	XtManageChild(SpPrimitiveArch(component).top_widget);
    } else if (SpPrimitiveArch(component).widget != NULL){
	XtManageChild(SpPrimitiveArch(component).widget);
	if (SpPrimitiveArch(component).sub_widget != NULL) {
	    XtManageChild(SpPrimitiveArch(component).sub_widget);
	}
    }

    if (spIsSubClass(component, SpTabBox) == SP_TRUE) {
	spMapTabItem(component, SpTabBoxPart(component).selected_index);
    }

    return;
}

void spPrimitiveUnmapArch(spComponent component)
{
    if (spIsDialog(component) == SP_TRUE) {
	XtUnmanageChild(SpPrimitiveArch(component).widget);
    } else if (SpPrimitiveArch(component).top_widget != NULL) {
	XtUnmanageChild(SpPrimitiveArch(component).top_widget);
    } else if (SpPrimitiveArch(component).widget != NULL){
	if (SpPrimitiveArch(component).sub_widget != NULL) {
	    XtUnmanageChild(SpPrimitiveArch(component).sub_widget);
	}
	XtUnmanageChild(SpPrimitiveArch(component).widget);
    }
    
    spDebug(30, "spPrimitiveUnmapArch", "done\n");
    
    return;
}

#define SP_MIN_WIDGET_WIDTH 10
#define SP_MIN_WIDGET_HEIGHT 10

spBool spPrimitiveSetSizeArch(spComponent component, int width, int height)
{
    Widget widget = NULL;
    short n = 0;
    int x, y;
    
    if (SpPrimitiveArch(component).widget != NULL) {
	if (spIsFrame(component) == SP_TRUE) {
	    int h;

	    if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		    height += h;
		}
	    }
#if 0
	    if (spIsVisible(SpFramePart(component).tool_bar) == SP_TRUE) {
		if (spGetSize(SpFramePart(component).tool_bar, NULL, &h) == SP_TRUE) {
		    height += h;
		}
	    }
#endif

	    if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
		XtVaSetValues(SpPrimitiveArch(component).toplevel,
			      XmNwidth, (short)MAX(width, SP_MIN_WIDGET_WIDTH),
			      XmNheight, (short)MAX(height, SP_MIN_WIDGET_HEIGHT),
			      NULL);
	    }
	    
	    if (SpComponentPart(component).x != 0 && SpComponentPart(component).y != 0) {
		XtVaSetValues(SpPrimitiveArch(component).toplevel,
			      XmNx, SpComponentPart(component).x,
			      XmNy, SpComponentPart(component).y,
			      NULL);
	    }
		
	    widget = SpPrimitiveArch(component).widget;
	    x = 0; y = 0;
	} else {
	    widget = (SpPrimitiveArch(component).top_widget != NULL ?
		      SpPrimitiveArch(component).top_widget : SpPrimitiveArch(component).widget);
	    if (spIsSubClass(component, SpPushButton) == SP_TRUE) {
		short thickness1, thickness2;
		XtVaGetValues(widget,
			      XmNshadowThickness, &thickness1,
			      XmNdefaultButtonShadowThickness, &thickness2,
			      NULL);
		if (thickness2 > 0) {
		    n = thickness1 * 2 + thickness2;
		}
	    }
	    
	    x = SpComponentPart(component).x - n;
	    y = SpComponentPart(component).y - n;
	}

	spDebug(30, "spPrimitiveSetSizeArch",
		"x = %d, y = %d, width = %d, height = %d\n", x, y, width, height);
		
	XtVaSetValues(widget,
		      XmNx, x, XmNy, y,
		      XmNwidth, (short)MAX(width + 2 * n, SP_MIN_WIDGET_WIDTH),
		      XmNheight, (short)MAX(height + 2 * n, SP_MIN_WIDGET_HEIGHT),
		      NULL);

	if (spIsSubClass(component, SpTabBox) == SP_TRUE) {
	    XtVaSetValues(SpPrimitiveArch(component).sub_widget,
			  XmNwidth, (short)width + 2 * n,
			  NULL);
	} else if (spIsCanvas(component) == SP_TRUE && spIsVisible(component) == SP_TRUE) {
	    spDebug(10, "spPrimitiveSetSizeArch", "refresh canvas\n");
	    spGetClientSize(component, NULL, NULL);
	    spRedrawCanvas(component);
	}
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetSizeArch(spComponent component, int *width, int *height)
{
    short w = 0, h = 0;
    Widget widget;
		    
    if (spIsFrame(component) == SP_TRUE) {
	widget = SpPrimitiveArch(component).widget;
    } else {
	widget = (SpPrimitiveArch(component).top_widget != NULL ?
		  SpPrimitiveArch(component).top_widget : SpPrimitiveArch(component).widget);
    }

    if (widget != NULL) {
	XtVaGetValues(widget,
		      XmNwidth, &w,
		      XmNheight, &h,
		      NULL);
	
	*width = (int)w;
	*height = (int)h;

	if (spIsFrame(component) == SP_TRUE) {
	    int h;
	    
	    if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		    *height -= h;
		}
	    }
	}
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveGetClientSizeArch(spComponent component, int *width, int *height)
{
    short w = 0, h = 0;
		    
    if (SpPrimitiveArch(component).widget != NULL) {
	XtVaGetValues(SpPrimitiveArch(component).widget,
		      XmNwidth, &w,
		      XmNheight, &h,
		      NULL);
	
	*width = (int)w;
	*height = (int)h;

	spDebug(30, "spPrimitiveGetClientSizeArch",
		"width = %d, height = %d\n", w, h);
	
	if (spIsWindow(component) == SP_TRUE) {
	    int h;
	    
	    if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
		if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		    *height -= h;
		}
	    }
	}
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

spBool spPrimitiveSetSensitiveArch(spComponent component, spBool flag)
{
    if (SpPrimitiveArch(component).widget != NULL) {
        if (flag == SP_TRUE) {
            if (SpPrimitiveArch(component).top_widget != NULL) {
                XtSetSensitive(SpPrimitiveArch(component).top_widget, True);
            } else {
                XtSetSensitive(SpPrimitiveArch(component).widget, True);
                if (SpPrimitiveArch(component).sub_widget != NULL) {
                    XtSetSensitive(SpPrimitiveArch(component).sub_widget, True);
                }
            }
        } else {
	    spPopdownToolTipXm(component);
            if (SpPrimitiveArch(component).top_widget != NULL) {
                XtSetSensitive(SpPrimitiveArch(component).top_widget, False);
            } else {
                if (SpPrimitiveArch(component).sub_widget != NULL) {
                    XtSetSensitive(SpPrimitiveArch(component).sub_widget, False);
                }
                XtSetSensitive(SpPrimitiveArch(component).widget, False);
            }
        }
        
        return SP_TRUE;
    } else {
        return SP_FALSE;
    }
}

#define SP_TOOL_TIP_INTERVAL 750
#define SP_TOOL_TIP_MARGIN 3
#define SP_TOOL_TIP_SPACING 4
#define SP_TOOL_TIP_BACKGROUND "#ffffcc"

Widget sp_tool_tip_parent = NULL;
Widget sp_tool_tip_widget = NULL;
XtIntervalId sp_interval_id;

spBool sp_add_time_out = SP_FALSE;
int sp_tool_tip_x = 0;
int sp_tool_tip_y = 0;
int sp_tool_tip_width = 0;
int sp_tool_tip_height = 0;

static char sp_tool_tip_default_string[SP_MAX_LINE] = "(none)";
char *sp_tool_tip_string = NULL;

static void exposeToolTipCB(Widget widget, XtPointer client_data,
			    XtPointer call_data)
{
    if (sp_tool_tip_string != NULL) {
	XmbDrawString(XtDisplay(widget),
		      XtWindow(widget),
		      SpTopLevelArch(sp_toplevel).font_set,
		      SpTopLevelArch(sp_toplevel).fg_gc,
		      sp_tool_tip_x, sp_tool_tip_y,
		      sp_tool_tip_string, strlen(sp_tool_tip_string));
    }

    return;
}

static void popupToolTipCB(XtPointer client_data, XtIntervalId *id)
{
    spComponent component = (spComponent)client_data;
    Widget draw_area;
    int x, y, width, height;
    XRectangle ink;
    XRectangle logical;

    if (component == NULL || SpPrimitiveArch(component).widget == NULL) return;

    sp_tool_tip_string = SpComponentPart(component).description;
    if (strnone(sp_tool_tip_string)) {
	sp_tool_tip_string = sp_tool_tip_default_string;
    }

    if (sp_tool_tip_widget != NULL) {
	XtUnrealizeWidget(sp_tool_tip_widget);
    }
    sp_tool_tip_widget = NULL;
    sp_tool_tip_parent = NULL;
    
    XmbTextExtents(SpTopLevelArch(sp_toplevel).font_set,
		   sp_tool_tip_string, strlen(sp_tool_tip_string),
		   &ink, &logical);
    sp_tool_tip_x = MAX(logical.x + SP_TOOL_TIP_SPACING, 0);
    sp_tool_tip_y = MAX(-logical.y + SP_TOOL_TIP_SPACING, 0);
    sp_tool_tip_width = logical.width + 2 * SP_TOOL_TIP_SPACING + 1;
    sp_tool_tip_height = logical.height + 2 * SP_TOOL_TIP_SPACING + 1;
    
    spDebug(40, "popupToolTipCB", "x = %d, y = %d, width = %d, height = %d\n", 
	    sp_tool_tip_x, sp_tool_tip_y, sp_tool_tip_width, sp_tool_tip_height);
    
    sp_tool_tip_parent = SpPrimitiveArch(component).widget;
    
    /* get current position of widget */
    spGetScreenGeometry(sp_tool_tip_parent, &x, &y, &width, &height);

    sp_tool_tip_widget = XtVaAppCreateShell("ToolTip", "toolTip",
					    overrideShellWidgetClass,
					    XtDisplay(sp_tool_tip_parent),
					    XmNx, x + width / 2,
					    XmNy, y + height + SP_TOOL_TIP_MARGIN,
					    XmNwidth, sp_tool_tip_width,
					    XmNheight, sp_tool_tip_height,
					    NULL);

    draw_area =  XtVaCreateManagedWidget("drawingArea",
					 xmDrawingAreaWidgetClass,
					 sp_tool_tip_widget,
					 XmNbackground, spGetColorPixelXm(SP_TOOL_TIP_BACKGROUND),
					 NULL);
    XtAddCallback(draw_area, XmNexposeCallback, exposeToolTipCB, (void *)component);
    
    XtRealizeWidget(sp_tool_tip_widget);
    
    return;
}

static void waitToolTipCB(Widget widget, XtPointer client_data,
			  XtPointer call_data)
{
    spComponent component = (spComponent)client_data;

    spDebug(30, "waitToolTipCB", "in\n");
    
    if (sp_tool_tip_widget != NULL) {
	XtUnrealizeWidget(sp_tool_tip_widget);
    }
    sp_tool_tip_widget = NULL;
    sp_tool_tip_parent = NULL;

    if (!strnone(SpComponentPart(component).description)) {
	sp_tool_tip_parent = widget;
	sp_tool_tip_string = NULL;
	sp_interval_id = XtAppAddTimeOut(SpTopLevelArch(sp_toplevel).app_context, SP_TOOL_TIP_INTERVAL,
					 popupToolTipCB, component);
	sp_add_time_out = SP_TRUE;
    }

    return;
}

static void popdownToolTip(Widget widget)
{
    spDebug(30, "popdownToolTip", "in\n");
    
    if (sp_tool_tip_widget != NULL) {
	XtUnrealizeWidget(sp_tool_tip_widget);
    }
    if (sp_add_time_out == SP_TRUE) {
	XtRemoveTimeOut(sp_interval_id);
    }
    sp_tool_tip_widget = NULL;
    sp_tool_tip_parent = NULL;
    sp_tool_tip_string = NULL;
    sp_add_time_out = SP_FALSE;

    return;
}

static void popdownToolTipCB(Widget widget, XtPointer client_data,
			     XtPointer call_data)
{
    popdownToolTip(widget);
    return;
}

void spPopdownToolTipXm(spComponent component)
{
    if (spIsPrimitive(component) == SP_FALSE) return;

    if (SpPrimitiveArch(component).widget != NULL
	&& SpPrimitiveArch(component).widget == sp_tool_tip_parent) {
	popdownToolTip(SpPrimitiveArch(component).widget);
    }

    return;
}

spBool spShowToolTipArch(spComponent component)
{
    if (SpPrimitiveArch(component).widget != NULL) {
	XtAddEventHandler(SpPrimitiveArch(component).widget, EnterWindowMask, False,
			  (XtEventHandler)waitToolTipCB, (XtPointer)component);
	XtAddEventHandler(SpPrimitiveArch(component).widget, LeaveWindowMask, False,
			  (XtEventHandler)popdownToolTipCB, (XtPointer)component);
	
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}
