/*
 *	spFrame_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/keysym.h>
#include <Xm/Xm.h>
#include <Xm/BulletinB.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/MainW.h>
#include <Xm/DrawingA.h>
#include <Xm/AtomMgr.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spDialog.h>
#include <sp/spContainer.h>

#include <sp/spFrameP.h>
#include <sp/spStatusBarP.h>

extern spTopLevel sp_toplevel;

static spComponent sp_grabbed_window = NULL;

void spFramePartInitArch(spComponent component)
{
    return;
}

void spFramePartFreeArch(spComponent component)
{
    return;
}

static void fixWindowSize(Widget widget, XtPointer client_data, XEvent *event)
{
    short width = 0, height = 0;
    spComponent component = (spComponent)client_data;

    if (event->type != ConfigureNotify) return;

    XtVaGetValues(SpPrimitiveArch(component).toplevel,
		  XmNwidth, &width,
		  XmNheight, &height,
		  NULL);
    spDebug(20, "fixWindowSize", "width = %d, height = %d\n", width, height);

    XtVaSetValues(SpPrimitiveArch(component).toplevel,
		  XmNminWidth, width,
		  XmNmaxWidth, width,
		  XmNminHeight, height,
		  XmNmaxHeight, height,
		  NULL);

    XtRemoveEventHandler(SpPrimitiveArch(component).toplevel, StructureNotifyMask,
			 False, (XtEventHandler)fixWindowSize, (XtPointer)component);

    return;
}

static void adjustComponentSize(Widget widget, XtPointer client_data, XEvent *event)
{
    if (event->type != ConfigureNotify) return;

    spAdjustComponentSize((spComponent)client_data);
    return;
}

long spPostMessageXm(spComponent component, String call_name,
		     XtPointer xt_call_data, EventMask event_mask)
{
    long k;
    long component_id;
    long num_callback;
    
    if ((component_id = SpGetComponentId(component)) == spGetDestroyedComponentId()) {
	/* now destroying */
	component_id = 0;
    }
    num_callback = SpPrimitivePart(component).num_callback;
    
    for (k = 0; k < num_callback; k++) {
	if (streq(SpPrimitivePart(component).callbacks[k].call_name, call_name)
	    && SpPrimitivePart(component).callbacks[k].component != NULL) {
	    SpPrimitiveArch(SpPrimitivePart(component).callbacks[k].component).xt_call_data = xt_call_data;
	    SpPrimitiveArch(SpPrimitivePart(component).callbacks[k].component).event_mask = event_mask;
	    spComponentCallbackFunc(&SpPrimitivePart(component).callbacks[k]);

	    if (component_id == spGetDestroyedComponentId()) {
		break;
	    }
	}
    }
    
    return component_id;
}

static void unmapWindowCB(Widget widget, XtPointer client_data, XEvent *event)
{
    long component_id;
    spComponent component = (spComponent)client_data;
    
    if (event->type != UnmapNotify) return;

    spDebug(10, "unmapWindowCB", "in\n");
    
    if (spIsCreated(component) == SP_TRUE && SpComponentPart(component).visible_flag == SP_TRUE) {
	SpComponentPart(component).visible_flag = SP_FALSE;
	spPopdownFrameArch(component);
	if (SpFramePart(component).close_style == SP_DESTROY_CLOSE
	    || SpFramePart(component).close_style == SP_UNMAP_CLOSE) {
	    component_id = spPostMessageXm(component, XmNdestroyCallback,
					   NULL, SP_CLOSE_CALLBACK_ID);

	    if (SpFramePart(component).close_style == SP_DESTROY_CLOSE) {
		if (component_id != spGetDestroyedComponentId()) {
		    spDestroyComponent(component);
		}
	    }
	}
    }
    
    return;
}

static Atom wm_protocols = None;
static Atom wm_delete_window = None;

static void clientMessageCB(Widget widget, XtPointer client_data, XEvent *event)
{
    spComponent component = (spComponent)client_data;
    
    if (event->type == ClientMessage) {
	if ((sp_grabbed_window == NULL || sp_grabbed_window == component)
	    && event->xclient.message_type == wm_protocols
	    && event->xclient.data.l[0] == wm_delete_window) {
	    spDebug(10, "clientMessageCB", "ClientMessage received\n");
	    if (SpFramePart(component).close_style == SP_CALLBACK_CLOSE) {
		spPostMessageXm(component, XmNdestroyCallback, NULL, SP_CLOSE_CALLBACK_ID);
	    }
	}
    }
    
    return;
}

void spAdjustComponentSizeCB(spComponent component, void *data)
{
    spAdjustComponentSize(component);

    return;
}

static spBool sp_main_frame_created = SP_FALSE;
static Atom atom = None;

void spFrameCreateArch(spComponent component)
{
    int narg = 0, narg2 = 0;
    Arg args[10], args2[10];
    char *title = NULL, *icon_name = NULL;
    XmString xmstr;
    char *ctext;

    if (wm_protocols == None) {
	wm_protocols = XInternAtom(XtDisplay(SpTopLevelArch(sp_toplevel).widget),
				   "WM_PROTOCOLS", False);
	wm_delete_window = XInternAtom(XtDisplay(SpTopLevelArch(sp_toplevel).widget),
				       "WM_DELETE_WINDOW", False);
    }
    
    if (!strnone(SpFramePart(component).icon_name)) {
	icon_name = SpFramePart(component).icon_name;
    }
    
    if (!strnone(SpComponentPart(component).title)) {
	title = SpComponentPart(component).title;
    }
    
    if (strnone(icon_name)) {
	icon_name = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }
    
    if (strnone(title)) {
	title = (!strnone(SpGetName(component)) ? SpGetName(component) : "");
    }

    if (SpFramePart(component).close_style == SP_DESTROY_CLOSE) {
	SpFrameArch(component).delete_response = XmUNMAP;
    } else if (SpFramePart(component).close_style == SP_CALLBACK_CLOSE) {
	/* not implemented yet */
	SpFrameArch(component).delete_response = XmDO_NOTHING;
    } else if (SpFramePart(component).close_style == SP_UNMAP_CLOSE) {
	SpFrameArch(component).delete_response = XmUNMAP;
    } else {
	SpFrameArch(component).delete_response = XmDO_NOTHING;
    }
    XtSetArg(args2[narg2], XmNdeleteResponse,
	     SpFrameArch(component).delete_response); narg2++;

    if (SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	XtSetArg(args2[narg2], XmNoverrideRedirect, True); narg2++;
    }

    if (spIsSubClass(component, SpMainFrame) == SP_TRUE
	&& sp_main_frame_created == SP_FALSE) {
	sp_main_frame_created = SP_TRUE;
	SpPrimitiveArch(component).toplevel = SpTopLevelArch(sp_toplevel).widget;
	XtSetValues(SpPrimitiveArch(component).toplevel, args2, narg2);
    } else {
	SpPrimitiveArch(component).toplevel =
	    XtAppCreateShell("Shell", "shell",
			     topLevelShellWidgetClass,
			     XtDisplay(SpTopLevelArch(sp_toplevel).widget),
			     args2, narg2);
    }
    XtAddEventHandler(SpPrimitiveArch(component).toplevel, NoEventMask,
		      True, (XtEventHandler)clientMessageCB, (XtPointer)component);
    XtAddEventHandler(SpPrimitiveArch(component).toplevel, StructureNotifyMask,
		      False, (XtEventHandler)unmapWindowCB, (XtPointer)component);
    if (SpFramePart(component).resize_flag == SP_FALSE) {
	XtAddEventHandler(SpPrimitiveArch(component).toplevel, StructureNotifyMask,
			  False, (XtEventHandler)fixWindowSize, (XtPointer)component);
    }
    
    SpPrimitiveArch(component).top_widget =
	XtCreateManagedWidget("",
			      xmMainWindowWidgetClass,
			      SpPrimitiveArch(component).toplevel,
			      NULL, 0);
    
    XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
    XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
    XtSetArg(args[narg], XmNresizePolicy, XmRESIZE_NONE); narg++;
#ifdef SP_USE_BULLETIN_BOARD_FOR_WINDOW
    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component))
			       ? SpGetName(component) : ""),
			      xmBulletinBoardWidgetClass,
			      (SpPrimitiveArch(component).top_widget != NULL ?
			       SpPrimitiveArch(component).top_widget :
			       SpPrimitiveArch(component).toplevel),
			      args, narg);
    XtAddEventHandler(SpPrimitiveArch(component).toplevel, StructureNotifyMask,
		      False, (XtEventHandler)adjustComponentSize, (XtPointer)component);
#else
    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component))
			       ? SpGetName(component) : ""),
			      xmDrawingAreaWidgetClass,
			      (SpPrimitiveArch(component).top_widget != NULL ?
			       SpPrimitiveArch(component).top_widget :
			       SpPrimitiveArch(component).toplevel),
			      args, narg);
    spAddCallback(component, SP_RESIZE_CALLBACK, spAdjustComponentSizeCB, NULL);
#endif

    if (!strnone(title)) {
	xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	ctext = XmCvtXmStringToCT(xmstr);

	if (atom == None) {
	    atom = XmInternAtom(XtDisplay(SpPrimitiveArch(component).toplevel),
				"COMPOUND_TEXT", False);
	}
	XtVaSetValues(SpPrimitiveArch(component).toplevel,
		      XmNtitle, ctext,
		      XmNtitleEncoding, atom,
		      NULL);
	XtFree(ctext);
	XmStringFree(xmstr);
    }

    if (!strnone(icon_name)) {
	xmstr = XmStringCreate(icon_name, XmFONTLIST_DEFAULT_TAG);
	ctext = XmCvtXmStringToCT(xmstr);

	if (atom == None) {
	    atom = XmInternAtom(XtDisplay(SpPrimitiveArch(component).toplevel),
				"COMPOUND_TEXT", False);
	}
	XtVaSetValues(SpPrimitiveArch(component).toplevel,
		      XmNiconName, ctext,
		      XmNiconNameEncoding, atom,
		      NULL);
	XtFree(ctext);
	XmStringFree(xmstr);
    }
    
    return;
}

void spFrameDestroyArch(spComponent component)
{
    spPostMessageXm(component, SppDestroyCallback, NULL, SP_DESTROY_CALLBACK_ID);

    return;
}
    
void spFrameSetParamsArch(spComponent component)
{
    char *title = NULL, *icon_name = NULL;
    XmString xmstr;
    char *ctext;

    if (SpFramePart(SpOldObject(component)).icon_name != SpFramePart(component).icon_name) {    
	if (!strnone(SpFramePart(component).icon_name)) {
	    icon_name = SpFramePart(component).icon_name;
	}
	
	if (!strnone(icon_name)) {
	    xmstr = XmStringCreate(icon_name, XmFONTLIST_DEFAULT_TAG);
	    ctext = XmCvtXmStringToCT(xmstr);

	    if (atom == None) {
		atom = XmInternAtom(XtDisplay(SpPrimitiveArch(component).toplevel),
				    "COMPOUND_TEXT", False);
	    }
	    XtVaSetValues(SpPrimitiveArch(component).toplevel,
			  XmNiconName, ctext,
			  XmNiconNameEncoding, atom,
			  NULL);
	    XtFree(ctext);
	    XmStringFree(xmstr);
	}
    }

    if (SpFramePart(SpOldObject(component)).close_style != SpFramePart(component).close_style) {
	if (SpFramePart(component).close_style == SP_DESTROY_CLOSE) {
	    SpFrameArch(component).delete_response = XmUNMAP;
	} else if (SpFramePart(component).close_style == SP_CALLBACK_CLOSE) {
	    /* not implemented yet */
	    SpFrameArch(component).delete_response = XmDO_NOTHING;
	} else if (SpFramePart(component).close_style == SP_UNMAP_CLOSE) {
	    SpFrameArch(component).delete_response = XmUNMAP;
	} else {
	    SpFrameArch(component).delete_response = XmDO_NOTHING;
	}
	XtVaSetValues(SpPrimitiveArch(component).toplevel,
		      XmNdeleteResponse, SpFrameArch(component).delete_response,
		      NULL);
    }
    
    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	if (!strnone(SpComponentPart(component).title)) {
	    title = SpComponentPart(component).title;
	}
	
	if (!strnone(title)) {
	    xmstr = XmStringCreate(title, XmFONTLIST_DEFAULT_TAG);
	    ctext = XmCvtXmStringToCT(xmstr);

	    if (atom == None) {
		atom = XmInternAtom(XtDisplay(SpPrimitiveArch(component).toplevel),
				    "COMPOUND_TEXT", False);
	    }
	    XtVaSetValues(SpPrimitiveArch(component).toplevel,
			  XmNtitle, ctext,
			  XmNtitleEncoding, atom,
			  NULL);
	    XtFree(ctext);
	    XmStringFree(xmstr);
	}
    }
    
    return;
}

void *spGetArchFrame(spComponent component)
{
    return (void *)SpPrimitiveArch(component).top_widget;
}

spBool spIsTaskTraySupported(void)
{
    return SP_FALSE;
}

spBool spShowTaskTrayArch(spComponent window, spBool flag)
{
    return SP_FALSE;
}

static void setAllDeleteResponse(spComponent window, spComponent avoid, spBool revert)
{
    spComponent next_window;
    unsigned char delete_response;

    next_window = window;
    do {
	if (next_window != avoid
	    && spIsVisible(next_window) == SP_TRUE
	    && spIsPrimitive(next_window) == SP_TRUE) {
	    if (spIsFrame(next_window) == SP_TRUE
		&& SpPrimitiveArch(next_window).toplevel != NULL) {
		if (revert == SP_TRUE) {
		    delete_response = SpFrameArch(next_window).delete_response;
		} else {
		    delete_response = XmDO_NOTHING;
		}
		XtVaSetValues(SpPrimitiveArch(next_window).toplevel,
			      XmNdeleteResponse, delete_response,
			      NULL);
	    } else if (SpPrimitiveArch(next_window).top_widget != NULL) {
		if (revert == SP_TRUE) {
		    delete_response = XmUNMAP;
		} else {
		    delete_response = XmDO_NOTHING;
		}
		XtVaSetValues(SpPrimitiveArch(next_window).top_widget,
			      XmNdeleteResponse, delete_response,
			      NULL);
	    }
	}
	next_window = spGetNextWindow(next_window, SP_TRUE);
    } while (next_window != NULL && next_window != window);

    if (SpGetParent(window) != NULL) {
	setAllDeleteResponse(SpGetParent(window), NULL, revert);
    }

    return;
}

void spRemoveGrabXm(spComponent window)
{
    Widget widget = NULL;
    
    if (sp_grabbed_window != NULL
	&& (window == NULL || sp_grabbed_window == window)) {
	spDebug(50, "spRemoveGrabXm", "in\n");
	
	window = sp_grabbed_window;

	setAllDeleteResponse(window, window, SP_TRUE);

	if (SpPrimitiveArch(window).toplevel != NULL) {
	    widget = SpPrimitiveArch(window).toplevel;
	} else if (SpPrimitiveArch(window).top_widget != NULL) {
	    widget = SpPrimitiveArch(window).top_widget;
	}

	if (widget != NULL) {
	    XtRemoveGrab(widget);
	}
	sp_grabbed_window = NULL;
	
	spDebug(50, "spRemoveGrabXm", "done\n");
    }
    
    return;
}

spComponent spAddGrabXm(spComponent window)
{
    spComponent prev = NULL;
    Widget widget = NULL;

    if (sp_grabbed_window != NULL) {
	prev = sp_grabbed_window;
	spRemoveGrabXm(sp_grabbed_window);
    }
    
    if (spIsCreated(window) == SP_TRUE) {
	spDebug(50, "spAddGrabXm", "in\n");

	setAllDeleteResponse(window, window, SP_FALSE);
	
	if (SpPrimitiveArch(window).toplevel != NULL) {
	    widget = SpPrimitiveArch(window).toplevel;
	} else if (SpPrimitiveArch(window).top_widget != NULL) {
	    widget = SpPrimitiveArch(window).top_widget;
	}
	
	if (widget != NULL) {
	    XtAddGrab(widget, True, False);
	}
	sp_grabbed_window = window;
	
	spDebug(50, "spAddGrabXm", "done\n");
    }
    
    return prev;
}

void spPopupFrameArch(spComponent frame, spBool move_cursor)
{
    Widget widget = NULL;
    Widget menu_bar = NULL;
    
    spDebug(50, "spPopupFrameArch", "in\n");
    
    if (SpPrimitiveArch(frame).toplevel != NULL) {
	widget = SpPrimitiveArch(frame).toplevel;
	if (XtIsRealized(widget) == False) {
	    if (SpPrimitiveArch(frame).top_widget != NULL
		&& XtIsSubclass(SpPrimitiveArch(frame).top_widget, xmMainWindowWidgetClass)) {
		if (SpFramePart(frame).menu_bar != NULL) {
		    menu_bar = SpPrimitiveArch(SpFramePart(frame).menu_bar).widget;
		}

		XmMainWindowSetAreas(SpPrimitiveArch(frame).top_widget,
				     menu_bar, NULL, NULL, NULL,
				     SpPrimitiveArch(frame).widget);
	    }

	    spAdjustComponentSize(frame);
	    XtRealizeWidget(widget);
	} else {
	    XtMapWidget(widget);
	    XRaiseWindow(XtDisplay(widget), XtWindow(widget));

	    if (move_cursor == SP_TRUE) {
		/* move pointer */
		XWarpPointer(XtDisplay(widget), None, XtWindow(widget),
			     0, 0, 0, 0, 0, 0);
	    }
	}
    } else if (SpPrimitiveArch(frame).widget != NULL) {
	widget = SpPrimitiveArch(frame).widget;
	if (XtIsManaged(widget) == False) {
	    if (spIsDialog(frame) == SP_FALSE) {
		spAdjustComponentSize(frame);
	    }
	    XtManageChild(widget);
	    
	    if (move_cursor == SP_TRUE
		&& spIsCreated(SpGetParent(frame)) == SP_TRUE) {
		/* move pointer */
		XWarpPointer(XtDisplay(widget), None, XtWindow(widget),
			     0, 0, 0, 0, 0, 0);
	    }
	} else {
	    XtMapWidget(widget);
	    XRaiseWindow(XtDisplay(widget), XtWindow(XtParent(widget)));
	    
	    if (move_cursor == SP_TRUE) {
		/* move pointer */
		XWarpPointer(XtDisplay(widget), None, XtWindow(widget),
			     0, 0, 0, 0, 0, 0);
	    }
	}
    }

    if (SpFramePart(frame).popup_style == SP_MODAL_POPUP) {
	spComponent prev_grabbed;
	
	prev_grabbed = spAddGrabXm(frame);
	
	spDebug(50, "spPopupFrameArch", "loop in\n");
	for (;;) {
	    spWaitEvent(sp_toplevel);

	    if (sp_grabbed_window == NULL) {
		break;
	    }
	}
	spDebug(50, "spPopupFrameArch", "loop end\n");

	spAddGrabXm(prev_grabbed);
    }
    
    spDebug(50, "spPopupFrameArch", "done\n");
    
    return;
}

void spPopdownFrameArch(spComponent frame)
{
    spDebug(30, "spPopdownFrameArch", "in\n");

    if (sp_grabbed_window != NULL) {
	spRemoveGrabXm(sp_grabbed_window);
    }
    
    if (SpPrimitiveArch(frame).toplevel != NULL) {
	XtUnmapWidget(SpPrimitiveArch(frame).toplevel);
    } else if (spIsDialog(frame) == SP_TRUE) {
	if (SpPrimitiveArch(frame).widget != NULL)
	    XtUnmanageChild(SpPrimitiveArch(frame).widget);
    } else if (SpPrimitiveArch(frame).top_widget != NULL) {
	XtUnmanageChild(SpPrimitiveArch(frame).top_widget);
    } else if (SpPrimitiveArch(frame).widget != NULL){
	if (SpPrimitiveArch(frame).sub_widget != NULL) {
	    XtUnmanageChild(SpPrimitiveArch(frame).sub_widget);
	}
	XtUnmanageChild(SpPrimitiveArch(frame).widget);
    }

    spDebug(30, "spPopdownFrameArch", "done\n");
    
    return;
}

void spRaiseFrameArch(spComponent window)
{
    Widget widget = NULL;

    widget = SpPrimitiveArch(window).toplevel;
    
    if (widget != NULL) {
	XRaiseWindow(XtDisplay(widget), XtWindow(widget));
    }
    
    return;
}

void spLowerFrameArch(spComponent window)
{
    Widget widget = NULL;

    widget = SpPrimitiveArch(window).toplevel;
    
    if (widget != NULL) {
	XLowerWindow(XtDisplay(widget), XtWindow(widget));
    }
    
    return;
}

spBool spSetFramePositionArch(spComponent window, int x, int y)
{
    XtVaSetValues(SpPrimitiveArch(window).toplevel,
		  XmNx, x,
		  XmNy, y,
		  NULL);
    
    return SP_TRUE;
}

spBool spGetFramePositionArch(spComponent window, int *x, int *y)
{
    short lx = 0, ly = 0;
    
    XtVaGetValues(SpPrimitiveArch(window).toplevel,
		  XmNx, &lx,
		  XmNy, &ly,
		  NULL);
    spDebug(30, "spGetFramePositionArch", "x = %d, y = %d\n", lx, ly);
    
    *x = lx;
    *y = ly;
    
    return SP_TRUE;
}

spBool spGetFrameModifierKeyMaskArch(spComponent window, spModifierMask *mask)
{
    Window root;
    Window child = None;
    int rx, ry, wx, wy;
    unsigned int xmask;
    
    if (!XQueryPointer(XtDisplay(SpPrimitiveArch(window).toplevel),
		       XtWindow(SpPrimitiveArch(window).toplevel),
		       &root, &child, &rx, &ry, &wx, &wy, &xmask)) {
	return SP_FALSE;
    }
    
    *mask = xmask;
	
    return SP_TRUE;
}

spBool spAddDropCallbackArch(spComponent component, spDropCallbackFunc call_func, void *call_data)
{
    return SP_FALSE;
}
