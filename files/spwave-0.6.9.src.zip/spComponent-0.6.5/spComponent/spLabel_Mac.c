/*
 *	spLabel_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spButtonP.h>
#include <sp/spLabelP.h>

void spDrawLabelMac(spComponent component)
{
    if (SpPrimitiveArch(component).control != NULL) {
	spDebug(80, "spDrawLabelMac", "in\n");
	spDrawControlMac(component);
    } else {
	char *title;
	int x, y;
	int width, height;
	int top_offset = SP_LABEL_TOP_OFFSET;
	GrafPtr save_port;
	
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top;
	
	width = SpComponentPart(component).current_width;
	height = SpComponentPart(component).current_height;
	
	title = spGetTitle(component);

	if (spIsAquaMac() == SP_TRUE) {
	    short just;
	    Rect rect;

	    top_offset = 2;
	    y += top_offset;
	    height -= top_offset;
	    
	    if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
		just = teJustRight;
	    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
		just = teJustCenter;
	    } else {
		just = teJustLeft;
	    }
	    
	    SetRect(&rect, x, y, x + width, y + height);
	    
	    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
		|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
		spGetOriginalRGBMac();
		spSetDeactivateRGBMac();
		
		TETextBox(title, strlen(title), &rect, just);
		spSetOriginalRGBMac();
	    } else {
		TETextBox(title, strlen(title), &rect, just);
	    }
	} else {
	    /* to prevent from illegal drawing on tab box */
	    y += top_offset;
	    height -= top_offset;
	    
	    if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
		int text_width;
		text_width = TextWidth(title, 0, strlen(title));
		MoveTo(x + width - text_width, y);
	    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
		int text_width;
		text_width = TextWidth(title, 0, strlen(title));
		MoveTo(x + (width - text_width) / 2, y);
	    } else {
		MoveTo(x, y);
	    }

	    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
		|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
		spGetOriginalRGBMac();
		spSetDeactivateRGBMac();
		spSetBackgroundRGBMac();
		DrawText(title, 0, strlen(title));
		spSetOriginalRGBMac();
	    } else {
		DrawText(title, 0, strlen(title));
	    }
	}
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    }
    
    return;
}

void spLabelCreateArch(spComponent component)
{
#if TARGET_API_MAC_CARBON
/*#if 0*/
    char label[SP_MAX_BUTTON_LABEL];
    Str255 pstr;
    Rect rect;
    ControlFontStyleRec fontStyle;
    spComponent window;

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	spGetMnemonic(SpComponentPart(component).title, label);
    } else {
	strcpy(label, (!strnone(SpGetName(component)) ? SpGetName(component) : ""));
    }
    spStrCToP(label, pstr);

    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    rect = SpPrimitiveArch(component).rect;

    window = SpGetWindow(component);

    SpPrimitiveArch(component).control =
	NewControl(SpPrimitiveArch(window).window,
		   &rect, pstr, spIsVisibleMac(component), 0, 0, 0, kControlStaticTextProc, 0);
    
    fontStyle.flags = kControlUseJustMask;
    if (SpLabelPart(component).alignment == SP_ALIGNMENT_END) {
	fontStyle.just = teFlushRight;
    } else if (SpLabelPart(component).alignment == SP_ALIGNMENT_CENTER) {
	fontStyle.just = teCenter;
    } else {
	fontStyle.just = teFlushLeft;
    }
    if (spIsAquaMac() == SP_TRUE) {
	fontStyle.flags |= kControlUseThemeFontIDMask;
	fontStyle.font = kThemeSystemFont;
    }
    SetControlFontStyle(SpPrimitiveArch(component).control, &fontStyle);

    SetControlData(SpPrimitiveArch(component).control,
		   kControlEntireControl, kControlStaticTextTextTag,
		   pstr[0], (Ptr)&pstr[1]);

    spSetReferenceMac(component);
    spSetNeedUpdateMac(component);
    spSetNeedMoveCallMac(component);
#else
    spSetNeedUpdateMac(component);
#endif
    return;
}

void spLabelSetParamsArch(spComponent component)
{
    if (SpPrimitiveArch(component).control != NULL) {
	spButtonSetParamsArch(component);
    }
    
    return;
}
