/*
 *	spText_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spComboBox.h>

#include <sp/spTextP.h>

void spTextPartInitArch(spComponent component)
{
    SpTextArch(component).vscroll_bar = NULL;
    SpTextArch(component).hscroll_bar = NULL;
    SpTextArch(component).font = NULL;
    
    return;
}

void spTextPartFreeArch(spComponent component)
{
    if (SpTextArch(component).font != NULL) {
	gdk_font_unref(SpTextArch(component).font);
    }
    
    return;
}

static void createTextFont(spComponent component)
{
    GtkStyle *style;
  
    if (!strnone(SpTextPart(component).font_name)) {
	if (SpTextArch(component).font != NULL) {
	    gdk_font_unref(SpTextArch(component).font);
	}
	
	spDebug(30, "createTextFont", "font_name = %s\n",
		SpTextPart(component).font_name);
    
	if ((SpTextArch(component).font =
	     gdk_fontset_load(SpTextPart(component).font_name)) == NULL) {
	    SpTextArch(component).font =
		gdk_font_load(SpTextPart(component).font_name);
	}
	
	style = gtk_style_copy(gtk_widget_get_style(SpPrimitiveArch(component).widget));
	gdk_font_unref(style->font);
	style->font = SpTextArch(component).font;
	gdk_font_ref(style->font);
	gtk_widget_set_style(SpPrimitiveArch(component).widget, style);
    }

    return;
}

static void textRealizeCB(GtkWidget *widget, spComponent component)
{
    if (!strnone(SpTextPart(component).string)) {
	gtk_text_freeze(GTK_TEXT(SpPrimitiveArch(component).widget));
	gtk_text_insert(GTK_TEXT(SpPrimitiveArch(component).widget), NULL, NULL, NULL,
			SpTextPart(component).string, -1);
	gtk_text_thaw(GTK_TEXT(SpPrimitiveArch(component).widget));
    }

    return;
}

void spTextCreateArch(spComponent component)
{
    if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	SpPrimitiveArch(component).widget = gtk_entry_new();
	
	gtk_entry_set_editable(GTK_ENTRY(SpPrimitiveArch(component).widget),
			       (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
	
	gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			  SpPrimitiveArch(component).widget);
	gtk_widget_show(SpPrimitiveArch(component).widget);
    } else {
	SpPrimitiveArch(component).top_widget = gtk_table_new (2, 2, FALSE);
	gtk_table_set_row_spacing(GTK_TABLE(SpPrimitiveArch(component).top_widget), 0, 2);
	gtk_table_set_col_spacing(GTK_TABLE(SpPrimitiveArch(component).top_widget), 0, 2);
	gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			  SpPrimitiveArch(component).top_widget);
	gtk_widget_show(SpPrimitiveArch(component).top_widget);
	
	SpPrimitiveArch(component).widget = gtk_text_new(NULL, NULL);
	gtk_table_attach(GTK_TABLE(SpPrimitiveArch(component).top_widget),
			 SpPrimitiveArch(component).widget, 0, 1, 0, 1,
			 GTK_EXPAND | GTK_SHRINK | GTK_FILL,
			 GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
	gtk_widget_show(SpPrimitiveArch(component).widget);

	SpTextArch(component).vscroll_bar =
	    gtk_vscrollbar_new (GTK_TEXT(SpPrimitiveArch(component).widget)->vadj);
	gtk_table_attach(GTK_TABLE(SpPrimitiveArch(component).top_widget),
			 SpTextArch(component).vscroll_bar, 1, 2, 0, 1,
			 GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
	gtk_widget_show(SpTextArch(component).vscroll_bar);
	
	gtk_text_set_editable(GTK_TEXT(SpPrimitiveArch(component).widget),
			      (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
	
	SpPrimitivePart(component).index =
	    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
			       "realize", GTK_SIGNAL_FUNC(textRealizeCB),
			       (gpointer)component);
    }

    createTextFont(component);
    
    return;
}

void spTextSetParamsArch(spComponent component)
{
    if (SpTextPart(SpOldObject(component)).editable != SpTextPart(component).editable) {
	if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	    gtk_entry_set_editable(GTK_ENTRY(SpPrimitiveArch(component).widget),
				   (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
	} else {
	    gtk_text_set_editable(GTK_TEXT(SpPrimitiveArch(component).widget),
				  (SpTextPart(component).editable == SP_TRUE ? TRUE : FALSE));
	}
    }
    
    if (!streq(SpTextPart(SpOldObject(component)).font_name, SpTextPart(component).font_name)) {
	createTextFont(component);
    }
    
    return;
}

void spSetTextStringArch(spComponent component)
{
    spDebug(30, "spSetTextStringArch", "string = %s\n",
	    SpTextPart(component).string);
    
    if (spIsComboBox(component) == SP_TRUE) {
	gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
			   SpTextPart(component).string);
    } else if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	gtk_entry_set_text(GTK_ENTRY(SpPrimitiveArch(component).widget),
			   SpTextPart(component).string);
    } else {
	if (GTK_WIDGET_REALIZED(SpPrimitiveArch(component).widget)) {
	    gtk_text_freeze(GTK_TEXT(SpPrimitiveArch(component).widget));
	    gtk_editable_delete_text(GTK_EDITABLE(SpPrimitiveArch(component).widget),
				     0, -1);
	    
	    gtk_text_insert(GTK_TEXT(SpPrimitiveArch(component).widget), NULL, NULL, NULL,
			    SpTextPart(component).string, -1);
	    gtk_text_thaw(GTK_TEXT(SpPrimitiveArch(component).widget));
	}
    }
    spSetTextPositionArch(component, -1);
    
    return;
}

void spGetTextStringArch(spComponent component)
{
    char *string;
    
    if (spIsComboBox(component) == SP_TRUE) {
	string =
	    gtk_editable_get_chars(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
				   0, -1);
    } else {
	string = gtk_editable_get_chars(GTK_EDITABLE(SpPrimitiveArch(component).widget),
					0, -1);
    }
    SpTextPart(component).string = strclone(string);
    g_free(string);
    
    return;
}

spBool spSetTextSelectionArch(spComponent component, long start, long end)
{
    if (start < 0) {
	/* is this correct? */
	start = 0;
	end = 0;
    }
    
    if (spIsComboBox(component) == SP_TRUE) {
	if (end > GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->text_length) {
	    end = GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->text_length;
	}
	gtk_editable_select_region(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
				   (gint)start, (gint)end);
    } else {
	if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	    if (end > GTK_ENTRY(SpPrimitiveArch(component).widget)->text_length) {
		end = GTK_ENTRY(SpPrimitiveArch(component).widget)->text_length;
	    }
	} else {
	    if (end > gtk_text_get_length(GTK_TEXT(SpPrimitiveArch(component).widget))) {
		end = gtk_text_get_length(GTK_TEXT(SpPrimitiveArch(component).widget));
	    }
	}
	gtk_editable_select_region(GTK_EDITABLE(SpPrimitiveArch(component).widget),
				   (gint)start, (gint)end);
    }
    
    return SP_TRUE;
}

spBool spGetTextSelectionArch(spComponent component, long *start, long *end)
{
    if (spIsComboBox(component) == SP_TRUE) {
	if (!GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->has_selection) {
	    return SP_FALSE;
	} else {
	    *start = GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->selection_start_pos;
	    *end = GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->selection_end_pos;
	}
    } else {
	if (!GTK_EDITABLE(SpPrimitiveArch(component).widget)->has_selection) {
	    return SP_FALSE;
	} else {
	    *start = GTK_EDITABLE(SpPrimitiveArch(component).widget)->selection_start_pos;
	    *end = GTK_EDITABLE(SpPrimitiveArch(component).widget)->selection_end_pos;
	}
    }
    
    return SP_TRUE;
}

spBool spSetTextPositionArch(spComponent component, long position)
{
    if (spIsComboBox(component) == SP_TRUE) {
	if (position == -1
	    || position > GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->text_length) {
	    position = GTK_ENTRY(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->text_length;
	}
	gtk_editable_set_position(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry),
				  (gint)position);
    } else {
	if (spIsSubClass(component, SpTextField) == SP_TRUE) {
	    if (position == -1
		|| position > GTK_ENTRY(SpPrimitiveArch(component).widget)->text_length) {
		position = GTK_ENTRY(SpPrimitiveArch(component).widget)->text_length;
	    }
	} else {
	    if (position == -1
		|| position > gtk_text_get_length(GTK_TEXT(SpPrimitiveArch(component).widget))) {
		position = gtk_text_get_length(GTK_TEXT(SpPrimitiveArch(component).widget));
	    }
	}
	gtk_editable_set_position(GTK_EDITABLE(SpPrimitiveArch(component).widget),
				  (gint)position);
    }
    
    return SP_TRUE;
}

spBool spGetTextPositionArch(spComponent component, long *position)
{
    if (spIsComboBox(component) == SP_TRUE) {
	*position = GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry)->current_pos;
    } else {
	*position = GTK_EDITABLE(SpPrimitiveArch(component).widget)->current_pos;
    }
    
    return SP_TRUE;
}

spBool spCutTextArch(spComponent component)
{
    if (spIsComboBox(component) == SP_TRUE) {
	gtk_editable_cut_clipboard(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry));
    } else {
	gtk_editable_cut_clipboard(GTK_EDITABLE(SpPrimitiveArch(component).widget));
    }
    return SP_TRUE;
}

spBool spCopyTextArch(spComponent component)
{
    if (spIsComboBox(component) == SP_TRUE) {
	gtk_editable_copy_clipboard(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry));
    } else {
	gtk_editable_copy_clipboard(GTK_EDITABLE(SpPrimitiveArch(component).widget));
    }
    return SP_TRUE;
}

spBool spPasteTextArch(spComponent component)
{
    if (spIsComboBox(component) == SP_TRUE) {
	gtk_editable_paste_clipboard(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry));
    } else {
	gtk_editable_paste_clipboard(GTK_EDITABLE(SpPrimitiveArch(component).widget));
    }
    return SP_TRUE;
}

spBool spClearTextArch(spComponent component)
{
    if (spIsComboBox(component) == SP_TRUE) {
	gtk_editable_delete_selection(GTK_EDITABLE(GTK_COMBO(SpPrimitiveArch(component).widget)->entry));
    } else {
	gtk_editable_delete_selection(GTK_EDITABLE(SpPrimitiveArch(component).widget));
    }
    return SP_TRUE;
}
