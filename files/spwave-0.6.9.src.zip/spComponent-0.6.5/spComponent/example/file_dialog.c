#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static char *file_filters[] =
{
    "*.txt",
    "*.c",
    "*.h",
    "*",
    NULL,
};

static void fileDialogCB(spComponent component, int dialog_type)
{
    char *filename;
    char *readable;
    
    if (dialog_type == 0) {
	filename = xspGetOpenFileName(component, NULL,
				      SppFileFilters, file_filters,
				      SppPathMustExist, SP_TRUE,
				      SppFileMustExist, SP_TRUE,
				      SppOverwritePrompt, SP_FALSE,
				      NULL);
	if (filename != NULL) {
	    if ((readable = xspGetReadablePath(filename)) != NULL) {
		spDisplayMessage(component, NULL, "Open File: %s", readable);
		xfree(readable);
	    }
	    xfree(filename);
	}
    } else if (dialog_type == 1) {
	filename = xspGetSaveFileName(component, NULL,
				      SppFileFilters, file_filters,
				      SppPathMustExist, SP_TRUE,
				      SppFileMustExist, SP_FALSE,
				      SppOverwritePrompt, SP_TRUE,
				      SppInitialFileName, "test",
				      NULL);
	if (filename != NULL) {
	    if ((readable = xspGetReadablePath(filename)) != NULL) {
		spDisplayMessage(component, NULL, "Save File: %s", readable);
		xfree(readable);
	    }
	    xfree(filename);
	}
    } else if (dialog_type == 2) {
	filename = xspGetSelectedDirName(component, NULL,
					 SppPathMustExist, SP_TRUE,
					 NULL);
	if (filename != NULL) {
	    if ((readable = xspGetReadablePath(filename)) != NULL) {
		spDisplayMessage(component, NULL, "Selected Directory: %s", readable);
		xfree(readable);
	    }
	    xfree(filename);
	}
    } else if (dialog_type == 3) {
	filename = xspChooseColor(component, NULL,
				  SppInitialColor, "Blue",
				  NULL);
	if (filename != NULL) {
	    spDisplayMessage(component, NULL, "Selected Color: %s", filename);
	    xfree(filename);
	}
    } else if (dialog_type == 4) {
	static char *fontname = NULL/*"-*-*-medium-r-normal--24-*-*-*-*-*-*-*"*/;

	filename = xspChooseFont(component, NULL,
				 SppInitialFont, fontname,
				 NULL);
	if (filename != NULL) {
	    spDisplayMessage(component, NULL, "Selected Font: %s", filename);
	    
	    if (fontname != NULL) xfree(fontname);
	    fontname = filename;
	}
    }

    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent open_button, save_button, quit_button;
    spComponent dir_button;
    spComponent color_button, font_button;

    /*spSetDebugLevel(100);*/
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);

    /* create main window */
    frame = spCreateMainFrame("File Dialog", NULL);

    /* create push button */
    open_button = spCreatePushButton(frame, "Open...",
				     SppCallbackFunc, fileDialogCB,
				     SppCallbackData, 0,
				     SppInitialWidth, 200,
				     SppDescription, "Create open file dialog",
				     NULL);
    save_button = spCreatePushButton(frame, "Save...",
				     SppCallbackFunc, fileDialogCB,
				     SppCallbackData, 1,
				     SppInitialWidth, 200,
				     SppDescription, "Create save file dialog",
				     NULL);
    dir_button = spCreatePushButton(frame, "Directory...",
				    SppCallbackFunc, fileDialogCB,
				    SppCallbackData, 2,
				    SppInitialWidth, 200,
				    SppDescription, "Create directory selection dialog",
				    NULL);
    color_button = spCreatePushButton(frame, "Color...",
				      SppCallbackFunc, fileDialogCB,
				      SppCallbackData, 3,
				      SppInitialWidth, 200,
				      SppDescription, "Create choose color dialog",
				      NULL);
    font_button = spCreatePushButton(frame, "Font...",
				     SppCallbackFunc, fileDialogCB,
				     SppCallbackData, 4,
				     SppInitialWidth, 200,
				     SppDescription, "Create choose font dialog",
				     NULL);
    
    quit_button = spCreatePushButton(frame, "Quit",
				     SppCallbackFunc, spQuitCB,
				     SppInitialWidth, 200,
				     SppDescription, "Quit program",
				     NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
