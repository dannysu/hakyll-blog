#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static spBool editable = SP_TRUE;
static spComponent text_field = NULL;

static void activateCB(spComponent component, void *data)
{
    char *string;

    if ((string = xspGetTextString(component)) != NULL) {
	printf("activated: reason = %d, string = %s\n", spGetCallbackReason(component), string);
	xfree(string);
    }
    
    return;
}

static void textCB(spComponent component, void *data)
{
    char *string;

    if ((string = xspGetTextString(component)) != NULL) {
	printf("reason = %d: %s\n", spGetCallbackReason(component), string);
	xfree(string);
    }
    
    return;
}

static void checkCB(spComponent component, void *data)
{
    if (spGetToggleState(component, &editable) == SP_TRUE) {
	printf("reason = %d: check: %d\n", spGetCallbackReason(component), editable);
	spSetParam(text_field,
		   SppEditable, editable,
		   NULL);
    }

    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    /*spSetDebugLevel(30);*/
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Text", NULL);

    /* create check box */
    spCreateCheckBox(frame, "Editable",
		     SppSet, editable,
		     SppCallbackFunc, checkCB,
		     NULL);

    /* create text field */
    text_field = spCreateTextField(frame, "text",
				   SppCallbackFunc, textCB,
				   SppTextString, "This is text.",
				   SppDescription, "This is text field.",
				   NULL);
    spAddCallback(text_field, SP_ACTIVATE_CALLBACK, activateCB, NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
