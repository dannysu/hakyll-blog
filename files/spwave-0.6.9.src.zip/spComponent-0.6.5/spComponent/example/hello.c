#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    /*spSetDebugLevel(100);*/

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);

    /* create main window */
    frame = spCreateMainFrame("Hello", NULL);

    /* create push button */
    spCreatePushButton(frame, "Hello World",
		       SppCallbackFunc, spQuitCB,
		       SppDefaultButton, SP_TRUE,
		       NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
