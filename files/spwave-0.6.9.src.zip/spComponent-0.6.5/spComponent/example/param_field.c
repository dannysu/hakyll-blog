#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>
#include <sp/spParamField.h>

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent param_field;
    static char *list_strings[] =
    {
	"Item 1",
	"Item 2",
	"Item 3",
	"Item 4",
	"Item 5",
	NULL,
    };
    static char *file_filters[] =
    {
	"*.txt",
	"*.c",
	"*.h",
	"*",
	NULL,
    };


    spSetDebugLevel(50);
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Parameter Field", NULL);

    /* create param field */
    param_field = spCreateParamField(frame, "Text Field", 0,
				     SppDimention, "dimention",
				     SppFieldOffset, 120,
				     SppFieldSize, 180,
				     SppEditable, SP_TRUE,
				     NULL);
    param_field = spCreateParamField(frame, "Combo Box", 0,
				     SppFieldType, SP_FIELD_TYPE_COMBO_BOX,
				     SppDimention, "dimention",
				     SppFieldOffset, 120,
				     SppFieldSize, 180,
				     SppFieldStrings, list_strings,
				     SppEditable, SP_TRUE,
				     NULL);

    param_field = spCreateParamField(frame, "Directory Text", 0,
				     SppFieldType, SP_FIELD_TYPE_DIR_TEXT,
				     SppFieldOffset, 120,
				     SppFieldSize, 180,
				     SppEditable, SP_TRUE,
				     SppUseCheckBox, SP_TRUE,
				     NULL);
    param_field = spCreateParamField(frame, "Open File Text", 0,
				     SppFieldType, SP_FIELD_TYPE_OPEN_FILE_TEXT,
				     SppFieldOffset, 120,
				     SppFieldSize, 180,
				     SppEditable, SP_TRUE,
				     SppUseCheckBox, SP_TRUE,
				     SppFileFilters, file_filters,
				     NULL);
    param_field = spCreateParamField(frame, "Save File Text", 0,
				     SppFieldType, SP_FIELD_TYPE_SAVE_FILE_TEXT,
				     SppFieldOffset, 120,
				     SppFieldSize, 180,
				     SppEditable, SP_TRUE,
				     SppUseCheckBox, SP_TRUE,
				     SppFileFilters, file_filters,
				     NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
