#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static void radioButtonCB(spComponent component, int num)
{
    spBool set;
    
    if (spGetToggleState(component, &set)) {
	if (set == SP_TRUE) {
	    printf("Button %d: Checked\n", num);
	} else {
	    printf("Button %d: Unchecked\n", num);
	}
    }
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Radio Button", NULL);

    /* create radio button */
    spCreateRadioButton(frame, "Button 1",
			SppCallbackFunc, radioButtonCB,
			SppCallbackData, 1,
			SppSet, SP_TRUE,
			NULL);
    spCreateRadioButton(frame, "Button 2",
			SppCallbackFunc, radioButtonCB,
			SppCallbackData, 2,
			NULL);
    spCreateRadioButton(frame, "Button 3",
			SppCallbackFunc, radioButtonCB,
			SppCallbackData, 3,
			NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
