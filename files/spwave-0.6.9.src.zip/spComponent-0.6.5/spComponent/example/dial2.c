#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

#include <sp/spDial.h>

static void dialCB(spComponent component, int id)
{
    int value;

    if (spGetDialValue(component, &value) == SP_TRUE) {
	spDebug(10, "dialCB", "%d: value = %d\n", id, value);
    }
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    /*spSetDebugLevel(30);*/
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Dial", NULL);

    /* create dial */
    spCreateDial(frame, "Dial",
		 SppCallbackFunc, dialCB,
		 SppCallbackData, 1,
		 SppShowScale, SP_TRUE,
		 NULL);
    spCreateDial(frame, "Dial2",
		 SppCallbackFunc, dialCB,
		 SppCallbackData, 2,
		 SppShowScale, SP_TRUE,
		 NULL);

    /* create push button */
    spCreatePushButton(frame, "Quit",
		       SppCallbackFunc, spQuitCB,
		       NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
