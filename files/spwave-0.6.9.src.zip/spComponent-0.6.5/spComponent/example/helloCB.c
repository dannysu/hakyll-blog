#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static void pressCB(spComponent component, void *data)
{
    if (spGetCallbackReason(component) == SP_CR_BUTTON_PRESS) {
	printf("pressed\n");
    } else {
	printf("relased\n");
    }
    
    return;
}

static void helloCB(spComponent component, void *data)
{
    static int count = 0;

    if (count >= 1) {
	/* quit program */
	spQuitCB(component, data);
	
	/* change label */
	spSetParam(component, SppTitle, "Hello World", NULL);
	count = 0;
    } else {
	/* change label */
	spSetParam(component, SppTitle, "Goodbye World", NULL);
	count++;
    }
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent button;

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("HelloCB", NULL);

    /* create push button */
    button = spCreatePushButton(frame, "Hello World",
				SppCallbackFunc, helloCB,
				SppInitialWidth, 200,
				NULL);
    spAddCallback(button, SP_BUTTON_PRESS_CALLBACK | SP_BUTTON_RELEASE_CALLBACK, pressCB, NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
