#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

spComponent status_bar = NULL;

static void canvasCB(spComponent component, void *data)
{
    int width = 0, height = 0;
    int sx = 0, sy = 0;
    int swidth = 0, sheight = 0;
    static char buf[SP_MAX_LINE];
    static spGraphics graphics = NULL;
    static spGraphics graphics_xor = NULL;

    if (graphics == NULL) {
	graphics = spCreateGraphics("graphics1",
				    SppForeground, "red",
				    SppLineType, SP_LINE_DASH_DOT,
				    SppLineWidth, 1,
				    SppFontName, "-*-*-medium-i-normal--16-*-*-*-*-*-*-*",
				    NULL);
    }

    if (graphics_xor == NULL) {
	graphics_xor = spCreateGraphics("graphics2",
					SppForeground, "max",
					SppGraphicsMode, SP_GM_XOR,
					NULL);
    }
    
    spGetSize(component, &width, &height);

    sprintf(buf, "width = %d, height = %d", width, height);
    spSetStatusText(status_bar, 0, buf);
    
    spDrawLine(component, graphics, 0, 0, width, height);
    spDrawLine(component, graphics, width, 0, 0, height);
    spFillRectangle(component, graphics, 80, 80, 100, 50);
    spFillRectangle(component, graphics_xor, 40, 40, 100, 50);
    
    spDebug(20, "canvasCB", "width = %d, height = %d\n", width, height);
#if 1
    spFillArc(component, graphics, width / 2 - 50, height / 2 - 50,
	      100, 100, 0, 45);
    spDrawArc(component, graphics, width / 2 - 50, height / 2 - 50,
	      100, 100, 90, 45);
    spFillArc(component, graphics, width / 2 - 50, height / 2 - 50,
	      100, 100, 180, 45);
    spDrawArc(component, graphics, width / 2 - 50, height / 2 - 50,
	      100, 100, 270, 45);
#else
    spFillArc(component, graphics, width / 2 - 100, height / 2 - 100,
	      100, 100, 0, 45);
    spDrawArc(component, graphics, width / 2 - 0, height / 2 - 100,
	      100, 100, 90, 45);
    spFillArc(component, graphics, width / 2 - 100, height / 2 - 0,
	      100, 100, 180, 45);
    spDrawArc(component, graphics, width / 2 - 0, height / 2 - 0,
	      100, 100, 270, 45);
#endif

    if (spGetStringExtent(graphics, "Hello World",
			  &sx, &sy, &swidth, &sheight) == SP_TRUE) {
	spDebug(20, "canvasCB",
		"sx = %d, sy = %d, sw = %d, sh = %d\n",
		sx, sy, swidth, sheight);
	spDrawRectangle(component, graphics, 5 + sx, 50 + sy, swidth, sheight);
    }
    spDrawString(component, graphics, 5, 50, "Hello World");
    
    if (spGetStringExtent(graphics, "Goodbye World",
			  &sx, &sy, &swidth, &sheight) == SP_TRUE) {
	spDebug(20, "canvasCB",
		"sx = %d, sy = %d, sw = %d, sh = %d\n",
		sx, sy, swidth, sheight);
	spDrawRectangle(component, graphics,
			width - 120 + sx, height - 50 + sy, swidth, sheight);
    }
    spDrawString(component, graphics,
		 width - 120, height - 50, "Goodbye World");
    
    spDebug(20, "canvasCB", "draw done\n");

    return;
}

static void canvasKeyPressCB(spComponent component, void *data)
{
    int len;
    int width = 0, height = 0;
    int sx = 0, sy = 0, swidth = 0, sheight = 0;
    spBool overflow = SP_FALSE;
    spKeySym key_sym;
    spModifierMask mask;
    static int xpos = 5, ypos = 20;
    static char *buf = NULL;
    static int buf_size = 0;
    static spGraphics graphics = NULL;

    if (graphics == NULL) {
	graphics = spCreateGraphics("graphics_string",
				    SppForeground, "blue",
				    SppLineWidth, 1,
				    SppFontName, "-*-*-medium-i-normal--16-*-*-*-*-*-*-*",
				    NULL);
    }

    if (buf == NULL) {
	buf_size = 128;
	buf = xalloc(buf_size, char);
    }
    
    spGetSize(component, &width, &height);
    
    spDebug(20, "canvasKeyPressCB", "key pressed\n");
    if ((len = spGetCallbackKeyString(component, buf, buf_size, &overflow)) >= 0) {
	spDebug(20, "canvasKeyPressCB", "len = %d\n", len);
	if (overflow == SP_TRUE) {
	    buf_size = len;
	    buf = xalloc(buf_size, char);
	    len = spGetCallbackKeyString(component, buf, buf_size, &overflow);
	}
	spDebug(20, "canvasKeyPressCB", "string = %s, len = %d\n", buf, len);

	if (spGetModifierKeyMask(component, &mask)) {
	    if (mask & SP_SHIFT_MASK) {
		spDebug(-20, "canvasKeyPressCB", "SP_SHIFT_MASK\n");
	    }
	    if (mask & SP_LOCK_MASK) {
		spDebug(-20, "canvasKeyPressCB", "SP_LOCK_MASK\n");
	    }
	    if (mask & SP_CONTROL_MASK) {
		spDebug(-20, "canvasKeyPressCB", "SP_CONTROL_MASK\n");
	    }
	    if (mask & SP_ALT_MASK) {
		spDebug(-20, "canvasKeyPressCB", "SP_ALT_MASK\n");
	    }
	}
	
	if (spGetStringExtent(graphics, buf,
			      &sx, &sy, &swidth, &sheight) == SP_TRUE) {
	    spDrawString(component, graphics, xpos, ypos, buf);
	    xpos += (swidth + sx);

	    spRefreshCanvas(component);
	}
	
    } else if (spGetCallbackKeySym(component, &key_sym) == SP_TRUE) {
	spDebug(20, "canvasKeyPressCB", "get key sym\n");
	if (key_sym == SPK_Return) {
	    xpos = 5;
	    ypos += 20;
	    if (ypos >= height) {
		ypos = 20;
	    }
	} else if (key_sym == SPK_Tab) {
	    xpos += 20;
	} else if (key_sym == SPK_Escape) {
	    spDebug(20, "canvasKeyPressCB", "escape program\n");
	    spQuit(0);
	} else if (key_sym == SPK_Prior) {
	    spDebug(-20, "canvasKeyPressCB", "prior key\n");
	} else if (key_sym == SPK_Next) {
	    spDebug(-20, "canvasKeyPressCB", "next key\n");
	}
    }
    
    return;
}

static void canvasKeyReleaseCB(spComponent component, void *data)
{
    spDebug(20, "canvasKeyReleaseCB", "key released\n");

    return;
}

static void showStatusBarCB(spComponent component, void *data)
{
    spBool set;
    
    if (spGetToggleState(component, &set)) {
	if (set == SP_TRUE) {
	    spMapComponent(status_bar);
	} else {
	    spUnmapComponent(status_bar);
	}
    }
    
    return;
}

spComponent canvas = NULL;

static void changeCursorCB(spComponent component, spCursorType cursor_type)
{
    spCursor cursor;
    
    if (canvas == NULL) return;

    if (cursor_type == SP_CURSOR_UNKNOWN) {
	spUnsetCanvasCursor(canvas);
    } else {
	if ((cursor = spGetCursor(cursor_type)) != NULL) {
	    spSetCanvasCursor(canvas, cursor);
	    spDestroyCursor(cursor);
	} else {
	    spUnsetCanvasCursor(canvas);
	}
    }

    spDebug(20, "changeCursorCB", "done\n");
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent menu, menu_bar;
    int status_sizes[] = {200, 0};

    spSetDebugLevel(50);

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Canvas", NULL);

    /* create status bar */
    status_bar = spCreateStatusBar(frame, "statusBar",
				   SppItemSizes, status_sizes,
				   SppHelpItemIndex, 1,
				   SppUseLastItem, SP_TRUE,
				   NULL);

    /* create menu bar */
    menu_bar = spCreateMenuBar(frame, "menuBar", NULL);
    
    /* create menu */
    menu = spCreatePulldownMenu(menu_bar, "File",
				SppDescription, "File menu",
				NULL);
    
    /* add menu item */
    spAddCheckBoxMenuItem(menu, "Show Status Bar",
			  SppCallbackFunc, showStatusBarCB,
			  SppSet, SP_TRUE,
			  SppShortcut, "Backspace",
			  SppDescription, "Show status bar",
			  NULL);

    /* add menu item */
    spAddMenuItem(menu, "Quit",
		  SppCallbackFunc, spQuitCB,
		  SppDescription, "Quit program",
		  NULL);

    /* create menu */
    menu = spCreatePulldownMenu(menu_bar, "Cursor",
				SppDescription, "Cursor menu",
				NULL);
    
    /* add radio button item */
    spAddRadioButtonMenuItem(menu, "Default",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_UNKNOWN,
			     SppSet, SP_TRUE,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Arrow",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_ARROW,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Text",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_TEXT,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Wait",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_WAIT,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Cross",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_CROSS,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Hand",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_HAND,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Move",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_MOVE,
			     NULL);
    spAddRadioButtonMenuItem(menu, "Size",
			     SppCallbackFunc, changeCursorCB,
			     SppCallbackData, SP_CURSOR_SIZE,
			     NULL);
    
    /* create canvas */
    canvas = spCreateCanvas(frame, "canvas",
			    300, 300,
			    SppBorderOn, SP_TRUE,
			    SppDrawBackground, SP_TRUE,
			    SppUseTabKey, SP_TRUE,
			    SppCallbackFunc, canvasCB,
			    NULL);
    spAddCallback(canvas, SP_KEY_PRESS_CALLBACK, canvasKeyPressCB, NULL);
    spAddCallback(canvas, SP_KEY_RELEASE_CALLBACK, canvasKeyReleaseCB, NULL);

    /* create popup menu */
    menu = spCreatePopupMenu(canvas, "popupMenu", NULL);
    
    /* add menu item */
    spAddCheckBoxMenuItem(menu, "Show Status Bar",
			  SppCallbackFunc, showStatusBarCB,
			  SppSet, SP_TRUE,
			  SppDescription, "Show status bar",
			  NULL);
    
    /* add menu item */
    spAddMenuItem(menu, "Quit",
		  SppCallbackFunc, spQuitCB,
		  SppDescription, "Quit program",
		  NULL);
    
    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
