#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static void helloCB(spComponent component, void *data)
{
    static int count = 0;

    if (count >= 1) {
	/* quit program */
	spQuitCB(component, data);
	
	/* change label */
	spSetParam(component, SppTitle, "Hello World", NULL);
	count = 0;
    } else {
	/* change label */
	spSetParam(component, SppTitle, "Goodbye World", NULL);
	count++;
    }
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent menu;

    /*spSetDebugLevel(10);*/

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Popup Menu", NULL);
    
    /* create label */
    spCreateLabel(frame, "Please click right button.",
		  SppAlignment, SP_ALIGNMENT_CENTER,
		  SppInitialWidth, 200,
		  NULL);
    
    /* create popup menu */
    menu = spCreatePopupMenu(frame, "Menu",
			     SppPopupButton, SP_RBUTTON,
			     NULL);
    
    /* add menu item */
    spAddMenuItem(menu, "Hello World",
		  SppCallbackFunc, helloCB,
		  NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
