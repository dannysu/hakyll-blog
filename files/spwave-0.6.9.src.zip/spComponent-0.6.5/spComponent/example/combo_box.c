#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static spBool editable = SP_TRUE;
static spComponent combo_box = NULL;

static void comboBoxCB(spComponent component, void *data)
{
    char *string;

    if ((string = xspGetTextString(component)) != NULL) {
	printf("reason = %d: %s\n", spGetCallbackReason(component), string);
	xfree(string);
    }
    
    return;
}

static void checkCB(spComponent component, void *data)
{
    if (spGetToggleState(component, &editable) == SP_TRUE) {
	printf("reason = %d: check: %d\n", spGetCallbackReason(component), editable);
	spSetParam(combo_box,
		   SppEditable, editable,
		   NULL);
    }

    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    /*spSetDebugLevel(50);*/

    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Combo Box", NULL);

    /* create check box */
    spCreateCheckBox(frame, "Editable",
		     SppSet, editable,
		     SppCallbackFunc, checkCB,
		     NULL);

    /* create combo box */
    combo_box = spCreateComboBox(frame, "comboBox",
				 SppCallbackFunc, comboBoxCB,
				 SppTextString, "This is combo box.",
				 NULL);
#if 1
    spAddListItem(combo_box, "");
    spAddListItem(combo_box, "Item 1");
    spAddListItem(combo_box, "Item 2");
    spAddListItem(combo_box, "Item 3");
    spAddListItem(combo_box, "Item 4");
    spAddListItem(combo_box, "Item 5");
    spAddListItem(combo_box, "Item 6");
    spAddListItem(combo_box, "Item 7");
    spAddListItem(combo_box, "Item 8");
    spAddListItem(combo_box, "Item 9");
    spAddListItem(combo_box, "Item 10");
    spAddListItem(combo_box, "Item 11");
    spAddListItem(combo_box, "Item 12");
    spAddListItem(combo_box, "Item 13");
    spAddListItem(combo_box, "Item 14");
    spAddListItem(combo_box, "Item 15");
#endif

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
