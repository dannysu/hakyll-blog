#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static spComponent dialog = NULL;

static void popdownDialogBoxCB(spComponent component, void *data)
{
    spCallbackReason reason;

    reason = spGetCallbackReason(component);
    
    if (reason == SP_CR_CANCEL) {
	spDebug(-1, "popdownDialogBoxCB", "SP_CR_CANCEL\n");
    } else if (reason == SP_CR_OK) {
	spDebug(-1, "popdownDialogBoxCB", "SP_CR_OK\n");
    }
    
    spPopdownWindow(component);
    return;
}

static void dialogBoxCB(spComponent component, void *data)
{
    spDebug(10, "dialogBoxCB", "in\n");

    if (spIsCreated(dialog) == SP_FALSE) {
	spDebug(10, "dialogBoxCB", "create new dialog box\n");
	dialog = spCreateDialogBox("Dialog Box",
				   SppCallbackFunc, popdownDialogBoxCB,
				   SppCloseStyle, SP_UNMAP_CLOSE,
				   NULL);
	
	spCreateTextField(dialog, "textField",
			  /*SppWidth, 0,*/
			  SppInitialWidth, 300,
			  NULL);
	spCreateLabel(dialog, "Label",
		      NULL);
	spCreatePushButton(dialog, "Button",
			   SppCallbackFunc, spDisplayMessageCB,
			   SppCallbackData, "Button clicked.",
			   NULL);
	spCreateTextArea(dialog, "textArea",
			 SppInitialWidth, 300,
			 NULL);
    }
    spPopupWindow(dialog);
    
    spDebug(10, "dialogBoxCB", "popup done\n");
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;

    spSetDebugLevel(60);
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Dialog Box", NULL);

    /* create push button */
    spCreatePushButton(frame, "Create Dialog Box",
		       SppCallbackFunc, dialogBoxCB,
		       SppInitialWidth, 200,
		       NULL);
    spCreatePushButton(frame, "Quit",
		       SppCallbackFunc, spQuitCB,
		       SppInitialWidth, 200,
		       NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
