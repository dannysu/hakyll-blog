#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

#include <sp/spTabBox.h>
#include <sp/spStatusBar.h>

static void canvasCB(spComponent component, void *data)
{
    int width = 0, height = 0;
    static spGraphics graphics = NULL;

    if (graphics == NULL) {
	graphics = spCreateGraphics("graphics1",
				    SppForeground, "red",
				    SppLineWidth, 1,
				    NULL);
    }

    spGetSize(component, &width, &height);
    spDebug(10, "canvasCB", "width = %d, height = %d\n", width, height);

    spDrawLine(component, graphics, 0, 0, width, height);
    spDrawLine(component, graphics, width, 0, 0, height);

    spRefreshCanvas(component);

    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent tab_box;
    spComponent tab_item;
    spComponent container;
    spComponent canvas;
    
    spSetDebugLevel(100);
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Tab Box", NULL);

#if 1
    /* create push button */
    spCreatePushButton(frame, "Quit",
		       SppCallbackFunc, spQuitCB,
		       SppInitialWidth, 200,
		       NULL);
#endif
    
    /* create tab box */
    tab_box = spCreateTabBox(frame, "tabBox", 190,
			     SppSpacingOn, SP_TRUE,
			     NULL);
    
    /* add tab item */
    tab_item = spAddTabItem(tab_box, "Tab Item 1", -1,
			    NULL);
    
    /* create push button */
    spCreatePushButton(tab_item, "Button1",
		       SppCallbackFunc, spSetStatusTextCB,
		       SppCallbackData, "Button1 clicked.",
		       SppInitialWidth, 300,
		       NULL);
    
    /* create push button */
    spCreatePushButton(tab_item, "Button1-2",
		       SppCallbackFunc, spSetStatusTextCB,
		       SppCallbackData, "Button1-2 clicked.",
		       NULL);
    
    /* create push button */
    spCreatePushButton(tab_item, "Button1-3",
		       SppCallbackFunc, spSetStatusTextCB,
		       SppCallbackData, "Button1-3 clicked.",
		       NULL);
    
    /* add tab item */
    tab_item = spAddTabItem(tab_box, "Tab Item 2", -1, NULL);
    
    /* create container */
    container = spCreateBox(tab_item, "container",
			    0,
			    SppOrientation, SP_VERTICAL,
			    SppBorderOn, SP_TRUE,
			    SppTitleOn, SP_TRUE,
			    NULL);
    
    /* create push button */
    spCreatePushButton(container, "Button2",
		       SppCallbackFunc, spSetStatusTextCB,
		       SppCallbackData, "Button2 clicked.",
		       NULL);
    
    /* create push button */
    spCreatePushButton(container, "Button2-2",
		       SppCallbackFunc, spSetStatusTextCB,
		       SppCallbackData, "Button2-2 clicked.",
		       NULL);
    
    /* add tab item */
    tab_item = spAddTabItem(tab_box, "Text Tab", -1, NULL);
    spCreateCheckBox(tab_item, "check box 1",
		     NULL);
    spCreateTextField(tab_item, "text1",
		      SppTextString, "This is text.",
		      NULL);
    spCreateTextField(tab_item, "text2",
		      SppTextString, "This is text.",
		      NULL);
    spCreateTextField(tab_item, "text3",
		      SppTextString, "This is text.",
		      NULL);
    
    /* add tab item */
    tab_item = spAddTabItem(tab_box, "Tab Item 3", -1, NULL);
    
    /* create container */
    container = spCreateBox(tab_item, "container",
			    0,
			    SppOrientation, SP_VERTICAL,
			    SppBorderOn, SP_TRUE,
			    SppTitleOn, SP_TRUE,
			    NULL);
    
    /* create canvas */
    canvas = spCreateCanvas(container, "canvas",
			    600, 300,
			    SppBorderOn, SP_TRUE,
			    SppCallbackFunc, canvasCB,
			    SppDrawBackground, SP_TRUE,
			    NULL);
    
    /* create status bar */
    spCreateStatusBar(frame, "statusBar", NULL);
    
    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
