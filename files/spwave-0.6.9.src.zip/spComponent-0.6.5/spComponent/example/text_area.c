#include <stdio.h>
#include <sp/spBaseLib.h>
#include <sp/spComponentLib.h>
#include <sp/spComponentMain.h>

static spBool editable = SP_TRUE;
static spComponent text_area = NULL;

static void textCB(spComponent component, void *data)
{
    char *string;

    if ((string = xspGetTextString(component)) != NULL) {
	fprintf(stderr, "length = %d, %s\n", strlen(string), string);
	printf("%s\n", string);
	xfree(string);
    }
    
    return;
}

static void checkCB(spComponent component, void *data)
{
    if (spGetToggleState(component, &editable) == SP_TRUE) {
	spSetParam(text_area,
		   SppEditable, editable,
		   NULL);
    }

    return;
}

static void forwardCB(spComponent component, long incr)
{
    long pos;

    if (spGetTextPosition(text_area, &pos) == SP_TRUE) {
	spSetTextPosition(text_area, pos + incr);
    }
    
    return;
}

static void selectionCB(spComponent component, long incr)
{
    long start = 0, end = 0;

    if (spGetTextSelection(text_area, &start, &end) == SP_FALSE) {
	spDisplayMessage(component, NULL, "No selection!");
    } else {
	end += incr;
	if (end >= start) {
	    spSetTextSelection(text_area, start, end);
	}
    }
    
    return;
}

static void selectCB(spComponent component, void *data)
{
    long start, end;
    
    if (spGetTextSelection(text_area, &start, &end) == SP_FALSE) {
	spSetTextSelection(text_area, 0, -1);
    } else {
	fprintf(stderr, "start = %ld, end = %ld\n", start, end);
	spSetTextSelection(text_area, -1, 0);

	/* go to end */
	spSetTextPosition(text_area, -1);
    }
    return;
}

static void clipboardCB(spComponent component, void *data)
{
    char *name;

    name = spGetName(component);

    if (streq(name, "Cut")) {
	fprintf(stderr, "cut\n");
	spCutText(text_area);
    } else if (streq(name, "Copy")) {
	fprintf(stderr, "copy\n");
	spCopyText(text_area);
    } else if (streq(name, "Paste")) {
	fprintf(stderr, "paste\n");
	spPasteText(text_area);
    } else if (streq(name, "Clear")) {
	fprintf(stderr, "clear\n");
	spClearText(text_area);
    }
    
    return;
}

static void chooseFontCB(spComponent component, void *data)
{
    char *font_name;

    if ((font_name = xspChooseFont(component, NULL, NULL)) != NULL) {
	spSetParams(text_area,
		    SppFontName, font_name,
		    NULL);
	xfree(font_name);
    }
    
    return;
}

int spMain(int argc, char *argv[])
{
    spTopLevel toplevel;
    spComponent frame;
    spComponent menu_bar;
    spComponent menu;

    /*spSetDebugLevel(10);*/
    
    /* initialize toolkit */
    toplevel = spInitialize(&argc, &argv, NULL);
    
    /* create main window */
    frame = spCreateMainFrame("Text", NULL);

    /* create menu */
    menu_bar = spCreateMenuBar(frame, "menuBar", NULL);
    menu = spCreatePulldownMenu(menu_bar, "File", NULL);
    spAddMenuItem(menu, "Quit",
		  SppCallbackFunc, spQuitCB,
		  NULL);
    menu = spCreatePulldownMenu(menu_bar, "Edit", NULL);
    spAddMenuItem(menu, "Cut",
		  SppCallbackFunc, clipboardCB,
		  NULL);
    spAddMenuItem(menu, "Copy",
		  SppCallbackFunc, clipboardCB,
		  NULL);
    spAddMenuItem(menu, "Paste",
		  SppCallbackFunc, clipboardCB,
		  NULL);
    spAddMenuItem(menu, "Clear",
		  SppCallbackFunc, clipboardCB,
		  NULL);
    spAddMenuSeparator(menu, "Separator", NULL);
    spAddMenuItem(menu, "Forward",
		  SppCallbackFunc, forwardCB,
		  SppCallbackData, 1,
		  NULL);
    spAddMenuItem(menu, "Backward",
		  SppCallbackFunc, forwardCB,
		  SppCallbackData, -1,
		  NULL);
    spAddMenuItem(menu, "Increase Selection",
		  SppCallbackFunc, selectionCB,
		  SppCallbackData, 1,
		  NULL);
    spAddMenuItem(menu, "Decrease Selection",
		  SppCallbackFunc, selectionCB,
		  SppCallbackData, -1,
		  NULL);
    spAddMenuItem(menu, "Select All/Deselect",
		  SppCallbackFunc, selectCB,
		  NULL);
    spAddMenuSeparator(menu, "Separator2", NULL);
    spAddMenuItem(menu, "Choose Font...",
		  SppCallbackFunc, chooseFontCB,
		  NULL);
    
    /* create check box */
    spCreateCheckBox(frame, "Editable",
		     SppSet, editable,
		     SppCallbackFunc, checkCB,
		     NULL);

    /* create text area */
    text_area = spCreateTextArea(frame, "text",
				 SppCallbackFunc, textCB,
				 SppTextString, "Hello!\nThis is text area.\n",
				 SppFontName, "-*-*-medium-r-normal--24-*-*-*-*-*-*-*",
				 NULL);

    /* popup window */
    spPopupWindow(frame);
    
    /* main loop */
    return spMainLoop(toplevel);
}
