/*
 *	spDialog_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spLabel.h>
#include <sp/spDialogBox.h>

#include <sp/spGraphicsP.h>
#include <sp/spDialogBoxP.h>
#include <sp/spDialogP.h>

#if defined(MACOS)
#pragma import on
#endif
extern spTopLevel sp_toplevel;
#if defined(MACOS)
#pragma import off
#endif

void spActivateWindowMac(spComponent component, spBool need_update)
{
    if (component == NULL) return;

    spActivateComponentMac(component, need_update);
#if defined(MACOSX)
    spSelectMenuBarMac(component, NULL);
#endif
    
    return;
}

void spDeactivateWindowMac(spComponent component, spBool need_update)
{
    if (component == NULL) return;

#if defined(MACOSX)
    spSelectMenuBarMac(NULL, component);
#endif
    spDeactivateComponentMac(component, need_update);
    
    return;
}

void spDialogPartInitArch(spComponent component)
{
    return;
}

pascal Boolean dialogFilter(DialogPtr dialog, EventRecord *event, SInt16 *item)
{
    Boolean flag = false;

    spDebug(80, "dialogFilter", "what = %d, message = %ld\n",
	    event->what, event->message);
    
    if ((event->what == updateEvt) && ((DialogPtr)event->message != dialog)) {
	if (!IsDialogEvent(event)) {
	    spHandleUpdateEventMac(event);
	}
    } else {
	flag = StdFilterProc(dialog, event, item);
    }

    spDebug(80, "dialogFilter", "done: %d\n", flag);
    
    return flag;
}

static AlertType getAlertType(spComponent component)
{
    AlertType type;

    if (SpDialogPart(component).dialog_type == SP_INFORMATION_DIALOG) {
	type = kAlertNoteAlert;
    } else if (SpDialogPart(component).dialog_type == SP_QUESTION_DIALOG) {
	type = kAlertNoteAlert;
    } else if (SpDialogPart(component).dialog_type == SP_WARNING_DIALOG) {
	type = kAlertCautionAlert;
    } else if (SpDialogPart(component).dialog_type == SP_ERROR_DIALOG) {
	type = kAlertStopAlert;
    } else if (SpDialogPart(component).dialog_type == SP_WORKING_DIALOG) {
	type = kAlertNoteAlert;
    } else {
	/*type = kAlertPlainAlert;*/
	type = kAlertNoteAlert;
    }
    
    return type;
}

static spDialogResponse getDialogResponse(spComponent component, SInt16 item)
{
    spDialogResponse response = SP_DR_NONE;

    if (SpDialogPart(component).button_type == SP_MB_OK) {
	response = SP_DR_OK;
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	if (item == kStdOkItemIndex) {
	    response = SP_DR_OK;
	} else {
	    response = SP_DR_CANCEL;
	}
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	if (item == kStdOkItemIndex) {
	    response = SP_DR_YES;
	} else {
	    response = SP_DR_NO;
	}
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	if (item == kStdOkItemIndex) {
	    response = SP_DR_YES;
	} else if (item == kStdCancelItemIndex) {
	    response = SP_DR_NO;
	} else {
	    response = SP_DR_CANCEL;
	}
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	if (item == kStdOkItemIndex) {
	    response = SP_DR_RETRY;
	} else {
	    response = SP_DR_CANCEL;
	}
    }
    
    return response;
}

#ifdef MACOSX
static DialogPtr sp_current_sheet_dialog = NULL;
static SInt16 sp_dialog_response_item = kStdCancelItemIndex;

DialogPtr spGetCurrentSheetDialogMacX(void)
{
    return sp_current_sheet_dialog;
}

spBool spQuitCurrentSheetDialogMacX(void)
{
    if (sp_current_sheet_dialog != NULL) {
	QuitAppModalLoopForWindow(GetDialogWindow(sp_current_sheet_dialog));
	sp_current_sheet_dialog = NULL;
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spSetDialogResponseMacX(UInt32 commandID)
{
    switch (commandID) {
      case kHICommandOK:
	sp_dialog_response_item = kStdOkItemIndex;
	break;
      case kHICommandCancel:
	sp_dialog_response_item = kStdCancelItemIndex;
	break;
      case kHICommandOther:
	sp_dialog_response_item = kStdCancelItemIndex + 1;
	break;
	
      default:
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spDialogResponse popupAquaMessageBox(spComponent component, char *message)
{
    spComponent window;
    spComponent parent_window;
    spDialogResponse response = SP_DR_NONE;
    AlertType type;
    SInt16 item = kStdCancelItemIndex;
    AlertStdCFStringAlertParamRec paramRec;
    CFStringRef cferror, cfexplanation;
    ModalFilterUPP dialogFilterUPP;
    DialogPtr dialog;

    window = spGetCurrentWindowMac();
    spDeactivateWindowMac(window, SP_TRUE);
    
    dialogFilterUPP = NewModalFilterUPP((ModalFilterProcPtr)dialogFilter);
    type = getAlertType(component);
    
    if (GetStandardAlertDefaultParams(&paramRec, kStdCFStringAlertVersionOne) != noErr) {
	return response;
    }

    paramRec.movable = true;
    paramRec.helpButton = false;
    paramRec.position = kWindowDefaultPosition;
    
    if (SpDialogPart(component).button_type == SP_MB_OK) {
	paramRec.defaultText = CFStringCreateWithCString(NULL, SP_OK_LABEL,
							 CFStringGetSystemEncoding());
	paramRec.cancelText = NULL;
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = 0;
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	paramRec.defaultText = CFStringCreateWithCString(NULL, SP_OK_LABEL,
							 CFStringGetSystemEncoding());
	paramRec.cancelText = CFStringCreateWithCString(NULL, SP_CANCEL_LABEL,
							CFStringGetSystemEncoding());
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	paramRec.defaultText = CFStringCreateWithCString(NULL, SP_YES_LABEL,
							 CFStringGetSystemEncoding());
	paramRec.cancelText = CFStringCreateWithCString(NULL, SP_NO_LABEL,
							CFStringGetSystemEncoding());
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	paramRec.defaultText = CFStringCreateWithCString(NULL, SP_YES_LABEL,
							 CFStringGetSystemEncoding());
	paramRec.cancelText = CFStringCreateWithCString(NULL, SP_NO_LABEL,
							CFStringGetSystemEncoding());
	paramRec.otherText = CFStringCreateWithCString(NULL, SP_CANCEL_LABEL,
						       CFStringGetSystemEncoding());
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = 3;
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	paramRec.defaultText = CFStringCreateWithCString(NULL, SP_RETRY_LABEL,
							 CFStringGetSystemEncoding());
	paramRec.cancelText = CFStringCreateWithCString(NULL, SP_CANCEL_LABEL,
							CFStringGetSystemEncoding());
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    }
    
    /*spLockMainMutexMac();*/
    cferror = CFStringCreateWithCString(NULL, spGetMessageBoxTitle(component),
					CFStringGetSystemEncoding());
    cfexplanation = CFStringCreateWithCString(NULL, message, CFStringGetSystemEncoding());

    if (SpGetParent(component) != NULL) {
	parent_window = SpGetWindow(SpGetParent(component));
	if (spIsVisible(parent_window) == SP_FALSE) {
	    parent_window = NULL;
	}
    } else {
	if (spIsInPThreadMac() == SP_TRUE) {
	    /* because standard alert doesn't work in pthread */
	    parent_window = spGetCurrentWindowMac();
	} else {
	    parent_window = NULL;
	}
    }

    if (parent_window == NULL) {
	CreateStandardAlert(type, cferror, cfexplanation, &paramRec, &dialog);
	RunStandardAlert(dialog, dialogFilterUPP, &item);
    } else {
	/* because RunAppModalLoopForWindow doesn't work correctly in OS 10.0.X without this flag */
	paramRec.flags |= kStdAlertDoNotDisposeSheet;
	
	CreateStandardSheet(type, cferror, cfexplanation, &paramRec,
			    GetApplicationEventTarget(), &dialog);
	spDebug(30, "popupAquaMessageBox", "create sheet done\n");
	ShowSheetWindow(GetDialogWindow(dialog), SpPrimitiveArch(parent_window).window);
	spDebug(30, "popupAquaMessageBox", "show sheet done\n");
	
	sp_current_sheet_dialog = dialog;
	sp_dialog_response_item = kStdCancelItemIndex;
	RunAppModalLoopForWindow(GetDialogWindow(dialog));
	CloseStandardSheet(dialog, 0);
	
	item = sp_dialog_response_item;
	sp_current_sheet_dialog = NULL;
    }
    spDebug(30, "popupAquaMessageBox", "item = %d\n", item);
    
    response = getDialogResponse(component, item);
    
    DisposeModalFilterUPP(dialogFilterUPP);
    /*spUnlockMainMutexMac();*/

    if (paramRec.defaultText != NULL) CFRelease(paramRec.defaultText);
    if (paramRec.cancelText != NULL) CFRelease(paramRec.cancelText);
    if (paramRec.otherText != NULL) CFRelease(paramRec.otherText);
    if (cferror != NULL) CFRelease(cferror);
    if (cfexplanation != NULL) CFRelease(cfexplanation);

    spActivateWindowMac(window, SP_TRUE);
    
    return response;
}
#else
static spDialogResponse popupAppearanceMessageBox(spComponent component, char *message)
{
    spComponent window;
    spDialogResponse response = SP_DR_NONE;
    AlertStdAlertParamRec paramRec;
    AlertType type;
    SInt16 item = kStdCancelItemIndex;
    Str255 pdefault, pcancel, pother;
    Str255 perror, pexplanation;
    ModalFilterUPP dialogFilterUPP;

    window = spGetCurrentWindowMac();
    spDeactivateWindowMac(window, SP_TRUE);
    
    dialogFilterUPP = NewModalFilterUPP((ModalFilterProcPtr)dialogFilter);
    type = getAlertType(component);
    
    paramRec.movable = true;
    paramRec.helpButton = false;
    paramRec.filterProc = dialogFilterUPP;
    paramRec.position = kWindowDefaultPosition;
    
    if (SpDialogPart(component).button_type == SP_MB_OK) {
	paramRec.defaultText = (StringPtr)kAlertDefaultOKText;
	paramRec.cancelText = NULL;
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = 0;
    } else if (SpDialogPart(component).button_type == SP_MB_OK_CANCEL) {
	paramRec.defaultText = (StringPtr)kAlertDefaultOKText;
	paramRec.cancelText = (StringPtr)kAlertDefaultCancelText;
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO) {
	spStrCToP(SP_YES_LABEL, pdefault);
	spStrCToP(SP_NO_LABEL, pcancel);
	
	paramRec.defaultText = pdefault;
	paramRec.cancelText = pcancel;
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    } else if (SpDialogPart(component).button_type == SP_MB_YES_NO_CANCEL) {
	spStrCToP(SP_YES_LABEL, pdefault);
	spStrCToP(SP_NO_LABEL, pcancel);
	spStrCToP(SP_CANCEL_LABEL, pother);
	
	paramRec.defaultText = pdefault;
	paramRec.cancelText = pcancel;
	paramRec.otherText = pother;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = 3;
    } else if (SpDialogPart(component).button_type == SP_MB_RETRY_CANCEL) {
	spStrCToP(SP_RETRY_LABEL, pdefault);
	
	paramRec.defaultText = pdefault;
	paramRec.cancelText = (StringPtr)kAlertDefaultCancelText;
	paramRec.otherText = NULL;
	paramRec.defaultButton = kAlertStdAlertOKButton;
	paramRec.cancelButton = kAlertStdAlertCancelButton;
    }
    
    /*spLockMainMutexMac();*/
    spStrCToP(spGetMessageBoxTitle(component), perror);
    spStrCToP(message, pexplanation);
    StandardAlert(type, perror, pexplanation, &paramRec, &item);
    DisposeModalFilterUPP(dialogFilterUPP);
    /*spUnlockMainMutexMac();*/
    
    response = getDialogResponse(component, item);

    spActivateWindowMac(window, SP_TRUE);
    
    return response;
}
#endif

static void popdownMessageBoxCB(spComponent component, spDialogResponse *response)
{
    switch (spGetCallbackReason(component)) {
      case SP_CR_OK:
	*response = SP_DR_OK;
	break;
      case SP_CR_CANCEL:
	*response = SP_DR_CANCEL;
	break;
      case SP_CR_YES:
	*response = SP_DR_YES;
	break;
      case SP_CR_NO:
	*response = SP_DR_NO;
	break;
      case SP_CR_RETRY:
	*response = SP_DR_RETRY;
	break;
      case SP_CR_APPLY:
	*response = SP_DR_APPLY;
	break;
      default:
	*response = SP_DR_CANCEL;
	break;
    }
    spDebug(50, "popdownMessageBoxCB", "response = %d\n", *response);

    spPopdownWindow(component);
    
    return;
}

static spDialogResponse popupMessageBox(spComponent component, char *message)
{
    spDialogResponse response = SP_DR_NONE;
    spComponent dialog;
    spComponent parent_window;
    char *title;
    int len;
    int width;
    char *ptr, *sep;
    char buf[SP_MAX_MESSAGE];
    Str255 pstr;
    
    title = spGetMessageBoxTitle(component);

    if (SpGetParent(component) != NULL) {
	parent_window = SpGetWindow(SpGetParent(component));
	if (spIsVisible(parent_window) == SP_FALSE) {
	    parent_window = NULL;
	}
    } else {
	parent_window = NULL;
    }
    
    /* create dialog box */
    dialog = spCreateDialogBox("messageBox",
			       SppTitle, title,
			       SppCallbackFunc, popdownMessageBoxCB,
			       SppCallbackData, &response,
			       SppDialogBoxButtonType, SpDialogPart(component).button_type,
			       SppParentWindow, parent_window,
			       SppSpacing, 0,
			       NULL);
    
    ptr = message;
    while (!strnone(ptr)) {
	sep = strchr(ptr, '\n');
	if (sep != NULL) {
	    len = (int)(sep - ptr);
	    strncpy(buf, ptr, len);
	    buf[len] = NUL;
	} else {
	    strcpy(buf, ptr);
	}

	spStrCToP(buf, pstr);
	width = MAX(StringWidth(pstr) + 2 * SP_DEFAULT_MARGIN, 250);
	
	/* create label */
	spCreateLabel(dialog, "message",
		      SppTitle, buf,
		      SppAlignment, SP_ALIGNMENT_BEGINNING,
		      SppInitialWidth, width,
		      NULL);

	if (sep == NULL) {
	    break;
	} else {
	    ptr = sep + 1;
	}
    }
    
    /*spLockMainMutexMac();*/
    spPopupWindow(dialog);
    /*spUnlockMainMutexMac();*/
    
    spDestroyComponent(dialog);

    spDebug(80, "popdownMessageBox", "done\n");
    
    return response;
}


spDialogResponse spPopupMessageBox(spComponent component, char *message)
{
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
#ifdef MACOSX
	return popupAquaMessageBox(component, message);
#else
	return popupAppearanceMessageBox(component, message);
#endif
    } else {
	return popupMessageBox(component, message);
    }
}

Boolean fileDialogFilter(spComponent component, char *path, OSType file_type, int type_index)
{
    int i;
    char **filters;

    if (component == NULL || SpDialogPart(component).file_filters == NULL) {
	return true;
    }

    filters = SpDialogPart(component).file_filters;
    
    for (i = 0; filters[i] != NULL; i++) {
	spDebug(30, "fileDialogFilter", "filters[%d] = %s\n", i, filters[i]);
	
	if (i == type_index - 1) {
	    if (streq(filters[i], "*")
		|| spEqSuffix(filters[i], ".*")
		|| spEqSuffix(path, filters[i])) {
		return true;
	    } else if (SpDialogPart(component).file_types != NULL
		       && file_type == 'TEXT'
		       && (spEqSuffix(filters[i], "*.txt")
			   || spEqSuffix(filters[i], "*.text"))) {
		return true;
	    }
	    break;
	}
    }

    return false;
}

static SInt16 sp_current_type_index = 1;

#if 1
#if !defined(MACOSX)
#include <Navigation.h>
#endif

static NavMenuItemSpec *sp_nav_default_menu_item = NULL;

pascal Boolean navFilterProc(AEDesc *item, void *info, NavCallBackUserData user_data,
			     NavFilterModes fmode)
{
    spComponent component;
    FSSpec fsspec;
    OSType file_type;
    char path[SP_MAX_PATHNAME];
    NavFileOrFolderInfo *ffinfo;

    ffinfo = (NavFileOrFolderInfo*)info;
    component = (spComponent)user_data;
	
    if (item->descriptorType == typeFSS) {
#if !TARGET_API_MAC_CARBON
	fsspec = (FSSpec)**item->dataHandle;
#else
	AEGetDescData(item, (Ptr)&fsspec, sizeof(FSSpec));
#endif

	if (ffinfo->isFolder) {
	    spDebug(100, "navFilterProc", "folder frFlags: %x\n",
		    ffinfo->fileAndFolder.folderInfo.finderDInfo.frFlags);
	    if (spIsAquaMac() == SP_TRUE) {
		/* on Mac OS X, bundle flag is not set */
	    } else if (!(ffinfo->fileAndFolder.folderInfo.finderDInfo.frFlags & kHasBundle)) {
		return true;
	    }
	    file_type = 'fold';
	} else {
	    file_type = ffinfo->fileAndFolder.fileInfo.finderInfo.fdType;
	}
	    
	if (spFSSpecToExactNameMac(&fsspec, path) == SP_TRUE) {
#if TARGET_API_MAC_CARBON
	    if (spIsAquaMac() == SP_TRUE && ffinfo->isFolder) {
		spDebug(100, "navFilterProc", "folder on Mac OS X: %s\n", path);
		if (!spEqSuffix(path, "*.app")
		    && !spEqSuffix(path, "*.bundle")
		    && !spEqSuffix(path, "*.pbproj")
		    && !spEqSuffix(path, "*.plugin")) {
		    return true;
		}
	    }
#endif
	    return fileDialogFilter(component, path, file_type, sp_current_type_index);
	}
    }
    
    return true;
}

static void navHandleShowPopupMenuSelect(spComponent component, NavCBRecPtr pcbrec)
{
    int i;
    char *string;
    Str255 pstr;
    
    if (component == NULL || SpDialogPart(component).file_filters == NULL) {
	return;
    }
    
    if (pcbrec != NULL) {
	NavMenuItemSpec *menu_item
	    = (NavMenuItemSpec *)pcbrec->eventData.eventDataParms.param;

	if (menu_item != NULL) {
	    for (i = 0;; i++) {
		if (SpDialogPart(component).file_types != NULL) {
		    string = SpDialogPart(component).file_types[i];
		} else {
		    string = SpDialogPart(component).file_filters[i];
		}
		if (strnone(string)) {
		    break;
		}
		
		spStrCToP(string, pstr);
		spDebug(30, "navHandleShowPopupMenuSelect",
			"i = %d, string = %s, len = %d\n", i, string, (int)pstr[0]);
		
		if (pstr[0] == menu_item->menuItemName[0]
		    && strneq((char *)&pstr[1], (char *)&menu_item->menuItemName[1], pstr[0])) {
		    sp_current_type_index = i + 1;
		    break;
		}
	    }
	}
    }

    return;
}

static void navHandleEvent(spComponent component, NavCBRecPtr pcbrec)
{
    WindowRef wref;
    spComponent window;
    
    spDebug(80, "navHandleEvent", "event->what = %d\n", pcbrec->eventData.eventDataParms.event->what);
	
    switch (pcbrec->eventData.eventDataParms.event->what) {
      case updateEvt:
	wref = (WindowRef)pcbrec->eventData.eventDataParms.event->message;
	if ((window = spSearchWindowMac(wref)) != NULL
	    && window != component) {
	    spHandleUpdateEventMac(pcbrec->eventData.eventDataParms.event);
	}
	break;
					
      case activateEvt:
	wref = (WindowRef)pcbrec->eventData.eventDataParms.event->message;
	if ((window = spSearchWindowMac(wref)) != NULL
	    && window != component) {
	    spHandleActivateEventMac(pcbrec->eventData.eventDataParms.event);
	}
	break;
    }
    
    spDebug(80, "navHandleEvent", "done\n");
    
    return;
}

pascal void navEventProc(NavEventCallbackMessage selector, NavCBRecPtr pcbrec,
			 NavCallBackUserData user_data)
{
    spComponent component;

    if ((component = (spComponent)user_data) == NULL) {
	return;
    }
		
    spDebug(80, "navEventProc", "selector = %d\n", selector);
    
    switch (selector)
    {
      case kNavCBStart:
	if (sp_nav_default_menu_item != NULL) {
	    NavCustomControl(pcbrec->context, kNavCtlSelectCustomType,
			     sp_nav_default_menu_item);
	}
	break;
				
      case kNavCBEvent:
	navHandleEvent(component, pcbrec);
	break;
	
      case kNavCBPopupMenuSelect:
	navHandleShowPopupMenuSelect(component, pcbrec);
	break;
    }

    spDebug(80, "navEventProc", "done\n");
    
    return;
}

static void navCreatePopup(spComponent component, NavDialogOptions *options)		
{
    int i;
    int num_menu;
    char *string;
    Str255 pstr;
    NavMenuItemSpec menu_item;
    NavMenuItemSpecArrayHandle popupExtension;
    OSType menu_type, menu_creator;

    sp_nav_default_menu_item = NULL;

    if (component == NULL || SpDialogPart(component).file_filters == NULL) {
	return;
    }

    /* dummy */
    menu_type = 'TEXT';
    menu_creator = 'ttxt';

    for (num_menu = 0;; num_menu++) {
	if (SpDialogPart(component).file_types != NULL) {
	    string = SpDialogPart(component).file_types[num_menu];
	} else {
	    string = SpDialogPart(component).file_filters[num_menu];
	}
	if (strnone(string)) {
	    break;
	}
    }
    
    if ((popupExtension =
	 (NavMenuItemSpecArrayHandle)NewHandleClear(sizeof(NavMenuItemSpec) * num_menu)) == NULL) {
	return;
    }

    for (i = 0; i < num_menu; i++) {
	if (SpDialogPart(component).file_types != NULL) {
	    string = SpDialogPart(component).file_types[i];
	} else {
	    string = SpDialogPart(component).file_filters[i];
	}
	if (strnone(string)) {
	    break;
	}
		
	spStrCToP(string, pstr);
	spDebug(30, "navCreatePopup", "i = %d, string = %s, len = %d\n",
		i, string, (int)pstr[0]);
	
	menu_item.version = kNavMenuItemSpecVersion;
	BlockMoveData(pstr, menu_item.menuItemName, pstr[0]+1);
	menu_item.menuType = menu_type;
	menu_item.menuCreator = menu_creator;
	
	BlockMoveData(&menu_item, &((*popupExtension)[i]), sizeof(NavMenuItemSpec));

	if (SpDialogPart(component).filter_index != NULL
	    && *SpDialogPart(component).filter_index == i) {
	    spDebug(50, "navCreatePopup", "default item = %d\n", *SpDialogPart(component).filter_index);
	    sp_nav_default_menu_item = (NavMenuItemSpecPtr)&((*popupExtension)[i]);
	}
    }

    options->popupExtension = popupExtension;
    
    spDebug(50, "navCreatePopup", "done\n");
    
    return;
}

static OSErr navGetFile(char *pathname, spComponent component)
{	
    NavDialogOptions options;
    NavEventUPP eventUPP;
    NavObjectFilterUPP filterUPP;
    NavReplyRecord reply;
    OSErr err = noErr;
    
    sp_current_type_index = 1;
    
    NavGetDefaultDialogOptions(&options);
    options.dialogOptionFlags &= ~kNavAllowMultipleFiles;
    options.dialogOptionFlags |= kNavSupportPackages /*| kNavAllowOpenPackages*/;
    if (!strnone(SpComponentPart(component).title)) {
	spStrCToP(SpComponentPart(component).title, options.message);
    }
    
    navCreatePopup(component, &options);
    
    eventUPP = NewNavEventUPP(navEventProc);
    filterUPP = NewNavObjectFilterUPP(navFilterProc);
    
    /*spLockMainMutexMac();*/
    err = NavGetFile(NULL, &reply, &options, eventUPP, NULL, filterUPP,
		     NULL, (NavCallBackUserData)component);
    /*spUnlockMainMutexMac();*/
    
    DisposeNavEventUPP(eventUPP);
    DisposeNavObjectFilterUPP(filterUPP);
    
    if (options.popupExtension != NULL ) {
	DisposeHandle((Handle)options.popupExtension);
    }
		
    if (reply.validRecord && err == noErr) {
	AEKeyword keyword;
	DescType dtype;
	Size size;
	FSSpec fsspec;
	
	if (AEGetNthPtr(&(reply.selection), 1, typeFSS, &keyword, &dtype,
			(Ptr)&fsspec, (long)sizeof(FSSpec), &size) == noErr) {
	    if (spFSSpecToExactNameMac(&fsspec, pathname) == SP_FALSE) {
		spDebug(30, "navGetFile", "spFSSpecToExactNameMac failed\n");
		err = fnfErr;	/* I don't know the meaning of this error. */
#if 0
	    } else {
		char buf[SP_MAX_PATHNAME];
		
		spStrPToC(fsspec.name, buf);
		spDebug(30, "navGetFile", "%s: %s\n", buf, (spIsExist(pathname) ? "exist" : "not exist"));
#endif
	    }
	}
	err = NavDisposeReply(&reply);
    }
			
    return err;
}

static OSErr navPutFile(char *pathname, spComponent component)
{	
    NavDialogOptions options;
    NavEventUPP eventUPP;
    NavReplyRecord reply;
    OSType type, signature;
    OSErr err = noErr;
    
    sp_current_type_index = 1;

#if 0
    if (spIsAquaMac() == SP_TRUE) {
	KeyScript(smKeySysScript);
    }
#endif
    
    NavGetDefaultDialogOptions(&options);
    options.dialogOptionFlags &= ~kNavAllowStationery;
    options.dialogOptionFlags &= ~kNavAllowMultipleFiles;
    if (!strnone(SpComponentPart(component).title)) {
	spStrCToP(SpComponentPart(component).title, options.message);
    }
    spCopyPStr("\p", options.savedFileName);
    if (!strnone(SpDialogPart(component).initial_file_name)) {
	spStrCToP(spGetBaseName(SpDialogPart(component).initial_file_name),
		  options.savedFileName);
    }

    eventUPP = NewNavEventUPP(navEventProc);
    type = 'TEXT';		/* dummy */
    signature = kNavGenericSignature;

    navCreatePopup(component, &options);

    /*spLockMainMutexMac();*/
    err = NavPutFile(NULL, &reply, &options, eventUPP,
		     type, signature, (NavCallBackUserData)component);
    /*spUnlockMainMutexMac();*/

    DisposeNavEventUPP(eventUPP);

    if (options.popupExtension != NULL ) {
	DisposeHandle((Handle)options.popupExtension);
    }
		
    spDebug(30, "navPutFile", "reply.validRecord = %d, err = %d\n", reply.validRecord, err);
    
    if (reply.validRecord && err == noErr) {
	AEKeyword keyword;
	DescType dtype;
	Size size;
	FSSpec fsspec;
	
	if ((err = AEGetNthPtr(&(reply.selection), 1, typeFSS, &keyword, &dtype,
			       (Ptr)&fsspec, (long)sizeof(FSSpec), &size)) == noErr) {
	    spDebug(30, "navPutFile", "AEGetNthPtr done: size = %ld\n", size);
	    if (spFSSpecToExactNameMac(&fsspec, pathname) == SP_FALSE) {
		char buf[SP_MAX_PATHNAME];
		
		spStrPToC(fsspec.name, buf);
		spDebug(30, "navPutFile", "spFSSpecToExactNameMac failed: name = %s\n", buf);

		strcpy(pathname, "");
		err = fnfErr;	/* I don't know the meaning of this error. */
#if 1
	    } else {
		spDebug(30, "navPutFile", "%s: %s\n", pathname, (spIsExist(pathname) ? "exist" : "not exist"));
		if (spIsDir(pathname) == SP_TRUE) {
		    strcpy(pathname, "");
		}
#endif
	    }
	}
	
	spDebug(30, "navPutFile", "err = %d, pathname = %s\n", err, pathname);

	reply.translationNeeded = false;
	NavCompleteSave(&reply, kNavTranslateInPlace);
	
	err = NavDisposeReply(&reply);
    }
	
    return err;
}

static OSErr navChooseFolder(char *pathname, spComponent component)
{	
    NavDialogOptions options;
    NavEventUPP eventUPP;
    NavReplyRecord reply;
    OSErr err = noErr;
    
    NavGetDefaultDialogOptions(&options);
    if (!strnone(SpComponentPart(component).title)) {
	spStrCToP(SpComponentPart(component).title, options.message);
    }
    
    eventUPP = NewNavEventUPP(navEventProc);
    
    /*spLockMainMutexMac();*/
    err = NavChooseFolder(NULL, &reply, &options, eventUPP, NULL,
			  (NavCallBackUserData)component);
    /*spUnlockMainMutexMac();*/
    
    DisposeNavEventUPP(eventUPP);
    
    if (reply.validRecord && err == noErr ) {
	AEKeyword keyword;
	DescType dtype;
	Size size;
	FSSpec fsspec;
	
	if (AEGetNthPtr(&(reply.selection), 1, typeFSS, &keyword, &dtype,
			(Ptr)&fsspec, (long)sizeof(FSSpec), &size) == noErr) {
	    spFSSpecToExactNameMac(&fsspec, pathname);
	}
	err = NavDisposeReply(&reply);
    }
			
    return err;
}

static Boolean getDirectoryNameNav(char *pathname, spComponent component)
{
    if (navChooseFolder(pathname, component) == noErr) {
	return true;
    } else {
	return false;
    }
}

static Boolean getFileNameNav(char *pathname, spComponent component,
			      spFileDialogType dialog_type, int *filter_index)
{
    OSErr err;
    
    if (dialog_type == SP_FD_TYPE_OPEN) {
	err = navGetFile(pathname, component);
    } else {
	err = navPutFile(pathname, component);
    }

    if (err == noErr) {
	if (filter_index != NULL) {
	    *filter_index = sp_current_type_index - 1;
	}
    
	return true;
    } else {
	return false;
    }
}
#endif

#if !TARGET_API_MAC_CARBON
/*
 * functions for the directory dialog
 */
#define SP_MAC_SELECT_BUTTON 10
#define SP_MAC_DIR_SELECTION_DIALOG 258

static Str255 sp_prev_dir_name = "\p";
static Boolean sp_dir_selected = false;

pascal Boolean filterFuncDirSelect(CInfoPBPtr pbptr, void *data)
{
    if (pbptr->hFileInfo.ioFlAttrib & kioFlAttribDirMask) {
	return false;
    } else {
	return true;
    }
}

pascal SInt16 hookFuncDirSelect(SInt16 item, DialogPtr dialog, void *data)
{
    SInt16 type, width;
    Handle hitem;
    Rect rect;
    Str255 name;
    Str255 pstr = "\pSelect  '";
    StandardFileReply *reply;

    reply = (StandardFileReply *)data;

    if (reply->sfIsFolder || reply->sfIsVolume) {
	spCopyPStr(reply->sfFile.name, name);

	if (IdenticalString(name, sp_prev_dir_name, NULL) != 0) {
	    spCopyPStr(name, sp_prev_dir_name);
	
	    GetDialogItem(dialog, SP_MAC_SELECT_BUTTON, &type, &hitem, &rect);

	    if (hitem != nil) {
		width = (rect.right - rect.left) - StringWidth("\pSelect  '    ");
		TruncString(width, name, smTruncMiddle);
		spCatPStr(pstr, name);
		spCatPStr(pstr, "\p'");

		SetControlTitle((ControlRef)hitem, pstr);
	    }
	}
    }

    if (item == SP_MAC_SELECT_BUTTON) {
	return sfItemCancelButton;
    } else if (item == sfItemCancelButton) {
	sp_dir_selected = false;
    }

    return item;
}

static Boolean getDirectoryNameOld(char *pathname, spComponent component)
{
    StandardFileReply reply;
    SFTypeList type_list;
    Point location;
    FileFilterYDUPP filterFuncDirSelectUPP;
    DlgHookYDUPP hookFuncDirSelectUPP;

#if 1
    if (Get1Resource('DLOG', SP_MAC_DIR_SELECTION_DIALOG) == nil) {
	return false;
    }
#endif
    reply.sfIsFolder = false;
    reply.sfIsVolume = false;
    reply.sfFile.name[0] = 0;
    
    filterFuncDirSelectUPP = NewFileFilterYDUPP((FileFilterYDProcPtr) filterFuncDirSelect);
    hookFuncDirSelectUPP = NewDlgHookYDUPP((DlgHookYDProcPtr)hookFuncDirSelect);
    
    sp_dir_selected = true;
    
    sp_prev_dir_name[0] = 0;
    location.v = -1; location.h = -1;
    
    /*spLockMainMutexMac();*/
    CustomGetFile(filterFuncDirSelectUPP, -1, type_list, &reply,
		  SP_MAC_DIR_SELECTION_DIALOG, location,
		  hookFuncDirSelectUPP, NULL, NULL, NULL, &reply);
    /*spUnlockMainMutexMac();*/
    
    DisposeFileFilterYDUPP(filterFuncDirSelectUPP);
    DisposeDlgHookYDUPP(hookFuncDirSelectUPP);

    if (sp_dir_selected == false
	|| spFSSpecToExactNameMac(&reply.sfFile, pathname) == SP_FALSE) {
	return false;
    }
    
    return true;
}		

/*
 * functions for the file dialog with popup menu
 */
#define SP_MAC_OPEN_POPUP_ITEM 10
#define SP_MAC_OPEN_DIALOG 256

#define SP_MAC_SAVE_POPUP_ITEM 13
#define SP_MAC_SAVE_DIALOG 257

static spBool sp_fd_initialized = SP_FALSE;

pascal Boolean filterFuncFileDialog(CInfoPBPtr pbptr, void *data)
{
    char path[SP_MAX_PATHNAME];
    spComponent component = (spComponent)data;
    
    if (pbptr->hFileInfo.ioFlAttrib & kioFlAttribDirMask) {
	return false;
    }

    spStrPToC(pbptr->hFileInfo.ioNamePtr, path);

    return !fileDialogFilter(component, path, pbptr->hFileInfo.ioFlFndrInfo.fdType, sp_current_type_index);
}

static MenuHandle getPopupMenuHandle(ControlRef control)
{
    MenuHandle menu = NULL;
    
#if ACCESSOR_CALLS_ARE_FUNCTIONS
    menu = GetControlPopupMenuHandle(control);
#else
    {
	PopupPrivateDataHandle hpopup;
	    
	if ((hpopup = (PopupPrivateDataHandle)(*control)->contrlData) == NULL) {
		return NULL;
	}
	menu = (*hpopup)->mHandle;
    }
#endif

    return menu;
}

pascal SInt16 hookFuncFileDialog(SInt16 item, DialogPtr dialog, void *data)
{
    int i;
    int popup_item_id;
    int num_menu;
    SInt16 type;
    Handle control;
    Rect rect;
    MenuHandle menu;
    char *string;
    Str255 pstr;
    spFileDialogType dialog_type;
    spComponent component = (spComponent)data;

    spDebug(30, "hookFuncFileDialog", "item = %d, component = %ld\n", item, (long)component);
    
    dialog_type = (spFileDialogType)spGetUserData(component);
    if (dialog_type == SP_FD_TYPE_OPEN) {
	popup_item_id = SP_MAC_OPEN_POPUP_ITEM;
    } else {
	popup_item_id = SP_MAC_SAVE_POPUP_ITEM;
    }
	spDebug(30, "hookFuncFileDialog", "dialog_type = %d, popup_item_id = %d\n", dialog_type, popup_item_id);

    if (item == sfHookFirstCall
	&& sp_fd_initialized == SP_FALSE) {
	GetDialogItem(dialog, popup_item_id, &type, &control, &rect);
	spDebug(30, "hookFuncFileDialog", "control = %ld\n", (long)control);

	if ((SpDialogPart(component).file_types != NULL
         || SpDialogPart(component).file_filters != NULL)
		 && (menu = getPopupMenuHandle((ControlRef)control)) != NULL) {
	    num_menu = CountMenuItems(menu);
	    for (i = 0;; i++) {
		if (SpDialogPart(component).file_types != NULL) {
		    string = SpDialogPart(component).file_types[i];
		} else {
		    string = SpDialogPart(component).file_filters[i];
		}
		if (strnone(string)) {
		    break;
		}
		
		spStrCToP(string, pstr);
		spDebug(30, "hookFuncFileDialog", "num_menu = %d, string = %s\n", num_menu, string);

		if (i >= num_menu) {
		    InsertMenuItem(menu, "\p ", i + 1);
		}
		spSetMenuItemTextMac(menu, i + 1, pstr);
	    }
		spDebug(30, "hookFuncFileDialog", "set menu item done: i = %d\n", i);
		
	    if (i < num_menu) {
		int j;
		
		for (j = num_menu; j > i; j--) {
		    if (j <= 1) {
			spSetMenuItemTextMac(menu, j, "\pAll Files");
			break;
		    } else {
			DeleteMenuItem(menu, j);
		    }
		}
	    }
	}
	SetControlValue((ControlRef)control, sp_current_type_index);
	sp_fd_initialized = SP_TRUE; /* because 2nd sfHookFirstCall causes crush */
	spDebug(30, "hookFuncFileDialog", "initialize done\n");
	return sfHookNullEvent;
    }
    else if ((dialog_type == SP_FD_TYPE_OPEN
	      && item == SP_MAC_OPEN_POPUP_ITEM)
	     || (dialog_type == SP_FD_TYPE_SAVE
		 && item == SP_MAC_SAVE_POPUP_ITEM)) {
	GetDialogItem(dialog, popup_item_id, &type, &control, &rect);
	type = GetControlValue((ControlRef)control);
	if (type != sp_current_type_index)
	{
	    sp_current_type_index = type;
	    return sfHookRebuildList;
	}
    }
	
    return item;
}

static Boolean getFile(StandardFileReply *reply, spComponent component,
		       spFileDialogType dialog_type, int *filter_index)
{
    
    Point location;
    FileFilterYDUPP filterFuncFileDialogUPP;
    DlgHookYDUPP hookFuncFileDialogUPP;
    Str255 pprompt = "\p", pdefault_name = "\p";

    if (!strnone(SpComponentPart(component).title)) {
	spStrCToP(SpComponentPart(component).title, pprompt);
    }
    if (!strnone(SpDialogPart(component).initial_file_name)) {
	spStrCToP(spGetBaseName(SpDialogPart(component).initial_file_name),
		  pdefault_name);
    }
    
    if (dialog_type == SP_FD_TYPE_OPEN && Get1Resource('DLOG', SP_MAC_OPEN_DIALOG) == nil) {
	/*spLockMainMutexMac();*/
	StandardGetFile(NULL, -1, NULL, reply);
	/*spUnlockMainMutexMac();*/
	return true;
    } else if (dialog_type == SP_FD_TYPE_SAVE && Get1Resource('DLOG', SP_MAC_SAVE_DIALOG) == nil) {
	/*spLockMainMutexMac();*/
	StandardPutFile(pprompt, pdefault_name, reply);
	/*spUnlockMainMutexMac();*/
	return true;
    }
    
    spSetUserData(component, (void *)dialog_type);
    
    sp_fd_initialized = SP_FALSE;
    sp_current_type_index = 1;
    filterFuncFileDialogUPP = NewFileFilterYDUPP((FileFilterYDProcPtr)filterFuncFileDialog);
    hookFuncFileDialogUPP = NewDlgHookYDUPP((DlgHookYDProcPtr)hookFuncFileDialog);

    location.v = -1; location.h = -1;

    /*spLockMainMutexMac();*/
    if (dialog_type == SP_FD_TYPE_OPEN) {
	CustomGetFile(filterFuncFileDialogUPP, -1, NULL, reply, SP_MAC_OPEN_DIALOG,
		      location, hookFuncFileDialogUPP, NULL, NULL, NULL, component);
    } else {
	CustomPutFile(pprompt, pdefault_name, reply, SP_MAC_SAVE_DIALOG,
		      location, hookFuncFileDialogUPP, NULL, NULL, NULL, component);
    }
    /*spUnlockMainMutexMac();*/
    
    DisposeFileFilterYDUPP(filterFuncFileDialogUPP);
    DisposeDlgHookYDUPP(hookFuncFileDialogUPP);

    if (filter_index != NULL) {
	*filter_index = sp_current_type_index - 1;
    }
    
    return true;
}

static Boolean getFileNameOld(char *pathname, spComponent component,
			      spFileDialogType dialog_type, int *filter_index)
{
    StandardFileReply reply;
    
    getFile(&reply, component, dialog_type, filter_index);
    if (!reply.sfGood || spFSSpecToExactNameMac(&reply.sfFile, pathname) == SP_FALSE) {
	return false;
    }
    
    return true;
}

static Boolean getDirectoryName(char *pathname, spComponent component)
{
    if (spGetAppearanceVersionMac() >= 0x00000101 && NavServicesAvailable()) {
	return getDirectoryNameNav(pathname, component);
    } else {
	return getDirectoryNameOld(pathname, component);
    }
}

static Boolean getFileName(char *pathname, spComponent component,
			   spFileDialogType dialog_type, int *filter_index)
{
    if (spGetAppearanceVersionMac() >= 0x00000101 && NavServicesAvailable()) {
	return getFileNameNav(pathname, component, dialog_type, filter_index);
    } else {
	return getFileNameOld(pathname, component, dialog_type, filter_index);
    }
}
#else
static Boolean getDirectoryName(char *pathname, spComponent component)
{
    return getDirectoryNameNav(pathname, component);
}

static Boolean getFileName(char *pathname, spComponent component,
			   spFileDialogType dialog_type, int *filter_index)
{
    return getFileNameNav(pathname, component, dialog_type, filter_index);
}
#endif

char *xspPopupFileSelectionBoxArg(spComponent parent, char *name,
				  spFileDialogType dialog_type,
				  spArg *args, int num_arg)
{
    Boolean flag = false;
    spComponent window;
    spComponent component;
    char pathname[SP_MAX_PATHNAME];

    window = spGetCurrentWindowMac();
    spDeactivateWindowMac(window, SP_TRUE);
    
    component = spCreateComponentArg(SpDialogClass, SpFileDialog,
				     name, NULL, args, num_arg);
    spDebug(50, "xspPopupFileSelectionBoxArg", "create component done\n");

    strcpy(pathname, "");
    if (dialog_type == SP_FD_TYPE_DIR) {
	flag = getDirectoryName(pathname, component);
    } else {
	int filter_index = 0;

	flag = true;
	while (flag) {
	    flag = getFileName(pathname, component, dialog_type, &filter_index);
	    if (flag) {
		if (dialog_type != SP_FD_TYPE_SAVE
		    || spAddCurrentFilterSuffix(component, filter_index, pathname) == SP_TRUE) {
		    break;
		}
	    }
	}
	
	if (flag && SpDialogPart(component).filter_index != NULL) {
	    *SpDialogPart(component).filter_index = filter_index;
	}
    }

    spDestroyComponent(component);
    
    spActivateWindowMac(window, SP_TRUE);
    
    if (flag == false) {
	return NULL;
    }

    spDebug(10, "xspPopupFileSelectionBoxArg", "pathname = %s\n", pathname);
    
    return strclone(pathname);
}

char *xspChooseFontArch(spComponent component)
{
    return xspChooseFontDefault(component);
}

#if !defined(MACOSX)
#include <ColorPicker.h>
#endif

char *xspChooseColorArch(spComponent component)
{
    Point point;
    Str255 pstr;
    RGBColor o_color;
    static RGBColor i_color = {0, 0, 0};
    
    point.h = -1; point.v = -1; 
    spStrCToP(spGetTitle(component), pstr);

    if (!strnone(SpDialogPart(component).initial_color)) {
	i_color = spGetRGBMac(SpDialogPart(component).initial_color);
    }
    
    if (GetColor(point, pstr, &i_color, &o_color)) {
	char color_name[SP_MAX_LINE];

	spGetColorName(spGetPixelMac(o_color), color_name);
	i_color = o_color;
	
	return strclone(color_name);
    }
    
    return NULL;
}
