/*
 *	spDial.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spContainer.h>
#include <sp/spCanvas.h>
#include <sp/spGraphics.h>
#include <sp/spDraw.h>

#include <sp/spDialP.h>

static spParamTable sp_dial_param_tables[] = {
    {SppShowScale, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.show_scale), SP_FALSE_STRING},
    {SppValue, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.value), "50"},
    {SppMinimum, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.minimum), "0"},
    {SppMaximum, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.maximum), "100"},
    {SppMinimumAngle, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.minimum_angle), "240"},
    {SppMaximumAngle, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.maximum_angle), "300"},
    {SppIncrement, SP_CREATE_ACCESS | SP_SET_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.increment), "10"},
    {SppShadowWidth, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.shadow_width), NULL},
    {SppIndicatorSize, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.indicator_size), NULL},
    {SppIndicatorType, SP_CREATE_ACCESS | SP_GET_ACCESS,
	 spOffset(spDial, dial.indicator_type), NULL},
};

spDialClassRec SpDialClassRec = {
    /* spObjectClassPart */
    {
	SpDial,
	(spObjectClass)&SpComponentClassRec,
	sizeof(spDialRec),
	spArraySize(sp_dial_param_tables),
	sp_dial_param_tables,
	spDialPartInit,
	spDialPartFree,
	SP_FALSE,
	NULL,
	NULL,
	spDialCreate,
	spDialDestroy,
	spDialSetParams,
	spDialGetParams,
    },
    /* spComponentClassPart */
    {
	SP_FALSE,
	SP_FALSE,
	SP_FALSE,
	spDialMap,
	spDialUnmap,
	spDialSetSize,
	spDialGetSize,
	spDialGetClientSize,
	spDialSetSensitive,
	spDialIsComponentType,

	spDialAddCallback,
	spDialRemoveCallback,
	spDialCallbackFunc,
	NULL,
	NULL,
    },
    /* spDialClassPart */
    {
	0,
    },
};

spComponentClass SpDialClass = (spComponentClass)&SpDialClassRec;

void spDialPartInit(spObject object)
{
    spComponent component = (spComponent)object;
    
    SpDialPart(component).canvas = NULL;
    SpDialPart(component).radius = 0;
    SpDialPart(component).cx = 0;
    SpDialPart(component).cy = 0;
    SpDialPart(component).button_down = SP_FALSE;

    SpDialPart(component).shadow_width = SP_DIAL_SHADOW_WIDTH;
    SpDialPart(component).indicator_size = SP_DIAL_INDICATOR_SIZE;
    SpDialPart(component).indicator_type = SP_DIAL_INDICATOR_LINE;
    
    return;
}

void spDialPartFree(spObject object)
{
    return;
}

void drawDial(spComponent component, spBool redraw_flag)
{
    int x, y;
    int w, h;
    int cx, cy;
    int width = 0, height = 0;
    double radius;
    double cc, sc;
    double angle;
    double theta;
    double increment;
    spComponent dial;
    static spGraphics background_gx = NULL;
    static spGraphics highlight_gx = NULL;
    static spGraphics top_shadow_gx = NULL;
    static spGraphics bottom_shadow_gx = NULL;
    static spGraphics dark_shadow_gx = NULL;
    static spGraphics black_gx = NULL;
    static spGraphics focus_gx = NULL;

    spDebug(50, "drawDial", "in: %s\n", SpGetClassName(component));

    dial = SpGetPropagateComponent(component);

    if (background_gx == NULL) {
	background_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_BACKGROUND);
    }
    if (top_shadow_gx == NULL) {
	top_shadow_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_TOP_SHADOW);
    }
    if (bottom_shadow_gx == NULL) {
	bottom_shadow_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_BOTTOM_SHADOW);
    }
    if (highlight_gx == NULL) {
	highlight_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_HIGHLIGHT);
    }
    if (dark_shadow_gx == NULL) {
	dark_shadow_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_DARK_SHADOW);
    }
    if (black_gx == NULL) {
	black_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_BLACK);
    }
    if (focus_gx == NULL) {
	focus_gx = spGetSystemGraphics(SP_SYSTEM_COLOR_FOCUS);
    }
    
    if (spGetClientSize(component, &width, &height) == SP_TRUE) {
	spDebug(40, "drawDial", "width = %d, height = %d\n", width, height);

	radius = (int)(MIN(width, height) / 2) - SP_DIAL_TICK_LENGTH;

	cx = width / 2;
	cy = height / 2;

	if (redraw_flag == SP_TRUE) {
	    x = cx - (int)radius;
	    y = cy - (int)radius;
	    w = (int)radius * 2 - 1; h = w;

	    spFillArc(component, top_shadow_gx, x, y, w, h, 45, 180);
#if 0
	    spFillArc(component, bottom_shadow_gx, x, y, w, h, 225, 180);
	    spDrawArc(component, dark_shadow_gx, x, y, w, h, 225, 180);
#else
	    spFillArc(component, dark_shadow_gx, x, y, w, h, 225, 180);
	    spFillArc(component, bottom_shadow_gx, x+1, y+1, w-2, h-2, 225, 180);
#endif
	    if (spIsCanvasFocused(component) == SP_TRUE) {
		spDrawArc(component, focus_gx, x, y, w, h, 0, 360);
	    }
	    spDebug(40, "drawDial", "fill background done: x = %d, y = %d, w = %d, h = %d\n",
		    x, y, w, h);
	    
	    if (SpDialPart(dial).show_scale == SP_TRUE) {
		increment = (double)(SpDialPart(dial).minimum_angle - SpDialPart(dial).maximum_angle)
		    * (double)SpDialPart(dial).increment /
			(SpDialPart(dial).maximum - SpDialPart(dial).minimum);
		
		for (angle = SpDialPart(dial).minimum_angle; angle >= SpDialPart(dial).maximum_angle;
		     angle -= increment) {
		    theta = PI * angle / 180.0;
		    cc = cos(theta);
		    sc = sin(theta);
		    
		    spDrawLine(component, black_gx,
			       cx + (int)spRound(cc * radius),
			       cy - (int)spRound(sc * radius),
			       cx + (int)spRound(cc * (radius + SP_DIAL_TICK_LENGTH)),
			       cy - (int)spRound(sc * (radius + SP_DIAL_TICK_LENGTH)));
		}
	    }
	}

	x = cx - (int)radius + SpDialPart(dial).shadow_width;
	y = cy - (int)radius + SpDialPart(dial).shadow_width;
	w = ((int)radius - SpDialPart(dial).shadow_width) * 2 - 1; h = w;
	spFillArc(component, background_gx, x, y, w, h, 0, 360);
	spDrawArc(component, highlight_gx, x, y, w, h, 45, 180);

	theta = 2 * PI * SpDialPart(dial).angle / 360.0;
	cc = cos(theta);
	sc = sin(theta);

	if (SpDialPart(dial).indicator_type == SP_DIAL_INDICATOR_LINE) {
	    spFillArc(component, bottom_shadow_gx, x, y, w, h,
		      SpDialPart(dial).angle - SP_DIAL_LINE_SHADOW_ANGLE,
		      SP_DIAL_LINE_SHADOW_ANGLE * 2);
	    if (SpDialPart(dial).angle == 135
		|| SpDialPart(dial).angle == 315) {
		/* do nothing */
	    } else if (SpDialPart(dial).angle > 135
		       && SpDialPart(dial).angle < 315) {
		spFillArc(component, top_shadow_gx, x, y, w, h, SpDialPart(dial).angle,
			  SP_DIAL_LINE_SHADOW_ANGLE);
	    } else {
		spFillArc(component, top_shadow_gx, x, y, w, h,
			  SpDialPart(dial).angle - SP_DIAL_LINE_SHADOW_ANGLE,
			  SP_DIAL_LINE_SHADOW_ANGLE);
	    }
	    x = cx - (int)radius + SpDialPart(dial).shadow_width + SpDialPart(dial).indicator_size;
	    y = cy - (int)radius + SpDialPart(dial).shadow_width + SpDialPart(dial).indicator_size;
	    w = ((int)radius - SpDialPart(dial).shadow_width - SpDialPart(dial).indicator_size) * 2 - 1;
	    h = w;
	    spFillArc(component, background_gx, x, y, w, h, 0, 360);
	} else {
	    x = cx + (int)spRound(cc * (radius - SP_DIAL_INDICATOR_OFFSET - SpDialPart(dial).shadow_width))
		- SpDialPart(dial).indicator_size / 2;
	    y = cy - (int)spRound(sc * (radius - SP_DIAL_INDICATOR_OFFSET - SpDialPart(dial).shadow_width))
		- SpDialPart(dial).indicator_size / 2;
	    w = SpDialPart(dial).indicator_size; h = w;
	    
	    spFillArc(component, bottom_shadow_gx, x, y, w, h, 0, 360);
	}

	SpDialPart(dial).radius = (int)radius;
	SpDialPart(dial).cx = cx;
	SpDialPart(dial).cy = cy;
    }

    spDebug(80, "drawDial", "done\n");
    
    return;
}

static void refreshDial(spComponent component, spBool redraw_flag)
{
    drawDial(SpDialPart(component).canvas, redraw_flag);
    spRefreshCanvas(SpDialPart(component).canvas);

    return;
}

spBool setDialValue(spComponent component, int value)
{
    double increment;
    
    if (spIsDial(component) == SP_FALSE) {
	if (spIsDial(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    SpDialPart(component).value = value;

    increment = (double)(SpDialPart(component).minimum_angle - SpDialPart(component).maximum_angle)
	* (double)SpDialPart(component).value /
	    (double)(SpDialPart(component).maximum - SpDialPart(component).minimum);
    SpDialPart(component).angle = (int)spRound((double)SpDialPart(component).minimum_angle - increment);
    if (SpDialPart(component).angle < 0.0) {
	SpDialPart(component).angle += 360;
    }
    spDebug(50, "setDialValue", "angle = %d\n", SpDialPart(component).angle);
    
    return SP_TRUE;
}

void spDialCreate(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (SpDialPart(component).maximum_angle > SpDialPart(component).minimum_angle) {
	SpDialPart(component).maximum_angle -= 360;
    }

    setDialValue(component, SpDialPart(component).value);
    
    SpComponentPart(component).x = 0;
    SpComponentPart(component).y = 0;
    if (SpComponentPart(component).width == 0
	&& SpParentComponentPart(component).orientation == SP_HORIZONTAL) {
	SpComponentPart(component).width = SP_DEFAULT_DIAL_WIDTH;
    }
    if (SpComponentPart(component).require_width <= 0) {
	SpComponentPart(component).require_width
	    = MAX(SpComponentPart(component).width, SP_DEFAULT_DIAL_WIDTH);
    }
    if (SpComponentPart(component).height == 0
	&& SpParentComponentPart(component).orientation == SP_VERTICAL) {
	SpComponentPart(component).height = SP_DEFAULT_DIAL_HEIGHT;
    }
    if (SpComponentPart(component).require_height <= 0) {
	SpComponentPart(component).require_height
	    = MAX(SpComponentPart(component).height, SP_DEFAULT_DIAL_HEIGHT);
    }
    SpComponentPart(component).current_width = SpComponentPart(component).width;
    SpComponentPart(component).current_height = SpComponentPart(component).height;

    SpDialPart(component).canvas = spCreateCanvas(SpGetParent(component), "canvas",
						  SpComponentPart(component).require_width,
						  SpComponentPart(component).require_height,
						  SppCallbackFunc, drawDial,
						  SppCallbackData, SP_TRUE,
						  SppWidth, SpComponentPart(component).width,
						  SppHeight, SpComponentPart(component).height,
						  SppFocusable, SP_TRUE,
						  SppDrawBackground, SP_TRUE,
						  SppUseArrowKey, SP_TRUE,
						  NULL);
    SpGetPropagateComponent(SpDialPart(component).canvas) = component;

    if (SpComponentPart(component).call_func != NULL) {
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK,
		      SpComponentPart(component).call_func,
		      SpComponentPart(component).call_data);
    }
    
    return;
}

void spDialDestroy(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spDestroyComponent(SpDialPart(component).canvas);

    return;
}

void spDialSetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    if (SpDialPart(SpOldObject(component)).value != SpDialPart(component).value) {
	spSetDialValue(component, SpDialPart(component).value);
    }
    
    return;
}

void spDialGetParams(spObject object)
{
    spComponent component = (spComponent)object;
    
    if (component == NULL) return;

    spGetDialValue(component, NULL);

    return;
}

void spDialMap(spComponent component)
{
    spMapComponent(SpDialPart(component).canvas);
    return;
}

void spDialUnmap(spComponent component)
{
    spUnmapComponent(SpDialPart(component).canvas);
    return;
}

spBool spDialSetSize(spComponent component, int width, int height)
{
    return spSetSize(SpDialPart(component).canvas, width, height);
}

spBool spDialGetSize(spComponent component, int *width, int *height)
{
    return spGetSize(SpDialPart(component).canvas, width, height);
}

spBool spDialGetClientSize(spComponent component, int *width, int *height)
{
    return spGetClientSize(SpDialPart(component).canvas, width, height);
}

spBool spDialSetSensitive(spComponent component, spBool flag)
{
    if (spSetSensitive(SpDialPart(component).canvas, flag) == SP_TRUE) {
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

spBool spDialIsComponentType(spComponent component, char *class_name)
{
    return SP_FALSE;
}

spCallbackReason spDialCallbackFunc(spComponent component)
{
    double angle = 0.0;
    double value;
    double xd, yd;
    int x = 0, y = 0;
    spComponent canvas;
    spCallbackReason canvas_reason;
    spCallbackReason call_reason = SP_CR_NONE;

    canvas = SpDialPart(component).canvas;
    canvas_reason = spGetCallbackReason(canvas);
    
    spDebug(60, "spDialCallbackFunc", "%s: reason = %d\n",
	    SpGetClassName(component), canvas_reason);

    if (canvas_reason == SP_CR_KEY_PRESS) {
	int prev_value;
	spKeySym key_sym;
	
	if (spGetCallbackKeySym(canvas, &key_sym) == SP_TRUE) {
	    spDebug(60, "spDialCallbackFunc", "key_sym = %ld\n", key_sym);

	    prev_value = SpDialPart(component).value;
    
	    switch (key_sym) {
	      case SPK_Left:
	      case SPK_Down:
		setDialValue(component,
			     MAX(SpDialPart(component).value - SpDialPart(component).increment,
				 SpDialPart(component).minimum));
		angle = SpDialPart(component).angle;
		call_reason = SP_CR_VALUE_CHANGED;
		break;
	      case SPK_Right:
	      case SPK_Up:
		setDialValue(component,
			     MIN(SpDialPart(component).value + SpDialPart(component).increment,
				 SpDialPart(component).maximum));
		angle = SpDialPart(component).angle;
		call_reason = SP_CR_VALUE_CHANGED;
		break;
	      default:
		break;
	    }
	    if (SpDialPart(component).value == prev_value) {
		return SP_CR_NONE;
	    }
	}
    } else if (spGetCallbackMousePosition(canvas, &x, &y) == SP_TRUE) {
	spDebug(40, "spDialCallbackFunc", "x = %d, y = %d\n", x, y);
	yd = (double)(SpDialPart(component).cy - y);
	xd = (double)(x - SpDialPart(component).cx);

	spDebug(50, "spDialCallbackFunc", "xd = %f, yd = %f, raduis = %d\n",
		xd, yd, SpDialPart(component).radius);

	if (SpDialPart(component).button_down == SP_FALSE
	    && (int)sqrt(xd * xd + yd * yd) > SpDialPart(component).radius) {
	    return SP_CR_NONE;
	}

	spDebug(50, "spDialCallbackFunc", "canvas_reason = %d\n", canvas_reason);
	
	if (canvas_reason == SP_CR_LBUTTON_PRESS) {
	    SpDialPart(component).button_down = SP_TRUE;
	    call_reason = SP_CR_VALUE_CHANGED;
	} else if (canvas_reason == SP_CR_LBUTTON_RELEASE) {
	    SpDialPart(component).button_down = SP_FALSE;
	    call_reason = SP_CR_VALUE_CHANGED;
	}

	if (call_reason != SP_CR_VALUE_CHANGED
	    && SpDialPart(component).button_down == SP_FALSE) {
	    return SP_CR_NONE;
	}

	if (yd == 0.0 && xd == 0.0) {
	    value = 0.0;
	} else {
	    value = atan2(yd, xd);
	}
	if (value < 0.0) value += 2 * PI;
	
	angle = spRound(180.0 * value / PI);
	
	spDebug(50, "spDialCallbackFunc", "angle = %f, min = %d, max = %d\n",
		angle, SpDialPart(component).minimum_angle,
		SpDialPart(component).maximum_angle);
	call_reason = SP_CR_VALUE_CHANGED;

	if (angle > SpDialPart(component).minimum_angle
	    && angle < SpDialPart(component).maximum_angle + 360) {
	    return SP_CR_NONE;
	}
    }
    
    if (call_reason == SP_CR_VALUE_CHANGED) {
	SpDialPart(component).angle = (int)angle;
	spDebug(40, "spDialCallbackFunc", "angle = %d\n",
		SpDialPart(component).angle);
	
	drawDial(canvas, SP_FALSE);
	spRefreshCanvas(canvas);
    }
    
    return call_reason;
}

spBool spDialAddCallback(spComponent component, spBool propagate, spCallbackType call_type,
			 spCallbackFunc call_func, void *call_data)
{
    if (call_type & SP_VALUE_CHANGED_CALLBACK) {
	spAddPropagateCallback(SpDialPart(component).canvas,
			       SP_BUTTON_PRESS_CALLBACK | SP_BUTTON_RELEASE_CALLBACK
			       | SP_BUTTON_MOTION_CALLBACK | SP_KEY_PRESS_CALLBACK,
			       call_func, call_data);
    }
    
    return SP_FALSE;
}

spBool spDialRemoveCallback(spComponent component, spCallbackType call_type,
			    spCallbackFunc call_func, void *call_data)
{
    if (call_type & SP_VALUE_CHANGED_CALLBACK) {
	spRemoveCallback(SpDialPart(component).canvas,
			 SP_BUTTON_PRESS_CALLBACK | SP_BUTTON_RELEASE_CALLBACK
			 | SP_BUTTON_MOTION_CALLBACK | SP_KEY_PRESS_CALLBACK,
			 call_func, call_data);
    }

    return SP_FALSE;
}

spBool spIsDial(spComponent component)
{
    return spIsSubClass(component, SpDial);
}

spComponent spCreateDial(spComponent parent, char *name, ...)
{
    int num_arg = 0;
    spArg args[SP_MAX_NUM_ARG];
    va_list argp;

    if (spIsCreated(parent) == SP_FALSE || spIsContainer(parent) == SP_FALSE)
	return NULL;
    
    va_start(argp, name);
    spGetArgs(argp, args, num_arg);
    va_end(argp);

    return spCreateComponentArg(SpDialClass, NULL, name, parent, args, num_arg);
}

spBool spSetDialValue(spComponent component, int value)
{
    if (setDialValue(component, value) == SP_TRUE) {
	refreshDial(component, SP_FALSE);
	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spGetDialValue(spComponent component, int *value)
{
    double increment;
    
    if (spIsDial(component) == SP_FALSE) {
	if (spIsDial(spGetComponent(component)) == SP_TRUE) {
	    component = spGetComponent(component);
	} else {
	    return SP_FALSE;
	}
    }

    increment = (double)(SpDialPart(component).minimum_angle - SpDialPart(component).angle);
    if (increment < 0.0) {
	increment += 360.0;
    }
    SpDialPart(component).value =
	(int)spRound(increment * (double)(SpDialPart(component).maximum - SpDialPart(component).minimum)
		     / (double)(SpDialPart(component).minimum_angle - SpDialPart(component).maximum_angle));
    
    spDebug(50, "spGetDialValue", "increment = %f, value = %d\n",
	    increment, SpDialPart(component).value);
    
    if (value != NULL)
	*value = SpDialPart(component).value;
    
    return SP_TRUE;
}
