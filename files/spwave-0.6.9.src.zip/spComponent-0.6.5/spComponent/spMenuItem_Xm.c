/*
 *	spMenuItem_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <Xm/Xm.h>
#include <Xm/MainW.h>
#include <Xm/RowColumn.h>
#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/Separator.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>

#include <sp/spBase.h>
#include <sp/spOption.h>

#include <sp/spStatusBar.h>

#include <sp/spMenuItemP.h>

void spShowMenuHelpCB(Widget widget, XtPointer client_data, XEvent *event)
{
    spComponent component = (spComponent)client_data;

    if (event->type != EnterNotify && event->type != LeaveNotify) return;
    
    if (event->type == EnterNotify
	&& SpGetDescription(component) != NULL) {
	spSetHelpStatusText(component, SpGetDescription(component));
    } else {
	spSetHelpStatusText(component, "");
    }

    return;
}

void spMenuItemCreateArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    XmString xmstr;
    int narg = 0;
    Arg args[10];

    strcpy(label, "");
    if (!strnone(SpComponentPart(component).title)) {
	mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
    }
    
    if (spIsToggleButton(component) == SP_TRUE) {
	if (spIsRadioButton(component) == SP_TRUE) {
	    XtSetArg(args[narg], XmNindicatorType, XmONE_OF_MANY); narg++;
	}
	XtSetArg(args[narg], XmNalignment, XmALIGNMENT_BEGINNING); narg++;
	XtSetArg(args[narg], XmNvisibleWhenOff, False); narg++;
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component))
				   ? SpGetName(component) : ""),
				  xmToggleButtonWidgetClass,
				  SpParentPrimitiveArch(component).widget,
				  args, narg);
    } else {
	SpPrimitiveArch(component).widget =
	    XtCreateManagedWidget((!strnone(SpGetName(component))
				   ? SpGetName(component) : ""),
				  xmPushButtonWidgetClass,
				  SpParentPrimitiveArch(component).widget,
				  args, narg);
    }
    
    XtAddEventHandler(SpPrimitiveArch(component).widget, EnterWindowMask, False,
		      (XtEventHandler)spShowMenuHelpCB, (XtPointer)component);
    XtAddEventHandler(SpPrimitiveArch(component).widget, LeaveWindowMask, False,
		      (XtEventHandler)spShowMenuHelpCB, (XtPointer)component);
	
    if (!strnone(label)) {
	spDebug(40, NULL, "label = %s\n", label);
	xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNmnemonic, mnemonic,
		      XmNlabelString, xmstr,
		      NULL);
	XmStringFree(xmstr);
    }

    if (spIsRadioButton(component) == SP_TRUE) {
	spAddRadioGroup(component, SpButtonPart(component).radio_end);
	spAddCallback(component, SP_VALUE_CHANGED_CALLBACK, spCheckRadioButtonCB, NULL);
    }
    
    spDebug(40, "spMenuItemCreateArch", "done\n");
    
    return;
}

void spMenuItemSetParamsArch(spComponent component)
{
    int mnemonic = NUL;
    static char label[SP_MAX_MENU_LABEL] = "";
    XmString xmstr;

    if (SpComponentPart(SpOldObject(component)).title != SpComponentPart(component).title) {    
	strcpy(label, "");
	if (!strnone(SpComponentPart(component).title)) {
	    mnemonic = spGetMnemonic(SpComponentPart(component).title, label);
	}
	
	if (!strnone(label)) {
	    spDebug(40, NULL, "label = %s\n", label);
	    xmstr = XmStringCreate(label, XmFONTLIST_DEFAULT_TAG);
	    XtVaSetValues(SpPrimitiveArch(component).widget,
			  XmNmnemonic, mnemonic,
			  XmNlabelString, xmstr,
			  NULL);
	    XmStringFree(xmstr);
	}
    }

    spDebug(40, "spMenuItemSetParamsArch", "done\n");
    
    return;
}

void spMenuSeparatorCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[10];

    SpPrimitiveArch(component).widget =
	XtCreateManagedWidget((!strnone(SpGetName(component))
			       ? SpGetName(component) : ""),
			      xmSeparatorWidgetClass,
			      SpParentPrimitiveArch(component).widget,
			      args, narg);
    
    return;
}

static spBool convertKeySym(char *key, char *keysym, char *keylabel)
{
    int len;
    spBool flag = SP_TRUE;

    if (strnone(key)) {
	flag = SP_FALSE;
    } else {
	len = strlen(key);
	if (streq(key, "RET") ||
	    streq(key, "RETURN") || streq(key, "Return")) {
	    strcpy(keysym, "Return");
	    strcpy(keylabel, "Return");
	} else if (streq(key, "ESC") ||
		   streq(key, "ESCAPE") || streq(key, "Escape")) {
	    strcpy(keysym, "Escape");
	    strcpy(keylabel, "Escape");
	} else if (streq(key, "SPC") ||
		   streq(key, "SPACE") || streq(key, "Space")) {
	    strcpy(keysym, "space");
	    strcpy(keylabel, "Space");
	} else if (streq(key, "DEL") ||
		   streq(key, "DELETE") || streq(key, "Delete")) {
	    strcpy(keysym, "Delete");
	    strcpy(keylabel, "Delete");
	} else if (streq(key, "TAB") || streq(key, "Tab")) {
	    strcpy(keysym, "Tab");
	    strcpy(keylabel, "Tab");
	} else if (streq(key, "LEFT") || streq(key, "Left")) {
	    strcpy(keysym, "Left");
	    strcpy(keylabel, "Left");
	} else if (streq(key, "UP") || streq(key, "Up")) {
	    strcpy(keysym, "Up");
	    strcpy(keylabel, "Up");
	} else if (streq(key, "RIGHT") || streq(key, "Right")) {
	    strcpy(keysym, "Right");
	    strcpy(keylabel, "Right");
	} else if (streq(key, "DOWN") || streq(key, "Down")) {
	    strcpy(keysym, "Down");
	    strcpy(keylabel, "Down");
	} else if (streq(key, "HOME") || streq(key, "Home")) {
	    strcpy(keysym, "Home");
	    strcpy(keylabel, "Home");
	} else if (streq(key, "END") || streq(key, "End")) {
	    strcpy(keysym, "End");
	    strcpy(keylabel, "End");
	} else if (streq(key, "PRIOR") || streq(key, "Prior")) {
	    strcpy(keysym, "Prior");
	    strcpy(keylabel, "Prior");
	} else if (streq(key, "NEXT") || streq(key, "Next")) {
	    strcpy(keysym, "Next");
	    strcpy(keylabel, "Next");
	} else if (streq(key, "F1")) {
	    strcpy(keysym, "F1");
	    strcpy(keylabel, "F1");
	} else if (streq(key, "F2")) {
	    strcpy(keysym, "F2");
	    strcpy(keylabel, "F2");
	} else if (streq(key, "F3")) {
	    strcpy(keysym, "F3");
	    strcpy(keylabel, "F3");
	} else if (streq(key, "F4")) {
	    strcpy(keysym, "F4");
	    strcpy(keylabel, "F4");
	} else if (streq(key, "F5")) {
	    strcpy(keysym, "F5");
	    strcpy(keylabel, "F5");
	} else if (streq(key, "F6")) {
	    strcpy(keysym, "F6");
	    strcpy(keylabel, "F6");
	} else if (streq(key, "F7")) {
	    strcpy(keysym, "F7");
	    strcpy(keylabel, "F7");
	} else if (streq(key, "F8")) {
	    strcpy(keysym, "F8");
	    strcpy(keylabel, "F8");
	} else if (streq(key, "F9")) {
	    strcpy(keysym, "F9");
	    strcpy(keylabel, "F9");
	} else if (streq(key, "F10")) {
	    strcpy(keysym, "F10");
	    strcpy(keylabel, "F10");
	} else if (streq(key, "F11")) {
	    strcpy(keysym, "F11");
	    strcpy(keylabel, "F11");
	} else if (streq(key, "F12")) {
	    strcpy(keysym, "F12");
	    strcpy(keylabel, "F12");
	} else if (len == 1) {
	    sprintf(keysym, "%c", tolower(key[0]));
	    sprintf(keylabel, "%c", toupper(key[0]));
	} else {
	    spMessage("unknown key symbol: %s\n", key);
	    flag = SP_FALSE;
	}
    }

    spDebug(30, "convertKeySym", "key = %s, keysym = %s, keylabel = %s\n",
	    key, keysym, keylabel);
    
    return flag;
}

static spBool getShortcutLabel(char *shortcut, char *key, char *label)
{
    spBool flag = SP_TRUE;
    int len;
    char *p = NULL;
    static char modkey[SP_MAX_LINE] = "";
    static char keysym[SP_MAX_LINE] = "";
    static char keylabel[SP_MAX_LINE] = "";

    if (!strnone(shortcut)) {
	len = strlen(shortcut);
	if ((p = strchr(shortcut, '-')) != NULL) {
	    switch (shortcut[0]) {
	      case 'C':
		strcpy(modkey, "Ctrl");
		break;
	      case 'S':
		strcpy(modkey, "Shift");
		break;
	      case 'M':
		strcpy(modkey, "Meta");
		break;
	      case 'A':
		strcpy(modkey, "Alt");
		break;
	      default:
		flag = SP_FALSE;
		break;
	    }
	    if (flag == SP_TRUE &&
		convertKeySym(p + 1, keysym, keylabel) == SP_TRUE) {
		sprintf(key, "%s<Key>%s", modkey, keysym);
		sprintf(label, "%s+%s", modkey, keylabel);
	    } else {
		spMessage("unknown shortcut: %s\n", shortcut);
		flag = SP_FALSE;
	    }
	} else if (convertKeySym(shortcut, keysym, keylabel) == SP_TRUE) {
	    sprintf(key, "<Key>%s", keysym);
	    sprintf(label, "%s", keylabel);
	} else {
	    flag = SP_FALSE;
	}
    } else {
	flag = SP_FALSE;
    }
    
    spDebug(30, "getShortcutLabel", "shortcut = %s, key = %s, label = %s\n",
	    shortcut, key, label);
    
    return flag;
}

spBool spAddShortcutArch(spComponent component, char *shortcut)
{
    XmString xmstr;
    static char shortcut_key[SP_MAX_MENU_LABEL] = "";
    static char shortcut_label[SP_MAX_MENU_LABEL] = "";
    
    if (component != NULL && SpPrimitiveArch(component).widget != NULL &&
	getShortcutLabel(shortcut, shortcut_key, shortcut_label) == SP_TRUE) {
	xmstr = XmStringCreate(shortcut_label, XmFONTLIST_DEFAULT_TAG);
	XtVaSetValues(SpPrimitiveArch(component).widget,
		      XmNaccelerator, shortcut_key,
		      XmNacceleratorText, xmstr,
		      NULL);
	XmStringFree(xmstr);

	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}
