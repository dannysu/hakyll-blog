/*
 *	spPrimitive_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spComponent.h>
#include <sp/spDialog.h>

#include <sp/spTopLevelP.h>
#include <sp/spFrameP.h>
#include <sp/spMenuP.h>
#include <sp/spButtonP.h>
#include <sp/spSliderP.h>
#include <sp/spMenuItemP.h>
#include <sp/spLabelP.h>
#include <sp/spTextP.h>
#include <sp/spListP.h>
#include <sp/spComboBoxP.h>
#include <sp/spTabBoxP.h>
#include <sp/spToolItemP.h>
#include <sp/spToolBarP.h>
#include <sp/spContainerP.h>
#include <sp/spStatusBarP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spCanvasP.h>
#include <sp/spDialogP.h>
#include <sp/spPrimitiveP.h>

#if defined(MACOS)
#pragma import on
#endif

extern spTopLevel sp_toplevel;

#if defined(MACOS)
#pragma import off
#endif

void spLockWindowPort(WindowPtr window, GrafPtr *save_port)
{
    spDebug(100, "spLockWindowPort", "++++++++ lock port ++++++++\n");
    
    spLockPortMutexMac();

#if TARGET_API_MAC_CARBON
    LockPortBits(GetWindowPort(window));
#endif
    GetPort(save_port);
    SetPortWindowPort(window);
    
    return;
}

void spUnlockWindowPort(WindowPtr window, GrafPtr save_port)
{
    SetPort(save_port);
#if TARGET_API_MAC_CARBON
    UnlockPortBits(GetWindowPort(window));
#endif
    
    spUnlockPortMutexMac();
    
    spDebug(100, "spLockWindowPort", "-------- unlock port --------\n");
    
    return;
}

void spLockDialogPort(DialogPtr dialog, GrafPtr *save_port)
{
    spLockPortMutexMac();
    
#if TARGET_API_MAC_CARBON
    LockPortBits(GetDialogPort(dialog));
#endif
    
    GetPort(save_port);
#if ACCESSOR_CALLS_ARE_FUNCTIONS
    SetPortDialogPort(dialog);
#else
    SetPort(dialog);
#endif
    
    return;
}

void spUnlockDialogPort(DialogPtr dialog, GrafPtr save_port)
{
    SetPort(save_port);
#if TARGET_API_MAC_CARBON
    UnlockPortBits(GetDialogPort(dialog));
#endif
    
    spUnlockPortMutexMac();
    
    return;
}

RgnHandle spGetVisibleRegionMac(WindowPtr window)
{
#if !TARGET_API_MAC_CARBON
    return window->visRgn;
#else
    CGrafPtr port;
    RgnHandle rgn = NULL;

    port = GetWindowPort(window);
    GetPortVisibleRegion(port, rgn);
    
    return rgn;
#endif
}

RgnHandle spGetContentRegionMac(WindowPtr window)
{
#if !TARGET_API_MAC_CARBON
    return ((WindowPeek)window)->contRgn;
#else
    RgnHandle rgn = NULL;

    if (GetWindowRegion(window, kWindowContentRgn, rgn) != noErr) {
	return NULL;
    }
    
    return rgn;
#endif
}

BitMap *spGetPortBitMapMac(WindowPtr window)
{
#if !TARGET_API_MAC_CARBON
    return &window->portBits;
#else
    CGrafPtr port;

    port = GetWindowPort(window);
    return (BitMap *)GetPortBitMapForCopyBits(port);
#endif
}

void spGetPortRectMac(WindowPtr window, Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    *rect = window->portRect;
#else
    GetWindowPortBounds(window, rect);
#endif
    return;
}

void spGetControlRectMac(ControlRef control, Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    *rect = (*control)->contrlRect;
#else
    GetControlBounds(control, rect);
#endif
    return;
}

void spGetScreenBoundsMac(Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    *rect = qd.screenBits.bounds;
#else
    BitMap 	screenBits;
    
    *rect = GetQDGlobalsScreenBits(&screenBits)->bounds;
#endif
    return;
}

void spGetRegionBoundsMac(RgnHandle region, Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    *rect = (*region)->rgnBBox;
#else
    GetRegionBounds(region, rect);
#endif
    return;
}

void spValidRectMac(WindowRef window, Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    ValidRect(rect);
#else
    ValidWindowRect(window, rect);
#endif
    return;
}

void spInvalRectMac(WindowRef window, Rect *rect)
{
#if !TARGET_API_MAC_CARBON
    InvalRect(rect);
#else
    InvalWindowRect(window, rect);
#endif
    return;
}

void spHiliteControlMac(ControlRef control, spBool flag)
{
    spLockDrawMutexMac();
    HiliteControl(control, (flag == SP_TRUE ? 0 : 255));
    spUnlockDrawMutexMac();
    
    return;
}

Boolean spIsVisibleMac(spComponent component)
{
    spComponent parent;
    
    parent = component;
    while (parent != NULL) {
	if (spIsVisible(parent) == SP_FALSE
	    || (spIsPrimitive(parent) == SP_TRUE
		&& SpPrimitiveArch(parent).map_flag == SP_FALSE)) {
	    return false;
	}
	parent = SpGetParent(parent);
    }
    
    return true;
}

Boolean spIsSensitiveMac(spComponent component)
{
    spComponent parent;
    
    parent = component;
    while (parent != NULL) {
	if (spIsSensitive(parent) == SP_FALSE
	    || (spIsPrimitive(parent) == SP_TRUE
		&& SpPrimitiveArch(parent).sensitive_flag == SP_FALSE)) {
	    return false;
	}
	parent = SpGetParent(parent);
    }
    
    return true;
}

void spMapComponentFirstMac(spComponent component)
{
    if (spIsVisible(component) == SP_TRUE) {
	spLockDrawMutexMac();
	if (SpPrimitiveArch(component).map_flag == SP_TRUE) {
	    if (spIsSubClass(component, SpList) == SP_TRUE) {
		LSetDrawingMode(true, SpListArch(component).list);
	    }
	    if (SpPrimitiveArch(component).control != NULL) {
		ShowControl(SpPrimitiveArch(component).control);
		if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE) {
		    HiliteControl(SpPrimitiveArch(component).control, 255);
		}
	    }
	    if (spIsComboBox(component) == SP_TRUE) {
		if (SpComboBoxArch(component).button != NULL) {
		    ShowControl(SpComboBoxArch(component).button);
		    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE) {
			HiliteControl(SpComboBoxArch(component).button, 255);
		    }
		}
	    }
	}
	spUnlockDrawMutexMac();
    } else {
	if (SpPrimitiveArch(component).map_flag == SP_TRUE
	    && spIsContainer(component) == SP_TRUE) {
	    spUnmapContainerMac(component);
	}
    }
    
    return;
}

static spComponent sp_current_window = NULL;
static spComponent sp_current_menu_bar = NULL;
static spComponent sp_drag_window = NULL;
static spComponent sp_drag_component = NULL;

static int sp_current_menu_id = SP_INIT_MENU_ID;
static spBool sp_suspended = SP_FALSE;

spBool spGetComponentGeometryMac(spComponent component, int *x, int *y)
{
    int tx, ty;
    
    if (component == NULL || x == NULL || y == NULL) return SP_FALSE;

    component = SpGetParent(component);
    
    tx = *x; ty = *y;
    while (component != NULL && spIsWindow(component) == SP_FALSE) {
	tx += SpComponentPart(component).x;
	ty += SpComponentPart(component).y;

	component = SpGetParent(component);
    }
    *x = tx; *y = ty;

    return SP_TRUE;
}

void spSetComponentRectMac(spComponent component, int width, int height)
{
    int x, y;

    if (component == NULL) return;
    
    x = SpComponentPart(component).x;
    y = SpComponentPart(component).y;
    spGetComponentGeometryMac(component, &x, &y);
    SetRect(&SpPrimitiveArch(component).rect, x, y, x + width, y + height);
    
    return;
}

spComponent spGetWindowReferenceMac(WindowPtr window)
{
    long refcon;
    
    if (window == NULL || (refcon = GetWRefCon(window)) == 0L) {
	return NULL;
    }

    return (spComponent)refcon;
}

spComponent spGetControlReferenceMac(ControlRef control)
{
    long refcon;
    
    if (control == NULL || (refcon = GetControlReference(control)) == 0L) {
	return NULL;
    }

    return (spComponent)refcon;
}

void spSetReferenceMac(spComponent component)
{
    long refcon;

    if (component == NULL) {
	refcon = 0L;
    } else {
	refcon = (long)component;
    }
    if (SpPrimitiveArch(component).control != NULL) {
	SetControlReference(SpPrimitiveArch(component).control, refcon);
#if TARGET_API_MAC_CARBON
	if (spIsCarbonEventAvailableMac() == SP_TRUE) {
	    EventHandlerRef ehref;
	
	    SpPrimitiveArch(component).eventHandler = spNewControlEventHandlerUPP();

	    if (spIsText(component) == SP_TRUE || spIsList(component) == SP_TRUE) {
		EventTypeSpec list[] = {
		    { kEventClassControl, kEventControlHit },
		    { kEventClassControl, kEventControlDraw },
		    { kEventClassControl, kEventControlClick },
		    { kEventClassControl, kEventControlTrack },
		    { kEventClassControl, kEventControlActivate },
		    { kEventClassControl, kEventControlDeactivate },
		    { kEventClassControl, kEventControlSetFocusPart },
		    { kEventClassControl, kEventControlSetCursor },
		    { kEventClassControl, kEventControlBoundsChanged },
		    { kEventClassTextInput, kEventTextInputUnicodeForKeyEvent },
		    { kEventClassTextInput, kEventTextInputShowHideBottomWindow },
		    { kEventClassKeyboard, kEventRawKeyDown },
		    { kEventClassKeyboard, kEventRawKeyRepeat },
		    { kEventClassKeyboard, kEventRawKeyUp },
		};
		
		InstallEventHandler(GetControlEventTarget(SpPrimitiveArch(component).control),
				    SpPrimitiveArch(component).eventHandler,
				    spArraySize(list), list, (void *)component,
				    &ehref);
	    } else if (spIsSlider(component) == SP_TRUE) {
		EventTypeSpec list[] = {
		    { kEventClassControl, kEventControlHit },
		    { kEventClassControl, kEventControlDraw },
		    { kEventClassControl, kEventControlClick },
		    { kEventClassControl, kEventControlTrack },
		    { kEventClassControl, kEventControlActivate },
		    { kEventClassControl, kEventControlDeactivate },
		    { kEventClassControl, kEventControlIndicatorMoved },
		    { kEventClassControl, kEventControlGhostingFinished },
		    { kEventClassControl, kEventControlValueFieldChanged },
		    { kEventClassControl, kEventControlBoundsChanged },
		};
		
		InstallEventHandler(GetControlEventTarget(SpPrimitiveArch(component).control),
				    SpPrimitiveArch(component).eventHandler,
				    spArraySize(list), list, (void *)component,
				    &ehref);
	    } else {
		EventTypeSpec list[] = {
		    { kEventClassControl, kEventControlHit },
		    { kEventClassControl, kEventControlDraw },
		    { kEventClassControl, kEventControlClick },
		    { kEventClassControl, kEventControlTrack },
		    { kEventClassControl, kEventControlActivate },
		    { kEventClassControl, kEventControlDeactivate },
		    { kEventClassControl, kEventControlBoundsChanged },
		};
		
		InstallEventHandler(GetControlEventTarget(SpPrimitiveArch(component).control),
				    SpPrimitiveArch(component).eventHandler,
				    spArraySize(list), list, (void *)component,
				    &ehref);
	    }
	}
#endif
    } else if (SpPrimitiveArch(component).window != NULL){
	SetWRefCon(SpPrimitiveArch(component).window, refcon);
    }

    return;
}

void spSetNeedUpdateMac(spComponent component)
{
    spComponent window;
    spComponent next;

    if (component == NULL || (window = SpGetWindow(component)) == NULL) {
	return;
    }

    next = window;
    while (next != NULL) {
	if (SpPrimitiveArch(next).next_need_update == NULL) {
	    SpPrimitiveArch(next).next_need_update = component;
	    SpPrimitiveArch(component).prev_need_update = next;
	    break;
	}
	next = SpPrimitiveArch(next).next_need_update;
    }

    if (SpPrimitiveArch(window).map_flag == SP_TRUE) {
	SpPrimitiveArch(component).map_flag = spIsVisibleMac(component);
    }
    if (SpPrimitiveArch(window).sensitive_flag == SP_TRUE) {
	SpPrimitiveArch(component).sensitive_flag = spIsSensitiveMac(component);
    }
    
    return;
}

void spSetNeedMoveCallMac(spComponent component)
{
    spComponent window;
    spComponent next;

    if (component == NULL || (window = SpGetWindow(component)) == NULL) {
	return;
    }

    next = window;
    while (next != NULL) {
	if (SpPrimitiveArch(next).next_need_move_call == NULL) {
	    SpPrimitiveArch(next).next_need_move_call = component;
	    SpPrimitiveArch(component).prev_need_move_call = next;
	    break;
	}
	next = SpPrimitiveArch(next).next_need_move_call;
    }

    return;
}

void spSetKeySendComponentMac(spComponent component, spBool set_current)
{
    spComponent window;
    spComponent next;

    if (component == NULL || (window = SpGetWindow(component)) == NULL) {
	return;
    }
    if (set_current == SP_TRUE) {
	SpFrameArch(window).key_send_component = component;
    }

    next = window;
    while (next != NULL) {
	if (SpPrimitiveArch(next).next_key_send == NULL) {
	    SpPrimitiveArch(next).next_key_send = component;
	    SpPrimitiveArch(component).prev_key_send = next;
	    SpPrimitiveArch(window).prev_key_send = component; /* last key send */
	    break;
	}
	next = SpPrimitiveArch(next).next_key_send;
    }
    
    return;
}

spComponent spSearchWindowMac(WindowRef window)
{
    spComponent first;
    spComponent next;

    if (window == NULL) return NULL;

    first = spGetChild(NULL);
    next = first;

    while (next != NULL) {
	if (spIsPrimitive(next) == SP_TRUE
	    && SpPrimitiveArch(next).window == window) {
	    return next;
	}
	next = spGetNextWindow(next, SP_TRUE);

	if (next == first) {
	    break;
	}
    }

    return NULL;
}

int spUseCurrentMenuIdMac(void)
{
    int menu_id;

    menu_id = sp_current_menu_id;
    sp_current_menu_id++;
    if (sp_current_menu_id == SP_WINDOW_MENU_ID) {
	sp_current_menu_id++;
    }
    
    return menu_id;
}

spBool spPostMessageMac(spComponent component, spCallbackType call_type,
			spCallbackReason reason)
{
    long k;
    long component_id;
    long num_callback;
    spBool flag = SP_FALSE;

    if (component == NULL || call_type == SP_NO_CALLBACK) {
	return SP_FALSE;
    }
    
    spDebug(50, "spPostMessageMac", "reason = %d\n", reason);
    
    SpPrimitiveArch(component).reason = reason;
    
    if ((component_id = SpGetComponentId(component)) == spGetDestroyedComponentId()) {
	/* now destroying */
	component_id = 0;
    }
    num_callback = SpPrimitivePart(component).num_callback;
    
    for (k = 0; k < num_callback; k++) {
	if (SpPrimitivePart(component).callbacks[k].call_type & call_type) {
	    spComponentCallbackFunc(&SpPrimitivePart(component).callbacks[k]);
	    flag = SP_TRUE;

	    if (component_id == spGetDestroyedComponentId()) {
		return flag;
	    }
	}
    }
    spDebug(50, "spPostMessageMac", "flag = %d\n", flag);
    
    SpPrimitiveArch(component).event.what = nullEvent;
    SpPrimitiveArch(component).reason = SP_CR_NONE;
    
    return flag;
}

void spUnsetCurrentWindowMac(spComponent window)
{
    if (window == sp_current_window) {
	sp_current_window = NULL;
    }
    
    return;
}

void spSetCurrentWindowMac(spComponent window)
{
    if (sp_current_window != window) {
	sp_current_window = window;
    }
    
    return;
}

spComponent spGetCurrentWindowMac(void)
{
    return sp_current_window;
}

spComponent spGetCurrentMenuBarMac(void)
{
    return sp_current_menu_bar;
}

spBool spIsSuspendedMac(void)
{
    return sp_suspended;
}

void spSetSuspendStateMac(spBool suspended)
{
    sp_suspended = suspended;
    return;
}

int spGetNumHelpMenuItemMac(void)
{
    return SpTopLevelArch(sp_toplevel).num_help_menu;
}

static void clearHelpMenu(spComponent menu_bar)
{
    int i;
    int current_num_menu;

    current_num_menu = CountMenuItems(SpTopLevelArch(sp_toplevel).help_menu);
    
    for (i = SpTopLevelArch(sp_toplevel).num_help_menu + 1; i <= current_num_menu; i++) {
	DeleteMenuItem(SpTopLevelArch(sp_toplevel).help_menu, i);
    }

    return;
}

static void clearAllMenu(spComponent component)
{
    spComponent child;
    
    child = SpGetChild(component);
    while (child != NULL) {
	clearAllMenu(child);
	if (spIsMenu(child) == SP_TRUE
	    && SpMenuPart(child).help_flag == SP_FALSE
	    && SpPrimitiveArch(child).menu_id > 0) {
	    DeleteMenu(SpPrimitiveArch(child).menu_id);
	}

	child = SpGetNextComponent(child);
    }

    return;
}

static void clearMenuBar(spComponent window)
{
    spComponent menu_bar = NULL;
    
    if (spIsFrame(window) == SP_TRUE) {
	menu_bar = SpFramePart(window).menu_bar;
    }

    if (menu_bar == NULL) {
	DeleteMenu(SP_FILE_MENU_ID);
	DeleteMenu(SP_EDIT_MENU_ID);
    } else {
	clearHelpMenu(menu_bar);
	clearAllMenu(window);
    }
    
    return;
}

void spInsertAllMenuMac(spComponent parent)
{
    spComponent child;
    
    child = SpGetChild(parent);
    
    while (child != NULL) {
	spInsertAllMenuMac(child);
	
	if (spIsMenu(child) == SP_TRUE) {
	    if (spIsMenuBar(parent) == SP_TRUE) {
		if (SpPrimitiveArch(child).menu != NULL
		    && SpMenuPart(child).help_flag == SP_FALSE) {
#if TARGET_API_MAC_CARBON
		    if (SpTopLevelArch(sp_toplevel).window_menu != NULL) {
			InsertMenu(SpPrimitiveArch(child).menu, SP_WINDOW_MENU_ID);
		    } else {
			InsertMenu(SpPrimitiveArch(child).menu, 0);
		    }
#else
		    InsertMenu(SpPrimitiveArch(child).menu, 0);
#endif
		}
	    } else {
		if (SpParentMenuPart(child).help_flag == SP_TRUE) {
		    SpPrimitiveArch(child).map_flag = SP_FALSE;
		    spMapMenuItemMac(child);
		}
		if (SpPrimitiveArch(child).menu != NULL) {
		    InsertMenu(SpPrimitiveArch(child).menu, -1);
		}
	    }
	} else if (spIsMenuItem(child) == SP_TRUE &&
		   SpParentMenuPart(child).help_flag == SP_TRUE) {
	    SpPrimitiveArch(child).map_flag = SP_FALSE;
	    spMapMenuItemMac(child);
	}
	
	child = SpGetNextComponent(child);
    }

    spDebug(30, "spInsertAllMenuMac", "done: %s\n", spGetTitle(parent));
    
    return;
}

static void changeQuitMenuState(spBool flag)
{
#if TARGET_API_MAC_CARBON
    if (spIsAquaMac() == SP_TRUE) {
	spDebug(50, "spChangeQuitMenuStateMac", "quit menu sensitive: %d\n", flag);
	if (flag == SP_TRUE) {
	    EnableMenuCommand(GetMenuRef(128), 'quit');
	} else {
	    DisableMenuCommand(GetMenuRef(128), 'quit');
	}
    }
#endif
    
    if (spIsAquaMac() == SP_FALSE && sp_current_menu_bar == NULL) {
	if (flag == SP_TRUE) {
	    EnableMenuItem(SpTopLevelArch(sp_toplevel).file_menu, SP_QUIT_MENU_ITEM_ID);
	} else {
	    DisableMenuItem(SpTopLevelArch(sp_toplevel).file_menu, SP_QUIT_MENU_ITEM_ID);
	}
    }
    
    return;
}

void spChangeQuitMenuStateMac(spBool flag)
{
    spLockMenuMutexMac();
    changeQuitMenuState(flag);
    spUnlockMenuMutexMac();
    
    return;
}

static void changeEditMenuState(spComponent component)
{
    spComponent text;
    TEHandle te;
    
    if (sp_current_menu_bar != NULL) return;
    
    if (spIsFrame(component) == SP_TRUE
	&& spIsText(SpFrameArch(component).key_send_component) == SP_TRUE
	&& SpTextPart(SpFrameArch(component).key_send_component).editable == SP_TRUE) {
	text = SpFrameArch(component).key_send_component;
	te = SpTextArch(text).text;

	if ((*te)->selStart < (*te)->selEnd) {
	    EnableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_CUT_MENU_ITEM_ID);
	    EnableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_COPY_MENU_ITEM_ID);
	    EnableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_DELETE_MENU_ITEM_ID);
	} else {
	    DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_CUT_MENU_ITEM_ID);
	    DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_COPY_MENU_ITEM_ID);
	    DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_DELETE_MENU_ITEM_ID);
	}
	if (TEGetScrapLength() > 0) {
	    EnableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_PASTE_MENU_ITEM_ID);
	} else {
	    DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_PASTE_MENU_ITEM_ID);
	}
	EnableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_SELECT_ALL_MENU_ITEM_ID);
    } else {
	DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_CUT_MENU_ITEM_ID);
	DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_COPY_MENU_ITEM_ID);
	DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_PASTE_MENU_ITEM_ID);
	DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_DELETE_MENU_ITEM_ID);
	DisableMenuItem(SpTopLevelArch(sp_toplevel).edit_menu, SP_SELECT_ALL_MENU_ITEM_ID);
    }
    
    return;
}

void spChangeEditMenuStateMac(spComponent component)
{
    spLockMenuMutexMac();
    changeEditMenuState(component);
    spUnlockMenuMutexMac();
    
    return;
}

spComponent spSelectMenuBarMac(spComponent component, spComponent avoid)
{
    int before_id;
    spComponent next, prev;
    
    if (component == NULL) {
	if ((component = spGetWindowReferenceMac(FrontWindow())) == NULL) {
	    component = spGetChild(NULL);
	    
	    next = component;
	    while (next != NULL) {
		if (spIsWindow(next) == SP_TRUE
		    && spIsVisible(next) == SP_TRUE) {
		    break;
		}

		next = SpGetNextComponent(next);
	    }
	    component = next;
	}
    }
    if (component == avoid
	|| (spIsPrimitive(component) == SP_TRUE && SpPrimitiveArch(component).map_flag == SP_FALSE)) {
	component = NULL;
    }
    
    if (component != NULL && sp_current_window == component) {
	return NULL;
    }

    prev = sp_current_window;
    spLockMenuMutexMac();
    clearMenuBar(sp_current_window);
    spUnlockMenuMutexMac();
    
    if (spIsFrame(component) == SP_TRUE) {
	sp_current_menu_bar = SpFramePart(component).menu_bar;
	if (FrontWindow() != SpPrimitiveArch(component).window) {
	    SelectWindow(SpPrimitiveArch(component).window);
	}
    } else {
	sp_current_menu_bar = NULL;
    }
    sp_drag_window = NULL;
    sp_drag_component = NULL;
    
    spLockMenuMutexMac();
    
    if (strnone(SpTopLevelPart(sp_toplevel).information)) {
	DisableMenuItem(SpTopLevelArch(sp_toplevel).apple_menu, SP_ABOUT_MENU_ITEM_ID);
    } else {
	EnableMenuItem(SpTopLevelArch(sp_toplevel).apple_menu, SP_ABOUT_MENU_ITEM_ID);
    }
	
    if (sp_current_menu_bar == NULL) {
#if TARGET_API_MAC_CARBON
	if (SpTopLevelArch(sp_toplevel).window_menu != NULL) {
	    before_id = SP_WINDOW_MENU_ID;
	    spDebug(30, "spSelectMenuBarMac", "window menu id = %d\n", before_id);
	} else {
	    before_id = 0;
	}
	spDebug(30, "spSelectMenuBarMac", "before_id = %d\n", before_id);
#else
	before_id = 0;
#endif
	InsertMenu(SpTopLevelArch(sp_toplevel).file_menu, before_id);
	InsertMenu(SpTopLevelArch(sp_toplevel).edit_menu, before_id);
	
	if (spIsFrame(component) == SP_TRUE) {
	    if (SpFramePart(component).close_style == SP_NO_CLOSE
		|| spIsDialog(component) == SP_TRUE
		|| spIsLastWindow(component) == SP_TRUE) {
		DisableMenuItem(SpTopLevelArch(sp_toplevel).file_menu, SP_CLOSE_MENU_ITEM_ID);
	    } else {
		EnableMenuItem(SpTopLevelArch(sp_toplevel).file_menu, SP_CLOSE_MENU_ITEM_ID);
	    }
	    if (spIsLastWindow(component) == SP_TRUE
		/*&& SpFramePart(component).close_style == SP_NO_CLOSE*/) {
		changeQuitMenuState(SP_TRUE);
	    } else {
		changeQuitMenuState(SP_FALSE);
	    }
	} else {
	    changeQuitMenuState(SP_FALSE);
	}
	changeEditMenuState(component);
    } else {
	spInsertAllMenuMac(component);
    
	if (spIsFrame(component) == SP_TRUE && SpFrameArch(component).quit_menu_item != NULL) {
	    changeQuitMenuState(spIsSensitive(SpFrameArch(component).quit_menu_item));
	}
    }

    spSetCurrentWindowMac(component);
    DrawMenuBar();

    spUnlockMenuMutexMac();
    
    spDebug(30, "spSelectMenuBarMac", "menu bar selected\n");
    
    return prev;
}

void spDrawGrowIconMac(WindowPtr window)
{
    Rect rect, clip_rect;
    RgnHandle orig_rgn;
    GrafPtr save_port;
    spComponent component;

    component = spGetWindowReferenceMac(window);
    if (spIsFrame(component) == SP_TRUE
	&& SpFramePart(component).window_type == SP_TRANSIENT_WINDOW) {
	return;
    }

    spGetPortRectMac(window, &rect);
    
    clip_rect.right = rect.right;
    clip_rect.bottom = rect.bottom;
    clip_rect.top = clip_rect.bottom - (SP_SIZE_BOX_SIZE - 1);
    clip_rect.left = clip_rect.right - (SP_SIZE_BOX_SIZE - 1);
    
    /* store original region */
    spLockWindowPort(window, &save_port);
    orig_rgn = NewRgn();
    GetClip(orig_rgn);
    
    /* draw size box */
    ClipRect(&clip_rect);
    DrawGrowIcon(window);

    /* restore original region */
    SetClip(orig_rgn);
    DisposeRgn(orig_rgn);
    spUnlockWindowPort(window, save_port);
	 
    return;
}

void spDrawControlInWindowPortMac(ControlRef control, WindowRef window)
{
    if (control != NULL) {
	Draw1Control(control);
    }
    
    return;
}

void spDrawControlMac(spComponent component)
{
    ControlRef control = NULL;
    
    if (spIsComboBox(component) == SP_TRUE) {
	if (SpComboBoxArch(component).button != NULL) {
	    control = SpComboBoxArch(component).button;
	}
    } else if (spIsText(component) == SP_TRUE || spIsList(component) == SP_TRUE) {
	/* do nothing */
    } else if (SpPrimitiveArch(component).control != NULL) {
	control = SpPrimitiveArch(component).control;
    }

    spDrawControlInWindowPortMac(control, SpPrimitiveArch(SpGetWindow(component)).window);
    
    return;
}

void spDrawComponentMac(spComponent component, spBool update)
{
    if (spIsVisible(component) == SP_TRUE) {
	spComponent window;

	window = SpGetWindow(component);
	
	if (SpPrimitiveArch(component).map_flag == SP_TRUE
	    && SpComponentPart(component).current_width > 0 && SpComponentPart(component).current_height > 0) {
	    spDebug(50, "spDrawComponentMac", "%s: draw\n", SpGetClassName(component));
	    if (spIsToolItem(component) == SP_TRUE) {
		if (spIsToggleButton(component) == SP_TRUE) {
		    if (SpToolItemPart(component).set == SP_TRUE) {
			HiliteControl(SpPrimitiveArch(component).control, kControlButtonPart);
		    } else {
			HiliteControl(SpPrimitiveArch(component).control, 0);
		    }
		}
		
		spDrawControlMac(component);
		if (spIsCarbonEventAvailableMac() == SP_FALSE) {
		    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
			|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
			spDrawToolItemMac(component, SP_FALSE);
		    } else {
			spDrawToolItemMac(component, SP_TRUE);
		    }
		}
	    } else if (spIsButton(component) == SP_TRUE) {
		spDrawButtonMac(component);
	    } else if (spIsToolBar(component) == SP_TRUE) {
		spDrawToolBarMac(component, SP_TRUE);		
	    } else if (spIsStatusBar(component) == SP_TRUE) {
		spDrawStatusBarMac(component);
	    } else if (spEqClass(component, SpLabel) == SP_TRUE) {
		spDrawLabelMac(component);
	    } else if (spIsCanvas(component) == SP_TRUE) {
		spDrawCanvasMac(component);
		if (SpPrimitiveArch(window).map_flag == SP_TRUE) {
		    spDebug(50, "spDrawComponentMac", "expose canvas\n");
		    spPostMessageMac(component, SP_EXPOSE_CALLBACK, SP_CR_EXPOSE);
		}
	    } else if (spIsTabBox(component) == SP_TRUE) {
		spDrawTabBoxMac(component, SP_TRUE);
	    } else if (spIsSubClass(component, SpList) == SP_TRUE) {
		spDrawListMac(component, update);
	    } else if (spIsSlider(component) == SP_TRUE) {
		spDrawSliderMac(component);
	    } else if (spIsSubClass(component, SpContainer) == SP_TRUE) {
		spDrawContainerMac(component);
	    }
	}
    }
    
    return;
}

void spUpdateComponentMac(spComponent component)
{
    spComponent next;
    
    spDebug(50, "spUpdateComponentMac", "in\n");
    
    if (SpPrimitiveArch(component).next_need_update != NULL) {
	next = SpPrimitiveArch(component).next_need_update;
	while (next != NULL) {
	    spDrawComponentMac(next, SP_TRUE);
	    next = SpPrimitiveArch(next).next_need_update;
	}
    }
    spDebug(50, "spUpdateComponentMac", "done\n");

    return;
}

void spUpdateWindowMac(spComponent component)
{
    Rect rect;
    
    if (spIsFrame(component) == SP_TRUE) {
	if (SpFrameArch(component).draw_func != NULL) {
	    spGetPortRectMac(SpPrimitiveArch(component).window, &rect);
	    
	    SpFrameArch(component).draw_func(SpFrameArch(component).data, 0, 0,
					     spGetRectWidthMac(rect), spGetRectHeightMac(rect));
	}
	
	spUpdateComponentMac(component);
	spUpdateTextMac(component);

	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    spDrawGrowIconMac(SpPrimitiveArch(component).window);
	}
    }
    spDebug(50, "spUpdateWindowMac", "done\n");
    
    return;
}

void spInitCallbackArch(spCallback *callback)
{
    callback->component = NULL;
    callback->call_func = NULL;
    callback->call_data = NULL;
    callback->propagate = SP_FALSE;

    return;
}

static spCallbackType getCallbackType(spComponent component, spCallbackType call_type, int *count)
{
    int i;
    int num_call_type = SP_NUM_CALLBACK_TYPE;
    spCallbackType current_type = SP_NO_CALLBACK;

    if (call_type == SP_NO_CALLBACK) return SP_NO_CALLBACK;

    if (*count < num_call_type) {
	for (i = *count; i < num_call_type; i++) {
	    if (((spCallbackType)(1L << i)) & call_type) {
		*count = i + 1;
		current_type = (spCallbackType)(1L << i);
		break;
	    }
	}
	if (i >= num_call_type) {
	    *count = num_call_type;
	}
    }

    return current_type;
}

static spBool addCallback(spComponent component, spBool propagate, spCallbackType call_type,
			  spCallbackFunc call_func, void *call_data)
{
    long k;
    spBool flag = SP_FALSE;
    
    if (spIsPrimitive(component) == SP_TRUE && call_type != SP_NO_CALLBACK &&
	call_func != NULL) {
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data &&
		SpPrimitivePart(component).callbacks[k].call_type == call_type) {
		return SP_FALSE;
	    } else if (SpPrimitivePart(component).callbacks[k].call_func == NULL) {
		break;
	    }
	}
	
	if (k >= SpPrimitivePart(component).num_callback) {
	    spAllocCallbacks(component);
	    SpPrimitivePart(component).num_callback++;
	}
	
	SpPrimitivePart(component).callbacks[k].component = component;
	SpPrimitivePart(component).callbacks[k].call_func = call_func;
	SpPrimitivePart(component).callbacks[k].call_data = call_data;
	SpPrimitivePart(component).callbacks[k].propagate = propagate;
	SpPrimitivePart(component).callbacks[k].call_type = call_type;
    }

    return flag;
}

spBool spPrimitiveAddCallbackArch(spComponent component, spBool propagate, spCallbackType call_type,
				  spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    spCallbackType current_type;
    
    while ((current_type = getCallbackType(component, call_type, &count)) != SP_NO_CALLBACK) {
	if (addCallback(component, propagate, current_type, call_func, call_data) == SP_TRUE) {
	    flag = SP_TRUE;
	}
    }

    return flag;
}

static spBool removeCallback(spComponent component, spCallbackType call_type,
			     spCallbackFunc call_func, void *call_data)
{
    long k;
    spBool flag = SP_FALSE;
    
    if (call_type != SP_NO_CALLBACK && call_func != NULL) {
	for (k = 0; k < SpPrimitivePart(component).num_callback; k++) {
	    if (SpPrimitivePart(component).callbacks[k].component == component &&
		SpPrimitivePart(component).callbacks[k].call_func == call_func &&
		SpPrimitivePart(component).callbacks[k].call_data == call_data &&
		SpPrimitivePart(component).callbacks[k].call_type == call_type) {
		SpPrimitivePart(component).callbacks[k].component = NULL;
		SpPrimitivePart(component).callbacks[k].call_func = NULL;
		SpPrimitivePart(component).callbacks[k].call_data = NULL;
		SpPrimitivePart(component).callbacks[k].propagate = SP_FALSE;
		SpPrimitivePart(component).callbacks[k].call_type = SP_NO_CALLBACK;
		flag = SP_TRUE;
		break;
	    }
	}
    }

    return flag;
}

spBool spPrimitiveRemoveCallbackArch(spComponent component, spCallbackType call_type,
				     spCallbackFunc call_func, void *call_data)
{
    int count = 0;
    spBool flag = SP_FALSE;
    spCallbackType current_type;
    
    while ((current_type = getCallbackType(component, call_type, &count)) != SP_NO_CALLBACK) {
	if (removeCallback(component, current_type, call_func, call_data) == SP_TRUE) {
	    flag = SP_TRUE;
	}
    }

    return flag;
}

spCallbackReason spPrimitiveGetCallbackReasonArch(spComponent component)
{
    return SpPrimitiveArch(component).reason;
}

spBool spPrimitiveGetCallbackMousePositionArch(spComponent component, int *x, int *y)
{
    Point point;
    GrafPtr save_port;
    spCallbackReason reason;

    reason = spGetCallbackReason(component);
    if (SpPrimitiveArch(component).reason == SP_CR_POINTER_MOTION
	|| SpPrimitiveArch(component).reason == SP_CR_LBUTTON_MOTION
	|| SpPrimitiveArch(component).reason == SP_CR_MBUTTON_MOTION
	|| SpPrimitiveArch(component).reason == SP_CR_RBUTTON_MOTION
	|| SpPrimitiveArch(component).reason == SP_CR_LBUTTON_PRESS
	|| SpPrimitiveArch(component).reason == SP_CR_MBUTTON_PRESS
	|| SpPrimitiveArch(component).reason == SP_CR_RBUTTON_PRESS
	|| SpPrimitiveArch(component).reason == SP_CR_LBUTTON_RELEASE
	|| SpPrimitiveArch(component).reason == SP_CR_MBUTTON_RELEASE
	|| SpPrimitiveArch(component).reason == SP_CR_RBUTTON_RELEASE) {
	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	GetMouse(&point);
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	
	if (x != NULL) {
	    *x = point.h - SpPrimitiveArch(component).rect.left;
	}
	if (y != NULL) {
	    *y = point.v - SpPrimitiveArch(component).rect.top;
	}
    
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spKeySym convertKeySym(unsigned long message, short modifiers)
{
    int char_code;

    char_code = (int)(charCodeMask & message);
    
    spDebug(50, "convertKeySym", "char_code = %c, %d\n", char_code, char_code);
    if (isprint(char_code)) {
	return SPK_Character;
    } else {
	switch ((char_code)) {
	  case kHomeCharCode:
	    return SPK_Home;
#if 0
	  case kEnterCharCode:
	    break;
#endif
	  case kEndCharCode:
	    return SPK_End;	    
	  case kHelpCharCode:
	    return SPK_Help;
#if 0
	  case kBellCharCode:
	    break;
#endif
	  case kBackspaceCharCode:
	    return SPK_BackSpace;
	  case kTabCharCode:
	    return SPK_Tab;
	  case kLineFeedCharCode:
	    return SPK_Linefeed;
	  /*case kVerticalTabCharCode:*/
	  case kPageUpCharCode:
	    return SPK_Prior;
	  /*case kFormFeedCharCode:*/
	  case kPageDownCharCode:
	    return SPK_Next;
	  case kReturnCharCode:
	    return SPK_Return;

#if 0
	  case kFunctionKeyCharCode:
	    break;
#endif
	  case kEscapeCharCode:
	    return SPK_Escape;
#if 0
	  case kClearCharCode:
	    return SPK_Clear;
#endif
	  case kLeftArrowCharCode:
	    return SPK_Left;
	  case kRightArrowCharCode:
	    return SPK_Right;
	  case kUpArrowCharCode:
	    return SPK_Up;
	  case kDownArrowCharCode:
	    return SPK_Down;
	  case kDeleteCharCode:
	    return SPK_Delete;

#if 0
	  case VK_PAUSE:        
	    return SPK_Pause;
	  case VK_SCROLL:
	    return SPK_ScrollLock;
	  case VK_SELECT:       
	    return SPK_Select;
	  case VK_PRINT:        
	    return SPK_Print;
	  case VK_EXECUTE:      
	    return SPK_Execute;
	  case VK_INSERT:       
	    return SPK_Insert;
	  case VK_CANCEL:         
	    return SPK_Cancel;
	  case VK_NUMLOCK:      
	    return SPK_NumLock;
	    
	  case VK_F1:           
	    return SPK_F1;
	  case VK_F2:           
	    return SPK_F2;
	  case VK_F3:           
	    return SPK_F3;
	  case VK_F4:           
	    return SPK_F4;
	  case VK_F5:           
	    return SPK_F5;
	  case VK_F6:           
	    return SPK_F6;
	  case VK_F7:           
	    return SPK_F7;
	  case VK_F8:           
	    return SPK_F8;
	  case VK_F9:           
	    return SPK_F9;
	  case VK_F10:          
	    return SPK_F10;
	  case VK_F11:          
	    return SPK_F11;
	  case VK_F12:         
	    return SPK_F12;
	  case VK_F13:          
	    return SPK_F13;
	  case VK_F14:          
	    return SPK_F14;
	  case VK_F15:          
	    return SPK_F15;
	  case VK_F16:          
	    return SPK_F16;
	  case VK_F17:          
	    return SPK_F17;
	  case VK_F18:          
	    return SPK_F18;
	  case VK_F19:          
	    return SPK_F19;
	  case VK_F20:          
	    return SPK_F20;
	  case VK_F21:          
	    return SPK_F21;
	  case VK_F22:          
	    return SPK_F22;
	  case VK_F23:          
	    return SPK_F23;
	  case VK_F24:          
	    return SPK_F24;
#endif
	  default:
	    break;
	}
    }

    if ((cmdKey & modifiers) != 0) {
	return SPK_Alt;
    } else if ((alphaLock & modifiers) != 0) {
	return SPK_CapsLock;
    } else if ((controlKey & modifiers) != 0 || (rightControlKey & modifiers)) {
	return SPK_Control;
    } else if ((shiftKey & modifiers) != 0 || (rightShiftKey & modifiers) != 0) {
	return SPK_Shift;
    }

    return SPK_Unknown;
}

spBool spPrimitiveGetCallbackKeySymArch(spComponent component, spKeySym *key_sym)
{
    if (SpPrimitiveArch(component).event.what == keyDown
	|| SpPrimitiveArch(component).event.what == autoKey
	|| SpPrimitiveArch(component).event.what == keyUp) {
	*key_sym = convertKeySym(SpPrimitiveArch(component).event.message,
				 SpPrimitiveArch(component).event.modifiers);
	spDebug(50, "spPrimitiveGetCallbackKeySymArch", "key_sym = %d\n", key_sym);
	return SP_TRUE;
    }
    
    return SP_FALSE;
}

int spPrimitiveGetCallbackKeyStringArch(spComponent component,
					char *buf, int buf_size, spBool *overflow)
{
    spKeySym key_sym;

    if (spPrimitiveGetCallbackKeySymArch(component, &key_sym) == SP_TRUE) {
	if (key_sym == SPK_Character) {
	    buf[0] = (char)(charCodeMask & SpPrimitiveArch(component).event.message);
	    spDebug(50, "spPrimitiveGetCallbackKeyStringArch", "char = %c\n", buf[0]);
	    if (buf_size >= 2) {
		if (overflow != NULL) *overflow = SP_FALSE;
		buf[1] = NUL;
	    } else {
		if (overflow != NULL) *overflow = SP_TRUE;
	    }

	    return 1;
	}
    }
    
    return -1;
}

void spPrimitivePartInitArch(spComponent component)
{
    SpPrimitiveArch(component).window = NULL;
    SpPrimitiveArch(component).control = NULL;
    SpPrimitiveArch(component).sub_control = NULL;
    SpPrimitiveArch(component).gworld = NULL;
    SpPrimitiveArch(component).menu = NULL;
    SpPrimitiveArch(component).event.what = nullEvent;    
    SpPrimitiveArch(component).rect.left = 0;
    SpPrimitiveArch(component).rect.right = 0;
    SpPrimitiveArch(component).rect.top = 0;
    SpPrimitiveArch(component).rect.bottom = 0;
    SpPrimitiveArch(component).region = NULL;
#if TARGET_API_MAC_CARBON
    SpPrimitiveArch(component).eventHandler = NULL;
#endif
    
    SpPrimitiveArch(component).menu_id = 0;
    SpPrimitiveArch(component).reason = SP_CR_NONE;
    SpPrimitiveArch(component).map_flag = /*SP_TRUE*/spIsVisible(component);
    SpPrimitiveArch(component).sensitive_flag = SP_TRUE;
    SpPrimitiveArch(component).cursor_type = SP_CURSOR_UNKNOWN;
    SpPrimitiveArch(component).popup_menu = NULL;
    SpPrimitiveArch(component).next_need_update = NULL;
    SpPrimitiveArch(component).prev_need_update = NULL;
    SpPrimitiveArch(component).next_need_move_call = NULL;
    SpPrimitiveArch(component).prev_need_move_call = NULL;
    SpPrimitiveArch(component).next_key_send = NULL;
    SpPrimitiveArch(component).prev_key_send = NULL;

    return;
}

void spPrimitiveDestroyArch(spComponent component)
{
    spComponent window;
    spComponent temp;

    spDebug(80, "spPrimitiveDestroyArch", "in\n");
    
    window = SpGetWindow(component);
    if (SpFrameArch(window).key_send_component == component) {
	SpFrameArch(window).key_send_component = NULL;
	if (spIsText(component) == SP_TRUE) {
	    if (spDeactivateTextMac(component, SP_FALSE) == SP_TRUE) {
		spTEToScrapMac();
	    }
	    spChangeEditMenuStateMac(window);
	}
    }
    
    if (spIsMenuItem(component) == SP_TRUE
	|| spIsSubMenu(component) == SP_TRUE) {
	if (SpFrameArch(SpGetWindow(component)).quit_menu_item == component) {
	    SpFrameArch(SpGetWindow(component)).quit_menu_item = NULL;
	}
	spUnmapMenuItemMac(component);
    } else if (SpPrimitiveArch(component).control != NULL) {
	DisposeControl(SpPrimitiveArch(component).control);
    } else if (SpPrimitiveArch(component).window != NULL) {
	SetWRefCon(SpPrimitiveArch(component).window, 0);
	KillControls(SpPrimitiveArch(component).window);
	DisposeWindow(SpPrimitiveArch(component).window);
    } else if (spIsSubClass(component, SpList) == SP_TRUE) {
	LDispose(SpListArch(component).list);
    }
    
    if (SpPrimitiveArch(component).sub_control != NULL) {
	DisposeControl(SpPrimitiveArch(component).sub_control);
    }
    if (spIsComboBox(component) == SP_TRUE
	&& SpComboBoxArch(component).button != NULL) {
	DisposeControl(SpComboBoxArch(component).button);
    }
    if (SpPrimitiveArch(component).menu != NULL
	&& SpMenuPart(component).help_flag != SP_TRUE) {
	DisposeMenu(SpPrimitiveArch(component).menu);
    }
    if (SpPrimitiveArch(component).region != NULL) {
	DisposeRgn(SpPrimitiveArch(component).region);
    }
    
    if ((temp = SpPrimitiveArch(component).next_need_update) != NULL) {
	SpPrimitiveArch(temp).prev_need_update
	    = SpPrimitiveArch(component).prev_need_update;
    }
    if ((temp = SpPrimitiveArch(component).prev_need_update) != NULL) {
	SpPrimitiveArch(temp).next_need_update
	    = SpPrimitiveArch(component).next_need_update;
    }
    if ((temp = SpPrimitiveArch(component).next_need_move_call) != NULL) {
	SpPrimitiveArch(temp).prev_need_move_call
	    = SpPrimitiveArch(component).prev_need_move_call;
    }
    if ((temp = SpPrimitiveArch(component).prev_need_move_call) != NULL) {
	SpPrimitiveArch(temp).next_need_move_call
	    = SpPrimitiveArch(component).next_need_move_call;
    }
    if ((temp = SpPrimitiveArch(component).next_key_send) != NULL) {
	SpPrimitiveArch(temp).prev_key_send
	    = SpPrimitiveArch(component).prev_key_send;
    }
    if ((temp = SpPrimitiveArch(component).prev_key_send) != NULL) {
	SpPrimitiveArch(temp).next_key_send
	    = SpPrimitiveArch(component).next_key_send;
    }

    if (component == sp_current_menu_bar) {
	spSelectMenuBarMac(NULL, component);
    } else {
	spUnsetCurrentWindowMac(component);
    }

#if TARGET_API_MAC_CARBON
    if (SpPrimitiveArch(component).eventHandler != NULL) {
	DisposeEventHandlerUPP(SpPrimitiveArch(component).eventHandler);
    }
#endif
    
    if (spIsSubClass(component, SpMainFrame) == SP_TRUE) {
	spQuit(0);
    }
    
    spDebug(80, "spPrimitiveDestroyArch", "done\n");
    
    return;
}

void spPrimitiveMapArch(spComponent component)
{
    spDebug(80, "spPrimitiveMapArch", "%s: map_flag = %d, (%d, %d), (%d, %d)\n",
	    spGetTitle(component), SpPrimitiveArch(component).map_flag,
	    SpComponentPart(component).x, SpComponentPart(component).y,
	    SpPrimitiveArch(component).rect.left,
	    SpPrimitiveArch(component).rect.top);
    
    if (SpPrimitiveArch(component).map_flag == SP_FALSE) {
	spLockDrawMutexMac();
    
	if (spIsMenuItem(component) == SP_TRUE
	    || spIsSubMenu(component) == SP_TRUE) {
	    spMapMenuItemMac(component);
	} else if (SpPrimitiveArch(component).window != NULL) {
	    ShowWindow(SpPrimitiveArch(component).window);
	} else if (spIsSubClass(component, SpList) == SP_TRUE) {
	    LSetDrawingMode(true, SpListArch(component).list);
	    if (SpPrimitiveArch(component).control != NULL) {
		ShowControl(SpPrimitiveArch(component).control);
	    }
	} else if (SpPrimitiveArch(component).control != NULL) {
	    spDebug(80, "spPrimitiveMapArch", "show control of %s\n", spGetTitle(component));
	    ShowControl(SpPrimitiveArch(component).control);
	}
	if (spIsComboBox(component) == SP_TRUE
	    && SpComboBoxArch(component).button != NULL) {
	    ShowControl(SpComboBoxArch(component).button);
	}

	spUnlockDrawMutexMac();
	
	if (spIsContainer(component) == SP_TRUE) {
	    spMapContainerMac(component);
	}
	SpPrimitiveArch(component).map_flag = SP_TRUE;
    }
    
    if (spIsStatusBar(component) == SP_TRUE) {
#if 0
	spComponent window;
    
	window = SpGetWindow(component);
	spDrawStatusBarMac(component);
	if (SpFramePart(window).resize_flag == SP_TRUE) {
	    spDrawGrowIconMac(SpPrimitiveArch(window).window);
	}
#endif
    } else {
	spPrimitiveSetSensitiveArch(component, SpPrimitiveArch(component).sensitive_flag);
    }
    
    return;
}

void spPrimitiveUnmapArch(spComponent component)
{
    spComponent window;
    
    if (SpPrimitiveArch(component).map_flag == SP_TRUE) {
	spLockDrawMutexMac();
    
	if (spIsMenuItem(component) == SP_TRUE
	    || spIsSubMenu(component) == SP_TRUE) {
	    spUnmapMenuItemMac(component);
	} else if (SpPrimitiveArch(component).window != NULL) {
	    HideWindow(SpPrimitiveArch(component).window);
	} else if (spIsSubClass(component, SpList) == SP_TRUE) {
	    LSetDrawingMode(false, SpListArch(component).list);
	    if (SpPrimitiveArch(component).control != NULL) {
		HideControl(SpPrimitiveArch(component).control);
	    }
	} else if (SpPrimitiveArch(component).control != NULL) {
	    HideControl(SpPrimitiveArch(component).control);
	}
	if (spIsComboBox(component) == SP_TRUE
	    && SpComboBoxArch(component).button != NULL) {
	    HideControl(SpComboBoxArch(component).button);
	}
    
	spUnlockDrawMutexMac();

	if (spIsContainer(component) == SP_TRUE) {
	    spUnmapContainerMac(component);
	}
	
	window = SpGetWindow(component);
	if (SpFrameArch(window).key_send_component == component) {
	    spDebug(50, "spPrimitiveUnmapArch", "unmap key_send_component\n");
	    SpFrameArch(window).key_send_component = NULL;
	    if (spIsText(component) == SP_TRUE) {
		if (spDeactivateTextMac(component, SP_FALSE) == SP_TRUE) {
		    spTEToScrapMac();
		}
		spChangeEditMenuStateMac(window);
	    }
	}
	SpPrimitiveArch(component).map_flag = SP_FALSE;
    }
    
    if (spIsStatusBar(component) == SP_TRUE) {
	window = SpGetWindow(component);
	spDrawStatusBarMac(component);
	if (SpFramePart(window).resize_flag == SP_TRUE) {
	    spDrawGrowIconMac(SpPrimitiveArch(window).window);
	}
    }
    
    return;
}

spBool spPrimitiveSetSizeArch(spComponent component, int width, int height)
{
    int x, y;
    Rect rect;
    Point point;
    GrafPtr save_port;

    spDebug(50, "spPrimitiveSetSizeArch", "width = %d, height = %d\n", width, height);
    
    if (spIsFrame(component) == SP_TRUE) {
	int h;
	
	if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		spDebug(50, "spPrimitiveSetSizeArch", "status bar height = %d\n", h);
		height += h;
	    }
	}
    }

#ifdef SP_DRAW_CANVAS_BORDER
    if (spGetAppearanceVersionMac() >= 0x00000101
	&& spIsCanvas(component) == SP_TRUE
	&& SpCanvasPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).x += SP_CANVAS_BORDER;
	SpComponentPart(component).y += SP_CANVAS_BORDER;
	width -= 2 * SP_CANVAS_BORDER;
	height -= 2 * SP_CANVAS_BORDER;
    }
#endif
    
    spSetComponentRectMac(component, width, height);

    spDebug(50, "spPrimitiveSetSizeArch", "set size: x = %d, y = %d\n",
	    SpPrimitiveArch(component).rect.left, SpPrimitiveArch(component).rect.top);
    
    if (SpPrimitiveArch(component).window != NULL) {
	spLockWindowPort(SpPrimitiveArch(component).window, &save_port);
	spGetPortRectMac(SpPrimitiveArch(component).window, &rect);
	EraseRect(&rect);
	spUnlockWindowPort(SpPrimitiveArch(component).window, save_port);
	
	SizeWindow(SpPrimitiveArch(component).window, (short)width, (short)height, true);
	spDebug(50, "spPrimitiveSetSizeArch", "window: width = %d, height = %d\n",
		width, height);
    } else if (spIsText(component) == SP_TRUE) {
	int text_margin = SP_TEXT_MARGIN;
	
	if (spIsSubClass(component, SpTextArea) == SP_FALSE) {
	    height = SP_DEFAULT_TEXT_HEIGHT;
	    text_margin = SP_TEXT_MARGIN;
	} else {
	    if (spIsSpacingOn(component) == SP_FALSE) {
		text_margin += 5; /* border */
	    }
	}
	if (spIsComboBox(component) == SP_TRUE) {
	    width -= (SP_COMBO_BOX_SPACING + SP_COMBO_BOX_BUTTON_SIZE);
	}
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top;

	if (SpPrimitiveArch(component).control != NULL) {
	    spLockDrawMutexMac();
	    MoveControl(SpPrimitiveArch(component).control, x + text_margin, y + text_margin);
	    SizeControl(SpPrimitiveArch(component).control,
			(short)width - 2 * text_margin,
			(short)height - 2 * text_margin);
	    spUnlockDrawMutexMac();
	} else {
	    spLockDrawMutexMac();
	    (*SpTextArch(component).text)->viewRect.left = x;
	    (*SpTextArch(component).text)->viewRect.top = y;
	    (*SpTextArch(component).text)->viewRect.right = x + width;
	    (*SpTextArch(component).text)->viewRect.bottom = y + height;
	    InsetRect(&(*SpTextArch(component).text)->viewRect,
		      text_margin, text_margin);
	    (*SpTextArch(component).text)->destRect
		= (*SpTextArch(component).text)->viewRect;
	    TECalText(SpTextArch(component).text);
	    spUnlockDrawMutexMac();
	}

	if (spIsComboBox(component) == SP_TRUE
	    && SpComboBoxArch(component).button != NULL) {
	    spLockDrawMutexMac();
	    spGetComboBoxButtonRectMac(component, &rect);
	    MoveControl(SpComboBoxArch(component).button,
			rect.left, rect.top);
	    SizeControl(SpComboBoxArch(component).button,
			spGetRectWidthMac(rect), spGetRectHeightMac(rect));
	    spUnlockDrawMutexMac();
	}
    } else if (spIsSubClass(component, SpList) == SP_TRUE) {
	spDebug(50, "spPrimitiveSetSizeArch", "set size of list: x = %d, y = %d\n",
		SpPrimitiveArch(component).rect.left, SpPrimitiveArch(component).rect.top);
    
	/*LSetDrawingMode(false, SpListArch(component).list);*/
	
	spLockDrawMutexMac();
	
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top;

	if (SpPrimitiveArch(component).control != NULL) {
	    MoveControl(SpPrimitiveArch(component).control, x, y);
	    SizeControl(SpPrimitiveArch(component).control, (short)width, (short)height);
	}
	
	width -= SP_DEFAULT_SLIDER_WIDTH;
	height -= SP_DEFAULT_SLIDER_WIDTH;
	spDebug(50, "spPrimitiveSetSizeArch", "list: width = %d, height = %d\n", width, height);

	spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);

	(*SpListArch(component).list)->rView.left = x;
	(*SpListArch(component).list)->rView.top = y;
	(*SpListArch(component).list)->rView.right = x + width;
	(*SpListArch(component).list)->rView.bottom = y + height;
	LSize(width, height, SpListArch(component).list);
	
	SetPt(&point, width, SP_DEFAULT_SLIDER_WIDTH);
	LCellSize(point, SpListArch(component).list);
	
	spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	
	spUnlockDrawMutexMac();
	
	/*LSetDrawingMode(true, SpListArch(component).list);*/
    } else if (SpPrimitiveArch(component).control != NULL) {
	x = SpPrimitiveArch(component).rect.left;
	y = SpPrimitiveArch(component).rect.top;

	if (SpComponentPart(component).border_width > 0) {
	    x += SpComponentPart(component).border_width;
	    y += SpComponentPart(component).border_width;
	    width -= 2 * SpComponentPart(component).border_width;
	    height -= 2 * SpComponentPart(component).border_width;
	}
	
	if (spIsSlider(component) == SP_TRUE) {
	    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
		if (height > SP_DEFAULT_SLIDER_WIDTH) {
		    y += (height - SP_DEFAULT_SLIDER_WIDTH);
		    height = SP_DEFAULT_SLIDER_WIDTH;
		}
		if (x + width >= SpComponentPart(SpGetWindow(component)).current_width - SP_DEFAULT_SLIDER_WIDTH
		    && y >= SpComponentPart(SpGetWindow(component)).current_height - SP_DEFAULT_SLIDER_WIDTH) {
		    width -= SP_DEFAULT_SLIDER_WIDTH;
		}
	    } else {
		if (width > SP_DEFAULT_SLIDER_WIDTH) {
		    x += (width - SP_DEFAULT_SLIDER_WIDTH);
		    width = SP_DEFAULT_SLIDER_WIDTH;
		}
		if (y + height >= SpComponentPart(SpGetWindow(component)).current_height - SP_DEFAULT_SLIDER_WIDTH
		    && x >= SpComponentPart(SpGetWindow(component)).current_width - SP_DEFAULT_SLIDER_WIDTH) {
		    height -= SP_DEFAULT_SLIDER_WIDTH;
		}
	    }
	} else if (spIsButton(component) == SP_TRUE) {
	    if (spIsAquaMac() == SP_TRUE
		&& (spIsSpacingOn(component) == SP_FALSE
		    || SpParentComponentPart(component).spacing <= SP_AQUA_MIN_SPACING)) {
		if (SpParentComponentPart(component).orientation == SP_VERTICAL) {
		    y += SP_AQUA_MIN_SPACING;
		    height -= 2 * SP_AQUA_MIN_SPACING;
		} else {
		    x += SP_AQUA_MIN_SPACING;
		    width -= 2 * SP_AQUA_MIN_SPACING;
		}
	    }
	} else if (spEqClass(component, SpLabel) == SP_TRUE) {
	    y += SP_DEFAULT_LABEL_TOP_OFFSET;
	    height -= SP_DEFAULT_LABEL_TOP_OFFSET;
	}
	spLockDrawMutexMac();
	MoveControl(SpPrimitiveArch(component).control, x, y);
	SizeControl(SpPrimitiveArch(component).control, (short)width, (short)height);
	spUnlockDrawMutexMac();
	spDebug(50, "spPrimitiveSetSizeArch", "control: width = %d, height = %d\n", width, height);
    } else {
	SpComponentPart(component).current_width = width;
	SpComponentPart(component).current_height = height;

	spDebug(50, "spPrimitiveSetSizeArch", "set size of %s: w = %d, h = %d\n",
		SpGetClassName(component), width, height);
    }
    
    if (spIsVisible(component) == SP_TRUE) {
	if (spIsCanvas(component) == SP_TRUE) {
	    spGetClientSize(component, NULL, NULL);
	    spDrawCanvasMac(component);
	    if (SpPrimitiveArch(SpGetWindow(component)).map_flag == SP_TRUE) {
		spDebug(50, "spPrimitiveSetSizeArch", "refresh canvas: w = %d, h = %d\n",
			width, height);
		spRedrawCanvas(component);
	    }
	} else if (spIsTabBox(component) == SP_TRUE) {
	    /* do nothing */
	} else {
	    spDrawComponentMac(component, SP_FALSE);
	} 
    }
    
    return SP_TRUE;
}

spBool spPrimitiveGetSizeArch(spComponent component, int *width, int *height)
{
    int w, h;
    Rect rect;
    spComponent window;
    
    if (SpPrimitiveArch(component).window != NULL) {
	spGetPortRectMac(SpPrimitiveArch(component).window, &rect);
	*width = spGetRectWidthMac(rect);
	*height = spGetRectHeightMac(rect);
	
	spDebug(50, "spPrimitiveGetSizeArch", "window: width = %d, height = %d\n",
		*width, *height);
    } else if (SpPrimitiveArch(component).control != NULL) {
#if 0
	spGetControlRectMac(SpPrimitiveArch(component).control, &rect);
#else
	rect = SpPrimitiveArch(component).rect;
#endif
	
	*width = spGetRectWidthMac(rect);
	*height = spGetRectHeightMac(rect);
	if (spIsSlider(component) == SP_TRUE) {
	    if (SpComponentPart(component).orientation == SP_HORIZONTAL) {
		*height += (rect.top - SpPrimitiveArch(component).rect.top);
	    } else {
		*width += (rect.left - SpPrimitiveArch(component).rect.left);
	    }
	}
	spDebug(50, "spPrimitiveGetSizeArch", "control: width = %d, height = %d\n",
		*width, *height);
    } else if (spIsSubClass(component, SpList) == SP_TRUE) {
	*width = spGetRectWidthMac((*SpListArch(component).list)->rView);
	*height = spGetRectHeightMac((*SpListArch(component).list)->rView);
	*width += SP_DEFAULT_SLIDER_WIDTH;
	*height += SP_DEFAULT_SLIDER_WIDTH;
    } else if (spIsText(component) == SP_TRUE) {
	spGetTextFrameRectMac(component, &rect);
	if (spIsComboBox(component) == SP_TRUE) {
	    rect.right += (SP_COMBO_BOX_SPACING + SP_COMBO_BOX_BUTTON_SIZE);
	}
	
	*width = spGetRectWidthMac(rect);
	*height = spGetRectHeightMac(rect);
	
	spDebug(50, "spPrimitiveGetSizeArch", "text: width = %d, height = %d\n",
		*width, *height);
    } else if (spIsStatusBar(component) == SP_TRUE) {
	window = SpGetWindow(component);
	spGetPortRectMac(SpPrimitiveArch(window).window, &rect);
	
	*width = spGetRectWidthMac(rect);
	*height = SP_DEFAULT_SLIDER_WIDTH;
    } else {
	w = SpComponentPart(component).current_width;
	h = SpComponentPart(component).current_height;
	*width = w; *height = h;
    }

    spSetComponentRectMac(component, *width, *height);

    if (spIsFrame(component) == SP_TRUE) {
	if (spIsVisible(SpFramePart(component).status_bar) == SP_TRUE) {
	    if (spGetSize(SpFramePart(component).status_bar, NULL, &h) == SP_TRUE) {
		spDebug(50, "spPrimitiveGetSizeArch", "status bar height = %d\n", h);
		*height -= h;
	    }
	}
    }
    
    return SP_TRUE;
}

spBool spPrimitiveGetClientSizeArch(spComponent component, int *width, int *height)
{
    return spPrimitiveGetSizeArch(component, width, height);
}

static void setContainerSensitive(spComponent component, spBool flag)
{
    spComponent next;

    spDebug(50, "setContainerSensitive", "flag = %d\n", flag);
    
    next = SpGetChild(component);
    while (next != NULL) {
	if (spIsCreated(next) == SP_TRUE
	    && spIsPrimitive(next) == SP_TRUE) {
	    if (flag == SP_FALSE) {
		spPrimitiveSetSensitiveArch(next, SP_FALSE);
	    } else {
		spPrimitiveSetSensitiveArch(next, spIsSensitive(next));
	    }

	}
	next = SpGetNextComponent(next);
    }

    return;
}

spBool spPrimitiveSetSensitiveArch(spComponent component, spBool flag)
{
    spDebug(50, "spPrimitiveSetSensitiveArch", "in: flag = %d\n", flag);
    
#if TARGET_API_MAC_CARBON
    if (spIsMenuItem(component) == SP_TRUE
	&& strcaseeq(SpGetName(component), SP_QUIT_MENU_ITEM_NAME)) {
	spChangeQuitMenuStateMac(flag);
    }
#endif

    if (SpPrimitiveArch(component).map_flag == SP_TRUE) {
#if TARGET_API_MAC_CARBON
	if (spGetSystemVersionMac() >= 0x00001010
	    /*spGetSystemVersionMac() < 0x00010?? */) { /* I hope this problem is fixed in future OS */
	    /* to guard from illegal drawing */
	    HMHideTag();
	}
#endif
	
	if (SpPrimitiveArch(component).window != NULL) {
	    if (FrontWindow() == SpPrimitiveArch(component).window) {
		spLockDrawMutexMac();
		HiliteWindow(SpPrimitiveArch(component).window,
			     ((flag == SP_TRUE) ? true : false));
		spUnlockDrawMutexMac();
	    }
	} else if (SpPrimitiveArch(component).control != NULL) {
	    if (FrontWindow() == SpPrimitiveArch(SpGetWindow(component)).window) {
		spHiliteControlMac(SpPrimitiveArch(component).control, flag);
	    }
	} else if (SpPrimitiveArch(component).menu_id > 0) {
	    spLockMenuMutexMac();
	    if (spIsMenuItem(component) == SP_TRUE) {
		if (flag == SP_TRUE) {
		    EnableMenuItem(SpParentPrimitiveArch(component).menu,
				   SpPrimitiveArch(component).menu_id);
		} else {
		    DisableMenuItem(SpParentPrimitiveArch(component).menu,
				    SpPrimitiveArch(component).menu_id);
		}
	    } else if (spIsMenu(component) == SP_TRUE) {
		if (flag == SP_TRUE) {
		    EnableMenuItem(SpPrimitiveArch(component).menu, 0);
		} else {
		    DisableMenuItem(SpPrimitiveArch(component).menu, 0);
		}
	    }
	    spUnlockMenuMutexMac();
	}
    }
    
    if (SpPrimitiveArch(component).sensitive_flag == flag) {
	return SP_TRUE;
    }
    SpPrimitiveArch(component).sensitive_flag = flag;

    if (spIsToolBar(component) == SP_FALSE
	/*&& SpPrimitiveArch(SpGetWindow(component)).map_flag == SP_TRUE*/) {
	WindowPtr window;

	window = SpPrimitiveArch(SpGetWindow(component)).window;

	if (spIsText(component) == SP_TRUE) {
	    spDrawTextMac(component, SP_FALSE);
	} else {
	    spDrawComponentMac(component, SP_FALSE);
	}
    }
    
    if (spIsContainer(component) == SP_TRUE) {
	setContainerSensitive(component, flag);
    }
    if (spIsFrame(component) == SP_TRUE
	&& spIsCreated(SpFramePart(component).menu_bar) == SP_TRUE) {
	setContainerSensitive(SpFramePart(component).menu_bar, flag);
    }
    
    spDebug(50, "spPrimitiveSetSensitiveArch", "done\n");
    
    return SP_TRUE;
}

spBool spShowToolTipArch(spComponent component)
{
    return SP_TRUE;
}

spBool spHandleOSEventMac(EventRecord *event)
{
    spComponent component;
    
    switch(((event->message & osEvtMessageMask) >> 24) & 0xff) {
      case suspendResumeMessage:
	if (event->message & resumeFlag) {
	    /* resume event */
	    spSetSuspendStateMac(SP_FALSE);
	    spDebug(50, "spHandleOSEventMac", "receive resume event\n");
	} else {
	    /* suspend event */
	    spSetSuspendStateMac(SP_TRUE);
	    spDebug(50, "spHandleOSEventMac", "receive suspend event\n");
	}

	if ((component = spGetCurrentWindowMac()) != NULL) {
	    if (event->message & resumeFlag) {
		spActivateComponentMac(component, SP_TRUE);
	    } else {
		spDeactivateComponentMac(component, SP_TRUE);
	    }
	}
        return SP_TRUE;

      case mouseMovedMessage:
	/* mouse moved */
	spDebug(30, "spHandleOSEventMac", "receive mouse moved event\n");
#if 0
	if ((component = spGetCurrentWindowMac()) != NULL) {
	}
#endif
        return SP_TRUE;
    }

    return SP_FALSE;
}

void spActivateControlMac(spComponent component, spBool activate_flag)
{
    if (SpPrimitiveArch(component).control != NULL) {
	if (spUseBevelButtonForToolItemMac() == SP_FALSE
	    && spIsToolItem(component) == SP_TRUE
	    && SpToolItemPart(component).set == SP_TRUE) {
	    /* do nothing */
	    spDebug(50, "spActivateControlMac", "tool item activated with value 1\n");
	} else {
	    spDebug(50, "spActivateControlMac", "%s: sensitive_flag = %d, activate_flag = %d\n",
		    spGetTitle(component), SpPrimitiveArch(component).sensitive_flag, activate_flag);
	    if (SpPrimitiveArch(component).sensitive_flag == SP_TRUE) {
		spHiliteControlMac(SpPrimitiveArch(component).control, activate_flag);
	    }
	}
	spDrawControlInWindowPortMac(SpPrimitiveArch(component).control,
				     SpPrimitiveArch(SpGetWindow(component)).window);
	
	if (spIsToolItem(component) == SP_TRUE) {
	    if (spIsCarbonEventAvailableMac() == SP_FALSE) {
		spDrawToolItemMac(component,
				  (activate_flag == SP_TRUE ? SpPrimitiveArch(component).sensitive_flag
				   : SP_FALSE));
	    }
	} else if (spIsSubClass(component, SpPushButton) == SP_TRUE) {
	    spDrawDefaultButtonMac(component);
	}
    }
    
    return;
}

void spActivateComboBoxMac(spComponent component, spBool activate_flag)
{
    if (SpComboBoxArch(component).button != NULL) {
	if (SpPrimitiveArch(component).sensitive_flag == SP_TRUE) {
	    spHiliteControlMac(SpComboBoxArch(component).button, activate_flag);
	}
	spDrawControlInWindowPortMac(SpComboBoxArch(component).button,
				     SpPrimitiveArch(SpGetWindow(component)).window);
    }
    
    return;
}

void spActivateComponentMac(spComponent component, spBool need_update)
{
    spComponent text;
    spComponent next;

    spDebug(50, "spActivateComponentMac", "window activated\n");
    
    if (component == NULL) return;
    
    SpFrameArch(component).activate_flag = SP_TRUE;
    
    if (SpFrameArch(component).foreground_func != NULL) {
	SpFrameArch(component).foreground_func(SpFrameArch(component).data);
    }
    
    if (spIsText(SpFrameArch(component).key_send_component) == SP_TRUE) {
	spDebug(50, "spActivateComponentMac", "activate text edit\n");
	
	text = SpFrameArch(component).key_send_component;
	if (SpPrimitiveArch(text).sensitive_flag == SP_TRUE) {
	    if (spActivateTextMac(text, SP_TRUE) == SP_TRUE) {
		spTEFromScrapMac();
		spChangeEditMenuStateMac(component);
	    }
	}
    }
    
    if (need_update == SP_TRUE) {
	if (SpPrimitiveArch(component).next_need_update != NULL) {
	    next = SpPrimitiveArch(component).next_need_update;
	    while (next != NULL) {
		if (spIsVisible(next) == SP_TRUE
		    && SpPrimitiveArch(next).sensitive_flag == SP_TRUE
		    && SpPrimitiveArch(next).map_flag == SP_TRUE
		    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		    if (spIsTabBox(next) == SP_TRUE) {
			spDrawTabBoxMac(next, SP_FALSE);
		    } else if (spIsToolBar(next) == SP_TRUE) {
			spDrawToolBarMac(next, SP_TRUE);
		    } else if (spIsSubClass(next, SpContainer) == SP_TRUE) {
			spDrawContainerMac(next);
		    }
		}
		next = SpPrimitiveArch(next).next_need_update;
	    }
	
	    next = SpPrimitiveArch(component).next_need_update;
	    while (next != NULL) {
		if (spIsVisible(next) == SP_TRUE
		    && SpPrimitiveArch(next).map_flag == SP_TRUE
		    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		    if (spIsSubClass(next, SpList) == SP_TRUE) {
			spActivateListMac(next, SP_TRUE, SP_TRUE);
		    } else if (spIsCanvas(next) == SP_TRUE) {
			spSetCanvasCursorMac(next);
			spDrawCanvasMac(next);
			spDebug(50, "spActivateComponentMac", "expose canvas\n");
			spPostMessageMac(next, SP_EXPOSE_CALLBACK, SP_CR_EXPOSE);
		    } else if (spIsStatusBar(next) == SP_TRUE) {
			spDrawStatusBarMac(next);
		    } else if (spEqClass(next, SpLabel) == SP_TRUE) {
			spDrawLabelMac(next);
		    } else if (spIsTabBox(next) == SP_TRUE) {
			/* do nothing */
		    } else if (spIsText(next) == SP_TRUE) {
			/* do nothing */
		    } else {
			spActivateControlMac(next, SP_TRUE);
			if (spIsSlider(next) == SP_TRUE) {
			    spDrawSliderValueMac(next);
			}
		    }

		    if (spIsComboBox(next) == SP_TRUE) {
			spActivateComboBoxMac(next, SP_TRUE);
		    }
		}
		next = SpPrimitiveArch(next).next_need_update;
	    }
	}
	spUpdateTextMac(component);
	
	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    spDrawGrowIconMac(SpPrimitiveArch(component).window);
	}
    }

    return;
}

void spDeactivateComponentMac(spComponent component, spBool need_update)
{
    spComponent text;
    spComponent next;
    
    spDebug(50, "spDeactivateComponentMac", "window deactivated\n");
    
    if (component == NULL) return;
    
    SpFrameArch(component).activate_flag = SP_FALSE;
    
    if (SpFrameArch(component).background_func != NULL) {
	SpFrameArch(component).background_func(SpFrameArch(component).data);
    }
    
    if (spIsText(SpFrameArch(component).key_send_component) == SP_TRUE) {
	spDebug(50, "spDeactivateComponentMac", "deactivate text edit\n");
	
	text = SpFrameArch(component).key_send_component;
	if (spDeactivateTextMac(text, SP_FALSE) == SP_TRUE) {
	    spTEToScrapMac();
	    spChangeEditMenuStateMac(component);
	}
    }
    
    if (need_update == SP_TRUE) {
	if (SpPrimitiveArch(component).next_need_update != NULL) {
	    next = SpPrimitiveArch(component).next_need_update;
	    while (next != NULL) {
		if (spIsVisible(next) == SP_TRUE
		    && SpPrimitiveArch(next).sensitive_flag == SP_TRUE
		    && SpPrimitiveArch(next).map_flag == SP_TRUE
		    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		    if (spIsTabBox(next) == SP_TRUE) {
			spDrawTabBoxMac(next, SP_FALSE);
		    } else if (spIsToolBar(next) == SP_TRUE) {
			spDrawToolBarMac(next, SP_TRUE);
		    } else if (spIsSubClass(next, SpContainer) == SP_TRUE) {
			spDrawContainerMac(next);
		    }
		}
		next = SpPrimitiveArch(next).next_need_update;
	    }

	    next = SpPrimitiveArch(component).next_need_update;
	    while (next != NULL) {
		if (spIsVisible(next) == SP_TRUE
		    && SpPrimitiveArch(next).map_flag == SP_TRUE
		    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		    if (spIsSubClass(next, SpList) == SP_TRUE) {
			spActivateListMac(next, SP_FALSE, SP_FALSE);
		    } else if (spIsCanvas(next) == SP_TRUE) {
			spUnsetCanvasCursorMac(next);
			spDrawCanvasMac(next);
			spDebug(50, "spDeactivateComponentMac", "expose canvas\n");
			spPostMessageMac(next, SP_EXPOSE_CALLBACK, SP_CR_EXPOSE);
		    } else if (spIsStatusBar(next) == SP_TRUE) {
			spDrawStatusBarMac(next);
		    } else if (spEqClass(next, SpLabel) == SP_TRUE) {
			spDrawLabelMac(next);
		    } else if (spIsTabBox(next) == SP_TRUE) {
			/* do nothing */
		    } else if (spIsText(next) == SP_TRUE) {
			/* do nothing */
		    } else {
			spActivateControlMac(next, SP_FALSE);
			if (spIsSlider(next) == SP_TRUE) {
			    spDrawSliderValueMac(next);
			}
		    }

		    if (spIsComboBox(next) == SP_TRUE) {
			spActivateComboBoxMac(next, SP_FALSE);
		    }
		}
		next = SpPrimitiveArch(next).next_need_update;
	    }
	}
	spUpdateTextMac(component);
	
	if (SpFramePart(component).resize_flag == SP_TRUE) {
	    spDrawGrowIconMac(SpPrimitiveArch(component).window);
	}
    }
    
    return;
}

spBool spHandleActivateEventMac(EventRecord *event)
{
    WindowPtr window;
    spComponent component;

    spDebug(50, "spHandleActivateEventMac", "in\n");
    
    window = (WindowPtr)event->message;
    
    if ((component = spGetWindowReferenceMac(window)) == NULL
	|| spIsFrame(component) == SP_FALSE) {
	return SP_FALSE;
    }

    if ((event->modifiers & activeFlag)) {	/* activated */
	spActivateComponentMac(component, SP_TRUE);
    } else {					/* deactivated */
	spDeactivateComponentMac(component, SP_TRUE);
    }

    if (SpFramePart(component).resize_flag == SP_TRUE) {
	spDrawGrowIconMac(window);
    }
    
    return SP_TRUE;
}

spBool spHandleAppleMenuChoiceMac(int item_id)
{
    spDebug(50, "spHandleAppleMenuChoiceMac", "in\n");
    
    switch (item_id) {
      case SP_ABOUT_MENU_ITEM_ID:		/* about menu */
	if (!strnone(SpTopLevelPart(sp_toplevel).information)) {
	    spDisplayInformation(/*spGetCurrentWindowMac()*/NULL, SP_ABOUT_LABEL,
				 SpTopLevelPart(sp_toplevel).information);
	    return SP_TRUE;
	}
	break;
      default:
#if !TARGET_API_MAC_CARBON
	{
	    Str255 pname;
    
	    GetMenuItemText(SpTopLevelArch(sp_toplevel).apple_menu, (short)item_id, pname);
	    OpenDeskAcc(pname);
	}
#endif
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spComponent spFindMenuItemMac(spComponent component, int menu_id, int item_id)
{
    spComponent child;
    spComponent menu_item = NULL;

    if (spIsCreated(component) == SP_FALSE) {
	return NULL;
    }
    child = SpGetChild(component);

    while (child != NULL) {
	if (spIsMenu(component) == SP_TRUE
	    && SpPrimitiveArch(component).menu_id == menu_id
	    && SpPrimitiveArch(child).menu_id == item_id) {
	    menu_item = child;
	    break;
	} else if ((menu_item = spFindMenuItemMac(child, menu_id, item_id)) != NULL) {
	    break;
	}
	child = SpGetNextComponent(child);
    }

    return menu_item;
}

spBool spPostMenuChoice(spComponent component, int menu_id, int item_id)
{
    spComponent menu_item;
    
    if ((menu_item = spFindMenuItemMac(component, menu_id, item_id)) != NULL) {
	if (spIsToggleButton(menu_item) == SP_TRUE) {
	    if (spToggleComponentMac(menu_item) == SP_TRUE) {
		return spPostMessageMac(menu_item, SP_VALUE_CHANGED_CALLBACK,
					SP_CR_VALUE_CHANGED);
	    }
	} else {
	    return spPostMessageMac(menu_item, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
	}
    }

    return SP_FALSE;
}

void spHandleCloseWindowMac(spComponent component)
{
    long component_id;
	    
    if (SpFramePart(component).close_style != SP_NO_CLOSE) {
	spDebug(50, "spHandleCloseWindowMac", "close_style = %d\n",
		SpFramePart(component).close_style);
	
	spPostMessageMac(component, SP_CLOSE_CALLBACK, SP_CR_CLOSE);
	
	if (SpFramePart(component).close_style == SP_DESTROY_CLOSE) {
	    component_id = SpGetComponentId(component);
	    spPopdownWindow(component);
	    if (component_id != spGetDestroyedComponentId()) {
		spDestroyWindow(component);
	    }
	} else if (SpFramePart(component).close_style == SP_CALLBACK_CLOSE) {
	    /* do nothing */
	} else if (SpFramePart(component).close_style == SP_UNMAP_CLOSE) {
	    spPopdownWindow(component);
	}
    }
    
    return;
}

spBool spHandleUserMenuChoiceMac(int menu_id, int item_id)
{
    GrafPtr save_port;
    spComponent text;
    spBool flag = SP_FALSE;
    
    if (sp_current_menu_bar == NULL) {
	if (menu_id == SP_FILE_MENU_ID) {
	    switch (item_id) {
	      case SP_CLOSE_MENU_ITEM_ID:
		if (sp_current_window != NULL) {
		    spHandleCloseWindowMac(sp_current_window);
		    return SP_TRUE;
		}
		break;
	      case SP_QUIT_MENU_ITEM_ID:
		if (sp_current_window != NULL) {
		    spQuitCB(sp_current_window, NULL);
		} else {
		    spQuit(0);
		}
		return SP_TRUE;
	      default:
		break;
	    }
	} else if (menu_id == SP_EDIT_MENU_ID) {
	    if (sp_current_window != NULL
		&& spIsText(SpFrameArch(sp_current_window).key_send_component) == SP_TRUE
		&& SpTextPart(SpFrameArch(sp_current_window).key_send_component).editable == SP_TRUE) {
		spLockWindowPort(SpPrimitiveArch(sp_current_window).window, &save_port);
		
		text = SpFrameArch(sp_current_window).key_send_component;
		switch (item_id) {
		  case SP_CUT_MENU_ITEM_ID:
		    spGetOriginalRGBMac(); spSetNormalRGBMac();
		    TECut(SpTextArch(text).text);
		    spSetOriginalRGBMac();
		    flag = SP_TRUE;
		    break;
		  case SP_COPY_MENU_ITEM_ID:
		    spGetOriginalRGBMac(); spSetNormalRGBMac();
		    TECopy(SpTextArch(text).text);
		    spSetOriginalRGBMac();
		    flag = SP_TRUE;
		    break;
		  case SP_PASTE_MENU_ITEM_ID:
		    {
			long scrap_len;
			TEHandle te;

			te = SpTextArch(text).text;
			
			scrap_len = TEGetScrapLength();

			if (spHandleExceedTextMac(text, 0, scrap_len) == SP_FALSE) {
			    spGetOriginalRGBMac(); spSetNormalRGBMac();
			    TEPaste(SpTextArch(text).text);
			    spSetOriginalRGBMac();
			    flag = SP_TRUE;
			}
		    }
		    break;
		  case SP_DELETE_MENU_ITEM_ID:
		    spGetOriginalRGBMac(); spSetNormalRGBMac();
		    TEDelete(SpTextArch(text).text);
		    spSetOriginalRGBMac();
		    flag = SP_TRUE;
		    break;
		  case SP_SELECT_ALL_MENU_ITEM_ID:
		    spGetOriginalRGBMac(); spSetNormalRGBMac();
		    TESetSelect(0, (*SpTextArch(text).text)->teLength, SpTextArch(text).text);
		    spSetOriginalRGBMac();
		    flag = SP_TRUE;
		    break;
		  default:
		    break;
		}
		spUnlockWindowPort(SpPrimitiveArch(sp_current_window).window, save_port);
		
		if (flag == SP_TRUE) {
		    spChangeEditMenuStateMac(sp_current_window);
		    return SP_TRUE;
		}
	    }
	}
    } else {
	return spPostMenuChoice(sp_current_window, menu_id, item_id);
    }
    
    return SP_FALSE;
}

spBool spHandleRootMenuChoiceMac(int menu_id, int item_id)
{
    spBool result = SP_FALSE;
    
    switch(menu_id) {
      case SP_APPLE_MENU_ID:	/* apple menu */
	result = spHandleAppleMenuChoiceMac(item_id);
	break;
	
      default:
	result = spHandleUserMenuChoiceMac(menu_id, item_id);
	break;
    }

    return result;
}

spBool spHandleMenuChoiceMac(long message)
{
    int menu_id, item_id;
    spBool result;

    menu_id = (int)HiWord(message);
    item_id = (int)LoWord(message);

    spDebug(50, "spHandleMenuChoiceMac", "menu_id = %d, item_id = %d\n",
	    menu_id, item_id);

    result = spHandleRootMenuChoiceMac(menu_id, item_id);
    
    spLockMenuMutexMac();
    HiliteMenu(0);
    spUnlockMenuMutexMac();
    
    return result;
}

spBool spHandleControlMouseDownMac(WindowPtr window, ControlRef control,
				   Point point, ControlPartCode part)
{
    spComponent component;
    
    spDebug(50, "spHandleControlMouseDownMac", "control part = %d\n", part);

    if (spHandleSliderActionMac(window, control, point, part) == SP_TRUE) {
	return SP_TRUE;
    }
    
    /* other control */
    if ((component = spGetControlReferenceMac(control)) != NULL) {
	ControlPartCode track_part;
	
	track_part = TrackControl(control, point, (ControlActionUPP)-1);

	if (track_part == part) {
	    switch (part) {
	      case kControlButtonPart:
		if (spIsToggleButton(component) == SP_TRUE
		    && spToggleComponentMac(component) == SP_TRUE) {
		    return spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK,
					    SP_CR_VALUE_CHANGED);
		} else {
		    return spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE);
		}
	      case kControlCheckBoxPart:
		/*case kControlRadioButtonPart:*/
		if (spToggleComponentMac(component) == SP_TRUE) {
		    return spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK,
					    SP_CR_VALUE_CHANGED);
		}
		break;
	      default:
		break;
	    }
	}
    }

    return SP_FALSE;
}

spBool spFocusComponentMac(spComponent window, spComponent component)
{
    spComponent prev;
    
    spDebug(50, "spFocusComponentMac", "in\n");
    
    if (SpFrameArch(window).key_send_component != component
	&& spIsVisible(component) == SP_TRUE
	&& SpPrimitiveArch(component).sensitive_flag == SP_TRUE
	&& SpPrimitiveArch(component).map_flag == SP_TRUE) {
	prev = SpFrameArch(window).key_send_component;
	SpFrameArch(window).key_send_component = component;

	if (spIsCreated(prev) == SP_TRUE) {
	    spDebug(50, "spFocusComponentMac", "prev = %s, new = %s\n",
		    SpGetClassName(prev), SpGetClassName(component));
	    if (spIsText(prev) == SP_TRUE) {
		if (spDeactivateTextMac(prev, SP_TRUE) == SP_TRUE) {
		    spTEToScrapMac();
		}
	    } else if (spIsList(prev) == SP_TRUE) {
		spActivateListMac(prev, SP_FALSE, SP_TRUE);
	    } else if (spIsCanvas(prev) == SP_TRUE) {
		if (SpCanvasPart(prev).focusable == SP_TRUE) {
		    spRedrawCanvas(prev);
		}
	    }
	}
    
	if (spIsText(component) == SP_TRUE) {
	    if (spActivateTextMac(component, SP_FALSE) == SP_TRUE) {
		spTEFromScrapMac();
	    }
	} else if (spIsList(component) == SP_TRUE) {
	    spActivateListMac(component, SP_TRUE, SP_FALSE);
	} else if (spIsCanvas(component) == SP_TRUE) {
	    if (SpCanvasPart(component).focusable == SP_TRUE) {
		spRedrawCanvas(component);
	    }
	}
	spChangeEditMenuStateMac(window);

	return SP_TRUE;
    }

    return SP_FALSE;
}

spBool spShowPopupMenuMac(spComponent component, int button_id, Point point, short modifiers)
{
    Point popup_point;
    spComponent popup_menu;
    spMouseButton button;
    long message;
    int menu_id, item_id;
    spBool canvas_flag;
    GrafPtr save_port;

    if ((popup_menu = SpPrimitiveArch(component).popup_menu) == NULL) {
	return SP_FALSE;
    }

    if (button_id > 1) {
	button = button_id - 1;
    } else {
	button = spGetPressedMouseButtonMac(modifiers);
    }
    spDebug(40, "spShowPopupMenuMac", "button = %d, popup_button = %d\n",
	    button, SpMenuPart(popup_menu).popup_button);
    
    if (SpMenuPart(popup_menu).popup_button != button) {
	return SP_FALSE;
    }

    spUnsetCursorMac();
		
    canvas_flag = spHandleCanvasMouseMac(component, button_id, point, modifiers, SP_TRUE);

    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
    popup_point = point;
    LocalToGlobal(&popup_point);
    spDebug(40, "spShowPopupMenuMac", "menu = %ld, point.v = %d, point.h = %d\n",
	    SpPrimitiveArch(popup_menu).menu, popup_point.v, popup_point.h);
    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);

#if 0
    InsertMenu(SpPrimitiveArch(popup_menu).menu, -1);
#endif
    
    message = PopUpMenuSelect(SpPrimitiveArch(popup_menu).menu,
			      popup_point.v, popup_point.h, 0);
    spDebug(40, "spShowPopupMenuMac", "PopUpMenuSelect: message = %ld\n", message);

#if 0
#if TARGET_API_MAC_CARBON
    DeleteMenu(GetMenuID(SpPrimitiveArch(popup_menu).menu));
#else
    DeleteMenu((*SpPrimitiveArch(popup_menu).menu)->menuID);
#endif
#endif
    
    if (message) {
	menu_id = (int)HiWord(message);
	item_id = (int)LoWord(message);
	spDebug(40, "spShowPopupMenuMac", "popup_menu_id = %d, menu_id = %d, item_id = %d\n",
		SpPrimitiveArch(popup_menu).menu_id, menu_id, item_id);

	spPostMenuChoice(popup_menu, menu_id, item_id);
    }
    
    if (canvas_flag == SP_TRUE) {
	spHandleCanvasMouseMac(component, button_id, point, modifiers, SP_FALSE);
    }
    
    return SP_TRUE;
}

spBool spHandleComponentMouseDownMac(WindowPtr window, int button_id, EventModifiers modifiers, Point point)
{
    Rect rect;
    spComponent component;
    spComponent next;
    spBool flag;
    
    if ((component = spGetWindowReferenceMac(window)) == NULL) {
	return SP_FALSE;
    }

    if (SpFrameArch(component).mouse_func != NULL) {
	SpFrameArch(component).mouse_func(SpFrameArch(component).data,
					  point.h, point.v);
    }
    
    if (SpPrimitiveArch(component).next_need_update == NULL) {
	return SP_FALSE;
    }
    spDebug(50, "spHandleComponentMouseDownMac", "x = %d, y = %d\n", point.h, point.v);

    sp_drag_window = NULL;
    sp_drag_component = NULL;
    
    next = component;
    while (next != NULL) {
	if (spIsVisible(next) == SP_TRUE
	    && SpPrimitiveArch(next).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(next).map_flag == SP_TRUE
	    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
	    rect = SpPrimitiveArch(next).rect;
	    
	    if (PtInRect(point, &rect)) {
		flag = SP_FALSE;
		
		if (spShowPopupMenuMac(next, button_id, point, modifiers) == SP_TRUE) {
		    flag = SP_TRUE;
		} else if (spHandleCanvasMouseMac(next, button_id, point,
						  modifiers, SP_TRUE) == SP_TRUE) {
		    sp_drag_window = component;
		    sp_drag_component = next;
		    flag = SP_TRUE;
		} else if (spIsCarbonEventAvailableMac() == SP_FALSE) {
		    if (spHandleListMouseMac(next, point, modifiers) == SP_TRUE) {
			flag = SP_TRUE;
		    } else if (spSelectTabBoxMac(next, point) == SP_TRUE) {
			flag = SP_TRUE;
		    } else if (spHandleToolItemMouseDownMac(next, point) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		}

		if (flag == SP_TRUE) {
		    return flag;
		}
	    }
	}

	next = SpPrimitiveArch(next).next_need_update;
    }

    return SP_FALSE;
}

spBool spFindModalWindowMac(WindowPtr window, spBool beep_flag)
{
    spComponent selected_component;
    
    if ((selected_component = spGetWindowReferenceMac(window)) != NULL
	&& sp_current_window == selected_component) {
	return SP_FALSE;
    }
    
    if (spIsFrame(sp_current_window) == SP_TRUE &&
	SpFramePart(sp_current_window).popup_style == SP_MODAL_POPUP) {
	if (beep_flag == SP_TRUE) {
	    SysBeep(1);
	}
	return SP_TRUE;
    }

    return SP_FALSE;
}

void spDragWindowMac(WindowPtr window, Point point)
{
    Rect rect;

    spGetScreenBoundsMac(&rect);
    InsetRect(&rect, SP_DRAG_THRESHOLD, SP_DRAG_THRESHOLD);
    
    DragWindow(window, point, &rect);
    
    return;
}

spBool spHandleDragWindowMac(WindowPtr window, Point where)
{
    spComponent component;

    if (spFindModalWindowMac(window, SP_TRUE) == SP_TRUE) {
	return SP_TRUE;
    }
    
    if ((component = spGetWindowReferenceMac(window)) != NULL) {
	spSelectMenuBarMac(component, NULL);
    }

    spDragWindowMac(window, where);
    
    return SP_TRUE;
}

spBool spHandleFrontWindowMouseDownMac(WindowPtr window, EventRecord *event)
{
    Point point;
    ControlPartCode part;
    ControlRef control;
    GrafPtr save_port;
    spBool flag = SP_FALSE;

    spDebug(50, "spHandleFrontWindowMouseDownMac", "in\n");
    
    spLockWindowPort(window, &save_port);
    point = event->where;
    GlobalToLocal(&point);
    spUnlockWindowPort(window, save_port);
    
    if (spHandleComponentMouseDownMac(window, 0, event->modifiers, point) == SP_TRUE) {
	flag = SP_TRUE;
    } else if (spHandleTextMouseDownMac(window, event->modifiers, point) == SP_TRUE) {
	flag = SP_TRUE;
    } else if ((part = FindControl(point, window, &control)) != kControlNoPart) {
	flag = spHandleControlMouseDownMac(window, control, point, part);
    }
    
    return flag;
}

spBool spSelectWindowMac(WindowPtr window, spBool beep_flag)
{
    spComponent component;

    spDebug(50, "spSelectWindowMac", "in\n");

    if (spFindModalWindowMac(window, beep_flag) == SP_TRUE) {
	return SP_TRUE;
    }
    
    if ((component = spGetWindowReferenceMac(window)) != NULL) {
	SelectWindow(window);
	spSelectMenuBarMac(component, NULL);
    } else {
	SelectWindow(window);
    }
    spDebug(50, "spSelectWindowMac", "window selected\n");

    return SP_TRUE;
}

spBool spHandleGoAwayMac(WindowPtr window, EventRecord *event)
{
    Boolean go_away;
    spComponent component;
    
    spDebug(50, "spHandleGoAwayMac", "in\n");

    go_away = TrackGoAway(window, event->where);
    
    if (go_away) {
	if ((component = spGetWindowReferenceMac(window)) == NULL) {
	    DisposeWindow(window);
	} else if (spIsFrame(component) == SP_TRUE) {
	    spHandleCloseWindowMac(component);
	}
    }

    return SP_TRUE;
}

spBool spHandleResizeMac(WindowPtr window)
{
    spBool flag = SP_FALSE;
    spComponent component;
    spComponent next;
    RgnHandle orig_rgn;
    Rect null_rect = {0, 0, 0, 0};
    
    if ((component = spGetWindowReferenceMac(window)) == NULL) {
	return SP_FALSE;
    }
    
    spDebug(50, "spHandleResizeMac", "in\n");
    
    orig_rgn = NewRgn();
    GetClip(orig_rgn);
    ClipRect(&null_rect);
    spAdjustComponentSize(component);
    SetClip(orig_rgn);
    DisposeRgn(orig_rgn);

    if (spPostMessageMac(component, SP_RESIZE_CALLBACK, SP_CR_RESIZE) == SP_TRUE) {
	flag = SP_TRUE;
    }
    if (SpPrimitiveArch(component).next_need_update != NULL) {
	next = SpPrimitiveArch(component).next_need_update;
	while (next != NULL) {
	    if (spIsVisible(next) == SP_TRUE
		&& SpPrimitiveArch(next).map_flag == SP_TRUE
		&& SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		if (spIsTabBox(next) == SP_TRUE) {
		    spDrawTabBoxMac(next, SP_FALSE);
		}
	    }
	    next = SpPrimitiveArch(next).next_need_update;
	}
	
	next = SpPrimitiveArch(component).next_need_update;
	while (next != NULL) {
	    if (spIsVisible(next) == SP_TRUE
		&& SpPrimitiveArch(next).map_flag == SP_TRUE
		&& SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		if (spIsCanvas(next) == SP_TRUE) {
		    spDebug(50, "spHandleResizeMac", "expose canvas\n");
		    spDrawCanvasMac(next);
		    if (spPostMessageMac(next, SP_RESIZE_CALLBACK,
					 SP_CR_RESIZE) == SP_TRUE) {
			flag = SP_TRUE;
		    } else if (spPostMessageMac(next, SP_EXPOSE_CALLBACK,
						SP_CR_EXPOSE) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		} else if (spIsTabBox(next) == SP_FALSE) {
		    spDrawComponentMac(next, SP_FALSE);
		}
	    }

	    next = SpPrimitiveArch(next).next_need_update;
	}
    }
    spUpdateTextMac(component);
    
    if (SpFramePart(component).resize_flag == SP_TRUE) {
	spDrawGrowIconMac(window);
    }
    
    return flag;
}

spBool spHandleGrowMac(WindowPtr window, EventRecord *event)
{
    Rect rect, bounds;
    long size;
    GrafPtr save_port;

    spDebug(50, "spHandleGrowMac", "in\n");
    
    rect.left = SP_MIN_WINDOW_WIDTH;		/* min width */
    rect.top = SP_MIN_WINDOW_HEIGHT;		/* min height */
    spGetScreenBoundsMac(&bounds);
    rect.right = bounds.right - bounds.left; /* max width */
    rect.bottom = bounds.bottom
	- bounds.top - GetMBarHeight(); /* max height */
    
    size = GrowWindow(window, event->where, &rect);
    
    if (size != 0) {
	spLockWindowPort(window, &save_port);
	
	spGetPortRectMac(window, &rect);
        EraseRect(&rect);
        SizeWindow(window, LoWord(size), HiWord(size), true);
	
	spUnlockWindowPort(window, save_port);

	spHandleResizeMac(window);
    }
    
    return SP_TRUE;
}

spBool spHandleZoomMac(WindowPtr window, WindowPartCode part, EventRecord *event)
{
    Rect rect;
    Boolean zoom;
    GrafPtr save_port;
    
    spDebug(50, "spHandleZoomMac", "in\n");

    zoom = TrackBox(window, event->where, part);
    
    if (zoom) {
	spLockWindowPort(window, &save_port);
    
	spGetPortRectMac(window, &rect);
        EraseRect(&rect);
        ZoomWindow(window, part, true);
	
	spUnlockWindowPort(window, save_port);
	
	spHandleResizeMac(window);
    }
    
    return SP_TRUE;
}

spBool spHandleMouseDownMac(EventRecord *event)
{
    long message;
    WindowPtr window;
    WindowPartCode part;
    
    spDebug(50, "spHandleMouseDownMac", "in\n");
    
    switch((part = FindWindow(event->where, &window))) {
      case inDesk:
	return spFindModalWindowMac(window, SP_TRUE);
	
      case inDrag:
	return spHandleDragWindowMac(window, event->where);

      case inMenuBar:
	message = MenuSelect(event->where);
        return spHandleMenuChoiceMac(message);

      case inContent:
	if (window == FrontWindow()) {
	    return spHandleFrontWindowMouseDownMac(window, event);
	}
	break;

      case inGoAway:		/* in close box */
	return spHandleGoAwayMac(window, event);
	
      case inGrow: /* in size box */
        return spHandleGrowMac(window, event);
	
      case inZoomIn:		/* in zoom box */
      case inZoomOut:
        return spHandleZoomMac(window, part, event);
	
      default:
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

spBool spHandleComponentMouseUpMac(WindowPtr window, int button_id, EventModifiers modifiers, Point point)
{
    Rect rect;
    spComponent component;
    spComponent next;
    
    if ((component = spGetWindowReferenceMac(window)) == NULL) {
	return SP_FALSE;
    }

#if 0
    if (SpFrameArch(component).mouse_func != NULL) {
	SpFrameArch(component).mouse_func(SpFrameArch(component).data,
					  point.h, point.v);
    }
#endif
    
    if (SpPrimitiveArch(component).next_need_update == NULL) {
	return SP_FALSE;
    }
    spDebug(10, "spHandleComponentMouseUpMac", "x = %d, y = %d\n", point.h, point.v);
    
    sp_drag_window = NULL;
    sp_drag_component = NULL;
    
    next = component;
    while (next != NULL) {
	if (spIsVisible(next) == SP_TRUE
	    && SpPrimitiveArch(next).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(next).map_flag == SP_TRUE
	    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
	    rect = SpPrimitiveArch(next).rect;
	    
	    if (spHandleCanvasMouseMac(next, button_id, point,
				       modifiers, SP_FALSE) == SP_TRUE) {
		return SP_TRUE;		    
	    }
	}

	next = SpPrimitiveArch(next).next_need_update;
    }

    return SP_FALSE;
}

spBool spHandleMouseUpMac(EventRecord *event)
{
    Point point;
    WindowPtr window;
    WindowPartCode part;
    GrafPtr save_port;
    spBool flag;
    
    switch ((part = FindWindow(event->where, &window))) {
      /*case inContent:*/
      default:
	if (sp_drag_window != NULL) {
	    if (SpPrimitiveArch(sp_drag_window).window != NULL) {
		window = SpPrimitiveArch(sp_drag_window).window;
		spDebug(10, "spHandleMouseUpMac", "part = %d\n", part);
		
		spLockWindowPort(window, &save_port);
		
		point = event->where;
		
		spDebug(10, "spHandleMouseUpMac", "x = %d, y = %d\n", point.h, point.v);
		GlobalToLocal(&point);
		spDebug(10, "spHandleMouseUpMac", "local: x = %d, y = %d\n", point.h, point.v);
		
		spUnlockWindowPort(window, save_port);
		
		flag = spHandleComponentMouseUpMac(window, 0, event->modifiers, point);
		
		return flag;
	    }
	} else {
	    if (part == inContent) {
		return spSelectWindowMac(window, SP_TRUE);
	    }
	}
	break;
    }

    return SP_FALSE;
}

spBool spHandleKeyUpMac(EventRecord *event)
{
    WindowPtr window;
    spComponent component;
    spComponent canvas;
    spBool flag = SP_FALSE;

    spDebug(50, "spHandleKeyUpMac", "in\n");
    
    window = FrontWindow();
    
    if ((component = spGetWindowReferenceMac(window)) == NULL
	|| spIsFrame(component) == SP_FALSE) {
	return SP_FALSE;
    }
    
    if (spIsCanvas(SpFrameArch(component).key_send_component) == SP_TRUE) {
	canvas = SpFrameArch(component).key_send_component;

	SpPrimitiveArch(canvas).event = *event;
	flag = spPostMessageMac(canvas, SP_KEY_RELEASE_CALLBACK, SP_CR_KEY_RELEASE);
    }
    
    return flag;
}

spBool spHandleDefaultButton(spComponent component, char key)
{
    spBool flag = SP_FALSE;

    if (spIsFrame(component) == SP_FALSE) return SP_FALSE;
    
    if (key == kEscapeCharCode
	&& spPressButtonMac(SpFramePart(component).cancel_button) == SP_TRUE) {
	flag = SP_TRUE;
    } else if (spIsSubClass(SpFrameArch(component).key_send_component, SpTextArea) == SP_FALSE
	       && (key == '\r' || key == '\n' || key == kEnterCharCode)
	       && spPressButtonMac(SpFramePart(component).default_button) == SP_TRUE) {
	flag = SP_TRUE;
    }

    return flag;
}

spBool spHandleRawKeyDownMac(spComponent component, EventModifiers modifiers, char key)
{
    spBool flag = SP_FALSE;
    spComponent child;
    
    spDebug(50, "spHandleRawKeyDownMac", "in: key_send_component: %ld\n",
	    (long)SpFrameArch(component).key_send_component);
    
    if (key == kTabCharCode
	&& (modifiers & shiftKey
	    || SpFrameArch(component).key_send_component == NULL
	    || (spIsCanvas(SpFrameArch(component).key_send_component) == SP_TRUE
		&& SpCanvasPart(SpFrameArch(component).key_send_component).focusable == SP_TRUE)
	    || spIsComboBox(SpFrameArch(component).key_send_component) == SP_TRUE
	    || spIsSubClass(SpFrameArch(component).key_send_component, SpTextField) == SP_TRUE
	    || spIsSubClass(SpFrameArch(component).key_send_component, SpList) == SP_TRUE)) {
	spDebug(50, "spHandleRawKeyDownMac", "tab key\n");
	
	if (SpFrameArch(component).key_send_component == NULL) {
	    child = component;
	} else {
	    child = SpFrameArch(component).key_send_component;
	}
	
	if (spIsVisible(child) == SP_TRUE
	    && SpPrimitiveArch(child).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(child).map_flag == SP_TRUE) {
	    do {
		if (modifiers & shiftKey) {
		    child = SpPrimitiveArch(child).prev_key_send;
		    if (child == SpFrameArch(component).key_send_component) {
			break;
		    } else if (child == NULL || spIsFrame(child) == SP_TRUE) {
			if (SpFrameArch(component).key_send_component == NULL) {
			    break;
			} else {
			    child = SpPrimitiveArch(component).prev_key_send;
			}
		    }
		    spDebug(100, "spHandleRawKeyDownMac", "invert search: %s\n", spGetTitle(child));
		} else {
		    child = SpPrimitiveArch(child).next_key_send;
		    if (child == SpFrameArch(component).key_send_component) {
			break;
		    } else if (child == NULL) {
			if (SpFrameArch(component).key_send_component == NULL) {
			    break;
			} else {
			    child = SpPrimitiveArch(component).next_key_send;
			}
		    }
		    spDebug(100, "spHandleRawKeyDownMac", "search: %s\n", spGetTitle(child));
		}
			    
		if (spIsVisible(child) == SP_TRUE
		    && spIsFrame(child) == SP_FALSE
		    && SpPrimitiveArch(child).sensitive_flag == SP_TRUE
		    && SpPrimitiveArch(child).map_flag == SP_TRUE) {
		    spFocusComponentMac(component, child);
		    /*flag = SP_TRUE;*/
		    break;
		}
	    } while (child != NULL);
	    
	    spDebug(50, "spHandleRawKeyDownMac", "search for tab key done\n");
	    flag = SP_TRUE;
	}
    }

    return flag;
}

spBool spHandleKeyDownMac(EventRecord *event)
{
    char key;
    int keycode;
    spBool flag = SP_FALSE;
    UInt32 message = 0;
    WindowPtr window;
    spComponent component;

    spDebug(50, "spHandleKeyDownMac", "in\n");
    
    if (spGetAppearanceVersionMac() >= 0x00000101) {
	message = MenuEvent(event);
	if (HiWord(message) == 0) {
	    message = 0;
	}
    } else {
	if ((cmdKey & event->modifiers) != 0) {
	    message = MenuKey(charCodeMask & event->message);
	}
    }
    
    if (message) {
        return spHandleMenuChoiceMac(message);
    } else {
	window = FrontWindow();
	
	if ((component = spGetWindowReferenceMac(window)) == NULL
	    || spIsFrame(component) == SP_FALSE) {
	    return SP_FALSE;
	}
	
	keycode = (event->message & keyCodeMask) >> 16;
	key = charCodeMask & event->message;
	spDebug(10, "spHandleKeyDownMac", "key down: %d\n", (int)key);

	if (SpFrameArch(component).key_func != NULL) {
	    SpFrameArch(component).key_func(SpFrameArch(component).data, (long)event->message);
	}

	if (spHandleDefaultButton(component, key) == SP_TRUE) {
	    flag = SP_TRUE;
	} else if (spHandleRawKeyDownMac(component, event->modifiers, key) == SP_TRUE) {
	    flag = SP_TRUE;
	} else if (spHandleListKeyDownMac(SpFrameArch(component).key_send_component,
					  event->modifiers, keycode, key) == SP_TRUE) {
	    flag = SP_TRUE;
	} else if (spHandleTextKeyDownMac(SpFrameArch(component).key_send_component,
					  event->modifiers, keycode, key) == SP_TRUE) {
	    flag = SP_TRUE;
	} else if (spHandleCanvasKeyDownMac(SpFrameArch(component).key_send_component, event) == SP_TRUE) {
	    flag = SP_TRUE;
	}
    }
    
    return flag;
}

spBool spHandleUpdateEventMac(EventRecord *event)
{
    WindowPtr window;
    /*GrafPtr save_port;*/
    spComponent component;

    window = (WindowPtr)event->message;
    component = spGetWindowReferenceMac(window);

    BeginUpdate(window);
	
    spUpdateWindowMac(component);
	
    EndUpdate(window);

    return SP_TRUE;
}

static Point sp_prev_balloon_point = {0, 0};

spBool spHandleComponentMouseMoveMac(spComponent component, EventRecord *event, Point point)
{
    Rect rect;
    spBool set_cursor = SP_FALSE;
    spBool button_down = SP_FALSE;
    spBool moved = SP_FALSE;
    spBool flag = SP_FALSE;
    spComponent next;
    spCallbackReason call_reason;
    spMouseButton button;
    unsigned long sec = 0;
    static unsigned long prev_sec = 0;
    
    if (SpPrimitiveArch(component).next_need_move_call == NULL) {
	return SP_FALSE;
    }

    if (!EqualPt(point, sp_prev_balloon_point)) {
	moved = SP_TRUE;
    }
    spDebug(80, "spHandleComponentMouseMoveMac", "moved = %d\n", moved);
    
    GetDateTime(&sec);
    
    next = SpPrimitiveArch(component).next_need_move_call;
    while (next != NULL) {
	if (spIsVisible(next) == SP_TRUE
	    && SpPrimitiveArch(next).sensitive_flag == SP_TRUE
	    && SpPrimitiveArch(next).map_flag == SP_TRUE
	    && SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
	    Boolean in_rect;
	    Boolean still_down;
	    
	    rect = SpPrimitiveArch(next).rect;

	    in_rect = PtInRect(point, &rect);
	    still_down = StillDown();
	    
	    if (in_rect || (still_down && next == sp_drag_component)) {
		if (moved == SP_TRUE) {
		    if (spIsCanvas(next) == SP_TRUE) {
			spSetCanvasCursorMac(next);
			set_cursor = SP_TRUE;
		    }
		    spDebug(80, "spHandleComponentMouseMoveMac",
			    "%s: in_rect = %d, still_down = %d, x = %d, y = %d\n",
			    SpGetClassName(next), in_rect, still_down, point.h, point.v);
		    
		    if (still_down && component == sp_drag_window) { /* button down */
			button = spGetPressedMouseButtonMac(event->modifiers);
			
			if (button == SP_RBUTTON) {
			    call_reason = SP_CR_RBUTTON_MOTION;
			} else if (button == SP_MBUTTON) {
			    call_reason = SP_CR_MBUTTON_MOTION;
			} else {
			    call_reason = SP_CR_LBUTTON_MOTION;
			}
			if (spPostMessageMac(next, SP_BUTTON_MOTION_CALLBACK, call_reason) == SP_TRUE) {
			    flag = SP_TRUE;
			}
			button_down = SP_TRUE;
		    }
		    if (spPostMessageMac(next, SP_POINTER_MOTION_CALLBACK,
					 SP_CR_POINTER_MOTION) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		} else if (in_rect && !still_down) {
		    flag = spShowToolTipMac(next, point, sec - prev_sec);
		}
	    }
	}

	next = SpPrimitiveArch(next).next_need_move_call;
    }

    if (moved == SP_TRUE) {
	spHideToolTipMac(event);
		    
	if (component != sp_drag_window && set_cursor == SP_FALSE && button_down == SP_FALSE) {
	    spUnsetCursorMac();
	}
	prev_sec = sec;
    }
    sp_prev_balloon_point = point;

    return flag;
}

spBool spHandleIdleMac(EventRecord *event)
{
    spComponent component;
    spComponent text;
    WindowPtr window;
    Point point;
    GrafPtr save_port;
    spBool flag = SP_FALSE;

    window = FrontWindow();
    
    if ((component = spGetWindowReferenceMac(window)) == NULL
	|| spIsFrame(component) == SP_FALSE
	|| component != sp_current_window) {
	return SP_FALSE;
    }
	
    spLockWindowPort(window, &save_port);

    if (spIsText(SpFrameArch(component).key_send_component) == SP_TRUE) {
	text = SpFrameArch(component).key_send_component;
	if (SpTextPart(text).editable == SP_TRUE
	    && SpPrimitiveArch(text).sensitive_flag == SP_TRUE
	    && SpTextArch(text).text != NULL
	    && SpTextArch(text).activated == SP_TRUE) {
	    spGetOriginalRGBMac(); spSetNormalRGBMac();
	    TEIdle(SpTextArch(text).text);
	    /*InitCursor();*/
	    spSetOriginalRGBMac();
	    
	    flag = SP_TRUE;
	}
    }
    
    spUnlockWindowPort(window, save_port);

    if (1 || flag == SP_FALSE) {
	spLockWindowPort(window, &save_port);
	point = event->where;
	GlobalToLocal(&point);
	spUnlockWindowPort(window, save_port);
	flag = spHandleComponentMouseMoveMac(component, event, point);
    }

    
    return flag;
}

spBool spHandleEventMac(EventRecord *event)
{
    spDebug(50, "spHandleEventMac", "in\n");

    if (spHideToolTipMac(event) == SP_TRUE) {
	sp_prev_balloon_point.v = sp_prev_balloon_point.h = 0;
    }

    switch (event->what) {
      case kHighLevelEvent:
	AEProcessAppleEvent(event);
	return SP_TRUE;
      case osEvt:
	return spHandleOSEventMac(event);
      case activateEvt:
	return spHandleActivateEventMac(event);
      case mouseDown:
	return spHandleMouseDownMac(event);
      case mouseUp:
	return spHandleMouseUpMac(event);
      case updateEvt:
	return spHandleUpdateEventMac(event);
      case keyUp:
	return spHandleKeyUpMac(event);
      case keyDown:
      case autoKey:
	return spHandleKeyDownMac(event);
      default:
	break;
    }
    
    spDebug(50, "spHandleEventMac", "done\n");
    
    return SP_FALSE;
}

#if TARGET_API_MAC_CARBON
spBool spHandleMouseMoveEventMac(WindowRef window, spBool drag_flag, int button_id,
				 EventModifiers modifiers, Point point)
{
    Rect rect;
    spBool flag = SP_FALSE;
    spBool set_cursor = SP_FALSE;
    spComponent next;
    spComponent component;
    spCallbackReason call_reason;
    spMouseButton button;
    
    if ((component = spGetWindowReferenceMac(window)) != NULL
	&& spIsFrame(component) == SP_TRUE && component == sp_current_window
	&& SpPrimitiveArch(component).next_need_move_call != NULL) {
	
	spDebug(100, "spHandleMouseMoveEventMac", "x = %d, y = %d\n", point.h, point.v);
	
	next = SpPrimitiveArch(component).next_need_move_call;
	while (next != NULL) {
	    if (spIsVisible(next) == SP_TRUE
		&& SpPrimitiveArch(next).sensitive_flag == SP_TRUE
		&& SpPrimitiveArch(next).map_flag == SP_TRUE
		&& SpComponentPart(next).current_width > 0 && SpComponentPart(next).current_height > 0) {
		rect = SpPrimitiveArch(next).rect;

		/*spDebug(100, "spHandleMouseMoveEventMac", "%s: x = %d, y = %d\n",
		  SpGetClassName(next), point.h, point.v);*/
	    
		if (PtInRect(point, &rect)
		    || (drag_flag == SP_TRUE && next == sp_drag_component)) {
		    if (spIsCanvas(next) == SP_TRUE) {
			spSetCanvasCursorMac(next);
			set_cursor = SP_TRUE;
		    }
		    if (drag_flag == SP_TRUE && component == sp_drag_window) {
			spDebug(100, "spHandleMouseMoveEventMac", "%s drag: x = %d, y = %d\n",
				SpGetClassName(next), point.h, point.v);
			
			if (button_id > 1) {
			    button = button_id - 1;
			} else {
			    button = spGetPressedMouseButtonMac(modifiers);
			}
			
			if (button == SP_RBUTTON) {
			    call_reason = SP_CR_RBUTTON_MOTION;
			} else if (button == SP_MBUTTON) {
			    call_reason = SP_CR_MBUTTON_MOTION;
			} else {
			    call_reason = SP_CR_LBUTTON_MOTION;
			}
			if (spPostMessageMac(next, SP_BUTTON_MOTION_CALLBACK, call_reason) == SP_TRUE) {
			    flag = SP_TRUE;
			}
		    }
		    if (spPostMessageMac(next, SP_POINTER_MOTION_CALLBACK,
					 SP_CR_POINTER_MOTION) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		}
	    }

	    next = SpPrimitiveArch(next).next_need_move_call;
	}
    }

    if (component != sp_drag_window && set_cursor == SP_FALSE) {
	spUnsetCursorMac();
    }
    
    return flag;
}

spBool spHandleMouseEventMac(WindowRef window, unsigned long ekind, EventRef event)
{
    spBool flag = SP_FALSE;
    unsigned long mod;
    EventModifiers modifiers;
    Point point;
    Rect rect;
    EventMouseButton button = kEventMouseButtonPrimary;
    CGrafPtr save_port;
    spComponent component;
		    
    if (window != NULL && (component = spSearchWindowMac(window)) != NULL) {
	WindowPartCode part;
	WindowRef foundWindow = NULL;
	
	GetEventParameter(event, kEventParamMouseLocation, typeQDPoint, NULL, sizeof(Point), NULL, &point);
	GetEventParameter(event, kEventParamKeyModifiers, typeUInt32, NULL, sizeof(unsigned long), NULL, &mod);
	modifiers = (EventModifiers)mod;

	part = FindWindow(point, &foundWindow);
	    
	spDebug(100, "spHandleMouseEventMac", "mouse event: window part = %d\n", part);
	    
	switch (ekind)
	{
	  case kEventMouseDown:
		
	    spDebug(80, "spHandleMouseEventMac", "received mouse down: part = %d\n", part);
	    if (window == foundWindow && part == inContent) {
		GetEventParameter(event, kEventParamMouseButton, typeMouseButton, NULL,
				  sizeof(EventMouseButton), NULL, &button);
		    
		spLockWindowPort(window, &save_port);
		GlobalToLocal(&point);
		spUnlockWindowPort(window, save_port);
	    
		if (spHandleComponentMouseDownMac(foundWindow, button, modifiers, point) == SP_TRUE) {
		    flag = SP_TRUE;
		}
	    }
	    break;
	    
	  case kEventMouseUp:
	  case kEventMouseDragged:

	    spDebug(80, "spHandleMouseEventMac", "received mouse up or drag\n");
	    if (sp_drag_window != NULL) {
		GetEventParameter(event, kEventParamMouseButton, typeMouseButton, NULL,
				  sizeof(EventMouseButton), NULL, &button);
		    
		spLockWindowPort(SpPrimitiveArch(sp_drag_window).window, &save_port);
		GlobalToLocal(&point);
		spUnlockWindowPort(SpPrimitiveArch(sp_drag_window).window, save_port);

		if (ekind == kEventMouseUp) {
		    if (spHandleComponentMouseUpMac(SpPrimitiveArch(sp_drag_window).window,
						    button, modifiers, point) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		} else if (ekind == kEventMouseDragged) {
		    spDebug(80, "spHandleMouseEventMac", "drag: x = %d, y = %d\n", point.h, point.v);
		    if (spHandleMouseMoveEventMac(SpPrimitiveArch(sp_drag_window).window,
						  SP_TRUE, button, modifiers, point) == SP_TRUE) {
			flag = SP_TRUE;
		    }
		}
	    }
	    
	    break;
	    
	  case kEventMouseMoved:

	    spLockWindowPort(window, &save_port);
	    GlobalToLocal(&point);
	    spUnlockWindowPort(window, save_port);
	    
	    spDebug(80, "spHandleMouseEventMac", "process mouse move event: %ld\n", window);
	    if (spHandleMouseMoveEventMac(window, SP_FALSE, 0, modifiers, point) == SP_TRUE) {
		flag = SP_TRUE;
	    }
	    break;

	  case kEventMouseWheelMoved:
	    {
		EventMouseWheelAxis axis;
		long wheelDelta;
			
		GetEventParameter(event, kEventParamMouseWheelAxis, typeMouseWheelAxis,
				  NULL, sizeof(EventMouseWheelAxis), NULL, &axis);
		GetEventParameter(event, kEventParamMouseWheelDelta, typeLongInteger,
				  NULL, sizeof(long), NULL,  &wheelDelta);

		spDebug(50, "spHandleMouseEventMac", "wheel axis: %d, wheel delta: %ld, key_send = %ld\n",
			axis, wheelDelta, SpFrameArch(component).key_send_component);
		    
		if (spIsFrame(component) == SP_TRUE && SpFrameArch(component).key_send_component != NULL) {
		    if (spIsText(SpFrameArch(component).key_send_component) == SP_TRUE) {
			if (spIsSubClass(SpFrameArch(component).key_send_component, SpTextArea) == SP_TRUE) {
			    spComponent text = SpFrameArch(component).key_send_component;
			
			    spLockWindowPort(SpPrimitiveArch(component).window, &save_port);
			    spGetOriginalRGBMac(); spSetNormalRGBMac();
			    TEPinScroll(0, (short)wheelDelta * (*SpTextArch(text).text)->lineHeight, SpTextArch(text).text);
			    rect = (*SpTextArch(text).text)->viewRect;
			    TEUpdate(&rect, SpTextArch(text).text);
			    spSetOriginalRGBMac();
			    spUnlockWindowPort(SpPrimitiveArch(component).window, save_port);
			} else if (spIsComboBox(SpFrameArch(component).key_send_component) == SP_TRUE) {
			    spScrollListMac(SpFrameArch(component).key_send_component, -wheelDelta);
			}
			flag = SP_TRUE;
		    } else if (spIsCanvas(SpFrameArch(component).key_send_component) == SP_TRUE) {
			spComponent canvas = SpFrameArch(component).key_send_component;
			
			spDebug(50, "spHandleMouseEventMac", "canvas wheel delta: %ld\n", wheelDelta);

			SpPrimitiveArch(canvas).event.modifiers = 0;
			if (wheelDelta > 0) {
			    SpPrimitiveArch(canvas).event.message = kPageUpCharCode;
			} else {
			    SpPrimitiveArch(canvas).event.message = kPageDownCharCode;
			}
			SpPrimitiveArch(canvas).event.what = keyDown;
			spPostMessageMac(canvas, SP_KEY_PRESS_CALLBACK, SP_CR_KEY_PRESS);
			
			SpPrimitiveArch(canvas).event.what = keyUp;
			spPostMessageMac(canvas, SP_KEY_RELEASE_CALLBACK, SP_CR_KEY_RELEASE);
			flag = SP_TRUE;
		    } else if (SpPrimitiveArch(SpFrameArch(component).key_send_component).control != NULL) {
			int keycode;
			
			keycode = (wheelDelta > 0 ? 116 /*page up*/ : 121/*page down*/);
			if (HandleControlKey(SpPrimitiveArch(SpFrameArch(component).key_send_component).control,
					     keycode, 0, 0) == kControlNoPart) {
			    flag = SP_TRUE;
			}
		    }
		}
	    }
	    break;
		
	  default:
	    break;
	}
    }

    return flag;
}

static pascal OSStatus appEventHandler(EventHandlerCallRef callRef, EventRef event, void *userData)
{
    short err = eventNotHandledErr;
    unsigned long ekind;
    long eclass;
    int menu_id;
    HICommand cmd;
    WindowRef window;
    spComponent component;
    
    eclass = GetEventClass(event);
    ekind = GetEventKind(event);
    
    if (eclass == kEventClassAppleEvent) {
	EventRecord evrec;

	if (ConvertEventRefToEventRecord(event, &evrec)) {
	    if (AEProcessAppleEvent(&evrec) == noErr) {
		err = noErr;
	    }
	}
	spDebug(50, "appEventHandler", "apple event received\n");
    } else {
	if (eclass == kEventClassMouse) {
	    spDebug(100, "appEventHandler", "mouse event, event kind: %ld\n", ekind);
	    if (spHandleMouseEventMac(FrontWindow(), ekind, event) == SP_TRUE) {
		err = noErr;
	    }
	} else if (eclass == kEventClassMenu) {
	    MenuRef menu;
	    MenuItemIndex item_id;
	    spComponent menu_item;
	    
	    spDebug(100, "appEventHandler", "menu event, event kind: %ld\n", ekind);
	    
	    if ((window = FrontWindow()) != NULL && (component = spSearchWindowMac(window)) != NULL) {
		switch (ekind)
		{
		  case kEventMenuTargetItem:
		    GetEventParameter(event, kEventParamDirectObject, typeMenuRef, NULL, sizeof(MenuRef), NULL, &menu);
		    GetEventParameter(event, kEventParamMenuItemIndex, typeMenuItemIndex,
				      NULL, sizeof(MenuItemIndex), NULL, &item_id);
		    menu_id = GetMenuID(menu);
		    if ((menu_item = spFindMenuItemMac(component, menu_id, item_id)) != NULL
			&& !strnone(SpGetDescription(menu_item))) {
			spSetHelpStatusText(component, SpGetDescription(menu_item));
		    } else {
			spSetHelpStatusText(component, "");
		    }
	
		    break;

#if 0
		  case kEventMenuOpening:
		    spDebug(100, "appEventHandler", "kEventOpening\n");
		    break;
		  case kEventMenuClosed:
		    spDebug(100, "appEventHandler", "kEventClosed\n");
		    break;
		  case kEventMenuMatchKey:
		    spDebug(100, "appEventHandler", "kEventMenuMatchKey\n");
		    break;
		  case kEventMenuBeginTracking:
		    spDebug(100, "appEventHandler", "kEventMenuBeginTracking\n");
		    break;
		  case kEventMenuEndTracking:
		    spDebug(100, "appEventHandler", "kEventMenuEndTracking\n");
		    break;
		  case kEventMenuEnableItems:
		    spDebug(100, "appEventHandler", "kEventMenuEnableItems\n");
		    break;
#endif
	    
		  default:
		    break;
		}
	    }
	} else if (eclass == kEventClassCommand) {
	    switch (ekind)
	    {
	      case kEventCommandProcess:
			
		GetEventParameter(event, kEventParamDirectObject, typeHICommand, NULL, sizeof(HICommand), NULL, &cmd);
		spDebug(50, "appEventHandler", "command: attributes = %ld, command_id = %ld\n",
			cmd.attributes, cmd.commandID);

		if (cmd.menu.menuRef != NULL) {
		    menu_id = GetMenuID(cmd.menu.menuRef);
		    spDebug(50, "appEventHandler", "command: menu_id = %d\n", menu_id);

		    if (spHandleRootMenuChoiceMac(menu_id, cmd.menu.menuItemIndex) == SP_TRUE) {
			if (sp_current_window != NULL) {
			    spSetHelpStatusText(sp_current_window, "");
			}
			err = noErr;
		    }
		} else {
#ifdef MACOSX
		    CallNextEventHandler(callRef, event);
		    
		    if (spSetDialogResponseMacX(cmd.commandID) == SP_TRUE) {
			if (spQuitCurrentSheetDialogMacX() == SP_TRUE) {
			    spDebug(10, "appEventHandler", "quit sheet done\n");
			    err = noErr;
			}
		    }
#endif
		}
		break;

	      default:
		break;
	    }
	}
    
	spDebug(80, "appEventHandler", "err = %d (eventNotHandledErr = %d)\n", err, eventNotHandledErr);
    }
    
    return err;
}

EventHandlerUPP spNewAppEventHandlerUPP(void)
{
    return NewEventHandlerUPP(appEventHandler);
}

static void updateToolTip(spComponent parent)
{
    spComponent next;
    GrafPtr save_port;
	
    if (SpPrimitiveArch(parent).next_need_update != NULL) {
	spLockWindowPort(SpPrimitiveArch(parent).window, &save_port);
    
	next = SpPrimitiveArch(parent).next_need_update;
	while (next != NULL) {
	    if (spIsVisible(next) == SP_TRUE) {
		if (SpPrimitiveArch(next).map_flag == SP_TRUE) {
		    spSetToolTipMac(next);
		}
	    }
	    next = SpPrimitiveArch(next).next_need_update;
	}
	
	spUnlockWindowPort(SpPrimitiveArch(parent).window, save_port);
    }

    spDebug(80, "updateToolTip", "done\n");
    
    return;
}

static pascal OSStatus windowEventHandler(EventHandlerCallRef callRef, EventRef event, void *userData)
{
    short err = eventNotHandledErr;
    spComponent component;
    long eclass;
    unsigned long ekind, ctype;
    CGrafPtr save_port;
    WindowRef window = NULL;
    short part;
    Point point;
    Rect rect;
    
    eclass = GetEventClass(event);
    ekind = GetEventKind(event);
    
    if (eclass == kEventClassWindow)
    {
	GetEventParameter(event, kEventParamDirectObject, typeWindowRef, NULL, sizeof(WindowRef), NULL, &window);

	spDebug(80, "windowEventHandler", "event class: %ld, event kind: %ld\n", eclass, ekind);
    
	switch (ekind)
	{
	  case kEventWindowDrawFrame:
	  case kEventWindowDrawPart:
	  case kEventWindowDrawGrowBox:
	  case kEventWindowPaint:
	    break;
	    
	  case kEventWindowActivated:
	    
	    CallNextEventHandler(callRef, event);
	    
	    if ((component = spGetWindowReferenceMac(window)) != NULL) {
		spActivateComponentMac(component, SP_TRUE);
		err = noErr;
	    }
	    break;
				
	  case kEventWindowDeactivated:
			
	    CallNextEventHandler(callRef, event);
	    
	    if ((component = spGetWindowReferenceMac(window)) != NULL) {
		spDeactivateComponentMac(component, SP_TRUE);
		err = noErr;
	    }
	    break;
				
	  case kEventWindowDrawContent:

	    CallNextEventHandler(callRef, event);
	    
	    if ((component = spGetWindowReferenceMac(window)) != NULL) {
		spUpdateWindowMac(component);
		err = noErr;
	    }
	    break;

	  case kEventWindowClose:

	    if ((component = spGetWindowReferenceMac(window)) == NULL) {
		DisposeWindow(window);
	    } else {
		spHandleCloseWindowMac(component);
	    }
	    err = noErr;
	    break;

	  case kEventWindowZoom:
	  case kEventWindowResizeCompleted:
	  case kEventWindowBoundsChanging:
	  case kEventWindowBoundsChanged:

	    if (ekind == kEventWindowZoom) {
		if (GetWindowStandardState (window, &rect) == noErr) {
		    point.h = rect.right - rect.left;
		    point.v = rect.bottom - rect.top;
		    if (IsWindowInStandardState(window, NULL, NULL)) {
			part=inZoomIn;
		    } else {
			part=inZoomOut;
		    }
		    ZoomWindowIdeal(window, part, &point);
		    err = noErr;
		}
	    } else if (ekind == kEventWindowBoundsChanging
		       || ekind == kEventWindowBoundsChanged) {
		GetEventParameter(event, kEventParamAttributes, typeUInt32, NULL,
				  sizeof(unsigned long), NULL, &ctype);
		if (ctype & kWindowBoundsChangeSizeChanged) {
		    err = noErr;
		}
	    } else {
		err = noErr;
	    }

	    if (IsWindowVisible(window) && err == noErr) {
		spLockMainMutexForMainMac();
		
		spLockWindowPort(window, &save_port);
		spGetPortRectMac(window, &rect);
		EraseRect(&rect);
		spUnlockWindowPort(window, save_port);
		spInvalRectMac(window, &rect);
		
		spHandleResizeMac(window);
		
		spUnlockMainMutexForMainMac();
	    }
	    
	    break;
			
	  case kEventWindowGetClickActivation:
	    if (spSelectWindowMac(window, SP_FALSE) == SP_TRUE) {
		err = noErr;
	    }
	    break;
		    
	  /*case kEventWindowClickDragRgn:*/
	  case kEventWindowClickResizeRgn:
	  case kEventWindowClickCollapseRgn:
	  case kEventWindowClickCloseRgn:
	  case kEventWindowClickZoomRgn:
	  case kEventWindowClickContentRgn:
	  case kEventWindowClickProxyIconRgn:
	  case kEventWindowClickToolbarButtonRgn:
	    if (spFindModalWindowMac(window, SP_TRUE) == SP_TRUE) {
		err = noErr;
	    } else if (ekind == kEventWindowClickToolbarButtonRgn) {
		if ((component = spGetWindowReferenceMac(window)) != NULL) {
		    spLockMainMutexForMainMac();
		    spPostMessageMac(component, SP_SIMPLIFY_CALLBACK, SP_CR_SIMPLIFY);
		    spUnlockMainMutexForMainMac();
		    err = noErr;
		}
	    }
	    break;
	    
	  default:
	    break;
	}

	if (ekind == kEventWindowBoundsChanged) {
	    if ((component = spGetWindowReferenceMac(window)) != NULL) {
		updateToolTip(component);
	    }
	}
    }
    else if (eclass == kEventClassKeyboard)
    {
	char key;
	unsigned long keycode, modifiers;
    
	if ((window = FrontWindow()) != NULL
	    && (component = spGetWindowReferenceMac(window)) != NULL
	    && spIsFrame(component) == SP_TRUE) {
	    switch (ekind)
	    {
	      case kEventRawKeyDown:
	      case kEventRawKeyRepeat:

		GetEventParameter(event, kEventParamKeyMacCharCodes, typeChar, NULL, sizeof(char), NULL, &key);
		GetEventParameter(event, kEventParamKeyModifiers, typeUInt32, NULL, sizeof(long), NULL, &modifiers);
		GetEventParameter(event, kEventParamKeyCode, typeUInt32, NULL, sizeof(long), NULL, &keycode);
		    
		spDebug(50, "windowEventHandler", "keycode = %ld, key = %c\n", keycode, key);

		if (spIsText(SpFrameArch(component).key_send_component) == SP_FALSE
		    && spHandleDefaultButton(component, key) == SP_TRUE) {
		    /* don't handle default button message in the text control area,
		       because confirming Japanese text will emit this message. */
		    err = noErr;
		} else if (spHandleRawKeyDownMac(component, (EventModifiers)modifiers, key) == SP_TRUE) {
		    err = noErr;
		} else {
		    EventRecord evrec;
		    
		    if (ConvertEventRefToEventRecord(event, &evrec)) {
			if (spHandleCanvasKeyDownMac(SpFrameArch(component).key_send_component,
						     &evrec) == SP_TRUE) {
			    err = noErr;
			}
		    }
		}
		break;
	    }
	}
    }
    
    /*spDebug(80, "windowEventHandler", "err = %d\n", err);*/
    
    return err;
}

EventHandlerUPP spNewWindowEventHandlerUPP(void)
{
    return NewEventHandlerUPP(windowEventHandler);
}

static pascal OSStatus controlEventHandler(EventHandlerCallRef callRef, EventRef event, void *userData)
{
    short err = eventNotHandledErr;
    unsigned long ekind;
    long eclass;
    spComponent component;
    ControlPartCode part;
    ControlRef control;
    CGrafPtr save_port;
    Point point;
    Rect rect;

    component = (spComponent)userData;
    
    eclass=GetEventClass(event);
    ekind=GetEventKind(event);
    
    GetEventParameter(event, kEventParamDirectObject, typeControlRef,
		      NULL, sizeof(ControlRef), NULL, &control);

    if (component != NULL && eclass == kEventClassControl && ekind == kEventControlDraw) {
	spDebug(50, "controlEventHandler", "%s: draw\n", SpGetClassName(component));
	
	/* the following code was added to avoid a crash caused by pthreads */
	spLockControlMutexMac();
	spLockPortMutexMac();
	err = CallNextEventHandler(callRef, event);
	spUnlockPortMutexMac();

	if (spIsToolItem(component) == SP_TRUE && spUseBevelButtonForToolItemMac() == SP_FALSE) {
	    if (SpPrimitiveArch(component).sensitive_flag == SP_FALSE
		|| SpFrameArch(SpGetWindow(component)).activate_flag == SP_FALSE) {
		spDrawToolItemMac(component, SP_FALSE);
	    } else {
		spDrawToolItemMac(component, SP_TRUE);
	    }
	} else if (spIsComboBox(component) == SP_TRUE
		   && control == SpComboBoxArch(component).button) {
	    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
	    spDrawComboBoxMac(component);
	    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
	}
	spUnlockControlMutexMac();
	
	spDebug(50, "controlEventHandler", "%s: err = %d\n", SpGetClassName(component), err);
	
	return err;
    }
	
    if (component == NULL) {
	return err;
    }

    spDebug(100, "controlEventHandler", "%s: event class: %ld, event kind: %ld\n",
	    SpGetClassName(component), eclass, ekind);

    if (spIsButton(component) == SP_TRUE || spIsToolItem(component) == SP_TRUE) {
	if (eclass == kEventClassControl) {
	    switch (ekind)
	    {
	      case kEventControlHit:
		spDebug(80, "controlEventHandler", "%s hit\n",	SpGetClassName(component));
		if (spIsToggleButton(component) == SP_TRUE) {
		    if (spToggleComponentMac(component) == SP_TRUE
			&& spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED) == SP_TRUE) {
			err = noErr;
		    }
		} else {
		    if (spPostMessageMac(component, SP_ACTIVATE_CALLBACK, SP_CR_ACTIVATE) == SP_TRUE) {
			err = noErr;
		    }
		}
		break;
		    
	      default:
		break;
	    }
	}
    } else if (spIsComboBox(component) == SP_TRUE
	       && control == SpComboBoxArch(component).button) {
	SInt16 index = -1;
	Size realSize;
	
	spDebug(50, "controlEventHandler", "receive event for combo box\n");
	
	if (eclass == kEventClassControl) {
	    switch (ekind)
	    {
	      case kEventControlClick:
		if (spUseBevelButtonForComboButtonMac() == SP_FALSE) {
		    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);
		    GetMouse(&point);
		    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
		    spGetTextFrameRectMac(component, &rect);

		    spHandleComboBoxMouseDownMac(component, point, rect);
		    err = noErr;
		}
		break;
		
	      case kEventControlHit:

		if (spUseBevelButtonForComboButtonMac() == SP_TRUE) {
		    if (GetControlData(SpComboBoxArch(component).button, 0, kControlBevelButtonMenuValueTag,
				       sizeof(SInt16), (Ptr)&index, &realSize) == noErr) {
			spSelectListIndexArch(component, index - 1);
			spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK, SP_CR_VALUE_CHANGED);
			err = noErr;
		    }
		}
		break;
		
	      default:
		break;
	    }
	}
    } else if (spIsContainer(component) == SP_TRUE) {
	spDebug(50, "controlEventHandler", "%s: event class: %ld, event kind: %ld\n",
		SpGetClassName(component), eclass, ekind);
	
	if (eclass == kEventClassControl) {
	    switch (ekind)
	    {
	      case kEventControlHit:
		if (spIsTabBox(component) == SP_TRUE
		    && SpPrimitiveArch(component).control == control) {	/* Sometimes this is different control. Why? */
		    GetEventParameter(event, kEventParamControlPart, typeControlPartCode,
				      NULL, sizeof(ControlPartCode), NULL, &part);
		    spDebug(50, "controlEventHandler", "tab control part = %d\n", part);
		    spSelectTabItemMac(component, part);
		}
		break;

	      default:
		break;
	    }
	}
    } else if (spIsText(component) == SP_TRUE || spIsSubClass(component, SpList) == SP_TRUE) {
	spDebug(80, "controlEventHandler", "%s: event class: %ld, event kind: %ld\n",
		SpGetClassName(component), eclass, ekind);
	
	if (eclass == kEventClassControl) {
	    switch (ekind)
	    {
	      case kEventControlClick:
	      case kEventControlHit:

		spDebug(80, "controlEventHandler", "text clicked\n");
	    
		if (spIsText(component) == SP_TRUE
		    && SpTextPart(component).editable == SP_FALSE && spIsComboBox(component) == SP_FALSE) {
		    spDebug(80, "controlEventHandler", "not editable text\n");
		    err = noErr;
		} else {
		    if (ekind == kEventControlHit) {
			if (spIsSubClass(component, SpList) == SP_TRUE) {
			    GetEventParameter(event, kEventParamControlPart, typeControlPartCode,
					      NULL, sizeof(ControlPartCode), NULL, &part);
			    spDebug(50, "controlEventHandler", "list control part = %d\n", part);
			    if (spHandleListValueChangedMac(component, part) == SP_TRUE) {
				err = noErr;
			    }
			} else if (spIsText(component) == SP_TRUE) {
			    spChangeEditMenuStateMac(SpGetWindow(component));
			}
		    } else if (spFocusComponentMac(SpGetWindow(component), component) == SP_TRUE) {
			err = noErr;
		    }
		}
		
		break;

#if 0
	      case kEventControlActivate:
	      case kEventControlDeactivate:
	      case kEventControlSetFocusPart:
#endif
	      case kEventControlTrack:
	      case kEventControlSetCursor:
		if (spIsText(component) == SP_TRUE && SpTextPart(component).editable == SP_FALSE) {
		    err = noErr;
		}
		break;
		
	      default:
		break;
	    }
	} else if (eclass == kEventClassTextInput) {
	    CharsHandle hchars;
	    char key = 0;
	    unsigned long keycode, modifiers;
	    EventRef rawKeyEvent;
	    
	    switch (ekind)
	    {
	      case kEventTextInputUnicodeForKeyEvent:
	      case kEventTextInputShowHideBottomWindow:

		if (ekind == kEventTextInputUnicodeForKeyEvent) {
		    if (GetEventParameter(event, kEventParamTextInputSendKeyboardEvent, typeEventRef,
					  NULL, sizeof(EventRef), NULL, &rawKeyEvent) == noErr) {
			GetEventParameter(rawKeyEvent, kEventParamKeyMacCharCodes, typeChar, NULL, sizeof(char), NULL, &key);
			GetEventParameter(event, kEventParamKeyModifiers, typeUInt32, NULL, sizeof(long), NULL, &modifiers);
			GetEventParameter(event, kEventParamKeyCode, typeUInt32, NULL, sizeof(long), NULL, &keycode);
			spDebug(50, "controlEventHandler", "kEventTextInputUnicodeForKeyEvent: key = %c\n", key);
			
			if (spHandleDefaultButton(SpGetWindow(component), key) == SP_TRUE) {
			    err = noErr;
			} else if (spHandleTextActivateKeyDownMac(component, key) == SP_TRUE) {
			    err = noErr;
			} else if (spHandleListKeyDownMac(component, (EventModifiers)modifiers, (int)keycode, key) == SP_TRUE) {
			    err = noErr;
			} else if (spHandleExceedTextMac(component, key, 1) == SP_TRUE) {
			    err = noErr;
			} else if (SpTextPart(component).editable == SP_FALSE) {
			    err = noErr;
			}
		    }

		    if (err != noErr) CallNextEventHandler(callRef, event);
		}
		
		spDebug(50, "controlEventHandler", "key = %d\n", key);
		
		if (spIsText(component) == SP_TRUE && err != noErr
		    && spIsTextCursorMoveKeyMac(key) == SP_FALSE) {
		    hchars = TEGetText(SpTextArch(component).text);
		    HLock((Handle)hchars);

		    spChangeEditMenuStateMac(SpGetWindow(component));
		    spPostMessageMac(component, SP_VALUE_CHANGED_CALLBACK,
				     SP_CR_VALUE_CHANGED);
		    err = noErr;
		    
		    HUnlock((Handle)hchars);
		}
	    }
	}
	
	spDebug(80, "controlEventHandler", "err = %d\n", err);
    } else if (spIsSlider(component) == SP_TRUE) {
	spDebug(80, "controlEventHandler", "%s: event class: %ld, event kind: %ld\n",
		SpGetClassName(component), eclass, ekind);
	
	if (eclass == kEventClassControl) {
	    switch (ekind)
	    {
	      case kEventControlHit:
		if (SpSliderPart(component).track_call_on == SP_FALSE) {
		    GetEventParameter(event, kEventParamControlPart, typeControlPartCode,
				      NULL, sizeof(ControlPartCode), NULL, &part);
		    spDebug(80, "controlEventHandler", "part = %d\n", part);
	    
		    spSliderActionMac(control, part);
		    err = noErr;
		}
		break;
		
	      default:
		break;
	    }
	}
    }
    
    return err;
}

EventHandlerUPP spNewControlEventHandlerUPP(void)
{
    return NewEventHandlerUPP(controlEventHandler);
}
#endif
