/*
 *	spToolBar_Mac.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spListP.h>
#include <sp/spToolItemP.h>
#include <sp/spToolBarP.h>

void spDrawToolBarMac(spComponent component, spBool map_flag)
{
    Rect rect;
    GrafPtr save_port;

    spLockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, &save_port);

    rect = SpPrimitiveArch(component).rect;
    EraseRect(&rect);
	
    if (!(spGetAppearanceVersionMac() >= 0x00000101)) {
	if (map_flag == SP_TRUE) {
	    MoveTo(0, SpComponentPart(component).height-1);
	    LineTo(spGetRectWidthMac(SpPrimitiveArch(component).rect),
		   SpComponentPart(component).height-1);
	}
    }

    spUnlockWindowPort(SpPrimitiveArch(SpGetWindow(component)).window, save_port);
    
    return;
}

void spToolBarPartInitArch(spComponent component)
{
    if (spIsAquaMac() == SP_TRUE && spUseBevelButtonForToolItemMac() == SP_FALSE) {
	SpComponentPart(component).margin_width = SP_DEFAULT_OSX_TOOL_ITEM_MARGIN;
	SpComponentPart(component).margin_height = SP_DEFAULT_OSX_TOOL_ITEM_MARGIN;
	SpComponentPart(component).spacing = SP_DEFAULT_OSX_TOOL_ITEM_SPACING;
    }
    
    return;
}

void spToolBarPartFreeArch(spComponent component)
{
    return;
}

void spToolBarCreateArch(spComponent component)
{
    spSetComponentRectMac(component,
			  SpComponentPart(component).current_width,
			  SpComponentPart(component).current_height);
    
    spSetNeedUpdateMac(component);
    
    return;
}

void spToolBarSetParamsArch(spComponent component)
{
    return;
}
    
void spToolBarDestroyArch(spComponent component)
{
    return;
}
