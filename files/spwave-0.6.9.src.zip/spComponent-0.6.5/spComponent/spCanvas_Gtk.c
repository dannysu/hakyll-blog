/*
 *	spCanvas_Gtk.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <gdk/gdkkeysyms.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spFrameP.h>
#include <sp/spDrawP.h>
#include <sp/spGraphicsP.h>
#include <sp/spCanvasP.h>

extern spTopLevel sp_toplevel;
extern GtkWidget *sp_grabbed_widget;

static GtkWidget *sp_grabbed_canvas = NULL;
static GtkWidget *sp_focused_canvas = NULL;

spBool spIsCanvasExposedArch(spComponent component)
{
    if (SpComponentPart(component).client_width >= 0
	&& SpComponentPart(component).client_height >= 0) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

void spExposeCanvasCBArch(spComponent component)
{
    return;
}

int grabPointerCB(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    static GtkWidget *prev_grabbed = NULL;
    
    switch (event->type) {
      case GDK_BUTTON_PRESS:
      case GDK_2BUTTON_PRESS:
      case GDK_3BUTTON_PRESS:
	spDebug(20, "spGrabPointerGtkCB", "button press\n");
	if (!GTK_WIDGET_HAS_GRAB(widget)) {
	    sp_grabbed_canvas = widget;
	    prev_grabbed = spAddGrabGtk(sp_grabbed_canvas);

	    return FALSE;
	}
	break;
      case GDK_BUTTON_RELEASE:
	if (sp_grabbed_canvas != NULL && GTK_WIDGET_HAS_GRAB(sp_grabbed_canvas)) {
	    spDebug(50, "spGrabPointerGtkCB", "ungrab pointer\n");
	    spRemoveGrabGtk(sp_grabbed_canvas);
	    sp_grabbed_canvas = NULL;
	    
	    spAddGrabGtk(prev_grabbed);
	    prev_grabbed = NULL;
	    return FALSE;
	} else {
	    gtk_signal_emit_stop_by_name(GTK_OBJECT(widget), "button_release_event");
	    return TRUE;
	}
	break;
      case GDK_MOTION_NOTIFY:
	if (event->motion.state) {
	    if (sp_grabbed_canvas != NULL) {
		return FALSE;
	    } else {
		gtk_signal_emit_stop_by_name(GTK_OBJECT(widget), "motion_notify_event");
		return TRUE;
	    }
	}
	break;
      case GDK_ENTER_NOTIFY:
	gtk_widget_grab_focus(widget);
	break;
      default:
	break;
    }
    
    return FALSE;
}

int focusChangeCB(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    if (event->type == GDK_FOCUS_CHANGE) {
	if (spIsCreated(component) == SP_TRUE
	    && SpPrimitiveArch(component).widget->window != NULL
	    && SpCanvasPart(component).focusable == SP_TRUE) {
	    if (event->focus_change.in) {
		sp_focused_canvas = widget;
	    } else {
		sp_focused_canvas = NULL;
	    }
	    spRedrawCanvas(component);
	    return TRUE;
	}
    }
    
    return FALSE;
}

int keyPressCB(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    if (event->type== GDK_KEY_PRESS && spIsCreated(component) == SP_TRUE) {
	if ((SpCanvasPart(component).use_tab_key == SP_TRUE
	     && event->key.keyval == GDK_Tab)
	    || (SpCanvasPart(component).use_arrow_key == SP_TRUE
		&& (event->key.keyval == GDK_Left
		    || event->key.keyval == GDK_Up
		    || event->key.keyval == GDK_Right
		    || event->key.keyval == GDK_Down))) {
	    return TRUE;
	}
    }
    
    return FALSE;
}

void spCanvasCreateArch(spComponent component)
{
    if (SpCanvasPart(component).border_on == SP_TRUE) {
	SpComponentPart(component).border_width = 2;
	
	SpPrimitiveArch(component).top_widget = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(SpPrimitiveArch(component).top_widget),
				  GTK_SHADOW_IN);
	gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			  SpPrimitiveArch(component).top_widget);
	gtk_widget_show(SpPrimitiveArch(component).top_widget);
    }
    
    SpPrimitiveArch(component).widget = gtk_drawing_area_new();
    spSetStyleGtk(component, SpPrimitiveArch(component).widget);
    gtk_widget_set_events(SpPrimitiveArch(component).widget,
			  GDK_BUTTON_PRESS_MASK
			  | GDK_BUTTON_RELEASE_MASK
			  | GDK_BUTTON_MOTION_MASK
			  | GDK_BUTTON1_MOTION_MASK
			  | GDK_BUTTON2_MOTION_MASK
			  | GDK_BUTTON3_MOTION_MASK
			  | GDK_POINTER_MOTION_MASK
			  | GDK_KEY_PRESS_MASK
			  | GDK_KEY_RELEASE_MASK
			  | GDK_ENTER_NOTIFY_MASK
			  | GDK_LEAVE_NOTIFY_MASK
			  | GDK_STRUCTURE_MASK
			  | GDK_EXPOSURE_MASK
			  | GDK_FOCUS_CHANGE_MASK
			  );
	
    if (SpPrimitiveArch(component).top_widget != NULL) {
	gtk_container_add(GTK_CONTAINER(SpPrimitiveArch(component).top_widget),
			  SpPrimitiveArch(component).widget);
    } else {
	gtk_container_add(GTK_CONTAINER(SpParentPrimitiveArch(component).widget),
			  SpPrimitiveArch(component).widget);
    }
    gtk_widget_show(SpPrimitiveArch(component).widget);

    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "button_press_event", GTK_SIGNAL_FUNC(grabPointerCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "button_release_event", GTK_SIGNAL_FUNC(grabPointerCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "motion_notify_event", GTK_SIGNAL_FUNC(grabPointerCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "enter_notify_event", GTK_SIGNAL_FUNC(grabPointerCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "leave_notify_event", GTK_SIGNAL_FUNC(grabPointerCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "focus_in_event", GTK_SIGNAL_FUNC(focusChangeCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "focus_out_event", GTK_SIGNAL_FUNC(focusChangeCB), component);
    gtk_signal_connect_after(GTK_OBJECT(SpPrimitiveArch(component).widget),
			     "key_press_event", GTK_SIGNAL_FUNC(keyPressCB), component);

    GTK_WIDGET_SET_FLAGS(SpPrimitiveArch(component).widget, GTK_CAN_FOCUS);
    
    return;
}

void spCanvasSetParamsArch(spComponent component)
{
    return;
}
    
void spCanvasDestroyArch(spComponent component)
{
    return;
}
    
void spRefreshCanvasArch(spComponent component)
{
    if (SpPrimitiveArch(component).widget->window == NULL) return;
    
    spDebug(50, "spRefreshCanvasArch", "in\n");

    gdk_draw_pixmap(SpPrimitiveArch(component).widget->window,
		    SpTopLevelArch(sp_toplevel).fg_gc,
		    SpPrimitiveArch(component).pixmap,
		    0, 0,
		    0, 0,
		    SpComponentPart(component).client_width,
		    SpComponentPart(component).client_height);

    spDebug(30, "spRefreshCanvasArch", "width = %d, height = %d\n", 
	    SpComponentPart(component).client_width, 
	    SpComponentPart(component).client_height);
    
    return;
}

void spRedrawCanvasArch(spComponent component)
{
    spRedrawImageArch(component);
    
    spDebug(50, "spRedrawCanvas", "client_width = %d, client_height = %d\n",
	    SpComponentPart(component).client_width, SpComponentPart(component).client_height);

    return;
}

int captureCanvasCB(GtkWidget *widget, GdkEvent *event, spComponent component)
{
    int x, y;
    spComponent window;
    static int prev_dx = 0, prev_dy = 0;
    static GtkWidget *prev_widget = NULL;

    if (component == NULL
	|| SpCanvasPart(component).capture_flag == SP_FALSE) return FALSE;
    
    window = SpGetWindow(component);
    
    switch (event->type) {
      case GDK_MOTION_NOTIFY:
	if (widget != prev_widget) return FALSE;
	
	SpComponentPart(window).x = event->motion.x_root + prev_dx;
	SpComponentPart(window).y = event->motion.y_root + prev_dy;

	gdk_window_move(SpFrameArch(window).toplevel->window,
			SpComponentPart(window).x, SpComponentPart(window).y);
	break;
      case GDK_BUTTON_PRESS:
      case GDK_2BUTTON_PRESS:
      case GDK_3BUTTON_PRESS:
	gdk_window_get_position(SpFrameArch(window).toplevel->window, &x, &y);
	prev_dx = x - event->button.x_root;
	prev_dy = y - event->button.y_root;
	prev_widget = widget;
	break;
      case GDK_BUTTON_RELEASE:
	prev_dx = 0;
	prev_dy = 0;
	prev_widget = NULL;
	break;
      default:
	break;
    }
    
    return FALSE;
}

spBool spSetCanvasCaptureArch(spComponent component)
{
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "button_press_event", GTK_SIGNAL_FUNC(captureCanvasCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "button_release_event", GTK_SIGNAL_FUNC(captureCanvasCB), component);
    gtk_signal_connect(GTK_OBJECT(SpPrimitiveArch(component).widget),
		       "motion_notify_event", GTK_SIGNAL_FUNC(captureCanvasCB), component);
    
    return SP_TRUE;
}

spBool spSetCanvasCursorArch(spComponent component, spCursor cursor)
{
    gdk_window_set_cursor(SpPrimitiveArch(component).widget->window,
			  SpCursorArch(cursor).cursor);
    gdk_flush();
    
    return SP_TRUE;
}

spBool spUnsetCanvasCursorArch(spComponent component)
{
    gdk_window_set_cursor(SpPrimitiveArch(component).widget->window,
			  NULL);
    gdk_flush();
    
    return SP_TRUE;
}

spBool spIsCanvasFocusedArch(spComponent component)
{
    if (SpPrimitiveArch(component).widget == sp_focused_canvas) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}
