/*
 *	spToolItem_Xm.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/Label.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/spToolBarP.h>
#include <sp/spToolItemP.h>

extern spTopLevel sp_toplevel;

void spToolItemPartInitArch(spComponent component)
{
    SpToolItemArch(component).insens_pixmap = None;
    return;
}

void spToolItemPartFreeArch(spComponent component)
{
    return;
}

static void drawInsensitivePixmap(Pixmap pixmap, int width, int height)
{
    int x, y;
    int size = 2;

    for (y = 0; y < height; y += size) {
	for (x = 0; x < width; x += size) {
	    if (((x / size) % 2 == 0 && (y / size) % 2 == 0)
		|| ((x / size) % 2 == 1 && (y / size) % 2 == 1)) {
		XFillRectangle(SpTopLevelArch(sp_toplevel).display,
			       pixmap, SpTopLevelArch(sp_toplevel).bg_gc,
			       x, y, size, size);
	    }
	}
    }

    return;
}

static Pixmap createToolItemPixmap(spComponent component, Pixmap parent_pixmap)
{
    Pixmap pixmap;

    if ((pixmap =
	 XCreatePixmap(SpParentPrimitiveArch(component).display, 
		       RootWindowOfScreen(SpParentPrimitiveArch(component).screen),
		       SpParentToolBarPart(component).bitmap_width,
		       SpParentToolBarPart(component).bitmap_height,
		       DefaultDepthOfScreen(SpParentPrimitiveArch(component).screen))) != None) {
	XCopyArea(SpParentPrimitiveArch(component).display,
		  parent_pixmap,
		  pixmap, SpTopLevelArch(sp_toplevel).fg_gc,
		  SpPrimitivePart(component).index * SpParentToolBarPart(component).bitmap_width, 0,
		  SpParentToolBarPart(component).bitmap_width,
		  SpParentToolBarPart(component).bitmap_height,
		  0, 0);
    }
    
    return pixmap;
}

void spToolItemCreateArch(spComponent component)
{
    int narg = 0;
    Arg args[20];
    
    if (spIsSubClass(component, SpToolSeparator) == SP_FALSE) {
	if (SpParentPrimitiveArch(component).pixmap != None) {
	    /* create pixmap */
	    if ((SpPrimitiveArch(component).pixmap =
		 createToolItemPixmap(component, SpParentPrimitiveArch(component).pixmap)) != None) {
		XtSetArg(args[narg], XmNlabelType, XmPIXMAP); narg++;
		XtSetArg(args[narg], XmNlabelPixmap, SpPrimitiveArch(component).pixmap); narg++;
		XtSetArg(args[narg], XmNshadowThickness, 2); narg++;
		XtSetArg(args[narg], XmNhighlightThickness, 0); narg++;
		XtSetArg(args[narg], XmNborderWidth, 0); narg++;
		XtSetArg(args[narg], XmNmarginWidth, 0); narg++;
		XtSetArg(args[narg], XmNmarginHeight, 0); narg++;
		XtSetArg(args[narg], XmNtraversalOn, False); narg++;
		XtSetArg(args[narg], XmNrecomputeSize, False); narg++;
		    
		if (spIsSubClass(component, SpCheckToolItem)) {
		    XtSetArg(args[narg], XmNspacing, 0); narg++;
		    XtSetArg(args[narg], XmNindicatorSize, 0); narg++;
		    XtSetArg(args[narg], XmNindicatorOn, False); narg++;
		    XtSetArg(args[narg], XmNfillOnSelect, True); narg++;
		    XtSetArg(args[narg], XmNselectPixmap, SpPrimitiveArch(component).pixmap); narg++;
		} else {
		    XtSetArg(args[narg], XmNarmPixmap, SpPrimitiveArch(component).pixmap); narg++;
		}
	    }

	    /* create insensitive pixmap */
	    if ((SpToolItemArch(component).insens_pixmap =
		 createToolItemPixmap(component, SpParentPrimitiveArch(component).pixmap)) != None) {
		drawInsensitivePixmap(SpToolItemArch(component).insens_pixmap,
				      SpParentToolBarPart(component).bitmap_width,
				      SpParentToolBarPart(component).bitmap_height);
		    
		XtSetArg(args[narg], XmNlabelInsensitivePixmap,
			 SpToolItemArch(component).insens_pixmap); narg++;
	    }
	}
	    
	if (spIsSubClass(component, SpCheckToolItem)) {
	    SpPrimitiveArch(component).widget =
		XtCreateManagedWidget("",
				      xmToggleButtonWidgetClass,
				      SpParentPrimitiveArch(component).widget,
				      args, narg);
	} else {
	    SpPrimitiveArch(component).widget =
		XtCreateManagedWidget("",
				      xmPushButtonWidgetClass,
				      SpParentPrimitiveArch(component).widget,
				      args, narg);
	}
	    
	spShowToolTip(component);
    }
    
    spDebug(30, "spToolItemCreateArch", "create done\n");

    return;
}

void spToolItemSetParamsArch(spComponent component)
{
    return;
}

void spToolItemDestroyArch(spComponent component)
{
    if (SpToolItemArch(component).insens_pixmap != None) {
	XFreePixmap(SpTopLevelArch(sp_toplevel).display,
		    SpToolItemArch(component).insens_pixmap);
    }
    
    return;
}

void spSetToolItemToggleStateArch(spComponent component)
{
    XmToggleButtonSetState(SpPrimitiveArch(component).widget,
			   (SpToolItemPart(component).set == SP_ON ? True : False), False);
    
    return;
}

void spGetToolItemToggleStateArch(spComponent component)
{
    if (XmToggleButtonGetState(SpPrimitiveArch(component).widget) == True) {
	SpToolItemPart(component).set = SP_TRUE;
    } else {
	SpToolItemPart(component).set = SP_FALSE;
    }
    spDebug(30, "spGetToolItemToggleStateArch", "set = %d\n",
	    SpToolItemPart(component).set);

    return;
}
