/*
 *	matrix.h
 */

#ifndef __MATRIX_H
#define __MATRIX_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _SMatrix {
    long row;
    long col;
    short **data;
    short **imag;
} *SMatrix;

typedef struct _LMatrix {
    long row;
    long col;
    long **data;
    long **imag;
} *LMatrix;

typedef struct _FMatrix {
    long row;
    long col;
    float **data;
    float **imag;
} *FMatrix;

typedef struct _DMatrix {
    long row;
    long col;
    double **data;
    double **imag;
} *DMatrix;

typedef struct _SMatrices {
    long num_matrix;
    SMatrix *matrix;
} *SMatrices;

typedef struct _LMatrices {
    long num_matrix;
    LMatrix *matrix;
} *LMatrices;

typedef struct _FMatrices {
    long num_matrix;
    FMatrix *matrix;
} *FMatrices;

typedef struct _DMatrices {
    long num_matrix;
    DMatrix *matrix;
} *DMatrices;

#if defined(MACOS)
#pragma import on
#endif

extern LMatrix xlmalloc(long row, long col);
extern DMatrix xdmalloc(long row, long col);
extern void xlmfree(LMatrix matrix);
extern void xdmfree(DMatrix matrix);

extern void lmialloc(LMatrix x);
extern void dmialloc(DMatrix x);
extern void lmifree(LMatrix x);
extern void dmifree(DMatrix x);

extern LMatrix xlmrialloc(long row, long col);
extern DMatrix xdmrialloc(long row, long col);

extern LMatrices xlmsalloc(long num);
extern DMatrices xdmsalloc(long num);
extern void xlmsfree(LMatrices xs);
extern void xdmsfree(DMatrices xs);

extern void lmreal(LMatrix x);
extern void dmreal(DMatrix x);
extern void lmimag(LMatrix x);
extern void dmimag(DMatrix x);

extern LMatrix xlmnums(long row, long col, long value);
extern DMatrix xdmnums(long row, long col, double value);
extern void lmnums(LMatrix mat, long row, long col, long value);
extern void dmnums(DMatrix mat, long row, long col, double value);
extern void lminums(LMatrix mat, long row, long col, long value);
extern void dminums(DMatrix mat, long row, long col, double value);
extern LMatrix xlmrinums(long row, long col, long value);
extern DMatrix xdmrinums(long row, long col, double value);

extern DMatrix xdminitrow(long nrow, double j, double incr, double n);
extern DMatrix xdminitcol(long ncol, double j, double incr, double n);

extern LVector xlmcutrow(LMatrix mat, long row, long offset, long length);
extern DVector xdmcutrow(DMatrix mat, long row, long offset, long length);
extern LVector xlmcutcol(LMatrix mat, long col, long offset, long length);
extern DVector xdmcutcol(DMatrix mat, long col, long offset, long length);

extern void lmpasterow(LMatrix mat, long row, LVector vec,
		       long offset, long length, int overlap);
extern void dmpasterow(DMatrix mat, long row, DVector vec,
		       long offset, long length, int overlap);
extern void lmpastecol(LMatrix mat, long col, LVector vec,
		       long offset, long length, int overlap);
extern void dmpastecol(DMatrix mat, long col, DVector vec,
		       long offset, long length, int overlap);

extern LVector xlmrmax(LMatrix mat);
extern LVector xdmrmax(DMatrix mat);
extern LVector xlmrmin(LMatrix mat);
extern LVector xdmrmin(DMatrix mat);
extern LVector xlmrextract(LMatrix mat, LVector idx);
extern DVector xdmrextract(DMatrix mat, LVector idx);
extern LVector xlmcmax(LMatrix mat);
extern LVector xdmcmax(DMatrix mat);
extern LVector xlmcmin(LMatrix mat);
extern LVector xdmcmin(DMatrix mat);
extern LVector xlmcextract(LMatrix mat, LVector idx);
extern DVector xdmcextract(DMatrix mat, LVector idx);

#if defined(MACOS)
#pragma import off
#endif

#define xlmextractrow(mat, k) xlmcutrow(mat, (long)(k), 0, mat->col)
#define xdmextractrow(mat, k) xdmcutrow(mat, (long)(k), 0, mat->col)
#define xlmextractcol(mat, k) xlmcutcol(mat, (long)(k), 0, mat->row)
#define xdmextractcol(mat, k) xdmcutcol(mat, (long)(k), 0, mat->row)

#define lmcopyrow(mat, k, vec) lmpasterow(mat, (long)(k), vec, 0, vec->length, 0)
#define dmcopyrow(mat, k, vec) dmpasterow(mat, (long)(k), vec, 0, vec->length, 0)
#define lmcopycol(mat, k, vec) lmpastecol(mat, (long)(k), vec, 0, vec->length, 0)
#define dmcopycol(mat, k, vec) dmpastecol(mat, (long)(k), vec, 0, vec->length, 0)

#define xlmzeros(row, col) xlmnums(row, col, 0)
#define xdmzeros(row, col) xdmnums(row, col, 0.0)
#define xlmones(row, col) xlmnums(row, col, 1)
#define xdmones(row, col) xdmnums(row, col, 1.0)

#define lmzeros(mat, row, col) lmnums(mat, row, col, 0)
#define dmzeros(mat, row, col) dmnums(mat, row, col, 0.0)
#define lmones(mat, row, col) lmnums(mat, row, col, 1)
#define dmones(mat, row, col) dmnums(mat, row, col, 1.0)

#define lmizeros(mat, row, col) lminums(mat, row, col, 0)
#define dmizeros(mat, row, col) dminums(mat, row, col, 0.0)
#define lmiones(mat, row, col) lminums(mat, row, col, 1)
#define dmiones(mat, row, col) dminums(mat, row, col, 1.0)

#define xlmrizeros(row, col) xlmrinums(row, col, 0)
#define xdmrizeros(row, col) xdmrinums(row, col, 0.0)
#define xlmriones(row, col) xlmrinums(row, col, 1)
#define xdmriones(row, col) xdmrinums(row, col, 1.0)

#define xlmnull() xlmalloc(0, 0)
#define xdmnull() xdmalloc(0, 0)

#define msset(xs, index, x) {(xs)->matrix[index]=(x);}
#define smsset msset
#define lmsset msset
#define fmsset msset
#define dmsset msset

/* for backwards compatibility */
typedef SMatrix SMATRIX;
typedef LMatrix LMATRIX;
typedef FMatrix FMATRIX;
typedef DMatrix DMATRIX;

typedef SMatrices SMATRICES;
typedef LMatrices LMATRICES;
typedef FMatrices FMATRICES;
typedef DMatrices DMATRICES;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __MATRIX_H */
