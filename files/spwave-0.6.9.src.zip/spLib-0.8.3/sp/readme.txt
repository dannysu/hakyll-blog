
	spLib - Library for signal processing

			Last modified: <00/12/14 01:39:51 hideki>


Introduction
------------

spLib is a library for speech signal processing. This library includes many
functions for signal processing.
 

Install
-------

To compile this library on UNIX (including Linux) or Cygwin, go to the
spLib top directory, and make a symbolic link from `include' directory
and `lib' directory of spBase (e.g. /usr/local/include and /usr/local/lib)
like this:

 % cd spLib-X.X.X
 % ln -s /usr/local/include
 % ln -s /usr/local/lib

If your platform is supported by the configuration file of spBase, you can
build the library by typing in the source directory:

 % cd sp
 % make

To install this library to your system directory (e.g /usr/local), login as
root and type:

 # make SPDESTROOT=/usr/local install
 # make SPDESTROOT=/usr/local install.hdr

If you don't want to make a symbolic link from spBase directory, you can
compile and install by adding TOP=/usr/local option (/usr/local is top
directory of spBase) to the above command line of `make' such as:
 
 % cd spLib-X.X.X
 % cd sp
 % make TOP=/usr/local
 % su
 # make TOP=/usr/local SPDESTROOT=/usr/local install
 # make TOP=/usr/local SPDESTROOT=/usr/local install.hdr


Supported Platforms
-------------------

spLib is known to work at least on DEC Alpha(Digital UNIX V3.2C),
SunOS(5.6), Linux(Redhat 4.2, Slackware 3.4), Microsoft Windows95/98, and
Cygnus GNU-Win32(Beta 19). 


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

License
-------

Please see LICENSE.txt.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
