/*
 *	filter.h
 */

#ifndef __FILTER_H
#define __FILTER_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void dvangle(DVector x);
extern DVector xdvangle(DVector x);
extern void dvunwrap(DVector phs, double cutoff);
extern double sinc(double x);
extern double sincc(double x, double c);
extern DVector xdvlowpass(double cutoff, double sidelobe, double trans, double gain);
extern DVector xdvfftfilt(DVector b, DVector x, long fftp);
extern DVector xdvfftfiltm(DVector b, DVector x, long fftp);
extern DVector xdvconv(DVector a, DVector b);
extern DVector xdvfilter(DVector b, DVector a, DVector x);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __FILTER_H */
