/*
 *	sp.h
 */

#ifndef __SP_H
#define __SP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spOption.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SP_VERSION 		0
#define SP_REVISION		8
#define SP_UPDATE_LEVEL		3
#define SP_VERSION_ID		(SP_VERSION * 1000 + SP_REVISION)
#define SP_VERSION_STRING	"0.8.3"

#define SP_CHECK_VERSION(version, revision, update) \
    (SP_VERSION > (version) || \
     (SP_VERSION == (version) && SP_REVISION > (revision)) || \
     (SP_VERSION == (version) && SP_REVISION == (revision) && SP_UPDATE_LEVEL >= (update)))
    
#define NO_WARNING

#define SUCCESS  	SP_SUCCESS
#define FAILURE        	SP_FAILURE
#define ON		SP_ON
#define OFF		SP_OFF
#define MAX_LINE	SP_MAX_LINE
#define MAX_PATHNAME	SP_MAX_PATHNAME
#define MAX_MESSAGE	SP_MAX_MESSAGE
#define EPSILON		SP_EPSILON
#define ALITTLE_NUMBER 	SP_ALITTLE_NUMBER
#define UNKNOWN		(-1)

#ifndef NODATA
#define NODATA 		NULL
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SP_H */
