/*
 *	voperate.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/memory.h>
#include <sp/vector.h>
#include <sp/voperate.h>

void fvoper(FVector x, char *op, FVector y)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (y->imag != NULL && x->imag == NULL) {
	fvizeros(x, x->length);
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < x->length; k++) {
	    if (k < y->length) {
		x->data[k] = x->data[k] + y->data[k];
		if (x->imag != NULL) {
		    if (y->imag != NULL) {
			x->imag[k] = x->imag[k] + y->imag[k];
		    }
		}
	    }
	}
    } else if (strveq(op2, "-")) {
	if (reverse) {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    x->data[k] = y->data[k] - x->data[k];
		    if (x->imag != NULL) {
			if (y->imag != NULL) {
			    x->imag[k] = y->imag[k] - x->imag[k];
			} else {
			    x->imag[k] = -x->imag[k];
			}
		    }
		} else {
		    x->data[k] = -x->data[k];
		    if (x->imag != NULL) {
			x->imag[k] = -x->imag[k];
		    }
		}
	    }
	} else {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    x->data[k] = x->data[k] - y->data[k];
		    if (x->imag != NULL) {
			if (y->imag != NULL) {
			    x->imag[k] = x->imag[k] - y->imag[k];
			}
		    }
		}
	    }
	}
    } else if (strveq(op2, "*")) {
	float xr, xi;
	for (k = 0; k < x->length; k++) {
	    if (k < y->length) {
		if (x->imag != NULL) {
		    if (y->imag != NULL) {
			xr = x->data[k] * y->data[k] - x->imag[k] * y->imag[k];
			xi = x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
			x->data[k] = xr;
			x->imag[k] = xi;
		    } else {
			x->data[k] = x->data[k] * y->data[k];
			x->imag[k] = x->imag[k] * y->data[k];
		    }
		} else {
		    x->data[k] = x->data[k] * y->data[k];
		}
	    } else {
		x->data[k] = 0.0;
		if (x->imag != NULL) {
		    x->imag[k] = 0.0;
		}
	    }
	}
    } else if (strveq(op2, "/")) {
	float a;
	float xr, xi;
	if (reverse) {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    if (x->imag != NULL) {
			if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			    spwarning("warning: fvoper: divide by zero\n");
			    
			    if (y->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = y->data[k] / ALITTLE_NUMBER;
			    }
			    if (y->imag != NULL) {
				if (y->imag[k] == 0.0) {
				    x->imag[k] = 0.0;
				} else {
				    x->imag[k] = y->imag[k] / ALITTLE_NUMBER;
				}
			    } else {
				x->imag[k] = 0.0;
			    }
			} else {
			    a = CSQUARE(x->data[k], x->imag[k]);
			    if (y->imag != NULL) {
				xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
				xi = x->data[k] * y->imag[k] - x->imag[k] * y->data[k];
				x->data[k] = xr / a;
				x->imag[k] = xi / a;
			    } else {
				x->data[k] =  x->data[k] * y->data[k] / a;
				x->imag[k] = -x->imag[k] * y->data[k] / a;
			    }
			}
		    } else {
			if (x->data[k] != 0.0) {
			    x->data[k] = y->data[k] / x->data[k];
			} else {
			    spwarning("warning: fvoper: divide by zero\n");

			    if (y->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = y->data[k] / ALITTLE_NUMBER;
			    }
			}
		    }
		} else {
		    x->data[k] = 0.0;
		    if (x->imag != NULL) {
			x->imag[k] = 0.0;
		    }
		}
	    }
	} else {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    if (x->imag != NULL && y->imag != NULL) {
			if (y->data[k] == 0.0 && y->imag[k] == 0.0) {
			    spwarning("warning: fvoper: divide by zero\n");

			    if (x->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = x->data[k] / ALITTLE_NUMBER;
			    }
			    if (x->imag[k] == 0.0) {
				x->imag[k] = 0.0;
			    } else {
				x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
			    }
			} else {
			    a = CSQUARE(y->data[k], y->imag[k]);
			    xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
			    xi = -x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
			    x->data[k] = xr / a;
			    x->imag[k] = xi / a;
			}
		    } else {
			if (y->data[k] == 0.0) {
			    spwarning("warning: fvoper: divide by zero\n");

			    if (x->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = x->data[k] / ALITTLE_NUMBER;
			    }
			    if (x->imag != NULL) {
				if (x->imag[k] == 0.0) {
				    x->imag[k] = 0.0;
				} else {
				    x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
				}
			    }
			} else {
			    x->data[k] = x->data[k] / y->data[k];
			    if (x->imag != NULL) {
				x->imag[k] = x->imag[k] / y->data[k];
			    }
			}
		    }
		} else {
		    x->data[k] = 0.0;
		    if (x->imag != NULL) {
			x->imag[k] = 0.0;
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	float xr, xi;
	float yr, yi;
	if (reverse) {
	    if (x->imag != NULL) {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			if (y->imag == NULL) {
			    yr = y->data[k];
			    yi = 0.0;
			} else {
			    yr = y->data[k];
			    yi = y->imag[k];
			}
			if (yr == 0.0 && yi == 0.0) {
			    x->data[k] = 0.0;
			    x->imag[k] = 0.0;
			} else if (x->imag[k] == 0.0 && yi == 0.0) {
			    x->data[k] = (float)pow((double)y->data[k], 
						    (double)x->data[k]);
			} else {
			    clogf(&yr, &yi);
			    xr = x->data[k] * yr - x->imag[k] * yi;
			    xi = x->data[k] * yi + x->imag[k] * yr;
			    cexpf(&xr, &xi);
			    x->data[k] = xr;
			    x->imag[k] = xi;
			}
		    } else {
			x->data[k] = 0.0;
			x->imag[k] = 0.0;
		    }
		}
	    } else {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			x->data[k] = (float)pow((double)y->data[k], 
						(double)x->data[k]);
		    } else {
			x->data[k] = 0.0;
		    }
		}
	    }
	} else {
	    if (x->imag != NULL) {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			    x->data[k] = 0.0;
			    x->imag[k] = 0.0;
			} else {
			    if (y->imag == NULL) {
				yr = y->data[k];
				yi = 0.0;
			    } else {
				yr = y->data[k];
				yi = y->imag[k];
			    }
			    if (x->imag[k] == 0.0 && yi == 0.0) {
				x->data[k] = (float)pow((double)x->data[k],
							(double)y->data[k]);
			    } else {
				clogf(&x->data[k], &x->imag[k]);
				xr = x->data[k] * yr - x->imag[k] * yi;
				xi = x->data[k] * yi + x->imag[k] * yr;
				cexpf(&xr, &xi);
				x->data[k] = xr;
				x->imag[k] = xi;
			    }
			}
		    } else {
			x->data[k] = 1.0;
			x->imag[k] = 1.0;
		    }
		}
	    } else {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			x->data[k] = (float)pow((double)x->data[k], 
						(double)y->data[k]);
		    } else {
			x->data[k] = 1.0;
		    }
		}
	    }
	}
    } else {
	fprintf(stderr, "fvoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

void dvoper(DVector x, char *op, DVector y)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (y->imag != NULL && x->imag == NULL) {
	dvizeros(x, x->length);
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < x->length; k++) {
	    if (k < y->length) {
		x->data[k] = x->data[k] + y->data[k];
		if (x->imag != NULL) {
		    if (y->imag != NULL) {
			x->imag[k] = x->imag[k] + y->imag[k];
		    }
		}
	    }
	}
    } else if (strveq(op2, "-")) {
	if (reverse) {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    x->data[k] = y->data[k] - x->data[k];
		    if (x->imag != NULL) {
			if (y->imag != NULL) {
			    x->imag[k] = y->imag[k] - x->imag[k];
			} else {
			    x->imag[k] = -x->imag[k];
			}
		    }
		} else {
		    x->data[k] = -x->data[k];
		    if (x->imag != NULL) {
			x->imag[k] = -x->imag[k];
		    }
		}
	    }
	} else {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    x->data[k] = x->data[k] - y->data[k];
		    if (x->imag != NULL) {
			if (y->imag != NULL) {
			    x->imag[k] = x->imag[k] - y->imag[k];
			}
		    }
		}
	    }
	}
    } else if (strveq(op2, "*")) {
	double xr, xi;
	for (k = 0; k < x->length; k++) {
	    if (k < y->length) {
		if (x->imag != NULL) {
		    if (y->imag != NULL) {
			xr = x->data[k] * y->data[k] - x->imag[k] * y->imag[k];
			xi = x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
			x->data[k] = xr;
			x->imag[k] = xi;
		    } else {
			x->data[k] = x->data[k] * y->data[k];
			x->imag[k] = x->imag[k] * y->data[k];
		    }
		} else {
		    x->data[k] = x->data[k] * y->data[k];
		}
	    } else {
		x->data[k] = 0.0;
		if (x->imag != NULL) {
		    x->imag[k] = 0.0;
		}
	    }
	}
    } else if (strveq(op2, "/")) {
	double a;
	double xr, xi;
	if (reverse) {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    if (x->imag != NULL) {
			if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			    spwarning("warning: dvoper: divide by zero\n");

			    if (y->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = y->data[k] / ALITTLE_NUMBER;
			    }
			    if (y->imag != NULL) {
				if (y->imag[k] == 0.0) {
				    x->imag[k] = 0.0;
				} else {
				    x->imag[k] = y->imag[k] / ALITTLE_NUMBER;
				}
			    } else {
				x->imag[k] = 0.0;
			    }
			} else {
			    a = CSQUARE(x->data[k], x->imag[k]);
			    if (y->imag != NULL) {
				xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
				xi = x->data[k] * y->imag[k] - x->imag[k] * y->data[k];
				x->data[k] = xr / a;
				x->imag[k] = xi / a;
			    } else {
				x->data[k] =  x->data[k] * y->data[k] / a;
				x->imag[k] = -x->imag[k] * y->data[k] / a;
			    }
			}
		    } else {
			if (x->data[k] != 0.0) {
			    x->data[k] = y->data[k] / x->data[k];
			} else {
			    spwarning("warning: dvoper: divide by zero\n");

			    if (y->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = y->data[k] / ALITTLE_NUMBER;
			    }
			}
		    }
		} else {
		    x->data[k] = 0.0;
		    if (x->imag != NULL) {
			x->imag[k] = 0.0;
		    }
		}
	    }
	} else {
	    for (k = 0; k < x->length; k++) {
		if (k < y->length) {
		    if (x->imag != NULL && y->imag != NULL) {
			if (y->data[k] == 0.0 && y->imag[k] == 0.0) {
			    spwarning("warning: dvoper: divide by zero\n");

			    if (x->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = x->data[k] / ALITTLE_NUMBER;
			    }
			    if (x->imag[k] == 0.0) {
				x->imag[k] = 0.0;
			    } else {
				x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
			    }
			} else {
			    a = CSQUARE(y->data[k], y->imag[k]);
			    xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
			    xi = -x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
			    x->data[k] = xr / a;
			    x->imag[k] = xi / a;
			}
		    } else {
			if (y->data[k] == 0.0) {
			    spwarning("warning: dvoper: divide by zero\n");

			    if (x->data[k] == 0.0) {
				x->data[k] = 0.0;
			    } else {
				x->data[k] = x->data[k] / ALITTLE_NUMBER;
			    }
			    if (x->imag != NULL) {
				if (x->imag[k] == 0.0) {
				    x->imag[k] = 0.0;
				} else {
				    x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
				}
			    }
			} else {
			    x->data[k] = x->data[k] / y->data[k];
			    if (x->imag != NULL) {
				x->imag[k] = x->imag[k] / y->data[k];
			    }
			}
		    }
		} else {
		    x->data[k] = 0.0;
		    if (x->imag != NULL) {
			x->imag[k] = 0.0;
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	double xr, xi;
	double yr, yi;
	if (reverse) {
	    if (x->imag != NULL) {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			if (y->imag == NULL) {
			    yr = y->data[k];
			    yi = 0.0;
			} else {
			    yr = y->data[k];
			    yi = y->imag[k];
			}
			if (yr == 0.0 && yi == 0.0) {
			    x->data[k] = 0.0;
			    x->imag[k] = 0.0;
			} else if (x->imag[k] == 0.0 && yi == 0.0) {
			    x->data[k] = pow(y->data[k], x->data[k]);
			} else {
			    clog(&yr, &yi);
			    xr = x->data[k] * yr - x->imag[k] * yi;
			    xi = x->data[k] * yi + x->imag[k] * yr;
			    cexp(&xr, &xi);
			    x->data[k] = xr;
			    x->imag[k] = xi;
			}
		    } else {
			x->data[k] = 0.0;
			x->imag[k] = 0.0;
		    }
		}
	    } else {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			x->data[k] = pow(y->data[k], x->data[k]);
		    } else {
			x->data[k] = 0.0;
		    }
		}
	    }
	} else {
	    if (x->imag != NULL) {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			    x->data[k] = 0.0;
			    x->imag[k] = 0.0;
			} else {
			    if (y->imag == NULL) {
				yr = y->data[k];
				yi = 0.0;
			    } else {
				yr = y->data[k];
				yi = y->imag[k];
			    }
			    if (x->imag[k] == 0.0 && yi == 0.0) {
				x->data[k] = pow(x->data[k], y->data[k]);
			    } else {
				clog(&x->data[k], &x->imag[k]);
				xr = x->data[k] * yr - x->imag[k] * yi;
				xi = x->data[k] * yi + x->imag[k] * yr;
				cexp(&xr, &xi);
				x->data[k] = xr;
				x->imag[k] = xi;
			    }
			}
		    } else {
			x->data[k] = 1.0;
			x->imag[k] = 1.0;
		    }
		}
	    } else {
		for (k = 0; k < x->length; k++) {
		    if (k < y->length) {
			x->data[k] = pow(x->data[k], y->data[k]);
		    } else {
			x->data[k] = 1.0;
		    }
		}
	    }
	}
    } else {
	fprintf(stderr, "dvoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

FVector xfvoper(FVector a, char *op, FVector b)
{
    FVector c;

    c = xfvclone(a);
    fvoper(c, op, b);

    return c;
}

DVector xdvoper(DVector a, char *op, DVector b)
{
    DVector c;

    c = xdvclone(a);
    dvoper(c, op, b);

    return c;
}

void fvscoper(FVector x, char *op, float t)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = x->data[k] + t;
	}
    } else if (strveq(op2, "-")) {
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		x->data[k] = t - x->data[k];
		if (x->imag != NULL) {
		    x->imag[k] = -x->imag[k];
		}
	    } else {
		x->data[k] = x->data[k] - t;
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = x->data[k] * t;
	    if (x->imag != NULL) {
		x->imag[k] = x->imag[k] * t;
	    }
	}
    } else if (strveq(op2, "/")) {
	float a;
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		if (x->imag != NULL) {
		    if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			spwarning("warning: fvscoper: divide by zero\n");

			if (t == 0.0) {
			    x->data[k] = 0.0;
			} else {
			    x->data[k] = t / ALITTLE_NUMBER;
			}
			x->imag[k] = 0.0;
		    } else {
			a = CSQUARE(x->data[k], x->imag[k]);
			x->data[k] = x->data[k] * t / a;
			x->imag[k] = -x->imag[k] * t / a;
		    }
		} else {
		    if (x->data[k] != 0.0) {
			x->data[k] = t / x->data[k];
		    } else {
			spwarning("warning: fvscoper: divide by zero\n");

			if (t == 0.0) {
			    x->data[k] = 0.0;
			} else {
			    x->data[k] = t / ALITTLE_NUMBER;
			}
		    }
		}
	    } else {
		if (t != 0.0) {
		    x->data[k] = x->data[k] / t;
		    if (x->imag != NULL) {
			x->imag[k] = x->imag[k] / t;
		    }
		} else {
		    if (x->data[k] == 0.0) {
			x->data[k] = 0.0;
		    } else {
			x->data[k] = x->data[k] / ALITTLE_NUMBER;
		    }
		    if (x->imag != NULL) {
			if (x->imag[k] == 0.0) {
			    x->imag[k] = 0.0;
			} else {
			    x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
			}
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	float a; 
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		if (x->imag != NULL && x->imag[k] != 0.0) {
		    a = log(t);
		    x->data[k] *= a;
		    x->imag[k] *= a;
		    cexpf(&x->data[k], &x->imag[k]);
		} else {
		    x->data[k] = (float)pow((double)t, (double)x->data[k]);
		}
	    } else {
		if (x->imag != NULL && x->imag[k] != 0.0) {
		    clogf(&x->data[k], &x->imag[k]);
		    x->data[k] *= t;
		    x->imag[k] *= t;
		    cexpf(&x->data[k], &x->imag[k]);
		} else {
		    x->data[k] = (float)pow((double)x->data[k], (double)t);
		}
	    }
	}
    } else {
	fprintf(stderr, "fvscoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

void dvscoper(DVector x, char *op, double t)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = x->data[k] + t;
	}
    } else if (strveq(op2, "-")) {
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		x->data[k] = t - x->data[k];
		if (x->imag != NULL) {
		    x->imag[k] = -x->imag[k];
		}
	    } else {
		x->data[k] = x->data[k] - t;
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = x->data[k] * t;
	    if (x->imag != NULL) {
		x->imag[k] = x->imag[k] * t;
	    }
	}
    } else if (strveq(op2, "/")) {
	double a;
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		if (x->imag != NULL) {
		    if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
			spwarning("warning: dvscoper: divide by zero\n");

			if (t == 0.0) {
			    x->data[k] = 0.0;
			} else {
			    x->data[k] = t / ALITTLE_NUMBER;
			}
			x->imag[k] = 0.0;
		    } else {
			a = CSQUARE(x->data[k], x->imag[k]);
			x->data[k] = x->data[k] * t / a;
			x->imag[k] = -x->imag[k] * t / a;
		    }
		} else {
		    if (x->data[k] != 0.0) {
			x->data[k] = t / x->data[k];
		    } else {
			spwarning("warning: dvscoper: divide by zero\n");

			if (t == 0.0) {
			    x->data[k] = 0.0;
			} else {
			    x->data[k] = t / ALITTLE_NUMBER;
			}
		    }
		}
	    } else {
		if (t != 0.0) {
		    x->data[k] = x->data[k] / t;
		    if (x->imag != NULL) {
			x->imag[k] = x->imag[k] / t;
		    }
		} else {
		    if (x->data[k] == 0.0) {
			x->data[k] = 0.0;
		    } else {
			x->data[k] = x->data[k] / ALITTLE_NUMBER;
		    }
		    if (x->imag != NULL) {
			if (x->imag[k] == 0.0) {
			    x->imag[k] = 0.0;
			} else {
			    x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
			}
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	double a; 
	for (k = 0; k < x->length; k++) {
	    if (reverse) {
		if (x->imag != NULL && x->imag[k] != 0.0) {
		    a = log(t);
		    x->data[k] *= a;
		    x->imag[k] *= a;
		    cexp(&x->data[k], &x->imag[k]);
		} else {
		    x->data[k] = pow(t, x->data[k]);
		}
	    } else {
		if (x->imag != NULL && x->imag[k] != 0.0) {
		    clog(&x->data[k], &x->imag[k]);
		    x->data[k] *= t;
		    x->imag[k] *= t;
		    cexp(&x->data[k], &x->imag[k]);
		} else {
		    x->data[k] = pow(x->data[k], t);
		}
	    }
	}
    } else {
	fprintf(stderr, "dvscoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

FVector xfvscoper(FVector a, char *op, float t)
{
    FVector c;

    c = xfvclone(a);
    fvscoper(c, op, t);

    return c;
}

DVector xdvscoper(DVector a, char *op, double t)
{
    DVector c;

    c = xdvclone(a);
    dvscoper(c, op, t);

    return c;
}

void svoper(SVector a, char *op, SVector b)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < a->length; k++) {
	    if (k < b->length) {
		a->data[k] = a->data[k] + b->data[k];
	    }
	}
    } else if (strveq(op2, "-")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = b->data[k] - a->data[k];
		} else {
		    a->data[k] = -(a->data[k]);
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = a->data[k] - b->data[k];
		}
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < a->length; k++) {
	    if (k < b->length) {
		a->data[k] = a->data[k] * b->data[k];
	    } else {
		a->data[k] = 0;
	    }
	}
    } else if (strveq(op2, "/")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    if (a->data[k] != 0) {
			a->data[k] = b->data[k] / a->data[k];
		    } else {
			spwarning("warning: svoper: divide by zero\n");

			if (b->data[k] == 0) {
			    a->data[k] = 0;
			} else {
			    a->data[k] = (short)((double)b->data[k] / ALITTLE_NUMBER);
			}
		    }
		} else {
		    a->data[k] = 0;
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = a->data[k] / b->data[k];
		} else {
		    a->data[k] = 0;
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = (short)pow(b->data[k], (double)a->data[k]);
		} else {
		    a->data[k] = 0;
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = (short)pow((double)a->data[k], b->data[k]);
		} else {
		    a->data[k] = 1;
		}
	    }
	}
    } else {
	fprintf(stderr, "svoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

void lvoper(LVector a, char *op, LVector b)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < a->length; k++) {
	    if (k < b->length) {
		a->data[k] = a->data[k] + b->data[k];
	    }
	}
    } else if (strveq(op2, "-")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = b->data[k] - a->data[k];
		} else {
		    a->data[k] = -(a->data[k]);
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = a->data[k] - b->data[k];
		}
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < a->length; k++) {
	    if (k < b->length) {
		a->data[k] = a->data[k] * b->data[k];
	    } else {
		a->data[k] = 0;
	    }
	}
    } else if (strveq(op2, "/")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    if (a->data[k] != 0) {
			a->data[k] = b->data[k] / a->data[k];
		    } else {
			spwarning("warning: lvoper: divide by zero\n");

			if (b->data[k] == 0) {
			    a->data[k] = 0;
			} else {
			    a->data[k] = (long)((double)b->data[k] / ALITTLE_NUMBER);
			}
		    }
		} else {
		    a->data[k] = 0;
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = a->data[k] / b->data[k];
		} else {
		    a->data[k] = 0;
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	if (reverse) {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = (long)pow(b->data[k], (double)a->data[k]);
		} else {
		    a->data[k] = 0;
		}
	    }
	} else {
	    for (k = 0; k < a->length; k++) {
		if (k < b->length) {
		    a->data[k] = (long)pow((double)a->data[k], b->data[k]);
		} else {
		    a->data[k] = 1;
		}
	    }
	}
    } else {
	fprintf(stderr, "lvoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

SVector xsvoper(SVector a, char *op, SVector b)
{
    SVector c;

    c = xsvclone(a);
    svoper(c, op, b);

    return c;
}

LVector xlvoper(LVector a, char *op, LVector b)
{
    LVector c;

    c = xlvclone(a);
    lvoper(c, op, b);

    return c;
}

void svscoper(SVector a, char *op, double t)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < a->length; k++) {
	    a->data[k] = a->data[k] + (short)t;
	}
    } else if (strveq(op2, "-")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		a->data[k] = (short)t - a->data[k];
	    } else {
		a->data[k] = a->data[k] - (short)t;
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < a->length; k++) {
	    a->data[k] = (short)((double)a->data[k] * t);
	}
    } else if (strveq(op2, "/")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		if (a->data[k] != 0.0) {
		    a->data[k] = (short)(t / (double)a->data[k]);
		} else {
		    spwarning("warning: svscoper: divide by zero\n");

		    if (t == 0) {
			a->data[k] = 0;
		    } else {
			a->data[k] = (short)(t / ALITTLE_NUMBER);
		    }
		}
	    } else {
		if (t != 0.0) {
		    a->data[k] = (short)((double)a->data[k] / t);
		} else {
		    spwarning("warning: svscoper: divide by zero\n");

		    if (a->data[k] != 0) {
			a->data[k] = (short)((double)a->data[k] / ALITTLE_NUMBER);
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		a->data[k] = (short)pow(t, (double)a->data[k]);
	    } else {
		a->data[k] = (short)pow((double)a->data[k], t);
	    }
	}
    } else {
	fprintf(stderr, "svscoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}

void lvscoper(LVector a, char *op, double t)
{
    long k;
    int reverse = 0;
    char *op2 = op;

    if (strveq(op2, "!")) {
	reverse = 1;
	op2++;
    }

    if (strveq(op2, "+")) {
	for (k = 0; k < a->length; k++) {
	    a->data[k] = a->data[k] + (long)t;
	}
    } else if (strveq(op2, "-")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		a->data[k] = (long)t - a->data[k];
	    } else {
		a->data[k] = a->data[k] - (long)t;
	    }
	}
    } else if (strveq(op2, "*")) {
	for (k = 0; k < a->length; k++) {
	    a->data[k] = (long)((double)a->data[k] * t);
	}
    } else if (strveq(op2, "/")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		if (a->data[k] != 0.0) {
		    a->data[k] = (long)(t / (double)a->data[k]);
		} else {
		    spwarning("warning: lvscoper: divide by zero\n");

		    if (t == 0) {
			a->data[k] = 0;
		    } else {
			a->data[k] = (long)(t / ALITTLE_NUMBER);
		    }
		}
	    } else {
		if (t != 0.0) {
		    a->data[k] = (long)((double)a->data[k] / t);
		} else {
		    spwarning("warning: lvscoper: divide by zero\n");

		    if (a->data[k] != 0) {
			a->data[k] = (long)((double)a->data[k] / ALITTLE_NUMBER);
		    }
		}
	    }
	}
    } else if (strveq(op2, "^")) {
	for (k = 0; k < a->length; k++) {
	    if (reverse) {
		a->data[k] = (long)pow(t, (double)a->data[k]);
	    } else {
		a->data[k] = (long)pow((double)a->data[k], t);
	    }
	}
    } else {
	fprintf(stderr, "lvscoper: unknouwn operation: %s\n", op2);
	exit(1);
    }

    return;
}


SVector xsvscoper(SVector a, char *op, double t)
{
    SVector c;

    c = xsvclone(a);
    svscoper(c, op, t);

    return c;
}

LVector xlvscoper(LVector a, char *op, double t)
{
    LVector c;

    c = xlvclone(a);
    lvscoper(c, op, t);

    return c;
}

void svabs(SVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = ABS(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = (short)CABS(x->data[k], x->imag[k]);
	}
	svifree(x);
    }

    return;
}

void lvabs(LVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = ABS(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = (long)CABS(x->data[k], x->imag[k]);
	}
	lvifree(x);
    }

    return;
}

void fvabs(FVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = FABS(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = (float)CABS(x->data[k], x->imag[k]);
	}
	fvifree(x);
    }

    return;
}

void dvabs(DVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = FABS(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = CABS(x->data[k], x->imag[k]);
	}
	dvifree(x);
    }

    return;
}

SVector xsvabs(SVector x)
{
    SVector y;

    y = xsvclone(x);
    svabs(y);

    return y;
}

LVector xlvabs(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvabs(y);

    return y;
}

FVector xfvabs(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvabs(y);

    return y;
}

DVector xdvabs(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvabs(y);

    return y;
}

void svsquare(SVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = SQUARE(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = CSQUARE(x->data[k], x->imag[k]);
	}
	svifree(x);
    }

    return;
}

void lvsquare(LVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = SQUARE(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = CSQUARE(x->data[k], x->imag[k]);
	}
	lvifree(x);
    }

    return;
}

void fvsquare(FVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = SQUARE(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = CSQUARE(x->data[k], x->imag[k]);
	}
	fvifree(x);
    }

    return;
}

void dvsquare(DVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = SQUARE(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = CSQUARE(x->data[k], x->imag[k]);
	}
	dvifree(x);
    }

    return;
}

SVector xsvsquare(SVector x)
{
    SVector y;

    y = xsvclone(x);
    svsquare(y);

    return y;
}

LVector xlvsquare(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvsquare(y);

    return y;
}

FVector xfvsquare(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvsquare(y);

    return y;
}

DVector xdvsquare(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvsquare(y);

    return y;
}

void svsign(SVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] > 0) {
		x->data[k] = 1;
	    } else if (x->data[k] == 0) {
		x->data[k] = 0;
	    } else {
		x->data[k] = -1;
	    }
	}
    } else {
	double value;
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] != 0 || x->imag[k] != 0) {
		value = CABS(x->data[k], x->imag[k]);
		x->data[k] = (short)((double)x->data[k] / value);
		x->imag[k] = (short)((double)x->imag[k] / value);
	    }
	}
    }

    return;
}

void lvsign(LVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] > 0) {
		x->data[k] = 1;
	    } else if (x->data[k] == 0) {
		x->data[k] = 0;
	    } else {
		x->data[k] = -1;
	    }
	}
    } else {
	double value;
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] != 0 || x->imag[k] != 0) {
		value = CABS(x->data[k], x->imag[k]);
		x->data[k] = (long)((double)x->data[k] / value);
		x->imag[k] = (long)((double)x->imag[k] / value);
	    }
	}
    }

    return;
}

void fvsign(FVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] > 0.0) {
		x->data[k] = 1.0;
	    } else if (x->data[k] == 0.0) {
		x->data[k] = 0.0;
	    } else {
		x->data[k] = -1.0;
	    }
	}
    } else {
	double value;
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] != 0.0 || x->imag[k] != 0.0) {
		value = CABS(x->data[k], x->imag[k]);
		x->data[k] = (float)((double)x->data[k] / value);
		x->imag[k] = (float)((double)x->imag[k] / value);
	    }
	}
    }

    return;
}

void dvsign(DVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] > 0.0) {
		x->data[k] = 1.0;
	    } else if (x->data[k] == 0.0) {
		x->data[k] = 0.0;
	    } else {
		x->data[k] = -1.0;
	    }
	}
    } else {
	double value;
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] != 0.0 || x->imag[k] != 0.0) {
		value = CABS(x->data[k], x->imag[k]);
		x->data[k] = (double)x->data[k] / value;
		x->imag[k] = (double)x->imag[k] / value;
	    }
	}
    }

    return;
}

SVector xsvsign(SVector x)
{
    SVector y;

    y = xsvclone(x);
    svsign(y);

    return y;
}

LVector xlvsign(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvsign(y);

    return y;
}

FVector xfvsign(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvsign(y);

    return y;
}

DVector xdvsign(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvsign(y);

    return y;
}

SVector xsvremap(SVector x, LVector map)
{
    long k;
    SVector y;

    y = xsvalloc(map->length);
    if (x->imag != NULL) {
	svialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	if (map->data[k] >= 0 && map->data[k] < x->length) {
	    y->data[k] = x->data[map->data[k]];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[map->data[k]];
	    }
	} else {
	    y->data[k] = 0;
	    if (y->imag != NULL) {
		y->imag[k] = 0;
	    }
	}
    }

    return y;
}

LVector xlvremap(LVector x, LVector map)
{
    long k;
    LVector y;

    y = xlvalloc(map->length);
    if (x->imag != NULL) {
	lvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	if (map->data[k] >= 0 && map->data[k] < x->length) {
	    y->data[k] = x->data[map->data[k]];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[map->data[k]];
	    }
	} else {
	    y->data[k] = 0;
	    if (y->imag != NULL) {
		y->imag[k] = 0;
	    }
	}
    }

    return y;
}

FVector xfvremap(FVector x, LVector map)
{
    long k;
    FVector y;

    y = xfvalloc(map->length);
    if (x->imag != NULL) {
	fvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	if (map->data[k] >= 0 && map->data[k] < x->length) {
	    y->data[k] = x->data[map->data[k]];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[map->data[k]];
	    }
	} else {
	    y->data[k] = 0.0;
	    if (y->imag != NULL) {
		y->imag[k] = 0.0;
	    }
	}
    }

    return y;
}

DVector xdvremap(DVector x, LVector map)
{
    long k;
    DVector y;

    y = xdvalloc(map->length);
    if (x->imag != NULL) {
	dvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	if (map->data[k] >= 0 && map->data[k] < x->length) {
	    y->data[k] = x->data[map->data[k]];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[map->data[k]];
	    }
	} else {
	    y->data[k] = 0.0;
	    if (y->imag != NULL) {
		y->imag[k] = 0.0;
	    }
	}
    }

    return y;
}

SVector xsvcodiff(SVector x, double coef)
{
    long k;
    SVector y;

    if (x->length <= 1) {
	y = xsvnull();
	return y;
    }
    y = xsvalloc(x->length - 1);
    if (x->imag != NULL) {
	svialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = x->data[k + 1] - (short)(coef * (double)x->data[k]);
	if (y->imag != NULL) {
	    y->imag[k] = x->imag[k + 1] - (short)(coef * (double)x->imag[k]);
	}
    }

    return y;
}

LVector xlvcodiff(LVector x, double coef)
{
    long k;
    LVector y;

    if (x->length <= 1) {
	y = xlvnull();
	return y;
    }
    y = xlvalloc(x->length - 1);
    if (x->imag != NULL) {
	lvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = x->data[k + 1] - (long)(coef * (double)x->data[k]);
	if (y->imag != NULL) {
	    y->imag[k] = x->imag[k + 1] - (long)(coef * (double)x->imag[k]);
	}
    }

    return y;
}

FVector xfvcodiff(FVector x, double coef)
{
    long k;
    FVector y;

    if (x->length <= 1) {
	y = xfvnull();
	return y;
    }
    y = xfvalloc(x->length - 1);
    if (x->imag != NULL) {
	fvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = x->data[k + 1] - (float)(coef * (double)x->data[k]);
	if (y->imag != NULL) {
	    y->imag[k] = x->imag[k + 1] - (float)(coef * (double)x->imag[k]);
	}
    }

    return y;
}

DVector xdvcodiff(DVector x, double coef)
{
    long k;
    DVector y;

    if (x->length <= 1) {
	y = xdvnull();
	return y;
    }
    y = xdvalloc(x->length - 1);
    if (x->imag != NULL) {
	dvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = x->data[k + 1] - coef * x->data[k];
	if (y->imag != NULL) {
	    y->imag[k] = x->imag[k + 1] - coef * x->imag[k];
	}
    }

    return y;
}

LVector xsvfind(SVector x)
{
    long k, l;
    LVector y;

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0) {
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0) {
	    l++;
	}
    }

    y = xlvalloc(l);

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0) {
	    y->data[l] = k;
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0) {
	    y->data[l] = k;
	    l++;
	}
    }

    return y;
}

LVector xlvfind(LVector x)
{
    long k, l;
    LVector y;

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0) {
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0) {
	    l++;
	}
    }

    y = xlvalloc(l);

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0) {
	    y->data[l] = k;
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0) {
	    y->data[l] = k;
	    l++;
	}
    }

    return y;
}

LVector xfvfind(FVector x)
{
    long k, l;
    LVector y;

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    l++;
	}
    }

    y = xlvalloc(l);

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    y->data[l] = k;
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    y->data[l] = k;
	    l++;
	}
    }

    return y;
}

LVector xdvfind(DVector x)
{
    long k, l;
    LVector y;

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    l++;
	}
    }

    y = xlvalloc(l);

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    y->data[l] = k;
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    y->data[l] = k;
	    l++;
	}
    }

    return y;
}

DVector xdvfindv(DVector x)
{
    long k, l;
    DVector y;

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    l++;
	}
    }

    if (x->imag != NULL) {
	y = xdvrialloc(l);
    } else {
	y = xdvalloc(l);
    }

    for (k = 0, l = 0; k < x->length; k++) {
	if (x->data[k] != 0.0) {
	    y->data[l] = x->data[k];
	    if (x->imag != NULL) {
		y->imag[l] = x->imag[k];
	    }
	    l++;
	} else if (x->imag != NULL && x->imag[k] != 0.0) {
	    y->data[l] = x->data[k];
	    y->imag[l] = x->imag[k];
	    l++;
	}
    }

    return y;
}

DVector xdvsceval(DVector x, char *op, double t)
{
    long k;
    DVector y;

    y = xdvzeros(x->length);

    if (strveq(op, "<=")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] <= t) {
		y->data[k] = 1.0;
	    }
	}
    } else if (strveq(op, "<")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] < t) {
		y->data[k] = 1.0;
	    }
	}
    } else if (strveq(op, ">=")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] >= t) {
		y->data[k] = 1.0;
	    }
	}
    } else if (strveq(op, ">")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] > t) {
		y->data[k] = 1.0;
	    }
	}
    } else if (strveq(op, "==")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] == t) {
		y->data[k] = 1.0;
	    }
	}
    } else if (strveq(op, "!=")) {
	for (k = 0; k < x->length; k++) {
	    if (x->data[k] != t) {
		y->data[k] = 1.0;
	    }
	}
    } else {
	fprintf(stderr, "xdvsceval: unknouwn operation: %s\n", op);
	exit(1);
    }

    return y;
}

LVector xdvscfind(DVector x, char *op, double t)
{
    DVector y;
    LVector z;

    y = xdvsceval(x, op, t);
    z = xdvfind(y);

    xdvfree(y);

    return z;
}

DVector xdvscfindv(DVector x, char *op, double t)
{
    DVector y;
    LVector idx;
    DVector xd;

    y = xdvsceval(x, op, t);
    idx = xdvfind(y);
    xd = xdvremap(x, idx);

    xdvfree(y);
    xlvfree(idx);

    return xd;
}
#if 0
#endif

void lvcumsum(LVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += x->data[k];
	x->data[k] = sum;
    }
    if (x->imag != NULL) {
	for (k = 0, sum = 0; k < x->length; k++) {
	    sum += x->imag[k];
	    x->imag[k] = sum;
	}
    }

    return;
}

void fvcumsum(FVector x)
{
    long k;
    float sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += x->data[k];
	x->data[k] = sum;
    }
    if (x->imag != NULL) {
	for (k = 0, sum = 0.0; k < x->length; k++) {
	    sum += x->imag[k];
	    x->imag[k] = sum;
	}
    }

    return;
}

void dvcumsum(DVector x)
{
    long k;
    double sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += x->data[k];
	x->data[k] = sum;
    }
    if (x->imag != NULL) {
	for (k = 0, sum = 0.0; k < x->length; k++) {
	    sum += x->imag[k];
	    x->imag[k] = sum;
	}
    }

    return;
}

LVector xlvcumsum(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvcumsum(y);

    return y;
}

FVector xfvcumsum(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvcumsum(y);

    return y;
}

DVector xdvcumsum(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvcumsum(y);

    return y;
}

void lvcumprod(LVector x)
{
    long k;
    long prod;

    for (k = 0, prod = 1; k < x->length; k++) {
	prod *= x->data[k];
	x->data[k] = prod;
    }
    if (x->imag != NULL) {
	for (k = 0, prod = 1; k < x->length; k++) {
	    prod *= x->imag[k];
	    x->imag[k] = prod;
	}
    }

    return;
}

void fvcumprod(FVector x)
{
    long k;
    float prod;

    for (k = 0, prod = 1.0; k < x->length; k++) {
	prod *= x->data[k];
	x->data[k] = prod;
    }
    if (x->imag != NULL) {
	for (k = 0, prod = 1.0; k < x->length; k++) {
	    prod *= x->imag[k];
	    x->imag[k] = prod;
	}
    }

    return;
}

void dvcumprod(DVector x)
{
    long k;
    double prod;

    for (k = 0, prod = 1.0; k < x->length; k++) {
	prod *= x->data[k];
	x->data[k] = prod;
    }
    if (x->imag != NULL) {
	for (k = 0, prod = 1.0; k < x->length; k++) {
	    prod *= x->imag[k];
	    x->imag[k] = prod;
	}
    }

    return;
}

LVector xlvcumprod(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvcumprod(y);

    return y;
}

FVector xfvcumprod(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvcumprod(y);

    return y;
}

DVector xdvcumprod(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvcumprod(y);

    return y;
}

void fvexp(FVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = (float)exp((double)x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    cexpf(&x->data[k], &x->imag[k]);
	}
    }

    return;
}

void dvexp(DVector x)
{
    long k;

    if (x->imag == NULL) {
	for (k = 0; k < x->length; k++) {
	    x->data[k] = exp(x->data[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    cexp(&x->data[k], &x->imag[k]);
	}
    }

    return;
}

FVector xfvexp(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvexp(y);

    return y;
}

DVector xdvexp(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvexp(y);

    return y;
}

void fvlog(FVector x)
{
    int flag = 0;
    long k;

    for (k = 0; k < x->length; k++) {
	if (x->imag != NULL || x->data[k] < 0.0) {
	    flag = 1;
	    break;
	}
    }

    if (flag) {
	if (x->imag == NULL) {
	    fvizeros(x, x->length);
	}
	for (k = 0; k < x->length; k++) {
	    clogf(&x->data[k], &x->imag[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    clogf(&x->data[k], NULL);
	}
    }

    return;
}

void dvlog(DVector x)
{
    int flag = 0;
    long k;

    for (k = 0; k < x->length; k++) {
	if (x->imag != NULL || x->data[k] < 0.0) {
	    flag = 1;
	    break;
	}
    }

    if (flag) {
	if (x->imag == NULL) {
	    dvizeros(x, x->length);
	}
	for (k = 0; k < x->length; k++) {
	    clog(&x->data[k], &x->imag[k]);
	}
    } else {
	for (k = 0; k < x->length; k++) {
	    clog(&x->data[k], NULL);
	}
    }

    return;
}

FVector xfvlog(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvlog(y);

    return y;
}

DVector xdvlog(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvlog(y);

    return y;
}

void fvdecibel(FVector x)
{
    long k;

    fvsquare(x);
    
    for (k = 0; k < x->length; k++) {
	if (x->data[k] <= 0.0) {
	    spwarning("warning: fvdecibel: log of zero\n");

	    x->data[k] = 10.0 * (float)log10(ALITTLE_NUMBER);
	} else {
	    x->data[k] = 10.0 * (float)log10((double)x->data[k]);
	}
    }

    return;
}

void dvdecibel(DVector x)
{
    long k;

    dvsquare(x);
    
    for (k = 0; k < x->length; k++) {
	if (x->data[k] <= 0.0) {
	    spwarning("warning: dvdecibel: log of zero\n");

	    x->data[k] = 10.0 * log10(ALITTLE_NUMBER);
	} else {
	    x->data[k] = 10.0 * log10(x->data[k]);
	}
    }

    return;
}

FVector xfvdecibel(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvdecibel(y);

    return y;
}

DVector xdvdecibel(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvdecibel(y);

    return y;
}

FVector xfvrandn(long length)
{
    long k;
    FVector x;

    x = xfvalloc(length);
    
    for (k = 0; k < x->length; k++) {
	x->data[k] = (float)randn();
    }

    return x;
}

DVector xdvrandn(long length)
{
    long k;
    DVector x;

    x = xdvalloc(length);
    
    for (k = 0; k < x->length; k++) {
	x->data[k] = randn();
    }

    return x;
}

#if defined(__STDC__) || defined(_WIN32) || defined(MACOS)
static int qsort_numcmp(const void *x, const void *y)
#else
static int qsort_numcmp(char *x, char *y)
#endif
{
    double tx, ty;

    tx = *(double *)x;
    ty = *(double *)y;

    if (tx < ty) return (-1);
    if (tx > ty) return (1);
    return (0);
}

void dvsort(DVector x)
{
    if (x == NODATA || x->length <= 1)
	return;

    qsort(x->data, (unsigned)x->length, sizeof(double), qsort_numcmp);

    return;
}

long svsum(SVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += (long)x->data[k];
    }

    return sum;
}

long lvsum(LVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += x->data[k];
    }

    return sum;
}

float fvsum(FVector x)
{
    long k;
    float sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += x->data[k];
    }

    return sum;
}

double dvsum(DVector x)
{
    long k;
    double sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += x->data[k];
    }

    return sum;
}

long svsqsum(SVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += SQUARE((long)x->data[k]);
    }

    return sum;
}

long lvsqsum(LVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += SQUARE(x->data[k]);
    }

    return sum;
}

float fvsqsum(FVector x)
{
    long k;
    float sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += SQUARE(x->data[k]);
    }

    return sum;
}

double dvsqsum(DVector x)
{
    long k;
    double sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += SQUARE(x->data[k]);
    }

    return sum;
}

long svabssum(SVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += FABS((long)x->data[k]);
    }

    return sum;
}

long lvabssum(LVector x)
{
    long k;
    long sum;

    for (k = 0, sum = 0; k < x->length; k++) {
	sum += FABS(x->data[k]);
    }

    return sum;
}

float fvabssum(FVector x)
{
    long k;
    float sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += FABS(x->data[k]);
    }

    return sum;
}

double dvabssum(DVector x)
{
    long k;
    double sum;

    for (k = 0, sum = 0.0; k < x->length; k++) {
	sum += FABS(x->data[k]);
    }

    return sum;
}

short svmax(SVector x, long *index)
{
    long k;
    long ind;
    short max;

    ind = 0;
    max = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (max < x->data[k]) {
	    ind = k;
	    max = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return max;
}

long lvmax(LVector x, long *index)
{
    long k;
    long ind;
    long max;

    ind = 0;
    max = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (max < x->data[k]) {
	    ind = k;
	    max = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return max;
}

float fvmax(FVector x, long *index)
{
    long k;
    long ind;
    float max;

    ind = 0;
    max = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (max < x->data[k]) {
	    ind = k;
	    max = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return max;
}

double dvmax(DVector x, long *index)
{
    long k;
    long ind;
    double max;

    ind = 0;
    max = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (max < x->data[k]) {
	    ind = k;
	    max = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return max;
}

short svmin(SVector x, long *index)
{
    long k;
    long ind;
    short min;

    ind = 0;
    min = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (min > x->data[k]) {
	    ind = k;
	    min = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return min;
}

long lvmin(LVector x, long *index)
{
    long k;
    long ind;
    long min;

    ind = 0;
    min = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (min > x->data[k]) {
	    ind = k;
	    min = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return min;
}

float fvmin(FVector x, long *index)
{
    long k;
    long ind;
    float min;

    ind = 0;
    min = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (min > x->data[k]) {
	    ind = k;
	    min = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return min;
}

double dvmin(DVector x, long *index)
{
    long k;
    long ind;
    double min;

    ind = 0;
    min = x->data[ind];
    for (k = 1; k < x->length; k++) {
	if (min > x->data[k]) {
	    ind = k;
	    min = x->data[k];
	}
    }

    if (index != NULL) {
	*index = ind;
    }

    return min;
}

void svscmax(SVector x, short a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MAX(x->data[k], a);
    }

    return;
}

void lvscmax(LVector x, long a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MAX(x->data[k], a);
    }

    return;
}

void fvscmax(FVector x, float a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MAX(x->data[k], a);
    }

    return;
}

void dvscmax(DVector x, double a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MAX(x->data[k], a);
    }

    return;
}

void svscmin(SVector x, short a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MIN(x->data[k], a);
    }

    return;
}

void lvscmin(LVector x, long a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MIN(x->data[k], a);
    }

    return;
}

void fvscmin(FVector x, float a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MIN(x->data[k], a);
    }

    return;
}

void dvscmin(DVector x, double a)
{
    long k;

    for (k = 0; k < x->length; k++) {
	x->data[k] = MIN(x->data[k], a);
    }

    return;
}

float fvdot(FVector x, FVector y)
{
    long k;
    float a = 0.0;

    if (x == NODATA || y == NODATA) {
	a = 0.0;
    } else if (x->length != y->length) {
	fprintf(stderr, "fvdot: vector length must agree\n");
	exit(1);
    } else {
	for (k = 0; k < x->length; k++) {
	    a += x->data[k] * y->data[k];
	}
    }
    
    return a;
}

double dvdot(DVector x, DVector y)
{
    long k;
    double a = 0.0;

    if (x == NODATA || y == NODATA) {
	a = 0.0;
    } else if (x->length != y->length) {
	fprintf(stderr, "dvdot: vector length must agree\n");
	exit(1);
    } else {
	for (k = 0; k < x->length; k++) {
	    a += x->data[k] * y->data[k];
	}
    }
    
    return a;
}

void dvmorph(DVector x, DVector y, double rate)
{
    long k;
    double a, b;

    if (x == NODATA)
	return;
    
    b = rate;
    a = 1.0 - b;
    
    for (k = 0; k < x->length; k++) {
	if (y != NODATA && k < y->length) {
	    x->data[k] = a * x->data[k] + b * y->data[k];
	} else {
	    x->data[k] = a * x->data[k];
	}
    }
    
    if (x->imag != NULL) {
	for (k = 0; k < x->length; k++) {
	    if (y != NODATA && (y->imag != NULL && k < y->length)) {
		x->imag[k] = a * x->imag[k] + b * y->imag[k];
	    } else {
		x->imag[k] = a * x->imag[k];
	    }
	}
    }
    
    return;
}

DVector xdvmorph(DVector x, DVector y, double rate)
{
    DVector z;

    if (x == NODATA && y == NODATA) {
	z = NODATA;
    } else if (x == NODATA) {
	z = xdvzeros(y->length);
    } else {
	z = xdvclone(x);
    }
    dvmorph(z, y, rate);
    
    return z;
}
#if 0
#endif
