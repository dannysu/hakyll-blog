/*
 *	window.h
 */

#ifndef __WINDOW_H
#define __WINDOW_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void blackmanf(float window[], long length);
extern void blackman(double window[], long length);
extern FVector xfvblackman(long length);
extern DVector xdvblackman(long length);

extern void hammingf(float window[], long length);
extern void hamming(double window[], long length);
extern FVector xfvhamming(long length);
extern DVector xdvhamming(long length);

extern void hanningf(float window[], long length);
extern void hanning(double window[], long length);
extern FVector xfvhanning(long length);
extern DVector xdvhanning(long length);

extern void gausswinf(float window[], long length);
extern void gausswin(double window[], long length);
extern FVector xfvgausswin(long length);
extern DVector xdvgausswin(long length);
    
extern void nblackmanf(float window[], long length);
extern void nblackman(double window[], long length);
extern FVector xfvnblackman(long length);
extern DVector xdvnblackman(long length);

extern void nhammingf(float window[], long length);
extern void nhamming(double window[], long length);
extern FVector xfvnhamming(long length);
extern DVector xdvnhamming(long length);

extern void nhanningf(float window[], long length);
extern void nhanning(double window[], long length);
extern FVector xfvnhanning(long length);
extern DVector xdvnhanning(long length);

extern void nboxcarf(float window[], long length);
extern void nboxcar(double window[], long length);
extern FVector xfvnboxcar(long length);
extern DVector xdvnboxcar(long length);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __WINDOW_H */
