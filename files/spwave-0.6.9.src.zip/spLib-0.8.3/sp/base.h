/*
 *	base.h
 */

#ifndef __BASE_H
#define __BASE_H

#include <sp/spBase.h>
#include <sp/spFile.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef round
#define round spRound
#endif
#ifndef fix
#define fix spFix
#endif
#ifndef rem
#define rem spRem
#endif
#ifndef factorial
#define factorial spFactorial
#endif
#ifndef ftos
#define ftos spFtos
#endif
#ifndef nextpow2
#define nextpow2 spNextPow2
#endif

#define setwarningflag spSetWarningFlag
#define spwarning spWarning
#define setmessageflag spSetMessageFlag
#define spmessage spMessage
#define sperror	spError
#define setdebugstdout spSetDebugStdout
#define setdebuglevel spSetDebugLevel
#define spdebug spDebug
#define spprogerror spProgError
				
#if defined(MACOS)
#pragma import on
#endif

extern void randun_no_init(void);
extern double randun(void);
extern double randun1(void);
extern void gauss_use_rand(int flag);
extern double gauss(double mu, double sigma);
extern long gcd(long x, long y);
extern void cexpf(float *xr, float *xi);
extern void cexp(double *xr, double *xi);
extern void clogf(float *xr, float *xi);
extern void clog(double *xr, double *xi);
extern void randsort(void *data, int num, int size);
extern void decibel(double *x, long length);
extern void decibelp(double *x, long length);

#if defined(MACOS)
#pragma import off
#endif

#define randn()	gauss(0.0, 1.0)

#define getbasename spGetBaseName
#define xgetbasename xspGetBaseName
#define xgetdirname xspGetDirName
#define xgetexactname xspGetExactName

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __BASE_H */
