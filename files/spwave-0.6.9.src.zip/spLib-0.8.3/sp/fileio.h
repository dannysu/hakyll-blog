/*
 *	fileio.h
 */

#ifndef __FILEIO_H
#define __FILEIO_H

#include <sp/spFile.h>

#include <sp/vector.h>
#include <sp/matrix.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern int dvreadfirst(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp);
extern int dvreadsfirst(DVector vector, long shift, long length, int swap, FILE *fp);
extern int dvreaddfirst(DVector vector, long shift, long length, int swap, FILE *fp);
extern int dvreadframe(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp);
extern int dvreadsframe(DVector vector, long shift, long length, int swap, FILE *fp);
extern int dvreaddframe(DVector vector, long shift, long length, int swap, FILE *fp);
extern int dvwriteframe(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp);
extern int dvwritesframe(DVector vector, long shift, long length, int swap, FILE *fp);
extern int dvwritedframe(DVector vector, long shift, long length, int swap, FILE *fp);

extern SVector xsvreadssignal(char *filename, int headlen, int swap);
extern LVector xlvreadlsignal(char *filename, int headlen, int swap);
extern DVector xdvreaddsignal(char *filename, int headlen, int swap);
extern DVector xdvreadssignal(char *filename, int headlen, int swap);
extern DVector xdvreadlsignal(char *filename, int headlen, int swap);
extern DVector xdvreadfsignal(char *filename, int headlen, int swap);
extern void svwritessignal(char *filename, SVector vector, int swap);
extern void lvwritelsignal(char *filename, LVector vector, int swap);
extern void dvwritedsignal(char *filename, DVector vector, int swap);
extern void dvwritessignal(char *filename, DVector vector, int swap);
extern void dvwritelsignal(char *filename, DVector vector, int swap);
extern void dvwritefsignal(char *filename, DVector vector, int swap);

extern LMatrix xlmreadlmatrix(char *filename, long ncol, int swap);
extern DMatrix xdmreaddmatrix(char *filename, long ncol, int swap);
extern void lmwritelmatrix(char *filename, LMatrix mat, int swap);
extern void dmwritedmatrix(char *filename, DMatrix mat, int swap);

extern int dvreaddvector_txt(char *filename, DVector vector);
extern DVector xdvreaddvector_txt(char *filename);
extern int dvwritedvector_txt(char *filename, DVector vector);

extern int dvreadcol_txt(char *filename, int col, DVector vector);
extern DVector xdvreadcol_txt(char *filename, int col);

extern float fvmaxamp(FVector vec);
extern double dvmaxamp(DVector vec);
extern float fvadjustamp(FVector vec, float amp);
extern double dvadjustamp(DVector vec, double amp);
extern float fvlimitamp(FVector vec, float amp);
extern double dvlimitamp(DVector vec, double amp);

extern DVector xdvextractchannel(DVector x, int channel, int num_channel);

extern void svdump(SVector vec);
extern void lvdump(LVector vec);
extern void fvdump(FVector vec);
extern void dvdump(DVector vec);

extern void svfdump(SVector vec, FILE *fp);
extern void lvfdump(LVector vec, FILE *fp);
extern void fvfdump(FVector vec, FILE *fp);
extern void dvfdump(DVector vec, FILE *fp);

extern void lmfdump(LMatrix mat, FILE *fp);
extern void dmfdump(DMatrix mat, FILE *fp);

extern void dvnfdump(FILE *fp, DVector vec, ...);

#if defined(MACOS)
#pragma import off
#endif

#define xsvreadsvector(filename, swap) xsvreadssignal((filename), 0, (swap))
#define xlvreadlvector(filename, swap) xlvreadlsignal((filename), 0, (swap))
#define xdvreaddvector(filename, swap) xdvreaddsignal((filename), 0, (swap))
#define xdvreadsvector(filename, swap) xdvreadssignal((filename), 0, (swap))
#define xdvreadlvector(filename, swap) xdvreadlsignal((filename), 0, (swap))
#define xdvreadfvector(filename, swap) xdvreadfsignal((filename), 0, (swap))

#define svwritesvector svwritessignal
#define lvwritelvector lvwritelsignal
#define dvwritedvector dvwritedsignal
#define dvwritesvector dvwritessignal
#define dvwritelvector dvwritelsignal
#define dvwritefvector dvwritefsignal

/* for backwards compatibility */
#define xreadssignal xsvreadssignal
#define xreaddsignal xdvreaddsignal
#define writessignal svwritessignal
#define writedsignal dvwritedsignal

#define xreadsvector xsvreadsvector
#define xreaddvector xdvreaddvector
#define writesvector svwritesvector
#define writedvector dvwritedvector

#define xreadlmatrix xlmreadlmatrix
#define xreaddmatrix xdmreaddmatrix
#define writelmatrix lmwritelmatrix
#define writedmatrix dmwritedmatrix

#define readdvector_txt dvreaddvector_txt
#define xreaddvector_txt xdvreaddvector_txt
#define writedvector_txt dvwritedvector_txt

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __FILEIO_H */
