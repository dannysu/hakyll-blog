/*
 *	base.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/memory.h>

#if 1
/*
 *	ran1: random number generator
 *
 *	Reference: NUMERICAL RECIPES in C
 */
#define R1_IA 16807
#define R1_IM 2147483647
#define R1_AM (1.0 / R1_IM)
#define R1_IQ 127773
#define R1_IR 2836
#define R1_NTAB 32
#define R1_NDIV (1 + (R1_IM - 1) / R1_NTAB)
#define R1_EPS (1.2e-7)
#define R1_RNMX (1.0 - R1_EPS)

double ran1(long *idum)
{
    int j;
    long k;
    static long iy = 0;
    static long iv[R1_NTAB];
    double temp;

    if (*idum <= 0 || !iy) {
	if (-(*idum) < 1) {
	    *idum = 1;
	} else {
	    *idum = -(*idum);
	}
	
	for (j = R1_NTAB + 7; j >= 0; j--) {
	    k = (*idum) / R1_IQ;
	    *idum = R1_IA * (*idum - k * R1_IQ) - R1_IR * k;

	    if (*idum < 0) *idum += R1_IM;
	    if (j < R1_NTAB)  iv[j] = *idum;
	}
	iy = iv[0];
    }

    k = (*idum) / R1_IQ;
    *idum = R1_IA * (*idum - k * R1_IQ) - R1_IR * k;

    if (*idum < 0) *idum += R1_IM;

    j = iy / R1_NDIV;
    iy = iv[j];
    iv[j] = *idum;

    if ((temp = R1_AM * (double)iy) > R1_RNMX) return R1_RNMX;
    else return temp;
}
#endif

static int sp_randun_init = 0;
static int sp_randun1_init = 0;

void randun_no_init(void)
{
    sp_randun_init = 1;
    sp_randun1_init = 1;
    return;
}

double randun(void)
{
    double x;
    
    /* reset random function */
    if (!sp_randun_init) {
	srand((int)spGetProcessId());
	sp_randun_init = 1;
    }

    x = (double)rand() / ((double)RAND_MAX + 1.0);

    return x;
}

double randun1(void)
{
    double x;
    static long idum = -1;
    
    /* reset random function */
    if (!sp_randun1_init) {
	idum = -spGetProcessId();
	ran1(&idum);
	sp_randun1_init = 1;
    }

    x = ran1(&idum);

    return x;
}

static int sp_gauss_use_rand = 0;

void gauss_use_rand(int flag)
{
    sp_gauss_use_rand = (flag ? 1 : 0);
    return;
}

/*
 *	mu : mean  sigma : standard deviation
 */
double gauss(double mu, double sigma)
{
    int i;
    double a, x;

    if (sp_gauss_use_rand) {
	for (i = 0, a = 0.0; i < 12; i++) {
	    a += randun();
	}
    } else {
	for (i = 0, a = 0.0; i < 12; i++) {
	    a += randun1();
	}
    }

    x = (a - 6.0) * sigma + mu;

    return x;
}

long gcd(long x, long y)
{
    long a;

    while (y != 0) {
	a = x % y;
	x = y;
	y = a;
    }

    return x;
}

void cexpf(float *xr, float *xi)
{
    double a;

    if (xr == NULL) {
	return;
    } else if (*xr == 0.0) {
	*xr = (float)cos((double)*xi);
	*xi = (float)sin((double)*xi);
    } else if (xi != NULL && *xi != 0.0) {
	a = exp((double)*xr);
	*xr = (float)(a * cos((double)*xi));
	*xi = (float)(a * sin((double)*xi));
    } else {
	*xr = (float)exp((double)*xr);
    }

    return;
}

void cexp(double *xr, double *xi)
{
    double a;

    if (xr == NULL) {
	return;
    } else if (*xr == 0.0) {
	*xr = cos(*xi);
	*xi = sin(*xi);
    } else if (xi != NULL && *xi != 0.0) {
	a = exp(*xr);
	*xr = a * cos(*xi);
	*xi = a * sin(*xi);
    } else {
	*xr = exp(*xr);
    }

    return;
}

void clogf(float *xr, float *xi)
{
    double a;

    if (*xr < 0.0 || (xi != NULL && *xi != 0.0)) {
	a = CABS(*xr, *xi);
	*xi = (float)atan2((double)*xi, (double)*xr);
	*xr = (float)log(a);
    } else {
	if (*xr == 0.0) {
	    spwarning("warning: clogf: log of zero\n");
	    
	    *xr = (float)log(ALITTLE_NUMBER);
	} else {
	    *xr = (float)log((double)*xr);
	}
    }

    return;
}

void clog(double *xr, double *xi)
{
    double a;

    if (*xr < 0.0 || (xi != NULL && *xi != 0.0)) {
	a = CABS(*xr, *xi);
	*xi = atan2(*xi, *xr);
	*xr = log(a);
    } else {
	if (*xr == 0.0) {
	    spwarning("warning: clog: log of zero\n");
	    
	    *xr = log(ALITTLE_NUMBER);
	} else {
	    *xr = log(*xr);
	}
    }

    return;
}

#if defined(__STDC__) || defined(_WIN32) || defined(MACOS)
static int randsort_numcmp(const void *x, const void *y)
#else
static int randsort_numcmp(char *x, char *y)
#endif
{
    double tx, ty;

    tx = randn();
    ty = randn();

    if (tx < ty) {
	return (-1);
    } else if (tx > ty) {
	return (1);
    } else {
	return (0);
    }
}

/* Do not use this function for important purpose. */
void randsort(void *data, int num, int size)
{
    qsort(data, (unsigned)num, (unsigned)size, randsort_numcmp);

    return;
}

void decibel(double *x, long length)
{
    long k;

    for (k = 0; k < length; k++) {
	x[k] = x[k] * x[k];
	if (x[k] <= 0.0) {
	    spwarning("warning: decibel: log of zero\n");
	    
	    x[k] = 10.0 * log10(ALITTLE_NUMBER);
	} else {
	    x[k] = 10.0 * log10(x[k]);
	}
    }

    return;
}

void decibelp(double *x, long length)
{
    long k;

    for (k = 0; k < length; k++) {
	if (x[k] <= 0.0) {
	    spwarning("warning: decibelp: log of zero\n");
	    
	    x[k] = 10.0 * log10(ALITTLE_NUMBER);
	} else {
	    x[k] = 10.0 * log10(x[k]);
	}
    }

    return;
}

