/*
 *	vector.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/memory.h>
#include <sp/vector.h>

/*
 *	allocate and free memory
 */
SVector xsvalloc(long length)
{
    SVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _SVector);
    x->data = xalloc(MAX(length, 1), short);
    x->imag = NULL;
    x->length = length;

    return x;
}

LVector xlvalloc(long length)
{
    LVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _LVector);
    x->data = xalloc(MAX(length, 1), long);
    x->imag = NULL;
    x->length = length;

    return x;
}

FVector xfvalloc(long length)
{
    FVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _FVector);
    x->data = xalloc(MAX(length, 1), float);
    x->imag = NULL;
    x->length = length;

    return x;
}

DVector xdvalloc(long length)
{
    DVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _DVector);
    x->data = xalloc(MAX(length, 1), double);
    x->imag = NULL;
    x->length = length;

    return x;
}

void xsvfree(SVector x)
{
    if (x != NULL) {
	if (x->data != NULL) {
	    xfree(x->data);
	}
	if (x->imag != NULL) {
	    xfree(x->imag);
	}
	xfree(x);
    }

    return;
}

void xlvfree(LVector x)
{
    if (x != NULL) {
	if (x->data != NULL) {
	    xfree(x->data);
	}
	if (x->imag != NULL) {
	    xfree(x->imag);
	}
	xfree(x);
    }

    return;
}

void xfvfree(FVector x)
{
    if (x != NULL) {
	if (x->data != NULL) {
	    xfree(x->data);
	}
	if (x->imag != NULL) {
	    xfree(x->imag);
	}
	xfree(x);
    }

    return;
}

void xdvfree(DVector x)
{
    if (x != NULL) {
	if (x->data != NULL) {
	    xfree(x->data);
	}
	if (x->imag != NULL) {
	    xfree(x->imag);
	}
	xfree(x);
    }

    return;
}

void svialloc(SVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    x->imag = xalloc(x->length, short);

    return;
}

void lvialloc(LVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    x->imag = xalloc(x->length, long);

    return;
}

void fvialloc(FVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    x->imag = xalloc(x->length, float);

    return;
}

void dvialloc(DVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    x->imag = xalloc(x->length, double);

    return;
}

void svifree(SVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    
    return;
}

void lvifree(LVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    
    return;
}

void fvifree(FVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    
    return;
}

void dvifree(DVector x)
{
    if (x->imag != NULL) {
	xfree(x->imag);
    }
    
    return;
}

SVector xsvrialloc(long length)
{
    SVector x;

    x = xsvalloc(length);
    svialloc(x);

    return x;
}

LVector xlvrialloc(long length)
{
    LVector x;

    x = xlvalloc(length);
    lvialloc(x);

    return x;
}

FVector xfvrialloc(long length)
{
    FVector x;

    x = xfvalloc(length);
    fvialloc(x);

    return x;
}

DVector xdvrialloc(long length)
{
    DVector x;

    x = xdvalloc(length);
    dvialloc(x);

    return x;
}

SVector xsvrealloc(SVector x, long length)
{
    long k;
    
    if (x == NODATA) {
	x = xsvzeros(length);
    } else {
	if (length > x->length) {
	    x->data = xrealloc(x->data, length, short);
	    for (k = x->length; k < length; k++) {
		x->data[k] = 0;
	    }
	}

	x->length = length;
    }

    return x;
}

LVector xlvrealloc(LVector x, long length)
{
    long k;
    
    if (x == NODATA) {
	x = xlvzeros(length);
    } else {
	if (length > x->length) {
	    x->data = xrealloc(x->data, length, long);
	    for (k = x->length; k < length; k++) {
		x->data[k] = 0;
	    }
	}
	x->length = length;
    }

    return x;
}

FVector xfvrealloc(FVector x, long length)
{
    long k;
    
    if (x == NODATA) {
	x = xfvzeros(length);
    } else {
	if (length > x->length) {
	    x->data = xrealloc(x->data, length, float);
	    for (k = x->length; k < length; k++) {
		x->data[k] = 0.0;
	    }
	}
	x->length = length;
    }

    return x;
}

DVector xdvrealloc(DVector x, long length)
{
    long k;
    
    if (x == NODATA) {
	x = xdvzeros(length);
    } else {
	if (length > x->length) {
	    x->data = xrealloc(x->data, length, double);
	    for (k = x->length; k < length; k++) {
		x->data[k] = 0.0;
	    }
	}
	x->length = length;
    }

    return x;
}

SVectors xsvsalloc(long num)
{
    long k;
    SVectors xs;

    xs = xalloc(1, struct _SVectors);
    xs->vector = xalloc(MAX(num, 1), SVector);
    xs->num_vector = num;
    
    for (k = 0; k < xs->num_vector; k++) {
	xs->vector[k] = NODATA;
    }

    return xs;
}

LVectors xlvsalloc(long num)
{
    long k;
    LVectors xs;

    xs = xalloc(1, struct _LVectors);
    xs->vector = xalloc(MAX(num, 1), LVector);
    xs->num_vector = num;
    
    for (k = 0; k < xs->num_vector; k++) {
	xs->vector[k] = NODATA;
    }

    return xs;
}

FVectors xfvsalloc(long num)
{
    long k;
    FVectors xs;

    xs = xalloc(1, struct _FVectors);
    xs->vector = xalloc(MAX(num, 1), FVector);
    xs->num_vector = num;
    
    for (k = 0; k < xs->num_vector; k++) {
	xs->vector[k] = NODATA;
    }

    return xs;
}

DVectors xdvsalloc(long num)
{
    long k;
    DVectors xs;

    xs = xalloc(1, struct _DVectors);
    xs->vector = xalloc(MAX(num, 1), DVector);
    xs->num_vector = num;
    
    for (k = 0; k < xs->num_vector; k++) {
	xs->vector[k] = NODATA;
    }

    return xs;
}

void xsvsfree(SVectors xs)
{
    long k;

    if (xs != NULL) {
	if (xs->vector != NULL) {
	    for (k = 0; k < xs->num_vector; k++) {
		if (xs->vector[k] != NODATA) {
		    xsvfree(xs->vector[k]);
		}
	    }
	    xfree(xs->vector);
	}
	xfree(xs);
    }

    return;
}

void xlvsfree(LVectors xs)
{
    long k;

    if (xs != NULL) {
	if (xs->vector != NULL) {
	    for (k = 0; k < xs->num_vector; k++) {
		if (xs->vector[k] != NODATA) {
		    xlvfree(xs->vector[k]);
		}
	    }
	    xfree(xs->vector);
	}
	xfree(xs);
    }

    return;
}

void xfvsfree(FVectors xs)
{
    long k;

    if (xs != NULL) {
	if (xs->vector != NULL) {
	    for (k = 0; k < xs->num_vector; k++) {
		if (xs->vector[k] != NODATA) {
		    xfvfree(xs->vector[k]);
		}
	    }
	    xfree(xs->vector);
	}
	xfree(xs);
    }

    return;
}

void xdvsfree(DVectors xs)
{
    long k;

    if (xs != NULL) {
	if (xs->vector != NULL) {
	    for (k = 0; k < xs->num_vector; k++) {
		if (xs->vector[k] != NODATA) {
		    xdvfree(xs->vector[k]);
		}
	    }
	    xfree(xs->vector);
	}
	xfree(xs);
    }

    return;
}

SVector xsvcplx(SVector xr, SVector xi)
{
    long k;
    SVector z;

    if (xr != NODATA && xi != NODATA) {
	z = xsvrialloc(MIN(xr->length, xi->length));
    } else if (xr != NODATA) {
	z = xsvrialloc(xr->length);
    } else if (xi != NODATA) {
	z = xsvrialloc(xi->length);
    } else {
#if 0
	z = xsvnull();
	return z;
#else
	return NODATA;
#endif
    }

    for (k = 0; k < z->length; k++) {
	if (xr != NODATA) {
	    z->data[k] = xr->data[k];
	} else {
	    z->data[k] = 0;
	}
	if (xi != NODATA) {
	    z->imag[k] = xi->data[k];
	} else {
	    z->imag[k] = 0;
	}
    }

    return z;
}

LVector xlvcplx(LVector xr, LVector xi)
{
    long k;
    LVector z;

    if (xr != NODATA && xi != NODATA) {
	z = xlvrialloc(MIN(xr->length, xi->length));
    } else if (xr != NODATA) {
	z = xlvrialloc(xr->length);
    } else if (xi != NODATA) {
	z = xlvrialloc(xi->length);
    } else {
#if 0
	z = xlvnull();
	return z;
#else
	return NODATA;
#endif
    }

    for (k = 0; k < z->length; k++) {
	if (xr != NODATA) {
	    z->data[k] = xr->data[k];
	} else {
	    z->data[k] = 0;
	}
	if (xi != NODATA) {
	    z->imag[k] = xi->data[k];
	} else {
	    z->imag[k] = 0;
	}
    }

    return z;
}

FVector xfvcplx(FVector xr, FVector xi)
{
    long k;
    FVector z;

    if (xr != NODATA && xi != NODATA) {
	z = xfvrialloc(MIN(xr->length, xi->length));
    } else if (xr != NODATA) {
	z = xfvrialloc(xr->length);
    } else if (xi != NODATA) {
	z = xfvrialloc(xi->length);
    } else {
#if 0
	z = xfvnull();
	return z;
#else
	return NODATA;
#endif
    }

    for (k = 0; k < z->length; k++) {
	if (xr != NODATA) {
	    z->data[k] = xr->data[k];
	} else {
	    z->data[k] = 0.0;
	}
	if (xi != NODATA) {
	    z->imag[k] = xi->data[k];
	} else {
	    z->imag[k] = 0.0;
	}
    }

    return z;
}

DVector xdvcplx(DVector xr, DVector xi)
{
    long k;
    DVector z;

    if (xr != NODATA && xi != NODATA) {
	z = xdvrialloc(MIN(xr->length, xi->length));
    } else if (xr != NODATA) {
	z = xdvrialloc(xr->length);
    } else if (xi != NODATA) {
	z = xdvrialloc(xi->length);
    } else {
#if 0
	z = xdvnull();
	return z;
#else
	return NODATA;
#endif
    }

    for (k = 0; k < z->length; k++) {
	if (xr != NODATA) {
	    z->data[k] = xr->data[k];
	} else {
	    z->data[k] = 0.0;
	}
	if (xi != NODATA) {
	    z->imag[k] = xi->data[k];
	} else {
	    z->imag[k] = 0.0;
	}
    }

    return z;
}

void svreal(SVector x)
{
    if (x->imag != NULL) {
	svifree(x);
    }

    return;
} 

void lvreal(LVector x)
{
    if (x->imag != NULL) {
	lvifree(x);
    }

    return;
} 

void fvreal(FVector x)
{
    if (x->imag != NULL) {
	fvifree(x);
    }

    return;
} 

void dvreal(DVector x)
{
    if (x->imag != NULL) {
	dvifree(x);
    }

    return;
} 

void svimag(SVector x)
{
    if (x->imag == NULL) {
	svzeros(x, x->length);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;

    return;
} 

void lvimag(LVector x)
{
    if (x->imag == NULL) {
	lvzeros(x, x->length);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;

    return;
} 

void fvimag(FVector x)
{
    if (x->imag == NULL) {
	fvzeros(x, x->length);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;

    return;
} 

void dvimag(DVector x)
{
    if (x->imag == NULL) {
	dvzeros(x, x->length);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;

    return;
} 

SVector xsvreal(SVector x)
{
    long k;
    SVector y;

    y = xsvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

LVector xlvreal(LVector x)
{
    long k;
    LVector y;

    y = xlvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

FVector xfvreal(FVector x)
{
    long k;
    FVector y;

    y = xfvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

DVector xdvreal(DVector x)
{
    long k;
    DVector y;

    y = xdvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

SVector xsvimag(SVector x)
{
    long k;
    SVector y;

    if (x->imag == NULL) {
	y = xsvzeros(x->length);

	return y;
    }
    y = xsvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

LVector xlvimag(LVector x)
{
    long k;
    LVector y;

    if (x->imag == NULL) {
	y = xlvzeros(x->length);

	return y;
    }
    y = xlvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

FVector xfvimag(FVector x)
{
    long k;
    FVector y;

    if (x->imag == NULL) {
	y = xfvzeros(x->length);

	return y;
    }
    y = xfvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

DVector xdvimag(DVector x)
{
    long k;
    DVector y;

    if (x->imag == NULL) {
	y = xdvzeros(x->length);

	return y;
    }
    y = xdvalloc(x->length);

    /* copy data */
    for (k = 0; k < x->length; k++) {
	y->data[k] = x->data[k];
    }

    return y;
} 

void svconj(SVector x)
{
    long k;

    if (x->imag == NULL) {
	return;
    }

    for (k = 0; k < x->length; k++) {
	x->imag[k] = -x->imag[k];
    }

    return;
}

void lvconj(LVector x)
{
    long k;

    if (x->imag == NULL) {
	return;
    }

    for (k = 0; k < x->length; k++) {
	x->imag[k] = -x->imag[k];
    }

    return;
}

void fvconj(FVector x)
{
    long k;

    if (x->imag == NULL) {
	return;
    }

    for (k = 0; k < x->length; k++) {
	x->imag[k] = -x->imag[k];
    }

    return;
}

void dvconj(DVector x)
{
    long k;

    if (x->imag == NULL) {
	return;
    }

    for (k = 0; k < x->length; k++) {
	x->imag[k] = -x->imag[k];
    }

    return;
}

SVector xsvconj(SVector x)
{
    SVector y;

    y = xsvclone(x);
    svconj(y);

    return y;
}

LVector xlvconj(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvconj(y);

    return y;
}

FVector xfvconj(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvconj(y);

    return y;
}

DVector xdvconj(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvconj(y);

    return y;
}

void svriswap(SVector x)
{
    short *p;

    if (x->imag == NULL) {
	svizeros(x, x->length);
    }

    p = x->data;
    x->data = x->imag;
    x->imag = p;

    return;
}

void lvriswap(LVector x)
{
    long *p;

    if (x->imag == NULL) {
	lvizeros(x, x->length);
    }

    p = x->data;
    x->data = x->imag;
    x->imag = p;

    return;
}

void fvriswap(FVector x)
{
    float *p;

    if (x->imag == NULL) {
	fvizeros(x, x->length);
    }

    p = x->data;
    x->data = x->imag;
    x->imag = p;

    return;
}

void dvriswap(DVector x)
{
    double *p;

    if (x->imag == NULL) {
	dvizeros(x, x->length);
    }

    p = x->data;
    x->data = x->imag;
    x->imag = p;

    return;
}

SVector xsvriswap(SVector x)
{
    SVector y;

    y = xsvclone(x);
    svriswap(y);

    return y;
}

LVector xlvriswap(LVector x)
{
    LVector y;

    y = xlvclone(x);
    lvriswap(y);

    return y;
}

FVector xfvriswap(FVector x)
{
    FVector y;

    y = xfvclone(x);
    fvriswap(y);

    return y;
}

DVector xdvriswap(DVector x)
{
    DVector y;

    y = xdvclone(x);
    dvriswap(y);

    return y;
}

/*
 *	copy data of x into y
 */
void svcopy(SVector y, SVector x)
{
    long k;
    long length;

    length = MIN(y->length, x->length);

    /* copy data */
    for (k = 0; k < length; k++) {
	y->data[k] = x->data[k];
    }
    if (x->imag != NULL && y->imag != NULL) {
	for (k = 0; k < length; k++) {
	    y->imag[k] = x->imag[k];
	}
    }

    return;
}

void lvcopy(LVector y, LVector x)
{
    long k;
    long length;

    length = MIN(y->length, x->length);

    /* copy data */
    for (k = 0; k < length; k++) {
	y->data[k] = x->data[k];
    }
    if (x->imag != NULL && y->imag != NULL) {
	for (k = 0; k < length; k++) {
	    y->imag[k] = x->imag[k];
	}
    }

    return;
}

void fvcopy(FVector y, FVector x)
{
    long k;
    long length;

    length = MIN(y->length, x->length);

    /* copy data */
    for (k = 0; k < length; k++) {
	y->data[k] = x->data[k];
    }
    if (x->imag != NULL && y->imag != NULL) {
	for (k = 0; k < length; k++) {
	    y->imag[k] = x->imag[k];
	}
    }

    return;
}

void dvcopy(DVector y, DVector x)
{
    long k;
    long length;

    length = MIN(y->length, x->length);

    /* copy data */
    for (k = 0; k < length; k++) {
	y->data[k] = x->data[k];
    }
    if (x->imag != NULL && y->imag != NULL) {
	for (k = 0; k < length; k++) {
	    y->imag[k] = x->imag[k];
	}
    }

    return;
}

/*
 *	make clone of input vector
 */
SVector xsvclone(SVector x)
{
    SVector y;

    /* memory allocate */
    y = xsvalloc(x->length);
    if (x->imag != NULL) {
	svialloc(y);
    }
    
    /* copy data */
    svcopy(y, x);

    return y;
}

LVector xlvclone(LVector x)
{
    LVector y;

    /* memory allocate */
    y = xlvalloc(x->length);
    if (x->imag != NULL) {
	lvialloc(y);
    }
    
    /* copy data */
    lvcopy(y, x);

    return y;
}

FVector xfvclone(FVector x)
{
    FVector y;

    /* memory allocate */
    y = xfvalloc(x->length);
    if (x->imag != NULL) {
	fvialloc(y);
    }
    
    /* copy data */
    fvcopy(y, x);

    return y;
}

DVector xdvclone(DVector x)
{
    DVector y;

    /* memory allocate */
    y = xdvalloc(x->length);
    if (x->imag != NULL) {
	dvialloc(y);
    }
    
    /* copy data */
    dvcopy(y, x);

    return y;
}

/*
 *	concatenate vector
 */
SVector xsvcat(SVector x, SVector y)
{
    long k;
    SVector z;

    /* memory allocate */
    z = xsvalloc(x->length + y->length);
    if (x->imag != NULL || y->imag != NULL) {
	svialloc(z);
    }
    
    /* concatenate data */
    for (k = 0; k < z->length; k++) {
	if (k < x->length) {
	    z->data[k] = x->data[k];
	} else {
	    z->data[k] = y->data[k - x->length];
	}
    }
    if (z->imag != NULL) {
	for (k = 0; k < z->length; k++) {
	    if (k < x->length) {
		if (x->imag != NULL) {
		    z->imag[k] = x->imag[k];
		} else {
		    z->imag[k] = 0;
		}
	    } else {
		if (y->imag != NULL) {
		    z->imag[k] = y->imag[k - x->length];
		} else {
		    z->imag[k] = 0;
		}
	    }
	}
    }

    return z;
}

LVector xlvcat(LVector x, LVector y)
{
    long k;
    LVector z;

    /* memory allocate */
    z = xlvalloc(x->length + y->length);
    if (x->imag != NULL || y->imag != NULL) {
	lvialloc(z);
    }
    
    /* concatenate data */
    for (k = 0; k < z->length; k++) {
	if (k < x->length) {
	    z->data[k] = x->data[k];
	} else {
	    z->data[k] = y->data[k - x->length];
	}
    }
    if (z->imag != NULL) {
	for (k = 0; k < z->length; k++) {
	    if (k < x->length) {
		if (x->imag != NULL) {
		    z->imag[k] = x->imag[k];
		} else {
		    z->imag[k] = 0;
		}
	    } else {
		if (y->imag != NULL) {
		    z->imag[k] = y->imag[k - x->length];
		} else {
		    z->imag[k] = 0;
		}
	    }
	}
    }

    return z;
}

FVector xfvcat(FVector x, FVector y)
{
    long k;
    FVector z;

    /* memory allocate */
    z = xfvalloc(x->length + y->length);
    if (x->imag != NULL || y->imag != NULL) {
	fvialloc(z);
    }
    
    /* concatenate data */
    for (k = 0; k < z->length; k++) {
	if (k < x->length) {
	    z->data[k] = x->data[k];
	} else {
	    z->data[k] = y->data[k - x->length];
	}
    }
    if (z->imag != NULL) {
	for (k = 0; k < z->length; k++) {
	    if (k < x->length) {
		if (x->imag != NULL) {
		    z->imag[k] = x->imag[k];
		} else {
		    z->imag[k] = 0.0;
		}
	    } else {
		if (y->imag != NULL) {
		    z->imag[k] = y->imag[k - x->length];
		} else {
		    z->imag[k] = 0.0;
		}
	    }
	}
    }

    return z;
}

DVector xdvcat(DVector x, DVector y)
{
    long k;
    DVector z;

    /* memory allocate */
    z = xdvalloc(x->length + y->length);
    if (x->imag != NULL || y->imag != NULL) {
	dvialloc(z);
    }
    
    /* concatenate data */
    for (k = 0; k < z->length; k++) {
	if (k < x->length) {
	    z->data[k] = x->data[k];
	} else {
	    z->data[k] = y->data[k - x->length];
	}
    }
    if (z->imag != NULL) {
	for (k = 0; k < z->length; k++) {
	    if (k < x->length) {
		if (x->imag != NULL) {
		    z->imag[k] = x->imag[k];
		} else {
		    z->imag[k] = 0.0;
		}
	    } else {
		if (y->imag != NULL) {
		    z->imag[k] = y->imag[k - x->length];
		} else {
		    z->imag[k] = 0.0;
		}
	    }
	}
    }

    return z;
}

/*
 *	get initialized vector
 */
void svinit(SVector x, long m, long incr, long n)
{
    long k;
    long num;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->data[k] = (short)(m + (k * incr));
    }

    return;
}

void lvinit(LVector x, long m, long incr, long n)
{
    long k;
    long num;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->data[k] = m + (k * incr);
    }

    return;
}

void fvinit(FVector x, float m, float incr, float n)
{
    long k;
    long num;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->data[k] = m + (k * incr);
    }

    return;
}

void dvinit(DVector x, double m, double incr, double n)
{
    long k;
    long num;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->data[k] = m + (k * incr);
    }

    return;
}

SVector xsvinit(long m, long incr, long n)
{
    long k;
    long num;
    SVector x;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	x = xsvnull();
	return x;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
	    x = xsvnull();
	    return x;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    
    /* memory allocate */
    x = xsvalloc(num);

    /* initailize data */
    for (k = 0; k < x->length; k++) {
	x->data[k] = (short)(m + (k * incr));
    }

    return x;
}

LVector xlvinit(long m, long incr, long n)
{
    long k;
    long num;
    LVector x;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	x = xlvnull();
	return x;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
	    x = xlvnull();
	    return x;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    
    /* memory allocate */
    x = xlvalloc(num);

    /* initailize data */
    for (k = 0; k < x->length; k++) {
	x->data[k] = m + (k * incr);
    }

    return x;
}

FVector xfvinit(float m, float incr, float n)
{
    long k;
    long num;
    FVector x;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	x = xfvnull();
	return x;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
	    x = xfvnull();
	    return x;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    
    /* memory allocate */
    x = xfvalloc(num);

    /* initailize data */
    for (k = 0; k < x->length; k++) {
	x->data[k] = m + (k * incr);
    }

    return x;
}

DVector xdvinit(double m, double incr, double n)
{
    long k;
    long num;
    DVector x;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	x = xdvnull();
	return x;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
	    x = xdvnull();
	    return x;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    
    /* memory allocate */
    x = xdvalloc(num);

    /* initailize data */
    for (k = 0; k < x->length; k++) {
	x->data[k] = m + (k * incr);
    }

    return x;
}

void sviinit(SVector x, long m, long incr, long n)
{
    long k;
    long num;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    if (x->imag == NULL) {
	svialloc(x);
	svizeros(x, x->length);
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->imag[k] = (short)(m + (k * incr));
    }

    return;
}

void lviinit(LVector x, long m, long incr, long n)
{
    long k;
    long num;

    if ((incr > 0 && m > n) || (incr < 0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0) {
	num = n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((n - m) / incr) + 1;
    }
    if (x->imag == NULL) {
	lvialloc(x);
	lvizeros(x, x->length);
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->imag[k] = m + (k * incr);
    }

    return;
}

void fviinit(FVector x, float m, float incr, float n)
{
    long k;
    long num;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    if (x->imag == NULL) {
	fvialloc(x);
	fvizeros(x, x->length);
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->imag[k] = m + (k * incr);
    }

    return;
}

void dviinit(DVector x, double m, double incr, double n)
{
    long k;
    long num;

    if ((incr > 0.0 && m > n) || (incr < 0.0 && m < n)) {
	fprintf(stderr, "bad increment value\n");
	return;
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    num = x->length;
	}
    } else {
	num = labs((long)((n - m) / incr)) + 1;
    }
    if (x->imag == NULL) {
	dvialloc(x);
	dvizeros(x, x->length);
    }
    
    /* initailize data */
    for (k = 0; k < num; k++) {
	if (k >= x->length) {
	    break;
	}
	x->imag[k] = m + (k * incr);
    }

    return;
}

SVector xsvriinit(long m, long incr, long n)
{
    SVector x;

    x = xsvinit(m, incr, n);
    svialloc(x);
    sviinit(x, m, incr, n);

    return x;
}

LVector xlvriinit(long m, long incr, long n)
{
    LVector x;

    x = xlvinit(m, incr, n);
    lvialloc(x);
    lviinit(x, m, incr, n);

    return x;
}

FVector xfvriinit(float m, float incr, float n)
{
    FVector x;

    x = xfvinit(m, incr, n);
    fvialloc(x);
    fviinit(x, m, incr, n);

    return x;
}

DVector xdvriinit(double m, double incr, double n)
{
    DVector x;

    x = xdvinit(m, incr, n);
    dvialloc(x);
    dviinit(x, m, incr, n);

    return x;
}

/*
 *	cut vector
 */
SVector xsvcut(SVector x, long offset, long length)
{
    long k;
    long pos;
    SVector y;
    
    y = xsvalloc(length);
    if (x->imag != NULL) {
	svialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < x->length) {
	    y->data[k] = x->data[pos];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[pos];
	    }
	} else {
	    y->data[k] = 0;
	    if (y->imag != NULL) {
		y->imag[k] = 0;
	    }
	}
    }

    return y;
}

LVector xlvcut(LVector x, long offset, long length)
{
    long k;
    long pos;
    LVector y;
    
    y = xlvalloc(length);
    if (x->imag != NULL) {
	lvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < x->length) {
	    y->data[k] = x->data[pos];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[pos];
	    }
	} else {
	    y->data[k] = 0;
	    if (y->imag != NULL) {
		y->imag[k] = 0;
	    }
	}
    }

    return y;
}

FVector xfvcut(FVector x, long offset, long length)
{
    long k;
    long pos;
    FVector y;
    
    y = xfvalloc(length);
    if (x->imag != NULL) {
	fvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < x->length) {
	    y->data[k] = x->data[pos];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[pos];
	    }
	} else {
	    y->data[k] = 0.0;
	    if (y->imag != NULL) {
		y->imag[k] = 0.0;
	    }
	}
    }

    return y;
}

DVector xdvcut(DVector x, long offset, long length)
{
    long k;
    long pos;
    DVector y;
    
    y = xdvalloc(length);
    if (x->imag != NULL) {
	dvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < x->length) {
	    y->data[k] = x->data[pos];
	    if (y->imag != NULL) {
		y->imag[k] = x->imag[pos];
	    }
	} else {
	    y->data[k] = 0.0;
	    if (y->imag != NULL) {
		y->imag[k] = 0.0;
	    }
	}
    }

    return y;
}

/*
 *	paste data of x in y
 *	if length equal to 0, length is set length of x
 */
void svpaste(SVector y, SVector x, long y_offset, long x_length, int overlap)
{
    long k;
    long pos;

    if (x_length <= 0 || x_length > x->length) {
	x_length = x->length;
    }

    if (overlap) {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void lvpaste(LVector y, LVector x, long y_offset, long x_length, int overlap)
{
    long k;
    long pos;
    
    if (x_length <= 0 || x_length > x->length) {
	x_length = x->length;
    }

    if (overlap) {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void fvpaste(FVector y, FVector x, long y_offset, long x_length, int overlap)
{
    long k;
    long pos;
    
    if (x_length <= 0 || x_length > x->length) {
	x_length = x->length;
    }

    if (overlap) {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void dvpaste(DVector y, DVector x, long y_offset, long x_length, int overlap)
{
    long k;
    long pos;
    
    if (x_length <= 0 || x_length > x->length) {
	x_length = x->length;
    }

    if (overlap) {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < x_length; k++) {
	    pos = k + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void svadd(SVector y, long y_offset, SVector x, long x_offset, long x_length, int overlap)
{
    long k;
    long pos;
    long length;
    
    length = MIN(x_offset + x_length, x->length);
#if 0
    if (length <= x_offset) {
	length = x->length;
    }
#endif

    if (overlap) {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void lvadd(LVector y, long y_offset, LVector x, long x_offset, long x_length, int overlap)
{
    long k;
    long pos;
    long length;
    
    length = MIN(x_offset + x_length, x->length);
#if 0
    if (length <= x_offset) {
	length = x->length;
    }
#endif

    if (overlap) {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void fvadd(FVector y, long y_offset, FVector x, long x_offset, long x_length, int overlap)
{
    long k;
    long pos;
    long length;
    
    length = MIN(x_offset + x_length, x->length);
#if 0
    if (length <= x_offset) {
	length = x->length;
    }
#endif

    if (overlap) {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

void dvadd(DVector y, long y_offset, DVector x, long x_offset, long x_length, int overlap)
{
    long k;
    long pos;
    long length;
    
    length = MIN(x_offset + x_length, x->length);
#if 0
    if (length <= x_offset) {
	length = x->length;
    }
#endif

    if (overlap) {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] += x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] += x->imag[k];
		}
	    }
	}
    } else {
	for (k = x_offset; k < length; k++) {
	    pos = k - x_offset + y_offset;
	    if (pos >= y->length) {
		break;
	    }
	    if (pos >= 0) {
		y->data[pos] = x->data[k];
		if (x->imag != NULL && y->imag != NULL) {
		    y->imag[pos] = x->imag[k];
		}
	    }
	}
    }

    return;
}

/*
 *	convert type of vector
 */
LVector xsvtol(SVector x)
{
    long k;
    LVector y;

    y = xlvalloc(x->length);
    if (x->imag != NULL) {
	lvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (long)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (long)x->imag[k];
	}
    }

    return y;
}

FVector xsvtof(SVector x)
{
    long k;
    FVector y;

    y = xfvalloc(x->length);
    if (x->imag != NULL) {
	fvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (float)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (float)x->imag[k];
	}
    }

    return y;
}

DVector xsvtod(SVector x)
{
    long k;
    DVector y;

    y = xdvalloc(x->length);
    if (x->imag != NULL) {
	dvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (double)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (double)x->imag[k];
	}
    }

    return y;
}

SVector xdvtos(DVector x)
{
    long k;
    SVector y;

    y = xsvalloc(x->length);
    if (x->imag != NULL) {
	svialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (short)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (short)x->imag[k];
	}
    }

    return y;
}

LVector xdvtol(DVector x)
{
    long k;
    LVector y;

    y = xlvalloc(x->length);
    if (x->imag != NULL) {
	lvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (long)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (long)x->imag[k];
	}
    }

    return y;
}

FVector xdvtof(DVector x)
{
    long k;
    FVector y;

    y = xfvalloc(x->length);
    if (x->imag != NULL) {
	fvialloc(y);
    }

    for (k = 0; k < y->length; k++) {
	y->data[k] = (float)x->data[k];
    }
    if (y->imag != NULL) {
	for (k = 0; k < y->length; k++) {
	    y->imag[k] = (float)x->imag[k];
	}
    }

    return y;
}

SVector xsvset(short *data, long length)
{
    SVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _SVector);
    x->data = data;
    x->imag = NULL;
    x->length = length;
    
    return x;
}


LVector xlvset(long *data, long length)
{
    LVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _LVector);
    x->data = data;
    x->imag = NULL;
    x->length = length;
    
    return x;
}


FVector xfvset(float *data, long length)
{
    FVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _FVector);
    x->data = data;
    x->imag = NULL;
    x->length = length;
    
    return x;
}

DVector xdvset(double *data, long length)
{
    DVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _DVector);
    x->data = data;
    x->imag = NULL;
    x->length = length;
    
    return x;
}

SVector xsvsetnew(short *data, long length)
{
    long k;
    SVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _SVector);
    x->data = xalloc(MAX(length, 1), short);
    for (k = 0; k < length; k++) {
	x->data[k] = data[k];
    }
    x->imag = NULL;
    x->length = length;
    
    return x;
}

LVector xlvsetnew(long *data, long length)
{
    long k;
    LVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _LVector);
    x->data = xalloc(MAX(length, 1), long);
    for (k = 0; k < length; k++) {
	x->data[k] = data[k];
    }
    x->imag = NULL;
    x->length = length;
    
    return x;
}

FVector xfvsetnew(float *data, long length)
{
    long k;
    FVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _FVector);
    x->data = xalloc(MAX(length, 1), float);
    for (k = 0; k < length; k++) {
	x->data[k] = data[k];
    }
    x->imag = NULL;
    x->length = length;
    
    return x;
}

DVector xdvsetnew(double *data, long length)
{
    long k;
    DVector x;

    length = MAX(length, 0);
    x = xalloc(1, struct _DVector);
    x->data = xalloc(MAX(length, 1), double);
    for (k = 0; k < length; k++) {
	x->data[k] = data[k];
    }
    x->imag = NULL;
    x->length = length;
    
    return x;
}
