/*
 *	main.c : sampling frequency converter main function
 *
 *	Last modified: <00/10/16 14:09:31 banno>
 */

#include <stdio.h>

#include <sp/spBase.h>
#include <sp/spOption.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/sfconv.h>

#define SFCONV_VERSION_STRING "1.0.0"
#define SFCONV_HELP_MESSAGE "sampling frequency converter version %s"

static double i_samp_freq;
static double o_samp_freq;
static char file_format[SP_MAX_PATHNAME] = "";

static spBool long_flag;
static spBool help_flag;
static spBool i_swap, o_swap;
static char i_param_file[SP_MAX_PATHNAME] = "";
static char o_param_file[SP_MAX_PATHNAME] = "";

static long fftl;
static double cutoff;
static double sidelobe;
static double transition;
static double tolerance;

static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-isf", NULL, "input sampling frequency [Hz]", "i_samp_freq",
	 SP_TYPE_DOUBLE, &i_samp_freq, "8000.0"},
    {"-osf", NULL, "output sampling frequency [Hz]", "o_samp_freq",
	 SP_TYPE_DOUBLE, &o_samp_freq, "12000.0"},
    {"-fftl", NULL, "FFT length [points]", "fft_length", 
	 SP_TYPE_LONG, &fftl, "512"},
    {"-co", "-cutoff", "normalized cutoff frequency (nyquist = 1)", "cutoff", 
	 SP_TYPE_DOUBLE, &cutoff, "0.95"},
    {"-sl", "-sidelobe", "height of sidelobe [dB]", "sidelobe", 
	 SP_TYPE_DOUBLE, &sidelobe, "50.0"},
    {"-trans", "-transition", "normalized transition width", "transition", 
	 SP_TYPE_DOUBLE, &transition, "0.05"},
    {"-tol", "-tolerance", "tolerance [%]", "tolerance", 
	 SP_TYPE_DOUBLE, &tolerance, "2.0"},
    {"-format", NULL, "file format (s[hort], d[ouble])", "file_format",
	 SP_TYPE_STRING_S, file_format, "short"},
    {"-long", NULL, "input file is long data", "long_data",
	 SP_TYPE_BOOLEAN, &long_flag, SP_FALSE_STRING},
    {"-iswap", NULL, "swap input file", "i_swap",
	 SP_TYPE_BOOLEAN, &i_swap, SP_FALSE_STRING},
    {"-oswap", NULL, "swap output file", "o_swap",
	 SP_TYPE_BOOLEAN, &o_swap, SP_FALSE_STRING},
    {"-iparam", NULL, "input parameter file", NULL,
	 SP_TYPE_STRING_S, i_param_file, NULL},
    {"-oparam", NULL, "output parameter file", NULL,
	 SP_TYPE_STRING_S, o_param_file, NULL},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-h", "-help", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<input file>",
    "<output file>",
};

int main(int argc, char *argv[])
{
    char *i_filename, *o_filename;

    /*spSetDebugLevel(20);*/
    spSetWarningFlag(1);
    
    /* get command line options */
    spSetHelpMessage(&help_flag, SFCONV_HELP_MESSAGE, SFCONV_VERSION_STRING);
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    /* read parameter file */
    if (!strnone(i_param_file)) {
	spMessage("Input Parameter File: %s\n", i_param_file);
	spReadSetup(i_param_file, options);
    }
    
    i_filename = spGetFile(options);
    o_filename = spGetFile(options);
    spCheckNumFile(options);

    setsfcparam(cutoff, sidelobe, transition, tolerance, fftl);

    if (long_flag == SP_TRUE) {
	spMessage("Long Version\n");
	if (file_format[0] == 'd') {
	    sfconvlongdfile(i_filename, i_swap, i_samp_freq, o_filename, o_swap, o_samp_freq);
	} else {
	    sfconvlongfile(i_filename, i_swap, i_samp_freq, o_filename, o_swap, o_samp_freq);
	}
    } else {
	if (file_format[0] == 'd') {
	    sfconvdfile(i_filename, i_swap, i_samp_freq, o_filename, o_swap, o_samp_freq);
	} else {
	    sfconvfile(i_filename, i_swap, i_samp_freq, o_filename, o_swap, o_samp_freq);
	}
    }

    /* write parameter file */
    if (!strnone(o_param_file)) {
	spMessage("Output Parameter File: %s\n", o_param_file);
	spWriteSetup(o_param_file, options);
    }
    
    return 0;
}
