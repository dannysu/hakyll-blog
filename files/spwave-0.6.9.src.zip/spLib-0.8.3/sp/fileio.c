/*
 *	fileio.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/memory.h>
#include <sp/vector.h>
#include <sp/voperate.h>
#include <sp/matrix.h>
#include <sp/fft.h>
#include <sp/fileio.h>

static DVector sp_prev_vec = NODATA;

int dvreadfirst(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp)
{
    int ndata = 0;
    long k;
    long len;
    short value;
    double dvalue;

    if (vector == NODATA) {
	return 0;
    }
    
    if (length <= 0 || vector->length < length) {
	length = vector->length;
    }
    
    if (shift < 0) {
	len = -shift;
	if (len >= vector->length) {
	    fprintf(stderr, "-shift must be less than input length\n");
	}
	
	for (k = 0; k < len; k++) {
	    vector->data[k] = 0.0;
	}
    } else {
	if (double_flag) {
	    for (k = 0; k < shift; k++) {
		freaddouble(&dvalue, 1, 0, fp);
	    }
	} else {
	    for (k = 0; k < shift; k++) {
		freadshort(&value, 1, 0, fp);
	    }
	}
	len = 0;
    }

    /* read data */
    if (double_flag) {
	ndata = freaddouble(vector->data + len, length - len, swap, fp);
    } else {
	ndata = freadshorttod(vector->data + len, length - len, swap, fp);
    }
    for (k = len + ndata; k < vector->length; k++) {
	vector->data[k] = 0.0;
    }
    
    if (sp_prev_vec != NODATA) {
	xdvfree(sp_prev_vec);
    }
    sp_prev_vec = xdvcut(vector, 0, len + ndata);
    
    return ndata;
}

int dvreadsfirst(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvreadfirst(vector, shift, length, swap, 0, fp);
}

int dvreaddfirst(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvreadfirst(vector, shift, length, swap, 1, fp);
}

int dvreadframe(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp)
{
    int ndata = 0;
    long k;
    long len;
    short value;
    double dvalue;

    if (vector == NODATA) {
	return 0;
    }
    
    if (length <= 0 || vector->length < length) {
	length = vector->length;
    }
    
    if (shift < 0) {
	fprintf(stderr, "shift must be 0 or more\n");
	return 0;
    }

    if (sp_prev_vec != NODATA) {
	if (shift < sp_prev_vec->length) {
	    len = sp_prev_vec->length - shift;
	    dvadd(vector, 0, sp_prev_vec, shift, len, 0);
	} else {
	    len = shift - sp_prev_vec->length;
	    if (double_flag) {
		for (k = 0; k < len; k++) {
		    freaddouble(&dvalue, 1, 0, fp);
		}
	    } else {
		for (k = 0; k < len; k++) {
		    freadshort(&value, 1, 0, fp);
		}
	    }
	    len = 0;
	}
    } else {
	len = 0;
    }

    /* read data */
    if (double_flag) {
	ndata = freaddouble(vector->data + len, length - len, swap, fp);
    } else {
	ndata = freadshorttod(vector->data + len, length - len, swap, fp);
    }
    for (k = len + ndata; k < vector->length; k++) {
	vector->data[k] = 0.0;
    }
    
    if (sp_prev_vec != NODATA) {
	xdvfree(sp_prev_vec);
    }
    sp_prev_vec = xdvcut(vector, 0, len + ndata);
    
    return ndata;
}

int dvreadsframe(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvreadframe(vector, shift, length, swap, 0, fp);
}

int dvreaddframe(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvreadframe(vector, shift, length, swap, 1, fp);
}

int dvwriteframe(DVector vector, long shift, long length, int swap, int double_flag, FILE *fp)
{
    int ndata = 0;

    if (vector == NODATA) {
	return 0;
    }
    
    if (length <= 0 || vector->length < length) {
	length = vector->length;
    }

    if (double_flag) {
	ndata = fwritedouble(vector->data, length, swap, fp);
    } else {
	ndata = fwritedoubletos(vector->data, length, swap, fp);
    }
    dvdatashift(vector, -shift);
    
    return ndata;
}

int dvwritesframe(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvwriteframe(vector, shift, length, swap, 0, fp);
}

int dvwritedframe(DVector vector, long shift, long length, int swap, FILE *fp)
{
    return dvwriteframe(vector, shift, length, swap, 1, fp);
}

/*
 *	read short signal
 */
SVector xsvreadssignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    SVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, short)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xsvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freadshort(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

/*
 *	read long signal
 */
LVector xlvreadlsignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    LVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, long)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xlvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freadlong(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

/*
 *	read double signal
 */
DVector xdvreaddsignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    DVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, double)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xdvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freaddouble(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

DVector xdvreadssignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    DVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, short)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xdvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freadshorttod(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

DVector xdvreadlsignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    DVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, long)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xdvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freadlongtod(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

DVector xdvreadfsignal(char *filename, int headlen, int swap)
{
    long length;
    char *basename;
    DVector vector;
    FILE *fp;

    /* get signal length */
    if ((length = getsiglen(filename, headlen, float)) <= 0) {
	return NODATA;
    }

    /* memory allocate */
    vector = xdvalloc(length);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* skip header */
    if (headlen > 0)
	fseek(fp, (long)headlen, 0);

    /* read data */
    freadfloattod(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return vector;
}

/*
 *	write short signal
 */
void svwritessignal(char *filename, SVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwriteshort(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

/*
 *	write long signal
 */
void lvwritelsignal(char *filename, LVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwritelong(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

/*
 *	write double signal
 */
void dvwritedsignal(char *filename, DVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwritedouble(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

void dvwritessignal(char *filename, DVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwritedoubletos(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

void dvwritelsignal(char *filename, DVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwritedoubletol(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

void dvwritefsignal(char *filename, DVector vector, int swap)
{
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    fwritedoubletof(vector->data, vector->length, swap, fp);

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);
    
    return;
}

LMatrix xlmreadlmatrix(char *filename, long ncol, int swap)
{
    long k;
    long nrow;
    long length;
    char *basename;
    LMatrix mat;
    FILE *fp;

    /* get data length */
    if ((length = getsiglen(filename, 0, long)) <= 0) {
	return NODATA;
    }
    if (length % ncol != 0) {
	fprintf(stderr, "Wrong data format: %s\n", filename);
	return NODATA;
    }
    nrow = length / ncol;

    /* memory allocate */
    mat = xlmalloc(nrow, ncol);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* read data */
    for (k = 0; k < mat->row; k++) {
	freadlong(mat->data[k], mat->col, swap, fp);
    }

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return mat;
}

DMatrix xdmreaddmatrix(char *filename, long ncol, int swap)
{
    long k;
    long nrow;
    long length;
    char *basename;
    DMatrix mat;
    FILE *fp;

    /* get data length */
    if ((length = getsiglen(filename, 0, double)) <= 0) {
	return NODATA;
    }
    if (length % ncol != 0) {
	fprintf(stderr, "Wrong data format: %s\n", filename);
	return NODATA;
    }
    nrow = length / ncol;

    /* memory allocate */
    mat = xdmalloc(nrow, ncol);

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "rb"))) {
	return NODATA;
    }

    /* read data */
    for (k = 0; k < mat->row; k++) {
	freaddouble(mat->data[k], mat->col, swap, fp);
    }

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return mat;
}

void lmwritelmatrix(char *filename, LMatrix mat, int swap)
{
    long k;
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    for (k = 0; k < mat->row; k++) {
	fwritelong(mat->data[k], mat->col, swap, fp);
    }

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return;
}

void dmwritedmatrix(char *filename, DMatrix mat, int swap)
{
    long k;
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    /* open file */
    if (NULL == (fp = spOpenFile(filename, "wb"))) {
	return;
    }

    /* write data */
    for (k = 0; k < mat->row; k++) {
	fwritedouble(mat->data[k], mat->col, swap, fp);
    }

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return;
}

int dvreaddvector_txt(char *filename, DVector vector)
{
    long lc;
    double value;
    char line[MAX_PATHNAME];
    char string[MAX_LINE];
    FILE *fp;

    if (NULL == (fp = fopen(filename, "r"))) {
        fprintf(stderr, "Can't open file: %s\n", filename);
	return FAILURE;
    }

    lc = 0;
    while (fgetline(line, fp) != EOF) {
	if (lc >= vector->length) {
	    break;
	}

        sscanf(line, "%s", string);
        if (sscanf(string, "%lf", &value) == 1) {
	    vector->data[lc] = value;
	    lc++;
        }
    }

    for (; lc < vector->length; lc++) {
	vector->data[lc] = 0.0;
    }

    fclose(fp);

    return SUCCESS;
}

DVector xdvreaddvector_txt(char *filename)
{
    long length;
    DVector vector;

    if ((length = getfilesize_txt(filename)) == FAILURE) {
	return NODATA;
    }

    vector = xdvalloc(length);

    if (dvreaddvector_txt(filename, vector) == FAILURE) {
	xdvfree(vector);
	return NODATA;
    }

    return vector;
}
int dvreadcol_txt(char *filename, int col, DVector vector)
{
    long k;
    char buf[MAX_LINE];
    FILE *fp;

    if (NULL == (fp = fopen(filename, "r"))) {
        fprintf(stderr, "Can't open file: %s\n", filename);
	return FAILURE;
    }

    for (k = 0; k < vector->length; k++) {
	if (fgetcol(buf, col, fp) == EOF) {
	    break;
	}
	sscanf(buf, "%lf", &vector->data[k]);
    }

    return SUCCESS;
}

DVector xdvreadcol_txt(char *filename, int col)
{
    long length;
    DVector vector;

    length = (long)getnumrow_txt(filename);

    if (length <= 0) {
	return NODATA;
    } else {
	vector = xdvzeros(length);
	dvreadcol_txt(filename, col, vector);
    }

    return vector;
}

int dvwritedvector_txt(char *filename, DVector vector)
{
    long lc;
    char *basename;
    FILE *fp;

    /* get base name */
    basename = xgetbasename(filename);

    if (NULL == (fp = spOpenFile(filename, "w"))) {
	return FAILURE;
    }

    for (lc = 0; lc < vector->length; lc++) {
	fprintf(fp, "%f\n", vector->data[lc]);
    }

    /* close file */
    spCloseFile(fp);

    /* memory free */
    xfree(basename);

    return SUCCESS;
}

float fvmaxamp(FVector vec)
{
    float value;
    
    value = MAX(FABS(fvmax(vec, NULL)), FABS(fvmin(vec, NULL)));
    
    return value;
}

double dvmaxamp(DVector vec)
{
    double value;
    
    value = MAX(FABS(dvmax(vec, NULL)), FABS(dvmin(vec, NULL)));
    
    return value;
}

float fvadjustamp(FVector vec, float amp)
{
    float value;

    value = fvmaxamp(vec);
    if (value > 0.0) {
	/*fvscoper(vec, "*", amp / value);*/
	fvscoper(vec, "/", value / amp);
    }
    
    return value;
}

double dvadjustamp(DVector vec, double amp)
{
    double value;

    value = dvmaxamp(vec);
    if (value > 0.0) {
	/*dvscoper(vec, "*", amp / value);*/
	dvscoper(vec, "/", value / amp);
    }

    return value;
}

float fvlimitamp(FVector vec, float amp)
{
    float value;

    value = fvmaxamp(vec);
    if (value > 0.0 && value > amp) {
	spWarning("power is too big: %f\n", value);
	spWarning("execute normalization\n");
	fvscoper(vec, "*", amp / value);
    }

    return value;
}

double dvlimitamp(DVector vec, double amp)
{
    double value;

    value = dvmaxamp(vec);
    if (value > 0.0 && value > amp) {
	spWarning("power is too big: %f\n", value);
	spWarning("execute normalization\n");
	dvscoper(vec, "*", amp / value);
    }

    return value;
}

#if 1
DVector xdvextractchannel(DVector x, int channel, int num_channel)
{
    long k;
    DVector y;

    if (x == NODATA || num_channel <= 0) return NODATA;
    
    if (channel < 0 || channel >= num_channel) {
	channel = 0;
    }
    
    y = xdvalloc(x->length / (long)num_channel);
    
    for (k = 0; k < y->length; k++) {
	y->data[k] = x->data[k * num_channel + channel];
    }

    return y;
}
#endif

/*
 *	dump data
 */
void svdump(SVector vec)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0) {
	    printf("%d\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0) {
		printf("%d - %di\n", vec->data[k], -vec->imag[k]);
	    } else {
		printf("%d + %di\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    printf("\n");

    return;
}

void lvdump(LVector vec)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0) {
	    printf("%ld\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0) {
		printf("%ld - %ldi\n", vec->data[k], -vec->imag[k]);
	    } else {
		printf("%ld + %ldi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    printf("\n");

    return;
}

void fvdump(FVector vec)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0.0) {
	    printf("%f\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0.0) {
		printf("%f - %fi\n", vec->data[k], -vec->imag[k]);
	    } else {
		printf("%f + %fi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    printf("\n");

    return;
}

void dvdump(DVector vec)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0.0) {
	    printf("%f\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0.0) {
		printf("%f - %fi\n", vec->data[k], -vec->imag[k]);
	    } else {
		printf("%f + %fi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    printf("\n");

    return;
}

void svfdump(SVector vec, FILE *fp)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0) {
	    fprintf(fp, "%d\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0) {
		fprintf(fp, "%d - %di\n", vec->data[k], -vec->imag[k]);
	    } else {
		fprintf(fp, "%d + %di\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    fprintf(fp, "\n");

    return;
}

void lvfdump(LVector vec, FILE *fp)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0) {
	    fprintf(fp, "%ld\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0) {
		fprintf(fp, "%ld - %ldi\n", vec->data[k], -vec->imag[k]);
	    } else {
		fprintf(fp, "%ld + %ldi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    fprintf(fp, "\n");

    return;
}

void fvfdump(FVector vec, FILE *fp)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0.0) {
	    fprintf(fp, "%f\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0.0) {
		fprintf(fp, "%f - %fi\n", vec->data[k], -vec->imag[k]);
	    } else {
		fprintf(fp, "%f + %fi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    fprintf(fp, "\n");

    return;
}

void dvfdump(DVector vec, FILE *fp)
{
    long k;

    for (k = 0; k < vec->length; k++) {
	if (vec->imag == NULL || vec->imag[k] == 0.0) {
	    fprintf(fp, "%f\n", vec->data[k]);
	} else {
	    if (vec->imag[k] < 0.0) {
		fprintf(fp, "%f - %fi\n", vec->data[k], -vec->imag[k]);
	    } else {
		fprintf(fp, "%f + %fi\n", vec->data[k], vec->imag[k]);
	    }
	}
    }
    fprintf(fp, "\n");

    return;
}

void lmfdump(LMatrix mat, FILE *fp)
{
    long k, l;

    for (k = 0; k < mat->row; k++) {
	for (l = 0; l < mat->col; l++) {
	    if (mat->imag == NULL || mat->imag[k][l] == 0) {
		fprintf(fp, "%ld  ", mat->data[k][l]);
	    } else {
		if (mat->imag[k][l] < 0) {
		    fprintf(fp, "%ld - %ldi  ", mat->data[k][l], -mat->imag[k][l]);
		} else {
		    fprintf(fp, "%ld + %ldi  ", mat->data[k][l], mat->imag[k][l]);
		}
	    }
	}
	fprintf(fp, "\n");
    }
    fprintf(fp, "\n");

    return;
}

void dmfdump(DMatrix mat, FILE *fp)
{
    long k, l;

    for (k = 0; k < mat->row; k++) {
	for (l = 0; l < mat->col; l++) {
	    if (mat->imag == NULL || mat->imag[k][l] == 0.0) {
		fprintf(fp, "%f  ", mat->data[k][l]);
	    } else {
		if (mat->imag[k][l] < 0.0) {
		    fprintf(fp, "%f - %fi  ", mat->data[k][l], -mat->imag[k][l]);
		} else {
		    fprintf(fp, "%f + %fi  ", mat->data[k][l], mat->imag[k][l]);
		}
	    }
	}
	fprintf(fp, "\n");
    }
    fprintf(fp, "\n");

    return;
}

void dvnfdump(FILE *fp, DVector vec, ...)
{
    int nrow, ncol;
    int end;
    char buf[MAX_LINE];
    char line[MAX_PATHNAME];
    DVector p;
    va_list argp;

    end = 0;
    nrow = 0;
    while (1) {
	line[0] = NUL;

	va_start(argp, vec);

	ncol = 0;
	while ((p = va_arg(argp, DVector)) != NULL) {
	    if (nrow >= p->length) {
		end = 1;
		break;
	    } else {
		sprintf(buf, "%f ", p->data[nrow]);
		strcat(line, buf);
	    }
	    ncol++;
	}

	va_end(argp);

	if (end == 1) {
	    break;
	} else {
	    fprintf(fp, "%s\n", line);
	}
	nrow++;
    }

    return;
}
