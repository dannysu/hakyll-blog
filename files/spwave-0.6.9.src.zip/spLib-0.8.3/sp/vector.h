/*
 *	vector.h
 */

#ifndef __VECTOR_H
#define __VECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _spSVector {
    long length;
    short *data;
    short *imag;
} *spSVector;

typedef struct _spLVector {
    long length;
    long *data;
    long *imag;
} *spLVector;

typedef struct _spFVector {
    long length;
    float *data;
    float *imag;
} *spFVector;

typedef struct _spDVector {
    long length;
    double *data;
    double *imag;
} *spDVector;

typedef struct _spSVectors {
    long num_vector;
    spSVector *vector;
} *spSVectors;

typedef struct _spLVectors {
    long num_vector;
    spLVector *vector;
} *spLVectors;

typedef struct _spFVectors {
    long num_vector;
    spFVector *vector;
} *spFVectors;

typedef struct _spDVectors {
    long num_vector;
    spDVector *vector;
} *spDVectors;

#define SVector spSVector
#define LVector spLVector
#define FVector spFVector
#define DVector spDVector
#define _SVector _spSVector
#define _LVector _spLVector
#define _FVector _spFVector
#define _DVector _spDVector

#define SVectors spSVectors
#define LVectors spLVectors
#define FVectors spFVectors
#define DVectors spDVectors
#define _SVectors _spSVectors
#define _LVectors _spLVectors
#define _FVectors _spFVectors
#define _DVectors _spDVectors

#define vlength(x) ((x)->length)
#define vdata(x) ((x)->data)
#define vreal(x) ((x)->data)
#define vimag(x) ((x)->imag)

#if defined(MACOS)
#pragma import on
#endif

extern SVector xsvalloc(long length);
extern LVector xlvalloc(long length);
extern FVector xfvalloc(long length);
extern DVector xdvalloc(long length);
extern void xsvfree(SVector vector);
extern void xlvfree(LVector vector);
extern void xfvfree(FVector vector);
extern void xdvfree(DVector vector);

extern void svialloc(SVector x);
extern void lvialloc(LVector x);
extern void fvialloc(FVector x);
extern void dvialloc(DVector x);
extern void svifree(SVector x);
extern void lvifree(LVector x);
extern void fvifree(FVector x);
extern void dvifree(DVector x);

extern SVector xsvrialloc(long length);
extern LVector xlvrialloc(long length);
extern FVector xfvrialloc(long length);
extern DVector xdvrialloc(long length);

extern SVector xsvrealloc(SVector x, long length);
extern LVector xlvrealloc(LVector x, long length);
extern FVector xfvrealloc(FVector x, long length);
extern DVector xdvrealloc(DVector x, long length);

extern SVectors xsvsalloc(long num);
extern LVectors xlvsalloc(long num);
extern FVectors xfvsalloc(long num);
extern DVectors xdvsalloc(long num);
extern void xsvsfree(SVectors xs);
extern void xlvsfree(LVectors xs);
extern void xfvsfree(FVectors xs);
extern void xdvsfree(DVectors xs);

extern SVector xsvcplx(SVector xr, SVector xi);
extern LVector xlvcplx(LVector xr, LVector xi);
extern FVector xfvcplx(FVector xr, FVector xi);
extern DVector xdvcplx(DVector xr, DVector xi);

extern void svreal(SVector x);
extern void lvreal(LVector x);
extern void fvreal(FVector x);
extern void dvreal(DVector x);

extern void svimag(SVector x);
extern void lvimag(LVector x);
extern void fvimag(FVector x);
extern void dvimag(DVector x);

extern SVector xsvreal(SVector x);
extern LVector xlvreal(LVector x);
extern FVector xfvreal(FVector x);
extern DVector xdvreal(DVector x);

extern SVector xsvimag(SVector x);
extern LVector xlvimag(LVector x);
extern FVector xfvimag(FVector x);
extern DVector xdvimag(DVector x);

extern void svconj(SVector x);
extern void lvconj(LVector x);
extern void fvconj(FVector x);
extern void dvconj(DVector x);
extern SVector xsvconj(SVector x);
extern LVector xlvconj(LVector x);
extern FVector xfvconj(FVector x);
extern DVector xdvconj(DVector x);

extern void svriswap(SVector x);
extern void lvriswap(LVector x);
extern void fvriswap(FVector x);
extern void dvriswap(DVector x);
extern SVector xsvriswap(SVector x);
extern LVector xlvriswap(LVector x);
extern FVector xfvriswap(FVector x);
extern DVector xdvriswap(DVector x);

extern void svcopy(SVector y, SVector x);
extern void lvcopy(LVector y, LVector x);
extern void fvcopy(FVector y, FVector x);
extern void dvcopy(DVector y, DVector x);

extern SVector xsvclone(SVector x);
extern LVector xlvclone(LVector x);
extern FVector xfvclone(FVector x);
extern DVector xdvclone(DVector x);

extern SVector xsvcat(SVector x, SVector y);
extern LVector xlvcat(LVector x, LVector y);
extern FVector xfvcat(FVector x, FVector y);
extern DVector xdvcat(DVector x, DVector y);

extern void svinit(SVector x, long m, long incr, long n);
extern void lvinit(LVector x, long m, long incr, long n);
extern void fvinit(FVector x, float m, float incr, float n);
extern void dvinit(DVector x, double m, double incr, double n);

extern SVector xsvinit(long m, long incr, long n);
extern LVector xlvinit(long m, long incr, long n);
extern FVector xfvinit(float m, float incr, float n);
extern DVector xdvinit(double m, double incr, double n);

extern void sviinit(SVector x, long m, long incr, long n);
extern void lviinit(LVector x, long m, long incr, long n);
extern void fviinit(FVector x, float m, float incr, float n);
extern void dviinit(DVector x, double m, double incr, double n);

extern SVector xsvriinit(long m, long incr, long n);
extern LVector xlvriinit(long m, long incr, long n);
extern FVector xfvriinit(float m, float incr, float n);
extern DVector xdvriinit(double m, double incr, double n);

extern SVector xsvcut(SVector x, long offset, long length);
extern LVector xlvcut(LVector x, long offset, long length);
extern FVector xfvcut(FVector x, long offset, long length);
extern DVector xdvcut(DVector x, long offset, long length);

extern void svpaste(SVector y, SVector x, long y_offset, long x_length, int overlap);
extern void lvpaste(LVector y, LVector x, long y_offset, long x_length, int overlap);
extern void fvpaste(FVector y, FVector x, long y_offset, long x_length, int overlap);
extern void dvpaste(DVector y, DVector x, long y_offset, long x_length, int overlap);

extern void svadd(SVector y, long y_offset, SVector x, long x_offset, long x_length, int overlap);
extern void lvadd(LVector y, long y_offset, LVector x, long x_offset, long x_length, int overlap);
extern void fvadd(FVector y, long y_offset, FVector x, long x_offset, long x_length, int overlap);
extern void dvadd(DVector y, long y_offset, DVector x, long x_offset, long x_length, int overlap);
     
extern LVector xsvtol(SVector x);
extern FVector xsvtof(SVector x);
extern DVector xsvtod(SVector x);
extern SVector xdvtos(DVector x);
extern LVector xdvtol(DVector x);
extern FVector xdvtof(DVector x);

extern SVector xsvset(short *data, long length);
extern LVector xlvset(long *data, long length);
extern FVector xfvset(float *data, long length);
extern DVector xdvset(double *data, long length);
extern SVector xsvsetnew(short *data, long length);
extern LVector xlvsetnew(long *data, long length);
extern FVector xfvsetnew(float *data, long length);
extern DVector xdvsetnew(double *data, long length);

#if defined(MACOS)
#pragma import off
#endif

#define xsvnums(length, value) xsvinit((long)(value), 0, (long)(length))
#define xlvnums(length, value) xlvinit((long)(value), 0, (long)(length))
#define xfvnums(length, value) xfvinit((float)(value), 0.0, (float)(length))
#define xdvnums(length, value) xdvinit((double)(value), 0.0, (double)(length))

#define xsvzeros(length) xsvnums(length, 0)
#define xlvzeros(length) xlvnums(length, 0)
#define xfvzeros(length) xfvnums(length, 0.0)
#define xdvzeros(length) xdvnums(length, 0.0)

#define xsvones(length) xsvnums(length, 1)
#define xlvones(length) xlvnums(length, 1)
#define xfvones(length) xfvnums(length, 1.0)
#define xdvones(length) xdvnums(length, 1.0)

#define xsvnull() xsvalloc(0)
#define xlvnull() xlvalloc(0)
#define xfvnull() xfvalloc(0)
#define xdvnull() xdvalloc(0)

#define xsvrinums(length, value) xsvriinit((long)(value), 0, (long)(length))
#define xlvrinums(length, value) xlvriinit((long)(value), 0, (long)(length))
#define xfvrinums(length, value) xfvriinit((float)(value), 0.0, (float)(length))
#define xdvrinums(length, value) xdvriinit((double)(value), 0.0, (double)(length))

#define xsvrizeros(length) xsvrinums(length, 0)
#define xlvrizeros(length) xlvrinums(length, 0)
#define xfvrizeros(length) xfvrinums(length, 0.0)
#define xdvrizeros(length) xdvrinums(length, 0.0)

#define xsvriones(length) xsvrinums(length, 1)
#define xlvriones(length) xlvrinums(length, 1)
#define xfvriones(length) xfvrinums(length, 1.0)
#define xdvriones(length) xdvrinums(length, 1.0)

#define svnums(x, length, value) svinit(x, (long)(value), 0, (long)(length))
#define lvnums(x, length, value) lvinit(x, (long)(value), 0, (long)(length))
#define fvnums(x, length, value) fvinit(x, (float)(value), 0.0, (float)(length))
#define dvnums(x, length, value) dvinit(x, (double)(value), 0.0, (double)(length))

#define svzeros(x, length) svnums(x, length, 0)
#define lvzeros(x, length) lvnums(x, length, 0)
#define fvzeros(x, length) fvnums(x, length, 0.0)
#define dvzeros(x, length) dvnums(x, length, 0.0)

#define svones(x, length) svnums(x, length, 1)
#define lvones(x, length) lvnums(x, length, 1)
#define fvones(x, length) fvnums(x, length, 1.0)
#define dvones(x, length) dvnums(x, length, 1.0)

#define svinums(x, length, value) sviinit(x, (long)(value), 0, (long)(length))
#define lvinums(x, length, value) lviinit(x, (long)(value), 0, (long)(length))
#define fvinums(x, length, value) fviinit(x, (float)(value), 0.0, (float)(length))
#define dvinums(x, length, value) dviinit(x, (double)(value), 0.0, (double)(length))

#define svizeros(x, length) svinums(x, length, 0.0)
#define lvizeros(x, length) lvinums(x, length, 0.0)
#define fvizeros(x, length) fvinums(x, length, 0.0)
#define dvizeros(x, length) dvinums(x, length, 0.0)

#define sviones(x, length) svinums(x, length, 1.0)
#define lviones(x, length) lvinums(x, length, 1.0)
#define fviones(x, length) fvinums(x, length, 1.0)
#define dviones(x, length) dvinums(x, length, 1.0)

#define vsset(xs, index, x) {(xs)->vector[index]=(x);}
#define svsset vsset
#define lvsset vsset
#define fvsset vsset
#define dvsset vsset

/* for backwards compatibility */
typedef SVector SVECTOR;
typedef LVector LVECTOR;
typedef FVector FVECTOR;
typedef DVector DVECTOR;

typedef SVectors SVECTORS;
typedef LVectors LVECTORS;
typedef FVectors FVECTORS;
typedef DVectors DVECTORS;

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __VECTOR_H */
