/*
 *	window.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/memory.h>
#include <sp/vector.h>
#include <sp/window.h>

/*
 *	blackman window
 */
void blackmanf(float window[], long length)
{
    long k;
    double a, b;
    double value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);
    b = 2.0 * a;

    for (k = 0; k < length; k++) {
	value = 0.42 - 0.5 * cos(a * (double)k) + 0.08 * cos(b * (double)k);
	window[k] = (float)value;
    }

    return;
}

void blackman(double window[], long length)
{
    long k;
    double a, b;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);
    b = 2.0 * a;

    for (k = 0; k < length; k++) {
	window[k] = 0.42 - 0.5 * cos(a * (double)k) + 0.08 * cos(b * (double)k);
    }

    return;
}

FVector xfvblackman(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    blackmanf(vec->data, vec->length);

    return vec;
}

DVector xdvblackman(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    blackman(vec->data, vec->length);

    return vec;
}

/*
 *	hamming window
 */
void hammingf(float window[], long length)
{
    long k;
    double a;
    double value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);

    for (k = 0; k < length; k++) {
	value = 0.54 - 0.46 * cos(a * (double)k);
	window[k] = (float)value;
    }

    return;
}

void hamming(double window[], long length)
{
    long k;
    double a;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);

    for (k = 0; k < length; k++) {
	window[k] = 0.54 - 0.46 * cos(a * (double)k);
    }

    return;
}

FVector xfvhamming(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    hammingf(vec->data, vec->length);

    return vec;
}

DVector xdvhamming(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    hamming(vec->data, vec->length);

    return vec;
}

/*
 *	hanning window
 */
void hanningf(float window[], long length)
{
    long k;
    double a;
    double value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length + 1);

    for (k = 0; k < length; k++) {
	value = 0.5 - 0.5 * cos(a * (double)(k + 1));
	window[k] = (float)value;
    }

    return;
}

void hanning(double window[], long length)
{
    long k;
    double a;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length + 1);

    for (k = 0; k < length; k++) {
	window[k] = 0.5 - 0.5 * cos(a * (double)(k + 1));
    }

    return;
}

FVector xfvhanning(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    hanningf(vec->data, vec->length);

    return vec;
}

DVector xdvhanning(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    hanning(vec->data, vec->length);

    return vec;
}

#if 1
void gausswinf(float window[], long length)
{
    long k;
    double t0, value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }

    t0 = (double)(length / 2);
    
    for (k = 0; k < length; k++) {
	value = ((double)k - t0) / t0;
	window[k] = (float)exp(-PI * SQUARE(value));
    }

    return;
}

void gausswin(double window[], long length)
{
    long k;
    double t0, value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }

    t0 = (double)(length / 2);
    
    for (k = 0; k < length; k++) {
	value = ((double)k - t0) / t0;
	window[k] = exp(-PI * SQUARE(value));
    }

    return;
}

FVector xfvgausswin(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    gausswinf(vec->data, vec->length);

    return vec;
}

DVector xdvgausswin(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    gausswin(vec->data, vec->length);

    return vec;
}
#endif

/*
 *	normalized blackman window
 */
void nblackmanf(float window[], long length)
{
    long k;
    double a, b;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);
    b = 2.0 * a;

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.42 - 0.5 * cos(a * (double)k) + 0.08 * cos(b * (double)k);
	power += SQUARE(value);
	window[k] = (float)value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= (float)rms;
    }

    return;
}

void nblackman(double window[], long length)
{
    long k;
    double a, b;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);
    b = 2.0 * a;

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.42 - 0.5 * cos(a * (double)k) + 0.08 * cos(b * (double)k);
	power += SQUARE(value);
	window[k] = value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= rms;
    }

    return;
}

FVector xfvnblackman(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    nblackmanf(vec->data, vec->length);

    return vec;
}

DVector xdvnblackman(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    nblackman(vec->data, vec->length);

    return vec;
}

/*
 *	hamming window
 */
void nhammingf(float window[], long length)
{
    long k;
    double a;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.54 - 0.46 * cos(a * (double)k);
	power += SQUARE(value);
	window[k] = (float)value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= (float)rms;
    }

    return;
}

void nhamming(double window[], long length)
{
    long k;
    double a;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length - 1);

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.54 - 0.46 * cos(a * (double)k);
	power += SQUARE(value);
	window[k] = value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= rms;
    }

    return;
}

FVector xfvnhamming(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    nhammingf(vec->data, vec->length);

    return vec;
}

DVector xdvnhamming(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    nhamming(vec->data, vec->length);

    return vec;
}

/*
 *	hanning window
 */
void nhanningf(float window[], long length)
{
    long k;
    double a;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length + 1);

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.5 - 0.5 * cos(a * (double)(k + 1));
	power += SQUARE(value);
	window[k] = (float)value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= (float)rms;
    }

    return;
}

void nhanning(double window[], long length)
{
    long k;
    double a;
    double value;
    double power, rms;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }
    a = 2.0 * PI / (double)(length + 1);

    for (k = 0, power = 0.0; k < length; k++) {
	value = 0.5 - 0.5 * cos(a * (double)(k + 1));
	power += SQUARE(value);
	window[k] = value;
    }
#if 1
    rms = sqrt(power / (double)length);
#else
    rms = sqrt(power);
#endif

    for (k = 0; k < length; k++) {
	window[k] /= rms;
    }

    return;
}

FVector xfvnhanning(long length)
{
    FVector vec;

    vec = xfvalloc(length);
    nhanningf(vec->data, vec->length);

    return vec;
}

DVector xdvnhanning(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    nhanning(vec->data, vec->length);

    return vec;
}

/*
 *	rectangular window
 */
void nboxcarf(float window[], long length)
{
    long k;
    float value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }

    value = 1.0 / (float)sqrt((double)length);
    for (k = 0; k < length; k++) {
	window[k] = value;
    }

    return;
}

void nboxcar(double window[], long length)
{
    long k;
    double value;

    if (length <= 1) {
	if (length == 1) {
	    window[0] = 1.0;
	}
	return;
    }

    value = 1.0 / sqrt((double)length);
    for (k = 0; k < length; k++) {
	window[k] = value;
    }

    return;
}

FVector xfvnboxcar(long length)
{
    FVector vec;
    
    vec = xfvalloc(length);
    nboxcarf(vec->data, vec->length);

    return vec;
}

DVector xdvnboxcar(long length)
{
    DVector vec;

    vec = xdvalloc(length);
    nboxcar(vec->data, vec->length);

    return vec;
}
