/*
 *	fft.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/memory.h>
#include <sp/fft.h>
#include <sp/vector.h>
#include <sp/voperate.h>
#include <sp/filter.h>

/*
 *	convolution using fft
 */
FVector xfvfftconv(FVector a, FVector b, long fftl)
{
    FVector x;
    FVector ca, cb;

    /* fft of a */
    ca = xfvfft(a, fftl);
    
    /* fft of b */
    cb = xfvfft(b, fftl);

    /* convolution */
    fvoper(ca, "*", cb);

    /* ifft */
    x = xfvifft(ca, fftl);
    fvreal(x);

    /* memory free */
    xfvfree(ca);
    xfvfree(cb);

    return x;
}

DVector xdvfftconv(DVector a, DVector b, long fftl)
{
    DVector x;
    DVector ca, cb;

    /* fft of a */
    ca = xdvfft(a, fftl);
    
    /* fft of b */
    cb = xdvfft(b, fftl);

    /* convolution */
    dvoper(ca, "*", cb);

    /* ifft */
    x = xdvifft(ca, fftl);
    dvreal(x);

    /* memory free */
    xdvfree(ca);
    xdvfree(cb);

    return x;
}

FVector xfvfftpower(FVector x, long fftl)
{
    FVector y;

    /* fft */
    y = xfvfft(x, fftl);

    /* square of complex */
    fvsquare(y);

    return y;
}

DVector xdvfftpower(DVector x, long fftl)
{
    DVector y;

    /* fft */
    y = xdvfft(x, fftl);

    /* square of complex */
    dvsquare(y);

    return y;
}

FVector xfvfftabs(FVector x, long fftl)
{
    FVector y;

    /* fft */
    y = xfvfft(x, fftl);

    /* abs of complex */
    fvabs(y);

    return y;
}

DVector xdvfftabs(DVector x, long fftl)
{
    DVector y;

    /* fft */
    y = xdvfft(x, fftl);

    /* abs of complex */
    dvabs(y);

    return y;
}

DVector xdvfftangle(DVector x, long fftl)
{
    DVector y;

    /* fft */
    y = xdvfft(x, fftl);

    /* phase angle */
    dvangle(y);

    return y;
}

DVector xdvfftgrpdly(DVector x, long fftl)
{
    long k;
    double value;
    DVector fx;
    DVector dfx;
    DVector gd;

    /* fft of input signal */
    fx = xdvfft(x, fftl);

    /* calculate frequency diff spectrum */
    dfx = xdvrizeros(fx->length);
    for (k = 0; k < x->length; k++) {
	if (k >= dfx->length) break;
	
	dfx->imag[k] = -(double)k * x->data[k];
    }
    dvfft(dfx);

    /* calculate group delay */
    gd = xdvalloc(fx->length);
    for (k = 0; k < fx->length; k++) {
	value = SQUARE(fx->data[k]) + SQUARE(fx->imag[k]);
	if (value == 0.0) {
	    gd->data[k] = 0.0;
	} else {
	    gd->data[k] = -(dfx->imag[k] * fx->data[k] -
			    fx->imag[k] * dfx->data[k]) / value;
	}
    }

    /* memory free */
    xdvfree(fx);
    xdvfree(dfx);

    return gd;
}

DVector xdvgdtophase(DVector gd, long fftl, int reverse)
{
    long k;
    double rv;
    double value;
    DVector phs;

    /* integrate group delay */
    phs = xdvscoper(gd, "*", -2.0 * PI / (double)(fftl));
    
    /* if necessary, reverse signal */
    if (reverse == 1) {
	phs->data[0] = PI;
    } else {
	phs->data[0] = 0.0;
    }
    dvcumsum(phs);

    rv = phs->data[fftl-1] + phs->data[1] - 2.0 * phs->data[0];
    value = -rv + 2.0 * PI * round(rv / (2.0 * PI));
    
    /* make phase continuous */
    for (k = 0; k < fftl; k++) {
	phs->data[k] = phs->data[k] + (double)k * value / (double)fftl;
    }

    return phs;
}

DVector xdvzerophase(DVector x, long fftl)
{
    DVector y;

    /* fft */
    y = xdvfft(x, fftl);

    /* abs of complex */
    dvabs(y);

    /* ifft */
    dvifft(y);

    /* fft shift */
    dvfftshift(y);

    return y;
}

void dvspectocep(DVector x)
{
    long k;

    dvabs(x);
    for (k = 0; k < x->length; k++) {
	if (x->data[k] > 0.0) {
	    x->data[k] = log(x->data[k]);
	} else {
	    x->data[k] = log(ALITTLE_NUMBER);
	}
    }

    dvifft(x);
    dvreal(x);

    return;
}

void dvceptospec(DVector x)
{
    /* convert cepstrum to spectrum */
    dvfft(x);
    dvexp(x);

    return;
}

DVector xdvrcep(DVector x, long fftl)
{
    DVector cep;

    cep = xdvfftabs(x, fftl);
    dvspectocep(cep);

    return cep;
}

void dvrcep(DVector x)
{
    rfftcep(x->data, NULL, x->length);
    return;
}

void dvceptompc(DVector cep)
{
    long k;
    long fftl2;

    fftl2 = cep->length / 2;
    
    for (k = 0; k < cep->length; k++) {
	if (k == 0) {
	    cep->data[k] = cep->data[k];
	} else if (k < fftl2) {
	    cep->data[k] = 2.0 * cep->data[k];
	} else {
	    cep->data[k] = 0.0;
	}
    }

    return;
}

DVector xdvmpcep(DVector x, long fftl)
{
    DVector cep;

    cep = xdvrcep(x, fftl);
    dvceptompc(cep);

    return cep;
}

void dvmpcep(DVector x)
{
    dvrcep(x);
    dvceptompc(x);
    
    return;
}

/*
 *	liftering function
 *	If lif < 0, high quefrency components are extracted.
 */
void dvlif(DVector cep, long fftl, long lif)
{
    long k;
    long lif2;

    if (lif >= 0) {
	lif2 = fftl - lif;
	for (k = 0; k < cep->length; k++) {
	    if (k > lif && k < lif2) {
		cep->data[k] = 0.0;
	    }
	}
    } else {
	lif *= -1;
	lif2 = fftl - lif;
	for (k = 0; k < cep->length; k++) {
	    if (k <= lif || k >= lif2) {
		cep->data[k] = 0.0;
	    }
	}
    }

    return;
}

DVector xdvcspec(DVector mag, DVector phs)
{
    DVector spc;
    DVector phe;

    if (mag == NODATA && phs == NODATA) {
	return NODATA;
    } else if (phs == NODATA) {
	phe = xdvabs(mag);
    } else {
	/* exponential of phase */
	phe = xdvcplx(NODATA, phs);
	dvexp(phe);

	if (mag != NODATA) {
	    /* multiply phase */
	    spc = xdvabs(mag);
	    dvoper(phe, "*", spc);

	    /* memory free */
	    xdvfree(spc);
	}
    }

    return phe;
}

DVector xdvtsp(double amp, long m, long n, int inverse)
{
    long k;
    long fftl, hfftl;
    double a0;
    double *real, *imag;
    DVector tsp;

    fftl = POW2(nextpow2(n));
    hfftl = fftl / 2;
    a0 = 4.0 * PI * (double)m / ((double)fftl * (double)fftl);
    if (inverse) a0 *= -1.0;

    real = xalloc(fftl, double);
    imag = xalloc(fftl, double);

    real[0] = amp;
    imag[0] = 0.0;
    for (k = 1; k <= hfftl; k++) {
	real[k] = amp * cos(a0 * (double)k * (double)k);
	imag[k] = amp * sin(a0 * (double)k * (double)k);
	real[fftl - k] = real[k];
	imag[fftl - k] = -imag[k];
    }

    fft(real, imag, fftl, 1);

    tsp = xdvalloc(fftl);
    for (k = 0; k < fftl; k++) {
	tsp->data[k] = real[k];
    }

    xfree(real);
    xfree(imag);

    return tsp;
}

void fvdatashift(FVector x, long shift)
{
    datashiftf(x->data, x->imag, x->length, shift);

    return;
}

void dvdatashift(DVector x, long shift)
{
    datashift(x->data, x->imag, x->length, shift);

    return;
}

void fvcircleshift(FVector x, long shift)
{
    circleshiftf(x->data, x->imag, x->length, shift);

    return;
}

void dvcircleshift(DVector x, long shift)
{
    circleshift(x->data, x->imag, x->length, shift);

    return;
}

void fvfftshift(FVector x)
{
    fftshiftf(x->data, x->imag, x->length);

    return;
}

void dvfftshift(DVector x)
{
    fftshift(x->data, x->imag, x->length);

    return;
}

FVector xfvfftshift(FVector x, long length)
{
    FVector y;

    if (x->imag != NULL) {
	y = xfvrizeros(length);
    } else {
	y = xfvzeros(length);
    }
    fvcopy(y, x);
    
    fftshiftf(y->data, y->imag, y->length);
    
    return y;
}

DVector xdvfftshift(DVector x, long length)
{
    DVector y;

    if (x->imag != NULL) {
	y = xdvrizeros(length);
    } else {
	y = xdvzeros(length);
    }
    dvcopy(y, x);
    
    fftshift(y->data, y->imag, y->length);
    
    return y;
}

void fvfftturn(FVector x)
{
    fftturnf(x->data, x->imag, x->length);

    return;
}

void dvfftturn(DVector x)
{
    fftturn(x->data, x->imag, x->length);

    return;
}

FVector xfvfftturn(FVector x, long length)
{
    FVector y;

    if (x->imag != NULL) {
	y = xfvrizeros(length);
    } else {
	y = xfvzeros(length);
    }
    fvcopy(y, x);
    
    fftturnf(y->data, y->imag, y->length);
    
    return y;
}

DVector xdvfftturn(DVector x, long length)
{
    DVector y;

    if (x->imag != NULL) {
	y = xdvrizeros(length);
    } else {
	y = xdvzeros(length);
    }
    dvcopy(y, x);
    
    fftturn(y->data, y->imag, y->length);
    
    return y;
}

void fvfft(FVector x)
{
    if (x->imag == NULL) {
	fvizeros(x, x->length);
    }

    fftf(x->data, x->imag, x->length, 0);

    return;
}

void dvfft(DVector x)
{
    if (x->imag == NULL) {
	dvizeros(x, x->length);
    }

    fft(x->data, x->imag, x->length, 0);

    return;
}

void fvifft(FVector x)
{
    if (x->imag == NULL) {
	fvizeros(x, x->length);
    }

    fftf(x->data, x->imag, x->length, 1);

    return;
}

void dvifft(DVector x)
{
    if (x->imag == NULL) {
	dvizeros(x, x->length);
    }

    fft(x->data, x->imag, x->length, 1);

    return;
}

FVector xfvfft(FVector x, long length)
{
    long fftp;
    FVector y;

    fftp = POW2(nextpow2(length));

    y = xfvrizeros(fftp);
    fvcopy(y, x);

    fftf(y->data, y->imag, fftp, 0);

    return y;
}

DVector xdvfft(DVector x, long length)
{
    long fftp;
    DVector y;

    fftp = POW2(nextpow2(length));

    y = xdvrizeros(fftp);
    dvcopy(y, x);

    fft(y->data, y->imag, fftp, 0);

    return y;
}

FVector xfvifft(FVector x, long length)
{
    long fftp;
    FVector y;

    fftp = POW2(nextpow2(length));

    y = xfvrizeros(fftp);
    fvcopy(y, x);

    fftf(y->data, y->imag, fftp, 1);

    return y;
}

DVector xdvifft(DVector x, long length)
{
    long fftp;
    DVector y;

    fftp = POW2(nextpow2(length));

    y = xdvrizeros(fftp);
    dvcopy(y, x);

    fft(y->data, y->imag, fftp, 1);

    return y;
}

int rfftabs(double *x, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);
    
    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 0);
	
    for (k = 0; k < fftp; k++) {
	x[k] = xRe[k] * xRe[k] + xIm[k] * xIm[k];
	x[k] = sqrt(x[k]);
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int rfftpow(double *x, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 0);
	
    for (k = 0; k < fftp; k++) {
	x[k] = xRe[k] * xRe[k] + xIm[k] * xIm[k];
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int rfftangle(double *x, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 0);
	
    for (k = 0; k < fftp; k++) {
	if (xRe[k] == 0.0 && xIm[k] == 0.0) {
	    x[k] = 0.0;
	} else {
	    x[k] = atan2(xIm[k], xRe[k]);
	}
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int rfft(double *x, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 0);
	
    for (k = 0; k < fftp; k++) {
	x[k] = xRe[k];
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int rifft(double *x, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 1);
	
    for (k = 0; k < fftp; k++) {
	x[k] = xRe[k];
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int rfftcep(double *x, double *pw, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = x[k];
	xIm[k] = 0.0;
    }
	
    fft(xRe, xIm, fftp, 0);
	
    for (k = 0; k < fftp; k++) {
	xRe[k] = xRe[k] * xRe[k] + xIm[k] * xIm[k];
	if (pw != NULL) {
	    pw[k] = xRe[k];
	}

	if (xRe[k] <= 0.0) {
	    xRe[k] = ALITTLE_NUMBER;
	}
	
	xRe[k] = 0.5 * log(xRe[k]);
	xIm[k] = 0.0;
    }

    fft(xRe, xIm, fftp, 1);

    for (k = 0; k < fftp; k++) {
	x[k] = xRe[k];
    }
    
    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int spectocep(double *real, double *imag, double *cep, long fftp)
{
    long k;
    double *xRe, *xIm;

    xRe = xalloc(fftp, double);
    xIm = xalloc(fftp, double);

    arrcpy(xRe, real, fftp, double);
    arrcpy(xIm, imag, fftp, double);

    for (k = 0; k < fftp; k++) {
	xRe[k] = xRe[k] * xRe[k] + xIm[k] * xIm[k];
	if (xRe[k] <= 0.0) {
	    xRe[k] = ALITTLE_NUMBER;
	}
	
	xRe[k] = 0.5 * log(xRe[k]);
	xIm[k] = 0.0;
    }

    fft(xRe, xIm, fftp, 1);

    for (k = 0; k < fftp; k++) {
	cep[k] = xRe[k];
    }

    xfree(xRe);
    xfree(xIm);
    
    return SUCCESS;
}

int ceptospec(double *cep, double *real, double *imag, long fftp)
{
    long k;
    
    for (k = 0; k < fftp; k++) {
	real[k] = cep[k];
	imag[k] = 0.0;
    }

    fft(real, imag, fftp, 0);

    for (k = 0; k < fftp; k++) {
	cexp(&real[k], &imag[k]);
    }

    return SUCCESS;
}

int ceplif(double *cep, long fftl, long lif)
{
    long k;
    long lif2;

    if (lif >= 0) {
	lif2 = fftl - lif;
	for (k = 0; k < fftl; k++) {
	    if (k > lif && k < lif2) {
		cep[k] = 0.0;
	    }
	}
    } else {
	lif *= -1;
	lif2 = fftl - lif;
	for (k = 0; k < fftl; k++) {
	    if (k <= lif || k >= lif2) {
		cep[k] = 0.0;
	    }
	}
    }

    return SUCCESS;
}

int cepwlif(double *cep, long fftl, long period, long width)
{
    long k, l;
    long hfftl;
    long lif, lif2;

    if (period <= 0) {
	return SUCCESS;
    }

    width = MAX(width, 0);
    hfftl = fftl / 2 + 1;

    for (l = 1;; l++) {
	lif = l * period - width / 2;
	lif2 = fftl - lif;

	for (k = 0; k < width; k++) {
	    if (lif + k < hfftl) {
		cep[lif + k] = 0.0;
		cep[lif2 - k] = 0.0;
	    }
	}
	if (lif + k >= hfftl) {
	    break;
	}
    }

    return SUCCESS;
}

void datashiftf(float *real, float *imag, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (real != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    real[k] = real[k - shift];
		} else {
		    real[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    real[k] = real[k - shift];
		} else {
		    real[k] = 0.0;
		}
	    }
	}
    }

    if (imag != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    imag[k] = imag[k - shift];
		} else {
		    imag[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    imag[k] = imag[k - shift];
		} else {
		    imag[k] = 0.0;
		}
	    }
	}
    }
    
    return;
}

void datashift(double *real, double *imag, long length, long shift)
{
    long k;
    long len;

    if (length <= 0 || shift == 0) return;

    if (real != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    real[k] = real[k - shift];
		} else {
		    real[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    real[k] = real[k - shift];
		} else {
		    real[k] = 0.0;
		}
	    }
	}
    }

    if (imag != NULL) {
	if (shift > 0) {
	    for (k = length - 1; k >= 0; k--) {
		if (k >= shift) {
		    imag[k] = imag[k - shift];
		} else {
		    imag[k] = 0.0;
		}
	    }
	} else {
	    len = length + shift;
	    for (k = 0; k < length; k++) {
		if (k < len) {
		    imag[k] = imag[k - shift];
		} else {
		    imag[k] = 0.0;
		}
	    }
	}
    }
    
    return;
}

void circleshiftf(float *real, float *imag, long length, long shift)
{
    int flag = 0;
    long init;
    long i, k, l;
    float value, value2;

    if (length <= 0 || shift == 0 || ((shift = shift % length) == 0)) return;

    if (ABS(gcd(length, shift)) != 1) flag = 1;

    if (real != NULL) {
	k = 0;
	init = k;
	value = real[k];
	for (i = 0; i < length; i++) {
	    l = k + shift;
	    if (l < 0) l += length;
	    else if (l >= length) l -= length;

	    value2 = real[l];
	    real[l] = value;
	    value = value2;
	    k = l;
	    
	    if (k == init && flag) {
		k++;
		init = k;
		value = real[k];
	    }
	}
    }

    if (imag != NULL) {
	k = 0;
	init = k;
	value = imag[k];
	for (i = 0; i < length; i++) {
	    l = k + shift;
	    if (l < 0) l += length;
	    else if (l >= length) l -= length;

	    value2 = imag[l];
	    imag[l] = value;
	    value = value2;
	    k = l;
	    
	    if (k == init && flag) {
		k++;
		init = k;
		value = imag[k];
	    }
	}
    }

    return;
}

void circleshift(double *real, double *imag, long length, long shift)
{
    int flag = 0;
    long init;
    long i, k, l;
    double value, value2;

    if (length <= 0 || shift == 0 || ((shift = shift % length) == 0)) return;

    if (ABS(gcd(length, shift)) != 1) flag = 1;

    if (real != NULL) {
	k = 0;
	init = k;
	value = real[k];
	for (i = 0; i < length; i++) {
	    l = k + shift;
	    if (l < 0) l += length;
	    else if (l >= length) l -= length;

	    value2 = real[l];
	    real[l] = value;
	    value = value2;
	    k = l;
	    
	    if (k == init && flag) {
		k++;
		init = k;
		value = real[k];
	    }
	}
    }

    if (imag != NULL) {
	k = 0;
	init = k;
	value = imag[k];
	for (i = 0; i < length; i++) {
	    l = k + shift;
	    if (l < 0) l += length;
	    else if (l >= length) l -= length;

	    value2 = imag[l];
	    imag[l] = value;
	    value = value2;
	    k = l;
	    
	    if (k == init && flag) {
		k++;
		init = k;
		value = imag[k];
	    }
	}
    }

    return;
}

/*
 *	fft turn for float data 
 */
void fftturnf(float *real, float *imag, long fftp)
{
    long i;
    long hfftp;

    hfftp = fftp - (fftp / 2);

    if (real != NULL) {
	/* real part */
	for (i = 1; i < hfftp; i++) {
	    real[fftp - i] = real[i];
	}
    }
    if (imag != NULL) {
	/* imaginary part */
	for (i = 1; i < hfftp; i++) {
	    imag[fftp - i] = imag[i];
	}
    }

    return;
} 

/*
 *	fft turn 
 */
void fftturn(double *real, double *imag, long fftp)
{
    long i;
    long hfftp;

    hfftp = fftp - (fftp / 2);

    if (real != NULL) {
	/* real part */
	for (i = 1; i < hfftp; i++) {
	    real[fftp - i] = real[i];
	}
    }
    if (imag != NULL) {
	/* imaginary part */
	for (i = 1; i < hfftp; i++) {
	    imag[fftp - i] = -imag[i];
	}
    }

    return;
} 

/*
 *	fft shift for float data
 */
void fftshiftf(float *real, float *imag, long fftp)
{
    long i;
    long hfftp, hfftp2;
    float value, value2;

    hfftp = fftp / 2;
    hfftp2 = fftp - hfftp;

    if (real != NULL) {
	/* real part */
	value2 = real[hfftp];
	real[hfftp] = real[fftp - 1];	/* if fft point is odd */
	for (i = 0; i < hfftp; i++) {
	    value = real[i];
	    real[i] = value2;
	    value2 = real[i + hfftp + 1];
	    real[i + hfftp2] = value;
	}
    }
    if (imag != NULL) {
	/* imaginaly part */
	value2 = imag[hfftp];
	imag[hfftp] = imag[fftp - 1];	/* if fft point is odd */
	for (i = 0; i < hfftp; i++) {
	    value = imag[i];
	    imag[i] = value2;
	    value2 = imag[i + hfftp + 1];
	    imag[i + hfftp2] = value;
	}
    }

    return;
} 

/*
 *	fft shift 
 */
void fftshift(double *real, double *imag, long fftp)
{
    long i;
    long hfftp, hfftp2;
    double value, value2;

    hfftp = fftp / 2;
    hfftp2 = fftp - hfftp;

    if (real != NULL) {
	/* real part */
	value2 = real[hfftp];
	real[hfftp] = real[fftp - 1];	/* if fft point is odd */
	for (i = 0; i < hfftp; i++) {
	    value = real[i];
	    real[i] = value2;
	    value2 = real[i + hfftp + 1];
	    real[i + hfftp2] = value;
	}
    }
    if (imag != NULL) {
	/* imaginaly part */
	value2 = imag[hfftp];
	imag[hfftp] = imag[fftp - 1];	/* if fft point is odd */
	for (i = 0; i < hfftp; i++) {
	    value = imag[i];
	    imag[i] = value2;
	    value2 = imag[i + hfftp + 1];
	    imag[i + hfftp2] = value;
	}
    }

    return;
} 

/*
 *	calculate FFT for float data 
 */
int spfftf(float *real, float *imag, long fftp, int inv)
{
    long p;
    long i, ip, j, k, m, me, me1, n, nv2;
    float uRe, uIm, vRe, vIm, wRe, wIm, tRe, tIm;

    p = nextpow2(fftp);
    n = POW2(p);
    if (n != fftp) {
	fprintf(stderr, "fft error: fft point must be a power of 2\n");
	return FAILURE;
    }
    nv2 = n / 2;

    if (inv) {
	for (i = 0; i < n; i++) {
	    imag[i] = -imag[i];
	}
    }

    /* bit reversion */
    for (i = 0, j = 0; i < n - 1; i++) {
	if (j > i) {
	    tRe = real[j];	tIm = imag[j];
	    real[j] = real[i];	imag[j] = imag[i];
	    real[i] = tRe;	imag[i] = tIm;
	}
	k = nv2;
	while (j >= k) {
	    j -= k;
	    k /= 2;
	}
	j += k;
    }

    /* butterfly numeration */
    for (m = 1; m <= p; m++) {
	me = POW2(m);		me1 = me / 2;
	uRe = 1.0;		uIm = 0.0;
	wRe = (float)cos(PI / (double)me1);
	wIm = (float)(-sin(PI / (double)me1));
	for (j = 0; j < me1; j++) {
	    for (i = j; i < n; i += me) {
		ip = i + me1;
		tRe = real[ip] * uRe - imag[ip] * uIm;
		tIm = real[ip] * uIm + imag[ip] * uRe;
		real[ip] = real[i] - tRe;
		imag[ip] = imag[i] - tIm;
		real[i] += tRe;
		imag[i] += tIm;
	    }
	    vRe = uRe * wRe - uIm * wIm;
	    vIm = uRe * wIm + uIm * wRe;
	    uRe = vRe;
	    uIm = vIm;
	}
    }

    if (inv) {
	for (i = 0; i < n; i++) {
	    real[i] /= (float)n;
	    imag[i] /= (float)(-n);

	}
    }

    return SUCCESS;
}

/*
 *	calculate FFT 
 */
int spfft(double *real, double *imag, long fftp, int inv)
{
    long p;
    long i, ip, j, k, m, me, me1, n, nv2;
    double uRe, uIm, vRe, vIm, wRe, wIm, tRe, tIm;

    p = nextpow2(fftp);
    n = POW2(p);
    if (n != fftp) {
	fprintf(stderr, "fft error: fft point must be a power of 2\n");
	return FAILURE;
    }
    nv2 = n / 2;

    if (inv) {
	for (i = 0; i < n; i++) {
	    imag[i] = -imag[i];
	}
    }

    /* bit reversion */
    for (i = 0, j = 0; i < n - 1; i++) {
	if (j > i) {
	    tRe = real[j];	tIm = imag[j];
	    real[j] = real[i];	imag[j] = imag[i];
	    real[i] = tRe;	imag[i] = tIm;
	}
	k = nv2;
	while (j >= k) {
	    j -= k;
	    k /= 2;
	}
	j += k;
    }

    /* butterfly numeration */
    for (m = 1; m <= p; m++) {
	me = POW2(m);		me1 = me / 2;
	uRe = 1.0;		uIm = 0.0;
	wRe = cos(PI / (double)me1);
	wIm = (-sin(PI / (double)me1));
	for (j = 0; j < me1; j++) {
	    for (i = j; i < n; i += me) {
		ip = i + me1;
		tRe = real[ip] * uRe - imag[ip] * uIm;
		tIm = real[ip] * uIm + imag[ip] * uRe;
		real[ip] = real[i] - tRe;
		imag[ip] = imag[i] - tIm;
		real[i] += tRe;
		imag[i] += tIm;
	    }
	    vRe = uRe * wRe - uIm * wIm;
	    vIm = uRe * wIm + uIm * wRe;
	    uRe = vRe;
	    uIm = vIm;
	}
    }

    if (inv) {
	for (i = 0; i < n; i++) {
	    real[i] /= (double)n;
	    imag[i] /= (double)(-n);

	}
    }

    return SUCCESS;
}
