/*
 *	fft.h
 */

#ifndef __FFT_H
#define __FFT_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern FVector xfvfftconv(FVector a, FVector b, long fftl);
extern DVector xdvfftconv(DVector a, DVector b, long fftl);

extern FVector xfvfftpower(FVector x, long fftl);
extern DVector xdvfftpower(DVector x, long fftl);
extern FVector xfvfftabs(FVector x, long fftl);
extern DVector xdvfftabs(DVector x, long fftl);
extern DVector xdvfftangle(DVector x, long fftl);
extern DVector xdvfftgrpdly(DVector x, long fftl);
extern DVector xdvgdtophase(DVector gd, long fftl, int reverse);
extern DVector xdvzerophase(DVector x, long fftl);

extern void dvspectocep(DVector x);
extern void dvceptospec(DVector x);
extern DVector xdvrcep(DVector x, long fftl);
extern void dvrcep(DVector x);
extern void dvceptompc(DVector cep);
extern DVector xdvmpcep(DVector x, long fftl);
extern void dvmpcep(DVector x);
extern void dvlif(DVector cep, long fftl, long lif);

extern DVector xdvcspec(DVector mag, DVector phs);
extern DVector xdvtsp(double amp, long m, long n, int inverse);

extern void fvdatashift(FVector x, long shift);
extern void dvdatashift(DVector x, long shift);
extern void fvcircleshift(FVector x, long shift);
extern void dvcircleshift(DVector x, long shift);
extern FVector xfvfftshift(FVector x, long length);
extern DVector xdvfftshift(DVector x, long length);
extern FVector xfvfftturn(FVector x, long length);
extern DVector xdvfftturn(DVector x, long length);
extern void fvfftshift(FVector x);
extern void dvfftshift(DVector x);
extern void fvfftturn(FVector x);
extern void dvfftturn(DVector x);

extern void fvfft(FVector x);
extern void dvfft(DVector x);
extern void fvifft(FVector x);
extern void dvifft(DVector x);
extern FVector xfvfft(FVector x, long length);
extern DVector xdvfft(DVector x, long length);
extern FVector xfvifft(FVector x, long length);
extern DVector xdvifft(DVector x, long length);

extern int rfftabs(double *x, long fftp);
extern int rfftpow(double *x, long fftp);
extern int rfftangle(double *x, long fftp);
extern int rfft(double *x, long fftp);
extern int rifft(double *x, long fftp);
extern int rfftcep(double *x, double *pw, long fftp);
extern int spectocep(double *real, double *imag, double *cep, long fftp);
extern int ceptospec(double *cep, double *real, double *imag, long fftp);
extern int ceplif(double *cep, long fftl, long lif);
extern int cepwlif(double *cep, long fftl, long period, long width);

extern void datashiftf(float *real, float *imag, long length, long shift);
extern void datashift(double *real, double *imag, long length, long shift);
extern void circleshiftf(float *real, float *imag, long length, long shift);
extern void circleshift(double *real, double *imag, long length, long shift);

extern void fftturnf(float *xRe, float *xIm, long fftp);
extern void fftturn(double *xRe, double *xIm, long fftp);
extern void fftshiftf(float *xRe, float *xIm, long fftp);
extern void fftshift(double *xRe, double *xIm, long fftp);
extern int spfftf(float *xRe, float *xIm, long fftp, int inv);
extern int spfft(double *xRe, double *xIm, long fftp, int inv);

#if defined(MACOS)
#pragma import off
#endif

#define fftf(xRe, xIm, fftp, inv) spfftf(xRe, xIm, fftp, inv);
#define fft(xRe, xIm, fftp, inv) spfft(xRe, xIm, fftp, inv);

#define xdvrceps(x, fftl) xdvrcep(x, fftl)
#define dvrceps(x) dvrcep(x)
#define xdvmpceps(x, fftl) xdvmpcep(x, fftl)
#define dvmpceps(x) dvmpcep(x)

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __FFT_H */
