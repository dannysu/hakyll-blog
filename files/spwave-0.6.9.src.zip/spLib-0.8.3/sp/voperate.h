/*
 *	voperate.h
 */

#ifndef __VOPERATE_H
#define __VOPERATE_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void fvoper(FVector a, char *op, FVector b);
extern void dvoper(DVector a, char *op, DVector b);
extern FVector xfvoper(FVector a, char *op, FVector b);
extern DVector xdvoper(DVector a, char *op, DVector b);

extern void fvscoper(FVector a, char *op, float t);
extern void dvscoper(DVector a, char *op, double t);
extern FVector xfvscoper(FVector a, char *op, float t);
extern DVector xdvscoper(DVector a, char *op, double t);

extern void svoper(SVector a, char *op, SVector b);
extern void lvoper(LVector a, char *op, LVector b);
extern SVector xsvoper(SVector a, char *op, SVector b);
extern LVector xlvoper(LVector a, char *op, LVector b);
extern void svscoper(SVector a, char *op, double t);
extern void lvscoper(LVector a, char *op, double t);
extern SVector xsvscoper(SVector a, char *op, double t);
extern LVector xlvscoper(LVector a, char *op, double t);

extern void svabs(SVector x);
extern void lvabs(LVector x);
extern void fvabs(FVector x);
extern void dvabs(DVector x);
extern SVector xsvabs(SVector x);
extern LVector xlvabs(LVector x);
extern FVector xfvabs(FVector x);
extern DVector xdvabs(DVector x);

extern void svsquare(SVector x);
extern void lvsquare(LVector x);
extern void fvsquare(FVector x);
extern void dvsquare(DVector x);
extern SVector xsvsquare(SVector x);
extern LVector xlvsquare(LVector x);
extern FVector xfvsquare(FVector x);
extern DVector xdvsquare(DVector x);

extern void svsign(SVector x);
extern void lvsign(LVector x);
extern void fvsign(FVector x);
extern void dvsign(DVector x);
extern SVector xsvsign(SVector x);
extern LVector xlvsign(LVector x);
extern FVector xfvsign(FVector x);
extern DVector xdvsign(DVector x);

extern SVector xsvremap(SVector x, LVector map);
extern LVector xlvremap(LVector x, LVector map);
extern FVector xfvremap(FVector x, LVector map);
extern DVector xdvremap(DVector x, LVector map);

extern SVector xsvcodiff(SVector x, double coef);
extern LVector xlvcodiff(LVector x, double coef);
extern FVector xfvcodiff(FVector x, double coef);
extern DVector xdvcodiff(DVector x, double coef);

extern LVector xsvfind(SVector x);
extern LVector xlvfind(LVector x);
extern LVector xfvfind(FVector x);
extern LVector xdvfind(DVector x);

extern DVector xdvfindv(DVector x);
extern DVector xdvsceval(DVector x, char *op, double t);
extern LVector xdvscfind(DVector x, char *op, double t);
extern DVector xdvscfindv(DVector x, char *op, double t);

extern void lvcumsum(LVector x);
extern void fvcumsum(FVector x);
extern void dvcumsum(DVector x);
extern LVector xlvcumsum(LVector x);
extern FVector xfvcumsum(FVector x);
extern DVector xdvcumsum(DVector x);

extern void lvcumprod(LVector x);
extern void fvcumprod(FVector x);
extern void dvcumprod(DVector x);
extern LVector xlvcumprod(LVector x);
extern FVector xfvcumprod(FVector x);
extern DVector xdvcumprod(DVector x);

extern void fvexp(FVector x);
extern void dvexp(DVector x);
extern FVector xfvexp(FVector x);
extern DVector xdvexp(DVector x);

extern void fvlog(FVector x);
extern void dvlog(DVector x);
extern FVector xfvlog(FVector x);
extern DVector xdvlog(DVector x);

extern void fvdecibel(FVector x);
extern void dvdecibel(DVector x);
extern FVector xfvdecibel(FVector x);
extern DVector xdvdecibel(DVector x);

extern FVector xfvrandn(long length);
extern DVector xdvrandn(long length);

extern void dvsort(DVector x);

extern long svsum(SVector x);
extern long lvsum(LVector x);
extern float fvsum(FVector x);
extern double dvsum(DVector x);
extern long svsqsum(SVector x);
extern long lvsqsum(LVector x);
extern float fvsqsum(FVector x);
extern double dvsqsum(DVector x);
extern long svabssum(SVector x);
extern long lvabssum(LVector x);
extern float fvabssum(FVector x);
extern double dvabssum(DVector x);

extern short svmax(SVector x, long *index);
extern long lvmax(LVector x, long *index);
extern float fvmax(FVector x, long *index);
extern double dvmax(DVector x, long *index);

extern short svmin(SVector x, long *index);
extern long lvmin(LVector x, long *index);
extern float fvmin(FVector x, long *index);
extern double dvmin(DVector x, long *index);

extern void svscmax(SVector x, short a);
extern void lvscmax(LVector x, long a);
extern void fvscmax(FVector x, float a);
extern void dvscmax(DVector x, double a);

extern void svscmin(SVector x, short a);
extern void lvscmin(LVector x, long a);
extern void fvscmin(FVector x, float a);
extern void dvscmin(DVector x, double a);

extern float fvdot(FVector x, FVector y);
extern double dvdot(DVector x, DVector y);

extern void dvmorph(DVector x, DVector y, double rate);
extern DVector xdvmorph(DVector x, DVector y, double rate);

#if defined(MACOS)
#pragma import off
#endif

#define svmean(x) ((double)svsum(x) / (double)x->length)
#define lvmean(x) ((double)lvsum(x) / (double)x->length)
#define fvmean(x) ((double)fvsum(x) / (double)x->length)
#define dvmean(x) (dvsum(x) / (double)x->length)
#define xsvdiff(x) xsvcodiff(x, 1.0);
#define xlvdiff(x) xlvcodiff(x, 1.0);
#define xfvdiff(x) xfvcodiff(x, 1.0);
#define xdvdiff(x) xdvcodiff(x, 1.0);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __VOPERATE_H */
