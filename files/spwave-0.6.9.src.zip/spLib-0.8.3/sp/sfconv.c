/*
 *	sfconv.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/base.h>
#include <sp/memory.h>
#include <sp/vector.h>
#include <sp/filter.h>
#include <sp/fileio.h>
#include <sp/fft.h>
#include <sp/sfconv.h>

static long sfc_fftl = 512;		/* fft point */
static double sfc_framem = 30.0;	/* frame length [ms] */
static double sfc_cutoff = 0.95;	/* normalized cut off frequency */
static double sfc_sidelobe = 40.0; 	/* sidelobe [dB] */
static double sfc_transition = 0.05;	/* normalized transition width */
static double sfc_tolerance = 2;	/* tolerance [%] */

/*
 *	set/get parameter for sampling frequency converting
 */
void setsfcframe(double framem)
{
    sfc_framem = MAX(framem, 1.0);
    return;
}

void getsfcframe(double *framem)
{
    if (framem != NULL)
	*framem = sfc_framem;
    return;
}

void setsfcparam(double cutoff, double sidelobe, double transition, double tolerance, long fftl)
{
    sfc_cutoff = MAX(cutoff, 0.0);
    sfc_sidelobe = MAX(sidelobe, 10.0);
    sfc_transition = MAX(transition, 0.0);
    sfc_tolerance = MAX(tolerance, 0.0);
    sfc_fftl = MAX(fftl, 128);
    return;
}

void getsfcparam(double *cutoff, double *sidelobe, double *transition, double *tolerance, long *fftl)
{
    if (cutoff != NULL) *cutoff = sfc_cutoff;
    if (sidelobe != NULL) *sidelobe = sfc_sidelobe;
    if (transition != NULL) *transition = sfc_transition;
    if (tolerance != NULL) *tolerance = sfc_tolerance;
    if (fftl != NULL) *fftl = sfc_fftl;
    return;
}

/*
 *	get ratio of sampling frequency converting
 */
double getsfcratio(double i_samp_freq, double o_samp_freq, double tolerance, 
		   long *upratio, long *downratio)
{
    int flag;
    long i, j;
    double x;
    long div;
    long up, down;
    double new_samp_freq;
    
    up =  (long)round(o_samp_freq * 100.0);
    down = (long)round(i_samp_freq * 100.0);
    div = gcd(up, down);
    up /= div;
    down /= div;
    tolerance *= (double)up;

    spDebug(10, "getsfcratio", "div = %ld, up = %ld, down = %ld, tolerance = %f\n", 
	    div, up, down, tolerance);
    
    flag = ((tolerance == 0.0 || (up < 10 && down < 10)) ? 0 : 1);
    for (i = 1; i <= up && flag == 1; i++) {
	for(j = 1; j <= down && flag == 1; j++) {
	    x = fabs(down * i - up * j);
	    if(x <= tolerance) {
		up = i;
		down = j;
		flag = 0;
	    }
	}
    }

    *upratio = up;
    *downratio = down;
    new_samp_freq = i_samp_freq * (double)up / (double)down;

    return new_samp_freq;
}

DVector xdvupsample(DVector sig, long upratio)
{
    long k;
    DVector osig;

    /* memory allocation */
    osig = xdvzeros(sig->length * upratio);

    /* up sampling */
    for (k = 0; k < sig->length; k++) {
	osig->data[k * upratio] = sig->data[k];
    }

    return osig;
}

DVector xdvdownsample(DVector sig, long downratio, long offset, long length)
{
    long k;
    long pos;
    DVector osig;

    /* memory allocation */
    if (length <= 0) {
	length = (sig->length - offset) / downratio;
    }
    osig = xdvalloc(length);

    /* down sampling */
    for (k = 0; k < osig->length; k++) {
	pos = k * downratio + offset;
	if (pos < sig->length && pos >= 0) {
	    osig->data[k] = sig->data[pos];
	} else {
	    osig->data[k] = 0.0;
	}
    }

    return osig;
}

/*
 *	convert sampling frequency from file
 */
static int resamplefile_main(char *i_filename, int i_swap, char *o_filename, int o_swap,
			     DVector filter, long upratio, long downratio, int double_flag)
{
    long k;
    long pos;
    long length;
    long shift;
    long syn_pos;
    long syn_offset;
    int nread;
    double value;
    DVector isig, osig;
    DVector upsig;
    DVector filsig;
    FILE *fp, *fp2;

    /* open file */
    if (NULL == (fp = spOpenFile(i_filename, "rb"))) {
	return SP_FAILURE;
    }

    /* open file */
    if (NULL == (fp2 = spOpenFile(o_filename, "wb"))) {
	return SP_FAILURE;
    }
	
    /* get signal length */
    length = MAX(2048, (filter->length / 2) * 2);
    spDebug(10, "resamplefile", "filter length = %ld, frame length = %ld\n",
	    filter->length, length);
    
    /* allocate memory */
    isig = xdvzeros(length);
    osig = xdvzeros(isig->length * upratio + filter->length - 1);
    
    nread = 0;
    pos = (-filter->length / 2);
    syn_offset = 0;
    for (k = 0;; k++) {
	/* read frame */
	if (k == 0) {
	    if ((nread = dvreadfirst(isig, 0, isig->length, i_swap, double_flag, fp)) <= 0) {
		break;
	    }
	} else {
	    if ((nread = dvreadframe(isig, isig->length, isig->length, i_swap, double_flag, fp)) <= 0) {
		break;
	    }
	}
	
	/* up sampling */
	upsig = xdvupsample(isig, upratio);

	/* lowpass filtering */
	filsig = xdvfftfilt(filter, upsig, sfc_fftl);

	/* overlap add */
	dvadd(osig, pos, filsig, 0, filsig->length, 1);
	shift = (long)nread * upratio;
	pos += shift;

	if (pos > 0) {
	    for (syn_pos = syn_offset; syn_pos < pos; syn_pos += downratio) {
		if (syn_pos >= 0 && syn_pos < osig->length) {
		    value = osig->data[syn_pos];
		} else {
		    value = 0.0;
		}
		if (double_flag) {
		    fwritedouble(&value, 1, o_swap, fp2);
		} else {
		    fwritedoubletos(&value, 1, o_swap, fp2);
		}
	    }
	    syn_offset = syn_pos - pos;
	    
	    dvdatashift(osig, -pos);
	    pos = 0;
	}

	spDebug(10, "resamplefile", "shift = %ld, pos = %ld\n", shift, pos);
	
	/* free memory */
	xdvfree(upsig);
	xdvfree(filsig);
    }

    /* write last frame */
    pos = filter->length / 2 - 1;
    for (syn_pos = syn_offset; syn_pos < pos; syn_pos += downratio) {
	if (syn_pos >= 0 && syn_pos < osig->length) {
	    value = osig->data[syn_pos];
	} else {
	    value = 0.0;
	}
	if (double_flag) {
	    fwritedouble(&value, 1, o_swap, fp2);
	} else {
	    fwritedoubletos(&value, 1, o_swap, fp2);
	}
    }

    /* close file */
    spCloseFile(fp);
    spCloseFile(fp2);
    
    /* free memory */
    xdvfree(filter);
    xdvfree(isig);
    xdvfree(osig);
    
    return SP_SUCCESS;
}

int resamplefile(char *i_filename, int i_swap, char *o_filename, int o_swap,
		 DVector filter, long upratio, long downratio)
{
    return resamplefile_main(i_filename, i_swap, o_filename, o_swap,
			     filter, upratio, downratio, 0);
}

int resampledfile(char *i_filename, int i_swap, char *o_filename, int o_swap,
		  DVector filter, long upratio, long downratio)
{
    return resamplefile_main(i_filename, i_swap, o_filename, o_swap,
			     filter, upratio, downratio, 1);
}

static int sfconvlongfile_main(char *i_filename, int i_swap, double i_samp_freq,
			       char *o_filename, int o_swap, double o_samp_freq, int double_flag)
{
    long upratio, downratio;
    double new_samp_freq;
    double ratio;
    double cutoff;
    double transition;
    DVector filter;

    /* get convert ratio */
    new_samp_freq = getsfcratio(i_samp_freq, o_samp_freq, 
				sfc_tolerance / 100.0, &upratio, &downratio);
    spDebug(10, "sfconvlongfile_main", "upratio = %ld, downratio = %ld\n", upratio, downratio);
    spMessage("New Sampling Frequency: %f\n", new_samp_freq);
    
    /* get lowpass filter */
    ratio = (double)MAX(upratio, downratio);
    cutoff = sfc_cutoff / ratio;
    transition = sfc_transition / ratio;
    filter = xdvlowpass(cutoff, sfc_sidelobe, transition, (double)upratio);

    return resamplefile_main(i_filename, i_swap, o_filename, o_swap, filter,
			     upratio, downratio, double_flag);
}

int sfconvlongfile(char *i_filename, int i_swap, double i_samp_freq,
		   char *o_filename, int o_swap, double o_samp_freq)
{
    return sfconvlongfile_main(i_filename, i_swap, i_samp_freq,
			       o_filename, o_swap, o_samp_freq, 0);
}

int sfconvlongdfile(char *i_filename, int i_swap, double i_samp_freq,
		   char *o_filename, int o_swap, double o_samp_freq)
{
    return sfconvlongfile_main(i_filename, i_swap, i_samp_freq,
			       o_filename, o_swap, o_samp_freq, 1);
}

static DVector xdvsfconvfile_main(char *i_filename, int swap, double i_samp_freq, double o_samp_freq,
				  int double_flag)
{
    long k;
    long pos;
    long shift;
    long sig_len;
    long length;
    long upratio, downratio;
    double new_samp_freq;
    double ratio;
    double cutoff;
    double transition;
    DVector isig, osig;
    DVector downsig, upsig;
    DVector filsig;
    DVector filter;
    FILE *fp;

    /* open file */
    if (NULL == (fp = spOpenFile(i_filename, "rb"))) {
	return NODATA;
    }
    if (double_flag) {
	sig_len = getsiglen(i_filename, 0, double);
    } else {
	sig_len = getsiglen(i_filename, 0, short);
    }
    length = (long)(sfc_framem * i_samp_freq / 1000.0);
    spMessage("Frame Length: %ld\n", length);
    spDebug(10, "xdvsfconvfile", "input signal length = %ld, frame length = %ld\n", sig_len, length);
	
    /* get convert ratio */
    new_samp_freq = getsfcratio(i_samp_freq, o_samp_freq, 
				sfc_tolerance / 100.0, &upratio, &downratio);
    spDebug(10, "xdvsfconvfile_main", "upratio = %ld, downratio = %ld\n", upratio, downratio);
    spMessage("New Sampling Frequency: %f\n", new_samp_freq);
    
    /* get lowpass filter */
    ratio = (double)MAX(upratio, downratio);
    cutoff = sfc_cutoff / ratio;
    transition = sfc_transition / ratio;
    filter = xdvlowpass(cutoff, sfc_sidelobe, transition, (double)upratio);
    
    /* allocate memory */
    isig = xdvzeros(length);
    osig = xdvzeros((sig_len * upratio) / downratio);
    
    spDebug(10, "xdvsfconvfile", "up = %ld, down = %ld, cutoff = %f\n", upratio, downratio, cutoff);

    pos = -filter->length / 2 / downratio;
    shift = (isig->length * upratio) / downratio;
    spMessage("shift = %ld\n", shift);
    for (k = 0;; k++) {
	/* read frame */
	if (k == 0) {
	    if (dvreadfirst(isig, 0, length, swap, double_flag, fp) <= 0) {
		break;
	    }
	} else if (dvreadframe(isig, length, length, swap, double_flag, fp) <= 0) {
	    break;
	}
	
	/* up sampling */
	upsig = xdvupsample(isig, upratio);

	/* lowpass filtering */
	filsig = xdvfftfilt(filter, upsig, sfc_fftl);

	/* down sampling */
	downsig = xdvdownsample(filsig, downratio, 0, 0);

	/* overlap add */
	dvadd(osig, pos, downsig, 0, downsig->length, 1);
	pos += shift;

	/* free memory */
	xdvfree(upsig);
	xdvfree(filsig);
	xdvfree(downsig);
    }

    /* close file */
    spCloseFile(fp);
    
    /* free memory */
    xdvfree(filter);
    xdvfree(isig);
    
    return osig;
}

DVector xdvsfconvfile(char *i_filename, int swap, double i_samp_freq, double o_samp_freq)
{
    return xdvsfconvfile_main(i_filename, swap, i_samp_freq, o_samp_freq, 0);
}

DVector xdvsfconvdfile(char *i_filename, int swap, double i_samp_freq, double o_samp_freq)
{
    return xdvsfconvfile_main(i_filename, swap, i_samp_freq, o_samp_freq, 1);
}

DVector xdvresample(DVector isig, DVector filter, long upratio, long downratio)
{	
    DVector osig;
    DVector upsig;
    DVector filsig;

    /* up sampling */
    upsig = xdvupsample(isig, upratio);

    /* lowpass filtering */
    filsig = xdvfftfilt(filter, upsig, sfc_fftl);
    xdvfree(upsig);

    /* down sampling */
    osig = xdvdownsample(filsig, downratio, filter->length / 2, (isig->length * upratio / downratio));
    xdvfree(filsig);

    return osig;
}

DVector xdvsfconv(DVector isig, double i_samp_freq, double o_samp_freq)
{	
    double new_samp_freq;
    long upratio, downratio;
    double ratio;
    double cutoff;
    double transition;
    DVector osig;
    DVector filter;

    /* get ratio */
    new_samp_freq = getsfcratio(i_samp_freq, o_samp_freq, 
				sfc_tolerance / 100.0, &upratio, &downratio);
    spDebug(10, "xdvsfconv", "upratio = %ld, downratio = %ld\n", upratio, downratio);
    spMessage("New Sampling Frequency: %f\n", new_samp_freq);

    /* get lowpass filter */
    ratio = (double)MAX(upratio, downratio);
    cutoff = sfc_cutoff / ratio;
    transition = sfc_transition / ratio;
    filter = xdvlowpass(cutoff, sfc_sidelobe, transition, (double)upratio);

    spDebug(10, "xdvsfconv", "up = %ld, down = %ld, new_samp_freq = %f, cutoff = %f\n",
	    upratio, downratio, new_samp_freq, cutoff);

    /* resampling */
    osig = xdvresample(isig, filter, upratio, downratio);

    /* memory free */
    xdvfree(filter);
    
    return osig;
}

int sfconvfile(char *i_filename, int i_swap, double i_samp_freq,
	       char *o_filename, int o_swap, double o_samp_freq)
{
    DVector isig;
    DVector osig;
    
    if ((isig = xdvreadssignal(i_filename, 0, i_swap)) == NODATA) {
	return SP_FAILURE;
    }
    
    osig = xdvsfconv(isig, i_samp_freq, o_samp_freq);
    dvwritessignal(o_filename, osig, o_swap);
    
    return SP_SUCCESS;
}

int sfconvdfile(char *i_filename, int i_swap, double i_samp_freq,
		char *o_filename, int o_swap, double o_samp_freq)
{
    DVector isig;
    DVector osig;
    
    if ((isig = xdvreaddsignal(i_filename, 0, i_swap)) == NODATA) {
	return SP_FAILURE;
    }
    
    osig = xdvsfconv(isig, i_samp_freq, o_samp_freq);
    dvwritedsignal(o_filename, osig, o_swap);
    
    return SP_SUCCESS;
}

int sfconvfile2(char *i_filename, int i_swap, double i_samp_freq,
		char *o_filename, int o_swap, double o_samp_freq)
{
    DVector osig;
    
    if ((osig = xdvsfconvfile(i_filename, i_swap, i_samp_freq, o_samp_freq)) == NODATA) {
	return SP_FAILURE;
    }
    dvwritessignal(o_filename, osig, o_swap);
    
    return SP_SUCCESS;
}

