/*
 *	sfconv.h
 */

#ifndef __SFCONV_H
#define __SFCONV_H

#include <sp/vector.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void setsfcframe(double framem);
extern void getsfcframe(double *framem);
extern void setsfcparam(double cutoff, double sidelobe, double transition,
			double tolerance, long fftl);
extern void getsfcparam(double *cutoff, double *sidelobe, double *transition,
			double *tolerance, long *fftl);
extern double getsfcratio(double i_samp_freq, double o_samp_freq, double tolerance, 
			  long *upratio, long *downratio);

extern DVector xdvupsample(DVector sig, long upratio);
extern DVector xdvdownsample(DVector sig, long downratio, long offset, long length);

extern int resamplefile(char *i_filename, int i_swap, char *o_filename, int o_swap,
			DVector filter, long upratio, long downratio);
extern int resampledfile(char *i_filename, int i_swap, char *o_filename, int o_swap,
			 DVector filter, long upratio, long downratio);
extern int sfconvlongfile(char *i_filename, int i_swap, double i_samp_freq,
			  char *o_filename, int o_swap, double o_samp_freq);
extern int sfconvlongdfile(char *i_filename, int i_swap, double i_samp_freq,
			   char *o_filename, int o_swap, double o_samp_freq);
extern DVector xdvsfconvfile(char *i_filename, int swap, double i_samp_freq, double o_samp_freq);
extern DVector xdvsfconvdfile(char *i_filename, int swap, double i_samp_freq, double o_samp_freq);
extern DVector xdvresample(DVector isig, DVector filter, long upratio, long downratio);
extern DVector xdvsfconv(DVector isig, double i_samp_freq, double o_samp_freq);
extern int sfconvfile(char *i_filename, int i_swap, double i_samp_freq,
		      char *o_filename, int o_swap, double o_samp_freq);
extern int sfconvdfile(char *i_filename, int i_swap, double i_samp_freq,
		       char *o_filename, int o_swap, double o_samp_freq);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __SFCONV_H */
