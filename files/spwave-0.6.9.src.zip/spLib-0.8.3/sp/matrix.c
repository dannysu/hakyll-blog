/*
 *	vector.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <sp/sp.h>
#include <sp/memory.h>
#include <sp/matrix.h>

/*
 *	allocate and free memory
 */
LMatrix xlmalloc(long row, long col)
{
    LMatrix matrix;

    matrix = xalloc(1, struct _LMatrix);
    matrix->data = xlmatalloc(row, col);
    matrix->imag = NULL;
    matrix->row = row;
    matrix->col = col;

    return matrix;
}

DMatrix xdmalloc(long row, long col)
{
    DMatrix matrix;

    matrix = xalloc(1, struct _DMatrix);
    matrix->data = xdmatalloc(row, col);
    matrix->imag = NULL;
    matrix->row = row;
    matrix->col = col;

    return matrix;
}

void xlmfree(LMatrix matrix)
{
    if (matrix != NULL) {
	if (matrix->data != NULL) {
	    xlmatfree(matrix->data, matrix->row);
	}
	if (matrix->imag != NULL) {
	    xlmatfree(matrix->imag, matrix->row);
	}
	xfree(matrix);
    }

    return;
}

void xdmfree(DMatrix matrix)
{
    if (matrix != NULL) {
	if (matrix->data != NULL) {
	    xdmatfree(matrix->data, matrix->row);
	}
	if (matrix->imag != NULL) {
	    xdmatfree(matrix->imag, matrix->row);
	}
	xfree(matrix);
    }

    return;
}

void lmialloc(LMatrix x)
{
    if (x->imag != NULL) {
	xlmatfree(x->imag, x->row);
    }
    x->imag = xlmatalloc(x->row, x->col);

    return;
}

void dmialloc(DMatrix x)
{
    if (x->imag != NULL) {
	xdmatfree(x->imag, x->row);
    }
    x->imag = xdmatalloc(x->row, x->col);

    return;
}

void lmifree(LMatrix x)
{
    if (x->imag != NULL) {
	xlmatfree(x->imag, x->row);
    }
    
    return;
}

void dmifree(DMatrix x)
{
    if (x->imag != NULL) {
	xdmatfree(x->imag, x->row);
    }
    
    return;
}

LMatrix xlmrialloc(long row, long col)
{
    LMatrix matrix;

    matrix = xlmalloc(row, col);
    lmialloc(matrix);

    return matrix;
}

DMatrix xdmrialloc(long row, long col)
{
    DMatrix matrix;

    matrix = xdmalloc(row, col);
    dmialloc(matrix);

    return matrix;
}

LMatrices xlmsalloc(long num)
{
    long k;
    LMatrices xs;

    xs = xalloc(1, struct _LMatrices);
    xs->matrix = xalloc(MAX(num, 1), LMatrix);
    xs->num_matrix = num;
    
    for (k = 0; k < xs->num_matrix; k++) {
	xs->matrix[k] = NODATA;
    }

    return xs;
}

DMatrices xdmsalloc(long num)
{
    long k;
    DMatrices xs;

    xs = xalloc(1, struct _DMatrices);
    xs->matrix = xalloc(MAX(num, 1), DMatrix);
    xs->num_matrix = num;
    
    for (k = 0; k < xs->num_matrix; k++) {
	xs->matrix[k] = NODATA;
    }

    return xs;
}

void xlmsfree(LMatrices xs)
{
    long k;

    if (xs != NULL) {
	if (xs->matrix != NULL) {
	    for (k = 0; k < xs->num_matrix; k++) {
		if (xs->matrix[k] != NODATA) {
		    xlmfree(xs->matrix[k]);
		}
	    }
	    xfree(xs->matrix);
	}
	xfree(xs);
    }

    return;
}

void xdmsfree(DMatrices xs)
{
    long k;

    if (xs != NULL) {
	if (xs->matrix != NULL) {
	    for (k = 0; k < xs->num_matrix; k++) {
		if (xs->matrix[k] != NODATA) {
		    xdmfree(xs->matrix[k]);
		}
	    }
	    xfree(xs->matrix);
	}
	xfree(xs);
    }

    return;
}

void lmreal(LMatrix x)
{
    if (x->imag != NULL) {
	xlmatfree(x->imag, x->row);
    }
    
    return;
}

void dmreal(DMatrix x)
{
    if (x->imag != NULL) {
	xdmatfree(x->imag, x->row);
    }
    
    return;
}

void lmimag(LMatrix x)
{
    if (x->imag == NULL) {
	lmzeros(x, 0, 0);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;
    
    return;
}

void dmimag(DMatrix x)
{
    if (x->imag == NULL) {
	dmzeros(x, 0, 0);
	return;
    }

    xfree(x->data);
    x->data = x->imag;
    x->imag = NULL;
    
    return;
}

LMatrix xlmnums(long row, long col, long value)
{
    long k, l;
    LMatrix mat;

    if (row <= 0 || col <= 0) {
	fprintf(stderr, "wrong value\n");
#if 0
	mat = xlmnull();
	return mat;
#else
	return NODATA;
#endif
    }

    /* memory allocate */
    mat = xlmalloc(row, col);

    /* initailize data */
    for (k = 0; k < mat->row; k++) {
	for (l = 0; l < mat->col; l++) {
	    mat->data[k][l] = value;
	}
    }

    return mat;
}

DMatrix xdmnums(long row, long col, double value)
{
    long k, l;
    DMatrix mat;

    if (row <= 0 || col <= 0) {
	fprintf(stderr, "wrong value\n");
#if 0
	mat = xdmnull();
	return mat;
#else
	return NODATA;
#endif
    }

    /* memory allocate */
    mat = xdmalloc(row, col);

    /* initailize data */
    for (k = 0; k < mat->row; k++) {
	for (l = 0; l < mat->col; l++) {
	    mat->data[k][l] = value;
	}
    }

    return mat;
}

void lmnums(LMatrix mat, long row, long col, long value)
{
    long k, l;

    if (row <= 0 || row > mat->row) {
	row = mat->row;
    }
    if (col <= 0 || col > mat->col) {
	col = mat->col;
    }

    /* initailize data */
    for (k = 0; k < row; k++) {
	for (l = 0; l < col; l++) {
	    mat->data[k][l] = value;
	}
    }

    return;
}

void dmnums(DMatrix mat, long row, long col, double value)
{
    long k, l;

    if (row <= 0 || row > mat->row) {
	row = mat->row;
    }
    if (col <= 0 || col > mat->col) {
	col = mat->col;
    }

    /* initailize data */
    for (k = 0; k < row; k++) {
	for (l = 0; l < col; l++) {
	    mat->data[k][l] = value;
	}
    }

    return;
}

void lminums(LMatrix mat, long row, long col, long value)
{
    long k, l;

    if (row <= 0 || row > mat->row) {
	row = mat->row;
    }
    if (col <= 0 || col > mat->col) {
	col = mat->col;
    }

    if (mat->imag == NULL) {
	/* memory allocate */
	lmizeros(mat, 0, 0);
    }

    /* initailize data */
    for (k = 0; k < row; k++) {
	for (l = 0; l < col; l++) {
	    mat->imag[k][l] = value;
	}
    }

    return;
}

void dminums(DMatrix mat, long row, long col, double value)
{
    long k, l;

    if (row <= 0 || row > mat->row) {
	row = mat->row;
    }
    if (col <= 0 || col > mat->col) {
	col = mat->col;
    }

    if (mat->imag == NULL) {
	/* memory allocate */
	dmizeros(mat, 0, 0);
    }

    /* initailize data */
    for (k = 0; k < row; k++) {
	for (l = 0; l < col; l++) {
	    mat->imag[k][l] = value;
	}
    }

    return;
}

LMatrix xlmrinums(long row, long col, long value)
{
    LMatrix mat;

    mat = xlmnums(row, col, value);
    lmialloc(mat);
    lminums(mat, row, col, value);

    return mat;
}

DMatrix xdmrinums(long row, long col, double value)
{
    DMatrix mat;

    mat = xdmnums(row, col, value);
    dmialloc(mat);
    dminums(mat, row, col, value);

    return mat;
}

/*
 *	initialize each rows
 */
DMatrix xdminitrow(long nrow, double j, double incr, double n)
{
    long k, l;
    long num;
    DMatrix mat;

    if ((incr > 0.0 && j > n) || (incr < 0.0 && j < n)) {
	fprintf(stderr, "bad increment value\n");
#if 0
	mat = xdmnull();
	return mat;
#else
	return NODATA;
#endif
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
#if 0
	    mat = xdmnull();
	    return mat;
#else
	    return NODATA;
#endif
	}
    } else {
	num = labs((long)((n - j) / incr)) + 1;
    }
    
    /* memory allocate */
    mat = xdmalloc(nrow, num);

    /* initailize data */
    for (k = 0; k < mat->row; k++) {
	for (l = 0; l < mat->col; l++) {
	    mat->data[k][l] = j + (l * incr);
	}
    }

    return mat;
}

/*
 *	initialize each columns
 */
DMatrix xdminitcol(long ncol, double j, double incr, double n)
{
    long k, l;
    long num;
    DMatrix mat;

    if ((incr > 0.0 && j > n) || (incr < 0.0 && j < n)) {
	fprintf(stderr, "bad increment value\n");
#if 0
	mat = xdmnull();
	return mat;
#else
	return NODATA;
#endif
    }
    if (incr == 0.0) {
	num = (long)n;
	if (num <= 0) {
	    fprintf(stderr, "wrong value\n");
#if 0
	    mat = xdmnull();
	    return mat;
#else
	    return NODATA;
#endif
	}
    } else {
	num = labs((long)((n - j) / incr)) + 1;
    }
    
    /* memory allocate */
    mat = xdmalloc(num, ncol);

    /* initailize data */
    for (l = 0; l < mat->col; l++) {
	for (k = 0; k < mat->row; k++) {
	    mat->data[k][l] = j + (k * incr);
	}
    }

    return mat;
}

/*
 *	cut one row of matrix
 */
LVector xlmcutrow(LMatrix mat, long row, long offset, long length)
{
    long k;
    long pos;
    LVector vec;

    if (row < 0 || row >= mat->row) {
#if 0
	vec = xlvnull();
	return vec;
#else
	return NODATA;
#endif
    }

    if (mat->imag != NULL) {
	vec = xlvrizeros(length);
    } else {
	vec = xlvzeros(length);
    }

    for (k = 0; k < vec->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < mat->col) {
	    vec->data[k] = mat->data[row][pos];
	    if (vec->imag != NULL) {
		vec->imag[k] = mat->imag[row][pos];
	    }
	}
    }

    return vec;
}

DVector xdmcutrow(DMatrix mat, long row, long offset, long length)
{
    long k;
    long pos;
    DVector vec;

    if (row < 0 || row >= mat->row) {
#if 0
	vec = xdvnull();
	return vec;
#else
	return NODATA;
#endif
    }

    if (mat->imag != NULL) {
	vec = xdvrizeros(length);
    } else {
	vec = xdvzeros(length);
    }

    for (k = 0; k < vec->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < mat->col) {
	    vec->data[k] = mat->data[row][pos];
	    if (vec->imag != NULL) {
		vec->imag[k] = mat->imag[row][pos];
	    }
	}
    }

    return vec;
}

/*
 *	cut one column of matrix
 */
LVector xlmcutcol(LMatrix mat, long col, long offset, long length)
{
    long k;
    long pos;
    LVector vec;

    if (col < 0 || col >= mat->col) {
#if 0
	vec = xlvnull();
	return vec;
#else
	return NODATA;
#endif
    }

    if (mat->imag != NULL) {
	vec = xlvrizeros(length);
    } else {
	vec = xlvzeros(length);
    }

    for (k = 0; k < vec->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < mat->row) {
	    vec->data[k] = mat->data[pos][col];
	    if (vec->imag != NULL) {
		vec->imag[k] = mat->imag[pos][col];
	    }
	}
    }

    return vec;
}

DVector xdmcutcol(DMatrix mat, long col, long offset, long length)
{
    long k;
    long pos;
    DVector vec;

    if (col < 0 || col >= mat->col) {
#if 0
	vec = xdvnull();
	return vec;
#else
	return NODATA;
#endif
    }

    if (mat->imag != NULL) {
	vec = xdvrizeros(length);
    } else {
	vec = xdvzeros(length);
    }

    for (k = 0; k < vec->length; k++) {
	pos = k + offset;
	if (pos >= 0 && pos < mat->row) {
	    vec->data[k] = mat->data[pos][col];
	    if (vec->imag != NULL) {
		vec->imag[k] = mat->imag[pos][col];
	    }
	}
    }

    return vec;
}

/*
 *	paste vector on the row of matrix 
 */
void lmpasterow(LMatrix mat, long row, LVector vec,
		long offset, long length, int overlap)
{
    long k;
    long pos;

    if (row < 0 || row >= mat->row) {
	return;
    }
    if (length <= 0 || length > vec->length) {
	length = vec->length;
    }

    if (overlap) {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->col) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[row][pos] += vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[row][pos] += vec->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->col) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[row][pos] = vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[row][pos] = vec->imag[k];
		}
	    }
	}
    }
	
    return;
}

void dmpasterow(DMatrix mat, long row, DVector vec,
		long offset, long length, int overlap)
{
    long k;
    long pos;

    if (row < 0 || row >= mat->row) {
	return;
    }
    if (length <= 0 || length > vec->length) {
	length = vec->length;
    }

    if (overlap) {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->col) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[row][pos] += vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[row][pos] += vec->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->col) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[row][pos] = vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[row][pos] = vec->imag[k];
		}
	    }
	}
    }
	
    return;
}

/*
 *	paste vector on the column of matrix 
 */
void lmpastecol(LMatrix mat, long col, LVector vec,
		long offset, long length, int overlap)
{
    long k;
    long pos;

    if (col < 0 || col >= mat->col) {
	return;
    }
    if (length <= 0 || length > vec->length) {
	length = vec->length;
    }

    if (overlap) {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->row) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[pos][col] += vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[pos][col] += vec->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->row) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[pos][col] = vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[pos][col] = vec->imag[k];
		}
	    }
	}
    }
	
    return;
}

void dmpastecol(DMatrix mat, long col, DVector vec,
		long offset, long length, int overlap)
{
    long k;
    long pos;

    if (col < 0 || col >= mat->col) {
	return;
    }
    if (length <= 0 || length > vec->length) {
	length = vec->length;
    }

    if (overlap) {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->row) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[pos][col] += vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[pos][col] += vec->imag[k];
		}
	    }
	}
    } else {
	for (k = 0; k < length; k++) {
	    pos = k + offset;
	    if (pos >= mat->row) {
		break;
	    }
	    if (pos >= 0) {
		mat->data[pos][col] = vec->data[k];
		if (vec->imag != NULL && mat->imag != NULL) {
		    mat->imag[pos][col] = vec->imag[k];
		}
	    }
	}
    }
	
    return;
}

LVector xlmrmax(LMatrix mat)
{
    long k, l;
    long index;
    long max;
    LVector x;

    x = xlvalloc(mat->row);

    for (k = 0; k < mat->row; k++) {
	max = mat->data[k][0];
	index = 0;
	for (l = 1; l < mat->col; l++) {
	    if (max < mat->data[k][l]) {
		max = mat->data[k][l];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xdmrmax(DMatrix mat)
{
    long k, l;
    long index;
    double max;
    LVector x;

    x = xlvalloc(mat->row);

    for (k = 0; k < mat->row; k++) {
	max = mat->data[k][0];
	index = 0;
	for (l = 1; l < mat->col; l++) {
	    if (max < mat->data[k][l]) {
		max = mat->data[k][l];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xlmrmin(LMatrix mat)
{
    long k, l;
    long index;
    long min;
    LVector x;

    x = xlvalloc(mat->row);

    for (k = 0; k < mat->row; k++) {
	min = mat->data[k][0];
	index = 0;
	for (l = 1; l < mat->col; l++) {
	    if (min > mat->data[k][l]) {
		min = mat->data[k][l];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xdmrmin(DMatrix mat)
{
    long k, l;
    long index;
    double min;
    LVector x;

    x = xlvalloc(mat->row);

    for (k = 0; k < mat->row; k++) {
	min = mat->data[k][0];
	index = 0;
	for (l = 1; l < mat->col; l++) {
	    if (min > mat->data[k][l]) {
		min = mat->data[k][l];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xlmrextract(LMatrix mat, LVector idx)
{
    long k;
    LVector x;

    x = xlvalloc(idx->length);
    if (mat->imag != NULL) {
	lvialloc(x);
    }

    for (k = 0; k < x->length; k++) {
	if (k < mat->row && 
	    idx->data[k] >= 0 && idx->data[k] < mat->col) {
	    x->data[k] = mat->data[k][idx->data[k]];
	    if (x->imag != NULL) {
		x->imag[k] = mat->imag[k][idx->data[k]];
	    }
	} else {
	    x->data[k] = 0;
	    if (x->imag != NULL) {
		x->imag[k] = 0;
	    }
	}
    }

    return x;
}

DVector xdmrextract(DMatrix mat, LVector idx)
{
    long k;
    DVector x;

    x = xdvalloc(idx->length);
    if (mat->imag != NULL) {
	dvialloc(x);
    }

    for (k = 0; k < x->length; k++) {
	if (k < mat->row && 
	    idx->data[k] >= 0 && idx->data[k] < mat->col) {
	    x->data[k] = mat->data[k][idx->data[k]];
	    if (x->imag != NULL) {
		x->imag[k] = mat->imag[k][idx->data[k]];
	    }
	} else {
	    x->data[k] = 0.0;
	    if (x->imag != NULL) {
		x->imag[k] = 0.0;
	    }
	}
    }

    return x;
}

LVector xlmcmax(LMatrix mat)
{
    long k, l;
    long index;
    long max;
    LVector x;

    x = xlvalloc(mat->col);

    for (k = 0; k < mat->col; k++) {
	max = mat->data[0][k];
	index = 0;
	for (l = 1; l < mat->row; l++) {
	    if (max < mat->data[l][k]) {
		max = mat->data[l][k];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xdmcmax(DMatrix mat)
{
    long k, l;
    long index;
    double max;
    LVector x;

    x = xlvalloc(mat->col);

    for (k = 0; k < mat->col; k++) {
	max = mat->data[0][k];
	index = 0;
	for (l = 1; l < mat->row; l++) {
	    if (max < mat->data[l][k]) {
		max = mat->data[l][k];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xlmcmin(LMatrix mat)
{
    long k, l;
    long index;
    long min;
    LVector x;

    x = xlvalloc(mat->col);

    for (k = 0; k < mat->col; k++) {
	min = mat->data[0][k];
	index = 0;
	for (l = 1; l < mat->row; l++) {
	    if (min > mat->data[l][k]) {
		min = mat->data[l][k];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xdmcmin(DMatrix mat)
{
    long k, l;
    long index;
    double min;
    LVector x;

    x = xlvalloc(mat->col);

    for (k = 0; k < mat->col; k++) {
	min = mat->data[0][k];
	index = 0;
	for (l = 1; l < mat->row; l++) {
	    if (min > mat->data[l][k]) {
		min = mat->data[l][k];
		index = l;
	    }
	}
	x->data[k] = index;
    }

    return x;
}

LVector xlmcextract(LMatrix mat, LVector idx)
{
    long k;
    LVector x;

    x = xlvalloc(idx->length);
    if (mat->imag != NULL) {
	lvialloc(x);
    }

    for (k = 0; k < x->length; k++) {
	if (k < mat->col && 
	    idx->data[k] >= 0 && idx->data[k] < mat->row) {
	    x->data[k] = mat->data[idx->data[k]][k];
	    if (x->imag != NULL) {
		x->imag[k] = mat->imag[idx->data[k]][k];
	    }
	} else {
	    x->data[k] = 0;
	    if (x->imag != NULL) {
		x->imag[k] = 0;
	    }
	}
    }

    return x;
}

DVector xdmcextract(DMatrix mat, LVector idx)
{
    long k;
    DVector x;

    x = xdvalloc(idx->length);
    if (mat->imag != NULL) {
	dvialloc(x);
    }

    for (k = 0; k < x->length; k++) {
	if (k < mat->col && 
	    idx->data[k] >= 0 && idx->data[k] < mat->row) {
	    x->data[k] = mat->data[idx->data[k]][k];
	    if (x->imag != NULL) {
		x->imag[k] = mat->imag[idx->data[k]][k];
	    }
	} else {
	    x->data[k] = 0.0;
	    if (x->imag != NULL) {
		x->imag[k] = 0.0;
	    }
	}
    }

    return x;
}
#if 0
#endif
