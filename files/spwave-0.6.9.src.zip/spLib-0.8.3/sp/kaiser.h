/*
 *	kaiser.h
 */

#ifndef __KAISER_H
#define __KAISER_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(MACOS)
#pragma import on
#endif

extern void getkaiserparam(double sidelobe, double trans, double *beta, long *length);
extern int kaiser(double w[], long n, double beta);
extern double ai0(double x);

#if defined(MACOS)
#pragma import off
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __KAISER_H */
