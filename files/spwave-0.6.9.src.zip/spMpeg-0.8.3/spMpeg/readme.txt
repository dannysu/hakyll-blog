
	spMpeg - MPEG Audio I/O Library 

			Last modified: <00/12/14 02:18:55 hideki>


Introduction
------------

spMpeg is MPEG audio I/O library which is a part of spLibs
(http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/). This
library is based on freeamp's decoding engine and bladeenc's encoding
engine. However, the archive doesn't include the source code of
encoding engine and an MPEG audio encoder.


Install
-------

To compile this library on UNIX (including Linux) or Cygwin, go to the
spMpeg top directory, and make a symbolic link from `include'
directory and `lib' directory of spBase and spAudio
(e.g. /usr/local/include and /usr/local/lib) as follows:

 % cd spMpeg-X.X.X
 % ln -s /usr/local/include
 % ln -s /usr/local/lib

If you want to use the mpeg encoding engine, you need to prepare the
source of BladeEnc (http://bladeenc.mp3.no/) and make a symbolic link
from the directory including source code of bladeenc 
(in the following case, `../bladeenc-0.92.0/bladeenc') in the source 
directory of spMpeg:
 
 % tar zxvf bladeenc-0.92.0-src-stable.tar.gz
 % cd spMpeg
 % ln -s ../bladeenc-0.92.0/bladeenc

I tested version 0.92.0 of bladeenc. The directory name must be
`bladeenc'. If your platform is supported by the configuration file of
spBase, you can build the library by typing make:

 % make

To install this library to your system directory (e.g /usr/local), 
login as root and type:

 # make SPDESTROOT=/usr/local install
 # make SPDESTROOT=/usr/local install.hdr

If you don't want to make a symbolic link from spBase directory, you can
compile and install by adding TOP=/usr/local option (/usr/local is top
directory of spBase) to the above command line of `make' such as:
 
 % cd spMpeg-X.X.X
 % cd spMpeg
 % make TOP=/usr/local
 % su
 # make TOP=/usr/local SPDESTROOT=/usr/local install
 # make TOP=/usr/local SPDESTROOT=/usr/local install.hdr


Official Site
-------------

The official web site is:
  http://www.itakura.nuee.nagoya-u.ac.jp/people/banno/spLibs/
  

License
-------

Please see LICENSE.txt. This distribution includes decoding engine of
freeamp. The licences of this part are not covered by LICENSE.txt. If
you write MP3 encoders or commecial MP3 decoders using this library,
you may have to pay a royalty to patent holders. Please see Fraunhofer
IIS's homepage http://www.iis.fhg.de/amm/legal/ for more information.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
