#ifndef USE_LAME
#define USE_LAME
#endif
#include "../output_mpeg/output_mpeg.c"
