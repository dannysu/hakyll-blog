#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spMain.h>
#include <sp/spBaseLib.h>

#include <sp/spAudio.h>
#include <sp/spWave.h>

#include <sp/mpegCodec.h>
#include <sp/mpegEncode.h>

static long bit_rate;
static spBool crc_flag;
static spBool copyright_flag;
static spBool copy_flag;

static char title[SP_MAX_LINE] = "";
static char artist[SP_MAX_LINE] = "";
static char album[SP_MAX_LINE] = "";
static char comment[SP_MAX_LINE] = "";
static char year[SP_MAX_LINE] = "";
static char genre[SP_MAX_LINE] = "";
static spBool tag_flag;

static char i_param_file[SP_MAX_PATHNAME] = "";
static char o_param_file[SP_MAX_PATHNAME] = "";

static spBool quiet_flag;
static spBool help_flag;
static int debug_level = -1;

static spOptions options;
static spOption option[] = {
    {"-br", NULL, "bit rate [kbit/sec]", "bit_rate",
	 SP_TYPE_LONG, &bit_rate, "128"},
    {"-crc", NULL, "include checksum data", "crc",
	 SP_TYPE_BOOL, &crc_flag, SP_FALSE_STRING},
    {"-c", "-copyright", "set copyright flag", "copyright",
	 SP_TYPE_BOOL, &copyright_flag, SP_FALSE_STRING},
    {"-copy", NULL, "clear original flag", "copy",
	 SP_TYPE_BOOL, &copy_flag, SP_FALSE_STRING},
    {"-tag", NULL, "write ID3 tag", "use_tag",
	 SP_TYPE_BOOL, &tag_flag, SP_FALSE_STRING},
    {"-title", NULL, "title in ID3 tag", "title",
	 SP_TYPE_STRING_S, title, ""},
    {"-artist", NULL, "artist name in ID3 tag", "artist",
	 SP_TYPE_STRING_S, artist, ""},
    {"-album", NULL, "album name in ID3 tag", "album",
	 SP_TYPE_STRING_S, album, ""},
    {"-year", NULL, "year in ID3 tag", "year",
	 SP_TYPE_STRING_S, year, ""},
    {"-comment", NULL, "comment in ID3 tag", "comment",
	 SP_TYPE_STRING_S, comment, ""},
    {"-genre", NULL, "genre ID in ID3 tag (148: Unknown Genre, help: display list)", "genre",
	 SP_TYPE_STRING_S, genre, "148"},
    {"-iparam", NULL, "input parameter file", NULL,
	 SP_TYPE_STRING_S, i_param_file, NULL},
    {"-oparam", NULL, "output parameter file", NULL,
	 SP_TYPE_STRING_S, o_param_file, NULL},
    {"-q", "-quiet", "suppress message", NULL,
	 SP_TYPE_BOOLEAN, &quiet_flag, SP_FALSE_STRING},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-h", "-help", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<input wav file>",
    "<output mp3 file>",
};

int spMain(int argc, char *argv[])
{
    int i;
    long nloop;
    long nframe;
    long nread, nwrite;
    long nin, nout;
    long current_frame;
    long current_length;
    long total_length;
    char *string;
    char *i_filename;
    char *o_filename;
    long r_offset;
    long i_offset, o_offset;
    long i_buf_len, o_buf_len;
    char *i_buf, *o_buf;
    mpegHeader header;
    mpegEncode encode;
    mpegCodecInfo info;
    mpegID3Tag tag;
    spWaveInfo wave_info;
    FILE *fp = NULL, *ofp = NULL;
    
    spSetHelpMessage(&help_flag, "MP3 encoder");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    /* read parameter file */
    if (!strnone(i_param_file)) {
	spMessage("Input Parameter File: %s\n", i_param_file);
	spReadSetup(i_param_file, options);
    }
    
    if (strcaseeq(genre, "help")) {
	for (i = 0;; i++) {
	    if ((string = mpegGetID3TagGenreString(i)) == NULL) {
		break;
	    }
	    printf("%d: %s\n", i, string);
	}
	spExit(0);
    }
    
    spCheckNumFile(options);
    
    i_filename = spGetFile(options);
    o_filename = spGetFile(options);
    
    if ((encode = mpegOpenEncoder()) == NULL) {
	spError(1, "Can't initialize encode engine.\n");
    }
    
    if ((fp = spOpenFile(i_filename, "rb")) == NULL) {
	spExit(1);
    }

    if (spReadWavInfo(&wave_info, fp) == SP_FALSE) {
	spError(1, "Unsupported format: %s\n", i_filename);
    }
    total_length = wave_info.length;
    
    header.version = MPEG1_ID;
    header.layer = MPEG_LAYER3_ID;
    if (crc_flag == SP_TRUE) {
	header.crc_disable = 0;
    } else {
	header.crc_disable = 1;
    }
    header.bit_rate = 1000 * bit_rate;
    header.samp_rate = (long)spRound(wave_info.samp_rate);
    header.padding = 0;
    if (wave_info.num_channel >= 2) {
	header.channel_mode = MPEG_CHANNEL_STEREO_ID;
    } else {
	header.channel_mode = MPEG_CHANNEL_SINGLE_CHANNEL_ID;
    }
    header.mode_extention = 0;
    if (copyright_flag == SP_TRUE) {
	header.copyright = 1;
    } else {
	header.copyright = 0;
    }
    if (copy_flag == SP_TRUE) {
	header.original = 0;
    } else {
	header.original = 1;
    }
    header.emphasis = 0;
    spDebug(10, NULL, "bit rate = %ld\n", bit_rate);
    
    if (!mpegGetEncodeInfo(encode, &header, &info)) {
	spError(1, "Can't get encode information.\n");
    }
    spDebug(10, NULL, "get info done\n");

    mpegShowHeaderInfo(&header, NULL, NULL);

    nloop = 4;
    nframe = info.max_frame_size;
    i_buf_len = nloop * info.max_frame_size;
    i_buf = xalloc(i_buf_len, char);
    
    o_buf_len = nloop * info.max_output_size;
    o_buf = xalloc(o_buf_len, char);
    
    spDebug(10, NULL, "i_buf_len = %ld, o_buf_len = %ld\n", i_buf_len, o_buf_len);
    
    if (!strnone(o_filename)) {
	if ((ofp = spOpenFile(o_filename, "wb")) == NULL) {
	    spError(1, "Can't open file: %s\n", o_filename);
	}
    } else {
	if ((ofp = spOpenFile("-", "wb")) == NULL) {
	    spError(1, "Can't open stdout.\n");
	}
    }

    r_offset = 0;
    current_length = 0;
    current_frame = 0;
    for (;;) {
	if ((nread = spReadWavData(&wave_info, (short *)(i_buf + r_offset),
				   (i_buf_len - r_offset) / 2, fp)) <= 0) {
	    break;
	}
	nread *= 2;
	nread += r_offset;
	r_offset = 0;
	    
	nout = 0;
	i_offset = 0;
	o_offset = 0;
	for (i = 0; i < nloop; i++) {
	    if ((nin = MIN(nframe, nread - i_offset)) <= 0) {
		break;
	    }
	    spDebug(1, NULL, "i = %d, nread = %ld, nframe = %ld, nin = %ld\n",
		    i, nread, nframe, nin);
	    
	    if ((nout = mpegEncodeFrame(encode, &header, i_buf + i_offset,
					&nin, o_buf + o_offset)) <= 0) {
		break;
	    }
	    spDebug(1, NULL, "nin = %ld, nout = %ld\n", nin, nout);

	    i_offset += nin;
	    o_offset += nout;

	    current_frame++;
	}

	if ((nwrite = fwrite(o_buf, 1, o_offset, ofp)) <= 0) {
	    break;
	}
	current_length += i_offset;

	if (quiet_flag == SP_FALSE) {
	    spMessage("Status : %5.1f %% done %c%c",
		      100.0 * (float)current_length / (float)total_length
		      / (float)wave_info.num_channel / 2.0, 
		      (char)13, (char)0);
	}
	
	if (nout <= 0) {
	    break;
	}
	if (nread > i_offset) {
	    r_offset = nread - i_offset;
	    memmove(i_buf, i_buf + i_offset, r_offset);
	}
    }

    spDebug(1, NULL, "current_length = %ld, total_length = %ld\n",
	    current_length / wave_info.num_channel / 2, total_length);
    
    if ((nout = mpegEncodeLastFrame(encode, &header, o_buf)) >= 1) {
	nwrite = fwrite(o_buf, 1, nout, ofp);
    }
    
    if (tag_flag == SP_TRUE
	|| !strnone(title) || !strnone(artist) || !strnone(album)
	|| !strnone(year) || !strnone(comment) || !strnone(genre)) {
	mpegInitID3Tag(&tag);
	mpegSetID3TagItem(&tag, MPEG_ID3_TITLE_ID, title);
	mpegSetID3TagItem(&tag, MPEG_ID3_ARTIST_ID, artist);
	mpegSetID3TagItem(&tag, MPEG_ID3_ALBUM_ID, album);
	mpegSetID3TagItem(&tag, MPEG_ID3_YEAR_ID, year);
	mpegSetID3TagItem(&tag, MPEG_ID3_COMMENT_ID, comment);
	mpegSetID3TagGenreNumber(&tag, atoi(genre));
	mpegWriteID3Tag(&tag, ofp);
    }
    
    spCloseFile(ofp);
    spCloseFile(fp);
    
    mpegCloseEncoder(encode);
    
    /* memory free */
    xfree(i_buf);
    xfree(o_buf);
    
    /* write parameter file */
    if (!strnone(o_param_file)) {
	spMessage("Output Parameter File: %s\n", o_param_file);
	spWriteSetup(o_param_file, options);
    }
    
    return 0;
}
