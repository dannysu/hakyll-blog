#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spMain.h>
#include <sp/spBaseLib.h>

#include <sp/spAudio.h>
#include <sp/spWave.h>

#include <sp/mpegCodec.h>
#include <sp/mpegDecode.h>

static spBool help_flag;
static int debug_level = -1;

static spBool use_8kHz;
static spBool quiet_flag;
static int channel_mode;
static int reduction_mode;
static long freq_limit;

static long skip_frame;
static long buffer_size;
static long output_buffer_coef;

static spOptions options;
static spOption option[] = {
    {"-k", "-skip", "number of frame to skip first", "skip_frame",
	 SP_TYPE_LONG, &skip_frame, "0"},
    {"-buf", NULL, "buffer size for audio output", "buffer_size",
	 SP_TYPE_LONG, &buffer_size, "16384"},
    {"-oc", "-ocoef", "coefficient for output buffer size", "output_buffer_coef",
	 SP_TYPE_LONG, &output_buffer_coef, "8"},
    {"-cm", "-cmode", "channel mode (0: stereo, 1: mono, 2: left, 3: right)", "channel_mode",
	 SP_TYPE_INT, &channel_mode, "0"},
    {"-rm", "-rmode", "reduction mode (0: full rate, 1: half rate, 2: quarter rate)", "reduction_mode",
	 SP_TYPE_INT, &reduction_mode, "0"},
    {"-fl", "-flimit", "frequency upper limit [Hz] (0: no limitation)", "freq_limit",
	 SP_TYPE_LONG, &freq_limit, "0"},
    {"-8k", "-use8k", "use 8kHz mode", "use_8kHz",
	 SP_TYPE_BOOLEAN, &use_8kHz, SP_FALSE_STRING},
    {"-q", "-quiet", "suppress message", NULL,
	 SP_TYPE_BOOLEAN, &quiet_flag, SP_FALSE_STRING},
    {"-debug", NULL, "debug level", NULL,
	 SP_TYPE_INT, &debug_level, NULL},
    {"-h", "-help", "display this message", NULL,
	 SP_TYPE_BOOLEAN, &help_flag, SP_FALSE_STRING},
};

static char *filelabel[] = {
    "<input mpeg file>",
    " [output wav file]",
};


int spMain(int argc, char *argv[])
{
    int i;
    int flag;
    int skip_flag;
    long skip_len;
    long nloop;
    long nframe;
    long nread, nwrite;
    long nin, nout;
    long current_frame;
    long current_length;
    long total_length;
    char *i_filename;
    char *o_filename;
    long h_buf_len = 1024;
    char h_buf[1024];
    long r_offset;
    long i_offset, o_offset;
    long i_buf_len, o_buf_len;
    char *i_buf, *o_buf;
    mpegDecode decode;
    mpegHeader header;
    mpegCodecInfo info;
    mpegDecodeOption decode_option;
    mpegID3Tag tag;
    spWaveInfo wave_info;
    spAudio audio;
    FILE *fp = NULL, *ofp = NULL;

    spSetHelpMessage(&help_flag, "play MPEG audio file");
    options = spGetOptions(argc, argv, option, filelabel);
    spGetOptionsValue(argc, argv, options);
    spSetDebugLevel(debug_level);

    if ((i_filename = spGetFile(options)) == NULL) {
	spPrintError("Not enough files.");
    }
    o_filename = spGetFile(options);

    if ((decode = mpegOpenDecoder()) == NULL) {
	spError(1, "Can't initialize decode engine.\n");
    }
    decode_option.use_8kHz = use_8kHz;
    decode_option.bit_mode = 1;
    decode_option.channel_mode = channel_mode;
    decode_option.reduction_mode = reduction_mode;
    decode_option.freq_limit = freq_limit;
    mpegSetDecodeOption(decode, decode_option);
    
    if ((fp = spOpenFile(i_filename, "rb")) == NULL) {
	spError(1, "Can't open file: %s\n", i_filename);
    }
    
    /* read header */
    if ((h_buf_len = fread(h_buf, 1, h_buf_len, fp)) <= 0) {
	spError(1, "Can't read header.\n");
    }

    if ((skip_len = mpegGetUnsupportedHeaderSize(h_buf, h_buf_len)) > 0) {
	spDebug(10, NULL, "skip_len = %ld\n", skip_len);
	fseek(fp, skip_len, SEEK_SET);
	if ((h_buf_len = fread(h_buf, 1, h_buf_len, fp)) <= 0) {
	    spError(1, "Can't read header.\n");
	}
    }
    
    /* decode header */
    if (!mpegDecodeHeader(decode, &header, h_buf, &h_buf_len)) {
	spError(1, "Can't decode header.\n");
    }
    if (quiet_flag == SP_FALSE) {
	if (!mpegShowHeaderInfo(&header, NULL, NULL)) {
	    spError(1, "Can't show header information.\n");
	}
    }
    spDebug(10, NULL, "init done\n");
    if (!mpegGetDecodeInfo(decode, &header, &info)) {
	spError(1, "Can't get decode information.\n");
    }
    spDebug(10, NULL, "get info done\n");
    
    nloop = MAX(output_buffer_coef, 1);
    nframe = info.max_frame_size;
    i_buf_len = nloop * info.max_frame_size;
    i_buf = xalloc(i_buf_len, char);
    
    o_buf_len = nloop * info.max_output_size;
    o_buf = xalloc(o_buf_len, char);
    memset(o_buf, 0, o_buf_len);
    
    spDebug(10, NULL, "i_buf_len = %ld, o_buf_len = %ld\n", i_buf_len, o_buf_len);

    if (quiet_flag == SP_FALSE) {
	if (mpegReadID3Tag(&tag, fp)) {
	    mpegShowID3TagInfo(&tag, NULL, NULL);
	}
    }
    
    if (!strnone(o_filename)) {
	audio = NULL;

	if ((ofp = spOpenFile(o_filename, "wb")) == NULL) {
	    spError(1, "Can't open file: %s\n", o_filename);
	}

	spInitWaveInfo(&wave_info);
	wave_info.num_channel = info.num_channel;
	wave_info.samp_rate = info.samp_rate;
	wave_info.samp_bit = 16;
	wave_info.length = 1;

	spWriteWavInfo(&wave_info, ofp);
    } else {
	if ((audio = spInitAudio()) == NULL) {
	    spError(1, "Can't initialize audio.\n");
	}
	
	spDebug(10, NULL, "num_channel= %d\n", info.num_channel);
	spSetAudioSampleRate(audio, info.samp_rate);
	spSetAudioChannel(audio, info.num_channel);
	spSetAudioBufferSize(audio, buffer_size);
	
	/* open audio device */
	if (!spOpenAudioDevice(audio, "wo")) {
	    spError(1, "Can't open audio device.\n");
	}
    }
    
    fseek(fp, info.data_offset + skip_len, SEEK_SET);

    flag = 0;
    i_offset = 0;
    o_offset = 0;
    r_offset = 0;
    current_frame = 0;
    current_length = 0;
    total_length = 0;
    for (;;) {
	spDebug(10, NULL, "total_length = %ld\n", total_length);
	if ((nread = fread(i_buf + r_offset, 1, i_buf_len - r_offset, fp)) <= 0
	    && r_offset <= 0) {
	    break;
	}
	nread += r_offset;
	r_offset = 0;

	spDebug(10, NULL, "nread = %ld\n", nread);

	skip_flag = 1;
	nout = 0;
	i_offset = 0;
	o_offset = 0;
	for (i = 0; i < nloop; i++) {
	    if ((nin = MIN(nframe, nread - i_offset)) <= 0) {
		break;
	    }
	    spDebug(1, NULL, "i = %d, nframe = %ld, nin = %ld\n",
		    i, nframe, nin);

	    if (current_frame < skip_frame) {
		if ((nout = mpegDecodeSkipFrame(decode, &header, i_buf + i_offset,
						&nin)) <= 0) {
		    break;
		}
	    } else {
		if ((nout = mpegDecodeFrame(decode, &header, i_buf + i_offset,
					    &nin, o_buf + o_offset)) <= 0) {
		    break;
		}
		skip_flag = 0;
	    }
	    spDebug(1, NULL, "nin = %ld, nout = %ld\n", nin, nout);
	    
	    i_offset += nin;
	    o_offset += nout;

	    current_frame++;
	}

	if (!skip_flag) {
	    if (audio == NULL) {
		if ((nwrite = spWriteWavData(&wave_info, (short *)o_buf,
					     o_offset / 2, ofp)) <= 0) {
		    break;
		}
	    } else {
		nwrite = spWriteAudio(audio, (short *)o_buf, o_offset / 2);
	    }
	    current_length += nwrite;
	} else {
	    nwrite = o_offset / 2;
	}
	total_length += nwrite;
	if (quiet_flag == SP_FALSE) {
	    spMessage("Time: %5.2f [s] %c%c",
		      (double)(total_length / info.num_channel)
		      / info.samp_rate, (char)13, (char)0);
	}
	
	if (nout <= 0) {
	    break;
	}
	if (nread > i_offset) {
	    r_offset = nread - i_offset;
	    memmove(i_buf, i_buf + i_offset, r_offset);
	}
    }
    
    if (audio == NULL) {
	wave_info.length = current_length / wave_info.num_channel;
	spWriteWavInfo(&wave_info, ofp);
	spCloseFile(ofp);
    } else {
	spCloseAudioDevice(audio);
    }
    
    spCloseFile(fp);
    
    mpegCloseDecoder(decode);
    
    return 0;
}
