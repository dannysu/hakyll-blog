/*
 *	mpegEncode.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/mpegCodec.h>
#include <sp/mpegEncode.h>

#ifdef USE_LAME
#include <lame/lame.h>
#else
#include <bladeenc/codec.h>
#endif

struct _mpegEncode
{
#ifdef USE_LAME
    lame_global_flags gf;
    short buffer[2][1152];
    char filename[SP_MAX_PATHNAME];
#else
    CodecInitIn cinit_in;
#endif
    int init_flag;
};

mpegEncode mpegOpenEncoder(void)
{
    mpegEncode encode;
    
    encode = xalloc(1, struct _mpegEncode);
    encode->init_flag = 0;
#ifdef USE_LAME
    lame_init(&encode->gf);
#endif

    return encode;
}

int mpegSetEncodeOption(mpegEncode encode, mpegEncodeOption *option)
{
    if (encode == NULL || option == NULL) return 0;
    
#ifdef USE_LAME
    if (option->option_mask & MPEG_ENC_OPTION_QUALITY) {
	encode->gf.quality = option->quality;
    }
    if (option->option_mask & MPEG_ENC_OPTION_USE_LOWPASS) {
	if (option->use_lowpass) {
	    encode->gf.lowpassfreq = 0;
	} else {
	    encode->gf.lowpassfreq = -1;
	}
    }
    if (option->option_mask & MPEG_ENC_OPTION_USE_VBR) {
	if (option->filename != NULL) {
	    encode->gf.VBR = option->use_vbr;
	    strcpy(encode->filename, option->filename);
	    encode->gf.outPath = encode->filename;
	}
    }
    if (option->option_mask & MPEG_ENC_OPTION_VBR_QUALITY) {
	/*encode->gf.VBR_q = option->vbr_quality;*/
	encode->gf.VBR_q = MAX(option->vbr_quality, 1);	/* Quality `0' is not supported yet. */
    }
    if (option->option_mask & MPEG_ENC_OPTION_VBR_MIN_BITRATE) {
	encode->gf.VBR_min_bitrate_kbps = option->vbr_min_bitrate;
    }
    if (option->option_mask & MPEG_ENC_OPTION_VBR_MAX_BITRATE) {
	encode->gf.VBR_max_bitrate_kbps = option->vbr_max_bitrate;
    }
#endif
    
    return 1;
}

int mpegGetEncodeOption(mpegEncode encode, mpegEncodeOption *option)
{
    if (encode == NULL || option == NULL) return 0;
    
#ifdef USE_LAME
    option->option_mask = MPEG_ENC_OPTION_QUALITY | MPEG_ENC_OPTION_USE_LOWPASS
	| MPEG_ENC_OPTION_USE_VBR | MPEG_ENC_OPTION_VBR_QUALITY
        | MPEG_ENC_OPTION_VBR_MIN_BITRATE | MPEG_ENC_OPTION_VBR_MAX_BITRATE;
    option->quality = encode->gf.quality;
    if (encode->gf.lowpassfreq >= 0) {
	option->use_lowpass = 1;
    } else {
	option->use_lowpass = 0;
    }
    option->use_vbr = encode->gf.VBR;
    option->vbr_quality = encode->gf.VBR_q;
    option->vbr_min_bitrate = encode->gf.VBR_min_bitrate_kbps;
    option->vbr_max_bitrate = encode->gf.VBR_max_bitrate_kbps;
#else
    option->option_mask = 0;
#endif
    
    return 1;
}

int mpegGetEncodeInfo(mpegEncode encode, mpegHeader *header, mpegCodecInfo *info)
{
    if (encode == NULL || header == NULL || info == NULL) return 0;

#ifdef USE_LAME
    encode->gf.gtkflag = 0;
    encode->gf.silent = 1;
    encode->gf.brate = header->bit_rate / 1000;

    header->layer = MPEG_LAYER3_ID;
    if (header->samp_rate < 32000) {
	header->version = MPEG2_ID;
	encode->gf.brate = MAX(encode->gf.brate, 56);
	encode->gf.brate = MIN(encode->gf.brate, 160);
	encode->gf.VBR_min_bitrate_kbps = MAX(encode->gf.VBR_min_bitrate_kbps, 8);
	encode->gf.VBR_max_bitrate_kbps = MIN(encode->gf.VBR_max_bitrate_kbps, 160);
    } else {
	header->version = MPEG1_ID;
	encode->gf.brate = MAX(encode->gf.brate, 112);
	encode->gf.brate = MIN(encode->gf.brate, 320);
	encode->gf.VBR_min_bitrate_kbps = MAX(encode->gf.VBR_min_bitrate_kbps, 32);
	encode->gf.VBR_max_bitrate_kbps = MIN(encode->gf.VBR_max_bitrate_kbps, 320);
    }
    encode->gf.VBR_min_bitrate_kbps = MIN(encode->gf.VBR_min_bitrate_kbps,
					  encode->gf.VBR_max_bitrate_kbps);
    
    if (header->channel_mode == 3) {
	encode->gf.num_channels = 1;
    } else {
	encode->gf.num_channels = 2;
    }
    encode->gf.in_samplerate = header->samp_rate;
    encode->gf.mode = header->channel_mode;	/* 0=stereo, 1=jstereo, 3=mono */
    
    encode->gf.copyright = header->copyright;
    encode->gf.original = header->original;
    encode->gf.error_protection = (header->crc_disable == 0);
    encode->gf.padding_type = header->padding;
    encode->gf.extension = header->private_bit;
    
    lame_init_params(&encode->gf);

    info->max_frame_size = 1152 * 4;
    info->max_output_size = LAME_MAXMP3BUFFER;
    
    if (encode->gf.mode == 3) {	/* mono */
	info->num_channel = 1;
    } else {
	info->num_channel = 2;
    }
    info->samp_rate = encode->gf.out_samplerate;
    info->bit_rate = encode->gf.brate * 1000;
#else
    if (header->channel_mode != MPEG_CHANNEL_SINGLE_CHANNEL_ID) {
	header->channel_mode = MPEG_CHANNEL_STEREO_ID;	/* stereo only */
    }
    
    if (header->samp_rate != 44100 && header->samp_rate != 48000
	&& header->samp_rate != 32000) {
	spDebug(1, NULL, "Sampling rate must be 32, 44.1 or 48 kHz.\n");
	return 0;
    }
    header->version = MPEG1_ID;
    header->layer = MPEG_LAYER3_ID;
	
    encode->cinit_in.frequency = header->samp_rate;
    encode->cinit_in.mode = header->channel_mode;
    encode->cinit_in.bitrate = header->bit_rate / 1000;
    encode->cinit_in.emphasis = header->emphasis;
    encode->cinit_in.fPrivate = header->private_bit;
    encode->cinit_in.fCRC = header->crc_disable;
    encode->cinit_in.fCopyright = header->copyright;
    encode->cinit_in.fOriginal = header->original;
	
    {
	CodecInitOut *cinit_out;
	
	cinit_out = codecInit(&encode->cinit_in);
	info->max_frame_size = (long)cinit_out->nSamples * 2;
	info->max_output_size = (long)cinit_out->bufferSize;
	spDebug(10, "mpegGetEncodeInfo", "cinit_out->nSamples = %d, cinit_out->bufferSize = %d\n",
		cinit_out->nSamples, cinit_out->bufferSize);
    }
    
    if (encode->cinit_in.mode == 3) {
	info->num_channel = 1;
    } else {
	info->num_channel = 2;
    }
    info->samp_rate = encode->cinit_in.frequency;
    info->bit_rate = encode->cinit_in.bitrate * 1000;
#endif
    info->samp_bit = 16;
    info->data_offset = 0;

    spDebug(10, "mpegGetEncodeInfo", "max_frame_size = %ld, max_output_size = %ld\n",
	    info->max_frame_size, info->max_output_size);
    
    encode->init_flag = 1;
	
    return 1;
}

long mpegEncodeFrame(mpegEncode encode, mpegHeader *header,
		     char *input_buf, long *buf_size, char *output_buf)
{
    long nsample;
    long encoded_length;
    
    if (encode == NULL || input_buf == NULL || buf_size == NULL
	|| *buf_size <= 0 || output_buf == NULL) return -1;

    nsample = *buf_size / 2;
    spDebug(80, "mpegEncodeFrame", "nsample = %ld\n", nsample);
    
#ifdef USE_LAME
    {
	long k;
	short *sbuf = (short *)input_buf;
	
	if (encode->gf.mode == 3) { /* mono */
	    encoded_length = lame_encode_buffer(&encode->gf,
						sbuf, NULL,
						nsample, output_buf, LAME_MAXMP3BUFFER);
	} else {
	    for (k = 0; k < nsample; k++) {
		if (k % 2 == 0) {
		    encode->buffer[0][k/2] = sbuf[k];
		} else {
		    encode->buffer[1][(k-1)/2] = sbuf[k];
		}
	    }
	    nsample /= 2;
	    encoded_length = lame_encode_buffer(&encode->gf,
						encode->buffer[0], encode->buffer[1],
						nsample, output_buf, LAME_MAXMP3BUFFER);
	}
    }
#else
    encoded_length = codecEncodeChunk(nsample, (short *)input_buf, output_buf);
#endif
    spDebug(10, "mpegEncodeFrame", "encoded_length = %ld\n", encoded_length);
    
    return encoded_length;
}

long mpegEncodeLastFrame(mpegEncode encode, mpegHeader *header, char *output_buf)
{
    long encoded_length;
    
    if (encode == NULL || output_buf == NULL) return -1;
    
#ifdef USE_LAME
    encoded_length = lame_encode_finish(&encode->gf,
					output_buf, LAME_MAXMP3BUFFER);
#else
    encoded_length = codecExit(output_buf);
#endif
    
    return encoded_length;
}

/* You must call this after encoding if you use VBR */
int mpegEncodeTag(mpegEncode encode)
{
    if (encode == NULL) return 0;
    
#ifdef USE_LAME
    lame_mp3_tags(&encode->gf);
#endif
    
    return 1;
}

int mpegEncodeReset(mpegEncode encode)
{
    if (encode == NULL) return 0;

#ifdef USE_LAME
    lame_init_params(&encode->gf);
#else
    codecInit(&encode->cinit_in);
#endif
    
    return 1;
}

int mpegCloseEncoder(mpegEncode encode)
{
    if (encode == NULL) return 0;

    xfree(encode);
    
    return 1;
}
