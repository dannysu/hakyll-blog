/*
 *	output_mpeg.c	version 0.3.0
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>
#include <sp/spWave.h>

#include <sp/mpegCodec.h>
#include <sp/mpegEncode.h>

#include <sp/spOutputPluginP.h>
#include <sp/spPluginMain.h>

#define PHASE_INVERSION
#define SET_DUMMY_AT_FIRST_FRAME

typedef struct _spMpegPluginInstance
{
    int type_index;
    mpegID3Tag id3_tag;
    
    long bit_rate;
    spBool crc_flag;
    spBool copyright_flag;
    spBool copy_flag;

#ifdef USE_LAME
    int quality;
    spBool use_joint_stereo;
    spBool use_lowpass;
    spBool use_vbr;
    int vbr_quality;
    int vbr_min_bitrate;
    int vbr_max_bitrate;
#endif

    FILE *fp;
    mpegEncode encode ;

    mpegHeader header;
    mpegCodecInfo info;

    long current_pos;

    long nloop;
    long nframe;
    long r_offset;

    long i_buf_len, o_buf_len;
    char *i_buf, *o_buf;
    char filename[SP_MAX_PATHNAME];

} *spMpegPluginInstance;
    
#ifdef USE_LAME
#define SP_NUM_MPEG_TYPE 2
#else
#define SP_NUM_MPEG_TYPE 1
#endif
#define SP_MPEG_TYPE_MPEG1_LAYER3 0
#define SP_MPEG_TYPE_MPEG2_LAYER3 1
#define SP_MPEG_TYPE_MPEG1_LAYER2 2
#define SP_MPEG_TYPE_MPEG2_LAYER2 3
#define SP_MPEG_TYPE_MPEG1_LAYER1 4
#define SP_MPEG_TYPE_MPEG2_LAYER1 5

static char *sp_mpeg_file_type_list[] = {
    "mpg1l3",
#ifdef USE_LAME
    "mpg2l3",
#endif
    NULL,
};
static char *sp_mpeg_file_desc_list[] = {
#ifdef USE_LAME
    "MPEG 1.0 Layer III (LAME)",
    "MPEG 2.0 Layer III (LAME)",
#else
    "MPEG 1.0 Layer III (BladeEnc)",
#endif
    NULL,
};
static char *sp_mpeg_file_filter_list[] = {
    "*.mp3",
#ifdef USE_LAME
    "*.mp3",
#endif
    NULL,
};

static int getTypeIndex(mpegHeader *h);

static spBool spInitPluginMpeg(char *lang);
static spBool spFreePluginMpeg(void);
static void *spInitPluginInstanceMpeg(char *lang);
static spBool spFreePluginInstanceMpeg(void *instance);
static spOptions spInitPluginOptionsMpeg(void *instance, char *lang);
static spBool spFreePluginOptionsMpeg(void *instance, spOptions options);

static spBool spIsSupportedByPluginMpeg(char *filename);
static spBool spSetPluginFileTypeMpeg(void *instance, int index);
static int spGetPluginFileTypeMpeg(void *instance);
static spBool spSetPluginSongInfoMpeg(void *instance, spSongInfo *song_info);
static spBool spGetPluginSongInfoMpeg(void *instance, spSongInfo *song_info);
static char *spGetPluginBestSuffixMpeg(void *instance);

static spBool spSetPluginSampleBitMpeg(void *instance, int samp_bit);
static spBool spGetPluginSampleBitMpeg(void *instance, int *samp_bit);
static spBool spSetPluginChannelMpeg(void *instance, int num_channel);
static spBool spGetPluginChannelMpeg(void *instance, int *num_channel);
static spBool spSetPluginSampleRateMpeg(void *instance, double samp_rate);
static spBool spGetPluginSampleRateMpeg(void *instance, double *samp_rate);
static spBool spSetPluginOtherInfoMpeg(void *instance, char *id, char *data);
static spBool spGetPluginOtherInfoMpeg(void *instance, char *id, char *data);

static spPluginError spOpenPluginMpeg(void *instance, char *filename, char *mode);
static spBool spClosePluginMpeg(void *instance);
static spPluginState spGetPluginStateMpeg(void *instance);
static long spGetPluginCurrentPositionMpeg(void *instance);
static spBool spStopPluginMpeg(void *instance);
static spBool spPausePluginMpeg(void *instance);
static spBool spRestartPluginMpeg(void *instance);

static long spWritePluginMpeg(void *instance, char *data, long length);


static spOutputPluginRec sp_output_plugin_mpeg = {
    NULL,
    NULL,

    SP_PLUGIN_OUTPUT,
    "MPEG",
    3,
#ifdef USE_LAME
    SP_PLUGIN_PRIORITY_HIGHEST,
    0,
    spInitPluginMpeg,
    spFreePluginMpeg,
    "MPEG Output Plugin (LAME)",
    "MPEG Output Plugin (LAME) Version 0.3\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
#else
    SP_PLUGIN_PRIORITY_HIGHER,
    0,
    spInitPluginMpeg,
    spFreePluginMpeg,
    "MPEG Output Plugin",
    "MPEG Output Plugin Version 0.3\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
#endif

    spInitPluginInstanceMpeg,
    spFreePluginInstanceMpeg,
    spInitPluginOptionsMpeg,
    spFreePluginOptionsMpeg,

    SP_PLUGIN_DEVICE_FILE,
    sp_mpeg_file_type_list,
    sp_mpeg_file_desc_list,
    sp_mpeg_file_filter_list,
    spIsSupportedByPluginMpeg,
    spSetPluginFileTypeMpeg,  
    spGetPluginFileTypeMpeg,
    SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_ALBUM_MASK
	| SP_SONG_COMMENT_MASK | SP_SONG_RELEASE_MASK | SP_SONG_GENRE_MASK | SP_SONG_TRACK_MASK,
    spSetPluginSongInfoMpeg,
    spGetPluginSongInfoMpeg,
    spGetPluginBestSuffixMpeg,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
    
    spSetPluginSampleBitMpeg,   
    spGetPluginSampleBitMpeg,   
    spSetPluginChannelMpeg,     
    spGetPluginChannelMpeg,     
    spSetPluginSampleRateMpeg,  
    spGetPluginSampleRateMpeg,  
    spSetPluginOtherInfoMpeg,   
    spGetPluginOtherInfoMpeg,
    
    spOpenPluginMpeg,              
    spClosePluginMpeg,             
    spGetPluginStateMpeg,          
    spGetPluginCurrentPositionMpeg,
    spStopPluginMpeg,              
    spPausePluginMpeg,             
    spRestartPluginMpeg,

    spWritePluginMpeg,             
    NULL,
    NULL,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_output_plugin_mpeg;
}

static spBool spInitPluginMpeg(char *lang)
{
    return SP_TRUE;
}

static spBool spFreePluginMpeg(void)
{
    return SP_TRUE;
}

static void *spInitPluginInstanceMpeg(char *lang)
{
    mpegEncode encode;
    spMpegPluginInstance pinstance;
    
    /*spSetDebugLevel(100);*/
	
    if ((encode = mpegOpenEncoder()) == NULL) {
	return SP_FALSE;
    }
	
    pinstance = xalloc(1, struct _spMpegPluginInstance);
    pinstance->type_index = 0;
    mpegInitID3Tag(&pinstance->id3_tag);
    
    pinstance->bit_rate = 128;
    pinstance->crc_flag = SP_FALSE;
    pinstance->copyright_flag = SP_FALSE;
    pinstance->copy_flag = SP_FALSE;

#ifdef USE_LAME
    pinstance->quality = 2;
    pinstance->use_joint_stereo = SP_TRUE;
    pinstance->use_lowpass = SP_FALSE;
    pinstance->use_vbr = SP_FALSE;
    pinstance->vbr_quality = 4;
    pinstance->vbr_min_bitrate = 32;
    pinstance->vbr_max_bitrate = 256;
#endif

    pinstance->fp = NULL;
    pinstance->encode = encode;

    memset(&pinstance->header, 0, sizeof(mpegHeader));
    pinstance->header.version = MPEG1_ID;
    pinstance->header.layer = MPEG_LAYER3_ID;
    pinstance->header.crc_disable = 1;
    pinstance->header.bit_rate = 128000;
    pinstance->header.samp_rate = 44100;
    pinstance->header.original = 1;

    pinstance->current_pos = 0;

    pinstance->nloop = 4;
    pinstance->nframe = 0;
    pinstance->r_offset = 0;

    pinstance->i_buf_len = 0;
    pinstance->o_buf_len = 0;
    pinstance->i_buf = NULL;
    pinstance->o_buf = NULL;
    strcpy(pinstance->filename, "");
    
    return (void *)pinstance;
}

static spBool spFreePluginInstanceMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->encode != NULL) {
	mpegCloseEncoder(pinstance->encode);
    }
    xfree(pinstance);
    
    return SP_TRUE;
}

static spOptions spInitPluginOptionsMpeg(void *instance, char *lang)
{
    int i;
    int num_option;
    spOption *options;
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
#if defined(_WIN32) || defined(MACOS)
#include "options_SJIS.h"
    char *ja_lang = "ja_JP.SJIS";
#else
#include "options_EUCJP.h"
    char *ja_lang = "ja_JP.eucJP";
#endif
    spOption options_en[] = {
#ifdef USE_LAME
	{"-br", NULL, "bit rate (more than 112 for 44.1kHz)", "bit_rate|Bit Rate|130|0|kbit/sec|0",
	     SP_TYPE_COMBO|SP_TYPE_LONG|SP_TYPE_SHOW_TIP, NULL, "56|64|80|96|112|@128|160|192|224|256|320"},
	{"-quality", NULL, "quality (1: best, 9: worst)", "quality|Quality|130",
	     SP_TYPE_COMBO|SP_TYPE_INT|SP_TYPE_SHOW_TIP, NULL, "1|@2|3|4|5|6|7|8|9"},
	{"-js", NULL, "use joint stereo", "joint_stereo|Joint Stereo|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_TRUE_STRING},
	{"-lowpass", NULL, "use lowpass filter", "use_lowpass|Lowpass Filter|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_FALSE_STRING},
	{"-vbr", NULL, "use variable bitrate (VBR)", "use_vbr|Variable Bitrate (VBR)|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_FALSE_STRING},
	{"-vbrq", NULL, "quality for VBR (0: best, 9: worst)", "vbr_quality|VBR Quality|130",
	     SP_TYPE_COMBO|SP_TYPE_INT|SP_TYPE_SHOW_TIP, NULL, "0|1|2|3|@4|5|6|7|8|9"},
	{"-minbr", NULL, "VBR minimum allowed bitrate", "min_bitrate|VBR Minimum Bitrate|130|0|kbit/sec|0",
	     SP_TYPE_COMBO|SP_TYPE_INT|SP_TYPE_SHOW_TIP, NULL, "@32|40|48|56|64|80|96|112|128"},
	{"-maxbr", NULL, "VBR maximum allowed bitrate", "max_bitrate|VBR Maximum Bitrate|130|0|kbit/sec|0",
	     SP_TYPE_COMBO|SP_TYPE_INT|SP_TYPE_SHOW_TIP, NULL, "64|80|96|112|128|160|192|224|@256|"},
#else
	{"-br", NULL, "bit rate", "bit_rate|Bit Rate|130|0|kbit/sec|0",
	     SP_TYPE_COMBO|SP_TYPE_LONG|SP_TYPE_SHOW_TIP, NULL, "56|64|80|96|112|@128|160|192|224|256|320"},
#endif
	{"-crc", NULL, "include checksum data", "crc|CRC Checksum|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_FALSE_STRING},
	{"-copyright", NULL, "set copyright flag", "copyright|Copyrighted|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_FALSE_STRING},
	{"-copy", NULL, "clear original flag", "copy|Not Original|130",
	     SP_TYPE_BOOL|SP_TYPE_SHOW_TIP, NULL, SP_FALSE_STRING},
    };

    if (spEqLanguage(lang, ja_lang)) {
	num_option = spArraySize(options_ja);
	options = options_ja;
    } else {
	num_option = spArraySize(options_en);
	options = options_en;
    }
    i = 0;
    options[i++].value = &pinstance->bit_rate;
#ifdef USE_LAME
    options[i++].value = &pinstance->quality;
    options[i++].value = &pinstance->use_lowpass;
    options[i++].value = &pinstance->use_joint_stereo;
    options[i++].value = &pinstance->use_vbr;
    options[i++].value = &pinstance->vbr_quality;
    options[i++].value = &pinstance->vbr_min_bitrate;
    options[i++].value = &pinstance->vbr_max_bitrate;
#endif
    options[i++].value = &pinstance->crc_flag;
    options[i++].value = &pinstance->copyright_flag;
    options[i++].value = &pinstance->copy_flag;

    return spCopyOptions(num_option, options);
}

static spBool spFreePluginOptionsMpeg(void *instance, spOptions options)
{
    spFreeOptions(options);
    return SP_TRUE;
}

static spBool spSetPluginFileTypeMpeg(void *instance, int index)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (index < SP_NUM_MPEG_TYPE) {
	pinstance->type_index = index;
    }
    
    return SP_TRUE;
}

static int spGetPluginFileTypeMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    return pinstance->type_index;
}

spBool spSetPluginSongInfoMpeg(void *instance, spSongInfo *song_info)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (!mpegCopySongInfoToID3Tag(&pinstance->id3_tag, song_info)) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spGetPluginSongInfoMpeg(void *instance, spSongInfo *song_info)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (!mpegCopyID3TagToSongInfo(song_info, &pinstance->id3_tag)) {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static char *spGetPluginBestSuffixMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    switch (pinstance->header.layer) {
      case 1:	/* layer 3 */
	return ".mp3";
      case 2:	/* layer 2 */
	return ".mp2";
      case 3:	/* layer 1 */
	return ".mpg";
      default:
	break;
    }
    
    return NULL;
}

static spBool spSetPluginSampleBitMpeg(void *instance, int samp_bit)
{
    if (samp_bit != 16) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spGetPluginSampleBitMpeg(void *instance, int *samp_bit)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    *samp_bit = pinstance->info.samp_bit;

    return SP_TRUE;
}

static spBool spSetPluginChannelMpeg(void *instance, int num_channel)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (num_channel == 1) {
	pinstance->header.channel_mode = MPEG_CHANNEL_SINGLE_CHANNEL_ID;
    } else if (num_channel == 2) {
	pinstance->header.channel_mode = MPEG_CHANNEL_STEREO_ID;
    } else {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static spBool spGetPluginChannelMpeg(void *instance, int *num_channel)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    switch (pinstance->header.channel_mode) {
      case MPEG_CHANNEL_SINGLE_CHANNEL_ID:
	*num_channel = 1;
	break;
      default:
	*num_channel = 2;
	break;
    }

    return SP_TRUE;
}

static spBool spSetPluginSampleRateMpeg(void *instance, double samp_rate)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (FABS(samp_rate - 44100.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG1_LAYER3;
	pinstance->header.samp_rate = 44100;
    } else if (FABS(samp_rate - 32000.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG1_LAYER3;
	pinstance->header.samp_rate = 32000;
    } else if (FABS(samp_rate - 48000.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG1_LAYER3;
	pinstance->header.samp_rate = 48000;
#ifdef USE_LAME
    } else if (FABS(samp_rate - 24000.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG2_LAYER3;
	pinstance->header.samp_rate = 24000;
    } else if (FABS(samp_rate - 22050.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG2_LAYER3;
	pinstance->header.samp_rate = 22050;
    } else if (FABS(samp_rate - 16000.0) <= 100.0) {
	pinstance->type_index = SP_MPEG_TYPE_MPEG2_LAYER3;
	pinstance->header.samp_rate = 16000;
#endif
    } else {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spGetPluginSampleRateMpeg(void *instance, double *samp_rate)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    *samp_rate = (double)pinstance->header.samp_rate;

    return SP_TRUE;
}

static spBool spSetPluginOtherInfoMpeg(void *instance, char *id, char *data)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->encode == NULL) return SP_FALSE;
    
    if (streq(id, SP_PLUGIN_INFO_BIT_RATE)) {
	pinstance->bit_rate = atol(data);
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool spGetPluginOtherInfoMpeg(void *instance, char *id, char *data)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->encode == NULL) return SP_FALSE;
    
    if (streq(id, SP_BIT_RATE_ID)) {
	sprintf(data, "%ld", pinstance->bit_rate);
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool spIsSupportedByPluginMpeg(char *filename)
{
    char *p;
    
    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if (/*strcaseeq(p, ".mpg") || strcaseeq(p, ".mp2") ||*/
	    strcaseeq(p, ".mp3")) {
	    return SP_TRUE;
	}
    }

    return SP_FALSE;
}

static spPluginError spOpenPluginMpeg(void *instance, char *filename, char *mode)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
#ifdef USE_LAME
    mpegEncodeOption option;
#endif
    
    /* open file */
    if (strnone(filename)) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    spDebug(10, "spOpenPluginMpeg", "filename = %s\n", filename);

    if ((pinstance->fp = spOpenFile(filename, "wb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }

    strcpy(pinstance->filename, filename);
    
#ifdef USE_LAME
    option.option_mask = 0;
    option.quality = pinstance->quality; option.option_mask |= MPEG_ENC_OPTION_QUALITY;
    option.use_lowpass = pinstance->use_lowpass; option.option_mask |= MPEG_ENC_OPTION_USE_LOWPASS;
    option.use_vbr = pinstance->use_vbr; option.option_mask |= MPEG_ENC_OPTION_USE_VBR;
    option.vbr_quality = pinstance->vbr_quality; option.option_mask |= MPEG_ENC_OPTION_VBR_QUALITY;
    option.vbr_min_bitrate = pinstance->vbr_min_bitrate; option.option_mask |= MPEG_ENC_OPTION_VBR_MIN_BITRATE;
    option.vbr_max_bitrate = pinstance->vbr_max_bitrate; option.option_mask |= MPEG_ENC_OPTION_VBR_MAX_BITRATE;
    option.filename = pinstance->filename;
    mpegSetEncodeOption(pinstance->encode, &option);
    if (pinstance->use_joint_stereo == SP_TRUE && pinstance->header.channel_mode != MPEG_CHANNEL_SINGLE_CHANNEL_ID) {
	pinstance->header.channel_mode =  MPEG_CHANNEL_JOINT_STEREO_ID;
    }
#endif

    pinstance->header.bit_rate = 1000 * pinstance->bit_rate;
    if (pinstance->copyright_flag == SP_TRUE) {
	pinstance->header.copyright = 1;
    } else {
	pinstance->header.copyright = 0;
    }
    if (pinstance->copy_flag == SP_TRUE) {
	pinstance->header.original = 0;
    } else {
	pinstance->header.original = 1;
    }
    spDebug(1, "spOpenPluginMpeg", "bit_rate = %ld, copyright = %d, original = %d\n",
	    pinstance->header.bit_rate, pinstance->header.copyright, pinstance->header.original);
	
    /* get encode information */
    if (!mpegGetEncodeInfo(pinstance->encode, &pinstance->header, &pinstance->info)) {
	spDebug(1, "spOpenPluginMpeg", "Can't get encode information.\n");
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_FAILURE;
    }
    pinstance->type_index = getTypeIndex(&pinstance->header);

    pinstance->nframe = pinstance->info.max_frame_size;
    pinstance->i_buf_len = pinstance->info.max_frame_size * pinstance->nloop;
    pinstance->o_buf_len = pinstance->info.max_output_size * pinstance->nloop;
    spDebug(1, "spOpenPluginMpeg", "pinstance->i_buf_len = %ld, pinstance->o_buf_len = %ld\n",
	    pinstance->i_buf_len, pinstance->o_buf_len);
    if (pinstance->i_buf != NULL) xfree(pinstance->i_buf);
    if (pinstance->o_buf != NULL) xfree(pinstance->o_buf);
    pinstance->i_buf = xalloc(pinstance->i_buf_len, char);
    pinstance->o_buf = xalloc(pinstance->o_buf_len, char);
    
    pinstance->r_offset = 0;
    pinstance->current_pos = 0;
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    long nread, nwrite;
    long i_offset, o_offset;
    long nin, nout;
    
    if (pinstance->fp != NULL) {
	spDebug(1, "spClosePluginMpeg", "last frame: pinstance->r_offset = %ld\n",
		pinstance->r_offset);
	if (pinstance->r_offset > 0) {
	    nread = pinstance->r_offset;
	    
	    nout = 0;
	    i_offset = 0;
	    o_offset = 0;
	    for (;;) {
		if ((nin = MIN(pinstance->nframe, nread - i_offset)) <= 0) {
		    break;
		}
		
		if ((nout = mpegEncodeFrame(pinstance->encode, &pinstance->header, pinstance->i_buf + i_offset,
					    &nin, pinstance->o_buf + o_offset)) <= 0) {
		    break;
		}
	    
		i_offset += nin;
		o_offset += nout;
	    }
	    
	    nwrite = fwrite(pinstance->o_buf, 1, o_offset, pinstance->fp);
	    pinstance->current_pos += ((i_offset / 2) / pinstance->info.num_channel);
	    spDebug(1, "spClosePluginMpeg", "pinstance->current_pos = %ld\n", pinstance->current_pos);
	}
	
	if ((nout = mpegEncodeLastFrame(pinstance->encode, &pinstance->header, pinstance->o_buf)) > 0) {
	    nwrite = fwrite(pinstance->o_buf, 1, nout, pinstance->fp);
	}
	
	mpegWriteID3Tag(&pinstance->id3_tag, pinstance->fp);
	
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	
	mpegEncodeTag(pinstance->encode);
	
	/* memory free */
	xfree(pinstance->i_buf); pinstance->i_buf = NULL;
	xfree(pinstance->o_buf); pinstance->o_buf = NULL;
	pinstance->i_buf_len = 0;
	pinstance->o_buf_len = 0;
	
	pinstance->r_offset = 0;
	pinstance->current_pos = 0;

#ifdef MACOS
	spSetMacFileInfo(pinstance->filename, 0, /*'MP3 '*/'MPG3');
#endif
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;

    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;

    return pinstance->current_pos;
}

static spBool spStopPluginMpeg(void *instance)
{

    return SP_TRUE;
}

static spBool spPausePluginMpeg(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginMpeg(void *instance)
{

    return SP_TRUE;
}

static void copyData(char *dest, char *src, long length)
{
#ifndef PHASE_INVERSION
    memmove(dest, src, length);
#else
    long k;
    short *sdest, *ssrc;

    sdest = (short *)dest;
    ssrc = (short *)src;

    length /= 2;
    
    for (k = 0; k < length; k++) {
	sdest[k] = -ssrc[k];	/* phase inversion */
    }
#endif
    return;
}

static long spWritePluginMpeg(void *instance, char *data, long length)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    long i;
    long nsize;
    long nread, nwrite;
    long data_offset;
    long nin, nout;
    long i_offset, o_offset;

    nsize = (pinstance->info.samp_bit / 8) * length;
    spDebug(1, "spWritePluginMpeg", "nsize = %ld\n", nsize);

    data_offset = 0;
    for (;;) {
	nread = pinstance->i_buf_len - pinstance->r_offset;
	spDebug(1, "spWritePluginMpeg", "nread = %ld, pinstance->r_offset = %ld, data_offset = %ld\n",
		nread, pinstance->r_offset, data_offset);
	if (data_offset + nread > nsize) {
	    nread = nsize - data_offset;
	    copyData(pinstance->i_buf + pinstance->r_offset, data + data_offset, nread);
	    pinstance->r_offset += nread;
	    
	    break;
	}
	copyData(pinstance->i_buf + pinstance->r_offset, data + data_offset, nread);
	data_offset += nread;

#ifdef SET_DUMMY_AT_FIRST_FRAME	/* I don't know why. */
	if (pinstance->current_pos <= 0) {
	    short *sdata = (short *)(pinstance->i_buf + pinstance->r_offset);
	    if (sdata[0] == 0) {
		sdata[0] = 1;
	    }
	}
#endif
	
	nread += pinstance->r_offset;
	pinstance->r_offset = 0;
	    
	nout = 0;
	i_offset = 0;
	o_offset = 0;
	for (i = 0; i < pinstance->nloop; i++) {
	    if ((nin = MIN(pinstance->nframe, nread - i_offset)) <= 0) {
		break;
	    }
	    spDebug(1, "spWritePluginMpeg", "i = %ld, pinstance->nframe = %ld, i_offset = %ld, nin = %ld\n",
		    i, pinstance->nframe, i_offset, nin);
	    
	    if ((nout = mpegEncodeFrame(pinstance->encode, &pinstance->header, pinstance->i_buf + i_offset,
					&nin, pinstance->o_buf + o_offset)) <= 0) {
		spDebug(1, "spWritePluginMpeg", "encode error: nout = %ld\n", nout);
		break;
	    }
	    spDebug(1, "spWritePluginMpeg", "nin = %ld, nout = %ld, i_offset = %ld, o_offset = %ld\n",
		    nin, nout, i_offset, o_offset);
	    
	    i_offset += nin;
	    o_offset += nout;
	}

	if ((nwrite = fwrite(pinstance->o_buf, 1, o_offset, pinstance->fp)) <= 0) {
	    break;
	}
	pinstance->current_pos += ((i_offset / 2) / pinstance->info.num_channel);
	spDebug(1, "spWritePluginMpeg", "pinstance->current_pos = %ld\n", pinstance->current_pos);

	if (nout <= 0) {
	    break;
	}
	if (nread > i_offset) {
	    pinstance->r_offset = nread - i_offset;
	    memmove(pinstance->i_buf, pinstance->i_buf + i_offset, pinstance->r_offset);
	}
    }
    
    return length;
}

static int getTypeIndex(mpegHeader *h)
{
    int index = -1;
    
    switch (h->version) {
      case 1:			/* MPEG 1.0 */
	switch (h->layer) {
	  case 1:
	    index = SP_MPEG_TYPE_MPEG1_LAYER3;
	    break;
	  case 2:
	    index = SP_MPEG_TYPE_MPEG1_LAYER2;
	    break;
	  case 3:
	    index = SP_MPEG_TYPE_MPEG1_LAYER1;
	    break;
	  default:
	    break;
	}
	break;
      case 0:			/* MPEG 2.0 */
	switch (h->layer) {
	  case 1:
	    index = SP_MPEG_TYPE_MPEG2_LAYER3;
	    break;
	  case 2:
	    index = SP_MPEG_TYPE_MPEG2_LAYER2;
	    break;
	  case 3:
	    index = SP_MPEG_TYPE_MPEG2_LAYER1;
	    break;
	  default:
	    break;
	}
	break;
      default:
	break;
    }
    return index;
}

