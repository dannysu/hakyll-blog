This is an MP3 output plugin. You can use the binary version of the
plugin only for education and research. You can't redistribute the
binary version because of the patent-related problems. The source code
I wrote is distributed under the LGPL.

On Windows and Mac OS (except for Mac OS X), you can install the binary
version by putting `output_mpeg.dll' in the folder including the excutable
binary. On Mac OS X, put output_mpeg.bundle in the folder `Contents/MacOS' 
which is located in the executable package.

On UNIX, you have to put `output_mpeg.so' in `/usr/lib/sp/plugins' or
`/usr/local/lib/sp/plugins/'. If you can't do that, you can put it in
`~/.sp_plugins'. The alternative way is to set the environmental variable
`SP_PLUGIN_PATH', and to put `output_mpeg.so' there. You can set several
paths in `SP_PLUGIN_PATH' by separating those with `:'.

To compile from the source code, you have to prepare the source of
BladeEnc (http://bladeenc.mp3.no/) at first.


Hideki BANNO
E-mail: banno@itakura.nuee.nagoya-u.ac.jp
