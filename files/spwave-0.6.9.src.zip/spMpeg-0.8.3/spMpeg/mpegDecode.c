/*
 *	mpegDecode.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>

#include <sp/mpegCodec.h>
#include <sp/mpegDecode.h>

#include <xingmp3/mhead.h>

#define USE_XING_HEADER

#ifdef USE_XING_HEADER
/*---- DXhead.h --------------------------------------------

decoder MPEG Layer III

handle Xing header


Copyright 1998 Xing Technology Corp.
-----------------------------------------------------------*/
/*
// A Xing header may be present in the ancillary
// data field of the first frame of an mp3 bitstream
// The Xing header (optionally) contains
//      frames      total number of audio frames in the bitstream
//      bytes       total number of bytes in the bitstream
//      toc         table of contents

// toc (table of contents) gives seek points
// for random access
// the ith entry determines the seek point for
// i-percent duration
// seek point in bytes = (toc[i]/256.0) * total_bitstream_bytes
// e.g. half duration seek point = (toc[50]/256.0) * total_bitstream_bytes
*/

#define FRAMES_FLAG     0x0001
#define BYTES_FLAG      0x0002
#define TOC_FLAG        0x0004
#define VBR_SCALE_FLAG  0x0008

#define FRAMES_AND_BYTES (FRAMES_FLAG | BYTES_FLAG)

/* structure to receive extracted header
 * toc may be NULL */
typedef struct {
    int h_id;       /* from MPEG header, 0=MPEG2, 1=MPEG1 */
    int samprate;   /* determined from MPEG header */
    int flags;      /* from Xing header data */
    int frames;     /* total bit stream frames from Xing header data */
    int bytes;      /* total bit stream bytes from Xing header data */
    int vbr_scale;  /* encoded vbr scale from Xing header data */
    unsigned char *toc;  /* pointer to unsigned char toc_buffer[100] 
                            may be NULL if toc not desired */
} XHEADDATA;

/*---- DXhead.c --------------------------------------------
  
decoder MPEG Layer III

handle Xing header

mod 12/7/98 add vbr scale

Copyright 1998 Xing Technology Corp.
-----------------------------------------------------------*/
static int ExtractI4(unsigned char *buf)
{
    int x;
    /* big endian extract */

    x = buf[0];
    x <<= 8;
    x |= buf[1];
    x <<= 8;
    x |= buf[2];
    x <<= 8;
    x |= buf[3];

    return x;
}

/* return 0=fail, 1=success
 * X   structure to receive header data (output)
 * buf bitstream input */
static int GetXingHeader(XHEADDATA *X,  unsigned char *buf)
{
    int i, head_flags;
    int h_id, h_mode, h_sr_index;
    static int sr_table[4] = { 44100, 48000, 32000, 99999 };

    /* get Xing header data */

    X->flags = 0;		/* clear to null incase fail */

    /* get selected MPEG header data */
    h_id       = (buf[1] >> 3) & 1;
    h_sr_index = (buf[2] >> 2) & 3;
    h_mode     = (buf[3] >> 6) & 3;

    /* determine offset of header */
    if( h_id ) {		/* mpeg1 */
	if( h_mode != 3 ) buf+=(32+4);
	else              buf+=(17+4);
    }
    else {			/* mpeg2 */
	if( h_mode != 3 ) buf+=(17+4);
	else              buf+=(9+4);
    }

    if( buf[0] != 'X' ) return 0; /* fail */
    if( buf[1] != 'i' ) return 0; /* header not found */
    if( buf[2] != 'n' ) return 0;
    if( buf[3] != 'g' ) return 0;
    buf+=4;

    X->h_id = h_id;
    X->samprate = sr_table[h_sr_index];
    if( h_id == 0 ) X->samprate >>= 1;

    head_flags = X->flags = ExtractI4(buf); buf+=4; /* get flags */

    if( head_flags & FRAMES_FLAG ) {X->frames   = ExtractI4(buf); buf+=4;}
    if( head_flags & BYTES_FLAG )  {X->bytes = ExtractI4(buf); buf+=4;}

    if( head_flags & TOC_FLAG ) {
	if( X->toc != NULL ) {
	    for(i=0;i<100;i++) X->toc[i] = buf[i];
	}
	buf+=100;
    }

    X->vbr_scale = -1;
    if( head_flags & VBR_SCALE_FLAG )  {X->vbr_scale = ExtractI4(buf); buf+=4;}

#if 0
    if( X->toc != NULL ) {
	for(i=0;i<100;i++) {
	    if( (i%10) == 0 ) printf("\n");
	    printf(" %3d", (int)(X->toc[i]));
	}
	printf("\n");
    }
#endif

    return 1;			/* success */
}

#if 0
/* return seekpoint in bytes (may be at eof if percent=100.0)
 * TOC = table of contents from Xing header
 * file_bytes = number of bytes in mp3 file
 * percent = play time percentage of total playtime. May be
 *           fractional (e.g. 87.245) */
static int SeekPoint(unsigned char TOC[100], int file_bytes, float percent)
{
    /* interpolate in TOC to get file seek point in bytes */
    int a, seekpoint;
    float fa, fb, fx;

    if( percent < 0.0f )   percent = 0.0f;
    if( percent > 100.0f ) percent = 100.0f;

    a = (int)percent;
    if( a > 99 ) a = 99;
    fa = TOC[a];
    if( a < 99 ) {
	fb = TOC[a+1];
    }
    else {
	fb = 256.0f;
    }

    fx = fa + (fb-fa)*(percent-a);

    seekpoint = (int)((1.0f/256.0f)*fx*file_bytes); 

    return seekpoint;
}
#endif
#endif

static unsigned char xing_toc[100];

struct _mpegDecode
{
    mpegDecodeOption option;
    int use_int;
    int convert_code;
    long frame_size;
    long output_size;
    int data_offset;
    long frame_count;
    MPEG_HEAD mpeg_head;
#ifdef USE_XING_HEADER
    int xhead_flag;
    XHEADDATA xhead;
#endif
};

typedef struct _MPEG_AUDIO
{
    int (*decode_init) (MPEG_HEAD * h, int framebytes_arg,
			int reduction_code, int transform_code,
			int convert_code, int freq_limit);
    void (*decode_info) (DEC_INFO * info);
    IN_OUT(*decode) (unsigned char *bs, short *pcm);
} *MPEG_AUDIO;

static struct _MPEG_AUDIO mpeg_audio_table[2][2] = {
    {
	{audio_decode_init, audio_decode_info, audio_decode},
	{audio_decode8_init, audio_decode8_info, audio_decode8},
    },
    {
	{i_audio_decode_init, i_audio_decode_info, i_audio_decode},
	{audio_decode8_init, audio_decode8_info, audio_decode8},
    }
};
static MPEG_AUDIO mpeg_audio = NULL;

mpegDecode mpegOpenDecoder(void)
{
    mpegDecode decode;
    
    decode = xalloc(1, struct _mpegDecode);
    decode->option.use_8kHz = 0;
    decode->option.bit_mode = 1;	/* 16 bit linear */
    decode->option.channel_mode = 0;	/* 2 channel output */
    decode->option.reduction_mode = 0; 	/* full sample rate */
    decode->option.freq_limit = 24000; 	/* 24kHz */
    
    decode->use_int = 0;
    decode->convert_code = 0;
    decode->frame_size = 0;
    decode->output_size = 0;
    decode->frame_count = 0;

#ifdef USE_XING_HEADER
    decode->xhead_flag = 0;
#endif
    
    return decode;
}

int mpegSetDecodeOption(mpegDecode decode, mpegDecodeOption *option)
{
    if (decode == NULL || option == NULL) return 0;

    if (option->option_mask & MPEG_DEC_OPTION_USE_8K) {
	decode->option.use_8kHz = option->use_8kHz;
    }
    if (option->option_mask & MPEG_DEC_OPTION_BIT_MODE) {
	decode->option.bit_mode = option->bit_mode;
    }
    if (option->option_mask & MPEG_DEC_OPTION_CHANNEL_MODE) {
	decode->option.channel_mode = option->channel_mode;
    }
    if (option->option_mask & MPEG_DEC_OPTION_REDUCTION_MODE) {
	decode->option.reduction_mode = option->reduction_mode;
    }
    if (option->option_mask & MPEG_DEC_OPTION_FREQ_LIMIT) {
	if (option->freq_limit > 0) decode->option.freq_limit = option->freq_limit;
    }
    
    return 1;
}

int mpegGetDecodeOption(mpegDecode decode, mpegDecodeOption *option)
{
    if (decode == NULL || option == NULL) return 0;

    option->option_mask = MPEG_DEC_OPTION_USE_8K | MPEG_DEC_OPTION_BIT_MODE
	| MPEG_DEC_OPTION_CHANNEL_MODE | MPEG_DEC_OPTION_REDUCTION_MODE | MPEG_DEC_OPTION_FREQ_LIMIT;
    option->use_8kHz = decode->option.use_8kHz;
    option->bit_mode = decode->option.bit_mode;
    option->channel_mode = decode->option.channel_mode;
    option->reduction_mode = decode->option.reduction_mode;
    option->freq_limit = decode->option.freq_limit;
    
    return 1;
}

int mpegDecodeHeader(mpegDecode decode, mpegHeader *header, char *input_buf, long *buf_size)
{
    int bit_rate;
    unsigned int search_forward;
    DEC_INFO decinfo;
    
    if (decode == NULL || header == NULL
	|| input_buf == NULL || buf_size == NULL) return 0;

    if (decode->option.use_8kHz) {
	if (decode->use_int) {
	    mpeg_audio = &mpeg_audio_table[1][1];
	} else {
	    mpeg_audio = &mpeg_audio_table[0][1];
	}
	decode->convert_code = 4 * decode->option.bit_mode + decode->option.channel_mode;
    } else {
	if (decode->use_int) {
	    mpeg_audio = &mpeg_audio_table[1][0];
	} else {
	    mpeg_audio = &mpeg_audio_table[0][0];
	}
	decode->convert_code = decode->option.channel_mode;
    }

    /*decode->frame_size = head_info2(input_buf, *buf_size, &decode->mpeg_head, &bit_rate);*/
    decode->frame_size = head_info3((unsigned char *)input_buf, (unsigned int)*buf_size,
				    &decode->mpeg_head, &bit_rate, &search_forward);
    decode->data_offset = (int)search_forward;
    spDebug(10, "mpegDecodeHeader", "data_offset = %d\n",
	    decode->data_offset);

#ifdef USE_XING_HEADER
    decode->xhead.toc = xing_toc;
    if (!GetXingHeader(&decode->xhead, (unsigned char *)input_buf)) {
	decode->xhead.toc = NULL;
	decode->xhead_flag = 0;
    } else {
	decode->xhead_flag = 1;
    }
#endif
    
    header->bit_rate = (long)bit_rate;
    spDebug(10, "mpegDecodeHeader", "decode->frame_size = %ld\n", decode->frame_size);
    
    if (!mpeg_audio->decode_init(&decode->mpeg_head, (int)decode->frame_size,
				 decode->option.reduction_mode, 0,
				 decode->convert_code, decode->option.freq_limit)) {
	return 0;
    }

    /* get original sampling rate */
    mpeg_audio->decode_info(&decinfo);
    header->samp_rate = decinfo.samprate << decode->option.reduction_mode;

    if (decode->mpeg_head.sync == 2) {
	header->version = MPEG25_ID;
    } else {
	header->version = decode->mpeg_head.id;
    }
    header->layer = decode->mpeg_head.option;
    header->crc_disable = decode->mpeg_head.prot;
    
    header->padding = decode->mpeg_head.pad;
    header->private_bit = decode->mpeg_head.private_bit;
    header->channel_mode = decode->mpeg_head.mode;
    header->mode_extention = decode->mpeg_head.mode_ext;
    header->copyright = decode->mpeg_head.cr;
    header->original = decode->mpeg_head.original;
    header->emphasis = decode->mpeg_head.emphasis;

    if (header->version != MPEG1_ID && header->version != MPEG2_ID
	&& header->version != MPEG25_ID) {
	return 0;
    }
    if (header->layer != MPEG_LAYER1_ID && header->layer != MPEG_LAYER2_ID
	&& header->layer != MPEG_LAYER3_ID) {
	return 0;
    }

    return 1;
}

int mpegGetDecodeInfo(mpegDecode decode, mpegHeader *header, mpegCodecInfo *info)
{
    DEC_INFO decinfo;

    if (decode == NULL || header == NULL
	|| info == NULL	|| mpeg_audio == NULL)
	return 0;
    
    mpeg_audio->decode_info(&decinfo);
    info->num_channel = decinfo.channels;
    info->samp_bit = decinfo.bits;
    info->bit_rate = header->bit_rate;
    info->samp_rate = decinfo.samprate;

    if (decode->xhead_flag) {
	if (header->layer == MPEG_LAYER1_ID) {	/* layer I */
	    if (header->version == MPEG1_ID) {	/* MPEG1 */
		info->max_frame_size = ((24 * 448000 / header->samp_rate) + 1) * 4;
	    } else {
		info->max_frame_size = ((24 * 256000 / header->samp_rate) + 1) * 4;
	    }
	} else {			/* layer II or III */
	    if (header->version == MPEG1_ID) {	/* MPEG1 */
		if (header->layer == MPEG_LAYER2_ID) {	/* layer II */
		    info->max_frame_size = 288 * 384000 / header->samp_rate + 1;
		} else {		/* layer III */
		    info->max_frame_size = 288 * 320000 / header->samp_rate + 1;
		}
	    } else {			/* MPEG2 */
		if (header->version == MPEG25_ID) { /* MPEG2.5 */
		    info->max_frame_size = 144 * 160000 / header->samp_rate + 1;
		} else {
		    info->max_frame_size = 288 * 160000 / header->samp_rate + 1;
		}
	    }
	}
    } else {
	info->max_frame_size = decinfo.framebytes;
	if (header->layer == MPEG_LAYER1_ID) { /* layer I */
	    info->max_frame_size += 4;
	} else {		/* layer II or III */
	    info->max_frame_size += 1;
	}
    }
    
    if (decode->option.bit_mode == 2
	|| decode->option.bit_mode == 3) {
	/* 8 bit case */
	info->max_output_size = decinfo.outvalues;
    } else {
	/* 16 bit case */
	info->max_output_size = 2 * decinfo.outvalues;
    }
    decode->output_size = info->max_output_size;

    info->data_offset = decode->data_offset;
    
    return 1;
}


long mpegDecodeFrame(mpegDecode decode, mpegHeader *header,
		     char *input_buf, long *buf_size, char *output_buf)
{
    static IN_OUT in_out;

    if (decode == NULL || input_buf == NULL || buf_size == NULL
	|| output_buf == NULL || mpeg_audio == NULL)
	return -1;

    in_out = mpeg_audio->decode((unsigned char *)input_buf, (short *)(output_buf));
    *buf_size = in_out.in_bytes;

    decode->frame_count++;
    
    return in_out.out_bytes;
}

long mpegDecodeSkipFrame(mpegDecode decode, mpegHeader *header,
			 char *input_buf, long *buf_size)
{
    int padding;
    int frame_size;
    
    if (decode == NULL || input_buf == NULL || buf_size == NULL)
	return -1;

    if (((unsigned char)input_buf[0] != 0xFF)
	|| ((((unsigned char)input_buf[1]) >> 4) != 0x0F)) {
	return -1;
    }
#ifdef USE_XING_HEADER
    if (decode->xhead_flag) {
	int bit_rate;
	frame_size = head_info2((unsigned char *)input_buf, *buf_size, &decode->mpeg_head,
				&bit_rate);
    } else {
	frame_size = decode->frame_size;
    }
#else
    frame_size = decode->frame_size;
#endif
    
    padding = (((unsigned char)input_buf[2]) & 0x02) >> 1;
    *buf_size = frame_size + padding;
    
    decode->frame_count++;
    
    return decode->output_size;
}

int mpegDecodeReset(mpegDecode decode)
{
    if (decode == NULL || mpeg_audio == NULL) return 0;

    decode->frame_count = 0;
    
    if (!mpeg_audio->decode_init(&decode->mpeg_head, (int)decode->frame_size,
				 decode->option.reduction_mode, 0,
				 decode->convert_code, decode->option.freq_limit)) {
	return 0;
    }

    return 1;
}

int mpegCloseDecoder(mpegDecode decode)
{
    if (decode == NULL) return 0;

    xfree(decode);

    return 1;
}
