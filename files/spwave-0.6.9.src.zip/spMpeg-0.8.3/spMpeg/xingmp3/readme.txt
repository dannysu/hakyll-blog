This source is a part of freeamp-1.3.1.
Please see http://www.freeamp.org for more information.
