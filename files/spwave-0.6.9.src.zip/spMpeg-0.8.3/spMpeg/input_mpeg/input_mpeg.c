/*
 *	input_mpeg.c
 */

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spFile.h>
#include <sp/spMemory.h>
#include <sp/spWave.h>

#include <sp/mpegCodec.h>
#include <sp/mpegDecode.h>

#include <sp/spInputPluginP.h>
#include <sp/spPluginMain.h>

typedef struct _spMpegPluginInstance
{
    int type_index;
    mpegID3Tag id3_tag;
    FILE *fp;
    mpegDecode decode;
    mpegHeader header;
    mpegCodecInfo info;
    
    long skip_header_len;

    long h_buf_len;
    char h_buf[1024];

    long current_pos;
    long current_frame;
    long total_length;

    long nloop;
    long nframe;
    long r_offset;
    long o_offset; 

    long i_buf_len, o_buf_len;
    char *i_buf, *o_buf;
} *spMpegPluginInstance;

#define MPEG_SKIP_FIRST_FRAME 1

#define SP_NUM_MPEG_TYPE 6
#define SP_MPEG_TYPE_MPEG1_LAYER3 0
#define SP_MPEG_TYPE_MPEG2_LAYER3 1
#define SP_MPEG_TYPE_MPEG1_LAYER2 2
#define SP_MPEG_TYPE_MPEG2_LAYER2 3
#define SP_MPEG_TYPE_MPEG1_LAYER1 4
#define SP_MPEG_TYPE_MPEG2_LAYER1 5

static char *sp_mpeg_file_type_list[] = {
    "mpg1l3",
    "mpg2l3",
    "mpg1l2",
    "mpg2l2",
    "mpg1l1",
    "mpg2l1",
    NULL,
};
static char *sp_mpeg_file_desc_list[] = {
    "MPEG 1.0 Layer III",
    "MPEG 2.0 Layer III",
    "MPEG 1.0 Layer II",
    "MPEG 2.0 Layer II",
    "MPEG 1.0 Layer I",
    "MPEG 2.0 Layer I",
    NULL,
};
static char *sp_mpeg_file_filter_list[] = {
    "*.mp3",
    "*.mp3",
    "*.mp2",
    "*.mp2",
    "*.mpg",
    "*.mpg",
    NULL,
};

static spBool spInitPluginMpeg(char *lang);
static spBool spFreePluginMpeg(void);

static void *spInitPluginInstanceMpeg(char *lang);
static spBool spFreePluginInstanceMpeg(void *instance);

static spBool spIsSupportedByPluginMpeg(char *filename);
static spBool spSetPluginFileTypeMpeg(void *instance, int index);
static int spGetPluginFileTypeMpeg(void *instance);
static spBool spSetPluginSongInfoMpeg(void *instance, spSongInfo *song_info);
static spBool spGetPluginSongInfoMpeg(void *instance, spSongInfo *song_info);
static char *spGetPluginBestSuffixMpeg(void *instance);

static spBool spSetPluginSampleBitMpeg(void *instance, int samp_bit);
static spBool spGetPluginSampleBitMpeg(void *instance, int *samp_bit);
static spBool spSetPluginChannelMpeg(void *instance, int num_channel);
static spBool spGetPluginChannelMpeg(void *instance, int *num_channel);
static spBool spSetPluginSampleRateMpeg(void *instance, double samp_rate);
static spBool spGetPluginSampleRateMpeg(void *instance, double *samp_rate);
static spBool spSetPluginOtherInfoMpeg(void *instance, char *id, char *data);
static spBool spGetPluginOtherInfoMpeg(void *instance, char *id, char *data);

static spPluginError spOpenPluginMpeg(void *instance, char *filename, char *mode);
static spBool spClosePluginMpeg(void *instance);
static spPluginState spGetPluginStateMpeg(void *instance);
static long spGetPluginCurrentPositionMpeg(void *instance);
static spBool spStopPluginMpeg(void *instance);
static spBool spPausePluginMpeg(void *instance);
static spBool spRestartPluginMpeg(void *instance);

static long spReadPluginMpeg(void *instance, char *data, long length);
static spBool spSeekPluginMpeg(void *instance, long pos);
static long spGetPluginTotalLengthMpeg(void *instance);


static spInputPluginRec sp_input_plugin_mpeg = {
    NULL,
    NULL,

    SP_PLUGIN_INPUT,
    "MPEG",
    2,
    SP_PLUGIN_PRIORITY_HIGHER,
    0,
    spInitPluginMpeg,
    spFreePluginMpeg,
    "MPEG Input Plugin",
    "MPEG Input Plugin Version 0.2\nCopyright(C) Hideki Banno\nE-mail: banno@itakura.nuee.nagoya-u.ac.jp",
    
    spInitPluginInstanceMpeg,
    spFreePluginInstanceMpeg,
    NULL,
    NULL,

    SP_PLUGIN_DEVICE_FILE,
    sp_mpeg_file_type_list,
    sp_mpeg_file_desc_list,
    sp_mpeg_file_filter_list,
    spIsSupportedByPluginMpeg,
    spSetPluginFileTypeMpeg,  
    spGetPluginFileTypeMpeg,
    SP_SONG_TITLE_MASK | SP_SONG_ARTIST_MASK | SP_SONG_ALBUM_MASK
	| SP_SONG_COMMENT_MASK | SP_SONG_RELEASE_MASK | SP_SONG_GENRE_MASK | SP_SONG_TRACK_MASK,
    spSetPluginSongInfoMpeg,
    spGetPluginSongInfoMpeg,
    spGetPluginBestSuffixMpeg,
    
    NULL,  
    NULL,
    NULL,
    NULL,  
    NULL,
    NULL,
    NULL,
    
    spSetPluginSampleBitMpeg,   
    spGetPluginSampleBitMpeg,   
    spSetPluginChannelMpeg,     
    spGetPluginChannelMpeg,     
    spSetPluginSampleRateMpeg,  
    spGetPluginSampleRateMpeg,  
    spSetPluginOtherInfoMpeg,   
    spGetPluginOtherInfoMpeg,
    
    spOpenPluginMpeg,              
    spClosePluginMpeg,             
    spGetPluginStateMpeg,          
    spGetPluginCurrentPositionMpeg,
    spStopPluginMpeg,              
    spPausePluginMpeg,             
    spRestartPluginMpeg,

    spReadPluginMpeg,             
    spSeekPluginMpeg,
    spGetPluginTotalLengthMpeg,
};

spPluginExport spPluginRec *spGetPluginRec(void)
{
    return (spPluginRec *)&sp_input_plugin_mpeg;
}

static spBool spInitPluginMpeg(char *lang)
{
    return SP_TRUE;
}

static spBool spFreePluginMpeg(void)
{
    return SP_TRUE;
}

static void *spInitPluginInstanceMpeg(char *lang)
{
    mpegDecode decode;
    spMpegPluginInstance pinstance;
    
    if ((decode = mpegOpenDecoder()) == NULL) {
	return NULL;
    }

    pinstance = xalloc(1, struct _spMpegPluginInstance);
    pinstance->type_index = 0;
    mpegInitID3Tag(&pinstance->id3_tag);
    pinstance->fp = NULL;
    pinstance->decode = decode;

    pinstance->skip_header_len = 0;
    pinstance->h_buf_len = 1024;
    
    pinstance->current_pos = 0;
    pinstance->current_frame = 0;
    pinstance->total_length = 0;

    pinstance->nloop = 4;
    pinstance->nframe = 0;
    pinstance->r_offset = 0;
    pinstance->o_offset = 0; 

    pinstance->i_buf_len = 0;
    pinstance->o_buf_len = 0;
    pinstance->i_buf = NULL;
    pinstance->o_buf = NULL;
    
    return (void *)pinstance;
}

static spBool spFreePluginInstanceMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->decode != NULL) {
	mpegCloseDecoder(pinstance->decode);
    }
    xfree(pinstance);
    
    return SP_TRUE;
}

static spBool spSetPluginFileTypeMpeg(void *instance, int index)
{
    /*pinstance->type_index = index;*/
    
    return SP_TRUE;
}

static int spGetPluginFileTypeMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    int index = -1;
    
    switch (pinstance->header.version) {
      case 1:			/* MPEG 1.0 */
	switch (pinstance->header.layer) {
	  case 1:
	    index = SP_MPEG_TYPE_MPEG1_LAYER3;
	    break;
	  case 2:
	    index = SP_MPEG_TYPE_MPEG1_LAYER2;
	    break;
	  case 3:
	    index = SP_MPEG_TYPE_MPEG1_LAYER1;
	    break;
	  default:
	    break;
	}
	break;
      case 0:			/* MPEG 2.0 */
	switch (pinstance->header.layer) {
	  case 1:
	    index = SP_MPEG_TYPE_MPEG2_LAYER3;
	    break;
	  case 2:
	    index = SP_MPEG_TYPE_MPEG2_LAYER2;
	    break;
	  case 3:
	    index = SP_MPEG_TYPE_MPEG2_LAYER1;
	    break;
	  default:
	    break;
	}
	break;
      default:
	break;
    }
    pinstance->type_index = index;
    
    return pinstance->type_index;
}

spBool spSetPluginSongInfoMpeg(void *instance, spSongInfo *song_info)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (!mpegCopySongInfoToID3Tag(&pinstance->id3_tag, song_info)) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

spBool spGetPluginSongInfoMpeg(void *instance, spSongInfo *song_info)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (!mpegCopyID3TagToSongInfo(song_info, &pinstance->id3_tag)) {
	return SP_FALSE;
    }
    
    return SP_TRUE;
}

static char *spGetPluginBestSuffixMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    switch (pinstance->header.layer) {
      case 1:	/* layer 3 */
	return ".mp3";
      case 2:	/* layer 2 */
	return ".mp2";
      case 3:	/* layer 1 */
	return ".mpg";
      default:
	break;
    }
    
    return NULL;
}

static spBool spSetPluginSampleBitMpeg(void *instance, int samp_bit)
{
    if (samp_bit != 16) {
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spGetPluginSampleBitMpeg(void *instance, int *samp_bit)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    *samp_bit = pinstance->info.samp_bit;

    return SP_TRUE;
}

static spBool spSetPluginChannelMpeg(void *instance, int num_channel)
{
    if (num_channel == 1
	|| num_channel == 2) {
	return SP_TRUE;
    } else {
	return SP_FALSE;
    }
}

static spBool spGetPluginChannelMpeg(void *instance, int *num_channel)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    *num_channel = pinstance->info.num_channel;

    return SP_TRUE;
}

static spBool spSetPluginSampleRateMpeg(void *instance, double samp_rate)
{

    return SP_TRUE;
}

static spBool spGetPluginSampleRateMpeg(void *instance, double *samp_rate)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    *samp_rate = (double)pinstance->info.samp_rate;

    return SP_TRUE;
}

static spBool spSetPluginOtherInfoMpeg(void *instance, char *id, char *data)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->decode == NULL) return SP_FALSE;
    
    if (streq(id, SP_PLUGIN_INFO_MPEG_DECODE_OPTION)) {
	mpegDecodeOption *option = (mpegDecodeOption *)data;
	mpegSetDecodeOption(pinstance->decode, option);
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool spGetPluginOtherInfoMpeg(void *instance, char *id, char *data)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->decode == NULL) return SP_FALSE;
    
    if (streq(id, SP_MPEG_DECODE_OPTION_ID)) {
	mpegDecodeOption *option = (mpegDecodeOption *)data;
	mpegGetDecodeOption(pinstance->decode, option);
	return SP_TRUE;
    }

    return SP_FALSE;
}

static spBool decodeMpegHeader(spMpegPluginInstance pinstance, FILE *fp)
{
    if (pinstance->decode == NULL || fp == NULL) return SP_FALSE;

    /* read header */
    pinstance->h_buf_len = 1024;
    if ((pinstance->h_buf_len = fread(pinstance->h_buf, 1, pinstance->h_buf_len, fp)) <= 0
	|| (pinstance->skip_header_len = mpegGetUnsupportedHeaderSize(pinstance->h_buf, pinstance->h_buf_len)) < 0) {
	spDebug(1, "spOpenPluginMpeg", "Can't read header.\n");
	return SP_FALSE;
    }
    spDebug(10, "spOpenPluginMpeg", "skip_len = %ld\n", pinstance->skip_header_len);
    if (pinstance->skip_header_len > 0) {
	fseek(fp, pinstance->skip_header_len, SEEK_SET);
	if ((pinstance->h_buf_len = fread(pinstance->h_buf, 1, pinstance->h_buf_len, fp)) <= 0) {
	    return SP_FALSE;
	}
    }

    /* decode header */
    if (!mpegDecodeHeader(pinstance->decode, &pinstance->header, pinstance->h_buf, &pinstance->h_buf_len)) {
	spDebug(1, "spOpenPluginMpeg", "Can't decode header.\n");
	return SP_FALSE;
    }

    return SP_TRUE;
}

static spBool spIsSupportedByPluginMpeg(char *filename)
{
    char *p;
    spBool flag = SP_FALSE;

    if (filename != NULL && (p = strrchr(filename, '.')) != NULL) {
	if ((strcaseeq(p, ".mpg") || strcaseeq(p, ".mp2")
	     || strcaseeq(p, ".mp3") || strcaseeq(p, ".rmp"))) {
	    flag = SP_TRUE;
	}
    }

    return flag;
}

static spPluginError spOpenPluginMpeg(void *instance, char *filename, char *mode)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    /* open file */
    if (strnone(filename) || (pinstance->fp = spOpenFile(filename, "rb")) == NULL) {
	return SP_PLUGIN_ERROR_OPEN;
    }
    spDebug(10, "spOpenPluginMpeg", "filename = %s\n", filename);

    mpegReadID3Tag(&pinstance->id3_tag, pinstance->fp);
    fseek(pinstance->fp, 0L, SEEK_SET);

    /* decode header */
    if (decodeMpegHeader(pinstance, pinstance->fp) == SP_FALSE) {
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_FAILURE;
    }
    if (!mpegGetDecodeInfo(pinstance->decode, &pinstance->header, &pinstance->info)) {
	spDebug(1, "spOpenPluginMpeg", "Can't get decode information.\n");
	spCloseFile(pinstance->fp); pinstance->fp = NULL;
	return SP_PLUGIN_ERROR_FAILURE;
    }
    spDebug(1, "spOpenPluginMpeg",
	    "data_offset = %ld, max_frame_size = %ld, max_output_size = %ld\n",
	    pinstance->info.data_offset, pinstance->info.max_frame_size, pinstance->info.max_output_size);

    pinstance->nframe = pinstance->info.max_frame_size;
    pinstance->i_buf_len = pinstance->info.max_frame_size * pinstance->nloop;
    pinstance->o_buf_len = pinstance->info.max_output_size * pinstance->nloop;
    spDebug(1, "spOpenPluginMpeg", "pinstance->i_buf_len = %ld, pinstance->o_buf_len = %ld\n", pinstance->i_buf_len, pinstance->o_buf_len);
    if (pinstance->i_buf != NULL) xfree(pinstance->i_buf);
    if (pinstance->o_buf != NULL) xfree(pinstance->o_buf);
    pinstance->i_buf = xalloc(pinstance->i_buf_len, char);
    pinstance->o_buf = xalloc(pinstance->o_buf_len, char);

    spDebug(1, "spOpenPluginMpeg", "alloc done\n");
    
    /* get total length */
    spGetPluginTotalLengthMpeg(instance);

    fseek(pinstance->fp, pinstance->info.data_offset + pinstance->skip_header_len, SEEK_SET);

    pinstance->r_offset = 0;
    pinstance->o_offset = 0;
    pinstance->current_pos = 0;
    pinstance->current_frame = 0;

    spDebug(10, "spOpenPluginMpeg", "done\n");
    
    return SP_PLUGIN_ERROR_SUCCESS;
}

static spBool spClosePluginMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	spDebug(1, NULL, "pinstance->r_offset = %ld, pinstance->o_offset = %ld\n", pinstance->r_offset, pinstance->o_offset);
	
	/* close file */
	spCloseFile(pinstance->fp);
	pinstance->fp = NULL;
	
	/* memory free */
	xfree(pinstance->i_buf); pinstance->i_buf = NULL;
	xfree(pinstance->o_buf); pinstance->o_buf = NULL;
	pinstance->i_buf_len = 0;
	pinstance->o_buf_len = 0;
	
	pinstance->r_offset = 0;
	pinstance->o_offset = 0;
	pinstance->current_pos = 0;
	pinstance->current_frame = 0;
	pinstance->total_length = 0;
    }

    return SP_TRUE;
}

static spPluginState spGetPluginStateMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->current_pos > 0) {
	return SP_PLUGIN_STATE_START;
    }

    return SP_PLUGIN_STATE_STOP;
}

static long spGetPluginCurrentPositionMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    return pinstance->current_pos;
}

static spBool spStopPluginMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->fp != NULL) {
	fseek(pinstance->fp, 0, SEEK_SET);
	mpegDecodeReset(pinstance->decode);
    }
    pinstance->current_pos = 0;
    pinstance->current_frame = 0;
    
    pinstance->r_offset = 0;
    pinstance->o_offset = 0;

    return SP_TRUE;
}

static spBool spPausePluginMpeg(void *instance)
{

    return SP_TRUE;
}

static spBool spRestartPluginMpeg(void *instance)
{

    return SP_TRUE;
}

static long readPlugin(spMpegPluginInstance pinstance, char *data, long length, spBool skip_flag)
{
    int flag = 0;
    long i;
    long nsize;
    long nread, nwrite;
    long data_offset;
    long nin, nout;
    long i_offset; 
    
    if (pinstance->fp == NULL) return -1;

    nsize = (long)(pinstance->info.samp_bit / 8) * length;
    data_offset = 0;

    if (skip_flag == SP_FALSE) {
	flag = 1;
    }
    
    if (pinstance->o_offset > 0) {
	if (nsize <= pinstance->o_offset) {
	    if (skip_flag == SP_FALSE) {
		memmove(data, pinstance->o_buf, nsize);
	    }
	    pinstance->o_offset -= nsize;
	    if (pinstance->o_offset > 0) {
		memmove(pinstance->o_buf, pinstance->o_buf + nsize, pinstance->o_offset);
	    }
	    return length;
	} else {
	    if (skip_flag == SP_FALSE) {
		memmove(data, pinstance->o_buf, pinstance->o_offset);
	    }
	    data_offset = pinstance->o_offset;
	}
    }
    pinstance->o_offset = 0;
    
    for (;;) {
	if ((nread = fread(pinstance->i_buf + pinstance->r_offset, 1, pinstance->i_buf_len - pinstance->r_offset, pinstance->fp)) <= 0
	    && pinstance->r_offset <= 0) {
	    break;
	}
	spDebug(1, NULL, "nread = %ld, pinstance->r_offset = %ld\n", nread, pinstance->r_offset);

	nread += pinstance->r_offset;
	pinstance->r_offset = 0;

	nout = 0;
	i_offset = 0;
	pinstance->o_offset = 0;
	for (i = 0; i < pinstance->nloop; i++) {
	    if ((nin = MIN(pinstance->nframe, nread - i_offset)) <= 0) {
		break;
	    }
	    spDebug(1, NULL, "i = %ld, pinstance->nframe = %ld, i_offset = %ld, nin = %ld\n",
		    i, pinstance->nframe, i_offset, nin);

	    if (skip_flag == SP_FALSE || pinstance->current_pos + 96 * pinstance->info.max_frame_size > nsize) {
		if (!flag) {
		    mpegDecodeReset(pinstance->decode);
		    flag = 1;
		}
		if ((nout = mpegDecodeFrame(pinstance->decode, &pinstance->header, pinstance->i_buf + i_offset,
					    &nin, pinstance->o_buf + pinstance->o_offset)) <= 0) {
		    break;
		}
	    } else {
		if ((nout = mpegDecodeSkipFrame(pinstance->decode, &pinstance->header, pinstance->i_buf + i_offset, &nin)) <= 0) {
		    break;
		}
		memset(pinstance->o_buf + pinstance->o_offset, 0, nout);
	    }
	    spDebug(1, NULL, "nin = %ld, nout = %ld\n", nin, nout);
	    
	    i_offset += nin;
	    if (!MPEG_SKIP_FIRST_FRAME || pinstance->current_frame > 0) {
		pinstance->o_offset += nout;
	    }
	    pinstance->current_frame++;
	}

	if (nread > i_offset) {
	    pinstance->r_offset = nread - i_offset;
	    memmove(pinstance->i_buf, pinstance->i_buf + i_offset, pinstance->r_offset);
	}
	
	nwrite = pinstance->o_offset;
	if (data_offset + nwrite >= nsize) {
	    nwrite = nsize - data_offset;

	    if (skip_flag == SP_FALSE) {
		if (nwrite > 0) {
		    memmove(data + data_offset, pinstance->o_buf, nwrite);
		}
	    }
	    data_offset += nwrite;
	    pinstance->current_pos += nwrite;
	    
	    pinstance->o_offset -= nwrite;
	    if (pinstance->o_offset > 0) {
		memmove(pinstance->o_buf, pinstance->o_buf + nwrite, pinstance->o_offset);
	    }
	    break;
	}
	if (skip_flag == SP_FALSE) {
	    memmove(data + data_offset, pinstance->o_buf, nwrite);
	}
	data_offset += nwrite;
	pinstance->current_pos += nwrite;
	pinstance->o_offset = 0;
	
	if (nout <= 0) {
	    break;
	}
    }
    
    pinstance->current_pos /= (long)(pinstance->info.num_channel * (pinstance->info.samp_bit / 8));
    
    return data_offset / (long)(pinstance->info.samp_bit / 8);
}

static long spReadPluginMpeg(void *instance, char *data, long length)
{
    return readPlugin((spMpegPluginInstance)instance, data, length, SP_FALSE);
}

static spBool spSeekPluginMpeg(void *instance, long pos)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;
    
    if (pinstance->fp == NULL) return SP_FALSE;
    
    fseek(pinstance->fp, pinstance->info.data_offset + pinstance->skip_header_len, SEEK_SET);

    pinstance->current_pos = 0;
    pinstance->current_frame = 0;
    pinstance->r_offset = 0;
    pinstance->o_offset = 0;
    
    if (pos == 0) {
	mpegDecodeReset(pinstance->decode);
	return SP_TRUE;
    }
    
    if (readPlugin(pinstance, NULL, pos * pinstance->info.num_channel, SP_TRUE) >= 0) {
	return SP_TRUE;
    }

    return SP_FALSE;
}

static long spGetPluginTotalLengthMpeg(void *instance)
{
    spMpegPluginInstance pinstance = (spMpegPluginInstance)instance;    
    long i;
    long nread;
    long nin, nout;
    long i_offset; 
    
    if (pinstance->fp != NULL && pinstance->total_length <= 0) {
	spDebug(1, "spOpenPluginMpeg", "data_offset = %ld\n", pinstance->info.data_offset);
	
	fseek(pinstance->fp, pinstance->info.data_offset + pinstance->skip_header_len, SEEK_SET);

	pinstance->current_pos = 0;
	pinstance->current_frame = 0;
	pinstance->r_offset = 0;
	pinstance->o_offset = 0;
	for (;;) {
	    if ((nread = fread(pinstance->i_buf + pinstance->r_offset, 1, pinstance->i_buf_len - pinstance->r_offset, pinstance->fp)) <= 0
		&& pinstance->r_offset <= 0) {
		break;
	    }
	    spDebug(1, "spGetPluginTotalLengthMpeg",
		    "nread = %ld, pinstance->r_offset = %ld\n", nread, pinstance->r_offset);
	    
	    nread += pinstance->r_offset;
	    pinstance->r_offset = 0;
	
	    nout = 0;
	    i_offset = 0;
	    pinstance->o_offset = 0;
	    for (i = 0; i < pinstance->nloop; i++) {
		if ((nin = MIN(pinstance->nframe, nread - i_offset)) <= 0) {
		    break;
		}

		if ((nout = mpegDecodeSkipFrame(pinstance->decode, &pinstance->header, pinstance->i_buf + i_offset, &nin)) <= 0) {
		    break;
		}
		
		i_offset += nin;
		if (!MPEG_SKIP_FIRST_FRAME || pinstance->current_frame > 0) {
		    pinstance->o_offset += nout;
		}
		pinstance->current_frame++;
	    }
	    pinstance->current_pos += pinstance->o_offset;
	    spDebug(1, "spGetPluginTotalLengthMpeg",
		    "i_offset = %ld, pinstance->current_pos = %ld\n", i_offset, pinstance->current_pos);
	
	    if (nout <= 0) {
		break;
	    }
	    
	    if (nread > i_offset) {
		pinstance->r_offset = nread - i_offset;
		memmove(pinstance->i_buf, pinstance->i_buf + i_offset, pinstance->r_offset);
	    }
	}

	pinstance->total_length = pinstance->current_pos / (pinstance->info.num_channel * (pinstance->info.samp_bit / 8));
	spDebug(1, "spGetPluginTotalLengthMpeg",
		"pinstance->total_length = %ld\n", pinstance->total_length);
	
	pinstance->current_pos = 0;
	pinstance->current_frame = 0;
	pinstance->r_offset = 0;
	pinstance->o_offset = 0;
	
	mpegDecodeReset(pinstance->decode);
	/*fseek(pinstance->fp, pinstance->info.data_offset + pinstance->skip_header_len, SEEK_SET);*/
    }

    return pinstance->total_length;
}

