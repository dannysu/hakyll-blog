/*
 *	mpegCodec.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sp/spDefs.h>
#include <sp/spBase.h>
#include <sp/spMemory.h>
#include <sp/spFile.h>
#include <sp/spKanji.h>

#include <sp/spWave.h>

#include <sp/mpegCodec.h>

int mpegShowHeaderInfo(mpegHeader *header, char *indent, FILE *fp)
{
    if (header == NULL) return 0;

    if (fp == NULL) fp = stderr;
    if (indent != NULL) fprintf(fp, indent);
    
    spDebug(10, "mpegShowHeaderInfo", "version = %d\n", header->version);
    switch (header->version) {
      case MPEG1_ID:
	fprintf(fp, "MPEG 1.0");
	break;
      case MPEG2_ID:
	fprintf(fp, "MPEG 2.0");
	break;
      default:
	return 0;
    }
    fprintf(fp, " ");

    spDebug(10, "mpegShowHeaderInfo", "layer = %d\n", header->layer);
    switch (header->layer) {
      case MPEG_LAYER3_ID:
	fprintf(fp, "Layer III");
	break;
      case MPEG_LAYER2_ID:
	fprintf(fp, "Layer II");
	break;
      case MPEG_LAYER1_ID:
	fprintf(fp, "Layer I");
	break;
      default:
	return 0;
    }
    fprintf(fp, "  ");

    if (header->copyright) {
	fprintf(fp, "Copyrighted  ");
    }
    if (header->copyright) {
	fprintf(fp, "Original  ");
    }
    
    switch (header->channel_mode) {
      case MPEG_CHANNEL_JOINT_STEREO_ID:
	fprintf(fp, "Joint Stereo");
	break;
      case MPEG_CHANNEL_DUAL_CHANNEL_ID:
	fprintf(fp, "Dual Channel");
	break;
      case MPEG_CHANNEL_SINGLE_CHANNEL_ID:
	fprintf(fp, "Single Channel");
	break;
      case MPEG_CHANNEL_STEREO_ID:
      default:
	fprintf(fp, "Stereo");
	break;
    }
    fprintf(fp, "  \n");
    
    if (indent != NULL) fprintf(fp, indent);
    fprintf(fp, "Bit Rate: %.0fkbit/sec", (double)header->bit_rate / 1000.0);
    fprintf(fp, "  ");
    fprintf(fp, "Sampling Rate: %.1fkHz", (double)header->samp_rate / 1000.0);
    fprintf(fp, "\n");
    
    return 1;
}

static char *mpeg_id3_genres[] =
{
    "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop",
    "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock",
    "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack",
    "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance",
    "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
    "Alt", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop",
    "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial",
    "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult",
    "Gangsta Rap", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American",
    "Cabaret", "New Wave", "Psychedelic", "Rave", "Showtunes", "Trailer", "Lo-Fi",
    "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll",
    "Hard Rock", "Folk", "Folk/Rock", "National Folk", "Swing", "Fast-Fusion", "Bebob",
    "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock",
    "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band",
    "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera",
    "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove",
    "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad",
    "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A Cappella",
    "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", "Terror",
    "Indie", "BritPop", "Negerpunk", "Polsk Punk", "Beat", "Christian Gangsta Rap",
    "Heavy Metal", "Black Metal", "Crossover", "Contemporary Christian",
    "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "JPop", "Synthpop",
    "Unknown Genre",
};

static void setWhiteSpace(char *tag_item, int size)
{
    int i;
    
    for (i = 0; i < size; i++) {
	tag_item[i] = ' ';
    }
    
    return;
}

int mpegInitID3Tag(mpegID3Tag *tag)
{
    if (tag == NULL) return 0;

    memset(tag, 0, sizeof(mpegID3Tag));
    tag->tag[0] = 'T';
    tag->tag[1] = 'A';
    tag->tag[2] = 'G';
    tag->genre = 148;		/* "Unknown Genre" */
    setWhiteSpace(tag->title, 30);
    setWhiteSpace(tag->artist, 30);
    setWhiteSpace(tag->album, 30);
    setWhiteSpace(tag->year, 4);
    setWhiteSpace(tag->comment, 30);

    return 1;
}

int mpegReadID3Tag(mpegID3Tag *tag, FILE *fp)
{
    int tag_size;
    mpegID3Tag id3tag;
    
    if (tag == NULL || fp == NULL) return 0;

    fseek(fp, -128, SEEK_END);

    tag_size = sizeof(mpegID3Tag);
    if (fread((char *)&id3tag, 1, tag_size, fp) != tag_size) {
	return 0;
    }

    if (!strneq(id3tag.tag, "TAG", 3)) {
	return 0;
    }

    memmove(tag, &id3tag, tag_size);

    return 1;
}

int mpegWriteID3Tag(mpegID3Tag *tag, FILE *fp)
{
    int tag_size;
    
    if (tag == NULL || fp == NULL) return 0;

    if (!strneq(tag->tag, "TAG", 3)) {
	return 0;
    }
    
    fseek(fp, 0, SEEK_END);

    tag_size = sizeof(mpegID3Tag);
    if (fwrite((char *)tag, 1, tag_size, fp) != tag_size) {
	return 0;
    }

    return 1;
}

static int num_genres = 0;

char *mpegGetID3TagGenreString(int genre)
{
    if (num_genres <= 0) {
	num_genres = (int)(sizeof(mpeg_id3_genres) / sizeof(mpeg_id3_genres[0]));
    }
    
    if (genre >= num_genres) {
	return NULL;
    }
    
    return mpeg_id3_genres[genre];
}

int mpegGetID3TagGenreNumber(mpegID3Tag *tag)
{
    if (num_genres <= 0) {
	num_genres = (int)(sizeof(mpeg_id3_genres) / sizeof(mpeg_id3_genres[0]));
    }
    
    if (tag == NULL || tag->genre >= num_genres) {
	return (num_genres - 1);
    }
    
    return (int)tag->genre;
}

char *mpegGetID3TagGenre(mpegID3Tag *tag)
{
    return mpeg_id3_genres[mpegGetID3TagGenreNumber(tag)];
}

static void getTagItemString(char *string, char *tag_item, int size)
{
    int i;
    
    strncpy(string, tag_item, size);
    string[size] = '\0';
    
    if (size == 30 && string[28] == '\0') {
	/* There is track information. */
	size = 28;
    }

    for (i = size - 1; i >= 0; i--) {
	if (string[i] != ' ') {
	    break;
	}
	string[i] = '\0';
    }

    return;
}

/* size of buf must be more than 31 */
int mpegGetID3TagItem(mpegID3Tag *tag, int item_id, char *buf)
{
    spKanjiCode kanji_code;
    static char string[SP_MAX_MESSAGE] = "";

    if (tag == NULL || buf == NULL) return 0;
    
    switch (item_id) {
      case MPEG_ID3_TITLE_ID:
	getTagItemString(buf, tag->title, 30);
	break;
      case MPEG_ID3_ARTIST_ID:
	getTagItemString(buf, tag->artist, 30);
	break;
      case MPEG_ID3_ALBUM_ID:
	getTagItemString(buf, tag->album, 30);
	break;
      case MPEG_ID3_COMMENT_ID:
	getTagItemString(buf, tag->comment, 30);
	break;
      case MPEG_ID3_YEAR_ID:
	getTagItemString(buf, tag->year, 4);
	break;
      case MPEG_ID3_GENRE_ID:
	strcpy(buf, mpegGetID3TagGenre(tag));
	break;
      case MPEG_ID3_GENRE_NUMBER_ID:
	sprintf(buf, "%d", mpegGetID3TagGenreNumber(tag)); 
	break;
      default:
	return 0;
    }

    if (strwhite(buf)) {
	return 0;
    }

    if ((kanji_code = spGetLocaleKanjiCode(NULL)) != SP_KANJI_CODE_UNKNOWN) {
#ifdef MACOS
	kanji_code = SP_KANJI_CODE_SJIS;
#endif
	spSetKanjiCode(SP_KANJI_CODE_SJIS, kanji_code);
	spConvertKanji((unsigned char *)buf, (unsigned char *)string, sizeof(string));
	strcpy(buf, string);
    }
    
    return 1;
}

int mpegSetID3TagGenreNumber(mpegID3Tag *tag, int number)
{
    if (tag == NULL) return -1;
    
    if (num_genres <= 0) {
	num_genres = (int)(sizeof(mpeg_id3_genres) / sizeof(mpeg_id3_genres[0]));
    }

    if (number < 0 || number >= num_genres) {
	tag->genre = num_genres - 1;
    } else {
	tag->genre = number;
    }
    
    return (int)tag->genre;
}

int mpegSetID3TagGenre(mpegID3Tag *tag, char *genre)
{
    int i;

    if (tag == NULL || genre == NULL) return -1;
    
    if (num_genres <= 0) {
	num_genres = (int)(sizeof(mpeg_id3_genres) / sizeof(mpeg_id3_genres[0]));
    }

    tag->genre = num_genres - 1;
    for (i = 0; i < num_genres; i++) {
	if (strcaseeq(mpeg_id3_genres[i], genre)) {
	    tag->genre = i;
	    break;
	}
    }
    
    return tag->genre;
}

static void setTagItemString(char *tag_item, char *string, int size)
{
    int i;
    int len;
    
    strncpy(tag_item, string, size);
    
    if ((len = strlen(string)) < size) {
	for (i = len; i < size; i++) {
	    tag_item[i] = ' ';
	}
    }

    return;
}

int mpegSetID3TagItem(mpegID3Tag *tag, int item_id, char *buf)
{
    spKanjiCode kanji_code;
    static char string[SP_MAX_MESSAGE] = "";

    if (tag == NULL || buf == NULL) return 0;

    if ((kanji_code = spGetLocaleKanjiCode(NULL)) != SP_KANJI_CODE_UNKNOWN) {
#ifdef MACOS
	kanji_code = SP_KANJI_CODE_SJIS;
#endif
	spSetKanjiCode(kanji_code, SP_KANJI_CODE_SJIS);
	spConvertKanji((unsigned char *)buf, (unsigned char *)string, sizeof(string));
    } else {
	strcpy(string, buf);
    }
    
    switch (item_id) {
      case MPEG_ID3_TITLE_ID:
	setTagItemString(tag->title, string, 30);
	break;
      case MPEG_ID3_ARTIST_ID:
	setTagItemString(tag->artist, string, 30);
	break;
      case MPEG_ID3_ALBUM_ID:
	setTagItemString(tag->album, string, 30);
	break;
      case MPEG_ID3_COMMENT_ID:
	setTagItemString(tag->comment, string, 30);
	break;
      case MPEG_ID3_YEAR_ID:
	setTagItemString(tag->year, string, 4);
	break;
      case MPEG_ID3_GENRE_ID:
	mpegSetID3TagGenre(tag, string);
	break;
      case MPEG_ID3_GENRE_NUMBER_ID:
	mpegSetID3TagGenreNumber(tag, atoi(string));
	break;
      default:
	return 0;
    }

    return 1;
}

int mpegShowID3TagInfo(mpegID3Tag *tag, char *indent, FILE *fp)
{
    char buf[40];

    if (tag == NULL) return 0;

    if (fp == NULL) fp = stderr;
    
    if (mpegGetID3TagItem(tag, MPEG_ID3_TITLE_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Title: %s\n", buf);
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_ARTIST_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Artist: %s\n", buf);
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_ALBUM_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Album: %s\n", buf);
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_GENRE_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Genre: %s\n", buf);
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_YEAR_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Year: %s\n", buf);
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_COMMENT_ID, buf)) {
	if (indent != NULL) fprintf(fp, indent);
	fprintf(fp, "Comment: %s\n", buf);
	
	if (buf[28] == '\0' && buf[29] != '\0') {
	    /* comment of version 1.1. so get track number */
	    fprintf(fp, "Track: %d\n", (int)buf[29]);
	}
    }
    
    return 1;
}

int mpegCopyID3TagToSongInfo(spSongInfo *song_info, mpegID3Tag *tag)
{
    if (song_info == NULL || tag == NULL) return 0;
    
    spInitSongInfo(song_info);
    song_info->info_mask = SP_SONG_NO_INFO;
    if (mpegGetID3TagItem(tag, MPEG_ID3_TITLE_ID, song_info->title)) {
	song_info->info_mask |= SP_SONG_TITLE_MASK;
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_ARTIST_ID, song_info->artist)) {
	song_info->info_mask |= SP_SONG_ARTIST_MASK;
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_ALBUM_ID, song_info->album)) {
	song_info->info_mask |= SP_SONG_ALBUM_MASK;
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_COMMENT_ID, song_info->comment)) {
	song_info->info_mask |= SP_SONG_COMMENT_MASK;
	
	if (song_info->comment[28] == '\0' && song_info->comment[29] != '\0') {
	    /* comment of version 1.1. so get track number */
	    song_info->info_mask |= SP_SONG_TRACK_MASK;
	    song_info->track = (int)song_info->comment[29];
	}
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_YEAR_ID, song_info->release)) {
	song_info->info_mask |= SP_SONG_RELEASE_MASK;
    }
    if (mpegGetID3TagItem(tag, MPEG_ID3_GENRE_ID, song_info->genre)) {
	song_info->info_mask |= SP_SONG_GENRE_MASK;
    }

    return 1;
}

int mpegCopySongInfoToID3Tag(mpegID3Tag *tag, spSongInfo *song_info)
{
    if (tag == NULL || song_info == NULL) return 0;
    
    mpegInitID3Tag(tag);
    if (song_info->info_mask & SP_SONG_TITLE_MASK)
	mpegSetID3TagItem(tag, MPEG_ID3_TITLE_ID, song_info->title);
    if (song_info->info_mask & SP_SONG_ARTIST_MASK)
	mpegSetID3TagItem(tag, MPEG_ID3_ARTIST_ID, song_info->artist);
    if (song_info->info_mask & SP_SONG_ALBUM_MASK)
	mpegSetID3TagItem(tag, MPEG_ID3_ALBUM_ID, song_info->album);
    if (song_info->info_mask & SP_SONG_RELEASE_MASK)
	mpegSetID3TagItem(tag, MPEG_ID3_YEAR_ID, song_info->release);
    if (song_info->info_mask & SP_SONG_COMMENT_MASK || song_info->info_mask & SP_SONG_TRACK_MASK) {
	char buf[SP_SONG_INFO_SIZE];

	if (song_info->info_mask & SP_SONG_COMMENT_MASK) {
	    strcpy(buf, song_info->comment);
	} else {
	    int i;
	    for (i = 0; i < 30; i++) {
		buf[i] = ' ';
	    }
	}
	if (song_info->info_mask & SP_SONG_TRACK_MASK) {
	    buf[28] = '\0';
	    buf[29] = (char)song_info->track;
	}
	mpegSetID3TagItem(tag, MPEG_ID3_COMMENT_ID, buf);
    }
    if (song_info->info_mask & SP_SONG_GENRE_MASK)
	mpegSetID3TagItem(tag, MPEG_ID3_GENRE_ID, song_info->genre);
    
    return 1;
}

long mpegGetUnsupportedHeaderSize(char *input_buf, long buf_size)
{
    char *ptr;
    long header_size = 0;
    spLong32 size;
    
    if (input_buf == NULL || buf_size < 4) return 0;
    
    if (strneq("RIFF", input_buf, 4)) {
	if (buf_size < 20) {
	    return 0;
	}
	
	header_size = 12;
	for (;;) {
	    ptr = input_buf + header_size;
	    
	    memcpy(&size, ptr + 4, 4);
#if SP_WAV_NEED_SWAP
	    swaplong32(&size, 1);
#endif
	    header_size += 8;
	    
	    if (strneq("data", ptr, 4)) {
		break;
	    }
	    header_size += size;

	    if (header_size >= buf_size) {
		return 0;
	    }
	}
	spDebug(10, "mpegGetUnsupportedHeaderSize", "header_size = %ld\n", header_size);
    } else if (strneq("ID3", input_buf, 3)) {
        int i;
        char buf[4];
	
	if (buf_size < 10) {
	    return 0;
	}
	memcpy(buf, input_buf + 6, 4);

	size = 0;
	for (i = 0; i < 4; i++) {
	    size = (size << 7) | (((spLong32)buf[i]) & ((1 << 7) - 1));
	}
	spDebug(10, "mpegGetUnsupportedHeaderSize", "size = %ld\n", size);
	header_size = size + 10;
    }
    
    return header_size;
}
