/*
 *	mpegDecode.h
 */

#ifndef __MPEGDECODE_H
#define __MPEGDECODE_H

#include <sp/mpegCodec.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _mpegDecode *mpegDecode;

#define MPEG_DEC_OPTION_USE_8K (1<<1)
#define MPEG_DEC_OPTION_BIT_MODE (1<<2)
#define MPEG_DEC_OPTION_CHANNEL_MODE (1<<3)
#define MPEG_DEC_OPTION_REDUCTION_MODE (1<<4)
#define MPEG_DEC_OPTION_FREQ_LIMIT (1<<5)

typedef struct _mpegDecodeOption
{
    unsigned long option_mask;
    int use_8kHz;		/* use 8kHz output */
    int bit_mode;		/* 1 = 16 bit linear pcm
				 * 2 =  8 bit (unsigned) linear pcm
				 * 3 = u-law (8 bits unsigned) */
    int channel_mode;		/* 0 = 2 channel output 
				 * 1 = convert 2 channel to mono
				 * 2 = convert 2 channel to left channel
				 * 3 = convert 2 channel to right channel */
    int reduction_mode;		/* 0 = full sample rate output
				 * 1 = half rate
				 * 2 = quarter rate */
    long freq_limit;
} mpegDecodeOption;

extern mpegDecode mpegOpenDecoder(void);
extern int mpegSetDecodeOption(mpegDecode decode, mpegDecodeOption *option);
extern int mpegGetDecodeOption(mpegDecode decode, mpegDecodeOption *option);
extern int mpegDecodeHeader(mpegDecode decode, mpegHeader *header, char *input_buf, long *buf_size);
extern int mpegGetDecodeInfo(mpegDecode decode, mpegHeader *header, mpegCodecInfo *info);
extern long mpegDecodeFrame(mpegDecode decode, mpegHeader *header,
			    char *input_buf, long *buf_size, char *output_buf);
extern long mpegDecodeSkipFrame(mpegDecode decode, mpegHeader *header,
				char *input_buf, long *buf_size);
extern int mpegDecodeReset(mpegDecode decode);
extern int mpegCloseDecoder(mpegDecode decode);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __MPEGDECODE_H */
