/*
 *	mpegCodec.h
 */

#ifndef __MPEGCODEC_H
#define __MPEGCODEC_H

#include <stdio.h>
#include <sp/spWave.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SPMPEG_VERSION_STRING	"0.8.3"
#define SPMPEG_VERSION 		0
#define SPMPEG_REVISION		8
#define SPMPEG_UPDATE_LEVEL	3
#define SPMPEG_VERSION_ID	(SPMPEG_VERSION * 1000 + SPMPEG_REVISION)

#define SPMPEG_CHECK_VERSION(version, revision, update) \
    (SPMPEG_VERSION > (version) || \
     (SPMPEG_VERSION == (version) && SPMPEG_REVISION > (revision)) || \
     (SPMPEG_VERSION == (version) && SPMPEG_REVISION == (revision) && SPMPEG_UPDATE_LEVEL >= (update)))
    
#define MPEG1_ID 1
#define MPEG2_ID 0
#define MPEG25_ID 2

#define MPEG_LAYER1_ID 3
#define MPEG_LAYER2_ID 2
#define MPEG_LAYER3_ID 1
    
#define MPEG_CHANNEL_STEREO_ID 0
#define MPEG_CHANNEL_JOINT_STEREO_ID 1
#define MPEG_CHANNEL_DUAL_CHANNEL_ID 2
#define MPEG_CHANNEL_SINGLE_CHANNEL_ID 3
    
typedef struct _mpegHeader
{
    int version;		/* 0 = MPEG2, 1 = MPEG1, 2 = MPEG2.5 */
    int layer;			/* 0 = reserved, 1 = Layer3, 2 = Layer2, 3 = Layer1 */
    int crc_disable;		/* 0 = protected by CRC, 1 = not protedted */
    long bit_rate;		/* bit rate [bit/sec] */
    long samp_rate;		/* sampling rate */
    int padding;		/* 0 = frame is not padded, 1 = frame is padded width one extra slot */
    int private_bit;		/* private bit */
    int channel_mode;		/* 0 = Stereo, 1 = Joint stereo, 2 = Dual channel, 3 = Single channel */
    int mode_extention;		/* only used in Joint stereo */
    int copyright;		/* 0 = not copyrighted, 1 = copyrighted */
    int original;		/* 0 = copy of original, 1 = original */
    int emphasis;		/* 0 = none, 1 = 50/15ms, 2 = reserved, 3 = CCIT J.17 */
} mpegHeader;

typedef struct _mpegCodecInfo
{
   int num_channel;		/* number of channels */
   int samp_bit;		/* bits per sample */
   long bit_rate;		/* bit rate */
   long samp_rate;		/* sampling rate */
   long max_frame_size;		/* maximum frame size */
   long max_output_size;	/* maximum output frame size */
   long data_offset;		/* data offset */
} mpegCodecInfo;

#define MPEG_ID3_TITLE_ID 1
#define MPEG_ID3_ARTIST_ID 2
#define MPEG_ID3_ALBUM_ID 3
#define MPEG_ID3_YEAR_ID 4
#define MPEG_ID3_COMMENT_ID 5
#define MPEG_ID3_GENRE_ID 6
#define MPEG_ID3_GENRE_NUMBER_ID 7

typedef struct _mpegID3Tag
{
    char tag[3];		/* 'T', 'A', 'G' */
    char title[30];
    char artist[30];
    char album[30];
    char year[4];
    char comment[30];
    unsigned char genre;
} mpegID3Tag;

extern int mpegShowHeaderInfo(mpegHeader *header, char *indent, FILE *fp);
extern int mpegInitID3Tag(mpegID3Tag *tag);
extern int mpegReadID3Tag(mpegID3Tag *tag, FILE *fp);
extern int mpegWriteID3Tag(mpegID3Tag *tag, FILE *fp);
extern char *mpegGetID3TagGenreString(int genre);
extern int mpegGetID3TagGenreNumber(mpegID3Tag *tag);
extern char *mpegGetID3TagGenre(mpegID3Tag *tag);
extern int mpegGetID3TagItem(mpegID3Tag *tag, int item_id, char *buf);
extern int mpegSetID3TagGenreNumber(mpegID3Tag *tag, int number);
extern int mpegSetID3TagGenre(mpegID3Tag *tag, char *genre);
extern int mpegSetID3TagItem(mpegID3Tag *tag, int item_id, char *buf);
extern int mpegShowID3TagInfo(mpegID3Tag *tag, char *indent, FILE *fp);
extern int mpegCopyID3TagToSongInfo(spSongInfo *song_info, mpegID3Tag *tag);
extern int mpegCopySongInfoToID3Tag(mpegID3Tag *tag, spSongInfo *song_info);
extern long mpegGetUnsupportedHeaderSize(char *input_buf, long buf_size);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __MPEGCODEC_H */
