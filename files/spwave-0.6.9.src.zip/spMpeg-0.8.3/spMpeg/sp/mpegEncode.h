/*
 *	mpegEncode.h
 */

#ifndef __MPEGENCODE_H
#define __MPEGENCODE_H

#include <sp/spDefs.h>
#include <sp/mpegCodec.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _mpegEncode *mpegEncode;

#define MPEG_ENC_OPTION_QUALITY (1<<0)
#define MPEG_ENC_OPTION_USE_LOWPASS (1<<1)
#define MPEG_ENC_OPTION_USE_VBR (1<<2)
#define MPEG_ENC_OPTION_VBR_QUALITY (1<<3)
#define MPEG_ENC_OPTION_VBR_MIN_BITRATE (1<<4)
#define MPEG_ENC_OPTION_VBR_MAX_BITRATE (1<<5)

typedef struct _mpegEncodeOption
{
    unsigned long option_mask;
    int quality;
    int use_lowpass;

    /* for VBR */
    int use_vbr;
    int vbr_quality;
    int vbr_min_bitrate;	/* in kbps */
    int vbr_max_bitrate;	/* in kbps */
    char *filename;		/* required for VBR */
} mpegEncodeOption;

extern mpegEncode mpegOpenEncoder(void);
/* call before mpegGetEncodeInfo */
extern int mpegSetEncodeOption(mpegEncode encode, mpegEncodeOption *option);
extern int mpegGetEncodeOption(mpegEncode encode, mpegEncodeOption *option);
extern int mpegGetEncodeInfo(mpegEncode encode, mpegHeader *header, mpegCodecInfo *info);
extern long mpegEncodeFrame(mpegEncode encode, mpegHeader *header, char *input_buf, long *buf_size, char *output_buf);
extern long mpegEncodeLastFrame(mpegEncode encode, mpegHeader *header, char *output_buf);
/* You must call the following function after encoding (the file must be closed) if you use VBR. */
extern int mpegEncodeTag(mpegEncode encode);
extern int mpegEncodeReset(mpegEncode encode);
extern int mpegCloseEncoder(mpegEncode encode);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration */
#endif

#endif /* __MPEGENCODE_H */
