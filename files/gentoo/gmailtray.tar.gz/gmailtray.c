/**
 * Author: Chien-Wen (Danny) Su (thedumbkid@gmail.com)
 *
 * References:
 *      1. Ilia Alshanetsky's PHP script to check for new mail
 *         http://ilia.ws/archives/15_Gmail_as_an_online_backup_system.html
 *      2. Dan Born's systraymail
 *         http://danborn.net/systraymail/
 *      3. gtray
 *         http://fraggle.alkali.org/projects/gtray/
 *
 * TODO:
 *	1. Improve speed when checking
 *	2. Complete preferences implementation (figure out how to store password and stuff, time interval between checks)
 *	3. Don't even write to .gmailtemp, just proccess result... need to figure how to do this with curl
 *	4. see other "TODO's" within the file
 */
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

#include <gtk/gtk.h>
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>

#include "eggtrayicon.h"

// All possible status
enum
{
	CONNECTING,
	NOMAIL,
	NEWMAIL,
	DISCONNECTED,
};

// Maximum length for file path information
const gint PATHMAX = 256;

// Status messages
const char *msg_newmail = "new mail";
const char *msg_nomail = "no new mail";
const char *msg_connecting = "connecting to gmail";
const char *msg_disconnected = "not connected";

// TODO: read username and password from preferences
const char *username = "";
const char *password = "";

char cookies[512];
char gv[43];

CURL *curl;
CURLcode res;

/* Mailbox polling times in seconds. */
size_t local_period, remote_period;

// Status of the program and/or gmail account...
gshort status;

gint currentcount;

// Indicates whether there are any dialog opened currently
gboolean dialog_open;

sigset_t block;

GtkImage *trayicon;
GdkPixbuf *icon_nomail;
GdkPixbuf *icon_newmail;
GdkPixbuf *icon_connecting;
GtkTooltips *tooltip;
EggTrayIcon *eggtray;
GtkWidget *menu = NULL;

GdkPixbuf *get_icon (const char *filename)
{
	GdkPixbuf *pixb = gdk_pixbuf_new_from_file (filename, NULL);
	if (pixb == NULL)
		fprintf (stderr, "Could not load icon from '%s'\n", filename);
	return pixb;
}

/**
 * Read settings from $HOME/.gmailtrayrc and initialize.
 * @return TRUE for success, FALSE otherwise.
 */
gboolean read_preferences() {
	const char *HOME = getenv("HOME");
	FILE *config = NULL; // File pointer to the configuration file
	char tmp[PATHMAX];
	char *config_path = NULL;
	icon_nomail = icon_newmail = icon_connecting = NULL;
	status = DISCONNECTED;

	// Check that program was able to obtain user's $HOME path
	if (HOME == NULL) {
		fputs("HOME not defined.  Can't get config.\n", stderr);
		goto read_config_err;
	}

	config_path = (char *)malloc(strlen(HOME) + strlen("/.gmailtrayrc"));
	strcpy(config_path, HOME);
	strcat(config_path, "/.gmailtrayrc");

	// Try to open file for read
	if ((config = fopen(config_path, "r")) == NULL) {
		// TODO: add code to create default config file or copy it from somewhere...
		perror("fopen");
		goto read_config_err;
	}

	// Try to obtain nomail pixmap
	if ( fgets(tmp, PATHMAX, config) == NULL ) {
		perror("nomail pixmap not found.");
		goto read_config_err;
	}
	else {
		// verify that newline is correctly read
		if ( tmp[strlen(tmp) - 1] != '\n' )
		{
			perror("read error.");
			goto read_config_err;
		}
		tmp[strlen(tmp) - 1] = '\0'; // delete the newline character
		icon_nomail = get_icon(tmp);
	}

	// Try to obtain newmail pixmap
	if ( fgets(tmp, PATHMAX, config) == NULL ) {
		perror("newmail pixmap not found.");
		goto read_config_err;
	}
	else {
		if ( tmp[strlen(tmp) - 1] != '\n' )
		{
			perror("read error.");
			goto read_config_err;
		}
		tmp[strlen(tmp) - 1] = '\0'; // delete the newline character
		icon_newmail = get_icon(tmp);
	}

	// TODO: I can write a simple readline() function to save coding

	// Try to obtain connecting pixmap
	if ( fgets(tmp, PATHMAX, config) == NULL ) {
		perror("connecting pixmap not found.");
		goto read_config_err;
	}
	else {
		if ( tmp[strlen(tmp) - 1] != '\n' )
		{
			perror("read error.");
			goto read_config_err;
		}
		tmp[strlen(tmp) - 1] = '\0'; // delete the newline character
		icon_connecting = get_icon(tmp);
	}

/*
    fscanf(cfg, "%d\n", &remote_period);
    if(remote_period < MIN_REMOTE) {
        fprintf(stderr, "%s%d%s%d\n",
                "Local check must be >= ", MIN_REMOTE, " seconds, found ",
                remote_period);
        goto read_config_err;
    }
*/

	free(config_path);
	fclose(config);
	return TRUE;
read_config_err:
	free(config_path);
	if(config != NULL)
		fclose(config);
	return FALSE;
}

void destroy(void) {
	gtk_widget_destroy(GTK_WIDGET(trayicon));
	
	if(icon_nomail != NULL)
		g_object_unref(icon_nomail);
	if(icon_newmail != NULL)
		g_object_unref(icon_newmail);
	if (icon_connecting != NULL)
		g_object_unref(icon_connecting);
		
	icon_nomail = icon_newmail = icon_connecting = NULL;
	
	gtk_widget_destroy(GTK_WIDGET(eggtray));
	
	// always cleanup
	if (curl)
		curl_easy_cleanup(curl);
}

/**
 * Update the system tray display.  Resets the icon and tooltip.
 */
void redisplay(void) {
    GdkPixbuf *pixb = NULL;

	switch(status)
	{
		case NEWMAIL:
    	    pixb = icon_newmail;
	   		gtk_tooltips_set_tip(tooltip, GTK_WIDGET(eggtray), msg_newmail, NULL);
			break;
		case NOMAIL:
    	    pixb = icon_nomail;
	   		gtk_tooltips_set_tip(tooltip, GTK_WIDGET(eggtray), msg_nomail, NULL);
			break;
		case CONNECTING:
    	    pixb = icon_connecting;
	   		gtk_tooltips_set_tip(tooltip, GTK_WIDGET(eggtray), msg_connecting, NULL);
			break;
		case DISCONNECTED:
    	    pixb = icon_connecting;
	   		gtk_tooltips_set_tip(tooltip, GTK_WIDGET(eggtray), msg_disconnected, NULL);
			break;
	}

    if(pixb != NULL && gtk_image_get_pixbuf(trayicon) != pixb)
		gtk_image_set_from_pixbuf(trayicon, pixb);
}

/**
 * Updates current status (nomail or newmail, etc) as well as the icons
 */
void set_status(gint s)
{
	status = s;
	redisplay();
}

/* Catch a SIGHUP, and reload config.
 */
void reload_config(int sigtype) {
    destroy();
    if(!read_preferences()) {
        fputs("Error reloading config.\n", stderr);
        gtk_main_quit();
    }
}

void quit(void) {
	fputs("Destroyed!\n", stderr);
	gtk_main_quit();
}

/**
 * Extract the number of unread mail from curl retrieved page
 */
size_t extract_newmail (void *ptr, size_t size, size_t nmemb, FILE *stream)
{
	char *count = NULL;
	char *start = strstr((char *)ptr, "Search results for: is:unread");
	char *end = NULL;
	
	if (start != NULL)
	{
		start += 44;
		end = strstr(start, "]");
		
		if (end == NULL)
		{
			printf("ERROR!!!\n");
		}
		else
		{
			count = (char *)malloc(end - start);
			
			strncpy (count, start, end - start);
			currentcount = atoi(count);
			
			free(count);
		}
	}
	
	return fwrite(ptr, size, nmemb, stream);
}

/**
 * Extract SID information and other things needed for curl to work with gmail
 */
size_t write_func(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
	char *temp = strstr((char *)ptr, "SID=");

	if (temp != NULL)
	{
		temp += 4;
		strcat (cookies, "SID=");
		strncat (cookies, temp, 89);
	}
	else
	{
		temp = strstr((char *)ptr, "var cookieVal=");
		
		if (temp != NULL)
		{
			strncpy (gv, (char *)(temp + 16), 43);
			gv[43] = '\0';
		}
	}
	
	return fwrite(ptr, size, nmemb, stream);
}

gboolean gmail_login(void)
{
	char *postdata = NULL;
	postdata = (char *)malloc (8 + 19 + 13 + strlen(username) + strlen(password));
	
	// TODO: sprintf???
	strcpy (postdata, "service=mail&Email=");
	strcat (postdata, username);
	strcat (postdata, "&Passwd=");
	strcat (postdata, password);
	strcat (postdata, "&Passwd=");
	
	strcpy (cookies, "");

	if (curl) {
		set_status(CONNECTING);
		// NOTE: since I'm not calling curl_easy_cleanup... all the stuff already set with easy_setopt don't need to be set again!
		
		FILE *outfile = NULL;
		outfile = fopen(".gmailtemp","w");
		curl_easy_setopt (curl, CURLOPT_WRITEDATA, outfile);
		curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, write_func);
		curl_easy_setopt (curl, CURLOPT_URL, "https://gmail.google.com/accounts/ServiceLoginBoxAuth");
		curl_easy_setopt (curl, CURLOPT_SSL_VERIFYHOST,  2);
		curl_easy_setopt (curl, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.4b) Gecko/20030430 Mozilla Firebird/0.6");
		curl_easy_setopt (curl, CURLOPT_POST, 1);
		curl_easy_setopt (curl, CURLOPT_HEADER, 1);
		curl_easy_setopt (curl, CURLOPT_POSTFIELDS, postdata);
		curl_easy_setopt (curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		res = curl_easy_perform (curl);
		fclose(outfile);
		
		if (res != CURLE_OK)
		{
			return FALSE;
		}

		char temp_cookies[512];
		strcpy (temp_cookies, cookies);
		cookies[0] = '\0';

		outfile = fopen(".gmailtemp", "w");
		curl_easy_setopt (curl, CURLOPT_WRITEDATA, outfile);
		curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, write_func);
		curl_easy_setopt (curl, CURLOPT_URL, "https://www.google.com/accounts/CheckCookie?service=mail&chtml=LoginDoneHtml");
		curl_easy_setopt (curl, CURLOPT_SSL_VERIFYHOST,  2);
		curl_easy_setopt (curl, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.4b) Gecko/20030430 Mozilla Firebird/0.6");
		curl_easy_setopt (curl, CURLOPT_HEADER, 1);
		curl_easy_setopt (curl, CURLOPT_COOKIE, temp_cookies);
		curl_easy_setopt (curl, CURLOPT_SSL_VERIFYPEER, FALSE); 
		res = curl_easy_perform (curl);
		fclose (outfile);
		if (res != CURLE_OK) return FALSE;

		strcpy (cookies, temp_cookies);
		strcat (cookies, " GV=");
		strcat (cookies, gv);

		return TRUE;
	}
	else
	{
		curl = curl_easy_init ();
		set_status(DISCONNECTED);
		return FALSE;
	}
}

/**
 * Check whether there's any new emails
 * @return Number of new messages
 */
void gmail_check_mail (void)
{
	if (!gmail_login())
	{
		set_status (DISCONNECTED);
		return;
	}

	currentcount = -1;

	FILE *outfile;
	outfile = fopen(".gmailtemp", "w");
	curl_easy_setopt (curl, CURLOPT_WRITEDATA, outfile);
	curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, extract_newmail);
	curl_easy_setopt (curl, CURLOPT_URL, "https://gmail.google.com/gmail?search=adv&as_subset=unread&view=tl&start=0");
	curl_easy_setopt (curl, CURLOPT_SSL_VERIFYHOST,  2);
	curl_easy_setopt (curl, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.4b) Gecko/20030430 Mozilla Firebird/0.6");
	curl_easy_setopt (curl, CURLOPT_COOKIE, cookies);
	curl_easy_setopt (curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_easy_setopt (curl, CURLOPT_TIMEOUT, 60);
	res = curl_easy_perform (curl);
	fclose (outfile);
	
	if (res != CURLE_OK)
	{
		set_status (DISCONNECTED);
		return;
	}
	else if (currentcount < 0)
	{
		// NOTE! error occured or something
		return;
	}
	else if (currentcount == 0)
	{
		set_status (NOMAIL);
	}
	else
	{
		set_status (NEWMAIL);
	}

	// TODO: popup something when new mail arrives?
	// TODO: probably need to keep track of # of new email last time... so I can't keep on saying new mail if user has already checked
}

/**
 */
static void clicked (GtkWidget *widget, GdkEventButton *event, gpointer data)
{
	if (!dialog_open)
		gtk_menu_popup (GTK_MENU (menu), NULL, NULL, NULL, NULL, event->button, event->time);
}

/**
 * Create menu for the systray icon
 */
void create_menu (void)
{
	// TODO: what about language support? is it pango?
	GtkWidget *menuitem;
	
	menu = gtk_menu_new ();

	menuitem = gtk_image_menu_item_new_with_label ("check now");
	gtk_image_menu_item_set_image (GTK_IMAGE_MENU_ITEM(menuitem), gtk_image_new_from_stock(GTK_STOCK_REFRESH, GTK_ICON_SIZE_MENU));
	g_signal_connect (G_OBJECT (menuitem), "activate", G_CALLBACK (gmail_check_mail), 0);
	gtk_menu_shell_append (GTK_MENU_SHELL (menu), menuitem);
	
	menuitem = gtk_image_menu_item_new_with_label ("preferences");
	gtk_image_menu_item_set_image (GTK_IMAGE_MENU_ITEM(menuitem), gtk_image_new_from_stock(GTK_STOCK_PREFERENCES, GTK_ICON_SIZE_MENU));
//	g_signal_connect (G_OBJECT (menuitem), "activate", G_CALLBACK (preferences_dialog), 0);
	gtk_menu_shell_append (GTK_MENU_SHELL (menu), menuitem);

/*
	menuitem = gtk_menu_item_new_with_label ("about");
	g_signal_connect (G_OBJECT (menuitem), "activate", G_CALLBACK (about_dialog), 0);
	gtk_menu_shell_append (GTK_MENU_SHELL (menu), menuitem);
*/

	menuitem = gtk_separator_menu_item_new ();
	gtk_menu_shell_append (GTK_MENU_SHELL (menu), menuitem);

	menuitem = gtk_image_menu_item_new_with_label ("exit");
	gtk_image_menu_item_set_image (GTK_IMAGE_MENU_ITEM(menuitem), gtk_image_new_from_stock(GTK_STOCK_QUIT, GTK_ICON_SIZE_MENU));
	g_signal_connect (G_OBJECT (menuitem), "activate", G_CALLBACK (gtk_main_quit), 0);
	gtk_menu_shell_append (GTK_MENU_SHELL (menu), menuitem);
	
	gtk_widget_show_all (menu);
}

/**
 * Initialize system tray, menu, icons
 */
void create_tray (void)
{
	GtkWidget *box;
	
	if (menu == NULL) create_menu ();
	
	eggtray = egg_tray_icon_new ("gmail notification");
	box = gtk_event_box_new ();
	trayicon = GTK_IMAGE(gtk_image_new ());
	tooltip = gtk_tooltips_new();
	 
	gtk_container_add (GTK_CONTAINER (box), GTK_WIDGET(trayicon));
	gtk_container_add (GTK_CONTAINER (eggtray), box);
	gtk_image_set_from_pixbuf(trayicon, icon_connecting); // TODO: do I need this if I call redisplay?
	gtk_widget_show_all (GTK_WIDGET (eggtray));
	
	g_signal_connect (G_OBJECT (box), "button-press-event", G_CALLBACK (clicked), NULL);
}

/**
 */
int main(int argc, char *argv[]) {
	struct sigaction act;

	gtk_init(&argc, &argv);

/*
 * Initialization code... probably should just shove in a function
 */
	dialog_open = FALSE;
	curl = curl_easy_init ();
	currentcount = -1;

	if(!read_preferences()) {
		fputs("Could not read config.\n", stderr);
		return -1;
	}
	
	// After reading preferences, create system tray icon
	create_tray ();

	/* SIGHUP to reload config. */
	act.sa_handler = reload_config;
	if(sigemptyset(&act.sa_mask) != 0) {
		perror("sigemptyset");
		return errno;
	}
	act.sa_flags = 0;
	if(sigaction(SIGHUP, &act, NULL) != 0) {
		perror("sigaction SIGHUP");
		return errno;
	}

	/* SIGUSR1 to force an immediate mailcheck. */
	/*
	act.sa_handler = check_all_boxes;
	if(sigaction(SIGUSR1, &act, NULL) != 0) {
		perror("sigaction SIGUSR1");
		return errno;
	}
	*/

	/* Signals to block while doing mail checks. */
	block = act.sa_mask;
	if(sigaddset(&block, SIGHUP) != 0 || sigaddset(&block, SIGUSR1) != 0) {
		perror("sigaddset");
		return errno;
	}

	// Periodic mail checks.
	gint local_period = 30;
	g_timeout_add(local_period * 1000, gmail_check_mail, NULL);

	redisplay();

	// TODO: check to see if user and password are set... if yes, start connecting
	gtk_image_set_from_pixbuf(trayicon, icon_nomail); // TODO: do I need this if I call redisplay?
	
	// Startup initial mail check.
	gmail_check_mail();

	gtk_main();

	destroy();
    
	return 0;
}
